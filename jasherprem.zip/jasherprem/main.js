const { Telegraf, session } = require('telegraf');
const { BOT_TOKEN } = require('./config');
const { connectDB } = require('./lib/database');
const { handleStart, handleHelp, handleCredit } = require('./src/commands');
const { handleCallbackQuery, handleTextMessage, handleNewChatMembers } = require('./src/handlers');

// Connect to MongoDB
connectDB();

// Initialize bot
const bot = new Telegraf(BOT_TOKEN);

// Middleware
bot.use(session());

// Command handlers
bot.command('start', handleStart);
bot.command('help', handleHelp);
bot.command('credit', handleCredit);
bot.command('share', (ctx) => {
  if (ctx.chat.type !== 'private') {
    return ctx.reply('Fitur share hanya bisa digunakan di private chat!');
  }
  
  return ctx.reply(
    '📤 <b>Share Menu</b>\n\nPilih jenis share:',
    {
      parse_mode: 'HTML',
      reply_markup: require('./src/keyboards').shareMenuKeyboard().reply_markup
    }
  );
});

// Event handlers
bot.on('callback_query', handleCallbackQuery);
bot.on('text', handleTextMessage);
bot.on('new_chat_members', handleNewChatMembers);

// Error handling
bot.catch((err, ctx) => {
  console.error(`Error for ${ctx.updateType}:`, err);
  ctx.reply('Terjadi kesalahan, silakan coba lagi.');
});

// Start bot
bot.launch().then(() => {
  console.log('Bot started successfully');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));