const { Telegraf, session } = require('telegraf');
const { message } = require('telegraf/filters');
const { BOT_TOKEN } = require('./config');
const { initializeDatabase, getUser, updateUser, addToGroup, getGroup } = require('./lib/database');
const { handleStart, handleShare, handleAddGroup, handleJoinGroup, handleStats } = require('./src/handlers');
const { mainKeyboard, shareOptionsKeyboard } = require('./src/keyboards');

// Initialize bot
const bot = new Telegraf(BOT_TOKEN);

// Use session middleware
bot.use(session());

// Initialize database
initializeDatabase();

// Start command
bot.command('start', handleStart);

// Share command - only works in private chat
bot.command('share', async (ctx) => {
    if (ctx.chat.type !== 'private') {
        return ctx.reply('Perintah /share hanya dapat digunakan di chat private dengan bot.');
    }
    await handleShare(ctx);
});

// Add group command - for group admins
bot.command('addgroup', handleAddGroup);

// Join group command - for users to join a group
bot.command('joingroup', handleJoinGroup);

// Stats command - check user credits
bot.command('stats', handleStats);

// Handle callback queries (buttons)
bot.on('callback_query', async (ctx) => {
    const data = ctx.callbackQuery.data;
    const userId = ctx.from.id;
    const user = getUser(userId);
    
    switch (data) {
        case 'join_group':
            await ctx.reply('Silakan tambahkan bot ke grup Anda terlebih dahulu, kemudian gunakan perintah /addgroup di grup tersebut.');
            break;
            
        case 'share_message':
            if (user.credits < 1) {
                await ctx.reply('Kredit Anda tidak cukup. Silakan join grup terlebih dahulu untuk mendapatkan kredit.');
                return ctx.answerCbQuery();
            }
            
            await ctx.reply('Silakan ketik atau reply pesan yang ingin di-share:', shareOptionsKeyboard);
            ctx.session.waitingForShare = true;
            break;
            
        case 'cancel_share':
            ctx.session.waitingForShare = false;
            await ctx.reply('Share dibatalkan.');
            break;
            
        default:
            break;
    }
    
    await ctx.answerCbQuery();
});

// Handle messages when waiting for share content
bot.on(message('text'), async (ctx) => {
    if (ctx.chat.type !== 'private') return;
    if (!ctx.session.waitingForShare) return;
    
    const userId = ctx.from.id;
    const user = getUser(userId);
    
    if (user.credits < 1) {
        ctx.session.waitingForShare = false;
        return ctx.reply('Kredit Anda tidak cukup. Silakan join grup terlebih dahulu untuk mendapatkan kredit.');
    }
    
    // Deduct credit
    user.credits -= 1;
    updateUser(user);
    
    // Get all groups user has joined
    const userGroups = user.groups || [];
    
    if (userGroups.length === 0) {
        ctx.session.waitingForShare = false;
        return ctx.reply('Anda belum tergabung di grup manapun. Silakan join grup terlebih dahulu.');
    }
    
    // Broadcast message to all groups
    let successCount = 0;
    for (const groupId of userGroups) {
        try {
            await ctx.telegram.sendMessage(groupId, `📢 Pesan dari ${ctx.from.first_name}:\n\n${ctx.message.text}`);
            successCount++;
        } catch (error) {
            console.error(`Failed to send message to group ${groupId}:`, error.message);
        }
    }
    
    ctx.session.waitingForShare = false;
    await ctx.reply(`Pesan berhasil dikirim ke ${successCount} grup. Kredit berkurang 1. Sisa kredit: ${user.credits}`);
});

// Handle new chat members (when bot is added to a group)
bot.on('chat_member', async (ctx) => {
    if (ctx.chatMember.new_chat_member.status === 'member' && 
        ctx.chatMember.new_chat_member.user.id === ctx.botInfo.id) {
        // Bot was added to a group
        const groupId = ctx.chat.id;
        const groupTitle = ctx.chat.title;
        
        // Add group to database
        addToGroup(groupId, groupTitle);
        
        // Notify group admin
        await ctx.reply(`Terima kasih telah menambahkan saya ke grup ini! Untuk mengaktifkan fitur, silakan gunakan perintah /addgroup di grup ini.`);
    }
});

// Error handling
bot.catch((err, ctx) => {
    console.error(`Error for ${ctx.updateType}:`, err);
    ctx.reply('Terjadi kesalahan. Silakan coba lagi nanti.');
});

// Start bot
bot.launch().then(() => {
    console.log('Bot Jasher started successfully');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));