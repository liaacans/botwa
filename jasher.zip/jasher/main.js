const { Telegraf } = require('telegraf');
const { setupCommands } = require('./src/commands');
const { setupHandlers } = require('./src/handlers');
const { BOT_TOKEN } = require('./config');

// Initialize bot
const bot = new Telegraf(BOT_TOKEN);

// Setup commands and handlers
setupCommands(bot);
setupHandlers(bot);

// Start bot
bot.launch().then(() => {
    console.log('🤖 Jasher Bot is running...');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));