const { Markup } = require('telegraf');
const JsConfuser = require('js-confuser');
const { updateProgress } = require('../lib/utils');

// Konstanta fungsi async untuk obfuscation Time-Locked Encryption
const obfuscateTimeLocked = async (fileContent, days) => {
  const expiryDate = new Date();
  expiryDate.setDate(expiryDate.getDate() + parseInt(days));
  const expiryTimestamp = expiryDate.getTime();
  try {
    const obfuscated = await JsConfuser.obfuscate(
      `(function(){const expiry=${expiryTimestamp};if(new Date().getTime()>expiry){throw new Error('Script has expired after ${days} days');}${fileContent}})();`,
      {
        target: "node",
        compact: true,
        renameVariables: true,
        renameGlobals: true,
        identifierGenerator: "randomized",
        stringCompression: true,
        stringConcealing: true,
        stringEncoding: true,
        controlFlowFlattening: 0.75,
        flatten: true,
        shuffle: true,
        rgf: false,
        opaquePredicates: {
          count: 6,
          complexity: 4,
        },
        dispatcher: true,
        globalConcealing: true,
        lock: {
          selfDefending: true,
          antiDebug: (code) =>
            `if(typeof debugger!=='undefined'||process.env.NODE_ENV==='debug')throw new Error('Debugging disabled');${code}`,
          integrity: true,
          tamperProtection: (code) =>
            `if(!((function(){return eval('1+1')===2;})()))throw new Error('Tamper detected');${code}`,
        },
        duplicateLiteralsRemoval: true,
      }
    );
    let obfuscatedCode = obfuscated.code || obfuscated;
    if (typeof obfuscatedCode !== "string") {
      throw new Error("Hasil obfuscation bukan string");
    }
    return obfuscatedCode;
  } catch (error) {
    throw new Error(`Gagal obfuscate: ${error.message}`);
  }
};

// Konstanta fungsi async untuk obfuscation Quantum Vortex Encryption
const obfuscateQuantum = async (fileContent) => {
  // Generate identifier unik berdasarkan waktu lokal
  const generateTimeBasedIdentifier = () => {
    const timeStamp = new Date().getTime().toString().slice(-5);
    const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_$#@&*";
    let identifier = "qV_";
    for (let i = 0; i < 7; i++) {
      identifier +=
        chars[Math.floor((parseInt(timeStamp[i % 5]) + i * 2) % chars.length)];
    }
    return identifier;
  };

  // Tambahkan kode phantom berdasarkan milidetik
  const currentMilliseconds = new Date().getMilliseconds();
  const phantomCode =
    currentMilliseconds % 3 === 0
      ? `if(Math.random()>0.999)console.log('PhantomTrigger');`
      : "";

  try {
    const obfuscated = await JsConfuser.obfuscate(fileContent + phantomCode, {
      target: "node",
      compact: true,
      renameVariables: true,
      renameGlobals: true,
      identifierGenerator: generateTimeBasedIdentifier,
      stringCompression: true,
      stringConcealing: false,
      stringEncoding: true,
      controlFlowFlattening: 0.85, // Intensitas lebih tinggi untuk versi 2.0
      flatten: true,
      shuffle: true,
      rgf: true,
      opaquePredicates: {
        count: 8, // Peningkatan count untuk versi 2.0
        complexity: 5,
      },
      dispatcher: true,
      globalConcealing: true,
      lock: {
        selfDefending: true,
        antiDebug: (code) =>
          `if(typeof debugger!=='undefined'||(typeof process!=='undefined'&&process.env.NODE_ENV==='debug'))throw new Error('Debugging disabled');${code}`,
        integrity: true,
        tamperProtection: (code) =>
          `if(!((function(){return eval('1+1')===2;})()))throw new Error('Tamper detected');${code}`,
      },
      duplicateLiteralsRemoval: true,
    });
    let obfuscatedCode = obfuscated.code || obfuscated;
    if (typeof obfuscatedCode !== "string") {
      throw new Error("Hasil obfuscation bukan string");
    }
    // Self-evolving code dengan XOR dinamis
    const key = currentMilliseconds % 256;
    obfuscatedCode = `(function(){let k=${key};return function(c){return c.split('').map((x,i)=>String.fromCharCode(x.charCodeAt(0)^(k+(i%16)))).join('');}('${obfuscatedCode}');})()`;
    return obfuscatedCode;
  } catch (error) {
    throw new Error(`Gagal obfuscate: ${error.message}`);
  }
};

module.exports = {
    obfuscateTimeLocked,
    obfuscateQuantum,
    
    handleEnclocked: async (ctx) => {
        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            await ctx.reply('Balas pesan file JavaScript dengan perintah ini untuk mengenkripsi dengan time lock.');
            return;
        }
        
        const args = ctx.message.text.split(' ');
        if (args.length < 2) {
            await ctx.reply('Format: /enclocked [days]');
            return;
        }
        
        const days = parseInt(args[1]);
        if (isNaN(days) || days < 1) {
            await ctx.reply('Hari harus berupa angka positif.');
            return;
        }
        
        try {
            const fileId = ctx.message.reply_to_message.document.file_id;
            const fileLink = await ctx.telegram.getFileLink(fileId);
            
            // Download file
            const response = await axios.get(fileLink.href);
            const fileContent = response.data;
            
            // Obfuscate with time lock
            await ctx.reply('Sedang memproses file...');
            const obfuscatedCode = await obfuscateTimeLocked(fileContent, days);
            
            // Send obfuscated file
            await ctx.replyWithDocument({
                source: Buffer.from(obfuscatedCode),
                filename: `encrypted_${days}days.js`
            }, {
                caption: `File telah dienkripsi dengan time lock selama ${days} hari.`
            });
        } catch (error) {
            console.error(error);
            await ctx.reply('Terjadi kesalahan saat memproses file.');
        }
    },
    
    handleQuantum: async (ctx) => {
        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            await ctx.reply('Balas pesan file JavaScript dengan perintah ini untuk mengenkripsi dengan quantum vortex.');
            return;
        }
        
        try {
            const fileId = ctx.message.reply_to_message.document.file_id;
            const fileLink = await ctx.telegram.getFileLink(fileId);
            
            // Download file
            const response = await axios.get(fileLink.href);
            const fileContent = response.data;
            
            // Obfuscate with quantum vortex
            await ctx.reply('Sedang memproses file dengan Quantum Vortex Encryption...');
            const obfuscatedCode = await obfuscateQuantum(fileContent);
            
            // Send obfuscated file
            await ctx.replyWithDocument({
                source: Buffer.from(obfuscatedCode),
                filename: 'quantum_encrypted.js'
            }, {
                caption: 'File telah dienkripsi dengan Quantum Vortex Encryption.'
            });
        } catch (error) {
            console.error(error);
            await ctx.reply('Terjadi kesalahan saat memproses file.');
        }
    }
};