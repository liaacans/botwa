const { Telegraf } = require('telegraf');
const nodemailer = require('nodemailer');
const imap = require('imap-simple');
const { simpleParser } = require('mailparser');
const fs = require('fs');
const path = require('path');
const _ = require('lodash');

// Konfigurasi
const CONFIG = {
    // Bot Token dari BotFather
    BOT_TOKEN: 'YOUR_BOT_TOKEN_HERE',
    
    // ID Grup yang diizinkan
    ALLOWED_GROUP_ID: -1002793801544,
    
    // Konfigurasi Email
    EMAIL_CONFIG: {
        host: 'newpinwheel.indowebsite.net',
        port: 465,
        secure: true, // gunakan SSL
        auth: {
            user: 'nokosmerah@buatkamu.web.id',
            pass: 'Grki6Vv1gdlA'
        }
    },
    
    // Konfigurasi IMAP untuk menerima balasan
    IMAP_CONFIG: {
        imap: {
            user: 'nokosmerah@buatkamu.web.id',
            password: 'Grki6Vv1gdlA',
            host: 'newpinwheel.indowebsite.net',
            port: 993,
            tls: true,
            tlsOptions: { rejectUnauthorized: false }
        }
    },
    
    // File untuk menyimpan data
    DATA_FILE: 'email_data.json'
};

// Inisialisasi bot
const bot = new Telegraf(CONFIG.BOT_TOKEN);

// Variabel untuk menyimpan data
let emailData = {
    lastUid: 0,
    sentEmails: {} // menyimpan informasi email yang dikirim
};

// Load data dari file jika ada
if (fs.existsSync(CONFIG.DATA_FILE)) {
    try {
        const data = fs.readFileSync(CONFIG.DATA_FILE, 'utf8');
        emailData = JSON.parse(data);
    } catch (error) {
        console.error('Error loading data file:', error);
    }
}

// Fungsi untuk menyimpan data
function saveData() {
    try {
        fs.writeFileSync(CONFIG.DATA_FILE, JSON.stringify(emailData, null, 2));
    } catch (error) {
        console.error('Error saving data file:', error);
    }
}

// Buat transporter email - PERBAIKAN DI SINI
const emailTransporter = nodemailer.createTransport(CONFIG.EMAIL_CONFIG);

// Middleware untuk memeriksa grup
bot.use(async (ctx, next) => {
    // Periksa jika update berasal dari grup yang diizinkan
    if (ctx.chat && ctx.chat.id === CONFIG.ALLOWED_GROUP_ID) {
        return next();
    }
    
    // Jika bot ditambahkan ke grup lain, keluar
    if (ctx.updateType === 'message' && 
        ctx.message && 
        ctx.message.new_chat_members && 
        ctx.message.new_chat_members.some(member => member.is_bot && member.id === ctx.botInfo.id)) {
        
        try {
            await ctx.leaveChat();
            console.log(`Left unauthorized group: ${ctx.chat.id}`);
        } catch (error) {
            console.error('Error leaving chat:', error);
        }
    }
    
    // Jangan proses pesan dari grup/chat lain
    return;
});

// Perintah untuk mengirim email
bot.command('kirimemail', async (ctx) => {
    const messageText = ctx.message.text;
    const args = messageText.split(' ').slice(1);
    
    if (args.length < 2) {
        return ctx.reply('Format: /kirimemail <email_tujuan> <subjek> <isi_pesan>');
    }
    
    const toEmail = args[0];
    const subject = args[1];
    const body = args.slice(2).join(' ');
    
    const mailOptions = {
        from: CONFIG.EMAIL_CONFIG.auth.user,
        to: toEmail,
        subject: subject,
        text: body,
        html: `<p>${body}</p>`
    };
    
    try {
        // Kirim email
        const info = await emailTransporter.sendMail(mailOptions);
        
        // Simpan informasi email yang dikirim
        const messageId = info.messageId;
        emailData.sentEmails[messageId] = {
            from: ctx.from.id,
            to: toEmail,
            subject: subject,
            body: body,
            timestamp: new Date().toISOString(),
            replied: false
        };
        
        saveData();
        
        ctx.reply(`✅ Email berhasil dikirim ke ${toEmail}\nMessage ID: ${messageId}`);
    } catch (error) {
        console.error('Error sending email:', error);
        ctx.reply('❌ Gagal mengirim email: ' + error.message);
    }
});

// Fungsi untuk memeriksa balasan email
async function checkEmailReplies() {
    try {
        const connection = await imap.connect(CONFIG.IMAP_CONFIG);
        
        await connection.openBox('INBOX');
        
        // Cari email yang belum dibaca sejak UID terakhir
        const searchCriteria = ['UNSEEN', ['UID', `${emailData.lastUid + 1}:*`]];
        const fetchOptions = { bodies: [''] };
        
        const messages = await connection.search(searchCriteria, fetchOptions);
        
        for (const message of messages) {
            const uid = message.attributes.uid;
            const all = _.find(message.parts, { which: '' });
            const id = message.attributes.uid;
            const body = all ? all.body : '';
            
            if (body) {
                const parsed = await simpleParser(body);
                
                // Periksa apakah ini balasan dari email yang kita kirim
                if (parsed.inReplyTo && emailData.sentEmails[parsed.inReplyTo]) {
                    const originalEmail = emailData.sentEmails[parsed.inReplyTo];
                    
                    // Tandai sebagai sudah dibalas
                    emailData.sentEmails[parsed.inReplyTo].replied = true;
                    emailData.sentEmails[parsed.inReplyTo].replyTimestamp = new Date().toISOString();
                    emailData.sentEmails[parsed.inReplyTo].replyContent = parsed.text;
                    
                    saveData();
                    
                    // Kirim notifikasi ke grup
                    await bot.telegram.sendMessage(
                        CONFIG.ALLOWED_GROUP_ID,
                        `📩 Balasan email diterima!\n\n` +
                        `Dari: ${parsed.from.text}\n` +
                        `Untuk: ${originalEmail.to}\n` +
                        `Subjek: ${parsed.subject}\n\n` +
                        `Isi balasan:\n${parsed.text.substring(0, 1000)}${parsed.text.length > 1000 ? '...' : ''}`
                    );
                }
            }
            
            // Update UID terakhir
            if (uid > emailData.lastUid) {
                emailData.lastUid = uid;
            }
        }
        
        saveData();
        connection.end();
    } catch (error) {
        console.error('Error checking email replies:', error);
    }
}

// Jadwalkan pengecekan email setiap 1 menit
setInterval(checkEmailReplies, 60000);

// Perintah untuk mengecek status email
bot.command('cekmail', async (ctx) => {
    const messageText = ctx.message.text;
    const args = messageText.split(' ').slice(1);
    
    if (args.length === 0) {
        // Tampilkan semua email yang dikirim
        const emailList = Object.entries(emailData.sentEmails)
            .map(([messageId, data]) => {
                const status = data.replied ? '✅ Dibalas' : '⏳ Menunggu';
                return `${status} - ${data.to} - ${data.subject}`;
            })
            .join('\n');
        
        return ctx.reply(`Daftar email yang dikirim:\n\n${emailList || 'Belum ada email yang dikirim'}`);
    } else {
        // Tampilkan detail email tertentu
        const messageId = args[0];
        const email = emailData.sentEmails[messageId];
        
        if (!email) {
            return ctx.reply('❌ Email tidak ditemukan');
        }
        
        const status = email.replied ? '✅ Dibalas' : '⏳ Menunggu balasan';
        let replyInfo = '';
        
        if (email.replied) {
            replyInfo = `\nWaktu balasan: ${email.replyTimestamp}\n` +
                       `Isi balasan: ${email.replyContent.substring(0, 500)}${email.replyContent.length > 500 ? '...' : ''}`;
        }
        
        ctx.reply(
            `Detail Email:\n\n` +
            `Message ID: ${messageId}\n` +
            `Kepada: ${email.to}\n` +
            `Subjek: ${email.subject}\n` +
            `Status: ${status}\n` +
            `Dikirim pada: ${email.timestamp}` +
            replyInfo
        );
    }
});

// Handle error
bot.catch((err, ctx) => {
    console.error(`Error for ${ctx.updateType}:`, err);
});

// Start bot
bot.launch().then(() => {
    console.log('Bot started');
    
    // Jalankan pengecekan email sekali saat bot dimulai
    checkEmailReplies();
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));