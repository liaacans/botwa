const { User, Group, Broadcast } = require('../lib/database');
const { mainMenuKeyboard, jasherMenuKeyboard, shareMenuKeyboard, adminMenuKeyboard, broadcastMenuKeyboard, backButton } = require('./keyboards');
const { isUrl } = require('../lib/utils');

async function handleCallbackQuery(ctx) {
  const data = ctx.callbackQuery.data;
  const userId = ctx.from.id;
  const isCreator = userId.toString() === process.env.ADMIN_ID;
  
  try {
    switch (data) {
      case 'main_menu':
        await ctx.editMessageCaption(
          `Hi kak @${ctx.from.first_name}\nSilahkan pilih menu dibawah ini!`,
          {
            reply_markup: mainMenuKeyboard(isCreator).reply_markup
          }
        );
        break;
        
      case 'jasher_menu':
        await ctx.editMessageCaption(
          '🎯 <b>Jasher Menu</b>\n\nPilih opsi yang tersedia:',
          {
            parse_mode: 'HTML',
            reply_markup: jasherMenuKeyboard().reply_markup
          }
        );
        break;
        
      case 'share_menu':
        await ctx.editMessageCaption(
          '📤 <b>Share Menu</b>\n\nPilih jenis share:',
          {
            parse_mode: 'HTML',
            reply_markup: shareMenuKeyboard().reply_markup
          }
        );
        break;
        
      case 'credit_info':
        const user = await User.findOne({ userId });
        const credit = user ? user.credit : 0;
        
        await ctx.editMessageCaption(
          `💎 <b>Credit Information</b>\n\n` +
          `Credit Anda: <b>${credit}</b>\n` +
          `Status: ${user && user.isPremium ? '⭐ Premium User' : 'Regular User'}\n\n` +
          `Tambahkan bot ke 3 grup untuk mendapatkan 10 kredit!`,
          {
            parse_mode: 'HTML',
            reply_markup: backButton('jasher_menu').reply_markup
          }
        );
        break;
        
      case 'share_free':
        if (ctx.chat.type !== 'private') {
          await ctx.answerCbQuery('Fitur ini hanya bisa digunakan di private chat!');
          return;
        }
        
        const userData = await User.findOne({ userId });
        if (!userData || userData.credit < 2) {
          await ctx.answerCbQuery('Credit tidak cukup! Minimal 2 credit untuk share free.');
          return;
        }
        
        await ctx.editMessageCaption(
          '📤 <b>Share Free</b>\n\n' +
          'Balas pesan ini dengan teks yang ingin di-share atau kirim teks langsung.',
          {
            parse_mode: 'HTML',
            reply_markup: backButton('share_menu').reply_markup
          }
        );
        
        // Set state untuk menunggu pesan yang akan di-share
        ctx.session = ctx.session || {};
        ctx.session.waitingForShareMessage = true;
        ctx.session.shareType = 'free';
        break;
        
      case 'share_vip':
        if (ctx.chat.type !== 'private') {
          await ctx.answerCbQuery('Fitur ini hanya bisa digunakan di private chat!');
          return;
        }
        
        const vipUser = await User.findOne({ userId });
        if (!vipUser || !vipUser.isPremium) {
          await ctx.answerCbQuery('Fitur ini hanya untuk user premium!');
          return;
        }
        
        if (!vipUser || vipUser.credit < 5) {
          await ctx.answerCbQuery('Credit tidak cukup! Minimal 5 credit untuk share VIP.');
          return;
        }
        
        await ctx.editMessageCaption(
          '🚀 <b>Share VIP</b>\n\n' +
          'Balas pesan ini dengan teks yang ingin di-share atau kirim teks langsung.',
          {
            parse_mode: 'HTML',
            reply_markup: backButton('share_menu').reply_markup
          }
        );
        
        // Set state untuk menunggu pesan yang akan di-share
        ctx.session = ctx.session || {};
        ctx.session.waitingForShareMessage = true;
        ctx.session.shareType = 'vip';
        break;
        
      case 'owner_menu':
        if (!isCreator) {
          await ctx.answerCbQuery('Akses ditolak! Hanya owner yang bisa mengakses menu ini.');
          return;
        }
        
        await ctx.editMessageCaption(
          '👤 <b>Owner Menu</b>\n\nPilih opsi yang tersedia:',
          {
            parse_mode: 'HTML',
            reply_markup: adminMenuKeyboard().reply_markup
          }
        );
        break;
        
      case 'admin_menu':
        if (!isCreator) {
          await ctx.answerCbQuery('Akses ditolak! Hanya admin yang bisa mengakses menu ini.');
          return;
        }
        
        await ctx.editMessageCaption(
          '⚙️ <b>Admin Menu</b>\n\nPilih opsi yang tersedia:',
          {
            parse_mode: 'HTML',
            reply_markup: adminMenuKeyboard().reply_markup
          }
        );
        break;
        
      case 'broadcast_menu':
        if (!isCreator) {
          await ctx.answerCbQuery('Akses ditolak! Hanya admin yang bisa mengakses menu ini.');
          return;
        }
        
        await ctx.editMessageCaption(
          '📢 <b>Broadcast Menu</b>\n\nPilih jenis broadcast:',
          {
            parse_mode: 'HTML',
            reply_markup: broadcastMenuKeyboard().reply_markup
          }
        );
        break;
        
      case 'add_premium':
        if (!isCreator) {
          await ctx.answerCbQuery('Akses ditolak! Hanya admin yang bisa mengakses menu ini.');
          return;
        }
        
        await ctx.editMessageCaption(
          '⭐ <b>Add Premium</b>\n\n' +
          'Balas pesan ini dengan username/user ID yang ingin ditambahkan sebagai premium.\n' +
          'Contoh: <code>@username</code> atau <code>123456789</code>',
          {
            parse_mode: 'HTML',
            reply_markup: backButton('admin_menu').reply_markup
          }
        );
        
        ctx.session = ctx.session || {};
        ctx.session.waitingForPremiumAdd = true;
        break;
        
      case 'remove_premium':
        if (!isCreator) {
          await ctx.answerCbQuery('Akses ditolak! Hanya admin yang bisa mengakses menu ini.');
          return;
        }
        
        await ctx.editMessageCaption(
          '🗑️ <b>Remove Premium</b>\n\n' +
          'Balas pesan ini dengan username/user ID yang ingin dihapus dari premium.\n' +
          'Contoh: <code>@username</code> atau <code>123456789</code>',
          {
            parse_mode: 'HTML',
            reply_markup: backButton('admin_menu').reply_markup
          }
        );
        
        ctx.session = ctx.session || {};
        ctx.session.waitingForPremiumRemove = true;
        break;
        
      case 'list_premium':
        if (!isCreator) {
          await ctx.answerCbQuery('Akses ditolak! Hanya admin yang bisa mengakses menu ini.');
          return;
        }
        
        const premiumUsers = await User.find({ isPremium: true });
        let premiumList = '⭐ <b>Premium Users List</b>\n\n';
        
        if (premiumUsers.length === 0) {
          premiumList += 'Tidak ada user premium.';
        } else {
          premiumUsers.forEach((user, index) => {
            premiumList += `${index + 1}. ${user.firstName} ${user.lastName || ''} (@${user.username || 'no_username'}) - ID: ${user.userId}\n`;
          });
        }
        
        await ctx.editMessageCaption(premiumList, {
          parse_mode: 'HTML',
          reply_markup: backButton('admin_menu').reply_markup
        });
        break;
        
      case 'broadcast_all':
        if (!isCreator) {
          await ctx.answerCbQuery('Akses ditolak! Hanya admin yang bisa mengakses menu ini.');
          return;
        }
        
        await ctx.editMessageCaption(
          '📢 <b>Broadcast to All Users</b>\n\n' +
          'Balas pesan ini dengan teks yang ingin di-broadcast ke semua user.',
          {
            parse_mode: 'HTML',
            reply_markup: backButton('broadcast_menu').reply_markup
          }
        );
        
        ctx.session = ctx.session || {};
        ctx.session.waitingForBroadcast = true;
        ctx.session.broadcastType = 'all';
        break;
        
      case 'broadcast_premium':
        if (!isCreator) {
          await ctx.answerCbQuery('Akses ditolak! Hanya admin yang bisa mengakses menu ini.');
          return;
        }
        
        await ctx.editMessageCaption(
          '⭐ <b>Broadcast to Premium Users</b>\n\n' +
          'Balas pesan ini dengan teks yang ingin di-broadcast ke user premium.',
          {
            parse_mode: 'HTML',
            reply_markup: backButton('broadcast_menu').reply_markup
          }
        );
        
        ctx.session = ctx.session || {};
        ctx.session.waitingForBroadcast = true;
        ctx.session.broadcastType = 'premium';
        break;
        
      case 'owner_info':
        await ctx.answerCbQuery('Informasi owner akan ditampilkan di sini.');
        // Tambahkan informasi owner sesuai kebutuhan
        break;
        
      default:
        await ctx.answerCbQuery('Fitur belum tersedia!');
    }
    
    await ctx.answerCbQuery();
  } catch (error) {
    console.error('Error handling callback query:', error);
    await ctx.answerCbQuery('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleTextMessage(ctx) {
  const text = ctx.message.text;
  const userId = ctx.from.id;
  const isCreator = userId.toString() === process.env.ADMIN_ID;
  
  try {
    // Cek jika menunggu pesan untuk di-share
    if (ctx.session && ctx.session.waitingForShareMessage) {
      const shareType = ctx.session.shareType;
      const user = await User.findOne({ userId });
      
      if (shareType === 'free' && user.credit < 2) {
        await ctx.reply('Credit tidak cukup! Minimal 2 credit untuk share free.');
        delete ctx.session.waitingForShareMessage;
        delete ctx.session.shareType;
        return;
      }
      
      if (shareType === 'vip' && user.credit < 5) {
        await ctx.reply('Credit tidak cukup! Minimal 5 credit untuk share VIP.');
        delete ctx.session.waitingForShareMessage;
        delete ctx.session.shareType;
        return;
      }
      
      // Dapatkan semua grup yang telah ditambahkan
      const groups = await Group.find({});
      
      if (groups.length === 0) {
        await ctx.reply('Tidak ada grup yang terdaftar. Tambahkan bot ke grup terlebih dahulu.');
        delete ctx.session.waitingForShareMessage;
        delete ctx.session.shareType;
        return;
      }
      
      // Kurangi credit sesuai jenis share
      const creditCost = shareType === 'free' ? 2 : 5;
      user.credit -= creditCost;
      await user.save();
      
      // Kirim pesan ke semua grup
      let successCount = 0;
      for (const group of groups) {
        try {
          await ctx.telegram.sendMessage(group.groupId, text);
          successCount++;
          
          // Delay untuk menghindari limit Telegram
          if (shareType === 'free') {
            await new Promise(resolve => setTimeout(resolve, 2000));
          }
        } catch (error) {
          console.error(`Gagal mengirim pesan ke grup ${group.groupId}:`, error);
        }
      }
      
      await ctx.reply(
        `Pesan berhasil dikirim ke ${successCount} dari ${groups.length} grup.\n` +
        `Credit berkurang: ${creditCost}\n` +
        `Sisa credit: ${user.credit}`
      );
      
      delete ctx.session.waitingForShareMessage;
      delete ctx.session.shareType;
      return;
    }
    
    // Cek jika menunggu input untuk menambah premium
    if (ctx.session && ctx.session.waitingForPremiumAdd) {
      let targetUser = null;
      
      // Cari user berdasarkan username atau ID
      if (text.startsWith('@')) {
        const username = text.substring(1);
        targetUser = await User.findOne({ username: username });
      } else if (!isNaN(text)) {
        targetUser = await User.findOne({ userId: parseInt(text) });
      }
      
      if (!targetUser) {
        await ctx.reply('User tidak ditemukan. Pastikan user sudah pernah menggunakan bot.');
        delete ctx.session.waitingForPremiumAdd;
        return;
      }
      
      targetUser.isPremium = true;
      await targetUser.save();
      
      await ctx.reply(`User ${targetUser.firstName} (@${targetUser.username || 'no_username'}) berhasil ditambahkan sebagai premium.`);
      delete ctx.session.waitingForPremiumAdd;
      return;
    }
    
    // Cek jika menunggu input untuk menghapus premium
    if (ctx.session && ctx.session.waitingForPremiumRemove) {
      let targetUser = null;
      
      // Cari user berdasarkan username atau ID
      if (text.startsWith('@')) {
        const username = text.substring(1);
        targetUser = await User.findOne({ username: username });
      } else if (!isNaN(text)) {
        targetUser = await User.findOne({ userId: parseInt(text) });
      }
      
      if (!targetUser) {
        await ctx.reply('User tidak ditemukan.');
        delete ctx.session.waitingForPremiumRemove;
        return;
      }
      
      targetUser.isPremium = false;
      await targetUser.save();
      
      await ctx.reply(`User ${targetUser.firstName} (@${targetUser.username || 'no_username'}) berhasil dihapus dari premium.`);
      delete ctx.session.waitingForPremiumRemove;
      return;
    }
    
    // Cek jika menunggu pesan broadcast
    if (ctx.session && ctx.session.waitingForBroadcast) {
      const broadcastType = ctx.session.broadcastType;
      let users = [];
      
      if (broadcastType === 'all') {
        users = await User.find({});
      } else if (broadcastType === 'premium') {
        users = await User.find({ isPremium: true });
      }
      
      let successCount = 0;
      for (const user of users) {
        try {
          await ctx.telegram.sendMessage(user.userId, text);
          successCount++;
          
          // Delay untuk menghindari limit Telegram
          await new Promise(resolve => setTimeout(resolve, 100));
        } catch (error) {
          console.error(`Gagal mengirim broadcast ke user ${user.userId}:`, error);
        }
      }
      
      // Simpan history broadcast
      const broadcast = new Broadcast({
        messageId: ctx.message.message_id,
        text: text,
        sentBy: userId,
        target: broadcastType
      });
      await broadcast.save();
      
      await ctx.reply(
        `Broadcast berhasil dikirim ke ${successCount} dari ${users.length} user.`
      );
      
      delete ctx.session.waitingForBroadcast;
      delete ctx.session.broadcastType;
      return;
    }
    
    // Handle command text biasa
    switch (text) {
      case '/start':
        // Already handled by command handler
        break;
        
      case '/help':
        // Already handled by command handler
        break;
        
      case '/credit':
        // Already handled by command handler
        break;
        
      case '/share':
        if (ctx.chat.type !== 'private') {
          await ctx.reply('Fitur share hanya bisa digunakan di private chat!');
          return;
        }
        
        await ctx.reply(
          '📤 <b>Share Menu</b>\n\nPilih jenis share:',
          {
            parse_mode: 'HTML',
            reply_markup: shareMenuKeyboard().reply_markup
          }
        );
        break;
        
      default:
        // Jika tidak ada command yang cocok, tampilkan menu utama
        await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
          caption: `Hi kak @${ctx.from.first_name}\nSilahkan pilih menu dibawah ini!`,
          reply_markup: mainMenuKeyboard(isCreator).reply_markup
        });
    }
  } catch (error) {
    console.error('Error handling text message:', error);
    await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleNewChatMembers(ctx) {
  // Ketika bot ditambahkan ke grup
  if (ctx.message.new_chat_members.some(member => member.is_bot && member.id === ctx.botInfo.id)) {
    const groupId = ctx.chat.id;
    const groupTitle = ctx.chat.title;
    const groupUsername = ctx.chat.username;
    const addedBy = ctx.from.id;
    
    try {
      // Cek apakah grup sudah terdaftar
      let group = await Group.findOne({ groupId: groupId });
      if (!group) {
        group = new Group({
          groupId: groupId,
          title: groupTitle,
          username: groupUsername,
          addedBy: addedBy
        });
        await group.save();
        
        // Beri credit kepada user yang menambahkan bot
        const user = await User.findOne({ userId: addedBy });
        if (user) {
          // Cek berapa banyak grup yang sudah user tambahkan
          const userGroups = await Group.find({ addedBy: addedBy });
          
          if (userGroups.length === 3) {
            // Beri bonus 10 credit ketika sudah menambahkan 3 grup
            user.credit += 10;
            await user.save();
            
            await ctx.reply(
              `Terima kasih telah menambahkan bot ke 3 grup!\n` +
              `Anda mendapatkan bonus 10 credit!\n` +
              `Total credit sekarang: ${user.credit}`
            );
          } else {
            // Beri credit biasa
            user.credit += 1;
            await user.save();
            
            await ctx.reply(
              `Terima kasih telah menambahkan bot ke grup!\n` +
              `Anda mendapatkan 1 credit!\n` +
              `Total credit sekarang: ${user.credit}\n` +
              `Butuh ${3 - userGroups.length} grup lagi untuk bonus 10 credit.`
            );
          }
        }
      }
    } catch (error) {
      console.error('Error handling new chat members:', error);
    }
  }
}

module.exports = {
  handleCallbackQuery,
  handleTextMessage,
  handleNewChatMembers
};