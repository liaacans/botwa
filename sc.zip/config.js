module.exports = {
    BOT_TOKEN: "8439733385:AAFlWBPVOloAWBzTodneZKkDoH3TKkf8TVQ",
    OWNER_IDS: ["7568960443"],
    OWNER_ID: "7568960443",
    CHANNEL_ID: "-1003011195058",
    CHANNEL_URL: "https://t.me/ginaimutp",
    BOT_NAME: "GINASTORE OFFICIAL",
    nomor_pencairan: "085654127071",
    type_ewallet: "dana",
    atas_nama_ewallet: "Akhmad Aulia Rahman",
    
    PAYMENT: {
        apiAtlantic: "bOXb4y6FDIV2Evyw590POxMDFgWq3ijEnwNhdL9MmQiMWHw98N7yLO36bfZSq8GeGsyqGTsKvINLiRQh3BTEZLx0X12VhY6LZHLd",
        FeeTransaksi: 250
    },
    
    PTERODACTYL: {
        domain: "https://console.naaofficial.web.id",
        apiKey: "ptla_Tiw2TRPT3JyViHEIkzdkMdO3Q4CPBYy1Bs4hu9POPjD",
        clientKey: "ptlc_v3tPPBQ7KcaTJpuFeT8QfXw3qyrZXmzuDUrjAD6wslr",
        loc: "1",
        nest: "5",
        eggs: {
            nodejs: "15",
            python: "16", 
            pm2: "17"
        }
    },
    
    PANEL_PRICES: {
        '5gb': 5000,
        '6gb': 6000,
        '7gb': 7000,
        '8gb': 8000,
        '9gb': 9000,
        '10gb': 10000,
        'unli': 15000
    },
    
    RESELLER_PRICES: {
        reseller: 8000
    },
    
    RESELLER: {
        reseller: {
            daily_limit: 5,
            max_ram: 10240,
            sell_price: 5000
        }
    },
    
    SPECIAL_PANEL_PRICES: {
        admin_panel: 10000,
        reseller_panel: 8000,
        owner_panel: 20000,
        pt_panel: 10000,
        tk_panel: 15000
    }
};