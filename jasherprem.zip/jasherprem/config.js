global.BOT_TOKEN = "8198305874:AAGdj8p_m2anVPF0PpqEHQzGs4k2AQ2V3_c";
global.DEVELOPER = "@ginaforyou";
global.PREMIUM_PRICE = 10000; // Harga premium dalam kredit
global.SHARE_CREDIT_COST = 1; // Biaya share per group
global.AUTO_JASHER_INTERVAL = 10 * 60 * 1000; // 10 menit

module.exports = {
    BOT_TOKEN: global.BOT_TOKEN,
    DEVELOPER: global.DEVELOPER
};