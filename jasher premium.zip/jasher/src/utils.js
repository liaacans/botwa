const moment = require('moment-timezone');

// Fungsi untuk format runtime
function runtime(seconds) {
    const days = Math.floor(seconds / (3600 * 24));
    const hours = Math.floor((seconds % (3600 * 24)) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    return `${days}d ${hours}h ${minutes}m ${secs}s`;
}

// Fungsi untuk membuat menu utama
function createMainMenu(ctx, user) {
    const sender = ctx.from.first_name;
    const userTelelu = ctx.from.username ? `@${ctx.from.username}` : 'Tidak ada';
    const isCreator = ctx.from.id === global.OWNER_ID;
    
    const message = `Hi kak @${sender}
╭─❒ 「 User Info 」 
├ Creator : @${userTelelu}
├ Name : ${sender}
├ Profile : ${userTelelu}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : Linux
├ Platform : Bot Telegram
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreator ? 'True' : 'False'}

Silahkan pilih button dibawah ini!`;

    const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('🎯 Jasher Menu', 'jasher_menu')],
        [Markup.button.callback('👑 Owner Menu', 'owner_menu')],
        [Markup.button.callback('➕ AddGroup', 'add_group')],
        [Markup.button.callback('ℹ️ Info', 'info')]
    ]);

    return { message, keyboard };
}

module.exports = {
    runtime,
    createMainMenu
};