const { Telegraf, Markup } = require('telegraf');
const { 
    loadUsers, saveUsers, 
    loadGroups, saveGroups, 
    loadPremium, savePremium, 
    loadBlacklist, saveBlacklist 
} = require('../lib/database');
const { 
    isPremium, isCreator, 
    formatDate, addDays, 
    log, runtime 
} = require('../lib/utils');
const moment = require('moment-timezone');

// Load data
let users = new Set(Object.keys(loadUsers()));
let groups = loadGroups();
let premium = loadPremium();
let blacklist = loadBlacklist();

// Handler untuk callback query
function setupCallbackHandlers(bot) {
    // Handler untuk menu utama
    bot.action('back', async (ctx) => {
        try {
            await ctx.deleteMessage();
            const userId = ctx.from.id;
            const isCreatorUser = isCreator(userId);
            const sender = ctx.from.username || ctx.from.first_name;
            
            await ctx.replyWithPhoto(
                'https://f.top4top.io/p_3530xky9e4.jpg',
                {
                    caption: `╭─❒ 「 User Info 」 
├ Owner : ${isCreatorUser ? 'True' : 'False'}
├ Name : ${ctx.from.first_name}${ctx.from.last_name ? ' ' + ctx.from.last_name : ''}
├ Profile : @${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`,
                    parse_mode: 'Markdown',
                    ...Markup.inlineKeyboard([
                        [Markup.button.callback('Jasher Menu', 'jasher_menu')],
                        [Markup.button.callback('Owner Menu', 'owner_menu'), Markup.button.callback('Obf Menu', 'obf_menu')],
                        [Markup.button.callback('Kembali', 'back')]
                    ])
                }
            );
        } catch (error) {
            console.error('Error in back action:', error);
        }
    });

    // Handler untuk Jasher Menu
    bot.action('jasher_menu', async (ctx) => {
        try {
            await ctx.editMessageCaption(
                `🎯 *Jasher Menu*\n\n` +
                `🔰 Fitur-fitur yang tersedia:\n` +
                `• /sharefree - Bagikan pesan ke semua grup (Free)\n` +
                `• /sharevip - Bagikan pesan ke semua grup (VIP, lebih cepat)\n` +
                `• /tourl - Konversi foto ke URL\n` +
                `• /menu - Tampilkan menu utama\n\n` +
                `💎 *Premium Features:*\n` +
                `• Share tanpa delay\n` +
                `• Prioritas pemrosesan\n` +
                `• Akses fitur VIP\n\n` +
                `Ketik /menu untuk kembali ke menu utama.`,
                {
                    parse_mode: 'Markdown',
                    ...Markup.inlineKeyboard([
                        [Markup.button.callback('Kembali', 'back')]
                    ])
                }
            );
        } catch (error) {
            console.error('Error in jasher_menu action:', error);
        }
    });

    // Handler untuk Owner Menu
    bot.action('owner_menu', async (ctx) => {
        if (!isCreator(ctx.from.id)) {
            await ctx.answerCbQuery('❌ Hanya owner yang dapat mengakses menu ini!');
            return;
        }
        
        try {
            await ctx.editMessageCaption(
                `👑 *Owner Menu*\n\n` +
                `🔧 Fitur-fitur owner:\n` +
                `• /addprem <user_id> <days> - Tambahkan premium user\n` +
                `• /delprem <user_id> - Hapus premium user\n` +
                `• /listprem - Lift daftar user premium\n` +
                `• /addbl <user_id> - Tambahkan user ke blacklist\n` +
                `• /delbl <user_id> - Hapus user dari blacklist\n` +
                `• /listbl - Lihat daftar blacklist\n` +
                `• /listgrup - Lihat daftar grup\n` +
                `• /hapusgb - Hapus grup tidak aktif\n` +
                `• /bc <pesan> - Broadcast ke semua user\n\n` +
                `Ketik /menu untuk kembali ke menu utama.`,
                {
                    parse_mode: 'Markdown',
                    ...Markup.inlineKeyboard([
                        [Markup.button.callback('Kembali', 'back')]
                    ])
                }
            );
        } catch (error) {
            console.error('Error in owner_menu action:', error);
        }
    });

    // Handler untuk Obf Menu
    bot.action('obf_menu', async (ctx) => {
        try {
            await ctx.editMessageCaption(
                `🔒 *Obfuscation Menu*\n\n` +
                `🛡️ Fitur-fitur obfuscation:\n` +
                `• /enc3 - Hardened Mandarin Obfuscation\n` +
                `• /enc4 - Hardened Arab Obfuscation\n` +
                `• /japan - Hardened Japan Obfuscation\n` +
                `• /deobfuscate - Deobfuscate file\n` +
                `• /zenc - Invisible Obfuscation\n` +
                `• /xx <nama> - Custom Obfuscation\n` +
                `• /quantum - Quantum Vortex Encryption\n` +
                `• /var - Var Dynamic Obfuscation\n` +
                `• /nebula - Nebula Polymorphic Storm\n` +
                `• /enc5 - Calcrick Chaos Core\n` +
                `• /enc2 <text> - Custom Text Obfuscation\n` +
                `• /enc <days> - Time-Locked Encryption\n\n` +
                `📝 Cara penggunaan: Balas file JavaScript dengan command di atas.\n\n` +
                `Ketik /menu untuk kembali ke menu utama.`,
                {
                    parse_mode: 'Markdown',
                    ...Markup.inlineKeyboard([
                        [Markup.button.callback('Kembali', 'back')]
                    ])
                }
            );
        } catch (error) {
            console.error('Error in obf_menu action:', error);
        }
    });

    // Handler untuk menu utama dari callback
    bot.action('menu', async (ctx) => {
        try {
            await ctx.deleteMessage();
            const userId = ctx.from.id;
            const isCreatorUser = isCreator(userId);
            const sender = ctx.from.username || ctx.from.first_name;
            
            await ctx.replyWithPhoto(
                'https://f.top4top.io/p_3530xky9e4.jpg',
                {
                    caption: `╭─❒ 「 User Info 」 
├ Owner : ${isCreatorUser ? 'True' : 'False'}
├ Name : ${ctx.from.first_name}${ctx.from.last_name ? ' ' + ctx.from.last_name : ''}
├ Profile : @${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`,
                    parse_mode: 'Markdown',
                    ...Markup.inlineKeyboard([
                        [Markup.button.callback('Jasher Menu', 'jasher_menu')],
                        [Markup.button.callback('Owner Menu', 'owner_menu'), Markup.button.callback('Obf Menu', 'obf_menu')],
                        [Markup.button.callback('Kembali', 'back')]
                    ])
                }
            );
        } catch (error) {
            console.error('Error in menu action:', error);
        }
    });
}

module.exports = {
    setupCallbackHandlers
};