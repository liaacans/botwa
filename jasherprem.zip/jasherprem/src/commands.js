const { Markup } = require('telegraf');
const { User } = require('../lib/database');
const { formatUserInfo } = require('./utils');

// Main menu keyboard
function getMainMenuKeyboard(ctx, user) {
    const buttons = [
        [Markup.button.callback('🎯 Jasher Menu', 'jasher_menu')],
        [Markup.button.callback('👤 Owner Menu', 'owner_menu')],
        [Markup.button.url('➕ Add Group', 'https://t.me/jasherpremtia_bot?startgroup=true')],
        [Markup.button.callback('👨‍💻 Owner', 'owner_info')]
    ];
    
    // Add premium menu if user is premium
    if (user.isPremium) {
        buttons[0].splice(1, 0, Markup.button.callback('⭐ Premium Menu', 'premium_menu'));
    }
    
    return Markup.inlineKeyboard(buttons);
}

// Jasher menu keyboard
function getJasherMenuKeyboard() {
    return Markup.inlineKeyboard([
        [Markup.button.callback('🔄 Share', 'share_command'), Markup.button.callback('💎 Credit', 'credit_command')],
        [Markup.button.callback('🔙 Kembali', 'main_menu')]
    ]);
}

// Owner menu keyboard (only for admin)
function getOwnerMenuKeyboard() {
    return Markup.inlineKeyboard([
        [Markup.button.callback('📢 Broadcast', 'broadcast_command')],
        [Markup.button.callback('⭐ Add Premium', 'add_premium'), Markup.button.callback('🗑️ Remove Premium', 'remove_premium')],
        [Markup.button.callback('📋 List Premium', 'list_premium')],
        [Markup.button.callback('🔙 Kembali', 'main_menu')]
    ]);
}

// Premium menu keyboard
function getPremiumMenuKeyboard() {
    return Markup.inlineKeyboard([
        [Markup.button.callback('🚀 Share VIP', 'share_vip')],
        [Markup.button.callback('🔙 Kembali', 'main_menu')]
    ]);
}

// Handle start command
async function handleStart(ctx) {
    try {
        const userId = ctx.from.id;
        let user = await User.findOne({ userId });
        
        if (!user) {
            user = new User({
                userId,
                username: ctx.from.username,
                firstName: ctx.from.first_name,
                lastName: ctx.from.last_name
            });
            await user.save();
        }
        
        const isCreator = userId.toString() === process.env.ADMIN_ID;
        const message = formatUserInfo(ctx, user, isCreator);
        const photoUrl = 'https://f.top4top.io/p_3530xky9e4.jpg';
        
        await ctx.replyWithPhoto(photoUrl, {
            caption: message,
            parse_mode: 'HTML',
            ...getMainMenuKeyboard(ctx, user)
        });
    } catch (error) {
        console.error('Error in start command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

// Handle help command
async function handleHelp(ctx) {
    const helpText = `🤖 <b>Jasher Bot Help</b>
    
🔹 <b>Fitur Umum:</b>
- /start - Memulai bot
- /help - Menampilkan bantuan
- Credit - Melihat kredit Anda
- Share - Berbagi pesan (mengurangi 2 kredit)

🔹 <b>Fitur Premium:</b>
- Share VIP - Berbagi pesan lebih cepat (hanya untuk premium)

🔹 <b>Cara Mendapatkan Kredit:</b>
- Tambahkan bot ke 3 grup untuk mendapatkan 10 kredit

🔹 <b>Fitur Owner:</b>
- Broadcast - Mengirim pesan ke semua pengguna
- Kelola pengguna premium`;

    await ctx.reply(helpText, { parse_mode: 'HTML' });
}

module.exports = {
    getMainMenuKeyboard,
    getJasherMenuKeyboard,
    getOwnerMenuKeyboard,
    getPremiumMenuKeyboard,
    handleStart,
    handleHelp
};