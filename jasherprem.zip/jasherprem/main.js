const { Telegraf, session } = require('telegraf');
const { BOT_TOKEN } = require('./config');
const { connectDB } = require('./lib/database');
const { handleStart, handleHelp } = require('./src/commands');
const { handleCallbacks } = require('./src/handlers');

// Initialize bot
const bot = new Telegraf(BOT_TOKEN);

// Middleware
bot.use(session());

// Connect to database
connectDB();

// Start command
bot.command('start', handleStart);

// Help command
bot.command('help', handleHelp);

// Credit command
bot.command('credit', async (ctx) => {
    const userId = ctx.from.id;
    const user = await User.findOne({ userId });
    await ctx.reply(`💎 Kredit Anda: ${user.credit}`);
});

// Share command
bot.command('share', async (ctx) => {
    const userId = ctx.from.id;
    const user = await User.findOne({ userId });
    
    if (ctx.chat.type !== 'private') {
        await ctx.reply('❌ Perintah ini hanya bisa digunakan di chat private!');
        return;
    }
    
    if (user.credit < 2) {
        await ctx.reply('❌ Kredit Anda tidak cukup! Tambahkan bot ke 3 grup untuk mendapatkan kredit.');
        return;
    }
    
    if (user.addedGroups.length < 3) {
        await ctx.reply(`❌ Anda harus menambahkan bot ke ${3 - user.addedGroups.length} grup lagi untuk menggunakan fitur share.`);
        return;
    }
    
    await ctx.reply('📤 Silakan kirim pesan yang ingin di-share atau balas pesan yang ingin di-share:');
});

// Handle callback queries
bot.on('callback_query', handleCallbacks);

// Handle new chat members (when bot is added to a group)
bot.on('chat_member', async (ctx) => {
    if (ctx.chatMember.new_chat_member.status === 'member' && 
        ctx.chatMember.new_chat_member.user.id === ctx.botInfo.id) {
        // Bot was added to a group
        const userId = ctx.chatMember.from.id;
        const user = await User.findOne({ userId });
        
        if (user) {
            // Check if group already added
            const groupExists = user.addedGroups.some(group => group.groupId === ctx.chat.id);
            
            if (!groupExists) {
                user.addedGroups.push({
                    groupId: ctx.chat.id,
                    groupName: ctx.chat.title
                });
                
                // Add credit if user added 3 groups
                if (user.addedGroups.length === 3) {
                    user.credit += 10;
                    await user.save();
                    
                    // Notify user
                    try {
                        await ctx.telegram.sendMessage(
                            userId, 
                            `🎉 Terima kasih! Anda telah menambahkan bot ke 3 grup. Anda mendapatkan 10 kredit! Total kredit: ${user.credit}`
                        );
                    } catch (error) {
                        console.error('Cannot send message to user:', error);
                    }
                } else {
                    await user.save();
                }
            }
        }
    }
});

// Error handling
bot.catch((err, ctx) => {
    console.error(`Error for ${ctx.updateType}:`, err);
    ctx.reply('❌ Terjadi kesalahan, silakan coba lagi.');
});

// Start bot
bot.launch().then(() => {
    console.log('Bot started successfully');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));