const { Markup } = require('telegraf');
const moment = require('moment-timezone');
const { 
  runtime, 
  isPremium, 
  getPremiumDaysLeft, 
  addPremium, 
  removePremium 
} = require('../lib/utils');
const { handleObfuscate } = require('./obf');

// Main menu
function mainMenu(ctx) {
  const username = ctx.from.username || 'Tidak ada';
  const isCreator = ctx.from.id.toString() === process.env.CREATOR_ID;
  const developer = global.DEVELOPER || '@developer';
  
  const menuText = `
╭─❒ 「 User Info 」 
├ Creator : ${developer}
├ Name : @${username}
├ Profile : @${ctx.from.first_name}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreator ? 'True' : 'False'}
Silahkan pilih button dibawah ini!`;

  const buttons = Markup.inlineKeyboard([
    [Markup.button.callback('Jasher Menu', 'jasher_menu')],
    [Markup.button.callback('Obf Menu', 'obf_menu')],
    [Markup.button.callback('Owner', 'owner_menu')]
  ]);

  ctx.replyWithPhoto({ url: 'https://f.top4top.io/p_3530xky9e4.jpg' }, {
    caption: menuText,
    parse_mode: 'HTML',
    ...buttons
  });
}

// Handle start command
function handleStart(ctx) {
  // Save user to database
  const userId = ctx.from.id.toString();
  if (!global.db.users.has(userId)) {
    global.db.users.set(userId, {
      userId: ctx.from.id,
      username: ctx.from.username,
      first_name: ctx.from.first_name,
      last_name: ctx.from.last_name,
      joinedGroups: new Set(),
      shareCount: 0,
      lastShare: 0,
      joinedAt: Date.now()
    });
  }
  
  mainMenu(ctx);
}

// Handle help command
function handleHelp(ctx) {
  const helpText = `
🤖 *BOT JASHER PREMIUM* 🤖

Fitur Utama:
- Obfuscation JavaScript dengan berbagai metode
- Sistem premium dengan berbagi grup
- Broadcast ke semua pengguna
- Fitur khusus untuk owner

Cara menggunakan:
1. Tambahkan bot ke grup Anda
2. Bagikan link bot ke 3 grup berbeda
3. Dapatkan akses premium 3 hari
4. Gunakan fitur obfuscation

Perintah yang tersedia:
/start - Memulai bot
/help - Menampilkan bantuan
/enclocked [hari] - Obfuscation dengan waktu kedaluwarsa
/quantum - Obfuscation Quantum
/siu - Obfuscation Siu Calcrick
/custom [teks] - Obfuscation dengan custom identifier
/nebula - Obfuscation Nebula
/nova - Obfuscation Nova
/strong - Obfuscation Strong
/arab - Obfuscation Arab
/japanxarab - Obfuscation Japan x Arab
/japan - Obfuscation Japan

Untuk owner:
/addprem [userid] [hari] - Menambah premium user
/delprem [userid] - Menghapus premium user
/listprem - Daftar user premium
/addbl [userid/groupid] - Menambah blacklist
/delbl [userid/groupid] - Menghapus blacklist
/listbl - Daftar blacklist
/autojasher - Auto share setiap 10 menit
/stopautojasher - Stop auto share
/listgroup - Daftar grup aktif
/tourl - Convert media to URL
/bc [pesan] - Broadcast ke semua user
  `;
  
  ctx.reply(helpText, { parse_mode: 'Markdown' });
}

// Handle enclocked command
function handleEnclocked(ctx) {
  const args = ctx.message.text.split(' ');
  if (args.length < 2) {
    return ctx.reply('Usage: /enclocked [days] - Reply to a JavaScript file or message');
  }
  
  const days = parseInt(args[1]);
  if (isNaN(days) || days <= 0) {
    return ctx.reply('Hari harus berupa angka positif');
  }
  
  handleObfuscate(ctx, 'timelocked', days);
}

// Handle quantum command
function handleQuantum(ctx) {
  handleObfuscate(ctx, 'quantum');
}

// Handle siu command
function handleSiu(ctx) {
  handleObfuscate(ctx, 'siu');
}

// Handle custom command
function handleCustom(ctx) {
  handleObfuscate(ctx, 'custom');
}

// Handle nebula command
function handleNebula(ctx) {
  handleObfuscate(ctx, 'nebula');
}

// Handle nova command
function handleNova(ctx) {
  handleObfuscate(ctx, 'nova');
}

// Handle strong command
function handleStrong(ctx) {
  handleObfuscate(ctx, 'strong');
}

// Handle arab command
function handleArab(ctx) {
  handleObfuscate(ctx, 'arab');
}

// Handle japanxarab command
function handleJapanxArab(ctx) {
  handleObfuscate(ctx, 'japanxarab');
}

// Handle japan command
function handleJapan(ctx) {
  handleObfuscate(ctx, 'japan');
}

// Handle callback queries
function handleCallbackQuery(ctx) {
  const data = ctx.callbackQuery.data;
  
  switch (data) {
    case 'jasher_menu':
      showJasherMenu(ctx);
      break;
    case 'obf_menu':
      showObfMenu(ctx);
      break;
    case 'owner_menu':
      showOwnerMenu(ctx);
      break;
    case 'main_menu':
      mainMenu(ctx);
      break;
    case 'back':
      ctx.deleteMessage();
      mainMenu(ctx);
      break;
    default:
      ctx.answerCbQuery('Fitur belum tersedia');
  }
}

// Show Jasher menu
function showJasherMenu(ctx) {
  const isPrem = isPremium(ctx.from.id);
  const daysLeft = getPremiumDaysLeft(ctx.from.id);
  
  const menuText = `
🤖 *JASHER MENU* 🤖

Status: ${isPrem ? `✅ Premium (${daysLeft} hari tersisa)` : '❌ Free'}
Group Joined: ${global.db.users.get(ctx.from.id.toString())?.joinedGroups.size || 0}/3

Fitur:
- Share ke grup untuk mendapatkan premium
- Gunakan fitur obfuscation
- Lihat status premium

Untuk mendapatkan premium, bagikan bot ini ke 3 grup berbeda.
  `;
  
  const buttons = Markup.inlineKeyboard([
    [Markup.button.callback('Share ke Grup', 'share_group')],
    [Markup.button.callback('Status Premium', 'premium_status')],
    [Markup.button.callback('Kembali', 'back')],
    [Markup.button.callback('Main Menu', 'main_menu')]
  ]);
  
  ctx.editMessageCaption(menuText, {
    parse_mode: 'Markdown',
    ...buttons
  });
}

// Show Obf menu
function showObfMenu(ctx) {
  const menuText = `
🔒 *OBFUSCATION MENU* 🔒

Pilih metode obfuscation:

1. Time-Locked - Obfuscation dengan waktu kedaluwarsa
2. Quantum - Obfuscation dengan enkripsi quantum
3. Siu Calcrick - Obfuscation dengan identifier khusus
4. Custom - Obfuscation dengan custom identifier
5. Nebula - Obfuscation metode Nebula
6. Nova - Obfuscation metode Nova
7. Strong - Obfuscation kuat
8. Arab - Obfuscation dengan identifier Arab
9. Japan x Arab - Mix identifier Japan dan Arab
10. Japan - Obfuscation dengan identifier Japan

Cara penggunaan:
Balas pesan yang berisi kode JavaScript, lalu ketik perintah obfuscation yang diinginkan.
  `;
  
  const buttons = Markup.inlineKeyboard([
    [Markup.button.callback('Time-Locked', 'obf_timelocked')],
    [Markup.button.callback('Quantum', 'obf_quantum')],
    [Markup.button.callback('Siu Calcrick', 'obf_siu')],
    [Markup.button.callback('Custom', 'obf_custom')],
    [Markup.button.callback('Nebula', 'obf_nebula')],
    [Markup.button.callback('Nova', 'obf_nova')],
    [Markup.button.callback('Strong', 'obf_strong')],
    [Markup.button.callback('Arab', 'obf_arab')],
    [Markup.button.callback('Japan x Arab', 'obf_japanxarab')],
    [Markup.button.callback('Japan', 'obf_japan')],
    [Markup.button.callback('Kembali', 'back')],
    [Markup.button.callback('Main Menu', 'main_menu')]
  ]);
  
  ctx.editMessageCaption(menuText, {
    parse_mode: 'Markdown',
    ...buttons
  });
}

// Show Owner menu
function showOwnerMenu(ctx) {
  // Check if user is owner/creator
  const isCreator = ctx.from.id.toString() === process.env.CREATOR_ID;
  if (!isCreator) {
    return ctx.answerCbQuery('Akses ditolak. Hanya owner yang bisa mengakses menu ini.');
  }
  
  const menuText = `
👑 *OWNER MENU* 👑

Fitur khusus untuk owner bot:

- Kelola premium user
- Kelola blacklist
- Auto share
- Broadcast pesan
- Kelola grup

Pilih opsi di bawah:
  `;
  
  const buttons = Markup.inlineKeyboard([
    [Markup.button.callback('Add Premium', 'owner_addprem')],
    [Markup.button.callback('Del Premium', 'owner_delprem')],
    [Markup.button.callback('List Premium', 'owner_listprem')],
    [Markup.button.callback('Add Blacklist', 'owner_addbl')],
    [Markup.button.callback('Del Blacklist', 'owner_delbl')],
    [Markup.button.callback('List Blacklist', 'owner_listbl')],
    [Markup.button.callback('Auto Jasher', 'owner_autojasher')],
    [Markup.button.callback('Stop Auto Jasher', 'owner_stopautojasher')],
    [Markup.button.callback('List Group', 'owner_listgroup')],
    [Markup.button.callback('Broadcast', 'owner_broadcast')],
    [Markup.button.callback('Kembali', 'back')],
    [Markup.button.callback('Main Menu', 'main_menu')]
  ]);
  
  ctx.editMessageCaption(menuText, {
    parse_mode: 'Markdown',
    ...buttons
  });
}

// Handle new chat members (bot added to group)
function handleNewChatMembers(ctx) {
  const newMembers = ctx.message.new_chat_members;
  
  // Check if bot was added to group
  const botId = ctx.botInfo.id;
  const botAdded = newMembers.some(member => member.id === botId);
  
  if (botAdded) {
    const chatId = ctx.chat.id;
    const chatTitle = ctx.chat.title;
    const chatType = ctx.chat.type;
    
    // Save group to database
    global.db.groups.set(chatId.toString(), {
      chatId: chatId,
      title: chatTitle,
      type: chatType,
      addedAt: Date.now(),
      active: true
    });
    
    // Send welcome message
    ctx.reply(`Terima kasih telah menambahkan saya ke grup ${chatTitle}! Gunakan /help untuk melihat fitur yang tersedia.`);
  }
}

// Handle left chat member (bot removed from group)
function handleLeftChatMember(ctx) {
  const leftMember = ctx.message.left_chat_member;
  const botId = ctx.botInfo.id;
  
  if (leftMember.id === botId) {
    const chatId = ctx.chat.id;
    
    // Remove group from database or mark as inactive
    if (global.db.groups.has(chatId.toString())) {
      global.db.groups.delete(chatId.toString());
    }
  }
}

module.exports = {
  handleStart,
  handleHelp,
  handleEnclocked,
  handleQuantum,
  handleSiu,
  handleCustom,
  handleNebula,
  handleNova,
  handleStrong,
  handleArab,
  handleJapanxArab,
  handleJapan,
  handleCallbackQuery,
  handleNewChatMembers,
  handleLeftChatMember
};