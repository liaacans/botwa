document.addEventListener('DOMContentLoaded', function() {
    // Handle order modal data
    const orderModal = document.getElementById('orderModal');
    if (orderModal) {
        orderModal.addEventListener('show.bs.modal', function(event) {
            const button = event.relatedTarget;
            const memory = button.getAttribute('data-memory');
            const disk = button.getAttribute('data-disk');
            const cpu = button.getAttribute('data-cpu');
            const price = button.getAttribute('data-price');
            
            // Convert memory to GB for display
            const memoryGB = memory === '0' ? 'Unlimited' : (memory / 1024) + 'GB';
            const diskGB = disk === '0' ? 'Unlimited' : (disk / 1024) + 'GB';
            const cpuCores = cpu === '0' ? 'Unlimited' : (cpu / 100) + ' Core';
            
            document.getElementById('orderMemory').value = memory;
            document.getElementById('orderDisk').value = disk;
            document.getElementById('orderCpu').value = cpu;
            document.getElementById('orderPrice').value = price;
            
            document.getElementById('packageName').value = `${memoryGB} RAM, ${diskGB} SSD, ${cpuCores} CPU`;
            document.getElementById('packagePrice').value = `Rp ${parseInt(price).toLocaleString('id-ID')}/bulan`;
        });
    }
    
    // Form validation
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            const password = document.getElementById('registerPassword').value;
            const confirmPassword = document.getElementById('registerConfirmPassword').value;
            
            if (password !== confirmPassword) {
                e.preventDefault();
                alert('Password dan konfirmasi password tidak cocok!');
            }
        });
    }
    
    // Phone number validation
    const phoneInput = document.getElementById('registerPhone');
    if (phoneInput) {
        phoneInput.addEventListener('input', function(e) {
            this.value = this.value.replace(/[^0-9]/g, '');
        });
    }
    
    // Auto close alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
    
    // Enable tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});