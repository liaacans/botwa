const { Telegraf, session } = require('telegraf');
const { BOT_TOKEN } = require('./config');
const { setupCommands } = require('./src/commands');
const { handleNewChatMember } = require('./src/handlers');
const db = require('./lib/database');

// Initialize bot
const bot = new Telegraf(BOT_TOKEN);

// Middleware
bot.use(session({
  defaultSession: () => ({
    waitingForBroadcast: false,
    broadcastType: null,
    waitingForPremiumAdd: false,
    waitingForPremiumRemove: false,
    waitingForOwnerBroadcast: false
  })
}));

// Event handlers
bot.on('new_chat_members', handleNewChatMember);

// Setup commands
setupCommands(bot);

// Error handling
bot.catch((err, ctx) => {
  console.error(`Error for ${ctx.updateType}:`, err);
  if (ctx.chat) {
    ctx.reply('❌ Terjadi kesalahan saat memproses permintaan Anda. Silakan coba lagi.');
  }
});

// Start bot
bot.launch().then(() => {
  console.log('🤖 Jasher Bot started successfully!');
}).catch(err => {
  console.error('Failed to start bot:', err);
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));