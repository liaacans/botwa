const { Telegraf, Markup } = require('telegraf');
const { connectDB } = require('./lib/database');
const { setupAllCommands } = require('./src/commands');
const { setupObfuscationCommands } = require('./src/obfuscation');
const { handleNewChatMembers, handleLeftChatMember, handleGroupMessage } = require('./src/groupManagement');
const { userMiddleware, premiumMiddleware } = require('./lib/middleware');
const { log, moment } = require('./lib/utils');
const { setBotInstance } = require('./src/paymentHandler');


// Load config
require('./config');

// Inisialisasi bot
const bot = new Telegraf(global.BOT_TOKEN);

// Koneksi database
connectDB();

// Middleware
bot.use(userMiddleware);
bot.use(handleGroupMessage);

// Setel instance bot di payment handler
setBotInstance(bot);

// Event handlers
bot.on('new_chat_members', handleNewChatMembers);
bot.on('left_chat_member', handleLeftChatMember);

// Setup commands
setupAllCommands(bot);
setupObfuscationCommands(bot);

// Handler untuk callback queries - PERBAIKAN
bot.action('buy_premium', async (ctx) => {
  try {
    // Coba edit message text jika memungkinkan
    try {
      await ctx.editMessageText(
        `🎖️ *Beli Premium*\n\n` +
        `Dengan premium, Anda dapat:\n` +
        `• Menggunakan semua fitur obfuscation\n` +
        `• Share tanpa batas\n` +
        `• Prioritas support\n\n` +
        `Harga: Rp 50.000 / bulan\n\n` +
        `Gunakan /buyprem untuk membeli premium.`,
        { 
          parse_mode: 'Markdown',
          reply_markup: { 
            inline_keyboard: [[Markup.button.callback('🔙 Kembali', 'main_menu')]] 
          }
        }
      );
    } catch (editError) {
      // Jika gagal mengedit (karena pesan berisi foto/media), kirim pesan baru
      await ctx.reply(
        `🎖️ *Beli Premium*\n\n` +
        `Dengan premium, Anda dapat:\n` +
        `• Menggunakan semua fitur obfuscation\n` +
        `• Share tanpa batas\n` +
        `• Prioritas support\n\n` +
        `Harga: Rp 50.000 / bulan\n\n` +
        `Gunakan /buyprem untuk membeli premium.`,
        { 
          parse_mode: 'Markdown',
          reply_markup: { 
            inline_keyboard: [[Markup.button.callback('🔙 Kembali', 'main_menu')]] 
          }
        }
      );
      
      // Hapus pesan callback query
      await ctx.answerCbQuery();
    }
  } catch (error) {
    log('Error in buy_premium callback: ' + error.message);
    await ctx.answerCbQuery('❌ Terjadi kesalahan');
  }
});

// Handler untuk main_menu callback - PERBAIKAN
bot.action('main_menu', async (ctx) => {
  try {
    const isCreator = ctx.from.id.toString() === global.OWNER_ID;
    const sender = ctx.from.username || `${ctx.from.first_name}${ctx.from.last_name ? ' ' + ctx.from.last_name : ''}`;
    
    const menuText = `
╭─❒ 「 User Info 」 
├ Owner : ${isCreator ? 'True' : 'False'}
├ Name : ${ctx.from.first_name}${ctx.from.last_name ? ' ' + ctx.from.last_name : ''}
├ Profile : @${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`;

    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('🔰 Jasher Menu', 'jasher_menu')],
      [Markup.button.callback('👤 Owner Menu', 'owner_menu'), Markup.button.callback('🔒 Obf Menu', 'obf_menu')],
      [Markup.button.callback('🛒 Buy Premium', 'buy_premium'), Markup.button.callback('📊 Status', 'status_info')]
    ]);

    // Coba edit message terlebih dahulu
    try {
      await ctx.editMessageText(menuText, {
        parse_mode: 'Markdown',
        ...keyboard
      });
    } catch (editError) {
      // Jika gagal mengedit, kirim pesan baru dan hapus yang lama jika mungkin
      try {
        await ctx.deleteMessage();
      } catch (deleteError) {
        // Ignore delete error
      }
      
      try {
        await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
          caption: menuText,
          parse_mode: 'Markdown',
          ...keyboard
        });
      } catch (photoError) {
        await ctx.reply(menuText, {
          parse_mode: 'Markdown',
          ...keyboard
        });
      }
    }
    
    await ctx.answerCbQuery();
  } catch (error) {
    log('Error in main_menu callback: ' + error.message);
    await ctx.answerCbQuery('❌ Terjadi kesalahan');
  }
});

// Handler untuk callback queries lainnya - PERBAIKAN DENGAN PATTERN YANG SAMA
bot.action('jasher_menu', async (ctx) => {
  try {
    try {
      await ctx.editMessageText(
        `🔰 *Jasher Menu*\n\n` +
        `• /sharefree - Share pesan (Free)\n` +
        `• /sharevip - Share pesan (VIP, premium only)\n` +
        `• /tourl - Upload file ke uguu.se\n` +
        `• /status - Status akun Anda\n` +
        `• /buysc - Beli script premium\n` +
        `• /buyprem - Beli akses premium\n\n` +
        `_Gunakan command di atas untuk mengakses fitur Jasher Bot._`,
        { 
          parse_mode: 'Markdown',
          reply_markup: { inline_keyboard: [[Markup.button.callback('🔙 Kembali', 'main_menu')]] }
        }
      );
    } catch (editError) {
      await ctx.reply(
        `🔰 *Jasher Menu*\n\n` +
        `• /sharefree - Share pesan (Free)\n` +
        `• /sharevip - Share pesan (VIP, premium only)\n` +
        `• /tourl - Upload file ke uguu.se\n` +
        `• /status - Status akun Anda\n` +
        `• /buysc - Beli script premium\n` +
        `• /buyprem - Beli akses premium\n\n` +
        `_Gunakan command di atas untuk mengakses fitur Jasher Bot._`,
        { 
          parse_mode: 'Markdown',
          reply_markup: { inline_keyboard: [[Markup.button.callback('🔙 Kembali', 'main_menu')]] }
        }
      );
      await ctx.answerCbQuery();
    }
  } catch (error) {
    log('Error in jasher_menu callback: ' + error.message);
    await ctx.answerCbQuery('❌ Terjadi kesalahan');
  }
});

bot.action('owner_menu', async (ctx) => {
  try {
    if (ctx.from.id.toString() !== global.OWNER_ID) {
      await ctx.answerCbQuery('⛔ Menu ini hanya untuk owner!');
      return;
    }
    
    try {
      await ctx.editMessageText(
        `👤 *Owner Menu*\n\n` +
        `• /addprem <user_id> <days> - Tambah premium user\n` +
        `• /delprem <user_id> - Hapus premium user\n` +
        `• /listprem - List user premium\n` +
        `• /addbl <group_id> [reason] - Tambah grup ke blacklist\n` +
        `• /delbl <group_id> - Hapus grup dari blacklist\n` +
        `• /listbl - List grup blacklist\n` +
        `• /listgroups - List grup aktif\n` +
        `• /cleangroups - Hapus grup tidak aktif\n` +
        `• /bc <message> - Broadcast ke semua user\n\n` +
        `_Gunakan command di atas untuk mengelola bot._`,
        { 
          parse_mode: 'Markdown',
          reply_markup: { inline_keyboard: [[Markup.button.callback('🔙 Kembali', 'main_menu')]] }
        }
      );
    } catch (editError) {
      await ctx.reply(
        `👤 *Owner Menu*\n\n` +
        `• /addprem <user_id> <days> - Tambah premium user\n` +
        `• /delprem <user_id> - Hapus premium user\n` +
        `• /listprem - List user premium\n` +
        `• /addbl <group_id> [reason] - Tambah grup ke blacklist\n` +
        `• /delbl <group_id> - Hapus grup dari blacklist\n` +
        `• /listbl - List grup blacklist\n` +
        `• /listgroups - List grup aktif\n` +
        `• /cleangroups - Hapus grup tidak aktif\n` +
        `• /bc <message> - Broadcast ke semua user\n\n` +
        `_Gunakan command di atas untuk mengelola bot._`,
        { 
          parse_mode: 'Markdown',
          reply_markup: { inline_keyboard: [[Markup.button.callback('🔙 Kembali', 'main_menu')]] }
        }
      );
      await ctx.answerCbQuery();
    }
  } catch (error) {
    log('Error in owner_menu callback: ' + error.message);
    await ctx.answerCbQuery('❌ Terjadi kesalahan');
  }
});

bot.action('obf_menu', async (ctx) => {
  try {
    try {
      await ctx.editMessageText(
        `🔒 *Obfuscation Menu*\n\n` +
        `• /enc3 - Mandarin Obfuscation\n` +
        `• /enc4 - Arab Obfuscation\n` +
        `• /japan - Japan Obfuscation\n` +
        `• /zenc - Invisible Obfuscation\n` +
        `• /xx <name> - Custom Obfuscation\n` +
        `• /quantum - Quantum Obfuscation\n` +
        `• /var - Nova Obfuscation\n` +
        `• /nebula - Nebula Obfuscation\n` +
        `• /enc5 - Siu+Calcrick Obfuscation\n` +
        `• /enc2 <text> - Custom Text Obfuscation\n` +
        `• /enc <days> - Time-Locked Obfuscation\n\n` +
        `_Balas file .js dengan command di atas untuk mengobfuscate._`,
        { 
          parse_mode: 'Markdown',
          reply_markup: { inline_keyboard: [[Markup.button.callback('🔙 Kembali', 'main_menu')]] }
        }
      );
    } catch (editError) {
      await ctx.reply(
        `🔒 *Obfuscation Menu*\n\n` +
        `• /enc3 - Mandarin Obfuscation\n` +
        `• /enc4 - Arab Obfuscation\n` +
        `• /japan - Japan Obfuscation\n` +
        `• /zenc - Invisible Obfuscation\n` +
        `• /xx <name> - Custom Obfuscation\n` +
        `• /quantum - Quantum Obfuscation\n` +
        `• /var - Nova Obfuscation\n` +
        `• /nebula - Nebula Obfuscation\n` +
        `• /enc5 - Siu+Calcrick Obfuscation\n` +
        `• /enc2 <text> - Custom Text Obfuscation\n` +
        `• /enc <days> - Time-Locked Obfuscation\n\n` +
        `_Balas file .js dengan command di atas untuk mengobfuscate._`,
        { 
          parse_mode: 'Markdown',
          reply_markup: { inline_keyboard: [[Markup.button.callback('🔙 Kembali', 'main_menu')]] }
        }
      );
      await ctx.answerCbQuery();
    }
  } catch (error) {
    log('Error in obf_menu callback: ' + error.message);
    await ctx.answerCbQuery('❌ Terjadi kesalahan');
  }
});

bot.action('status_info', async (ctx) => {
  try {
    const user = ctx.userData;
    const isCreator = ctx.from.id.toString() === global.OWNER_ID;
    
    let statusMessage = `📊 *Status Akun*\n\n`;
    statusMessage += `👤 Nama: ${user.firstName}${user.lastName ? ' ' + user.lastName : ''}\n`;
    statusMessage += `🆔 ID: ${user.userId}\n`;
    statusMessage += `📅 Terdaftar: ${moment(user.createdAt).format('DD/MM/YYYY HH:mm')}\n\n`;
    
    if (user.isPremium && user.premiumUntil > new Date()) {
      const remaining = Math.ceil((user.premiumUntil - new Date()) / (1000 * 60 * 60 * 24));
      statusMessage += `🎖️ Status: *Premium*\n`;
      statusMessage += `⏰ Sisa waktu: ${remaining} hari\n`;
      statusMessage += `📅 Hingga: ${moment(user.premiumUntil).format('DD/MM/YYYY HH:mm')}\n`;
    } else {
      statusMessage += `🎖️ Status: *Regular*\n`;
      statusMessage += `💡 Tambahkan bot ke 3 grup untuk mendapatkan premium 3 hari gratis!\n`;
    }
    
    statusMessage += `\n📤 Total share: ${user.shareCount}`;
    
    try {
      await ctx.editMessageText(statusMessage, {
        parse_mode: 'Markdown',
        reply_markup: { inline_keyboard: [[Markup.button.callback('🔙 Kembali', 'main_menu')]] }
      });
    } catch (editError) {
      await ctx.reply(statusMessage, {
        parse_mode: 'Markdown',
        reply_markup: { inline_keyboard: [[Markup.button.callback('🔙 Kembali', 'main_menu')]] }
      });
      await ctx.answerCbQuery();
    }
  } catch (error) {
    log('Error in status_info callback: ' + error.message);
    await ctx.answerCbQuery('❌ Terjadi kesalahan');
  }
});

// Handler error
bot.catch((err, ctx) => {
  log(`Error for ${ctx.updateType}: ${err.message}`);
  console.error(err);
});

// Start bot
bot.launch().then(() => {
  log('Bot started successfully');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));