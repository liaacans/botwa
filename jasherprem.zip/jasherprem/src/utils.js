const moment = require('moment-timezone');

// Format runtime
function runtime(seconds) {
    seconds = Math.floor(seconds);
    const days = Math.floor(seconds / (3600 * 24));
    seconds %= 3600 * 24;
    const hours = Math.floor(seconds / 3600);
    seconds %= 3600;
    const minutes = Math.floor(seconds / 60);
    seconds %= 60;
    
    return `${days}d ${hours}h ${minutes}m ${seconds}s`;
}

// Generate keyboard menu
function generateMainMenu(isCreator) {
    const buttons = [
        [{ text: "Jasher Menu", callback_data: "jasher_menu" }],
        [{ text: "Owner Menu", callback_data: "owner_menu" }]
    ];
    
    if (isCreator) {
        buttons.push([{ text: "AddGroup", callback_data: "add_group" }]);
        buttons.push([{ text: "Owner", callback_data: "owner_options" }]);
    }
    
    return {
        reply_markup: {
            inline_keyboard: buttons
        }
    };
}

// Format pesan utama
function mainMenuMessage(ctx, user) {
    const sender = ctx.from.username || ctx.from.first_name;
    const userTelelu = ctx.from.username || 'Tidak ada username';
    const isCreator = ctx.from.id.toString() === process.env.OWNER_ID;
    
    return `Hi kak @${sender}
╭─❒ 「 User Info 」 
├ Creator : @${userTelelu}
├ Name : ${ctx.from.first_name}${ctx.from.last_name ? ' ' + ctx.from.last_name : ''}
├ Profile : @${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : Linux
├ Platform : Bot Telegram
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreator ? 'True' : 'False'}
Silahkan pilih button dibawah ini!`;
}

module.exports = {
    runtime,
    generateMainMenu,
    mainMenuMessage
};