const moment = require('moment-timezone');

function runtime(seconds) {
    const days = Math.floor(seconds / (3600 * 24));
    seconds %= 3600 * 24;
    const hours = Math.floor(seconds / 3600);
    seconds %= 3600;
    const minutes = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    
    return `${days}d ${hours}h ${minutes}m ${secs}s`;
}

function formatUserInfo(ctx, userData) {
    const sender = ctx.from.first_name;
    const userTele = ctx.from.username ? `@${ctx.from.username}` : 'Tidak ada';
    const isCreator = ctx.from.id.toString() === process.env.ADMIN_ID;
    
    return `Hi kak @${sender}
╭─❒ 「 User Info 」 
├ Creator : @${userTele}
├ Name : ${sender}
├ Profile : @${userTele}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : Linux
├ Platform : Bot Telegram
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreator ? 'True' : 'False'}
Silahkan pilih button dibawah ini!`;
}

module.exports = {
    runtime,
    formatUserInfo
};