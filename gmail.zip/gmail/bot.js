const { Telegraf } = require('telegraf');
const nodemailer = require('nodemailer');
const Imap = require('imap');
const { simpleParser } = require('mailparser');
const cron = require('node-cron');

// Konfigurasi Bot Telegram
const BOT_TOKEN = '7569137877:AAHnvva5p9SFclkDpDio8QcJsSfbzlrK6IY';
const ALLOWED_GROUP_ID = '-1002793801544';

// Konfigurasi Email
const emailConfig = {
  incoming: {
    host: 'newpinwheel.indowebsite.net',
    port: 993, // Port IMAP default dengan SSL
    user: 'nokosmerah@buatkamu.web.id',
    password: 'Grki6Vv1gdlA',
    tls: true
  },
  outgoing: {
    host: 'newpinwheel.indowebsite.net', // Ganti dengan host SMTP yang benar
    port: 587, // Port SMTP biasanya 587 untuk TLS
    secure: false, // true untuk port 465, false untuk port lainnya
    auth: {
      user: 'nokosmerah@buatkamu.web.id',
      pass: 'Grki6Vv1gdlA'
    }
  }
};

// Inisialisasi Bot
const bot = new Telegraf(BOT_TOKEN);

// Inisialisasi Transport SMTP untuk mengirim email
const smtpTransporter = nodemailer.createTransporter(emailConfig.outgoing);

// Fungsi untuk memeriksa email masuk
function checkEmails() {
  const imap = new Imap({
    user: emailConfig.incoming.user,
    password: emailConfig.incoming.password,
    host: emailConfig.incoming.host,
    port: emailConfig.incoming.port,
    tls: emailConfig.incoming.tls,
    tlsOptions: { rejectUnauthorized: false }
  });

  imap.once('ready', () => {
    imap.openBox('INBOX', false, (err, box) => {
      if (err) throw err;
      
      imap.search(['UNSEEN'], (err, results) => {
        if (err) throw err;
        
        if (!results || results.length === 0) {
          imap.end();
          return;
        }
        
        const fetch = imap.fetch(results, { bodies: '' });
        fetch.on('message', (msg) => {
          msg.on('body', (stream) => {
            simpleParser(stream, async (err, parsed) => {
              if (err) throw err;
              
              // Kirim notifikasi ke grup yang diizinkan
              const message = `📧 Email Baru\n\nDari: ${parsed.from.text}\nJudul: ${parsed.subject}\n\n${parsed.text?.substring(0, 200)}...`;
              
              try {
                await bot.telegram.sendMessage(ALLOWED_GROUP_ID, message);
              } catch (error) {
                console.error('Gagal mengirim notifikasi email:', error);
              }
            });
          });
        });
        
        fetch.once('end', () => {
          imap.end();
        });
      });
    });
  });

  imap.once('error', (err) => {
    console.error('Koneksi IMAP error:', err);
  });

  imap.connect();
}

// Periksa email setiap 1 menit
cron.schedule('* * * * *', () => {
  checkEmails();
});

// Command handler untuk mengirim email
bot.command('kirimemail', async (ctx) => {
  // Periksa apakah pesan berasal dari grup yang diizinkan
  if (ctx.chat.id.toString() !== ALLOWED_GROUP_ID) {
    await ctx.reply('Maaf, bot ini hanya dapat digunakan di grup tertentu.');
    return;
  }

  const messageParts = ctx.message.text.split(' ');
  if (messageParts.length < 4) {
    await ctx.reply('Format: /kirimemail [alamat_email_tujuan] [subjek] [pesan]');
    return;
  }

  const toEmail = messageParts[1];
  const subject = messageParts[2];
  const message = messageParts.slice(3).join(' ');

  try {
    const mailOptions = {
      from: emailConfig.outgoing.auth.user,
      to: toEmail,
      subject: subject,
      text: message
    };

    await smtpTransporter.sendMail(mailOptions);
    await ctx.reply(`Email berhasil dikirim ke ${toEmail}`);
  } catch (error) {
    console.error('Error mengirim email:', error);
    await ctx.reply('Gagal mengirim email. Silakan coba lagi.');
  }
});

// Handler ketika bot ditambahkan ke grup
bot.on('chat_member', async (ctx) => {
  const chatMember = ctx.chatMember;
  const chatId = ctx.chat.id.toString();
  
  // Jika bot ditambahkan ke grup yang tidak diizinkan
  if (chatMember.new_chat_member.status === 'member' && 
      chatMember.new_chat_member.user.id === ctx.botInfo.id &&
      chatId !== ALLOWED_GROUP_ID) {
    
    try {
      await ctx.leaveChat();
    } catch (error) {
      console.error('Gagal keluar dari grup:', error);
    }
  }
});

// Handler untuk pesan di grup yang tidak diizinkan
bot.on('message', async (ctx) => {
  const chatId = ctx.chat.id.toString();
  
  if (chatId !== ALLOWED_GROUP_ID && ctx.chat.type !== 'private') {
    try {
      await ctx.reply('Maaf, bot ini hanya dapat digunakan di grup tertentu.');
      await ctx.leaveChat();
    } catch (error) {
      console.error('Gagal merespons atau keluar dari grup:', error);
    }
  }
});

// Start bot
bot.launch().then(() => {
  console.log('Bot berhasil dijalankan');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));