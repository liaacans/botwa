Script Awal : Simple Bot V5
=========================================================================

  #- Credits By Fahri - OfficiaL
   Contact: https://6287786336665
   Youtube: https://youtube.com/@Fahriofficial
   Telegram: https://t.me/Fahriofficial
    
  Developer : https://wa.me/6287786336665

=========================================================================


Apa yang diubah dari sc simple bot v5 ? 
• Fix yang erorr
• add fitur 

#- Modify By Biyu Offc 
[ https://6285776461481 ]
[ https://youtube.com/@BiyuOffc ]
[ https://t.me/BiyuOffc ]
|== Jajgan Dihapus Credits dan Modify ==|

#Respect