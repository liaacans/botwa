const { Markup } = require('telegraf');
const moment = require('moment-timezone');
const path = require('path');
const fs = require('fs-extra');
const fetch = require('node-fetch');
const JsConfuser = require('js-confuser');

const { 
  addUser, 
  addGroup, 
  deactivateGroup, 
  addPremium, 
  removePremium, 
  isPremium, 
  addBlacklist, 
  removeBlacklist, 
  isBlacklisted,
  users,
  groups,
  premiumUsers,
  blacklist
} = require('../lib/database');

const { 
  updateProgress, 
  runtime, 
  log 
} = require('../lib/utils');

const {
  obfuscateTimeLocked,
  obfuscateQuantum,
  getSiuCalcrickObfuscationConfig,
  getCustomObfuscationConfig,
  getNebulaObfuscationConfig,
  getNovaObfuscationConfig,
  getStrongObfuscationConfig,
  getArabObfuscationConfig,
  getJapanxArabObfuscationConfig,
  getJapanObfuscationConfig
} = require('./obf');

const { DEVELOPER_ID, DEVELOPER_USERNAME } = require('../config');

// Fungsi untuk menangani command start
function handleStart(ctx) {
  addUser(ctx.from.id);
  
  const isCreator = ctx.from.id.toString() === DEVELOPER_ID;
  const username = ctx.from.username ? `@${ctx.from.username}` : 'Tidak ada';
  const sender = ctx.from.first_name || 'Tidak ada';
  
  const message = `
╭─❒ 「 User Info 」 
├ Creator : ${DEVELOPER_USERNAME}
├ Name : ${username}
├ Profile : ${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreator ? 'True' : 'False'}

Silahkan pilih button dibawah ini!`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('Jasher Menu', 'jasher_menu')],
    [Markup.button.callback('Obf Menu', 'obf_menu')],
    [Markup.button.callback('Owner', 'owner_menu')]
  ]);

  ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
    caption: message,
    parse_mode: 'Markdown',
    ...keyboard
  });
}

// Fungsi untuk menangani callback queries
function handleCallbackQuery(ctx) {
  const data = ctx.callbackQuery.data;
  const userId = ctx.from.id;
  const isCreator = userId.toString() === DEVELOPER_ID;
  
  switch (data) {
    case 'jasher_menu':
      const jasherKeyboard = Markup.inlineKeyboard([
        [Markup.button.callback('Share Free', 'share_free')],
        [Markup.button.callback('Share VIP', 'share_vip')],
        [Markup.button.callback('Kembali', 'main_menu')]
      ]);
      
      ctx.editMessageCaption('╭─❒ 「 Jasher Menu 」\n├ Pilih opsi share:\n╰❒ Hanya bekerja di private chat', {
        parse_mode: 'Markdown',
        ...jasherKeyboard
      });
      break;
      
    case 'obf_menu':
      const obfKeyboard = Markup.inlineKeyboard([
        [Markup.button.callback('Encrypt Time-Locked', 'enc_time_locked')],
        [Markup.button.callback('Encrypt Quantum', 'enc_quantum')],
        [Markup.button.callback('Encrypt Custom', 'enc_custom')],
        [Markup.button.callback('Encrypt Strong', 'enc_strong')],
        [Markup.button.callback('Encrypt Arab', 'enc_arab')],
        [Markup.button.callback('Encrypt Japan', 'enc_japan')],
        [Markup.button.callback('Kembali', 'main_menu')]
      ]);
      
      ctx.editMessageCaption('╭─❒ 「 Obfuscation Menu 」\n├ Pilih jenis encrypt:\n╰❒ Balas file JS dengan command', {
        parse_mode: 'Markdown',
        ...obfKeyboard
      });
      break;
      
    case 'owner_menu':
      if (!isCreator) {
        ctx.answerCbQuery('Hanya owner yang bisa mengakses menu ini!');
        return;
      }
      
      const ownerKeyboard = Markup.inlineKeyboard([
        [Markup.button.callback('Add Premium', 'add_premium'), Markup.button.callback('Del Premium', 'del_premium')],
        [Markup.button.callback('List Premium', 'list_premium'), Markup.button.callback('Broadcast', 'broadcast')],
        [Markup.button.callback('Add Blacklist', 'add_blacklist'), Markup.button.callback('Del Blacklist', 'del_blacklist')],
        [Markup.button.callback('List Groups', 'list_groups'), Markup.button.callback('Hapus Group', 'remove_group')],
        [Markup.button.callback('Kembali', 'main_menu')]
      ]);
      
      ctx.editMessageCaption('╭─❒ 「 Owner Menu 」\n├ Pilih opsi admin:\n╰❒ Hanya untuk owner', {
        parse_mode: 'Markdown',
        ...ownerKeyboard
      });
      break;
      
    case 'main_menu':
      handleStart(ctx);
      break;
      
    case 'share_free':
      if (ctx.chat.type !== 'private') {
        ctx.answerCbQuery('Command ini hanya bekerja di private chat!');
        return;
      }
      ctx.reply('Fitur Share Free: Kirim pesan yang ingin dishare secara free');
      break;
      
    case 'share_vip':
      if (ctx.chat.type !== 'private') {
        ctx.answerCbQuery('Command ini hanya bekerja di private chat!');
        return;
      }
      if (!isPremium(userId)) {
        ctx.reply('Anda bukan user premium! Silahkan upgrade untuk menggunakan fitur VIP.');
        return;
      }
      ctx.reply('Fitur Share VIP: Kirim pesan yang ingin dishare secara VIP');
      break;
      
    // Handler untuk menu owner
    case 'add_premium':
      if (!isCreator) {
        ctx.answerCbQuery('Akses ditolak!');
        return;
      }
      ctx.reply('Balas pesan user dengan /addprem <jumlah_hari>');
      break;
      
    case 'del_premium':
      if (!isCreator) {
        ctx.answerCbQuery('Akses ditolak!');
        return;
      }
      ctx.reply('Balas pesan user dengan /delprem');
      break;
      
    case 'list_premium':
      if (!isCreator) {
        ctx.answerCbQuery('Akses ditolak!');
        return;
      }
      const premiumList = premiumUsers.map(u => `- User ID: ${u.id} (Expiry: ${moment(u.expiry).format('DD/MM/YYYY')})`).join('\n');
      ctx.reply(`Daftar User Premium:\n${premiumList || 'Tidak ada user premium'}`);
      break;
      
    case 'broadcast':
      if (!isCreator) {
        ctx.answerCbQuery('Akses ditolak!');
        return;
      }
      ctx.reply('Balas pesan dengan /bc <pesan> untuk broadcast ke semua user');
      break;
      
    case 'add_blacklist':
      if (!isCreator) {
        ctx.answerCbQuery('Akses ditolak!');
        return;
      }
      ctx.reply('Balas pesan dengan /addbl untuk menambah group ke blacklist');
      break;
      
    case 'del_blacklist':
      if (!isCreator) {
        ctx.answerCbQuery('Akses ditolak!');
        return;
      }
      ctx.reply('Balas pesan dengan /delbl untuk menghapus group dari blacklist');
      break;
      
    case 'list_groups':
      if (!isCreator) {
        ctx.answerCbQuery('Akses ditolak!');
        return;
      }
      const groupList = groups.map(g => `- ${g.name} (ID: ${g.id}) ${g.active ? '🟢' : '🔴'}`).join('\n');
      ctx.reply(`Daftar Group:\n${groupList || 'Tidak ada group'}`);
      break;
      
    case 'remove_group':
      if (!isCreator) {
        ctx.answerCbQuery('Akses ditolak!');
        return;
      }
      ctx.reply('Balas pesan dengan /hapusgb untuk menghapus group');
      break;
      
    default:
      ctx.answerCbQuery('Menu tidak dikenali!');
  }
  
  ctx.answerCbQuery();
}

// Fungsi untuk menangani command obfuscation
async function handleObfCommand(ctx, command) {
  addUser(ctx.from.id);
  
  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.replyWithMarkdown('❌ *Error:* Balas file .js dengan command ini!');
  }

  const file = ctx.message.reply_to_message.document;
  if (!file.file_name.endsWith('.js')) {
    return ctx.replyWithMarkdown('❌ *Error:* Hanya file .js yang didukung!');
  }

  let encryptedPath, configFunction, commandName;
  
  switch (command) {
    case 'enc3':
      encryptedPath = path.join(__dirname, '..', 'temp', `china-encrypted-${file.file_name}`);
      configFunction = getCustomObfuscationConfig('china');
      commandName = 'Hardened Mandarin';
      break;
    case 'enc4':
      encryptedPath = path.join(__dirname, '..', 'temp', `arab-encrypted-${file.file_name}`);
      configFunction = getArabObfuscationConfig;
      commandName = 'Hardened Arab';
      break;
    case 'japan':
      encryptedPath = path.join(__dirname, '..', 'temp', `japan-encrypted-${file.file_name}`);
      configFunction = getJapanObfuscationConfig;
      commandName = 'Hardened Japan';
      break;
    case 'zenc':
      encryptedPath = path.join(__dirname, '..', 'temp', `invisible-encrypted-${file.file_name}`);
      configFunction = getStrongObfuscationConfig;
      commandName = 'Invisible';
      break;
    case 'nebula':
      encryptedPath = path.join(__dirname, '..', 'temp', `nebula-encrypted-${file.file_name}`);
      configFunction = getNebulaObfuscationConfig;
      commandName = 'Nebula Polymorphic Storm';
      break;
    case 'enc5':
      encryptedPath = path.join(__dirname, '..', 'temp', `siucalcrick-encrypted-${file.file_name}`);
      configFunction = getSiuCalcrickObfuscationConfig;
      commandName = 'Calcrick Chaos Core';
      break;
    case 'var':
      encryptedPath = path.join(__dirname, '..', 'temp', `var-encrypted-${file.file_name}`);
      configFunction = getNovaObfuscationConfig;
      commandName = 'Var';
      break;
    case 'quantum':
      encryptedPath = path.join(__dirname, '..', 'temp', `quantum-encrypted-${file.file_name}`);
      commandName = 'Quantum Vortex Encryption';
      break;
    case 'enc':
      const args = ctx.message.text.split(' ').slice(1);
      if (args.length !== 1 || !/^\d+$/.test(args[0]) || parseInt(args[0]) < 1 || parseInt(args[0]) > 365) {
        return ctx.replyWithMarkdown('❌ *Error:* Gunakan format `/enc [1-365]` untuk jumlah hari!');
      }
      encryptedPath = path.join(__dirname, '..', 'temp', `locked-encrypted-${file.file_name}`);
      commandName = 'Time-Locked Encryption';
      break;
    default:
      return ctx.replyWithMarkdown('❌ *Error:* Command tidak dikenali!');
  }

  try {
    const progressMessage = await ctx.replyWithMarkdown(
      "```css\n" +
      "🔒 JasherBot\n" +
      ` ⚙️ Memulai (${commandName}) (1%)\n` +
      ` ${createProgressBar(1)}\n` +
      "```\n" +
      "PROSES ENCRYPT "
    );

    const fileLink = await ctx.telegram.getFileLink(file.file_id);
    log(`Mengunduh file untuk ${commandName}: ${file.file_name}`);
    await updateProgress(ctx, progressMessage, 10, "Mengunduh");
    const response = await fetch(fileLink);
    let fileContent = await response.text();
    await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

    log(`Memvalidasi kode: ${file.file_name}`);
    await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
    try {
      new Function(fileContent);
    } catch (syntaxError) {
      throw new Error(`Kode tidak valid: ${syntaxError.message}`);
    }

    log(`Mengenkripsi file dengan ${commandName}`);
    await updateProgress(ctx, progressMessage, 40, `Inisialisasi ${commandName}`);
    
    let obfuscatedCode;
    if (command === 'quantum') {
      obfuscatedCode = await obfuscateQuantum(fileContent);
    } else if (command === 'enc') {
      const days = ctx.message.text.split(' ')[1];
      obfuscatedCode = await obfuscateTimeLocked(fileContent, days);
    } else {
      const obfuscated = await JsConfuser.obfuscate(fileContent, configFunction());
      obfuscatedCode = obfuscated.code || obfuscated;
    }
    
    await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
    await fs.ensureDir(path.dirname(encryptedPath));
    await fs.writeFile(encryptedPath, obfuscatedCode);
    await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

    log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
    try {
      new Function(obfuscatedCode);
    } catch (postObfuscationError) {
      throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
    }

    log(`Mengirim file terenkripsi: ${file.file_name}`);
    await ctx.replyWithDocument(
      { source: encryptedPath, filename: `${command.toLowerCase()}-encrypted-${file.file_name}` },
      {
        caption: `✅ *File terenkripsi (${commandName}) siap!*\nSUKSES ENCRYPT 🕊`,
        parse_mode: "Markdown",
      }
    );
    await updateProgress(ctx, progressMessage, 100, `${commandName} Selesai`);

    if (await fs.pathExists(encryptedPath)) {
      await fs.unlink(encryptedPath);
      log(`File sementara dihapus: ${encryptedPath}`);
    }
  } catch (error) {
    log(`Kesalahan saat ${commandName} obfuscation`, error);
    await ctx.replyWithMarkdown(
      `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
    );
    if (encryptedPath && await fs.pathExists(encryptedPath)) {
      await fs.unlink(encryptedPath);
      log(`File sementara dihapus setelah error: ${encryptedPath}`);
    }
  }
}

module.exports = {
  handleStart,
  handleCallbackQuery,
  handleObfCommand
};