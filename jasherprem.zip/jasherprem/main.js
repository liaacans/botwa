require('./config');
const { Telegraf, session } = require('telegraf');
const { message } = require('telegraf/filters');
const commandHandler = require('./src/commands');
const messageHandler = require('./src/handlers');

const bot = new Telegraf(BOT_TOKEN);

// Session middleware
bot.use(session());

// Command handlers
bot.command('start', commandHandler.start);
bot.command('menu', commandHandler.menu);
bot.command('owner', commandHandler.owner);
bot.command('addprem', commandHandler.addPrem);
bot.command('delprem', commandHandler.delPrem);
bot.command('listprem', commandHandler.listPrem);
bot.command('addbl', commandHandler.addBl);
bot.command('delbl', commandHandler.delBl);
bot.command('listbl', commandHandler.listBl);
bot.command('autojasher', commandHandler.autoJasher);
bot.command('stopautojasher', commandHandler.stopAutoJasher);
bot.command('listgrup', commandHandler.listGrup);
bot.command('tourl', commandHandler.toUrl);
bot.command('sharevip', commandHandler.shareVip);
bot.command('enclocked', commandHandler.enclocked);
bot.command('quantum', commandHandler.quantum);
bot.command('siucalcrick', commandHandler.siuCalcrick);
bot.command('custom', commandHandler.custom);
bot.command('nebula', commandHandler.nebula);
bot.command('nova', commandHandler.nova);
bot.command('strong', commandHandler.strong);
bot.command('arab', commandHandler.arab);
bot.command('japanxarab', commandHandler.japanxArab);
bot.command('japan', commandHandler.japan);

// Message handlers
bot.on(message('text'), messageHandler.text);
bot.on(message('photo'), messageHandler.photo);

// Handle new chat members (bot added to group)
bot.on('chat_member', async (ctx) => {
  if (ctx.chatMember.new_chat_member.status === 'member' && 
      ctx.chatMember.new_chat_member.user.id === ctx.botInfo.id) {
    // Bot added to a group
    const groupId = ctx.chat.id;
    const groupName = ctx.chat.title || `Group-${groupId}`;
    
    // Add group to database
    await db.addGroup(groupId, groupName, ctx.from.id);
    
    // Send welcome message
    await ctx.reply(`Terima kasih telah menambahkan saya ke grup ${groupName}!`);
  }
});

// Error handling
bot.catch((err, ctx) => {
  console.error(`Error for ${ctx.updateType}:`, err);
  ctx.reply('Terjadi kesalahan pada bot. Silakan coba lagi nanti.');
});

// Start bot
bot.launch().then(() => {
  console.log('Bot Jasher started successfully!');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));