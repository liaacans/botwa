const moment = require('moment-timezone');

// Format runtime
function runtime(seconds) {
    seconds = Math.floor(seconds);
    const days = Math.floor(seconds / (3600 * 24));
    seconds %= 3600 * 24;
    const hours = Math.floor(seconds / 3600);
    seconds %= 3600;
    const minutes = Math.floor(seconds / 60);
    seconds %= 60;
    
    return `${days}d ${hours}h ${minutes}m ${seconds}s`;
}

// Parse mode untuk telegraf
function escapeMarkdown(text) {
    return text.replace(/([_[\]()~`>#+\-=|{}.!])/g, '\\$1');
}

module.exports = { runtime, escapeMarkdown, moment };