const { Telegraf } = require('telegraf');
const nodemailer = require('nodemailer');
const Imap = require('imap');
const { simpleParser } = require('mailparser');
const cron = require('node-cron');
const { inspect } = require('util');

// Konfigurasi Bot Telegram
const BOT_TOKEN = '7569137877:AAHnvva5p9SFclkDpDio8QcJsSfbzlrK6IY';
const ALLOWED_GROUP_ID = '-1002793801544';

// Konfigurasi Email
const emailConfig = {
  incoming: {
    host: 'newpinwheel.indowebsite.net',
    port: 993,
    user: 'nokosmerah@buatkamu.web.id',
    password: 'Grki6Vv1gdlA',
    tls: true,
    authTimeout: 10000
  },
  outgoing: {
    host: 'newpinwheel.indowebsite.net',
    port: 587,
    secure: false,
    auth: {
      user: 'nokosmerah@buatkamu.web.id',
      pass: 'Grki6Vv1gdlA'
    },
    tls: {
      rejectUnauthorized: false
    }
  }
};

// Inisialisasi Bot
const bot = new Telegraf(BOT_TOKEN);

// Inisialisasi Transport SMTP untuk mengirim email
const smtpTransporter = nodemailer.createTransport(emailConfig.outgoing);

// Verifikasi koneksi SMTP
smtpTransporter.verify((error, success) => {
  if (error) {
    console.log('Koneksi SMTP gagal:', error);
  } else {
    console.log('Server SMTP siap mengirim pesan');
  }
});

// Variabel untuk menyimpan UID terakhir yang diproses
let lastProcessedUID = 0;

// Fungsi untuk memeriksa email masuk terbaru
function checkNewEmails() {
  console.log('Memeriksa email masuk terbaru...');
  
  const imap = new Imap({
    user: emailConfig.incoming.user,
    password: emailConfig.incoming.password,
    host: emailConfig.incoming.host,
    port: emailConfig.incoming.port,
    tls: emailConfig.incoming.tls,
    tlsOptions: { rejectUnauthorized: false },
    authTimeout: 10000
  });

  imap.once('ready', () => {
    console.log('Terhubung ke server IMAP');
    
    imap.openBox('INBOX', true, (err, box) => {
      if (err) {
        console.error('Gagal membuka kotak masuk:', err);
        imap.end();
        return;
      }
      
      // Cari semua email yang belum diproses (UID lebih besar dari yang terakhir diproses)
      const searchCriteria = lastProcessedUID > 0 ? ['UID', `${lastProcessedUID + 1}:*`] : ['ALL'];
      
      imap.search(searchCriteria, (err, results) => {
        if (err) {
          console.error('Gagal mencari email:', err);
          imap.end();
          return;
        }
        
        if (!results || results.length === 0) {
          console.log('Tidak ada email baru');
          imap.end();
          return;
        }
        
        console.log(`Ditemukan ${results.length} email baru`);
        
        // Urutkan hasil untuk memproses dari yang terlama ke terbaru
        results.sort((a, b) => a - b);
        
        const fetch = imap.fetch(results, { 
          bodies: '',
          markSeen: false // Jangan tandai sebagai sudah dibaca
        });
        
        fetch.on('message', (msg, seqno) => {
          let buffer = '';
          let uid = null;
          
          msg.on('attributes', (attrs) => {
            uid = attrs.uid;
            console.log(`Memproses email UID: ${uid}`);
          });
          
          msg.on('body', (stream) => {
            stream.on('data', (chunk) => {
              buffer += chunk.toString('utf8');
            });
            
            stream.once('end', async () => {
              try {
                const parsed = await simpleParser(buffer);
                
                // Update UID terakhir yang diproses
                if (uid && uid > lastProcessedUID) {
                  lastProcessedUID = uid;
                }
                
                // Kirim notifikasi ke grup yang diizinkan
                const message = `📧 Email Baru\n\nDari: ${parsed.from.text}\nKepada: ${parsed.to.text}\nJudul: ${parsed.subject || '(Tidak ada judul)'}\nTanggal: ${parsed.date}\n\n${parsed.text?.substring(0, 300) || 'Tidak ada konten teks'}...`;
                
                try {
                  await bot.telegram.sendMessage(ALLOWED_GROUP_ID, message);
                  console.log('Notifikasi email terkirim ke Telegram');
                  
                  // Jika email memiliki lampiran, beri tahu
                  if (parsed.attachments && parsed.attachments.length > 0) {
                    await bot.telegram.sendMessage(ALLOWED_GROUP_ID, `📎 Email ini memiliki ${parsed.attachments.length} lampiran`);
                  }
                } catch (error) {
                  console.error('Gagal mengirim notifikasi email:', error);
                }
              } catch (parseError) {
                console.error('Gagal parsing email:', parseError);
              }
            });
          });
        });
        
        fetch.once('end', () => {
          console.log('Pemeriksaan email selesai. UID terakhir:', lastProcessedUID);
          imap.end();
        });
        
        fetch.once('error', (err) => {
          console.error('Error saat fetch email:', err);
          imap.end();
        });
      });
    });
  });

  imap.once('error', (err) => {
    console.error('Koneksi IMAP error:', err);
  });

  imap.once('end', () => {
    console.log('Koneksi IMAP ditutup');
  });

  imap.connect();
}

// Fungsi untuk mendapatkan UID tertinggi saat ini (saat bot pertama kali dijalankan)
function getHighestUID() {
  console.log('Mendapatkan UID tertinggi saat ini...');
  
  const imap = new Imap({
    user: emailConfig.incoming.user,
    password: emailConfig.incoming.password,
    host: emailConfig.incoming.host,
    port: emailConfig.incoming.port,
    tls: emailConfig.incoming.tls,
    tlsOptions: { rejectUnauthorized: false },
    authTimeout: 10000
  });

  imap.once('ready', () => {
    imap.openBox('INBOX', true, (err, box) => {
      if (err) {
        console.error('Gagal membuka kotak masuk:', err);
        imap.end();
        return;
      }
      
      // Cari email dengan UID tertinggi
      imap.search(['ALL'], (err, results) => {
        if (err) {
          console.error('Gagal mencari email:', err);
          imap.end();
          return;
        }
        
        if (results && results.length > 0) {
          // Urutkan descending dan ambil UID tertinggi
          results.sort((a, b) => b - a);
          lastProcessedUID = results[0];
          console.log('UID tertinggi saat ini:', lastProcessedUID);
        }
        
        imap.end();
      });
    });
  });

  imap.once('error', (err) => {
    console.error('Koneksi IMAP error:', err);
  });

  imap.connect();
}

// Periksa email baru setiap 3 menit
cron.schedule('*/1 * * * *', () => {
  checkNewEmails();
});

// Command handler untuk mengirim email
bot.command('kirimemail', async (ctx) => {
  if (ctx.chat.id.toString() !== ALLOWED_GROUP_ID) {
    await ctx.reply('Maaf, bot ini hanya dapat digunakan di grup tertentu.');
    return;
  }

  const messageText = ctx.message.text;
  const commandParts = messageText.split(' ');
  
  if (commandParts.length < 4) {
    await ctx.reply('Format: /kirimemail [alamat_email_tujuan] [subjek] [pesan]');
    await ctx.reply('Contoh: /kirimemail recipient@example.com "Subjek Email" "Isi pesan email"');
    return;
  }

  const toEmail = commandParts[1];
  const subject = commandParts[2];
  const message = commandParts.slice(3).join(' ');

  try {
    const mailOptions = {
      from: emailConfig.outgoing.auth.user,
      to: toEmail,
      subject: subject,
      text: message
    };

    const info = await smtpTransporter.sendMail(mailOptions);
    console.log('Email terkirim:', info.messageId);
    await ctx.reply(`✅ Email berhasil dikirim ke ${toEmail}`);
  } catch (error) {
    console.error('Error mengirim email:', error);
    await ctx.reply('❌ Gagal mengirim email. Silakan coba lagi.');
  }
});

// Command untuk memeriksa email manual
bot.command('cekmail', async (ctx) => {
  if (ctx.chat.id.toString() !== ALLOWED_GROUP_ID) {
    return;
  }
  
  await ctx.reply('🔄 Memeriksa email masuk...');
  checkNewEmails();
});

// Command bantuan
bot.command('help', async (ctx) => {
  if (ctx.chat.id.toString() !== ALLOWED_GROUP_ID) {
    return;
  }
  
  const helpMessage = `
🤖 *Bot Email Telegram*

*Perintah yang tersedia:*
/kirimemail [email] [subjek] [pesan] - Kirim email
/cekmail - Periksa email masuk secara manual
/help - Tampilkan pesan bantuan ini

Bot akan secara otomatis memeriksa email masuk setiap 3 menit dan mengirimkan notifikasi ke grup ini.
  `;
  
  await ctx.replyWithMarkdown(helpMessage);
});

// Handler ketika bot ditambahkan ke grup
bot.on('chat_member', async (ctx) => {
  const chatMember = ctx.chatMember;
  
  if (chatMember.new_chat_member.user.id === ctx.botInfo.id && 
      chatMember.new_chat_member.status === 'member') {
    
    const chatId = ctx.chat.id.toString();
    
    if (chatId !== ALLOWED_GROUP_ID) {
      try {
        await ctx.reply('Maaf, bot ini hanya dapat digunakan di grup tertentu.');
        await ctx.leaveChat();
      } catch (error) {
        console.error('Gagal keluar dari grup:', error);
      }
    } else {
      await ctx.reply('Halo! Terima kasih telah menambahkan saya ke grup. Gunakan /help untuk melihat perintah yang tersedia.');
    }
  }
});

// Handler untuk pesan di grup yang tidak diizinkan
bot.on('message', async (ctx) => {
  if (ctx.chat.type === 'private') return;
  
  const chatId = ctx.chat.id.toString();
  
  if (chatId !== ALLOWED_GROUP_ID) {
    try {
      await ctx.reply('Maaf, bot ini hanya dapat digunakan di grup tertentu.');
      await ctx.leaveChat();
    } catch (error) {
      console.error('Gagal merespons atau keluar dari grup:', error);
    }
  }
});

// Start bot
bot.launch().then(() => {
  console.log('Bot berhasil dijalankan');
  // Dapatkan UID tertinggi saat ini saat bot mulai
  getHighestUID();
  // Periksa email setelah 10 detik (memberi waktu untuk mendapatkan UID tertinggi)
  setTimeout(() => checkNewEmails(), 10000);
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));