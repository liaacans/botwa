const { Telegraf, session } = require('telegraf');
const config = require('./config');
const bot = require('./src/commands');
const { setupCallbackHandlers } = require('./src/handlers');
const { loadUsers, saveUsers, loadGroups } = require('./lib/database');
const { log } = require('./lib/utils');

// Load data
let users = new Set(Object.keys(loadUsers()));
let groups = loadGroups();

// Setup callback handlers
setupCallbackHandlers(bot);

// Error handling
bot.catch((err, ctx) => {
    log('Error occurred:', err);
    ctx.reply('❌ Terjadi kesalahan saat memproses permintaan Anda.');
});

// Start bot
bot.launch().then(() => {
    log('Bot Jasher Premium started successfully!');
}).catch(err => {
    log('Error starting bot:', err);
});

// Enable graceful stop
process.once('SIGINT', () => {
    bot.stop('SIGINT');
    // Save data before exit
    saveUsers(users);
    process.exit(0);
});

process.once('SIGTERM', () => {
    bot.stop('SIGTERM');
    // Save data before exit
    saveUsers(users);
    process.exit(0);
});