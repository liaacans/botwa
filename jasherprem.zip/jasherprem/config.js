global.BOT_TOKEN = "8198305874:AAHk3rqCM_-0kYlDvKoAuCaX3Yyi4lZQTKc";
global.OWNER_ID = "8135269613";

// Database configuration
global.db = {
    users: new Map(),
    groups: new Map(),
    premium: new Map(),
    blacklist: new Set(),
    settings: new Map()
};

// Export untuk digunakan di file lain
module.exports = {
    BOT_TOKEN: global.BOT_TOKEN,
    OWNER_ID: global.OWNER_ID,
    db: global.db
};