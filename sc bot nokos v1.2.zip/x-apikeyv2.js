const axios = require('axios');
const config = require('./config');

class CashifyService {
  constructor() {
    this.apiKey = config.cashify_apikey; 
    this.webhookSecret = config.cashify_webhook; 
    this.qrId = config.cashify_qr_id;
    this.fixedFee = 150;
  }

  async createDeposit(reffId, nominal) {
    try {
      const amountWithFee = nominal + this.fixedFee;
      
      const requestBody = {
        qr_id: this.qrId,
        amount: amountWithFee, 
        useUniqueCode: true,
        packageIds: ["id.dana"],
        expiredInMinutes: 20,
        qrType: "dynamic",
        paymentMethod: "qris",
        useQris: true
      };

      const response = await axios.post('https://cashify.my.id/api/generate/v2/qris', 
        requestBody, 
        {
          headers: {
            'x-license-key': this.apiKey,
            'content-type': 'application/json'
          },
          timeout: 30000
        }
      );

      if (response.data.status === 200) {
        
        return {
          success: true,
          data: {
            id: response.data.data.transactionId,
            qr_string: response.data.data.qr_string,
            total: amountWithFee, 
            diterima: nominal, 
            fee: this.fixedFee,
            method: 'QRIS',
            status: 'pending',
            qr_string_full: response.data.data.qr_string
          }
        };
      } else {
        return {
          success: false,
          message: response.data.message || 'Gagal membuat deposit'
        };
      }
    } catch (error) {
      return { 
        success: false, 
        message: error.response?.data?.message || error.message || 'Network error'
      };
    }
  }

  async checkDepositStatus(depositId) {
    try {
      const response = await axios.post('https://cashify.my.id/api/generate/check-status', 
        { transactionId: depositId },
        {
          headers: {
            'x-license-key': this.apiKey,
            'content-type': 'application/json'
          },
          timeout: 15000
        }
      );

      if (response.data.status === 200) {
        const status = response.data.data.status;
        let mappedStatus = 'pending';
        
        if (status === 'paid') mappedStatus = 'success';
        if (status === 'cancel' || status === 'expired') mappedStatus = status;
        
        const amountPaid = response.data.data.amount || 0;
        const originalNominal = amountPaid - this.fixedFee;
        
        return {
          success: true,
          data: {
            id: depositId,
            status: mappedStatus,
            total: amountPaid, 
            diterima: originalNominal > 0 ? originalNominal : 0, 
            fee: this.fixedFee,
            method: 'QRIS',
            raw_status: status,
            amount_paid: amountPaid
          }
        };
      } else {
        return {
          success: false,
          message: response.data.message || 'Status tidak ditemukan'
        };
      }
    } catch (error) {
      return { 
        success: false, 
        message: error.response?.data?.message || error.message 
      };
    }
  }

  async cancelDeposit(depositId) {
    try {
      const response = await axios.post('https://cashify.my.id/api/generate/cancel-status', 
        { transactionId: depositId },
        {
          headers: {
            'x-license-key': this.apiKey,
            'content-type': 'application/json'
          },
          timeout: 15000
        }
      );

      if (response.data.status === 200) {
        return {
          success: true,
          message: 'Deposit berhasil dibatalkan',
          data: {
            id: depositId,
            status: 'cancel'
          }
        };
      } else {
        return {
          success: false,
          message: response.data.message || 'Gagal membatalkan deposit'
        };
      }
    } catch (error) {
      return { 
        success: false, 
        message: error.response?.data?.message || error.message 
      };
    }
  }
}

module.exports = CashifyService;