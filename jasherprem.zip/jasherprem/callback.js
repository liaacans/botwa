// callback.js
const express = require('express');
const { handlePaymentCallback } = require('./src/paymentHandler');
const router = express.Router();

router.post('/callback', async (req, res) => {
  try {
    const callbackData = req.body;
    
    // Proses callback
    const result = await handlePaymentCallback(callbackData);
    
    if (result.success) {
      res.status(200).json({ status: 'success', message: 'Callback processed successfully' });
    } else {
      res.status(400).json({ status: 'error', message: result.message });
    }
  } catch (error) {
    console.error('Error processing callback:', error);
    res.status(500).json({ status: 'error', message: 'Internal server error' });
  }
});

module.exports = router;