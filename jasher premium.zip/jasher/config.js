global.BOT_TOKEN = process.env.BOT_TOKEN || 'YOUR_BOT_TOKEN_HERE';
global.OWNER_ID = process.env.OWNER_ID || 'YOUR_OWNER_ID_HERE';

module.exports = {
    BOT_TOKEN: global.BOT_TOKEN,
    OWNER_ID: global.OWNER_ID,
    CREDITS: {
        ADD_GROUP_REWARD: 10,
        SHARE_COST: 2
    }
};