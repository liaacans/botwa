const { isPremium, isOwner, log } = require('../../lib/utils');
const { isBlacklisted, getUser } = require('../../lib/database');

module.exports = (bot) => {
    // Middleware untuk authentication dan authorization
    bot.use(async (ctx, next) => {
        // Skip jika tidak ada user info
        if (!ctx.from) {
            return next();
        }

        const userId = ctx.from.id;
        const chatType = ctx.chat?.type || 'unknown';

        // Log activity
        log(`Activity: ${ctx.from.first_name} (${userId}) in ${chatType} - ${ctx.message?.text?.substring(0, 50) || 'non-text message'}`);

        // Check blacklist
        if (isBlacklisted(userId)) {
            if (chatType === 'private') {
                await ctx.reply(
                    '❌ *Anda telah diblacklist!*\n\n' +
                    'Anda tidak dapat menggunakan bot ini.\n' +
                    'Hubungi owner jika ini adalah kesalahan.',
                    { parse_mode: 'Markdown' }
                );
            }
            log(`Blacklisted user attempted access: ${ctx.from.first_name} (${userId})`);
            return;
        }

        // Add user to database jika belum ada
        const user = getUser(userId);
        if (!user) {
            const { addUser } = require('../../lib/database');
            addUser(userId, {
                username: ctx.from.username,
                first_name: ctx.from.first_name,
                last_name: ctx.from.last_name,
                language_code: ctx.from.language_code
            });
        }

        // Attach user info to context
        ctx.user = getUser(userId);
        ctx.isPremium = isPremium(userId);
        ctx.isOwner = isOwner(userId);

        // Rate limiting untuk commands
        await rateLimitMiddleware(ctx, next);
    });

    // Middleware untuk premium features
    bot.use(async (ctx, next) => {
        const premiumCommands = ['quantum', 'zenc', 'nebula', 'var', 'japan', 'enc3', 'enc4', 'enc5', 'enc2', 'xx', 'deobfuscate'];
        const command = ctx.message?.text?.split(' ')[0]?.replace('/', '');

        if (premiumCommands.includes(command)) {
            if (!ctx.isPremium && !ctx.isOwner) {
                await ctx.reply(
                    '❌ *Fitur Premium!*\n\n' +
                    'Anda perlu akun premium untuk menggunakan fitur ini.\n\n' +
                    '💎 *Cara mendapatkan premium:*\n' +
                    '1. Tambah bot ke 3 group (gratis 3 hari)\n' +
                    '2. Beli premium 30 hari: /menu\n\n' +
                    '⭐ Status Anda: Non-Premium',
                    { parse_mode: 'Markdown' }
                );
                return;
            }
        }

        await next();
    });

    // Middleware untuk owner-only commands
    bot.use(async (ctx, next) => {
        const ownerCommands = ['addprem', 'delprem', 'listprem', 'addbl', 'delbl', 'listbl', 'listgroups', 'cleangroups', 'broadcast'];
        const command = ctx.message?.text?.split(' ')[0]?.replace('/', '');

        if (ownerCommands.includes(command)) {
            if (!ctx.isOwner) {
                await ctx.reply(
                    '❌ *Akses Ditolak!*\n\n' +
                    'Hanya owner bot yang dapat menggunakan command ini.',
                    { parse_mode: 'Markdown' }
                );
                return;
            }
        }

        await next();
    });

    // Middleware untuk group-only commands
    bot.use(async (ctx, next) => {
        const groupCommands = ['addgroup', 'antispam', 'noevent', 'nolinks', 'noforwards', 'nocontacts', 'nohashtags', 'nocommands', 'groupinfo'];
        const command = ctx.message?.text?.split(' ')[0]?.replace('/', '');

        if (groupCommands.includes(command)) {
            if (ctx.chat?.type !== 'group' && ctx.chat?.type !== 'supergroup') {
                await ctx.reply(
                    '❌ *Command Group Only!*\n\n' +
                    'Command ini hanya dapat digunakan dalam group.',
                    { parse_mode: 'Markdown' }
                );
                return;
            }
        }

        await next();
    });

    // Middleware untuk private-only commands
    bot.use(async (ctx, next) => {
        const privateCommands = ['sharefree', 'sharevip'];
        const command = ctx.message?.text?.toLowerCase();

        if (privateCommands.includes(command)) {
            if (ctx.chat?.type !== 'private') {
                await ctx.reply(
                    '❌ *Command Private Only!*\n\n' +
                    'Command ini hanya dapat digunakan dalam private chat.',
                    { parse_mode: 'Markdown' }
                );
                return;
            }
        }

        await next();
    });
};

// Rate limiting function
async function rateLimitMiddleware(ctx, next) {
    const userId = ctx.from.id;
    const now = Date.now();
    const windowMs = 60000; // 1 minute window
    const maxRequests = 10; // Max 10 requests per minute

    // Initialize rate limit storage
    if (!global.rateLimit) {
        global.rateLimit = new Map();
    }

    if (!global.rateLimit.has(userId)) {
        global.rateLimit.set(userId, {
            count: 1,
            startTime: now
        });
    } else {
        const userLimit = global.rateLimit.get(userId);
        
        // Reset counter if window has passed
        if (now - userLimit.startTime > windowMs) {
            userLimit.count = 1;
            userLimit.startTime = now;
        } else {
            userLimit.count++;
            
            // Check if over limit
            if (userLimit.count > maxRequests) {
                const timeLeft = Math.ceil((userLimit.startTime + windowMs - now) / 1000);
                await ctx.reply(
                    `⏰ *Rate Limit Exceeded!*\n\n` +
                    `Anda telah mencapai batas request.\n` +
                    `Tunggu ${timeLeft} detik sebelum menggunakan command lagi.`,
                    { parse_mode: 'Markdown' }
                );
                return;
            }
        }
    }

    await next();
}

// Export middleware functions untuk digunakan di file lain
module.exports = {
    requirePremium: (ctx, next) => {
        if (!ctx.isPremium && !ctx.isOwner) {
            ctx.reply('❌ Fitur ini membutuhkan akun premium!');
            return;
        }
        next();
    },

    requireOwner: (ctx, next) => {
        if (!ctx.isOwner) {
            ctx.reply('❌ Hanya owner yang bisa menggunakan command ini!');
            return;
        }
        next();
    },

    requireGroup: (ctx, next) => {
        if (ctx.chat?.type !== 'group' && ctx.chat?.type !== 'supergroup') {
            ctx.reply('❌ Command ini hanya bisa digunakan di group!');
            return;
        }
        next();
    },

    requirePrivate: (ctx, next) => {
        if (ctx.chat?.type !== 'private') {
            ctx.reply('❌ Command ini hanya bisa digunakan di private chat!');
            return;
        }
        next();
    }
};