const { Markup } = require('telegraf');
const moment = require('moment-timezone');
const { isPremium, isOwner, runtime } = require('../../lib/utils');
const { getUser, updateUserGroups } = require('../../lib/database');
const fs = require('fs-extra');

module.exports = (bot) => {
  // Start command
  bot.start(async (ctx) => {
    const user = getUser(ctx.from.id);
    const isCreator = isOwner(ctx.from.id);
    const sender = ctx.from.username || ctx.from.first_name;
    
    const menuText = 
`╭─❒ 「 User Info 」 
├ Owner : ${isCreator ? 'True' : 'False'}
├ Name : ${ctx.from.first_name}${ctx.from.last_name ? ' ' + ctx.from.last_name : ''}
├ Profile : @${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`;

    await ctx.replyWithPhoto(
      'https://f.top4top.io/p_3530xky9e4.jpg',
      {
        caption: menuText,
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
          [Markup.button.callback('📱 Jasher Menu', 'jasher_menu')],
          [Markup.button.callback('👑 Owner Menu', 'owner_menu'), Markup.button.callback('🔒 Obf Menu', 'obf_menu')],
          [Markup.button.callback('🔄 Kembali', 'main_menu')]
        ])
      }
    );
  });

  // Menu command
  bot.command('menu', async (ctx) => {
    await ctx.replyWithPhoto(
      'https://f.top4top.io/p_3530xky9e4.jpg',
      {
        caption: '🏠 *Menu Utama Jasher Bot*',
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
          [Markup.button.callback('📱 Jasher Menu', 'jasher_menu')],
          [Markup.button.callback('👑 Owner Menu', 'owner_menu'), Markup.button.callback('🔒 Obf Menu', 'obf_menu')],
          [Markup.button.callback('🔄 Kembali', 'main_menu')]
        ])
      }
    );
  });

  // Callback query handler
  bot.action('main_menu', async (ctx) => {
    await ctx.editMessageCaption(
      '🏠 *Menu Utama Jasher Bot*',
      {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
          [Markup.button.callback('📱 Jasher Menu', 'jasher_menu')],
          [Markup.button.callback('👑 Owner Menu', 'owner_menu'), Markup.button.callback('🔒 Obf Menu', 'obf_menu')],
          [Markup.button.callback('🔄 Kembali', 'main_menu')]
        ])
      }
    );
  });

  // Jasher Menu
  bot.action('jasher_menu', async (ctx) => {
    const user = getUser(ctx.from.id);
    const premiumStatus = isPremium(ctx.from.id) ? 'Aktif' : 'Tidak Aktif';
    
    await ctx.editMessageCaption(
      `📱 *Jasher Menu*\n\n` +
      `👤 User: ${ctx.from.first_name}\n` +
      `⭐ Status: ${premiumStatus}\n` +
      `👥 Groups Added: ${user?.groups_added || 0}/3\n\n` +
      `Pilih fitur yang tersedia:`,
      {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
          [Markup.button.callback('🆓 Share Free', 'share_free'), Markup.button.callback('💎 Share VIP', 'share_vip')],
          [Markup.button.callback('💰 Buy Premium', 'buy_premium'), Markup.button.callback('📦 Buy Script', 'buy_script')],
          [Markup.button.callback('📊 Stats', 'user_stats'), Markup.button.callback('🔙 Kembali', 'main_menu')]
        ])
      }
    );
  });

  // Share Free handler
  bot.action('share_free', async (ctx) => {
    if (ctx.chat.type !== 'private') {
      await ctx.answerCbQuery('❌ Command ini hanya bisa digunakan di private chat!');
      return;
    }

    const user = getUser(ctx.from.id);
    if ((user?.groups_added || 0) < 3) {
      await ctx.reply(
        `❌ Anda harus menambahkan bot ke 3 group terlebih dahulu!\n` +
        `📊 Status: ${user?.groups_added || 0}/3 group\n\n` +
        `Tambahkan bot ke group dan gunakan /addgroup di group tersebut.`
      );
      return;
    }

    // Add 3 days premium
    const { addPremium } = require('../../lib/utils');
    const expiry = addPremium(ctx.from.id, 3);
    
    await ctx.reply(
      `✅ *Share Free Berhasil!*\n\n` +
      `⭐ Premium aktif selama 3 hari\n` +
      `⏰ Berakhir: ${moment(expiry).tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss')}\n\n` +
      `Sekarang Anda bisa menggunakan fitur Share VIP!`,
      { parse_mode: 'Markdown' }
    );
  });

  // Share VIP handler
  bot.action('share_vip', async (ctx) => {
    if (ctx.chat.type !== 'private') {
      await ctx.answerCbQuery('❌ Command ini hanya bisa digunakan di private chat!');
      return;
    }

    if (!isPremium(ctx.from.id)) {
      await ctx.reply(
        `❌ Anda harus premium untuk menggunakan Share VIP!\n\n` +
        `Gunakan Share Free terlebih dahulu atau beli premium.`
      );
      return;
    }

    await ctx.reply(
      `💎 *Share VIP*\n\n` +
      `Balas pesan yang ingin di-share dengan caption "sharevip" atau ketik pesan langsung.`,
      { parse_mode: 'Markdown' }
    );
  });

  // Buy Premium handler
  bot.action('buy_premium', async (ctx) => {
    await ctx.reply(
      `💰 *Buy Premium*\n\n` +
      `Harga: Rp ${global.PREMIUM_PRICE.toLocaleString()}\n` +
      `Durasi: 30 Hari\n\n` +
      `📋 Cara Pembelian:\n` +
      `1. Transfer ke rekening BCA: 1234567890\n` +
      `2. Kirim bukti transfer ke @owner_username\n` +
      `3. Premium akan diaktifkan setelah konfirmasi\n\n` +
      `⚠️ Pastikan mengirim bukti transfer yang valid.`,
      { parse_mode: 'Markdown' }
    );
  });

  // Buy Script handler
  bot.action('buy_script', async (ctx) => {
    await ctx.reply(
      `📦 *Buy Script*\n\n` +
      `Harga: Rp ${global.SCRIPT_PRICE.toLocaleString()}\n` +
      `Format: ZIP File\n\n` +
      `📋 Cara Pembelian:\n` +
      `1. Transfer ke rekening BCA: 1234567890\n` +
      `2. Kirim bukti transfer ke @owner_username\n` +
      `3. Script akan dikirim via document setelah konfirmasi\n\n` +
      `📁 Isi package:\n` +
      `- Full source code bot\n` +
      `- Dokumentasi lengkap\n` +
      `- Support teknis 1 bulan`,
      { parse_mode: 'Markdown' }
    );
  });
};

module.exports.handleMainMenu = async (ctx) => {
    const isCreator = isOwner(ctx.from.id);
    const sender = ctx.from.username || ctx.from.first_name;
    
    const menuText = 
`╭─❒ 「 User Info 」 
├ Owner : ${isCreator ? 'True' : 'False'}
├ Name : ${ctx.from.first_name}${ctx.from.last_name ? ' ' + ctx.from.last_name : ''}
├ Profile : @${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`;

    await ctx.editMessageCaption(menuText, {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
            [Markup.button.callback('📱 Jasher Menu', 'jasher_menu')],
            [Markup.button.callback('👑 Owner Menu', 'owner_menu'), Markup.button.callback('🔒 Obf Menu', 'obf_menu')],
            [Markup.button.callback('🔄 Kembali', 'main_menu')]
        ])
    });
};

module.exports.handleJasherMenu = async (ctx) => {
    const user = getUser(ctx.from.id);
    const premiumStatus = isPremium(ctx.from.id) ? 'Aktif' : 'Tidak Aktif';
    
    await ctx.editMessageCaption(
        `📱 *Jasher Menu*\n\n` +
        `👤 User: ${ctx.from.first_name}\n` +
        `⭐ Status: ${premiumStatus}\n` +
        `👥 Groups Added: ${user?.groups_added || 0}/3\n\n` +
        `Pilih fitur yang tersedia:`,
        {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
                [Markup.button.callback('🆓 Share Free', 'share_free'), Markup.button.callback('💎 Share VIP', 'share_vip')],
                [Markup.button.callback('💰 Buy Premium', 'buy_premium'), Markup.button.callback('📦 Buy Script', 'buy_script')],
                [Markup.button.callback('📊 Stats', 'user_stats'), Markup.button.callback('🔙 Kembali', 'main_menu')]
            ])
        }
    );
};