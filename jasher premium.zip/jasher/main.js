const { Telegraf, session } = require('telegraf');
const { message } = require('telegraf/filters');
const { BOT_TOKEN } = require('./config');
const { initializeDatabase, getUser, updateUser, getPremiumUsers, addPremiumUser, removePremiumUser } = require('./lib/database');
const { handleStart, handleHelp, handleCredit, handleShare, handleShareVip, handleBroadcast, handleAddPrem, handleDelPrem, handleListPrem } = require('./src/commands');
const { mainKeyboard, ownerKeyboard, backKeyboard } = require('./src/keyboards');

// Inisialisasi bot
const bot = new Telegraf(BOT_TOKEN);

// Middleware session
bot.use(session());

// Inisialisasi database
initializeDatabase();

// Command handlers
bot.start((ctx) => handleStart(ctx));
bot.help((ctx) => handleHelp(ctx));
bot.command('credit', (ctx) => handleCredit(ctx));
bot.command('share', (ctx) => handleShare(ctx));
bot.command('sharevip', (ctx) => handleShareVip(ctx));
bot.command('broadcast', (ctx) => handleBroadcast(ctx));
bot.command('addprem', (ctx) => handleAddPrem(ctx));
bot.command('delprem', (ctx) => handleDelPrem(ctx));
bot.command('listprem', (ctx) => handleListPrem(ctx));

// Action handlers untuk button
bot.action('main_menu', (ctx) => {
    ctx.editMessageText('🏠 Menu Utama Jasher Bot', mainKeyboard);
});

bot.action('owner_menu', (ctx) => {
    if (ADMIN_ID.includes(ctx.from.id)) {
        ctx.editMessageText('🔧 Menu Owner', ownerKeyboard);
    } else {
        ctx.answerCbQuery('Anda bukan owner bot!');
    }
});

bot.action('back', (ctx) => {
    ctx.editMessageText('🏠 Menu Utama Jasher Bot', mainKeyboard);
});

bot.action('add_group', (ctx) => {
    ctx.editMessageText(
        '📝 Untuk menambahkan group, ikuti langkah berikut:\n\n' +
        '1. Undang bot @jasherbot ke group Anda\n' +
        '2. Jadikan bot sebagai admin\n' +
        '3. Ketik /addgroup di group tersebut\n\n' +
        'Setelah menambahkan 3 group, Anda akan mendapatkan 10 kredit!',
        backKeyboard
    );
});

// Handler untuk pesan teks
bot.on(message('text'), (ctx) => {
    const text = ctx.message.text;
    
    switch (text) {
        case 'Jasher Menu':
            ctx.reply('🏠 Menu Utama Jasher Bot', mainKeyboard);
            break;
            
        case 'Owner Menu':
            if (ADMIN_ID.includes(ctx.from.id)) {
                ctx.reply('🔧 Menu Owner', ownerKeyboard);
            } else {
                ctx.reply('Anda bukan owner bot!');
            }
            break;
            
        case 'Kembali':
            ctx.reply('🏠 Menu Utama Jasher Bot', mainKeyboard);
            break;
            
        case 'AddGroup':
            ctx.reply(
                '📝 Untuk menambahkan group, ikuti langkah berikut:\n\n' +
                '1. Undang bot @jasherbot ke group Anda\n' +
                '2. Jadikan bot sebagai admin\n' +
                '3. Ketik /addgroup di group tersebut\n\n' +
                'Setelah menambahkan 3 group, Anda akan mendapatkan 10 kredit!',
                backKeyboard
            );
            break;
            
        case 'Owner':
            ctx.reply('👤 Owner Bot: @username_owner\n\nHubungi owner untuk pertanyaan atau bantuan.');
            break;
            
        default:
            // Tidak melakukan apa-apa untuk pesan lainnya
            break;
    }
});

// Jalankan bot
bot.launch().then(() => {
    console.log('Bot Jasher berhasil dijalankan!');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));