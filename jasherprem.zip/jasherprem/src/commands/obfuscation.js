const { Markup } = require('telegraf');
const fs = require('fs-extra');
const path = require('path');
const fetch = require('node-fetch');
const JsConfuser = require('js-confuser');
const { updateProgress, log, isPremium } = require('../../lib/utils');
const { addUser } = require('../../lib/database');

// Import obfuscation configs from obf.js
const {
    obfuscateTimeLocked,
    obfuscateQuantum,
    getSiuCalcrickObfuscationConfig,
    getCustomObfuscationConfig,
    getNebulaObfuscationConfig,
    getNovaObfuscationConfig,
    getStrongObfuscationConfig,
    getArabObfuscationConfig,
    getJapanObfuscationConfig,
    getJapanxArabObfuscationConfig,
    getMandarinObfuscationConfig
} = require('../../../obf');

module.exports = (bot) => {
    // Obfuscation menu
    bot.action('obf_menu', async (ctx) => {
        const premiumStatus = isPremium(ctx.from.id) ? 'Aktif' : 'Tidak Aktif';
        
        await ctx.editMessageCaption(
            `🔒 *Obfuscation Menu*\n\n` +
            `⭐ Status Premium: ${premiumStatus}\n\n` +
            `Pilih metode obfuscation:\n` +
            `🆓 = Free | 💎 = Premium`,
            {
                parse_mode: 'Markdown',
                ...Markup.inlineKeyboard([
                    [Markup.button.callback('⏰ Time Locked (🆓)', 'obf_enc'), Markup.button.callback('🌀 Quantum (💎)', 'obf_quantum')],
                    [Markup.button.callback('🕶️ Invisible (💎)', 'obf_zenc'), Markup.button.callback('🌟 Nebula (💎)', 'obf_nebula')],
                    [Markup.button.callback('⚡ Nova (💎)', 'obf_var'), Markup.button.callback('🎎 Japan (💎)', 'obf_japan')],
                    [Markup.button.callback('🕌 Arab (💎)', 'obf_enc4'), Markup.button.callback('🐉 Mandarin (💎)', 'obf_enc3')],
                    [Markup.button.callback('🎭 Custom (💎)', 'obf_xx'), Markup.button.callback('🤖 Siu+Calcrick (💎)', 'obf_enc5')],
                    [Markup.button.callback('🔧 Custom Text (💎)', 'obf_enc2'), Markup.button.callback('🔓 Deobfuscate (💎)', 'obf_deobfuscate')],
                    [Markup.button.callback('🔙 Kembali', 'main_menu')]
                ])
            }
        );
    });

    // Helper function untuk obfuscation
    async function handleObfuscation(ctx, methodName, obfuscationFunction, filenamePrefix) {
        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown(`❌ *Error:* Balas file .js dengan \`/${methodName}\`!`);
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        // Check premium for premium features
        if (methodName !== 'enc' && !isPremium(ctx.from.id)) {
            return ctx.reply(
                "❌ *Fitur Premium!*\n\n" +
                "Anda perlu premium untuk menggunakan fitur ini.\n" +
                "Gunakan /menu untuk info premium.",
                { parse_mode: 'Markdown' }
            );
        }

        const encryptedPath = path.join(__dirname, `../../${filenamePrefix}-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                ` ⚙️ Memulai (${methodName}) (1%)\n` +
                ` ${createProgressBar(1)}\n` +
                "```\n" +
                "PROSES ENCRYPT"
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk ${methodName} obfuscation: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            // Validate code
            log(`Memvalidasi kode: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode tidak valid: ${syntaxError.message}`);
            }

            // Obfuscate
            log(`Mengenkripsi file dengan ${methodName}`);
            await updateProgress(ctx, progressMessage, 40, `Inisialisasi ${methodName}`);
            
            let obfuscatedCode;
            if (typeof obfuscationFunction === 'function') {
                obfuscatedCode = await obfuscationFunction(fileContent);
            } else {
                const obfuscated = await JsConfuser.obfuscate(fileContent, obfuscationFunction);
                obfuscatedCode = obfuscated.code || obfuscated;
            }

            if (typeof obfuscatedCode !== "string") {
                throw new Error("Hasil obfuscation bukan string");
            }

            await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
            await fs.writeFile(encryptedPath, obfuscatedCode);
            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

            // Validate obfuscated code
            log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
            try {
                new Function(obfuscatedCode);
            } catch (postObfuscationError) {
                throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
            }

            // Send file
            log(`Mengirim file terenkripsi: ${file.file_name}`);
            await ctx.replyWithDocument(
                { source: encryptedPath, filename: `${filenamePrefix}-${file.file_name}` },
                {
                    caption: `✅ *File terenkripsi (${methodName}) siap!*\nSUKSES ENCRYPT 🕊`,
                    parse_mode: "Markdown",
                }
            );
            await updateProgress(ctx, progressMessage, 100, `${methodName} Obfuscation Selesai`);

            // Cleanup
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus: ${encryptedPath}`);
            }

        } catch (error) {
            log(`Kesalahan saat ${methodName} obfuscation`, error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
            );
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus setelah error: ${encryptedPath}`);
            }
        }
    }

    // Progress bar function
    function createProgressBar(percentage, length = 20) {
        const filled = Math.round((percentage / 100) * length);
        const empty = length - filled;
        return `[${'█'.repeat(filled)}${'░'.repeat(empty)}] ${percentage}%`;
    }

    // Time-Locked Encryption (enc)
    bot.command('enc', async (ctx) => {
        addUser(ctx.from.id);
        const args = ctx.message.text.split(' ').slice(1);
        
        if (args.length !== 1 || !/^\d+$/.test(args[0]) || parseInt(args[0]) < 1 || parseInt(args[0]) > 365) {
            return ctx.replyWithMarkdown(
                "❌ *Error:* Gunakan format `/enc [1-365]` untuk jumlah hari (misal: `/enc 7`)!"
            );
        }

        const days = args[0];
        
        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc [1-365]`!");
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const encryptedPath = path.join(__dirname, `../../locked-encrypted-${file.file_name}`);
        const expiryDate = new Date();
        expiryDate.setDate(expiryDate.getDate() + parseInt(days));

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                " ⚙️ Memulai (Time-Locked Encryption) (1%)\n" +
                " " + createProgressBar(1) + "\n" +
                "```\n" +
                "PROSES ENCRYPT"
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            // Validate code
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode tidak valid: ${syntaxError.message}`);
            }

            // Obfuscate with time lock
            await updateProgress(ctx, progressMessage, 40, "Inisialisasi Time-Locked Encryption");
            const obfuscatedCode = await obfuscateTimeLocked(fileContent, days);
            
            await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
            await fs.writeFile(encryptedPath, obfuscatedCode);
            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

            // Validate obfuscated code
            try {
                new Function(obfuscatedCode);
            } catch (postObfuscationError) {
                throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
            }

            // Send result
            await ctx.replyWithMarkdown(
                `✅ *File terenkripsi (Time-Locked Encryption) siap!*\n` +
                `⏰ Masa aktif: ${days} hari (Kedaluwarsa: ${expiryDate.toLocaleDateString()})\n` +
                `_Powered by Jasher Bot_`
            );
            
            await ctx.replyWithDocument({
                source: encryptedPath,
                filename: `locked-encrypted-${file.file_name}`,
            });
            
            await updateProgress(ctx, progressMessage, 100, "Time-Locked Encryption Selesai");

            // Cleanup
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
            }

        } catch (error) {
            log("Kesalahan saat Time-Locked obfuscation", error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
            );
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
            }
        }
    });

    // Quantum Encryption
    bot.command('quantum', async (ctx) => {
        await handleObfuscation(ctx, 'Quantum', obfuscateQuantum, 'quantum-encrypted');
    });

    // Invisible Encryption
    bot.command('zenc', async (ctx) => {
        await handleObfuscation(ctx, 'Invisible', getStrongObfuscationConfig, 'invisible-encrypted');
    });

    // Nebula Encryption
    bot.command('nebula', async (ctx) => {
        await handleObfuscation(ctx, 'Nebula', getNebulaObfuscationConfig, 'nebula-encrypted');
    });

    // Nova Encryption
    bot.command('var', async (ctx) => {
        await handleObfuscation(ctx, 'Nova', getNovaObfuscationConfig, 'var-encrypted');
    });

    // Japan Encryption
    bot.command('japan', async (ctx) => {
        await handleObfuscation(ctx, 'Japan', getJapanObfuscationConfig, 'japan-encrypted');
    });

    // Arab Encryption
    bot.command('enc4', async (ctx) => {
        await handleObfuscation(ctx, 'Arab', getArabObfuscationConfig, 'arab-encrypted');
    });

    // Mandarin Encryption
    bot.command('enc3', async (ctx) => {
        await handleObfuscation(ctx, 'Mandarin', getMandarinObfuscationConfig, 'china-encrypted');
    });

    // Custom Encryption
    bot.command('xx', async (ctx) => {
        addUser(ctx.from.id);
        const args = ctx.message.text.split(' ');
        if (args.length < 2 || !args[1]) {
            return ctx.replyWithMarkdown("❌ *Error:* Gunakan format `/xx <nama>` dengan nama kustom!");
        }
        
        const customName = args[1].replace(/[^a-zA-Z0-9_]/g, "");
        if (!customName) {
            return ctx.replyWithMarkdown("❌ *Error:* Nama kustom harus berisi huruf, angka, atau underscore!");
        }

        await handleObfuscation(
            ctx, 
            `Custom-${customName}`, 
            getCustomObfuscationConfig(customName), 
            `custom-${customName}-encrypted`
        );
    });

    // Siu+Calcrick Encryption
    bot.command('enc5', async (ctx) => {
        await handleObfuscation(ctx, 'SiuCalcrick', getSiuCalcrickObfuscationConfig, 'siucalcrick-encrypted');
    });

    // Custom Text Encryption
    bot.command('enc2', async (ctx) => {
        addUser(ctx.from.id);
        const customString = ctx.message.text.split(' ')[1];

        if (!customString) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc2 <text>`!");
        }

        await handleObfuscation(
            ctx, 
            `Custom-${customString}`, 
            getCustomObfuscationConfig(customString), 
            `custom-encrypted`
        );
    });

    // Deobfuscate command
    bot.command('deobfuscate', async (ctx) => {
        if (!isPremium(ctx.from.id)) {
            return ctx.reply("❌ *Fitur Premium!* Anda perlu premium untuk menggunakan deobfuscate.");
        }

        await handleDeobfuscation(ctx);
    });

    async function handleDeobfuscation(ctx) {
        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js yang diobfuscate dengan `/deobfuscate`!");
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const deobfuscatedPath = path.join(__dirname, `../../deobfuscated-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                " ⚙️ Memulai Deobfuscation (1%)\n" +
                " " + createProgressBar(1) + "\n" +
                "```\n" +
                "PROSES DECRYPT"
            );

            // Download file
            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            // Basic deobfuscation attempt (simplified)
            await updateProgress(ctx, progressMessage, 40, "Memulai Deobfuscation");
            
            // Simple string replacements for common obfuscation patterns
            let deobfuscatedCode = fileContent
                .replace(/\\x([0-9A-Fa-f]{2})/g, (match, p1) => String.fromCharCode(parseInt(p1, 16)))
                .replace(/\\u([0-9A-Fa-f]{4})/g, (match, p1) => String.fromCharCode(parseInt(p1, 16)));

            // Try to beautify the code
            try {
                deobfuscatedCode = deobfuscatedCode
                    .replace(/;/g, ';\n')
                    .replace(/{/g, '{\n')
                    .replace(/}/g, '\n}\n')
                    .replace(/,/g, ', ');
            } catch (error) {
                log("Error beautifying code:", error);
            }

            await updateProgress(ctx, progressMessage, 80, "Menyimpan Hasil");
            await fs.writeFile(deobfuscatedPath, deobfuscatedCode);

            // Send result
            await ctx.replyWithDocument(
                { source: deobfuscatedPath, filename: `deobfuscated-${file.file_name}` },
                {
                    caption: "✅ *File berhasil dideobfuscate!*\nSUKSES DECRYPT 🕊",
                    parse_mode: "Markdown",
                }
            );
            await updateProgress(ctx, progressMessage, 100, "Deobfuscation Selesai");

            // Cleanup
            if (await fs.pathExists(deobfuscatedPath)) {
                await fs.unlink(deobfuscatedPath);
            }

        } catch (error) {
            log("Kesalahan saat deobfuscation", error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan file Javascript yang valid!_`
            );
            if (await fs.pathExists(deobfuscatedPath)) {
                await fs.unlink(deobfuscatedPath);
            }
        }
    }

    // Tourl command untuk upload file ke URL
    bot.command('tourl', async (ctx) => {
        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file dengan `/tourl` untuk mengupload ke URL!");
        }

        const file = ctx.message.reply_to_message.document;
        const { uploadToUguu } = require('../../lib/utils');

        try {
            const progressMessage = await ctx.reply("📤 Mengupload file...");

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            const response = await fetch(fileLink);
            const fileBuffer = await response.buffer();

            const url = await uploadToUguu(fileBuffer, file.file_name);

            await ctx.editMessageText(
                `✅ *File berhasil diupload!*\n\n` +
                `📁 Nama: ${file.file_name}\n` +
                `📦 Size: ${(file.file_size / 1024).toFixed(2)} KB\n` +
                `🔗 URL: ${url}`,
                { parse_mode: 'Markdown' }
            );

        } catch (error) {
            log("Error uploading file:", error);
            await ctx.reply("❌ Gagal mengupload file. Silakan coba lagi.");
        }
    });
};