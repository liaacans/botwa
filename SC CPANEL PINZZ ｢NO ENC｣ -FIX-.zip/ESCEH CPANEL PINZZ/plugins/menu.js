const fs = require("fs");
const ffmpeg = require("fluent-ffmpeg");
const axios = require("axios");

const qchanel = {
key: {
remoteJid: 'status@broadcast',
fromMe: false,
participant: '0@s.whatsapp.net'
},
message: {
newsletterAdminInviteMessage: {
newsletterJid: `belum disalin`,
newsletterName: `Pinzz 📌 || Whatsapp Channel ⭐`,
jpegThumbnail: "",
caption: `PinzzStoree⚡`,
inviteExpiration: Date.now() + 1814400000
}}}

let handler = async (m, { Sky }) => {
    let teksnya = `
｢ 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐒𝐈 𝐁𝐎𝐓 ｣
➤ Script : CPANEL PinzzStoree
➤ wa dev : 083845718881
➤ tele dev: t.me/pinzstoreee
➤ Version : 1.0
➤ Status : UDH DI FIX KE YG NEW + BAGUS 💦

   *｢ OTHERMENU ｣*
  ➤ ｢cekidch｣
  ➤ ｢cekidgc｣
  ➤ ｢qc｣
  ➤ ｢brat｣
  ➤ ｢readviewonce｣
  ➤ ｢stickerwm｣
  ➤ ｢sticker｣
  
  *｢ SEARCHMENU ｣*
  ➤ ｢yts｣
  ➤ ｢apkmod｣
  ➤ ｢pinterest｣
  
  *｢ TOOLSMENU ｣*
  ➤ ｢ai｣
  ➤ ｢gpt｣
  ➤ ｢tourl｣
  ➤ ｢tourl2｣
  ➤ ｢ssweb｣
  ➤ ｢translate｣
  ➤ ｢tohd｣
  ➤ ｢shortlink｣
  ➤ ｢shortlink2｣
  ➤ ｢enc｣
  
  *｢ SHOPEMENU ｣*
  ➤ ｢buypanel｣
  ➤ ｢buyadp｣
  ➤ ｢buyscript｣
  ➤ ｢buyvps｣
  
  *｢ DWONLOADMENU ｣*
  ➤ ｢tiktok｣
  ➤ ｢tiktokmp3｣
  ➤ ｢instagram｣
  ➤ ｢ytmp3｣
  ➤ ｢ytmp4｣
  ➤ ｢play｣
  ➤ ｢playvid｣
  ➤ ｢gitclone｣
  ➤ ｢mediafire｣
  
  *｢ STOREMENU ｣*
  ➤ ｢addrespon｣
  ➤ ｢delrespon｣
  ➤ ｢listrespon｣
  ➤ ｢done｣
  ➤ ｢proses｣
  ➤ ｢jpm｣
  ➤ ｢jpm2｣
  ➤ ｢jpmtesti｣
  ➤ ｢jpmslide｣
  ➤ ｢jpmslideht｣
  ➤ ｢sendtesti｣
  ➤ ｢pushkontak｣
  ➤ ｢pushkontak2｣
  ➤ ｢payment｣
  ➤ ｢produk｣
  ➤ ｢subdomain｣
  
  *｢ DIGITALOCEANMENU ｣*
  ➤ ｢r1c1｣
  ➤ ｢r2c1｣
  ➤ ｢r4c2｣
  ➤ ｢r8c4｣
  ➤ ｢r16c4｣
  ➤ ｢sisadroplet｣
  ➤ ｢deldroplet｣
  ➤ ｢listdroplet｣
  ➤ ｢rebuild｣
  ➤ ｢restartvps｣
  
  *｢ MENUPANELRESSELER ｣*
  ➤ ｢addseller｣
  ➤ ｢delseller｣
  ➤ ｢listseller｣
  ➤ ｢1gb｣
  ➤ ｢2gb｣
  ➤ ｢3gb｣
  ➤ ｢4gb｣
  ➤ ｢5gb｣
  ➤ ｢6gb｣
  ➤ ｢7gb｣
  ➤ ｢8gb｣
  ➤ ｢9gb｣
  ➤ ｢10gb｣
  ➤ ｢unlimited｣
  ➤ ｢cadmin｣
  ➤ ｢delpanel｣
  ➤ ｢deladmin｣
  ➤ ｢listpanel｣
  ➤ ｢listadmin｣
    
  *｢ MENUPANELRESSELER-V2 ｣*
  ➤ ｢1gb-v2｣
  ➤ ｢2gb-v2｣
  ➤ ｢3gb-v2｣
  ➤ ｢4gb-v2｣
  ➤ ｢5gb-v2｣
  ➤ ｢6gb-v2｣
  ➤ ｢7gb-v2｣
  ➤ ｢8gb-v2｣
  ➤ ｢9gb-v2｣
  ➤ ｢10gb-v2｣
  ➤ ｢unlimited-v2｣
  ➤ ｢cadmin-v2｣
  ➤ ｢delpanel-v2｣
  ➤ ｢deladmin-v2｣
  ➤ ｢listpanel-v2｣
  ➤ ｢listadmin-v2｣
  
  *｢ INSTALLMENU ｣*
  ➤ ｢hackbackpanel｣
  ➤ ｢installpanel｣
  ➤ ｢installtemastellar｣
  ➤ ｢installtemabilling｣
  ➤ ｢installtemaenigma｣
  ➤ ｢uninstallpanel｣
  ➤ ｢uninstalltema｣
  
  *｢ GROUPMENU ｣*
  ➤ ｢add｣
  ➤ ｢kick｣
  ➤ ｢close｣
  ➤ ｢open｣
  ➤ ｢hidetag｣
  ➤ ｢kudetagc｣
  ➤ ｢leave｣
  ➤ ｢tagall｣
  ➤ ｢promote｣
  ➤ ｢demote｣
  ➤ ｢resetlinkgc｣
  ➤ ｢on｣
  ➤ ｢off｣
  ➤ ｢linkgc｣
  
  *｢ OWNERMENU ｣*
  ➤ ｢autoread｣
  ➤ ｢autopromosi｣
  ➤ ｢autoreadsw｣
  ➤ ｢autotyping｣
  ➤ ｢addplugins｣
  ➤ ｢listplugins｣
  ➤ ｢delplugins｣
  ➤ ｢getplugins｣
  ➤ ｢saveplugins｣
  ➤ ｢addowner｣
  ➤ ｢listowner｣
  ➤ ｢delowner｣
  ➤ ｢self/public｣
  ➤ ｢setimgmenu｣
  ➤ ｢setimgfake｣
  ➤ ｢setppbot｣
  ➤ ｢clearsession｣
  ➤ ｢clearchat｣
  ➤ ｢resetdb｣
  ➤ ｢restartbot｣
  ➤ ｢getsc｣
  ➤ ｢getcase｣
  ➤ ｢listgc｣
  ➤ ｢joingc｣
  ➤ ｢joinch｣
  ➤ ｢upchannel｣
  ➤ ｢upchannel2｣
  
  ｢ 𝐂𝐑𝐄𝐃𝐈𝐓 𝐒𝐂𝐑𝐈𝐏𝐓 ｣
  ➤ ｢PINZZ STOREE｣
  
  ｢ 𝐈𝐍𝐅𝐎 𝐒𝐂𝐑𝐈𝐏𝐓 ｣
  ➤ https://whatsapp.com/channel/0029Vb2bXsrIHphBIvD8c52f
`;

let videoUrl = 'https://files.catbox.moe/o6kuua.mp4'; // Ganti dengan URL video
let videoPath = './temp-video.mp4'; 
let thumbnailPath = './thumbnail.jpg'; 

try {

console.log('Mengunduh video...');
const response = await axios({
method: 'get',
url: videoUrl,
responseType: 'stream',
});

const writer = fs.createWriteStream(videoPath);
response.data.pipe(writer);

writer.on('finish', () => {
console.log('Video berhasil diunduh!');

ffmpeg(videoPath)
.screenshots({
count: 1,
folder: './',
filename: 'thumbnail.jpg',
size: '320x180' 
})
.on('end', async () => {
console.log('Thumbnail berhasil dibuat!');

await Sky.sendMessage(m.chat, {
video: { url: videoUrl }, 
mimetype: 'video/mp4',
caption: teksnya,
jpegThumbnail: fs.readFileSync(thumbnailPath)
}, { quoted: qchanel });

await Sky.sendMessage(m.chat, { 
audio: { url: 'https://files.catbox.moe/ov9ieo.m4a' }, 
mimetype: 'audio/mpeg', 
ptt: true }, { quoted: qchanel });

fs.unlinkSync(videoPath);
fs.unlinkSync(thumbnailPath);
})
.on('error', (err) => {
console.error('Gagal membuat thumbnail:', err);
});
});
} catch (error) {
console.error('Gagal mengunduh video:', error);
await Sky.sendMessage(m.chat, { text: "Gagal mengunduh video, pastikan link valid!" }, { quoted: m });
}
};


handler.command = ["menu"];

module.exports = handler;
