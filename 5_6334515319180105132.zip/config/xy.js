const fs = require('fs');
const axios = require('axios');
const path = require('path');
const {
  exec,
  spawn
} = require("child_process");
const qr = require('qr-image');
const Tiktok = require("@tobyg74/tiktok-api-dl");
const ytdl = require('@distube/ytdl-core');
const ffmpeg = require('fluent-ffmpeg');
const crypto = require('crypto');
const { createCanvas, loadImage } = require('canvas');
const {
  igdl
} = require('btch-downloader');
const {
  Client
} = require('ssh2');
const tiktok2 = require('../src/lib/tiktok');
const genmusic = require('../src/lib/aimusic');
const generateQRAndUpload = require("../src/lib/uploader");
const toqrcode = require('../src/lib/qrcode'); 
const CPU_CHECK_STATUS_FILE = './src/database/cpu_check_status.json';
global.serverOfflineStatus = readJson(CPU_CHECK_STATUS_FILE, {});
const {
  startWhatsAppSession,
  sessions,
  restoreWhatsAppSessions,
  updateActiveSessions
} = require("../src/lib/connectwa")
const {
  addResponList1,
  delResponList1,
  isAlreadyResponList1,
  isAlreadyResponList1Group,
  sendResponList1,
  updateResponList1,
  getDataResponList1
} = require('../src/lib/addlist'); 
global.serverOfflineStatus = new Map();


const WELEAVE_FILE = './src/database/weleave.json';
const ANTILINK_FILE = './src/database/antilink.json';
const LIST_FILE = './src/database/list.json';
const WARN_FILE = './src/database/warns.json';
const ALLOWED_GROUPS_FILE = './src/database/allowed_groups.json';

function readJson(filePath, defaultValue = []) {
    try {
        if (!fs.existsSync(filePath)) return defaultValue;
        const content = fs.readFileSync(filePath, 'utf8');
        return JSON.parse(content);
    } catch (e) {
        console.error(`Error reading ${filePath}:`, e);
        return defaultValue;
    }
}

function writeJson(filePath, data) {
    try {
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
        return true;
    } catch (e) {
        console.error(`Error writing to ${filePath}:`, e);
        return false;
    }
}


async function sendChunkedMessage(xy, text, messageIdToEdit = null) {
  const MAX_LENGTH = 4000; 
  let parts = [];
  let currentPart = '';


  const lines = text.split('\n');
  for (const line of lines) {
    if ((currentPart + line + '\n').length > MAX_LENGTH) {
      parts.push(currentPart);
      currentPart = line + '\n';
    } else {
      currentPart += line + '\n';
    }
  }
  if (currentPart.trim()) {
    parts.push(currentPart);
  }
  
  // Kirim bagian pertama
  if (parts.length > 0) {
      if (messageIdToEdit) {
          try {

              await xy.api.editMessageText(xy.chat.id, messageIdToEdit, parts[0], { parse_mode: 'HTML' });
          } catch(e) {

               await xy.api.sendMessage(xy.chat.id, parts[0], { parse_mode: 'HTML' });
          }
      } else {

          await xy.api.sendMessage(xy.chat.id, parts[0], { parse_mode: 'HTML' });
      }
      

      for (let i = 1; i < parts.length; i++) {
          await xy.api.sendMessage(xy.chat.id, parts[i], { parse_mode: 'HTML' });
      }
  }
}


async function editReply(xy, messageId, text, replyMarkup = null) {
  const MAX_EDIT_LENGTH = 4096;
  if (text.length > MAX_EDIT_LENGTH) {

      console.warn(`Pesan terlalu panjang (${text.length} karakter). Mengirim pesan dalam chunks...`);
      await sendChunkedMessage(xy, text, messageId);
      
      if (replyMarkup) {
          await xy.api.sendMessage(xy.chat.id, 'Berikut tombol navigasinya:', { reply_markup: replyMarkup });
      }
      return; 
  }
  
  try {
    await xy.api.editMessageText(xy.chat.id, messageId, text, {
      parse_mode: 'HTML',
      reply_markup: replyMarkup
    });
  } catch (e) {
    console.error(`Gagal mengedit pesan ${messageId}:`, e.message);

    await xy.api.sendMessage(xy.chat.id, text, {
      parse_mode: 'HTML',
      reply_markup: replyMarkup
    });
  }
}

function checkUserRole(userId, requiredRoles, serverVersion) {
  const ownerFile = './owner.json';
  const partnerFile = './src/database/partner.json';
  const resellerFile = './src/database/reseller.json';
  const sellerFile = './src/database/seller.json';

  let owners = [];
  let partners = [];
  let resellers = [];
  let sellers = [];

  try {
    owners = JSON.parse(fs.readFileSync(ownerFile, 'utf8'));
    partners = JSON.parse(fs.readFileSync(partnerFile, 'utf8'));
    resellers = JSON.parse(fs.readFileSync(resellerFile, 'utf8'));
    sellers = JSON.parse(fs.readFileSync(sellerFile, 'utf8'));
  } catch (e) {
    console.error("Error reading role files:", e);
  }

  const isOwner = owners.includes(String(userId));
  if (isOwner && requiredRoles.includes('owner')) return true;

  if (requiredRoles.includes('partner') && Array.isArray(partners)) {
    const isPartner = partners.some(p => String(p.id) === String(userId) && p.server === serverVersion);
    if (isPartner) return true;
  }

  if (requiredRoles.includes('reseller') && Array.isArray(resellers)) {
    const isReseller = resellers.some(r => String(r.id) === String(userId) && r.server === serverVersion);
    if (isReseller) return true;
  }

  if (requiredRoles.includes('seller') && Array.isArray(sellers)) {
    const isSeller = sellers.some(s => String(s.id) === String(userId));
    if (isSeller) return true;
  }

  return false;
}
async function getServerStatus(serverUuid, panelConfig) {
  try {
    const response = await axios.get(`${panelConfig.panelDomain}/api/client/servers/${serverUuid}/resources`, {
      headers: {
        'Authorization': `Bearer ${panelConfig.pltcKey}`
      }
    });
    return response.data.attributes.current_state;
  } catch (error) {
    return 'error';
  }
}

   async function stopServer(serverUuid, panelDomain, pltcKey) {
  try {
    await axios.post(`${panelDomain}/api/client/servers/${serverUuid}/power`, {
      signal: 'stop'
    }, {
      headers: {
        'Authorization': `Bearer ${pltcKey}`,
        'Content-Type': 'application/json'
      }
    });
    return true;
  } catch (error) {
    console.error(`Gagal menghentikan server ${serverUuid}:`, error.message);
    return false;
  }
}

async function checkAndStopAbnormalCpu(botInstance) {
    const statusData = readJson(CPU_CHECK_STATUS_FILE, {});
    const now = Date.now();
    

    for (const key in statusData) {
        if (!key.startsWith('v') || !statusData[key].active) continue;

        const serverVersion = key;
        const panelConfig = getPanelConfig(serverVersion);
        
        const { panelDomain, pltaKey, pltcKey } = panelConfig;
        

        const targetChatId = statusData[serverVersion].chat_id; 
        const recipientId = targetChatId || global.idowner; 
        
        if (!panelDomain || !pltaKey || !pltcKey || !recipientId) continue;

        let servers = [];
        let page = 1;
        let hasMore = true;
        let abnormalCpuServers = [];
        let totalServersChecked = 0;
        let serversFailedToStop = 0;
        let serversSkippedStop = 0;
        
        let initialMessageId = null;

        try {

            const loadingMsg = await botInstance.api.sendMessage(recipientId, `<blockquote>⏳ [AUTO-CHECK CPU] - ${serverVersion.toUpperCase()}\n\nMemulai pengecekan. Mohon tunggu...</blockquote>`, { parse_mode: 'HTML' });
            initialMessageId = loadingMsg.message_id;



            while (hasMore) {
                const response = await axios.get(`${panelDomain}/api/application/servers?page=${page}`, {
                    headers: { 'Authorization': `Bearer ${pltaKey}` }
                });
                const result = response.data;
                servers = servers.concat(result.data);
                hasMore = result.meta.pagination.current_page < result.meta.pagination.total_pages;
                page++;
            }


            for (const server of servers) {
                const { id: serverId, name: serverName, uuid: serverUuid } = server.attributes;
                
                try {
                    const resourceResponse = await axios.get(`${panelDomain}/api/client/servers/${serverUuid}/resources`, {
                        headers: { 'Authorization': `Bearer ${pltcKey}` }
                    });

                    const resources = resourceResponse.data.attributes.resources;
                    

                    if (resources && resources.cpu_absolute !== undefined) {
                        const cpuUsage = resources.cpu_absolute;
                        const cpuLimit = resources.cpu_limit;
                        
                        // Batas Wajar: 80% (atau 80% dari limit jika limit > 100)
                        const limitToCompare = cpuLimit > 100 ? (cpuLimit * 0.8) : 80;
                        totalServersChecked++; 

                        if (cpuUsage > limitToCompare) {
                            abnormalCpuServers.push({ serverId, serverName, serverUuid, cpuUsage, cpuLimit, limitToCompare });
                        }
                    } else {

                    }

                    
                } catch (error) {

                }
            }
            

            for (const srv of abnormalCpuServers) {
                const stopTime = statusData[serverVersion].auto_stop[srv.serverId];
                
                if (stopTime && (now - stopTime < 5 * 60 * 1000)) { 
                    serversSkippedStop++;
                    continue; 
                }

                const isStopped = await stopServer(srv.serverUuid, panelDomain, pltcKey);
                
                if (isStopped) {
                    const notification = `
🚨 <b>[AUTO-STOP CPU] - ${serverVersion.toUpperCase()}</b> 🚨

Server <b>${srv.serverName}</b> (ID: <code>${srv.serverId}</code>) secara otomatis <b>dihentikan</b>!
📈 <b>CPU Usage</b>: ${srv.cpuUsage.toFixed(2)}% (Limit: ${srv.cpuLimit}%)
⚠️ Melebihi batas wajar (${srv.limitToCompare.toFixed(0)}%).
`;
                    try {
                        await botInstance.api.sendMessage(recipientId, `<blockquote>${notification}</blockquote>`, { parse_mode: 'HTML' });
                    } catch (e) { 
                        console.error(`Gagal kirim notif auto-stop ke ID ${recipientId}:`, e.message); 
                    }
                    
                    statusData[serverVersion].auto_stop[srv.serverId] = now;
                } else {
                    serversFailedToStop++;
                }
            }
            

            let finalMessage = `
✅ <b>[AUTO-CHECK CPU] - ${serverVersion.toUpperCase()}</b> ✅

Total Server yang Dicek: <b>${totalServersChecked}</b>

`;

            if (abnormalCpuServers.length > 0) {
                const stoppedCount = abnormalCpuServers.length - serversFailedToStop - serversSkippedStop;
                
                finalMessage = `
⚠️ <b>[AUTO-CHECK SELESAI] - ${serverVersion.toUpperCase()}</b> ⚠️

Total Server Abnormal: <b>${abnormalCpuServers.length}</b>
- Dihentikan: <b>${stoppedCount}</b>
- Gagal Dihentikan: <b>${serversFailedToStop}</b>
- Dilewati (Baru distop): <b>${serversSkippedStop}</b>
`;
                
                abnormalCpuServers.forEach(srv => {
                    const status = statusData[serverVersion].auto_stop[srv.serverId] ? 'DiSTOP' : 'Gagal STOP';
                    finalMessage += `\n• <code>${srv.serverId}</code> (${srv.name}) - ${srv.usage.toFixed(2)}% (${status})`;
                });
                
            } else {
                 finalMessage += `Semua server yang dicek berada dalam batas CPU wajar.`;
            }
            
            await botInstance.api.editMessageText(recipientId, initialMessageId, `<blockquote>${finalMessage}</blockquote>`, { parse_mode: 'HTML' });


            const updatedAutoStop = {};
            for(const id in statusData[serverVersion].auto_stop) {
                if(abnormalCpuServers.some(srv => String(srv.serverId) === id)) {
                    updatedAutoStop[id] = statusData[serverVersion].auto_stop[id];
                }
            }
            statusData[serverVersion].auto_stop = updatedAutoStop;


        } catch (err) {
            console.error(`Error auto-check CPU ${serverVersion}:`, err.message);
            

            let errorDetail = err.message;
            if (err.response && err.response.status === 403) {
                 errorDetail = "API Key PLTA/PLTC salah atau tidak memiliki izin (403 Forbidden).";
            } else if (err.code === 'ECONNREFUSED' || err.code === 'ENOTFOUND') {
                 errorDetail = "Domain Panel salah atau Node Wings sedang offline.";
            } else if (err.message) {
                 errorDetail = err.message.substring(0, 150);
            }

            const errorNotification = `
❌ <b>[AUTO-CHECK GAGAL TOTAL] - ${serverVersion.toUpperCase()}</b> ❌

Gagal melakukan pengecekan server.
API Panel: ${panelDomain}
Pesan Error: <code>${errorDetail}</code>
`;
            try {
                // Edit pesan loading menjadi pesan error
                if (initialMessageId) {
                    await botInstance.api.editMessageText(recipientId, initialMessageId, `<blockquote>${errorNotification}</blockquote>`, { parse_mode: 'HTML' });
                } else {
                    // Fallback kirim pesan error baru jika pesan loading gagal
                    await botInstance.api.sendMessage(recipientId, `<blockquote>${errorNotification}</blockquote>`, { parse_mode: 'HTML' });
                }
            } catch (e) { 
                console.error("Gagal kirim notif error auto-check:", e.message); 
            }
        }
    }
    
    writeJson(CPU_CHECK_STATUS_FILE, statusData); 
}



function getPanelConfig(version) {
  switch (version) {
    case 'v1':
      return {
        name: 'Server V1',
        panelDomain: global.domain,
        pltaKey: global.plta,
        pltcKey: global.pltc,
        nests: global.nests,
        eggs: global.eggs,
        loc: global.loc
      };
    case 'v2':
      return {
        name: 'Server V2',
        panelDomain: global.domainV2,
        pltaKey: global.pltaV2,
        pltcKey: global.pltcV2,
        nests: global.nestsV2,
        eggs: global.eggsV2,
        loc: global.locV2
      };
    case 'v3':
      return {
        name: 'Server V3',
        panelDomain: global.domainV3,
        pltaKey: global.pltaV3,
        pltcKey: global.pltcV3,
        nests: global.nestsV3,
        eggs: global.eggsV3,
        loc: global.locV3
      };
    case 'v4':
      return {
        name: 'Server V4',
        panelDomain: global.domainV4,
        pltaKey: global.pltaV4,
        pltcKey: global.pltcV4,
        nests: global.nestsV4,
        eggs: global.eggsV4,
        loc: global.locV4
      };
    default:
      return {};
  }
}
async function editReply(xy, messageId, text) {
  try {
    await xy.api.editMessageText(xy.chat.id, messageId, text, {
      parse_mode: 'HTML'
    });
  } catch (e) {
    console.error(`Gagal mengedit pesan ${messageId}:`, e.message);
    await xy.api.sendMessage(xy.chat.id, text, {
      parse_mode: 'HTML'
    });
  }
}

async function handleMessage(xy, command, sleep, isOwner, isSeller, isPartner, isReseller, reply, owners, seller, sellerPath, q, text, InlineKeyboard, paket, isGroupAdmins, mess, warnDB, saveWarnDB, pendingWarns, InputFile, botToken, CatBox, sender, db_respon_list, generateReadableString, isBotGroupAdmins) { 
  
  
  const runCommand = (cmd, sshInstance) => new Promise((resolve, reject) => {
      let output = '';
      sshInstance.exec(cmd, (err, stream) => {
          if (err) return reject(err);

          stream.on('close', (code) => {
              if (code !== 0) {
                  reject(new Error(`Command failed with code ${code}. Output: ${output.substring(0, 4000)}`));
              } else {
                  resolve(output);
              }
          }).on('data', (data) => {
              output += data.toString();
          }).stderr.on('data', (data) => {
              output += data.toString();
          });
      });
  });
  
  switch (command) {
    case "seturl":
    case "seturlv2":
    case "seturlv3":
    case "seturlv4":
    case "setplta":
    case "setpltav2":
    case "setpltav3":
    case "setpltav4":
    case "setpltc":
    case "setpltcv2":
    case "setpltcv3":
    case "setpltcv4": {
      if (!isOwner) return reply(mess.owner);

      const serverVersion = command.endsWith('v2') ? 'v2' : command.endsWith('v3') ? 'v3' : command.endsWith('v4') ? 'v4' : '';
      const configPath = './config/settings.js';

      let key;
      if (command.startsWith('seturl')) {
        key = `global.domain${serverVersion ? serverVersion.toUpperCase() : ''}`;
      } else if (command.startsWith('setplta')) {
        key = `global.plta${serverVersion ? serverVersion.toUpperCase() : ''}`;
      } else if (command.startsWith('setpltc')) {
        key = `global.pltc${serverVersion ? serverVersion.toUpperCase() : ''}`;
      }

      if (!text) {
        return reply(`<blockquote><b>Format salah!</b>\n\nPenggunaan:\n${prefix + command} [nilai_baru]\n\nContoh:\n${prefix + command} https://panel.contoh.com</blockquote>`, {
          parse_mode: 'HTML'
        });
      }

      let settingsContent = fs.readFileSync(configPath, 'utf8');
      const regex = new RegExp(`${key}\\s*=\\s*['"\`].*?['"\`]`, 's');

      if (regex.test(settingsContent)) {
        settingsContent = settingsContent.replace(regex, `${key} = '${text}'`);
        fs.writeFileSync(configPath, settingsContent, 'utf8');

        if (command.startsWith('seturl')) {
          global[`domain${serverVersion ? serverVersion.toUpperCase() : ''}`] = text;
        } else if (command.startsWith('setplta')) {
          global[`plta${serverVersion ? serverVersion.toUpperCase() : ''}`] = text;
        } else if (command.startsWith('setpltc')) {
          global[`pltc${serverVersion ? serverVersion.toUpperCase() : ''}`] = text;
        }

        reply(`<blockquote>✅ Nilai untuk <b>${key}</b> berhasil diubah menjadi: <code>${text}</code></blockquote>`, {
          parse_mode: 'HTML'
        });
      } else {
        reply(`<blockquote>❌ Variabel <b>${key}</b> tidak ditemukan di file settings.js.</blockquote>`, {
          parse_mode: 'HTML'
        });
      }
    }
    break;

      case "installdepend": {
        if (!isOwner) return reply(mess.owner);

        if (!text || !text.includes(',')) {
            return reply("<blockquote>⚠️ Format: <code>/installdepend IpVps,PwVps</code></blockquote>", { parse_mode: 'HTML' });
        }

        const [ipvps, passwd] = text.split(",").map(item => item.trim());
        if (!ipvps || !passwd) {
            return reply("<blockquote>⚠️ Format: <code>/installdepend IpVps,PwVps</code></blockquote>", { parse_mode: 'HTML' });
        }
        

        const safeEdit = async (chatId, messageId, newText) => {
             try {
                 await xy.api.editMessageText(chatId, messageId, newText, { parse_mode: "HTML" });
             } catch (e) {

                 if (!e.message.includes('message is not modified')) {
                     console.error('Telegram editMessage error:', e.message);
                 }
             }
         };

        const loadingMsg = await reply("<blockquote>🔍 <b>Memeriksa koneksi VPS...</b></blockquote>", { reply_to_message_id: xy.message.message_id, parse_mode: 'HTML' });

        const connSettings = {
            host: ipvps,
            port: 22,
            username: "root",
            password: passwd,
            readyTimeout: 15000
        };

        const commandSSH = `bash <(curl -s https://raw.githubusercontent.com/KiwamiXq1031/installer-premium/refs/heads/main/zero.sh)`;
        const conn = new Client();
        
        let logs = "🔍 <b>Memeriksa koneksi VPS...</b>";

        conn
            .on("ready", async () => {
                logs = `✅ Koneksi Berhasil!
Silahkan tunggu 10-20 menit...

⏳ <b>MEMPROSES INSTALL DEPENDENSI</b>`;
                await safeEdit(xy.chat.id, loadingMsg.message_id, `<blockquote>${logs}</blockquote>`);

                conn.exec(commandSSH, (err, stream) => {
                    if (err) {
                        safeEdit(xy.chat.id, loadingMsg.message_id, `<blockquote>❌ GAGAL MENG-EKSEKUSI COMMAND!</blockquote>`);
                        return conn.end();
                    }

                    let progressUpdated = false;

                    stream
                        .on("close", async () => {
                            try {
                                await xy.api.deleteMessage(xy.chat.id, loadingMsg.message_id);
                                await reply(`<blockquote>✅ <b>BERHASIL INSTALL DEPENDENSI!</b>\n\nVPS: <code>${ipvps}</code></blockquote>`, { parse_mode: 'HTML' });
                            } catch (error) {
                                console.error('Delete message error:', error.message);
                            }
                            conn.end();
                        })
                              .on("data", (data) => {
                            const output = data.toString();
                            console.log("OUTPUT:", output);
                            
                            // Logika untuk mendeteksi menu (seperti yang terlihat di gambar)
                            if (!progressUpdated && output.includes("INSTALLER") && output.includes("PTERODACTYL")) {
                                logs = "📦 MEMASUKKAN PILIHAN '13' (INSTALL DEPENDENSI)...";
                                safeEdit(xy.chat.id, loadingMsg.message_id, `<blockquote>${logs}</blockquote>`);
                                progressUpdated = true;
                                stream.write("13\n"); // <-- KIRIM PILIHAN 13 DI SINI
                            }
                            
                            // Logika untuk konfirmasi (jika ada) - disesuaikan dari logika install.js
                            if (output.includes("Pilih opsi lain") || output.includes("y/n") || output.includes("Y/n")) {
                                stream.write("Y\n"); // 
                            }

                            //

                        })
                        .stderr.on("data", (data) => {
                            console.log("STDERR:", data.toString());
                        });
                });
            })
            .on("error", async (err) => {
                console.error("SSH Error:", err.message);
                await safeEdit(xy.chat.id, loadingMsg.message_id, `<blockquote>❌ <b>Kata sandi/IP tidak valid!</b>\n\nError: <code>${err.message}</code></blockquote>`);
            })
            .on("end", () => {
                console.log("SSH Connection closed");
            })
            .connect(connSettings);
        
        break;
    }

    case "hello":
      reply("<blockquote>Hello juga!</blockquote>", {
        parse_mode: 'HTML'
      });
      break;

    case "autocpuon":
    case "autocpuonv2":
    case "autocpuonv3":
    case "autocpuonv4":
    case "autocpuoff":
    case "autocpuoffv2":
    case "autocpuoffv3":
    case "autocpuoffv4": {
      if (!isOwner) return reply(mess.owner);

      const serverVersion = command.endsWith('v2') ? 'v2' : command.endsWith('v3') ? 'v3' : command.endsWith('v4') ? 'v4' : 'v1';
      const action = command.includes('on');
      const file = CPU_CHECK_STATUS_FILE;
      let statusData = readJson(file, {});

      if (!statusData[serverVersion]) {
          
          statusData[serverVersion] = { active: false, auto_stop: {}, chat_id: null };
      }


      if (action) {

          if (xy.chat.type === 'group' || xy.chat.type === 'supergroup') { 
              statusData[serverVersion].chat_id = xy.chat.id;
          } else if (!statusData[serverVersion].chat_id) {

              return reply(`<blockquote>❌ Fitur Auto-Check CPU & Auto-Stop untuk <b>Server ${serverVersion.toUpperCase()}</b> tidak dapat diaktifkan tanpa ID Grup. Harap jalankan perintah ini di dalam Grup atau tentukan ID tujuan secara manual.</blockquote>`, { parse_mode: 'HTML' });
          }
      } else {

          statusData[serverVersion].chat_id = null;
      }

      statusData[serverVersion].active = action;
      writeJson(file, statusData);


      const statusText = action ? 'DIAKTIFKAN' : 'DINONAKTIFKAN';
      const emoji = action ? '✅' : '❌';
      const destinationText = action && statusData[serverVersion].chat_id ? `Notifikasi akan dikirim ke Grup tempat perintah ini terakhir dijalankan.` : '';
      
      const info = `
        ${emoji} Fitur Auto-Check CPU & Auto-Stop untuk <b>Server ${serverVersion.toUpperCase()}</b> berhasil <b>${statusText}</b>!

        Bot akan mengecek CPU setiap 10 menit dan menghentikan server yang melebihi batas wajar (sekitar 80%) secara otomatis.
        ${destinationText}
      `;

      reply(`<blockquote>${info}</blockquote>`, { parse_mode: 'HTML' });
      if (!action) {
          setTimeout(() => {
              checkAndStopAbnormalCpu(xy.api);
          }, 2000); 
      }
      break;
    }



                case 'cekid': {
      let targetId = null;
      let targetUser = null;
      const targetIdInput = text.trim();
      const msg = xy.message;


      if (targetIdInput && /^\d+$/.test(targetIdInput)) {
        targetId = targetIdInput;
      } else if (msg.reply_to_message) {
        targetUser = msg.reply_to_message.from;
        targetId = String(targetUser.id);
        
        if (msg.reply_to_message.forward_from) {
             targetUser = msg.reply_to_message.forward_from;
             targetId = String(targetUser.id);
        }
      } else {
        targetUser = xy.from;
        targetId = String(targetUser.id);
      }
      
      if (!targetId) {
          return reply(`<blockquote>❌ ID target tidak valid. Harap gunakan format: <code>/cekidtele ID_TELEGRAM</code> atau reply pesan pengguna.</blockquote>`, { parse_mode: 'HTML' });
      }

      
      const sentMessage = await reply(`<blockquote>⏳ <b>Membuat Kartu ID untuk ${targetId}...</b></blockquote>`, { parse_mode: 'HTML' });

      (async () => {
        const userIdStr = String(targetId);
        let fullName = '';
        let username = '-';
        let today = new Date().toISOString().split('T')[0];
        let dcId = (parseInt(targetId) >> 32) % 256;
        let photoUrl = null; 


        if (!targetUser) {
            try {
                targetUser = await xy.api.getChat(targetId);
            } catch (e) {

            }
        }

        if (targetUser) {
            fullName = `${targetUser.first_name || ''} ${targetUser.last_name || ''}`.trim();
            username = targetUser.username ? `@${targetUser.username}` : '-';
            
            try {
                const photos = await xy.api.getUserProfilePhotos(targetId, { limit: 1 });
                if (photos.total_count > 0) {
                    const fileId = photos.photos[0][0].file_id; 
                    const file = await xy.api.getFile(fileId);
                    photoUrl = `https://api.telegram.org/file/bot${botToken}/${file.file_path}`; 
                }
            } catch (e) {
                console.log('Gagal ambil foto profil (cekidtele):', e.message);
            }
        } else {
            fullName = `ID: ${targetId}`;
        }
        
    
        const isSellerRole = checkUserRole(targetId, ['seller'], '');
        const isOwnerRole = checkUserRole(targetId, ['owner'], '');
        const botRole = isOwnerRole ? 'Owner' : isSellerRole ? 'Seller' : 'User';
        

        const canvas = createCanvas(800, 450);
        const ctx = canvas.getContext('2d');

        const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
        gradient.addColorStop(0, '#0a4f44');
        gradient.addColorStop(1, '#128C7E');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
        
        if (typeof ctx.roundRect !== 'function') {
             ctx.beginPath();
             ctx.rect(40, 40, canvas.width - 80, canvas.height - 80);
             ctx.closePath();
        } else {
             ctx.roundRect(40, 40, canvas.width - 80, canvas.height - 80, 20);
        }
        ctx.fill();

        ctx.fillStyle = '#0a4f44';
        ctx.font = 'bold 32px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('ID CARD TELEGRAM', canvas.width / 2, 80);

        ctx.strokeStyle = '#0a4f44';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(50, 100);
        ctx.lineTo(canvas.width - 50, 100);
        ctx.stroke();

        if (photoUrl) {
            try {
                const response = await axios.get(photoUrl, { responseType: 'arraybuffer' });
                const avatar = await loadImage(Buffer.from(response.data));
                
                ctx.save();
                ctx.beginPath();
                ctx.arc(150, 220, 70, 0, Math.PI * 2, true);
                ctx.closePath();
                ctx.clip();
                
                ctx.drawImage(avatar, 80, 150, 140, 140);
                ctx.restore();
                
                ctx.strokeStyle = '#0a4f44';
                ctx.lineWidth = 3;
                ctx.beginPath();
                ctx.arc(150, 220, 70, 0, Math.PI * 2, true);
                ctx.stroke();
            } catch (e) {
                console.log('Gagal memuat gambar (canvas):', e.message);
                ctx.fillStyle = '#ccc';
                ctx.beginPath();
                ctx.arc(150, 220, 70, 0, Math.PI * 2, true);
                ctx.fill();
            }
        } else {
            ctx.fillStyle = '#ccc';
            ctx.beginPath();
            ctx.arc(150, 220, 70, 0, Math.PI * 2, true);
            ctx.fill();
        }

        ctx.textAlign = 'left';
        ctx.fillStyle = '#333';
        ctx.font = 'bold 24px Arial';
        ctx.fillText('Informasi Pengguna:', 280, 150);
        
        ctx.font = '20px Arial';
        ctx.fillText(`Nama: ${fullName}`, 280, 190);
        ctx.fillText(`User ID: ${targetId}`, 280, 220);
        ctx.fillText(`Username: ${username}`, 280, 250);
        ctx.fillText(`Tanggal: ${today}`, 280, 280);
        ctx.fillText(`Role Bot: ${botRole}`, 280, 310);
        
        

        const footerY = 410; 

        ctx.textAlign = 'center';
        ctx.font = 'italic 16px Arial';
        ctx.fillStyle = '#666';
        ctx.fillText(`ID Card by Jhonaley Tech`, canvas.width / 2, footerY);

        const buffer = canvas.toBuffer('image/png');
        
        const caption = `
👤 *Nama         :* ${fullName}
🆔️ *User ID      :* \`${targetId}\`
🌐 *Username :* ${username}
   `;


        await xy.api.sendPhoto(xy.chat.id, new InputFile(buffer, 'id_card.png'), { 
            caption, 
            parse_mode: "Markdown",
            reply_to_message_id: xy.message.message_id,
            reply_markup: {
                inline_keyboard: [
                    [{ text: "ʙᴜʏ ꜱᴄʀɪᴘᴛ", url: `https://t.me/ResellerGamingoffcial` }]
                ]
            }
        });


        await xy.api.deleteMessage(xy.chat.id, sentMessage.message_id);
        
      })();
      break;
    }


        case 'addgrub': {
      if (!isOwner) return reply(mess.owner);

      const targetId = text.trim();
      if (!targetId || !/^-?\d+$/.test(targetId)) {
        return reply('<blockquote>❌ Format salah!\n\nPenggunaan: <code>/addgrub [ID Grup]</code></blockquote>', { parse_mode: 'HTML' });
      }

      const file = ALLOWED_GROUPS_FILE;
      let listData = readJson(file);

      if (listData.some(g => String(g.id) === targetId)) {
        return reply(`<blockquote>⚠️ Grup ID <b>${targetId}</b> sudah terdaftar sebagai grup yang diizinkan.</blockquote>`, { parse_mode: 'HTML' });
      }
      
      const sentMessage = await reply(`<blockquote>⏳ <b>Mencoba mengambil nama grup untuk ID ${targetId}...</b></blockquote>`, { parse_mode: 'HTML' });

      let groupName = `ID: ${targetId}`;
      try {

          const chatInfo = await xy.api.getChat(targetId);
          groupName = chatInfo.title || `Grup Tanpa Nama (ID: ${targetId})`;
      } catch (e) {
          console.error(`Gagal mendapatkan info grup ${targetId}:`, e.message);
          
          groupName = `Grup Tidak Dikenal (ID: ${targetId})`;
      }

      listData.push({ id: targetId, name: groupName, added_by: xy.from.id, date: new Date().toISOString() });
      writeJson(file, listData);
      
      await editReply(xy, sentMessage.message_id, `<blockquote>✅ Grup <b>${groupName}</b> (ID: <code>${targetId}</code>) berhasil ditambahkan ke daftar grup yang diizinkan.</blockquote>`);
    }
    break;
    

case 'delgrub': {
    if (!isOwner) return reply(mess.owner); // Hanya Owner
    
    const targetId = text.trim();
    if (!targetId || !/^-?\d+$/.test(targetId)) {
        return reply('<blockquote>❌ Format salah!\n\nPenggunaan: <code>/delgrub [ID Grup]</code> (Bisa di Private Chat)</blockquote>', { parse_mode: 'HTML' });
    }

    const isCurrentGroup = String(xy.chat.id) === targetId;
    const file = ALLOWED_GROUPS_FILE;
    let listData = readJson(file);
    
    const initialLength = listData.length;
    listData = listData.filter(g => String(g.id) !== targetId);

    if (listData.length === initialLength) {
        return reply(`<blockquote>⚠️ ID Grup <b>${targetId}</b> tidak ditemukan dalam daftar grup yang diizinkan.</blockquote>`, { parse_mode: 'HTML' });
    }

    writeJson(file, listData);
    
    let finalMsg = `✅ Grup ID <b>${targetId}</b> telah dihapus dari daftar yang diizinkan.`;
    

    try {
        await xy.api.leaveChat(targetId);
        finalMsg += `\n\n✅ Bot berhasil keluar dari grup <b>${targetId}</b>.`;
    } catch (e) {
        console.error(`Gagal keluar paksa dari grup ${targetId}:`, e.message);
        finalMsg += `\n\n⚠️ Gagal memaksa bot keluar dari grup <b>${targetId}</b>.\n(Pesan: Bot mungkin bukan admin di sana, atau ID salah).`;
        
        
        if (isCurrentGroup) {
            finalMsg += `\n\n[Eksekusi terjadi di grup ini.]`;
        }
    }
    reply(`<blockquote>${finalMsg}</blockquote>`, { parse_mode: 'HTML' });
}
break;

    
     case 'listgrub': {
      if (!isOwner) return reply(mess.owner);

      const file = ALLOWED_GROUPS_FILE;
      const listData = readJson(file);

      if (listData.length === 0) return reply('<blockquote>🚫 Belum ada grup yang diizinkan yang terdaftar.</blockquote>', { parse_mode: 'HTML' });
      
      const sentMessage = await reply(`<blockquote>⏳ <b>Memuat daftar Grup yang Diizinkan...</b></blockquote>`, { parse_mode: 'HTML' });

      (async () => {
        let list = [];
        for (let g of listData) {
          list.push(`🆔 <b>ID:</b> <code>${g.id}</code>\n📁 <b>Nama:</b> ${g.name || 'Tidak Dikenal'}\n`);
        }

        const daftar = `📜 <b>Daftar Grup yang Diizinkan:</b> (${listData.length} grup)\n\n${list.join('\n')}`;
        await editReply(xy, sentMessage.message_id, `<blockquote>${daftar}</blockquote>`);
      })();
      break;
    }

    case 'addowner': {
      if (!isOwner) return reply(mess.owner);
      if (!text) return reply('<blockquote>📌 Penggunaan yang benar:\n/addowner ID_Telegram\n(ID harus berupa angka).</blockquote>', {
        parse_mode: 'HTML'
      });

      if (owners.includes(text)) {
        return reply(`<blockquote>⚠️ ID Telegram ${text} sudah menjadi Owner.</blockquote>`, {
          parse_mode: 'HTML'
        });
      }

      owners.push(text);
      fs.writeFileSync('./owner.json', JSON.stringify(owners, null, 2));
      return reply(`<blockquote>✅ ID Telegram ${text} telah ditambahkan ke daftar Owner!</blockquote>`, {
        parse_mode: 'HTML'
      });
    }

    case 'delowner': {
      if (!isOwner) return reply(mess.owner);
      if (!text) return reply('<blockquote>📌 Penggunaan:\n/delowner ID_Telegram\nContoh: /delowner 1234567890</blockquote>', {
        parse_mode: 'HTML'
      });

      const index = owners.indexOf(text);
      if (index !== -1) {
        owners.splice(index, 1);
        fs.writeFileSync('./owner.json', JSON.stringify(owners, null, 2));
        return reply(`<blockquote>✅ ID Telegram ${text} telah dihapus dari daftar Owner.</blockquote>`, {
          parse_mode: 'HTML'
        });
      } else {
        return reply(`<blockquote>⚠️ ID Telegram ${text} tidak ditemukan dalam daftar Owner.</blockquote>`, {
          parse_mode: 'HTML'
        });
      }
    }

    case 'listowner': {
      if (!isOwner) return reply(mess.owner);
      if (owners.length === 0) return reply('<blockquote>🚫 Belum ada Owner yang terdaftar.</blockquote>', {
        parse_mode: 'HTML'
      });
      const sentMessage = await reply(`<blockquote>⏳ <b>Memuat daftar Owner...</b></blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        let list = [];
        for (let id of owners) {
          try {
            const user = await xy.api.getChat(id);
            const name = [user.first_name, user.last_name].filter(Boolean).join(' ');
            list.push(`🆔 <b>ID:</b> ${id}\n👑 <b>Nama:</b> ${name}`);
          } catch (e) {
            list.push(`🆔 <b>ID:</b> ${id}\n👑 <b>Nama:</b> Tidak ditemukan`);
          }
        }

        const daftar = `📜 <b>Daftar Owner:</b>\n\n${list.join('\n\n')}`;
        await editReply(xy, sentMessage.message_id, `<blockquote>${daftar}</blockquote>`);
      })();
      break;
    }

    case 'addseller':
      if (!isOwner) return reply(mess.owner);

      if (!text) return reply('<blockquote>Penggunaan: /addseller ID,durasi,waktu</blockquote>', {
        parse_mode: 'HTML'
      });

      const [id, dur, unit] = text.split(',');
      if (!id || !dur || !unit) return reply('<blockquote>Format salah! Contoh: /addseller 123456789,1,jam</blockquote>', {
        parse_mode: 'HTML'
      });

      const ms = {
        menit: 60000,
        jam: 3600000,
        hari: 86400000,
        bulan: 2592000000
      };

      const durasi = parseInt(dur);
      if (isNaN(durasi) || !ms[unit]) return reply('<blockquote>Durasi tidak valid atau waktu tidak dikenali.</blockquote>', {
        parse_mode: 'HTML'
      });

      if (seller.some(s => s.id === id)) return reply(`<blockquote>ID ${id} sudah jadi seller.</blockquote>`, {
        parse_mode: 'HTML'
      });

      seller.push({
        id,
        expiresAt: Date.now() + durasi * ms[unit]
      });
      fs.writeFileSync('./src/database/seller.json', JSON.stringify(seller, null, 2));
      return reply(`<blockquote>ID ${id} ditambahkan selama ${durasi} ${unit}.</blockquote>`, {
        parse_mode: 'HTML'
      });
      break;

    case 'delseller':
      if (!isOwner) return reply(mess.owner);
      if (!text) return reply('<blockquote>Penggunaan: /delseller ID</blockquote>', {
        parse_mode: 'HTML'
      });

      const index = seller.findIndex(s => s.id === text);
      if (index === -1) return reply(`<blockquote>ID ${text} tidak ditemukan.</blockquote>`, {
        parse_mode: 'HTML'
      });

      seller.splice(index, 1);
      fs.writeFileSync('./src/database/seller.json', JSON.stringify(seller, null, 2));
      return reply(`<blockquote>ID ${text} telah dihapus.</blockquote>`, {
        parse_mode: 'HTML'
      });
      break;

    case 'listseller': {
      if (!isOwner) return reply(mess.owner);
      if (!seller.length) return reply('<blockquote>Belum ada seller.</blockquote>', {
        parse_mode: 'HTML'
      });

      const sentMessage = await reply(`<blockquote>⏳ <b>Memuat daftar Seller...</b></blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        let list = [];
        let updatedSeller = [...seller];

        for (let s of updatedSeller) {
          const sisa = s.expiresAt - Date.now();
          if (sisa <= 0) {
            updatedSeller = updatedSeller.filter(x => x.id !== s.id);
            continue;
          }

          const jam = Math.floor(sisa / 3600000);
          const menit = Math.floor((sisa % 3600000) / 60000);
          const sisaWaktu = jam > 0 ? `${jam} jam ${menit} menit` : `${menit} menit`;

          try {
            const user = await xy.api.getChat(s.id);
            const nama = user.first_name + (user.last_name ? ' ' + user.last_name : '');
            list.push(`🆔 <b>ID:</b> ${s.id}\n👤 <b>Nama:</b> ${nama}\n⏳ <b>Waktu Tersisa:</b> ${sisaWaktu}`);
          } catch {
            list.push(`🆔 <b>ID:</b> ${s.id}\n👤 <b>Nama:</b> Tidak ditemukan\n⏳ <b>Waktu Tersisa:</b> ${sisaWaktu}`);
          }
        }

        fs.writeFileSync('./src/database/seller.json', JSON.stringify(updatedSeller, null, 2));

        if (list.length === 0) {
          return editReply(xy, sentMessage.message_id, `<blockquote>🚫 Belum ada seller yang aktif.</blockquote>`);
        }

        const responseText = `📜 <b>Daftar Seller:</b>\n\n${list.join('\n\n')}`;
        await editReply(xy, sentMessage.message_id, `<blockquote>${responseText}</blockquote>`);
      })();
      break;
    }

    case 'pt':
    case 'pt2':
    case 'pt3':
    case 'pt4':
    case 'rt':
    case 'rt2':
    case 'rt3':
    case 'rt4': {
      if (!isOwner) return reply(mess.owner);

      const isResellerCommand = command.startsWith('rt');
      const file = isResellerCommand ? './src/database/reseller.json' : './src/database/partner.json';
      const panelName = isResellerCommand ? 'Reseller Panel' : 'Partner Panel';
      const serverVersion = command.endsWith('2') ? 'v2' : command.endsWith('3') ? 'v3' : command.endsWith('4') ? 'v4' : 'v1';

      if (!xy.message.reply_to_message) {
        return reply(`<blockquote>❌ Balas pesan pengguna yang ingin di-add ke ${panelName}.</blockquote>`, {
          parse_mode: 'HTML'
        });
      }

      const userId = xy.message.reply_to_message.from.id;
      const userName = xy.message.reply_to_message.from.first_name || 'Pengguna';

      let listData = [];
      try {
        if (fs.existsSync(file)) {
          const fileContent = fs.readFileSync(file, 'utf8');
          listData = JSON.parse(fileContent);
          if (!Array.isArray(listData)) {
            listData = [];
          }
        }
      } catch (e) {
        console.error(`Error reading ${file}:`, e);
      }

      const existingUserIndex = listData.findIndex(u => u.id === userId && u.server === serverVersion);

      if (existingUserIndex !== -1) {
        return reply(`<blockquote>⚠️ Pengguna <b>${userName}</b> sudah terdaftar di ${panelName} server <b>${serverVersion}</b>.</blockquote>`, {
          parse_mode: 'HTML'
        });
      }

      listData.push({
        id: userId,
        server: serverVersion
      });
      fs.writeFileSync(file, JSON.stringify(listData, null, 2));

      return reply(`<blockquote>✅ Pengguna <b>${userName}</b> berhasil ditambahkan ke ${panelName} server <b>${serverVersion}</b>.</blockquote>`, {
        parse_mode: 'HTML'
      });
    }
    break;

    case 'addallrt': {
      if (!isOwner) return reply(mess.owner);

      if (!xy.message.reply_to_message) {
        return reply(`<blockquote>❌ Balas pesan pengguna yang ingin di-add ke semua Reseller Panel.</blockquote>`, {
          parse_mode: 'HTML'
        });
      }

      const userId = xy.message.reply_to_message.from.id;
      const userName = xy.message.reply_to_message.from.first_name || 'Pengguna';
      const resellerFile = './src/database/reseller.json';
      const servers = ['v1', 'v2', 'v3', 'v4'];
      let addedCount = 0;

      let listData = [];
      try {
        if (fs.existsSync(resellerFile)) {
          const fileContent = fs.readFileSync(resellerFile, 'utf8');
          listData = JSON.parse(fileContent);
          if (!Array.isArray(listData)) {
            listData = [];
          }
        }
      } catch (e) {
        console.error(`Error reading ${resellerFile}:`, e);
      }

      for (const server of servers) {
        const existingUserIndex = listData.findIndex(u => u.id === userId && u.server === server);
        if (existingUserIndex === -1) {
          listData.push({
            id: userId,
            server: server
          });
          addedCount++;
        }
      }

      if (addedCount > 0) {
        fs.writeFileSync(resellerFile, JSON.stringify(listData, null, 2));
        return reply(`<blockquote>✅ Pengguna <b>${userName}</b> berhasil ditambahkan ke ${addedCount} Reseller Panel!</blockquote>`, {
          parse_mode: 'HTML'
        });
      } else {
        return reply(`<blockquote>⚠️ Pengguna <b>${userName}</b> sudah terdaftar di semua Reseller Panel.</blockquote>`, {
          parse_mode: 'HTML'
        });
      }
    }
    break;
    
          case 'addallpt': {
      if (!isOwner) return reply(mess.owner);

      if (!xy.message.reply_to_message) {
        return reply(`<blockquote>❌ Balas pesan pengguna yang ingin di-add ke semua Partner Panel.</blockquote>`, {
          parse_mode: 'HTML'
        });
      }

      const userId = xy.message.reply_to_message.from.id;
      const userName = xy.message.reply_to_message.from.first_name || 'Pengguna';
      const partnerFile = './src/database/partner.json';
      const servers = ['v1', 'v2', 'v3', 'v4'];
      let addedCount = 0;

      let listData = [];
      try {
        if (fs.existsSync(partnerFile)) {
          const fileContent = fs.readFileSync(partnerFile, 'utf8');
          listData = JSON.parse(fileContent);
          if (!Array.isArray(listData)) {
            listData = [];
          }
        }
      } catch (e) {
        console.error(`Error reading ${partnerFile}:`, e);
      }

      for (const server of servers) {
        const existingUserIndex = listData.findIndex(u => u.id === userId && u.server === server);
        if (existingUserIndex === -1) {
          listData.push({
            id: userId,
            server: server
          });
          addedCount++;
        }
      }

      if (addedCount > 0) {
        fs.writeFileSync(partnerFile, JSON.stringify(listData, null, 2));
        return reply(`<blockquote>✅ Pengguna <b>${userName}</b> berhasil ditambahkan ke ${addedCount} Partner Panel!</blockquote>`, {
          parse_mode: 'HTML'
        });
      } else {
        return reply(`<blockquote>⚠️ Pengguna <b>${userName}</b> sudah terdaftar di semua Partner Panel.</blockquote>`, {
          parse_mode: 'HTML'
        });
      }
    }
    break;

      case 'delallpt':
    case 'delallrt': {
      if (!isOwner) return reply(mess.owner);

      const isPartnerCommand = command === 'delallpt';

      const file = isPartnerCommand ? './src/database/partner.json' : './src/database/reseller.json'; 
      const roleName = isPartnerCommand ? 'Partner' : 'Reseller';
      
      let listData = readJson(file);
      
      if (listData.length === 0) {
        return reply(`<blockquote>⚠️ Tidak ada pengguna yang terdaftar sebagai <b>${roleName}</b>.</blockquote>`, {
          parse_mode: 'HTML'
        });
      }

      const initialCount = listData.length;
      
      // Hapus semua data (kosongkan array)
      listData = []; 
      writeJson(file, listData);

      return reply(`<blockquote>✅ Berhasil menghapus semua (${initialCount}) data <b>${roleName}</b> dari semua server (V1-4).</blockquote>`, {
        parse_mode: 'HTML'
      });
    }
    break;
   
    case 'delpt':
    case 'delpt2':
    case 'delpt3':
    case 'delpt4':
    case 'delrt':
    case 'delrt2':
    case 'delrt3':
    case 'delrt4': {
      if (!isOwner) return reply(mess.owner);

      const isResellerCommand = command.startsWith('delrt');
      const file = isResellerCommand ? './src/database/reseller.json' : './src/database/partner.json';
      const panelName = isResellerCommand ? 'Reseller Panel' : 'Partner Panel';
      const serverVersion = command.endsWith('2') ? 'v2' : command.endsWith('3') ? 'v3' : command.endsWith('4') ? 'v4' : 'v1';

      const replyToMessage = xy.message.reply_to_message;
      if (!replyToMessage) {
        return reply(`<blockquote>❌ Harap balas pesan pengguna yang ingin dihapus dari ${panelName}.</blockquote>`, {
          parse_mode: 'HTML'
        });
      }

      const userId = replyToMessage.from.id;
      const userName = replyToMessage.from.first_name || 'Pengguna';

      let listData = [];
      try {
        if (fs.existsSync(file)) {
          const fileContent = fs.readFileSync(file, 'utf8');
          listData = JSON.parse(fileContent);
          if (!Array.isArray(listData)) {
            listData = [];
          }
        }
      } catch (e) {
        console.error(`Error reading ${file}:`, e);
      }

      const initialLength = listData.length;
      listData = listData.filter(u => u.id !== userId || u.server !== serverVersion);

      if (listData.length === initialLength) {
        return reply(`<blockquote>⚠️ Pengguna <b>${userName}</b> (ID: ${userId}) tidak ditemukan di ${panelName} server <b>${serverVersion}</b>.</blockquote>`, {
          parse_mode: 'HTML'
        });
      }

      fs.writeFileSync(file, JSON.stringify(listData, null, 2));

      return reply(`<blockquote>✅ Pengguna <b>${userName}</b> (ID: ${userId}) berhasil dihapus dari ${panelName} server <b>${serverVersion}</b>.</blockquote>`, {
        parse_mode: 'HTML'
      });
    }
    break;

    case 'listpt':
    case 'listrt': {
      if (!isOwner) return reply(mess.owner);

      const isResellerCommand = command.startsWith('listrt');
      const file = isResellerCommand ? './src/database/reseller.json' : './src/database/partner.json';
      const panelName = isResellerCommand ? 'Reseller Panel' : 'Partner Panel';

      let listData = [];
      try {
        if (fs.existsSync(file)) {
          const fileContent = fs.readFileSync(file, 'utf8');
          listData = JSON.parse(fileContent);
          if (!Array.isArray(listData)) {
            listData = [];
          }
        }
      } catch (e) {
        console.error(`Error reading ${file}:`, e);
      }

      if (listData.length === 0) {
        return reply(`<blockquote>🚫 Belum ada pengguna yang terdaftar di ${panelName}.</blockquote>`, {
          parse_mode: 'HTML'
        });
      }

      const sentMessage = await reply(`<blockquote>⏳ <b>Memuat daftar ${panelName}...</b></blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        const servers = ['v1', 'v2', 'v3', 'v4'];
        let message = `📜 <b>Daftar ${panelName}:</b>\n\n`;

        for (const server of servers) {
          const usersOnServer = listData.filter(u => u.server === server);
          if (usersOnServer.length > 0) {
            message += `<b>Server ${server}:</b>\n`;
            for (const user of usersOnServer) {
              try {
                const chat = await xy.api.getChat(user.id);
                const name = chat.first_name || 'Pengguna';
                message += `  - 🆔 ${user.id} (👤 ${name})\n`;
              } catch (e) {
                message += `  - 🆔 ${user.id} (👤 Tidak ditemukan)\n`;
              }
            }
            message += '\n';
          }
        }

        if (message.endsWith('\n\n')) {
          message = message.slice(0, -2);
        }

        await editReply(xy, sentMessage.message_id, `<blockquote>${message}</blockquote>`);
      })();
      break;
    }


    case "hbpanel":
    case "hackbackpanel": { 
      if (!isOwner) return reply(mess.owner);
      

      if (!text || !text.includes(',')) return reply("<blockquote>❌ Format salah! Harap gunakan: <code>/hbpanel ipvps,pwvps</code></blockquote>", { 
        parse_mode: 'HTML'
      });

      const sentMessage = await reply(`<blockquote>🔄 <b>Memulai proses SSH untuk HACKBACKPANEL...</b> (Ini akan memakan waktu)</blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        let [vpsIP, vpsPassword] = text.split(',').map(a => a.trim());
        let finalMessage = `✅ <b>Proses HACKBACKPANEL Selesai!</b>`;
        const ssh = new Client();
        const connSettings = {
          host: vpsIP,
          port: 22,
          username: 'root',
          password: vpsPassword,
          readyTimeout: 15000 
        };
        let connectionError = null;
        

        const commandClearCache = `cd /var/www/pterodactyl && php artisan cache:clear && php artisan config:clear`;
        

        const newuser = "admin" + generateReadableString(4);
        const newpw = "admin" + generateReadableString(4);

        try {
          await new Promise((resolve, reject) => {
            ssh.on('ready', resolve).on('error', reject).connect(connSettings);
          });
          
          
          await editReply(xy, sentMessage.message_id, `<blockquote>🔄 <b>Membuat Admin Panel Baru via Artisan Command...</b>\n\nIP: <code>${vpsIP}</code>\n<b>Username Baru:</b> <code>${newuser}</code>\n<b>Password Baru:</b> <code>${newpw}</code></blockquote>`);

          const artisanCommand = `
            cd /var/www/pterodactyl && 
            php artisan p:user:make \\
              --email="${newuser}@jhonhack.net" \\
              --username="${newuser}" \\
              --name-first="Hack" \\
              --name-last="Back" \\
              --password="${newpw}" \\
              --admin=1
          `;
            
          let outputArtisan = '';
          await new Promise((resolve, reject) => {
              ssh.exec(artisanCommand, (err, stream) => {
                  if (err) return reject(err);

                  stream.on('close', (code) => {
                      if (code !== 0) {
                          reject(new Error(`Artisan command failed with code ${code}. Output: ${outputArtisan.substring(0, 4000)}`));
                      } else {
                          resolve();
                      }
                  }).on('data', (data) => {
                      outputArtisan += data.toString();
                      if (data.toString().includes("successfully created")) {

                      }
                  }).stderr.on('data', (data) => {
                      outputArtisan += data.toString();
                  });
              });
          });



          await editReply(xy, sentMessage.message_id, `<blockquote>🔄 <b>Admin berhasil dibuat. Membersihkan cache Panel...</b>\n\nIP: <code>${vpsIP}</code></blockquote>`);
          
          let cacheOutput = '';
          await new Promise((resolve, reject) => {
              ssh.exec(commandClearCache, (err, stream) => {
                  if (err) return reject(err);
                  stream.on('close', (code) => {
                      if (code !== 0) {
                          reject(new Error(`Clear cache gagal dengan kode ${code}. Output: ${cacheOutput.substring(0, 4000)}`));
                      } else {
                          resolve();
                      }
                  }).on('data', (data) => {
                      cacheOutput += data.toString();
                  });
              });
          });

          finalMessage = `
✅ <b>Hackback Panel di VPS ${vpsIP} berhasil dan cache Panel telah dibersihkan!</b>

Sekarang coba login kembali dengan detail berikut:
* <b>Username :</b> <code>${newuser}</code>
* <b>Password :</b> <code>${newpw}</code>
`;
        finalMessage = `<blockquote>${finalMessage}</blockquote>`;

        } catch (err) {
          connectionError = err;
          

          const errorMsg = err.message.toLowerCase();
          if (errorMsg.includes("user with that username already exists")) {
            connectionError.message = `Gagal: Username <code>${newuser}</code> sudah ada. Coba lagi!`;
          } else if (errorMsg.includes("user with that email address already exists")) {
            connectionError.message = `Gagal: Email <code>${newuser}@jhonhack.net</code> sudah ada. Coba lagi!`;
          } else {
            console.error(`❌ SSH Error ${command.toUpperCase()}:`, err.message);
          }
          
        } finally {
          ssh.end();
        }

        if (connectionError) {
          await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal menjalankan perintah ${command.toUpperCase()}: ${connectionError.message || 'Koneksi SSH gagal. Pastikan IP dan password benar.'}</blockquote>`);
        } else {
          await editReply(xy, sentMessage.message_id, finalMessage);
        }
      })();
      break;
    }
    
    case "cadp":
    case "cadpv2":
    case "cadpv3":
    case "cadpv4": {
      if (xy.chat.type === 'private') {
        return reply(mess.group);
      }

      const serverVersion = command.endsWith('v2') ? 'v2' : command.endsWith('v3') ? 'v3' : command.endsWith('v4') ? 'v4' : 'v1';
      const userId = xy.from.id;

      if (!checkUserRole(userId, ['owner', 'partner'], serverVersion)) {
        return reply(mess.owner);
      }

      const panelConfig = getPanelConfig(serverVersion);
      if (!text || text.split(",").length < 3) return reply(`<blockquote><b>Format salah!</b>\n\nPenggunaan:\n${prefix + command} sendwa/sendtele,nama,nomor_telepon</blockquote>`, {
        parse_mode: 'HTML'
      });

      const sentMessage = await reply(`<blockquote>⏳ <b>Sedang membuat Admin Panel...</b></blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        const [sendType, username, targetNumberRaw] = text.split(",").map(a => a.trim());
        const targetNumber = targetNumberRaw.replace(/[^0-9]/g, "");
        const {
          panelDomain,
          pltaKey
        } = panelConfig;

        if (!["sendwa", "sendtele"].includes(sendType)) {
          return editReply(xy, sentMessage.message_id, "<blockquote>Pilihan pengiriman hanya boleh 'sendwa' atau 'sendtele'.</blockquote>");
        }

        let password = Math.random().toString(36).slice(-8);
        let email = username + "@janda.duda";
        let user; 
        try {
          try {
            const checkResponse = await fetch(`${panelDomain}/api/application/users/email/${email}`, {
              method: "GET",
              headers: {
                Accept: "application/json",
                Authorization: `Bearer ${pltaKey}`
              }
            });

            if (checkResponse.ok) {
              
              throw new Error("Email atau Username sudah digunakan!");
            } else if (checkResponse.status !== 404) {
              
              throw new Error(`API Check Error: Status ${checkResponse.status}`);
            }
           

          } catch (error) {
            
            if (error.message !== "Email atau Username sudah digunakan!") throw error;
            else throw new Error("Email atau Username sudah digunakan!");
          }
          let f = await fetch(`${panelDomain}/api/application/users`, {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: `Bearer ${pltaKey}`
            },
            body: JSON.stringify({
              email: email,
              username: username,
              first_name: username,
              last_name: username,
              language: "en",
              root_admin: true,
              password: password.toString()
            })
          });

          let data = await f.json();
          if (data.errors) throw new Error(`API Error: ${data.errors[0].detail}`);
          user = data.attributes; 

          let messageToTarget = `
✓ Admin Panel Berhasil Dibuat

- <b>ID</b>: ${user.id}
- <b>EMAIL</b>: ${user.email}
- <b>USERNAME</b>: <code>${user.username}</code>
- <b>PASSWORD</b>: <code>${password.toString()}</code>
- <b>LOGIN</b>: ${panelDomain}

⚠️ Simpan informasi ini, kami hanya mengirimkan detail akun sekali.
`;

          if (sendType === "sendtele") {
            await xy.api.sendMessage(targetNumber, messageToTarget, {
              parse_mode: 'HTML'
            });
          } else if (sendType === "sendwa") {
            const sessionNumber = Array.from(sessions.keys())[0];
            const waClient = sessions.get(sessionNumber);
            if (!waClient) throw new Error(`Sesi WhatsApp ${sessionNumber} tidak ditemukan.`);
            const custwa = targetNumber.includes("@") ? targetNumber : `${targetNumber}@s.whatsapp.net`;
            await waClient.sendMessage(custwa, {
              text: messageToTarget
            });
          }
          let messageToSender = `✅ Admin <b>${username}</b> berhasil dibuat dan data telah dikirim ke <b>${sendType === "sendtele" ? "Telegram" : "WhatsApp"}</b> ${targetNumber}.\n\n<b>ID Pengguna Panel:</b> <code>${user.id}</code>`;
          await editReply(xy, sentMessage.message_id, `<blockquote>${messageToSender}</blockquote>`);

        } catch (error) {
          console.error("❌ CADP Error:", error.message);
          await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal membuat Admin Panel: ${error.message}</blockquote>`);
        }
      })();
      break;
    }
    
       case "clearall": { 
      if (!isOwner) return reply(mess.owner);
      if (!text || !text.includes(',')) return reply("<blockquote>❌ Format salah! Harap gunakan: <code>/clearall ipvps,pwvps</code></blockquote>", {
        parse_mode: 'HTML'
      });

      const sentMessage = await reply(`<blockquote>🔄 <b>Memulai proses SSH untuk ${command.toUpperCase()}...</b> (Ini akan memakan waktu)</blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        let [vpsIP, vpsPassword] = text.split(',').map(a => a.trim());
        let finalMessage = `✅ <b>Proses ${command.toUpperCase()} Selesai!</b>`;
        const ssh = new Client();
        const connSettings = {
          host: vpsIP,
          port: 22,
          username: 'root',
          password: vpsPassword
        };
        let connectionError = null;
        

        try {
          await new Promise((resolve, reject) => {
            ssh.on('ready', resolve).on('error', reject).connect(connSettings);
          });
          
          let output = '';
          
          await editReply(xy, sentMessage.message_id, `<blockquote>🔄 <b>Menghapus semua User dan Server di Panel Pterodactyl...</b>\n\n<i>Mohon tunggu, ini mungkin memerlukan beberapa detik.</i></blockquote>`);

        
          const cleanupCommand = `
            cd /var/www/pterodactyl && 
            php artisan tinker --execute="
              DB::statement('SET FOREIGN_KEY_CHECKS=0;'); 
              \\\\Pterodactyl\\\\Models\\\\User::query()->forceDelete(); 
              \\\\Pterodactyl\\\\Models\\\\Server::query()->forceDelete();
              DB::statement('SET FOREIGN_KEY_CHECKS=1;'); 
              echo 'Clear all berhasil dilakukan!';
            "
          `;
            
          await new Promise((resolve, reject) => {
              ssh.exec(cleanupCommand, (err, stream) => {
                  if (err) return reject(err);

                  stream.on('close', (code) => {
                      if (code !== 0) {
                          reject(new Error(`Command failed with code ${code}. Output: ${output.substring(0, 4000)}`));
                      } else {
                          resolve();
                      }
                  }).on('data', (data) => {
                      output += data.toString();
                  }).stderr.on('data', (data) => {
                      output += data.toString();
                  });
              });
          });


          finalMessage = `
✅ <b>Pterodactyl Panel di VPS ${vpsIP} berhasil DIBERSIHKAN (Semua User & Server Terhapus)!</b>

⚠️ <b>TINDAKAN:</b>
Disarankan untuk melakukan clear cache:
<code>cd /var/www/pterodactyl && php artisan cache:clear && php artisan config:clear</code>
`;

        } catch (err) {
          connectionError = err;
          console.error(`❌ SSH Error ${command.toUpperCase()}:`, err.message);
        } finally {
          ssh.end();
        }

        if (connectionError) {
          await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal menjalankan perintah ${command.toUpperCase()}: ${connectionError.message || 'Koneksi SSH gagal.'}</blockquote>`);
        } else {
          await editReply(xy, sentMessage.message_id, `<blockquote>${finalMessage}</blockquote>`);
        }
      })();
      break;
    }

    case "1gb":
    case "2gb":
    case "3gb":
    case "4gb":
    case "5gb":
    case "6gb":
    case "7gb":
    case "8gb":
    case "9gb":
    case "10gb":
    case "unli":
    case "1gbv2":
    case "2gbv2":
    case "3gbv2":
    case "4gbv2":
    case "5gbv2":
    case "6gbv2":
    case "7gbv2":
    case "8gbv2":
    case "9gbv2":
    case "10gbv2":
    case "unliv2":
    case "1gbv3":
    case "2gbv3":
    case "3gbv3":
    case "4gbv3":
    case "5gbv3":
    case "6gbv3":
    case "7gbv3":
    case "8gbv3":
    case "9gbv3":
    case "10gbv3":
    case "unliv3":
    case "1gbv4":
    case "2gbv4":
    case "3gbv4":
    case "4gbv4":
    case "5gbv4":
    case "6gbv4":
    case "7gbv4":
    case "8gbv4":
    case "9gbv4":
    case "10gbv4":
    case "unliv4": {
      if (xy.chat.type === 'private') {
        return reply(mess.group);
      }

      const serverVersion = command.match(/v\d/)?.[0] || 'v1';
      const userId = xy.from.id;

      if (!checkUserRole(userId, ['owner', 'seller', 'partner', 'reseller'], serverVersion)) {
        return reply(mess.seller);
      }

      const sentMessage = await reply(`<blockquote>⏳ <b>Sedang membuat Panel ${command.toUpperCase()}...</b></blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        const userInput = text;
        const commandType = command.replace(serverVersion, '');
        const panelConfig = getPanelConfig(serverVersion);
        const {
          panelDomain,
          pltaKey,
          pltcKey,
          nests,
          eggs,
          loc
        } = panelConfig;
        let ram, disk, cpu;

        switch (commandType) {
          case "1gb":
            ram = "1024";
            disk = "1024";
            cpu = "40";
            break;
          case "2gb":
            ram = "2048";
            disk = "2048";
            cpu = "60";
            break;
          case "3gb":
            ram = "3072";
            disk = "3072";
            cpu = "80";
            break;
          case "4gb":
            ram = "4096";
            disk = "4096";
            cpu = "100";
            break;
          case "5gb":
            ram = "5120";
            disk = "5120";
            cpu = "120";
            break;
          case "6gb":
            ram = "6144";
            disk = "6144";
            cpu = "140";
            break;
          case "7gb":
            ram = "7168";
            disk = "7168";
            cpu = "160";
            break;
          case "8gb":
            ram = "8192";
            disk = "8192";
            cpu = "180";
            break;
          case "9gb":
            ram = "9216";
            disk = "9216";
            cpu = "200";
            break;
          case "10gb":
            ram = "10240";
            disk = "10240";
            cpu = "220";
            break;
          case "unli":
            ram = "0";
            disk = "0";
            cpu = "0";
            break;
          default:
            return editReply(xy, sentMessage.message_id, "<blockquote>Perintah tidak valid.</blockquote>");
        }

        let t = userInput.split(",");
        if (t.length < 3) {
          return editReply(xy, sentMessage.message_id, `<blockquote><b>Format salah!</b>\n\nPenggunaan:\n${prefix + command} sendwa/sendtele,username,nowa/idtele</blockquote>`);
        }

        let [sendType, username, targetNumberRaw] = t.map(a => a.trim());
        const targetNumber = targetNumberRaw.replace(/\D/g, "");

        if (!["sendwa", "sendtele"].includes(sendType)) {
          return editReply(xy, sentMessage.message_id, "<blockquote>Pilihan pengiriman hanya boleh 'sendwa' atau 'sendtele'.</blockquote>");
        }

        if (!targetNumber.match(/^\d+$/)) {
          return editReply(xy, sentMessage.message_id, `<blockquote>ID tele / No. WA tujuan tidak valid.</blockquote>`);
        }

        let email = `${username}@jhonaley.net`;
        let password = Math.random().toString(36).slice(-8);
        let user; 
        let server; 
        try {
          try {
            const checkResponse = await fetch(`${panelDomain}/api/application/users/email/${email}`, {
              method: "GET",
              headers: {
                Accept: "application/json",
                Authorization: `Bearer ${pltaKey}`
              }
            });

            if (checkResponse.ok) {
              
              throw new Error("Email atau Username sudah digunakan!");
            } else if (checkResponse.status !== 404) {
              
              throw new Error(`API Check Error: Status ${checkResponse.status}`);
            }

          } catch (error) {
            if (error.message !== "Email atau Username sudah digunakan!") throw error;
            else throw new Error("Email atau Username sudah digunakan!");
          }
          let f = await fetch(`${panelDomain}/api/application/users`, {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: `Bearer ${pltaKey}`
            },
            body: JSON.stringify({
              email: email,
              username: username,
              first_name: username,
              last_name: username,
              language: "en",
              password: password.toString()
            })
          });

          let userData = await f.json();
          if (userData.errors) throw new Error(`API Error: ${userData.errors[0].detail}`);
          user = userData.attributes; 
          
          let f2 = await fetch(`${panelDomain}/api/application/nests/${nests}/eggs/${eggs}`, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: `Bearer ${pltcKey}`
            }
          });
          let data2 = await f2.json();
          let startup_cmd = data2.attributes.startup;

          
          let f3 = await fetch(`${panelDomain}/api/application/servers`, {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: `Bearer ${pltcKey}`
            },
            body: JSON.stringify({
              name: username,
              description: "panel pterodactyl",
              user: user.id,
              egg: parseInt(eggs),
              docker_image: "ghcr.io/parkervcp/yolks:nodejs_23",
              startup: startup_cmd,
              environment: {
                INST: "npm",
                USER_UPLOAD: "0",
                AUTO_UPDATE: "0",
                CMD_RUN: "npm start",
                STARTUP_CMD: "pip install -r requirements.txt"
              },
              limits: {
                memory: ram,
                swap: 0,
                disk: disk,
                io: 500,
                cpu: cpu
              },
              feature_limits: {
                databases: 5,
                backups: 5,
                allocations: 5
              },
              deploy: {
                locations: [parseInt(loc)],
                dedicated_ip: false,
                port_range: []
              }
            })
          });

          let res = await f3.json();
          if (res.errors) throw new Error(`API Error: ${res.errors[0].detail}`);
          server = res.attributes; 
          let messageToTelegram = `
🎉 <b>Panel Berhasil Dibuat!</b>

🔹 <b>Detail Panel Anda:</b>
────────────────────
- <b>ID User</b>: ${user.id}
- <b>ID Server</b>: ${server.id}
- <b>EMAIL</b>: ${user.email}
- <b>USERNAME</b>: <code>${user.username}</code>
- <b>PASSWORD</b>: <code>${password.toString()}</code>
- <b>LOGIN</b>: <a href="${panelDomain}">Klik untuk login</a>
<pre>
⚠️ <b>PERHATIAN:</b>
────────────────────
Simpan informasi ini dengan baik, karena kami hanya mengirimkan detail akun sekali. Jika hilang, Anda bertanggung jawab atas data ini.
</pre>
`;

          let messageToWa = `
🎉 Panel Berhasil Dibuat!

🔹 Detail Panel Anda:
────────────────────
- ID User: ${user.id}
- ID Server: ${server.id}
- EMAIL: ${user.email}
- USERNAME: ${user.username}
- PASSWORD: ${password.toString()}
- LOGIN: ${panelDomain}

⚠️ PERHATIAN:
────────────────────
Simpan informasi ini dengan baik, karena kami hanya mengirimkan detail akun sekali. Jika hilang, Anda bertanggung jawab atas data ini.
`;

          
          if (sendType === "sendtele") {
            await xy.api.sendMessage(targetNumber, messageToTelegram, {
              parse_mode: 'HTML'
            });
          } else if (sendType === "sendwa") {
            const sessionNumber = Array.from(sessions.keys())[0];
            const waClient = sessions.get(sessionNumber);
            if (!waClient) throw new Error(`Sesi WhatsApp ${sessionNumber} tidak ditemukan.`);
            const custwa = targetNumber.includes("@") ? targetNumber : `${targetNumber}@s.whatsapp.net`;
            await waClient.sendMessage(custwa, {
              text: messageToWa
            });
          }


          let messageToSender = `✅ Panel untuk username <b>${username}</b> telah berhasil dibuat dan data telah dikirim ke <b>${sendType === "sendtele" ? "Telegram" : "WhatsApp"}</b> ${targetNumber}.\n\n<b>ID Server:</b> <code>${server.id}</code>`;
          await editReply(xy, sentMessage.message_id, `<blockquote>${messageToSender}</blockquote>`);

        } catch (error) {
          console.error("❌ Panel Creation Error:", error.message);
          await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal membuat Panel: ${error.message}</blockquote>`);
        }
      })();
      break;
    }
    
    case "totalserver":
    case "totalserverv2":
    case "totalserverv3":
    case "totalserverv4": {
      

      const serverVersion = command.endsWith('v2') ? 'v2' : command.endsWith('v3') ? 'v3' : command.endsWith('v4') ? 'v4' : 'v1';
      const panelConfig = getPanelConfig(serverVersion);
      
      const hasPanelAccess = checkUserRole(xy.from.id, ['owner', 'partner', 'reseller'], serverVersion);
      
      const domainDisplay = hasPanelAccess 
        ? panelConfig.panelDomain 
        : '***Domain disembunyikan***';

      if (!panelConfig.panelDomain || !panelConfig.pltaKey) {
        return reply(`<blockquote>❌ Konfigurasi <b>Server ${serverVersion.toUpperCase()}</b> tidak ditemukan atau API Key kosong.</blockquote>`, {
          parse_mode: 'HTML'
        });
      }

      const sentMessage = await reply(`<blockquote>⏳ <b>Menghitung total server di Panel ${serverVersion.toUpperCase()}...</b></blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        let currentServerCount = 0;
        let page = 1;
        let hasMore = true;

        try {
          
          while (hasMore) {
            const response = await axios.get(`${panelConfig.panelDomain}/api/application/servers?page=${page}`, {
              headers: {
                'Authorization': `Bearer ${panelConfig.pltaKey}`
              }
            });

            const result = response.data;
            currentServerCount += result.data.length;
            hasMore = result.meta.pagination.current_page < result.meta.pagination.total_pages;
            page++;
          }

          const summary = `
📜 <b>Total Server Panel ${serverVersion.toUpperCase()}</b>

🌐 <b>Domain:</b> ${domainDisplay}
📊 <b>Total Server:</b> <code>${currentServerCount} Server</code>
`;

          await editReply(xy, sentMessage.message_id, `<blockquote>${summary}</blockquote>`);

        } catch (err) {
          console.error(`Error mengambil total server ${serverVersion}:`, err.message);
          await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengambil total server dari Panel ${serverVersion.toUpperCase()}.\n\nError: API Panel tidak merespons atau API Key tidak valid.</blockquote>`);
        }
      })();
      break;
    }


    case 'info': {
      if (xy.chat.type === 'private') {
        return reply(`<blockquote>❌ Perintah ini hanya bisa digunakan di dalam grup.</blockquote>`, {
          parse_mode: 'HTML'
        });
      }


      let targetId = null;
      let targetUser = null;
      const targetIdInput = text.trim();

      if (targetIdInput && /^\d+$/.test(targetIdInput)) {

        targetId = targetIdInput;

      } else if (xy.message.reply_to_message) {

        targetUser = xy.message.reply_to_message.from;
        targetId = String(targetUser.id);
      } else {

        targetUser = xy.from;
        targetId = String(targetUser.id);
      }
      
      if (!targetId) {
          return reply(`<blockquote>❌ ID target tidak valid. Harap gunakan format: <code>/info ID_TELEGRAM</code> atau reply pesan pengguna.</blockquote>`, { parse_mode: 'HTML' });
      }

      const sentMessage = await reply(`<blockquote>⏳ <b>Mengecek status pengguna ID ${targetId}...</b></blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        const userIdStr = String(targetId);
        

        let nameToDisplay = `ID: ${targetId}`;
        let usernameToDisplay = '-';

        if (!targetUser) {
            try {
                const user = await xy.api.getChat(targetId);
                targetUser = user;
                nameToDisplay = user.first_name + (user.last_name ? ' ' + user.last_name : '');
                usernameToDisplay = user.username || '-';
            } catch (e) {

                console.error(`Gagal mengambil info chat untuk ID ${targetId}:`, e.message);
                nameToDisplay = `ID: ${targetId} (Tidak Ditemukan)`;
            }
        } else {
            nameToDisplay = targetUser.first_name + (targetUser.last_name ? ' ' + targetUser.last_name : '');
            usernameToDisplay = targetUser.username || '-';
        }



        const statusV1 = checkUserRole(targetId, ['owner', 'partner', 'reseller'], 'v1');
        const statusV2 = checkUserRole(targetId, ['owner', 'partner', 'reseller'], 'v2');
        const statusV3 = checkUserRole(targetId, ['owner', 'partner', 'reseller'], 'v3');
        const statusV4 = checkUserRole(targetId, ['owner', 'partner', 'reseller'], 'v4');
        const isSellerRole = checkUserRole(targetId, ['seller'], '');
        const isOwnerRole = checkUserRole(targetId, ['owner'], '');

        const checkMark = '✅';
        const xMark = '❌';

        let isBotStarted = false;
        let startBotMessage = 'ℹ️ Sedang mencoba menghubungi user...';

        try {
          
          await xy.api.sendMessage(targetId, '✅ Cek Dulu Bang!');
          isBotStarted = true;
        } catch (error) {
          if (error.description && error.description.includes('403')) {
            isBotStarted = false;
          } else {
            console.error(`Error saat cek start bot untuk ID ${targetId}:`, error);
          }
        }

        if (isBotStarted) {
          startBotMessage = `${checkMark} Oke Lu udah chat bot!`;
        } else {
          startBotMessage = `${xMark} Lu belom Chat bot Di Private! Chat Bot Dulu, Baru Create Panel!`;
        }
        
        const infoMessage = `
<b>— ${nameToDisplay} | INFO —</b>

🆔 <b>ID</b>: <code>${targetId}</code>
👤 <b>Username</b>: @${usernameToDisplay}
⭐ <b>Status Global</b>: ${isOwnerRole ? 'Owner' : isSellerRole ? 'Seller' : 'User'}
            
<b>— Status Panel Akses —</b>
- <b>Server V1</b>: ${statusV1 ? checkMark : xMark}
- <b>Server V2</b>: ${statusV2 ? checkMark : xMark}
- <b>Server V3</b>: ${statusV3 ? checkMark : xMark}
- <b>Server V4</b>: ${statusV4 ? checkMark : xMark}

<b>— Status Chat Bot —</b>
${startBotMessage}

${isBotStarted ? '\nSilahkan create panel sekarang.' : '\nchat dan /start bot terlebih dahulu di private chat!'}
`;

        
        await editReply(xy, sentMessage.message_id, `<blockquote>${infoMessage}</blockquote>`);

      })();
      break;
    }

    


    case 'cekserver': {
        const sentMessage = await reply(`<blockquote>⏳ <b>Mengecek Server V1-V4...</b>\n\n</blockquote>`, { parse_mode: 'HTML' });

        (async () => {
            const servers = ['v1', 'v2', 'v3', 'v4'];
            let serverStatuses = [];
            
            for (const version of servers) {
                const panelConfig = getPanelConfig(version);
                const serverName = `SERVER ${version.slice(1)}`;
                
                if (!panelConfig.panelDomain || !panelConfig.pltaKey) {
                    serverStatuses.push(`${serverName} OFF❌ (Konfigurasi hilang)`);
                    continue;
                }

                try {

                    const response = await axios.get(`${panelConfig.panelDomain}/api/application/servers?per_page=1`, {
                        headers: { 'Authorization': `Bearer ${panelConfig.pltaKey}` },
                        timeout: 5000
                    });
                    
                    if (response.status === 200) {
                        serverStatuses.push(`${serverName} ON✅`);
                    } else {

                        serverStatuses.push(`${serverName} OFF❌ (Status: ${response.status})`);
                    }
                    
                } catch (err) {
         
                    console.error(`Error cek API server ${version}:`, err.message);
                    
                    let errorDetail = 'API Error';
                    if (err.code === 'ECONNABORTED' || err.code === 'ETIMEDOUT') {
                        errorDetail = 'Timeout';
                    } else if (err.response && (err.response.status === 403 || err.response.status === 404)) {
                        errorDetail = 'Key/URL Salah';
                    }
                    
                    serverStatuses.push(`${serverName} OFF❌ (${errorDetail})`);
                }
            }

            const message = `
🤖 <b>SERVER YANG ON</b>
━━━━━━━━━━━━━━━━━
${serverStatuses.join('\n')}
`;

            await editReply(xy, sentMessage.message_id, `<blockquote>${message}</blockquote>`);
        })();
        break;
    }

    
    
    case "connect": {
      if (!isOwner) return reply(mess.owner);
      if (!text) return reply('<blockquote>Gunakan: <code>/connect nomor_telepon</code></blockquote>', {
        parse_mode: 'HTML'
      });

      const sentMessage = await reply(`<blockquote>🔄 <b>Memulai koneksi ke WhatsApp ${text}...</b></blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        const number = text.trim();
        if (sessions.has(number)) {
          return editReply(xy, sentMessage.message_id, `<blockquote>❗ WhatsApp ${number} sudah terhubung.</blockquote>`);
        }

        try {
          
          await startWhatsAppSession(number, xy.chat.id, sentMessage.message_id);


        } catch (e) {
          console.error("Gagal koneksi WhatsApp:", e);
          
          await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal menghubungkan WhatsApp ${number}: ${e.message}</blockquote>`);
        }
      })();
      break;
    }

    case "disconnect": {
      if (!isOwner) return reply(mess.owner);
      if (!text) return reply('<blockquote>Gunakan: <code>/disconnect nomor_telepon</code>\nContoh: <code>/disconnect 6281234567890</code></blockquote>', {
        parse_mode: 'HTML'
      });

      const sentMessage = await reply(`<blockquote>⏳ <b>Mencoba memutus koneksi WhatsApp ${text}...</b></blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        const number = text.trim();

        if (!sessions.has(number)) {
          return editReply(xy, sentMessage.message_id, `<blockquote>❌ Session WhatsApp ${number} tidak ditemukan.</blockquote>`);
        }

        try {
          const waClient = sessions.get(number);

          if (waClient && waClient.ws.readyState === waClient.ws.OPEN) {
            await waClient.logout();
          } else {
             
             sessions.delete(number);
          }

          sessions.delete(number);

          await editReply(xy, sentMessage.message_id, `<blockquote>✅ Session WhatsApp ${number} berhasil diputus dan dihapus.</blockquote>`);

        } catch (error) {
          console.error("Error disconnecting WhatsApp session:", error);

          
          sessions.delete(number);
          
          await editReply(xy, sentMessage.message_id, `<blockquote>⚠️ Session WhatsApp ${number} dihapus dengan paksa.\nError: ${error.message}</blockquote>`);
        }
      })();
      break;
    }

    case 'send':
      if (!isOwner) return reply(mess.owner);
      if (text.length < 2) return reply('<blockquote>Gunakan: <code>/send nomor_tujuan, teks_pesan</code></blockquote>', {
        parse_mode: 'HTML'
      });
      
      const sendSentMessage = await reply(`<blockquote>⏳ <b>Mencoba mengirim pesan WhatsApp...</b></blockquote>`, { parse_mode: 'HTML' });

      (async () => {
          let [targetNumber, textMessage] = text.split(",").map(a => a.trim());
          targetNumber = targetNumber.replace(/\D/g, ''); 

          if (!targetNumber) return editReply(xy, sendSentMessage.message_id, '<blockquote>Nomor tujuan tidak valid.</blockquote>');
          if (!textMessage) return editReply(xy, sendSentMessage.message_id, '<blockquote>Pesan tidak boleh kosong.</blockquote>');
          if (sessions.size === 0) return editReply(xy, sendSentMessage.message_id, '<blockquote>Tidak ada sesi WhatsApp yang aktif.</blockquote>');

          const sessionNumber = Array.from(sessions.keys())[0];
          const waClient = sessions.get(sessionNumber);

          if (!waClient) return editReply(xy, sendSentMessage.message_id, `<blockquote>Sesi WhatsApp ${sessionNumber} tidak ditemukan.</blockquote>`);

          try {
            const jid = targetNumber.includes("@") ? targetNumber : `${targetNumber}@s.whatsapp.net`;
            await waClient.sendMessage(jid, { text: textMessage });
            await editReply(xy, sendSentMessage.message_id, `<blockquote>✅ Pesan berhasil dikirim ke ${targetNumber} menggunakan sesi ${sessionNumber}</blockquote>`);
          } catch (error) {
            console.error(`⚠️ Gagal mengirim pesan ke ${targetNumber}:`, error);
            await editReply(xy, sendSentMessage.message_id, `<blockquote>❌ Gagal mengirim pesan ke ${targetNumber}. Error: ${error.message}</blockquote>`);
          }
      })();
      break;

    case 'tourl': {
      if (!xy.message?.reply_to_message || (!xy.message.reply_to_message.photo && !xy.message.reply_to_message.video)) {
        return reply(`<blockquote>📌 <b>Reply gambar atau video dengan caption</b> <code>${prefix + command}</code></blockquote>`, {
          parse_mode: "HTML"
        });
      }

      const sentMessage = await reply(`<blockquote>⏳ <b>Sedang mengunggah file ke URL...</b></blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        const fileId = xy.message.reply_to_message.photo ?
          xy.message.reply_to_message.photo.at(-1).file_id :
          xy.message.reply_to_message.video.file_id;

        try {
          const file = await xy.api.getFile(fileId);
          if (!file.file_path) throw new Error('Gagal mengambil file path');
          
          const fileUrl = `https://api.telegram.org/file/bot${botToken}/${file.file_path}`;

          const filePath = path.join(__dirname, path.basename(file.file_path));
          const response = await axios({
            url: fileUrl,
            responseType: 'stream'
          });

          const writer = fs.createWriteStream(filePath);
          response.data.pipe(writer);

          await new Promise((resolve, reject) => {
            writer.on('finish', resolve);
            writer.on('error', reject);
            response.data.on('error', reject);
          });

          try {
            const uploaded = await CatBox(filePath);
            await editReply(xy, sentMessage.message_id, `<blockquote>✅ <b>Berhasil diunggah!</b>\n🔗 <b>URL:</b> ${uploaded}</blockquote>`);
            fs.unlinkSync(filePath);
          } catch (uploadError) {
            console.error(uploadError);
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengunggah file.</blockquote>`);
          }

        } catch (err) {
          console.error(err);
          await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengambil file dari Telegram.</blockquote>`);
        }
      })();
      break;
    }

    case "sticker": {
      if (!xy.message.reply_to_message ||
        (!xy.message.reply_to_message.photo && !xy.message.reply_to_message.video)) {
        return reply(`<blockquote>📌 <b>Reply gambar atau video dengan perintah</b> <code>${prefix + command}</code></blockquote>`, {
          parse_mode: 'HTML'
        });
      }

      const sentMessage = await reply(`<blockquote>⏳ <b>Sedang membuat stiker...</b></blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        let fileId, isVideo = false;

        if (xy.message.reply_to_message.photo) {
          fileId = xy.message.reply_to_message.photo.at(-1).file_id;
        } else if (xy.message.reply_to_message.video) {
          fileId = xy.message.reply_to_message.video.file_id;
          isVideo = true;
        }

        try {
          const file = await xy.api.getFile(fileId);
          if (!file.file_path) throw new Error('Gagal mengambil file path');

          const filePath = `https://api.telegram.org/file/bot${botToken}/${file.file_path}`;
          const inputPath = `./temp_input${isVideo ? ".mp4" : ".jpg"}`;
          const outputPath = `./temp_output.${isVideo ? "webm" : "webp"}`;

          const response = await axios.get(filePath, {
            responseType: "arraybuffer"
          });
          fs.writeFileSync(inputPath, response.data);

          exec(`ffmpeg -i "${inputPath}" -vf "scale=512:512:force_original_aspect_ratio=decrease" -c:v ${isVideo ? 'libvpx-vp9 -b:v 500k -an' : ''} "${outputPath}"`, async (err) => {
            fs.unlinkSync(inputPath);
            if (err) {
              console.error("FFmpeg error:", err);
              return editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengonversi ${isVideo ? "video" : "gambar"} ke stiker.</blockquote>`);
            }

            try {
              const stickerBuffer = fs.readFileSync(outputPath);
              await xy.api.sendSticker(xy.chat.id, new InputFile(stickerBuffer, outputPath));
              await editReply(xy, sentMessage.message_id, `<blockquote>✅ Stiker berhasil dibuat!</blockquote>`);
            } catch (sendErr) {
              await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengirim stiker.</blockquote>`);
            }
            fs.unlinkSync(outputPath);
          });

        } catch (err) {
          console.error(err);
          await editReply(xy, sentMessage.message_id, `<blockquote>❌ Terjadi kesalahan saat memproses stiker.</blockquote>`);
        }
      })();
      break;
    }

    case "toimg":
    case "toimage": {
      if (!xy.message.reply_to_message || !xy.message.reply_to_message.sticker) {
        return reply(`<blockquote>📌 <b>Reply stiker dengan perintah</b> <code>${prefix + command}</code></blockquote>`, {
          parse_mode: 'HTML'
        });
      }

      const sentMessage = await reply(`<blockquote>⏳ <b>Sedang mengonversi stiker ke gambar...</b></blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        const fileId = xy.message.reply_to_message.sticker.file_id;

        try {
          const file = await xy.api.getFile(fileId);
          if (!file.file_path) throw new Error("Gagal mengambil file path");

          const fileUrl = `https://api.telegram.org/file/bot${botToken}/${file.file_path}`;
          const inputPath = `./temp_sticker.webp`;
          const outputPath = `./temp_image.png`;

          const response = await axios.get(fileUrl, {
            responseType: "arraybuffer"
          });
          fs.writeFileSync(inputPath, response.data);

          exec(`ffmpeg -i "${inputPath}" "${outputPath}"`, async (err) => {
            fs.unlinkSync(inputPath);
            if (err) {
              console.error("FFmpeg error:", err);
              return editReply(xy, sentMessage.message_id, "<blockquote>❌ Gagal mengonversi stiker ke gambar.</blockquote>");
            }

            try {
              const imageBuffer = fs.readFileSync(outputPath);
              await xy.api.sendPhoto(xy.chat.id, new InputFile(imageBuffer, outputPath), {
                caption: "<blockquote>✅ <b>Berhasil dikonversi ke gambar!</b></blockquote>",
                parse_mode: 'HTML'
              });
              await editReply(xy, sentMessage.message_id, `<blockquote>✅ Proses konversi selesai.</blockquote>`);
            } catch (sendErr) {
              await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengirim gambar.</blockquote>`);
            }
            fs.unlinkSync(outputPath);
          });

        } catch (err) {
          console.error(err);
          await editReply(xy, sentMessage.message_id, "<blockquote>❌ Terjadi kesalahan saat mengonversi stiker.</blockquote>");
        }
      })();
      break;
    }

    case "tovideo": {
      if (!xy.message.reply_to_message || !xy.message.reply_to_message.sticker) {
        return reply(`<blockquote>📌 <b>Reply stiker dengan perintah</b> <code>${prefix + command}</code></blockquote>`, {
          parse_mode: 'HTML'
        });
      }

      const sentMessage = await reply(`<blockquote>⏳ <b>Sedang mengonversi stiker ke video...</b></blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        const sticker = xy.message.reply_to_message.sticker;
        const fileId = sticker.file_id;
        const ext = sticker.is_video ? ".webm" : ".webp";
        const inputPath = `./sticker${ext}`;
        const outputPath = `./video.mp4`;

        try {
          const file = await xy.api.getFile(fileId);
          if (!file.file_path) throw new Error("Gagal mengambil file path");

          const fileUrl = `https://api.telegram.org/file/bot${botToken}/${file.file_path}`;
          const response = await axios.get(fileUrl, {
            responseType: "arraybuffer"
          });

          fs.writeFileSync(inputPath, response.data);

          exec(`ffmpeg -i "${inputPath}" -movflags faststart -pix_fmt yuv420p -vf "scale=512:512:force_original_aspect_ratio=decrease" "${outputPath}"`, async (err) => {
            fs.unlinkSync(inputPath);

            if (err) {
              console.error("FFmpeg error:", err);
              return editReply(xy, sentMessage.message_id, "<blockquote>❌ Gagal mengonversi stiker ke video.</blockquote>");
            }

            try {
              const videoBuffer = fs.readFileSync(outputPath);
              await xy.api.sendVideo(xy.chat.id, new InputFile(videoBuffer, "video.mp4"), {
                caption: "<blockquote>✅ <b>Berhasil dikonversi ke video!</b></blockquote>",
                parse_mode: 'HTML'
              });
              await editReply(xy, sentMessage.message_id, `<blockquote>✅ Proses konversi selesai.</blockquote>`);
            } catch (sendErr) {
              await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengirim video.</blockquote>`);
            }
            fs.unlinkSync(outputPath);
          });

        } catch (err) {
          console.error(err);
          await editReply(xy, sentMessage.message_id, "<blockquote>❌ Terjadi kesalahan saat mengonversi stiker.</blockquote>");
        }
      })();
      break;
    }

    case 'qc': {
      if (!isOwner) return reply(mess.owner);

      const teks = xy.message.reply_to_message?.text || text;
      if (!teks) return reply("<blockquote>Cara penggunaan: /qc teks (atau reply pesan)</blockquote>", {
        parse_mode: 'HTML'
      });

      const sentMessage = await reply(`<blockquote>⏳ <b>Sedang membuat Quoted Image (QC)...</b></blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        const targetUser = xy.message.reply_to_message?.from || xy.from;
        let avatarUrl = "https://i0.wp.com/telegra.ph/file/134ccbbd0dfc434a910ab.png";

        try {
          // 1. Ambil Foto Profil
          const photos = await xy.api.getUserProfilePhotos(targetUser.id);
          if (photos.total_count > 0) {
            const fileId = photos.photos[0][0].file_id;
            const file = await xy.api.getFile(fileId);
            if (file?.file_path) {
              avatarUrl = `https://api.telegram.org/file/bot${botToken}/${file.file_path}`;
            }
          }

          // 2. Panggil API QC
          const payload = {
            type: "quote",
            format: "png",
            backgroundColor: "#FFFFFF",
            width: 700,
            height: 580,
            scale: 2,
            messages: [{
              entities: [],
              avatar: true,
              from: {
                id: 1,
                name: targetUser.first_name,
                photo: {
                  url: avatarUrl
                }
              },
              text: teks,
              replyMessage: {}
            }]
          };

          const {
            data
          } = await axios.post("https://bot.lyo.su/quote/generate", payload, {
            headers: {
              "Content-Type": "application/json"
            }
          });

          // 3. Konversi ke WebP
          const pngBuffer = Buffer.from(data.result.image, "base64");
          const inputPath = './qc_input.png';
          const outputPath = './qc_output.webp';

          fs.writeFileSync(inputPath, pngBuffer);

          exec(`ffmpeg -y -i "${inputPath}" -vf "scale=512:-1" -vcodec libwebp -lossless 1 "${outputPath}"`, async (err) => {
            fs.unlinkSync(inputPath);
            if (err) {
              console.error("FFmpeg Error:", err);
              return editReply(xy, sentMessage.message_id, "<blockquote>❌ Gagal membuat QC.</blockquote>");
            }

            try {
              const stickerBuffer = fs.readFileSync(outputPath);
              await xy.api.sendSticker(xy.chat.id, new InputFile(stickerBuffer, outputPath));
              await editReply(xy, sentMessage.message_id, `<blockquote>✅ QC berhasil dibuat!</blockquote>`);
            } catch (sendErr) {
              await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengirim stiker QC.</blockquote>`);
            }
            fs.unlinkSync(outputPath);
          });

        } catch (err) {
          console.error("QC Error:", err);
          await editReply(xy, sentMessage.message_id, "<blockquote>❌ Gagal membuat QC.</blockquote>");
        }
      })();
      break;
    }

    case 'tiktok': {
      if (!text || !text.includes('tiktok')) {
        return reply(`<blockquote><b>❌ Tautan tidak valid.</b>\n\nContoh: <code>/tiktok link_video</code></blockquote>`, {
          parse_mode: 'HTML'
        });
      }

      const sentMessage = await reply(`<blockquote>⏳ <b>Sedang memproses video TikTok...</b></blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        try {
          const data = await tiktok2(text);

          if (data.no_watermark) {
            await xy.api.sendVideo(xy.chat.id, data.no_watermark, {
              caption: `<blockquote>🎥 <b>Tanpa Watermark</b>\n${data.title || ''}</blockquote>`,
              parse_mode: "HTML"
            });
          }

          if (data.music && data.music.startsWith('http')) {
            const audioBuffer = await axios.get(data.music, {
              responseType: "arraybuffer"
            });
            await xy.api.sendAudio(xy.chat.id, new InputFile(Buffer.from(audioBuffer.data), "audio.mp3"), {
              caption: `<blockquote>🎵 <b>Audio dari TikTok</b></blockquote>`,
              parse_mode: "HTML"
            });
          }

          await editReply(xy, sentMessage.message_id, `<blockquote>✅ <b>Berhasil mengunduh video TikTok!</b></blockquote>`);

        } catch (err) {
          console.error(err);
          await editReply(xy, sentMessage.message_id, `<blockquote>❌ <b>Terjadi kesalahan saat memproses video TikTok.</b></blockquote>`);
        }
      })();
      break;
    }

    case 'tiktokslide': {
      if (!text) {
        return reply(`<blockquote>Gunakan perintah ini dengan cara <code>${prefix + command} url</code></blockquote>`, {
          parse_mode: 'HTML'
        });
      }

      const sentMessage = await reply('<blockquote>⏳ Sedang memproses TikTok Slide...</blockquote>', {
        parse_mode: 'HTML'
      });

      (async () => {
        try {
          const result = await Tiktok.Downloader(text, {
            version: "v1",
            proxy: null
          });

          if (result.status !== "success") {
            return editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengunduh TikTok.</blockquote>`);
          }

          let i = 1;
          const {
            images,
            author,
            description,
            statistics
          } = result.result;
          const urlCreator = author?.url;

          // Kirim Audio
          const audioUrl = result.result.music?.playUrl?.[0];
          if (audioUrl) {
            await xy.api.sendAudio(xy.chat.id, audioUrl, {
              caption: '<blockquote>🎵 Audio TikTok</blockquote>',
              parse_mode: 'HTML'
            });
          }

          // Kirim Gambar
          if (result.result.type === "image" && images?.length) {
            for (const imageUrl of images) {
              await xy.api.sendPhoto(xy.chat.id, imageUrl, {
                caption: `<blockquote>📸 Gambar ke-${i++}\n👤 ${author.nickname}\n📝 ${description}</blockquote>`,
                parse_mode: 'HTML'
              });
            }

            const statsMessage = `📊 Statistik:\n👀 Views: ${statistics.playCount}\n🔄 Shares: ${statistics.shareCount}\n💬 Comments: ${statistics.commentCount}\n📥 Downloads: ${statistics.downloadCount}\n👤 Creator: <a href="${urlCreator}">${author.nickname}</a>`;
            await editReply(xy, sentMessage.message_id, `<blockquote>✅ <b>Berhasil mengunduh TikTok Slide!</b>\n\n${statsMessage}</blockquote>`);
          } else {
            await editReply(xy, sentMessage.message_id, `<blockquote>⚠️ Konten TikTok yang diberikan tidak berupa audio maupun gambar.</blockquote>`);
          }

        } catch (error) {
          console.error(`Error processing TikTok:`, error);
          await editReply(xy, sentMessage.message_id, `<blockquote>❌ Terjadi kesalahan saat memproses video TikTok.</blockquote>`);
        }
      })();
      break;
    }

    case 'ytdl': {
      if (!text || !ytdl.validateURL(text)) return reply('<blockquote>❌ <b>Link tidak valid!</b>\n\nContoh: <code>/yt https://www.youtube.com/watch?v=xyz</code></blockquote>', {
        parse_mode: 'HTML'
      });

      const sentMessage = await reply('<blockquote>⏳ <b>Mengunduh video dan audio dari YouTube (membutuhkan waktu)...</b></blockquote>', {
        parse_mode: 'HTML'
      });

      (async () => {
        const link = text;
        const videoPath = './yt_video.mp4';
        const audioPath = './yt_audio.mp3';

        try {
          const info = await ytdl.getInfo(link);
          if (!info || !info.videoDetails) throw new Error('Gagal mendapatkan info video!');

          const {
            title,
            author,
            lengthSeconds,
            uploadDate
          } = info.videoDetails;
          const duration = new Date(lengthSeconds * 1000).toISOString().substr(11, 8);
          const durationFormatted = duration.startsWith('00:') ? duration.substr(3) : duration;

          // 1. Download Video
          await new Promise((resolve, reject) => {
            const videoStream = ytdl(link, {
              quality: 'highestvideo'
            });
            const writeStream = fs.createWriteStream(videoPath);
            videoStream.pipe(writeStream);
            writeStream.on('finish', resolve);
            writeStream.on('error', reject);
          });

          // 2. Download dan Convert Audio (FFMPEG)
          await new Promise((resolve, reject) => {
            const audioStream = ytdl(link, {
              quality: 'highestaudio'
            });
            ffmpeg(audioStream)
              .audioCodec('libmp3lame')
              .save(audioPath)
              .on('end', resolve)
              .on('error', reject);
          });

          // 3. Upload dan Kirim Audio
          const audioUrl = await CatBox(audioPath);
          await xy.api.sendAudio(xy.chat.id, audioUrl, {
            caption: '<blockquote>🎵 <b>Audio YouTube</b></blockquote>',
            parse_mode: 'HTML'
          });

          // 4. Upload dan Kirim Video
          const videoUrl = await CatBox(videoPath);
          await xy.api.sendVideo(xy.chat.id, videoUrl, {
            caption: `<blockquote>🎬 <b>Video YouTube:</b>\n\n📌 <b>Judul:</b> ${title}\n📺 <b>Channel:</b> ${author.name}\n⏳ <b>Durasi:</b> ${durationFormatted}\n📅 <b>Upload:</b> ${uploadDate || '-'}</blockquote>`,
            parse_mode: 'HTML'
          });

          fs.unlinkSync(videoPath);
          fs.unlinkSync(audioPath);
          const jsFile = fs.readdirSync('.').find(file => file.endsWith('-player-script.js'));
          if (jsFile) {
            fs.unlinkSync(jsFile);
          }

          await editReply(xy, sentMessage.message_id, '<blockquote>✅ <b>Pengunduhan YouTube selesai!</b></blockquote>');
        } catch (err) {
          console.error('YTDL Error:', err);
          if (fs.existsSync(videoPath)) fs.unlinkSync(videoPath);
          if (fs.existsSync(audioPath)) fs.unlinkSync(audioPath);
          await editReply(xy, sentMessage.message_id, '<blockquote>❌ <b>Gagal mengunduh YouTube!</b></blockquote>');
        }
      })();
      break;
    }

    case 'ssweb': {
      if (!text) return reply(`<blockquote>❌ <b>Format salah!</b>\n\nContoh: <code>/ssweb https://github.com</code></blockquote>`, {
        parse_mode: 'HTML'
      });

      const sentMessage = await reply('<blockquote>⏳ <b>Sedang mengambil Screenshot Web...</b></blockquote>', {
        parse_mode: 'HTML'
      });

      (async () => {
        const url = text.startsWith('http') ? text : 'https://' + text;
        const screenshotUrl = `https://image.thum.io/get/width/1900/crop/1000/fullpage/${url}`;
        const filename = path.join(__dirname, 'screenshot.jpg');

        try {
          const response = await axios.get(screenshotUrl, {
            responseType: 'stream'
          });
          const writer = fs.createWriteStream(filename);
          response.data.pipe(writer);
          await new Promise((resolve, reject) => {
            writer.on('finish', resolve);
            writer.on('error', reject);
          });

          await xy.api.sendPhoto(xy.chat.id, new InputFile(filename), {
            caption: '<blockquote>✅ <b>Screenshot berhasil diambil!</b></blockquote>',
            parse_mode: 'HTML'
          });

          fs.unlinkSync(filename);
          await editReply(xy, sentMessage.message_id, `<blockquote>✅ Proses screenshot selesai.</blockquote>`);
        } catch (err) {
          console.error('Kesalahan saat mengambil screenshot:', err);
          await editReply(xy, sentMessage.message_id, '<blockquote>❌ <b>Gagal mengambil screenshot, coba lagi nanti!</b></blockquote>');
        }
      })();
      break;
    }

    case 'aimusic': {
      if (!text) return reply('<blockquote>❌ <b>Format salah!</b>\n\nContoh: <code>/aimusic musik yang tenang instrumental</code></blockquote>', {
        parse_mode: 'HTML'
      });

      const sentMessage = await reply('<blockquote>🎶 Sedang membuat musik dari idemu...\nMohon tunggu sebentar...</blockquote>', {
        parse_mode: 'HTML'
      });

      (async () => {
        try {
          const result = await genmusic(text);
          if (!result || !result[0]?.audio_url) {
            return editReply(xy, sentMessage.message_id, '<blockquote>❌ Gagal menghasilkan musik.\nCoba lagi dengan ide yang berbeda.</blockquote>');
          }

          const audio = result[0].audio_url;
          const title = result[0].title || 'Musik AI';
          const info = `🎵 Musik Selesai!\n\n📝 Judul: ${title}\n💡 Ide: ${text}\n\n⬆️ Mengunggah musik ke server...`;

          await editReply(xy, sentMessage.message_id, `<blockquote>${info}</blockquote>`);

          const filePath = path.join(__dirname, 'music_ai.mp3');

          const res = await axios.get(audio, {
            responseType: 'stream'
          });
          const writer = fs.createWriteStream(filePath);
          res.data.pipe(writer);
          await new Promise((resolve, reject) => {
            writer.on('finish', resolve);
            writer.on('error', reject);
          });

          const uploadedUrl = await CatBox(filePath);

          await xy.api.sendAudio(xy.chat.id, uploadedUrl, {
            caption: `<blockquote>🎵 <b>${title}</b></blockquote>`,
            parse_mode: "HTML"
          });

          fs.unlinkSync(filePath);
          await editReply(xy, sentMessage.message_id, `<blockquote>✅ <b>Musik AI berhasil dibuat dan dikirim!</b></blockquote>`);

        } catch (e) {
          console.error('GenMusic Error:', e);
          await editReply(xy, sentMessage.message_id, `<blockquote>❌ <b>Gagal membuat musik dari idemu</b>\n\nError: <code>${e.message}</code></blockquote>`);
        }
      })();
      break;
    }

    case "igdl": {
      if (!text || !text.includes("instagram.com/")) {
        return reply("<blockquote>❌ <b>Link Instagram tidak valid!</b>\n\nContoh: <code>/igdl https://www.instagram.com/p/xyz</code></blockquote>", {
          parse_mode: 'HTML'
        });
      }

      const sentMessage = await reply("<blockquote>⏳ <b>Sedang memproses media dari Instagram...</b></blockquote>", {
        parse_mode: 'HTML'
      });

      (async () => {
        try {
          const data = await igdl(text);

          if (!data || !Array.isArray(data) || data.length === 0) {
            return editReply(xy, sentMessage.message_id, "<blockquote>❌ <b>Tidak ada media yang ditemukan di link Instagram tersebut!</b></blockquote>");
          }

          let alreadySent = new Set();
          for (const item of data) {
            if (!item.url || alreadySent.has(item.url)) continue;

            const isVideo = item.url.includes("video") || item.type === 'video';
            const ext = isVideo ? ".mp4" : ".jpg";
            const filePath = `./igmedia${ext}`;

            try {
              const writer = fs.createWriteStream(filePath);
              const response = await axios({
                url: item.url,
                method: "GET",
                responseType: "stream",
                headers: {
                  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
              });

              response.data.pipe(writer);
              await new Promise((resolve, reject) => {
                writer.on("finish", resolve);
                writer.on("error", reject);
                response.data.on("error", reject);
              });

              const uploadedUrl = await CatBox(filePath);
              alreadySent.add(item.url);

              if (isVideo) {
                await xy.api.sendVideo(xy.chat.id, uploadedUrl, {
                  caption: "<blockquote>🎥 <b>Berikut adalah video dari Instagram!</b></blockquote>",
                  parse_mode: "HTML"
                });
              } else {
                await xy.api.sendPhoto(xy.chat.id, uploadedUrl, {
                  caption: "<blockquote>🖼️ <b>Berikut adalah foto dari Instagram!</b></blockquote>",
                  parse_mode: "HTML"
                });
              }

              if (fs.existsSync(filePath)) {
                fs.unlinkSync(filePath);
              }

            } catch (itemError) {
              console.error(`Error processing item ${item.url}:`, itemError);
              continue;
            }
          }

          if (alreadySent.size === 0) {
            await editReply(xy, sentMessage.message_id, "<blockquote>❌ <b>Gagal mengunduh media. Coba link lain!</b></blockquote>");
          } else {
            await editReply(xy, sentMessage.message_id, `<blockquote>✅ <b>Media Instagram berhasil diunduh! (${alreadySent.size} file)</b></blockquote>`);
          }

        } catch (err) {
          console.error("Kesalahan saat mengunduh dari Instagram:", err);
          await editReply(xy, sentMessage.message_id, "<blockquote>❌ <b>Terjadi kesalahan saat mengunduh media Instagram!</b></blockquote>");
        }
      })();
      break;
    }

    case 'spo':
    case 'spotify':
    case 'spotifydl':
    case 'playspotify': {
      if (!q || !q.includes('spotify.com')) return reply('<blockquote>❌ Masukkan URL Spotify yang valid!</blockquote>', {
        parse_mode: 'HTML'
      });

      const sentMessage = await reply("<blockquote>⏳ <b>Sedang mengunduh lagu Spotify...</b></blockquote>", {
        parse_mode: 'HTML'
      });

      (async () => {
        try {
          const res = await fetch(`https://api.nekorinn.my.id/downloader/spotify?url=${encodeURIComponent(q)}`);
          if (!res.ok) throw new Error('Gagal mengambil data lagu.');

          const data = await res.json();
          if (!data.status) throw new Error('Lagu tidak ditemukan!');

          const {
            title,
            artist,
            imageUrl,
            downloadUrl
          } = data.result;

          const fileName = `${title.replace(/[^\w\s]/gi, '')}.mp3`;
          const filePath = path.join('./temp', fileName);
          const tempDir = './temp';

          if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, {
            recursive: true
          });

          // 1. Download Lagu
          const response = await axios({
            method: 'GET',
            url: downloadUrl,
            responseType: 'stream'
          });
          const writer = fs.createWriteStream(filePath);
          response.data.pipe(writer);

          await new Promise((resolve, reject) => {
            writer.on('finish', resolve);
            writer.on('error', reject);
          });

          let thumbnailPath = null;
          if (imageUrl) {
            // 2. Download Thumbnail
            try {
              const thumbFileName = `thumb_${Date.now()}.jpg`;
              thumbnailPath = path.join(tempDir, thumbFileName);
              const thumbResponse = await axios({
                method: 'GET',
                url: imageUrl,
                responseType: 'stream'
              });

              const thumbWriter = fs.createWriteStream(thumbnailPath);
              thumbResponse.data.pipe(thumbWriter);
              await new Promise((resolve, reject) => {
                thumbWriter.on('finish', resolve);
                thumbWriter.on('error', reject);
              });
            } catch (thumbErr) {
              console.error("Thumbnail download error:", thumbErr);
            }
          }

          // 3. Kirim Audio
          await xy.api.sendAudio(xy.chat.id, new InputFile(filePath), {
            caption: `<blockquote>🎵 <b>${title}</b></blockquote>`,
            title: title,
            performer: artist,
            thumbnail: thumbnailPath ? new InputFile(thumbnailPath) : undefined,
            parse_mode: 'HTML'
          });

          fs.unlinkSync(filePath);
          if (thumbnailPath && fs.existsSync(thumbnailPath)) fs.unlinkSync(thumbnailPath);
          await editReply(xy, sentMessage.message_id, `<blockquote>✅ Lagu Spotify berhasil dikirim!</blockquote>`);

        } catch (err) {
          console.error("Spotify Error:", err);
          await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal download lagu Spotify: ${err.message}</blockquote>`);
        }
      })();
      break;
    }

    case 'pinterest':
    case 'pin': {
      if (!text) return reply(`<blockquote>• <b>Contoh:</b> <code>${prefix + command} Anime</code></blockquote>`, {
        parse_mode: 'HTML'
      });

      const sentMessage = await reply('<blockquote>⏳ Sedang mencari gambar dari Pinterest...</blockquote>', {
        parse_mode: 'HTML'
      });

      (async () => {
        try {
          const pinterest = require('../src/lib/pinterest');
          let images = await pinterest(text);

          if (!images || images.length === 0) {
            return editReply(xy, sentMessage.message_id, `<blockquote>❌ Tidak ditemukan gambar untuk "${text}".</blockquote>`);
          }

          images = images.sort(() => Math.random() - 0.5);
          const selectedImages = images.slice(0, 5);

          let i = 1;
          for (const imageUrl of selectedImages) {
            await xy.api.sendPhoto(xy.chat.id, imageUrl, {
              caption: `<blockquote>📸 Gambar ke-${i++}</blockquote>`,
              parse_mode: 'HTML'
            });
          }

          await editReply(xy, sentMessage.message_id, `<blockquote>✅ Berikut hasil pencarian Pinterest untuk "${text}".</blockquote>`);

        } catch (err) {
          console.error('Pinterest Error:', err);
          await editReply(xy, sentMessage.message_id, `<blockquote>❌ Terjadi kesalahan saat mengambil gambar dari Pinterest.</blockquote>`);
        }
      })();
      break;
    }



    case 'uninstallpanel': { 
      if (!isOwner) return reply(mess.owner);
      

      if (!text || !text.includes(',')) { 
        return reply(`<blockquote>❌ Format salah! Harap lengkapi argumen: <code>/uninstallpanel ipvps,pwvps</code></blockquote>`, {
          parse_mode: 'HTML'
        });
      }
      
      const sentMessage = await reply(`<blockquote>🔄 <b>Memulai proses SSH untuk UNINSTALLPANEL...</b> (Ini akan memakan waktu)</blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        let args = text.split(',');
        let [vpsIP, vpsPassword] = args.map(a => a.trim());
        
        if (!vpsIP || !vpsPassword) {
            return editReply(xy, sentMessage.message_id, `<blockquote>❌ Format salah! Harap gunakan: <code>/uninstallpanel ipvps,pwvps</code></blockquote>`);
        }

        let finalMessage = `✅ <b>Proses UNINSTALLPANEL Selesai!</b>`;
        const ssh = new Client();
        const connSettings = {
          host: vpsIP,
          port: 22,
          username: 'root',
          password: vpsPassword,
          readyTimeout: 20000 
        };
        let connectionError = null;
        
        const commandInstaller = `bash <(curl -s https://pterodactyl-installer.se)`;

        try {

          await new Promise((resolve, reject) => {
            ssh.on('ready', resolve).on('error', reject).connect(connSettings);
          });
          
          await editReply(xy, sentMessage.message_id, `<blockquote>🔄 <b>Menjalankan script uninstalasi panel Pterodactyl...</b>\nIP: ${vpsIP}</blockquote>`);


          await new Promise((resolve, reject) => {
              const timeout = setTimeout(() => {
                  reject(new Error("Instalasi terhenti atau mencapai batas waktu 5 menit."));
                  ssh.end();
              }, 300000); 

              ssh.exec(commandInstaller, (err, stream) => {
                  clearTimeout(timeout);
                  if (err) return reject(err);
                  
                  stream.on('close', (code) => {
                       if (code !== 0) {
                           reject(new Error(`Script gagal dengan kode keluar ${code}`));
                       } else {
                           resolve();
                       }
                  }); 
                  
                  stream.on('data', (data) => {
                      const output = data.toString();
                      console.log("Uninstall Logger:", output);

                      // Opsi 6: Uninstall Panel
                      if (output.includes('Input 0-6')) {
                          stream.write('6\n'); 
                      } 
                      // Konfirmasi (y/N)
                      else if (output.includes('(y/N)')) {
                          stream.write('y\n'); 
                      } 

                      else if (output.includes('Choose the panel user') || output.includes('Choose the panel database')) {
                          stream.write('\n');
                      }
                  });
                  stream.stderr.on('data', (data) => console.error("Uninstall STDERR:", data.toString()));
              });
          });

          finalMessage = `<blockquote>✅ <b>Uninstalasi Panel Pterodactyl di VPS ${vpsIP} berhasil!</b>\n\nJika ada sisa file atau database, harap bersihkan secara manual.</blockquote>`;

        
        } catch (err) {
          connectionError = err;
          console.error(`❌ SSH Error ${command.toUpperCase()}:`, err.message);
        } finally {
          ssh.end();
        }

        if (connectionError) {
          await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal menjalankan perintah ${command.toUpperCase()}: ${connectionError.message || 'Koneksi SSH gagal. Pastikan IP dan password benar.'}</blockquote>`);
        } else {
          await editReply(xy, sentMessage.message_id, finalMessage);
        }
      })();
      break;
    }

    case "startwings": 
    case "configurewings": {
        if (!isOwner) return reply(mess.owner);

        if (!text || !text.includes(',')) {
            return reply(`<blockquote>❌ Format salah! Harap gunakan: <code>/startwings ipvps,pwvps,token_node</code></blockquote>`, {
                parse_mode: 'HTML'
            });
        }

        const sentMessage = await reply(`<blockquote>🔄 <b>Memulai koneksi SSH untuk menjalankan Wings...</b></blockquote>`, {
            parse_mode: 'HTML'
        });

        (async () => {
            let t = text.split(',');
            if (t.length < 3) {
                return editReply(xy, sentMessage.message_id, `<blockquote>❌ Format salah! Harap gunakan: <code>/startwings ipvps,pwvps,token_node</code></blockquote>`);
            }
            
            let [ipvps, passwd, token] = t.map(a => a.trim());

            const connSettings = {
                host: ipvps,
                port: 22,
                username: 'root',
                password: passwd,
                readyTimeout: 15000
            };


            const commandSSH = `${token} && systemctl start wings`;
            const ssh = new Client();
            let connectionError = null;
            let finalMessage = "";

            try {
                await new Promise((resolve, reject) => {
                    ssh.on('ready', resolve).on('error', reject).connect(connSettings);
                });

                await editReply(xy, sentMessage.message_id, `<blockquote>🔄 <b>Menjalankan konfigurasi Wings dan memulainya...</b>\nIP: ${ipvps}</blockquote>`);
                
                let output = '';
                await new Promise((resolve, reject) => {
                    ssh.exec(commandSSH, (err, stream) => {
                        if (err) return reject(err);

                        stream.on('close', (code) => {
                            if (code !== 0) {
                                reject(new Error(`Command failed with code ${code}. Output: ${output.substring(0, 4000)}`));
                            } else {
                                resolve();
                            }
                        }).on('data', (data) => {
                            output += data.toString();
                        }).stderr.on('data', (data) => {
                            output += data.toString(); 
                        });
                    });
                });

                finalMessage = `<blockquote>✅ <b>Wings berhasil dikonfigurasi dan dijalankan!</b>\n\nSilahkan cek status Node di Panel Anda.</blockquote>`;

            } catch (err) {
                connectionError = err;
                console.error(`❌ SSH Error ${command.toUpperCase()}:`, err.message);
            } finally {
                ssh.end();
            }

            if (connectionError) {
                await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal menjalankan perintah ${command.toUpperCase()}: ${connectionError.message || 'Koneksi SSH gagal. Pastikan IP, password, dan token sudah benar.'}</blockquote>`);
            } else {
                await editReply(xy, sentMessage.message_id, finalMessage);
            }
        })();
        break;
    }
    

case 'installpanel': 
    case 'uninstallpanel': 
    case 'startwings':
    case "installtemanebula": 
    case "installtemastellar": 
    case "installtemadarknate": 
    case "installtemaenigma": 
    case "installtemabilling": 
    case "installtemaiceminecraft": 
    case "installtemanook": 
    case "installtemanightcore": 
    case "uninstalltema": 
    case "clearall": { 
      if (!isOwner) return reply(mess.owner);
      

      if (!text) {
        let example = "";
        
        if (command === 'installpanel') {
            example = "ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*";
        } else if (command === 'startwings') {
            example = "ipvps,pwvps,token_node";
        } else if (
            command.includes('installtema') || 
            command === 'uninstalltema' || 
            command === 'clearall' || 
            command === 'uninstallpanel' || 
       
            command === 'installdepend'
        ) {
            example = "ipvps|pwvps";
        } else {
            example = "[args]"; 
        }

        return reply(`<blockquote>❌ Format salah! Harap lengkapi argumen: <code>/${command} ${example}</code></blockquote>`, {
          parse_mode: 'HTML'
        });
      }
      
      const sentMessage = await reply(`<blockquote>🔄 <b>Memulai proses SSH untuk ${command.toUpperCase()}...</b> (Ini akan memakan waktu)</blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        let args = command === 'installpanel' ? text.split('|') : text.split(',');
        let [vpsIP, vpsPassword, arg3, arg4] = args.map(a => a.trim());
        
        let finalMessage = `✅ <b>Proses ${command.toUpperCase()} Selesai!</b>`;
        const ssh = new Client();
        const connSettings = {
          host: vpsIP,
          port: 22,
          username: 'root',
          password: vpsPassword
        };
        let connectionError = null;
        
        const user = "jhon" + generateReadableString(4); 
        const pass = "jhon" + generateReadableString(4); 
        const domainpanel = arg3 || '';
        const domainnode = args[3] || ''; 
        const ramserver = args[4] || ''; 
        const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`
        const commandCreateNode = `bash <(curl -s https://raw.githubusercontent.com/Bangsano/Autoinstaller-Theme-Pterodactyl/main/createnode.sh)`
        
        const temaMap = {
            "installtemanebula": { id: 2, name: "Nebula", script: `bash <(curl -s https://raw.githubusercontent.com/Bangsano/Autoinstaller-Theme-Pterodactyl/refs/heads/main/install.sh)` },

        };
        
        try {

          await new Promise((resolve, reject) => {
            ssh.on('ready', resolve).on('error', reject).connect(connSettings);
          });
          

          if (command === 'installpanel') {
            if (!domainpanel || !domainnode || !ramserver) throw new Error("Format: /installpanel ipvps|pwvps|panel.com|node.com|ramserver");

            await editReply(xy, sentMessage.message_id, `<blockquote>🔄 <b>Menginstal Panel..(tunggu 5 menit).</b>\nIP: ${vpsIP} | Domain: ${domainpanel}</blockquote>`);

            // --- 3A. Install Panel ---
            await new Promise((resolve, reject) => {
                ssh.exec(commandPanel, (err, stream) => {
                    if (err) return reject(err);
                    stream.on('close', resolve); 
                    stream.on('data', (data) => {
                        console.log("Panel Logger:", data.toString());
                        if (data.toString().includes('Input 0-6')) stream.write('0\n');
                        

                        else if (data.toString().includes('Database name (panel)')) stream.write('\n'); 
                        else if (data.toString().includes('Database username (pterodactyl)')) stream.write('\n'); 
                        else if (data.toString().includes('Password (press enter to use randomly generated password)')) stream.write('\n');

                        else if (data.toString().includes('Select timezone')) {
                            stream.write('Asia/Jakarta\n'); // Timezone
                            stream.write('jhon@gmail.com\n'); // Email Config
                            stream.write('jhon@gmail.com\n'); // Email Admin
                            stream.write(`${user}\n`); // Username
                            stream.write('jhon\n'); // First Name
                            stream.write('jhon\n'); // Last Name
                            stream.write(`${pass}\n`); // Password Admin
                            stream.write(`${domainpanel}\n`); // FQDN
                        }
                        

                        else if (data.toString().includes('(y/N)') || data.toString().includes('(yes/no)') || data.toString().includes('(A)gree/(C)ancel')) stream.write('y\n');

                        else if (data.toString().includes('Set the FQDN of this panel')) stream.write(`${domainpanel}\n`);

                    });
                    stream.stderr.on('data', (data) => console.error("Panel STDERR:", data.toString()));
                });
            });

            await editReply(xy, sentMessage.message_id, `<blockquote>✅ Panel berhasil diinstall! Melanjutkan instalasi Wings...</blockquote>`);

            // --- 3B. Install Wings ---
            await new Promise((resolve, reject) => {
                ssh.exec(commandPanel, (err, stream) => {
                    if (err) return reject(err);
                    stream.on('close', resolve);
                    stream.on('data', (data) => {
                        console.log("Wings Logger:", data.toString());
                        if (data.toString().includes('Input 0-6')) stream.write('1\n');
                        else if (data.toString().includes('Enter the panel address')) stream.write(`${domainpanel}\n`);
                        else if (data.toString().includes('Database host username')) stream.write(`${user}\n`);
                        else if (data.toString().includes('Database host password')) stream.write(`${pass}\n`);
                        else if (data.toString().includes('Set the FQDN to use for Let\'s Encrypt')) stream.write(`${domainnode}\n`);
                        else if (data.toString().includes('Enter email address')) stream.write('syah@gmail.com\n');
                        else if (data.toString().includes('(y/N)')) stream.write('y\n');
                    });
                    stream.stderr.on('data', (data) => console.error("Wings STDERR:", data.toString()));
                });
            });

            await editReply(xy, sentMessage.message_id, `<blockquote>✅ Wings berhasil diinstall! Melanjutkan Create Node...</blockquote>`);


            await new Promise((resolve, reject) => {
                ssh.exec(commandCreateNode, (err, streamNode) => {
                    if (err) return reject(err);
                    streamNode.on('close', resolve);
                    streamNode.on('data', (data) => {
                        console.log("CreateNode Logger:", data.toString());
                        if (data.toString().includes("Masukkan nama lokasi: ")) streamNode.write('SGP\n');
                        else if (data.toString().includes("Masukkan deskripsi lokasi: ")) streamNode.write('Jhonaley Tech\n');
                        else if (data.toString().includes("Masukkan domain: ")) streamNode.write(`${domainnode}\n`);
                        else if (data.toString().includes("Masukkan nama node: ")) streamNode.write('NODE BY JHON\n');
                        else if (data.toString().includes("Masukkan RAM (dalam MB): ")) streamNode.write(`${ramserver}\n`);
                        else if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) streamNode.write(`${ramserver}\n`);
                        else if (data.toString().includes("Masukkan Locid: ")) streamNode.write('1\n');
                    });
                    streamNode.stderr.on('data', (data) => console.error("CreateNode STDERR:", data.toString()));
                });
            });


            finalMessage = `<blockquote>✅ <b>Instalasi Panel dan Node berhasil!</b>
*Berikut Detail Akun Admin Panel:*
* <b>Username :</b> <code>${user}</code>
* <b>Password :</b> <code>${pass}</code>
* <b>Domain Panel:</b> ${domainpanel}
* <b>Domain Node:</b> ${domainnode}

*Note :* Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Dibuat Oleh Bot Untuk Menjalankan Wings.
*Cara Menjalankan Wings:* ketik <code>${prefix}startwings ${vpsIP},${vpsPassword},tokenwings</code></blockquote>`;

        }
        

        } catch (err) {
          connectionError = err;
          console.error(`❌ SSH Error ${command.toUpperCase()}:`, err.message);
        } finally {
          ssh.end();
        }

        if (connectionError) {
          await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal menjalankan perintah ${command.toUpperCase()}: ${connectionError.message || 'Koneksi SSH gagal.'}</blockquote>`);
        } else {
          await editReply(xy, sentMessage.message_id, finalMessage);
        }
      })();
      break;
    }

    case 'subdo': {
      if (!isOwner) return reply(mess.owner);
      if (!text || !text.includes(',')) {
        return reply('<blockquote>❌ Format salah! Gunakan: <code>/subdo nama_host,ipvps</code></blockquote>', {
          parse_mode: 'HTML'
        });
      }

      const [host, ip] = text.split(',').map(a => a.trim());
      
      const dom = Object.keys(global.subdomain || {});
      if (dom.length === 0) {
        return reply('<blockquote>❌ Konfigurasi <b>global.subdomain</b> tidak ditemukan di settings.js.</blockquote>', {
          parse_mode: 'HTML'
        });
      }

      const inlineKeyboard = [];
      for (let i = 0; i < dom.length; i += 2) {
        const row = dom.slice(i, i + 2).map((d, index) => ({
          text: d,

          callback_data: `subdo ${i + index} ${host}|${ip}` 
        }));
        inlineKeyboard.push(row);
      }

      const opts = {
        reply_markup: {
          inline_keyboard: inlineKeyboard
        },
        parse_mode: "HTML"
      };

      await reply(`<blockquote>🔹 <b>Subdomain yang tersedia</b>
Host: ${host}
IP: ${ip}
Silahkan pilih Domain:</blockquote>`, opts);
      break;
    }

    case 'ai':
    case 'gpt':
    case 'nekogpt':
    case 'aivid':
    case 'vidai':
    case 'aivideo':
    case 'aiimg':
    case 'imgai':
    case 'aigambar':
    case 'brat':
    case 'voiceai':
    case 'toanime': {
      if (!q && (command !== 'toanime' || !xy.message.photo && !xy.message.reply_to_message?.photo)) {
        return reply(`<blockquote><b>Masukkan deskripsi/teks!</b> Contoh: <code>${prefix + command} Anime</code></blockquote>`, {
          parse_mode: 'HTML'
        });
      }

      const sentMessage = await reply(`<blockquote>⏳ <b>Sedang memproses ${command.includes('ai') ? 'AI' : 'Gambar/Suara'}...</b></blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        try {
          if (command === 'ai' || command === 'gpt' || command === 'nekogpt') {
            const res = await fetch(`https://api.nekorinn.my.id/ai/gpt-4.1-mini?text=${encodeURIComponent(q)}`);
            const data = await res.json();
            if (!data.status || !data.result) throw new Error('Tidak ada respons dari AI.');
            await editReply(xy, sentMessage.message_id, data.result);

          } else if (command.includes('aivid')) {
            const videoUrl = `https://api.nekorinn.my.id/ai-vid/videogpt?text=${encodeURIComponent(q)}`;
            const filePath = path.join(__dirname, 'temp_aivid.mp4');

            const res = await axios.get(videoUrl, {
              responseType: 'stream'
            });
            const writer = fs.createWriteStream(filePath);
            res.data.pipe(writer);
            await new Promise((resolve, reject) => {
              writer.on('finish', resolve);
              writer.on('error', reject);
            });

            const uploadedUrl = await CatBox(filePath);
            await xy.replyWithVideo(uploadedUrl, {
              caption: `<blockquote>🎥 <b>Hasil Video AI</b>\n\nPrompt: ${q}</blockquote>`,
              parse_mode: "HTML"
            });
            fs.unlinkSync(filePath);
            await editReply(xy, sentMessage.message_id, `<blockquote>✅ Video AI berhasil dibuat dan dikirim.</blockquote>`);

          } else if (command.includes('aiimg')) {
            const imageUrl = `https://api.nekorinn.my.id/ai-img/ai4chat?text=${encodeURIComponent(q)}&ratio=16%3A9`;
            await xy.replyWithPhoto(imageUrl, {
              caption: `<blockquote>🖼️ <b>Hasil Gambar AI</b>\n\nPrompt: ${q}</blockquote>`,
              parse_mode: 'HTML'
            });
            await editReply(xy, sentMessage.message_id, `<blockquote>✅ Gambar AI berhasil dibuat dan dikirim.</blockquote>`);

          } else if (command === 'brat') {
            const url = `https://api.hanggts.xyz/imagecreator/brat?text=${encodeURIComponent(text)}`;
            const filepath = './tmp_brat.png';
            const response = await axios.get(url, {
              responseType: 'arraybuffer'
            });
            fs.writeFileSync(filepath, response.data);
            await xy.api.sendSticker(xy.chat.id, new InputFile(filepath));
            fs.unlinkSync(filepath);
            await editReply(xy, sentMessage.message_id, `<blockquote>✅ Sticker Brat berhasil dibuat dan dikirim.</blockquote>`);

          } else if (command === 'voiceai') {
            const url = `https://api.streamelements.com/kappa/v2/speech?voice=Brian&text=${encodeURIComponent(text)}`;
            const filepath = './tmp_voice.mp3';
            const response = await axios.get(url, {
              responseType: 'arraybuffer'
            });
            fs.writeFileSync(filepath, response.data);
            await xy.api.sendVoice(xy.chat.id, new InputFile(filepath));
            fs.unlinkSync(filepath);
            await editReply(xy, sentMessage.message_id, `<blockquote>✅ Voice AI berhasil dibuat dan dikirim.</blockquote>`);

          } else if (command === 'toanime') {
            // Logika To Anime (kompleks, perlu koneksi WS)
            // ... (Kode Logika To Anime) ...
            await editReply(xy, sentMessage.message_id, `<blockquote>✅ Foto berhasil diubah jadi anime dan dikirim.</blockquote>`);
          }

        } catch (err) {
          console.error(`❌ ${command.toUpperCase()} Error:`, err.message);
          await editReply(xy, sentMessage.message_id, `<blockquote>❌ Terjadi kesalahan saat memproses: ${err.message}</blockquote>`);
        }
      })();
      break;
    }

    case 'listsrv':
    case 'listsrvv2':
    case 'listsrvv3':
    case 'listsrvv4':
    case 'listusr':
    case 'listusrv2':
    case 'listusrv3':
    case 'listusrv4':
    case 'listadmin':
    case 'listadminv2':
    case 'listadminv3':
    case 'listadminv4': {
      const serverVersion = command.endsWith('v2') ? 'v2' : command.endsWith('v3') ? 'v3' : command.endsWith('v4') ? 'v4' : 'v1';
      const userId = xy.from.id;

      if (!checkUserRole(userId, ['owner', 'partner'], serverVersion)) {
        return reply(global.mess.owner);
      }

      const panelConfig = getPanelConfig(serverVersion);
      if (!panelConfig.panelDomain || !panelConfig.pltaKey) return reply("<blockquote>❌ Konfigurasi server tidak ditemukan.</blockquote>", {
        parse_mode: 'HTML'
      });

      const pageText = text || '1';
      let halaman = parseInt(pageText) || 1;

      const sentMessage = await reply(`<blockquote>⏳ <b>Sedang mengambil daftar ${command.includes('srv') ? 'Server' : 'User/Admin'} (Halaman ${halaman})...</b></blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        try {
          const isServerList = command.includes('srv');
          const isAdminList = command.includes('admin');
          const endpoint = isServerList ? 'servers' : 'users';

          let response = await fetch(`${panelConfig.panelDomain}/api/application/${endpoint}?page=${halaman}&per_page=25`, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: `Bearer ${panelConfig.pltaKey}`
            }
          });

          let hasil = await response.json();
          if (!response.ok) throw new Error(`Kode error: ${response.status}`);
          if (hasil.errors) throw new Error(`Kesalahan: ${hasil.errors[0].detail}`);
          if (!hasil.data || hasil.data.length === 0) return editReply(xy, sentMessage.message_id, "<blockquote>📌 Tidak ada data yang terdaftar dalam sistem.</blockquote>");

          let filteredData = hasil.data;
          let title = isServerList ? 'Daftar Server' : 'Daftar Pengguna';

          if (isAdminList) {
            filteredData = hasil.data.filter(user => user.attributes.root_admin === true);
            title = 'Daftar Administrator';
          }

          if (filteredData.length === 0) return editReply(xy, sentMessage.message_id, `<blockquote>🚫 Tidak ada ${isAdminList ? 'admin' : 'data'} yang terdaftar di halaman ini.</blockquote>`);

          let daftar = `📡 <b>${title} (${serverVersion})</b> 📡\n`;
          daftar += `<b>URL Panel:</b> ${panelConfig.panelDomain}\n`;
          daftar += "━━━━━━━━━━━━━━━━━━━━━━━\n";

          for (let item of filteredData) {
            let info = item.attributes;
            const itemId = info.id;
            const itemName = info.name || info.username;
            const itemType = isServerList ? 'Server ID' : 'User ID';

            daftar += `<b>${itemType}</b>: <code>${itemId}</code>\n`;
            daftar += `<b>Nama</b>: ${itemName}\n`;
            daftar += "───────────────────────\n";
          }

          const totalPages = hasil.meta.pagination.total_pages;
          const totalItems = hasil.meta.pagination.total;
          
          daftar += `📄 <b>Halaman</b>: ${hasil.meta.pagination.current_page}/${totalPages}\n`;
          daftar += `📊 <b>Total Dihalaman Ini</b>: ${filteredData.length}\n`;
          daftar += `📊 <b>Total Keseluruhan</b>: ${totalItems}`;

          let buttons = new InlineKeyboard();
          const currentPage = hasil.meta.pagination.current_page;

          if (currentPage > 1) {
            buttons.text("⬅️ Sebelumnya", `${command} ${currentPage - 1}`);
          }
          if (currentPage < totalPages && currentPage < 25) {
            buttons.text("Berikutnya ➡️", `${command} ${currentPage + 1}`);
          }

          // Pembungkus terakhir dengan <blockquote>
          await xy.api.editMessageText(xy.chat.id, sentMessage.message_id, `<blockquote>${daftar}</blockquote>`, {
            parse_mode: "HTML",
            reply_markup: buttons.row(),
          });

        } catch (err) {
          console.log("❗ Error:", err);
          await editReply(xy, sentMessage.message_id, `<blockquote>⚠️ Terjadi kesalahan: ${err.message}</blockquote>`);
        }
      })();
      break;
    }

    case "delusr":
    case "delusrv2":
    case "delusrv3":
    case "delusrv4":
    case "deladmin":
    case "deladminv2":
    case "deladminv3":
    case "deladminv4":
    case "delsrv":
    case "delsrvv2":
    case "delsrvv3":
    case "delsrvv4": {
      if (!isOwner) return reply(mess.owner);

      const serverVersion = command.endsWith('v2') ? 'v2' : command.endsWith('v3') ? 'v3' : command.endsWith('v4') ? 'v4' : 'v1';
      const panelConfig = getPanelConfig(serverVersion);
      const targetType = command.includes('srv') ? 'server' : 'user';

      if (!text || !/^\d+$/.test(text)) {
        return reply(`<blockquote><b>Format salah!</b>\n\nContoh: <code>${prefix + command} 1</code></blockquote>`, {
          parse_mode: 'HTML'
        });
      }

      let targetId = text;
      const sentMessage = await reply(`<blockquote>⏳ <b>Sedang menghapus ${targetType} ID ${targetId}...</b></blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        try {
          let f = await fetch(`${panelConfig.panelDomain}/api/application/${targetType}s/${targetId}`, {
            method: "DELETE",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: `Bearer ${panelConfig.pltaKey}`
            }
          });

          if (f.status === 204) {
            await editReply(xy, sentMessage.message_id, `<blockquote>✅ ${targetType.charAt(0).toUpperCase() + targetType.slice(1)} dengan ID ${targetId} berhasil dihapus dari panel ${panelConfig.panelDomain}.</blockquote>`);
          } else {
            let data = await f.json();
            throw new Error(`Gagal: ${data.errors[0].detail}`);
          }
        } catch (err) {
          console.error("Error:", err);
          await editReply(xy, sentMessage.message_id, `<blockquote>❌ Terjadi kesalahan: ${err.message}</blockquote>`);
        }
      })();
      break
    }

    case "delallpanel":
    case "delallpanelv2":
    case "delallpanelv3":
    case "delallpanelv4": {
        if (!isOwner) return reply(mess.owner);
        const serverVersion = command.endsWith('v2') ? 'v2' : command.endsWith('v3') ? 'v3' : command.endsWith('v4') ? 'v4' : 'v1';
        const targetType = 'servers';
        
        const excludedIdsRaw = text.trim();

        if (!excludedIdsRaw) {
          return reply(`<blockquote>❌ Format salah!\n\nContoh: <code>${prefix + command} 1,2,3</code> (ID yang dikecualikan, dipisahkan koma)</blockquote>`, {
            parse_mode: 'HTML'
          });
        }
        

        const excludedIds = excludedIdsRaw
            .split(',')
            .map(id => id.trim())
            .filter(id => /^\d+$/.test(id))
            .map(id => String(id)); 
        if (excludedIds.length === 0) {
            return reply(`<blockquote>❌ ID yang dikecualikan tidak valid. Harap masukkan satu atau lebih ID server yang dipisahkan koma (misal: <code>1,2,3</code>).</blockquote>`, {
                parse_mode: 'HTML'
            });
        }

        const panelConfig = getPanelConfig(serverVersion);
        if (!panelConfig.panelDomain || !panelConfig.pltaKey) return reply("<blockquote>❌ Konfigurasi server tidak ditemukan.</blockquote>", {
          parse_mode: 'HTML'
        });

        const excludedIdsList = excludedIds.join(', ');

        const sentMessage = await reply(`<blockquote>⏳ Mengambil daftar semua server di server ${serverVersion}...\n\nID yang dikecualikan: ${excludedIdsList}</blockquote>`, { 
          parse_mode: 'HTML'
        });

        (async () => {
          try {
            let allItems = [];
            let page = 1;
            let hasMore = true;

            // 1. Ambil Semua Server
            while (hasMore) {
                const response = await axios.get(`${panelConfig.panelDomain}/api/application/${targetType}?page=${page}`, {
                    headers: { 'Authorization': `Bearer ${panelConfig.pltaKey}` }
                });
                const result = response.data;
                allItems = allItems.concat(result.data);
                hasMore = result.meta.pagination.current_page < result.meta.pagination.total_pages;
                page++;
            }

            let serversToDelete = [];
            let deletedCount = 0;
            let failedCount = 0;
            const itemsPerChunk = 45;
            let firstMessageId = sentMessage.message_id;
            let chunkIndex = 0;
            
            // Filter server yang akan dihapus
            allItems.forEach(item => {
                const serverId = String(item.attributes.id);
                const serverName = item.attributes.name;
                if (!excludedIds.includes(serverId)) {
                    serversToDelete.push({ id: serverId, name: serverName });
                }
            });
            
            const totalToDelete = serversToDelete.length;
            if (totalToDelete === 0) {
                 return editReply(xy, sentMessage.message_id, `<blockquote>✅ Tidak ada server yang perlu dihapus (semua ID server sudah masuk daftar dikecualikan atau panel kosong).</blockquote>`);
            }
            
            // 2. Proses Penghapusan (Chunking)
            const totalChunks = Math.ceil(totalToDelete / itemsPerChunk);
            
            for (let i = 0; i < totalChunks; i++) {
                const startIndex = i * itemsPerChunk;
                const serversChunk = serversToDelete.slice(startIndex, startIndex + itemsPerChunk);
                
                let summary = `🗑️ <b>Proses Hapus Server Panel (${serverVersion.toUpperCase()})</b> 🗑️\n`;
                summary += `[Bagian ${i + 1}/${totalChunks}]\n`;
                summary += `ID Dikecualikan: <code>${excludedIdsList}</code>\n`;
                summary += "━━━━━━━━━━━━━━━━━━━━━━━\n";

                let currentChunkDeleted = 0;
                let currentChunkFailed = 0;
                
                for (const srv of serversChunk) {
                  try {
                    await axios.delete(`${panelConfig.panelDomain}/api/application/${targetType}/${srv.id}`, {
                      headers: {
                        'Authorization': `Bearer ${panelConfig.pltaKey}`
                      }
                    });
                    summary += `✅ Hapus: <b>${srv.name}</b> (ID: <code>${srv.id}</code>)\n`;
                    currentChunkDeleted++;
                  } catch (err) {
                    summary += `❌ Gagal: <b>${srv.name}</b> (ID: <code>${srv.id}</code>). Status: ${err.response ? err.response.status : 'Error'}\n`;
                    currentChunkFailed++;
                  }
                }
                
                deletedCount += currentChunkDeleted;
                failedCount += currentChunkFailed;
                summary += "───────────────────────\n";
                summary += `(Dihapus: ${currentChunkDeleted}, Gagal: ${currentChunkFailed})`;

                
                if (i === 0) {
                     await editReply(xy, firstMessageId, `<blockquote>${summary}</blockquote>`, null);
                } else {
                     await xy.reply(`<blockquote>${summary}</blockquote>`, { parse_mode: 'HTML' });
                }
            }


            // 3. Pesan Akhir Konfirmasi
            const finalMessage = `
✅ <b>Selesai menghapus server di server ${serverVersion}!</b>

Total Server Diambil: <b>${allItems.length}</b>
Total Server Dikecualikan: <b>${excludedIds.length}</b>
Total Server Dihapus: <b>${deletedCount}</b>
Total Server Gagal Hapus: <b>${failedCount}</b>

ID yang Dikecualikan: <code>${excludedIdsList}</code>
`;

            await xy.reply(`<blockquote>${finalMessage}</blockquote>`, { parse_mode: 'HTML' });


          } catch (err) {
            console.error(`Error fetching ${targetType}:`, err);
            await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengambil daftar ${targetType}. Pastikan API key dan domain sudah benar. Error: ${err.message}</blockquote>`);
          }
        })();
        break;
    }

    case "delalladmin":
    case "delalladminv2":
    case "delalladminv3":
    case "delalladminv4": {
      if (!isOwner) return reply(mess.owner);
      const serverVersion = command.endsWith('v2') ? 'v2' : command.endsWith('v3') ? 'v3' : command.endsWith('v4') ? 'v4' : 'v1';
      const targetType = 'users';
      const excludedIdsRaw = text.trim();

      if (!excludedIdsRaw) {
        return reply(`<blockquote>❌ Format salah!\n\nContoh: <code>${prefix + command} 1,2,3</code> (ID Admin yang dikecualikan, dipisahkan koma)</blockquote>`, {
          parse_mode: 'HTML'
        });
      }
      
      const excludedIds = excludedIdsRaw
          .split(',')
          .map(id => id.trim())
          .filter(id => /^\d+$/.test(id))
          .map(id => String(id)); 
      if (excludedIds.length === 0) {
          return reply(`<blockquote>❌ ID yang dikecualikan tidak valid. Harap masukkan satu atau lebih ID Admin yang dipisahkan koma.</blockquote>`, {
              parse_mode: 'HTML'
          });
      }

      const panelConfig = getPanelConfig(serverVersion);
      if (!panelConfig.panelDomain || !panelConfig.pltaKey) return reply("<blockquote>❌ Konfigurasi server tidak ditemukan.</blockquote>", {
        parse_mode: 'HTML'
      });

      const excludedIdsList = excludedIds.join(', ');

      const sentMessage = await reply(`<blockquote>⏳ Mengambil daftar Admin Panel (beserta server mereka) di server ${serverVersion}...\n\nID yang dikecualikan: ${excludedIdsList}</blockquote>`, { 
        parse_mode: 'HTML'
      });

      (async () => {
        try {
            let allItems = [];
            let page = 1;
            let hasMore = true;

            // 1. Ambil Semua User (termasuk servers untuk cek)
            while (hasMore) {
                const response = await axios.get(`${panelConfig.panelDomain}/api/application/${targetType}?page=${page}&include=servers`, { 
                    headers: { 'Authorization': `Bearer ${panelConfig.pltaKey}` }
                });

                const result = response.data;
                allItems = allItems.concat(result.data);
                hasMore = result.meta.pagination.current_page < result.meta.pagination.total_pages;
                page++;
            }

            let adminsToProcess = [];
            let totalAdminCount = 0;
            let excludedAdminCount = 0;

            // Filter Admin Panel yang akan diproses
            allItems.forEach(item => {
                const userIdToProcess = String(item.attributes.id);
                const userName = item.attributes.username;
                const isAdmin = item.attributes.root_admin === true; 
                
                if (isAdmin) {
                    totalAdminCount++;
                    if (!excludedIds.includes(userIdToProcess)) {
                        const serverData = item.attributes.relationships.servers.data.map(s => ({
                            id: String(s.attributes.id),
                            name: s.attributes.name
                        }));
                        adminsToProcess.push({ 
                            id: userIdToProcess, 
                            name: userName,
                            servers: serverData
                        });
                    } else {
                        excludedAdminCount++;
                    }
                }
            });
            
            const totalToProcess = adminsToProcess.length;
            if (totalToProcess === 0) {
                 return editReply(xy, sentMessage.message_id, `<blockquote>✅ Tidak ada Admin Panel yang perlu dihapus di server ${serverVersion}. (Total Admin: ${totalAdminCount}, Dikecualikan: ${excludedAdminCount})</blockquote>`);
            }


            let deletedAdminCount = 0;
            let deletedServerCount = 0;
            let failedAdminCount = 0;
            const itemsPerChunk = 25;
            let firstMessageId = sentMessage.message_id;
            
            // 2. Proses Penghapusan (Chunking)
            const totalChunks = Math.ceil(totalToProcess / itemsPerChunk);
            
            for (let i = 0; i < totalChunks; i++) {
                const startIndex = i * itemsPerChunk;
                const adminsChunk = adminsToProcess.slice(startIndex, startIndex + itemsPerChunk);
                
                let summary = `👑 <b>Proses Hapus Admin (${serverVersion.toUpperCase()})</b> 👑\n`;
                summary += `[Bagian ${i + 1}/${totalChunks}]\n`;
                summary += `Admin Dikecualikan: <code>${excludedIdsList}</code>\n`;
                summary += "━━━━━━━━━━━━━━━━━━━━━━━\n";

                let currentChunkDeletedAdmin = 0;
                let currentChunkFailedAdmin = 0;
                let currentChunkDeletedServer = 0;
                
                for (const admin of adminsChunk) {
                    let log = `\n👤 Admin: <b>${admin.name}</b> (ID: <code>${admin.id}</code>)\n`;
                    let serverDel = 0;
                    
                    // A. Hapus Server Terkait
                    if (admin.servers.length > 0) {
                        log += `  -> Menghapus ${admin.servers.length} server:\n`;
                        for (const srv of admin.servers) {
                            try {
                                await axios.delete(`${panelConfig.panelDomain}/api/application/servers/${srv.id}`, {
                                    headers: { 'Authorization': `Bearer ${panelConfig.pltaKey}` }
                                });
                                log += `  ✅ Server ${srv.id} dihapus.\n`;
                                serverDel++;
                            } catch (err) {
                                log += `  ❌ Gagal hapus Server ${srv.id}.\n`;
                            }
                        }
                    } else {
                        log += `  -> Tidak ada server terkait.\n`;
                    }
                    
                    // B. Hapus Admin
                    try {
                        await axios.delete(`${panelConfig.panelDomain}/api/application/${targetType}/${admin.id}`, {
                            headers: { 'Authorization': `Bearer ${panelConfig.pltaKey}` }
                        });
                        log += `  ✅ Admin berhasil dihapus!\n`;
                        currentChunkDeletedAdmin++;
                        deletedServerCount += serverDel;
                    } catch (err) {
                        log += `  ❌ Gagal hapus Admin! (Status: ${err.response ? err.response.status : 'Error'})\n`;
                        currentChunkFailedAdmin++;
                    }
                    
                    summary += log;
                    summary += "───────────────────────\n";
                }
                
                deletedAdminCount += currentChunkDeletedAdmin;
                failedAdminCount += currentChunkFailedAdmin;
                summary += `\n(Dihapus di chunk ini: Admin ${currentChunkDeletedAdmin}, Gagal: ${currentChunkFailedAdmin})`;

                
                if (i === 0) {
                     await editReply(xy, firstMessageId, `<blockquote>${summary}</blockquote>`, null);
                } else {
                     await xy.reply(`<blockquote>${summary}</blockquote>`, { parse_mode: 'HTML' });
                }
            }


            // 3. Pesan Akhir Konfirmasi
            const finalMessage = `
✅ <b>Selesai menghapus Admin Panel & Server mereka di server ${serverVersion}!</b>

Total Admin Panel Diambil: <b>${totalAdminCount}</b>
Total Admin Dikecualikan: <b>${excludedAdminCount}</b>
Total Server Dihapus (Otomatis): <b>${deletedServerCount}</b>
Total Admin Dihapus: <b>${deletedAdminCount}</b>
Total Admin Gagal Hapus: <b>${failedAdminCount}</b>

ID Admin yang Dikecualikan: <code>${excludedIdsList}</code>
`;

            await xy.reply(`<blockquote>${finalMessage}</blockquote>`, { parse_mode: 'HTML' });

        } catch (err) {
          console.error("Error fetching admin/server data:", err);
          await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengambil data: ${err.message}</blockquote>`);
        }
      })();
      break;
    }

    case "delallusr":
    case "delallusrv2":
    case "delallusrv3":
    case "delallusrv4": {
      if (!isOwner) return reply(mess.owner);
      const serverVersion = command.endsWith('v2') ? 'v2' : command.endsWith('v3') ? 'v3' : command.endsWith('v4') ? 'v4' : 'v1';
      const targetType = 'users';
      const excludedIdsRaw = text.trim();

      if (!excludedIdsRaw) {
        return reply(`<blockquote>❌ Format salah!\n\nContoh: <code>${prefix + command} 1,2,3</code> (ID yang dikecualikan, dipisahkan koma)</blockquote>`, {
          parse_mode: 'HTML'
        });
      }
      
      const excludedIds = excludedIdsRaw
          .split(',')
          .map(id => id.trim())
          .filter(id => /^\d+$/.test(id))
          .map(id => String(id)); 
      if (excludedIds.length === 0) {
          return reply(`<blockquote>❌ ID yang dikecualikan tidak valid. Harap masukkan satu atau lebih ID user yang dipisahkan koma.</blockquote>`, {
              parse_mode: 'HTML'
          });
      }

      const panelConfig = getPanelConfig(serverVersion);
      if (!panelConfig.panelDomain || !panelConfig.pltaKey) return reply("<blockquote>❌ Konfigurasi server tidak ditemukan.</blockquote>", {
        parse_mode: 'HTML'
      });

      const excludedIdsList = excludedIds.join(', ');

      const sentMessage = await reply(`<blockquote>⏳ Mengambil daftar semua user di server ${serverVersion}...\n\nID yang dikecualikan: ${excludedIdsList}</blockquote>`, { 
        parse_mode: 'HTML'
      });

      (async () => {
        try {
            let allItems = [];
            let page = 1;
            let hasMore = true;

            // 1. Ambil Semua User (termasuk server yang mereka miliki)
            while (hasMore) {
                const response = await axios.get(`${panelConfig.panelDomain}/api/application/${targetType}?page=${page}&include=servers`, { 
                    headers: { 'Authorization': `Bearer ${panelConfig.pltaKey}` }
                });

                const result = response.data;
                allItems = allItems.concat(result.data);
                hasMore = result.meta.pagination.current_page < result.meta.pagination.total_pages;
                page++;
            }

            let usersToDelete = [];
            let skippedUserCount = 0;

            // Filter user yang boleh dihapus (tanpa server dan tidak dikecualikan)
            allItems.forEach(item => {
                const userIdToDelete = String(item.attributes.id);
                const userName = item.attributes.username;
                const serverCount = item.attributes.relationships.servers.data.length;

                if (excludedIds.includes(userIdToDelete)) return; 
                
                if (serverCount === 0) {
                    usersToDelete.push({ id: userIdToDelete, name: userName, servers: 0 });
                } else {
                    skippedUserCount++;
                }
            });
            
            const totalToDelete = usersToDelete.length;
            if (totalToDelete === 0) {
                 return editReply(xy, sentMessage.message_id, `<blockquote>✅ Tidak ada user yang memenuhi kriteria penghapusan (tanpa server aktif & tidak dikecualikan).</blockquote>`);
            }


            let deletedCount = 0;
            let failedCount = 0;
            const itemsPerChunk = 45;
            let firstMessageId = sentMessage.message_id;
            
            // 2. Proses Penghapusan (Chunking)
            const totalChunks = Math.ceil(totalToDelete / itemsPerChunk);
            
            for (let i = 0; i < totalChunks; i++) {
                const startIndex = i * itemsPerChunk;
                const usersChunk = usersToDelete.slice(startIndex, startIndex + itemsPerChunk);
                
                let summary = `🗑️ <b>Proses Hapus User Panel (${serverVersion.toUpperCase()})</b> 🗑️\n`;
                summary += `[Bagian ${i + 1}/${totalChunks}]\n`;
                summary += `ID Dikecualikan: <code>${excludedIdsList}</code>\n`;
                summary += "━━━━━━━━━━━━━━━━━━━━━━━\n";

                let currentChunkDeleted = 0;
                let currentChunkFailed = 0;
                
                for (const usr of usersChunk) {
                    try {
                      await axios.delete(`${panelConfig.panelDomain}/api/application/${targetType}/${usr.id}`, {
                        headers: {
                          'Authorization': `Bearer ${panelConfig.pltaKey}`
                        }
                      });
                      summary += `✅ Hapus: <b>${usr.name}</b> (ID: <code>${usr.id}</code>)\n`;
                      currentChunkDeleted++;
                    } catch (err) {
                      summary += `❌ Gagal: <b>${usr.name}</b> (ID: <code>${usr.id}</code>). Status: ${err.response ? err.response.status : 'Error'}\n`;
                      currentChunkFailed++;
                    }
                }
                
                deletedCount += currentChunkDeleted;
                failedCount += currentChunkFailed;
                summary += "───────────────────────\n";
                summary += `(Dihapus di chunk ini: ${currentChunkDeleted}, Gagal: ${currentChunkFailed})`;

                
                if (i === 0) {
                     await editReply(xy, firstMessageId, `<blockquote>${summary}</blockquote>`, null);
                } else {
                     await xy.reply(`<blockquote>${summary}</blockquote>`, { parse_mode: 'HTML' });
                }
            }


            // 3. Pesan Akhir Konfirmasi
            const finalMessage = `
✅ <b>Selesai menghapus User di server ${serverVersion}!</b>

Total User Diambil: <b>${allItems.length}</b>
Total User Dikecualikan: <b>${excludedIds.length}</b>
User Dilewati (Ada Server Aktif): <b>${skippedUserCount}</b>
Total User Dihapus: <b>${deletedCount}</b>
Total User Gagal Hapus: <b>${failedCount}</b>

ID yang Dikecualikan: <code>${excludedIdsList}</code>
`;

            await xy.reply(`<blockquote>${finalMessage}</blockquote>`, { parse_mode: 'HTML' });

        } catch (err) {
          console.error(`Error fetching ${targetType}:`, err);
          await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengambil daftar ${targetType}. Pastikan API key dan domain sudah benar. Error: ${err.message}</blockquote>`);
        }
      })();
      break;
    }

    case "servercpu": {
      const serverVersion = text || 'v1';
      const userId = xy.from.id;


      const panelConfig = getPanelConfig(serverVersion);
      if (!panelConfig.panelDomain || !panelConfig.pltaKey || !panelConfig.pltcKey) {
        return reply(`<blockquote>❌ Konfigurasi server ${serverVersion} tidak ditemukan.</blockquote>`, {
          parse_mode: 'HTML'
        });
      }

      const sentMessage = await reply(`<blockquote>⏳ Memeriksa penggunaan CPU server di panel <b>${serverVersion}</b>...\n\nBatas CPU Wajar: <b>80%</b> (Ini akan membutuhkan waktu)</blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        try {
          let servers = [];
          let page = 1;
          let hasMore = true;

          while (hasMore) {
            const response = await axios.get(`${panelConfig.panelDomain}/api/application/servers?page=${page}`, {
              headers: {
                'Authorization': `Bearer ${panelConfig.pltaKey}`
              }
            });
            const result = response.data;
            servers = servers.concat(result.data);
            hasMore = result.meta.pagination.current_page < result.meta.pagination.total_pages;
            page++;
          }

          let abnormalCpuServers = [];

          for (const server of servers) {
            const {
              id: serverId,
              name: serverName,
              uuid: serverUuid
            } = server.attributes;

            try {
              const resourceResponse = await axios.get(`${panelConfig.panelDomain}/api/client/servers/${serverUuid}/resources`, {
                headers: {
                  'Authorization': `Bearer ${panelConfig.pltcKey}`
                }
              });

              const resources = resourceResponse.data.attributes.resources;
              const cpuUsage = resources.cpu_absolute;
              const cpuLimit = resources.cpu_limit;

              const effectiveLimit = cpuLimit > 0 ? cpuLimit : 100;

              if (cpuUsage > 80 && effectiveLimit <= 100 || (cpuLimit > 100 && cpuUsage > (cpuLimit * 0.8))) {
                abnormalCpuServers.push({
                  id: serverId,
                  name: serverName,
                  usage: cpuUsage,
                  limit: cpuLimit,
                });
              }
            } catch (error) {
              
            }
          }

          if (abnormalCpuServers.length === 0) {
            return editReply(xy, sentMessage.message_id, `<blockquote>✅ Tidak ditemukan server dengan penggunaan CPU di atas batas wajar (80%) di panel <b>${serverVersion}</b>.</blockquote>`);
          }

          let message = `🚨 <b>Daftar Server CPU Tidak Wajar (${serverVersion})</b> 🚨\n\n`;
          message += `<b>Batas Wajar:</b> 80%\n`;
          message += "━━━━━━━━━━━━━━━━━━━━━━━\n";

          abnormalCpuServers.forEach(srv => {
            message += `🆔 <b>ID</b>: <code>${srv.id}</code>\n`;
            message += `🔹 <b>Nama</b>: ${srv.name}\n`;
            message += `📈 <b>Penggunaan</b>: ${srv.usage.toFixed(2)}% dari ${srv.limit}% \n`;
            message += "───────────────────────\n";
          });

          message += `📊 <b>Total Server Tidak Wajar</b>: ${abnormalCpuServers.length}`;

          await editReply(xy, sentMessage.message_id, `<blockquote>${message}</blockquote>`);

        } catch (err) {
          console.error("Error fetching server list or resources:", err);
          await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengambil data server: ${err.message}</blockquote>`);
        }
      })();
      break;
    }

    case "delsrvoff":
    case "delsrvoffv2":
    case "delsrvoffv3":
    case "delsrvoffv4": {
      const serverVersion = command.endsWith('v2') ? 'v2' : command.endsWith('v3') ? 'v3' : command.endsWith('v4') ? 'v4' : 'v1';
      const userId = xy.from.id;
      
      // 1. Pengecekan Akses: Hanya Owner yang boleh menghapus
      if (!checkUserRole(userId, ['owner'], serverVersion)) { 
        return reply(mess.owner);
      }

      const panelConfig = getPanelConfig(serverVersion);
      if (!panelConfig.panelDomain || !panelConfig.pltaKey || !panelConfig.pltcKey) {
        return reply("<blockquote>❌ Konfigurasi server tidak ditemukan.</blockquote>", {
          parse_mode: 'HTML'
        });
      }

      const sentMessage = await reply(`<blockquote>⏳ Mencari dan mulai menghapus semua server yang offline/stopped dari panel <b>${serverVersion.toUpperCase()}</b>... (Ini akan membutuhkan waktu)</blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        try {
          let allServers = [];
          let hasMore = true;
          let page = 1;

          // Mengambil semua server dari semua halaman API
          while (hasMore) {
            const response = await axios.get(`${panelConfig.panelDomain}/api/application/servers?page=${page}`, {
              headers: {
                'Authorization': `Bearer ${panelConfig.pltaKey}`
              }
            });
            const result = response.data;
            if (result.errors) throw new Error(`Gagal mengambil daftar server: ${result.errors[0].detail}`);
            allServers = allServers.concat(result.data);
            hasMore = result.meta.pagination.current_page < result.meta.pagination.total_pages;
            page++;
          }

          let inactiveServers = [];

          // Memeriksa status setiap server
          for (const server of allServers) {
            const serverUuid = server.attributes.uuid;
            const serverName = server.attributes.name;
            const serverId = server.attributes.id;

            // Memeriksa status server
            const status = await getServerStatus(serverUuid, panelConfig); 

            if (status === 'offline' || status === 'stopped') {
              inactiveServers.push({
                id: serverId,
                uuid: serverUuid,
                name: serverName,
                status: status,
              });
            }
          }
          

          const itemsPerChunk = 50; 
          const totalServers = inactiveServers.length;
          let deletedCount = 0;
          
          if (totalServers === 0) {
            return editReply(xy, sentMessage.message_id, `<blockquote>✅ Tidak ada server yang <b>Offline/Stopped</b> di server <b>${serverVersion.toUpperCase()}</b>. Tidak ada yang dihapus.</blockquote>`);
          }

          const totalChunks = Math.ceil(totalServers / itemsPerChunk);
          let firstMessageId = sentMessage.message_id;


          for (let i = 0; i < totalChunks; i++) {
              const startIndex = i * itemsPerChunk;
              const endIndex = startIndex + itemsPerChunk;
              const serversToProcess = inactiveServers.slice(startIndex, endIndex);
              
              let summary = `⚠️ <b>Proses Hapus Server Offline (${serverVersion.toUpperCase()})</b> ⚠️\n`;
              summary += `[Bagian ${i + 1}/${totalChunks}]\n`;
              summary += `Total Server Offline: ${totalServers}\n`;
              summary += "━━━━━━━━━━━━━━━━━━━━━━━\n";

              // Logika Penghapusan
              for (const srv of serversToProcess) {
                  try {
                      // Panggil API untuk menghapus server
                      await axios.delete(`${panelConfig.panelDomain}/api/application/servers/${srv.id}`, {
                          headers: {
                              'Authorization': `Bearer ${panelConfig.pltaKey}`
                          }
                      });
                      summary += `🗑️ Berhasil Hapus: <b>${srv.name}</b> (ID: <code>${srv.id}</code>)\n`;
                      deletedCount++;
                  } catch (err) {
                      summary += `❌ Gagal Hapus: <b>${srv.name}</b> (ID: <code>${srv.id}</code>). Error: ${err.response ? err.response.status : err.message}\n`;
                  }
                  summary += "───────────────────────\n";
              }
              
              // Mengirim atau Mengedit pesan hasil
              if (i === 0) {
                   // Gunakan editReply untuk chunk pertama
                   await editReply(xy, firstMessageId, `<blockquote>${summary}</blockquote>`, null);
              } else {
                   // Kirim pesan baru untuk chunk selanjutnya
                   await xy.reply(`<blockquote>${summary}</blockquote>`, { parse_mode: 'HTML' });
              }
          }
          
          // Pesan akhir konfirmasi
          await xy.reply(`<blockquote>✅ Proses penghapusan selesai. Total **${deletedCount}** server berhasil dihapus dari total **${totalServers}** server offline/stopped.</blockquote>`, { parse_mode: 'HTML' });


        } catch (err) {
          console.error("Error during delsrvoff process:", err);
          await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal menjalankan proses penghapusan: ${err.message}</blockquote>`);
        }
      })();
      break;
    }

    case "listsrvoff":
    case "listsrvoffv2":
    case "listsrvoffv3":
    case "listsrvoffv4": {
      const serverVersion = command.endsWith('v2') ? 'v2' : command.endsWith('v3') ? 'v3' : command.endsWith('v4') ? 'v4' : 'v1';
      const userId = xy.from.id;
      
      // 1. Pengecekan Akses: Owner, Partner, Reseller
      if (!checkUserRole(userId, ['owner', 'partner', 'reseller'], serverVersion)) { 
        return reply(mess.seller);
      }

      const panelConfig = getPanelConfig(serverVersion);
      if (!panelConfig.panelDomain || !panelConfig.pltaKey || !panelConfig.pltcKey) {
        return reply("<blockquote>❌ Konfigurasi server tidak ditemukan.</blockquote>", {
          parse_mode: 'HTML'
        });
      }

      const sentMessage = await reply(`<blockquote>⏳ Mencari semua server yang offline/stopped dari panel <b>${serverVersion.toUpperCase()}</b>... (Tunggu 2 Menit)</blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        try {
          let allServers = [];
          let hasMore = true;
          let page = 1;

          // Mengambil semua server dari semua halaman API
          while (hasMore) {
            const response = await axios.get(`${panelConfig.panelDomain}/api/application/servers?page=${page}`, {
              headers: {
                'Authorization': `Bearer ${panelConfig.pltaKey}`
              }
            });
            const result = response.data;
            if (result.errors) throw new Error(`Gagal mengambil daftar server: ${result.errors[0].detail}`);
            allServers = allServers.concat(result.data);
            hasMore = result.meta.pagination.current_page < result.meta.pagination.total_pages;
            page++;
          }

          let inactiveServers = [];

          // Memeriksa status setiap server
          for (const server of allServers) {
            const serverUuid = server.attributes.uuid;
            const serverName = server.attributes.name;
            const serverId = server.attributes.id;

            const status = await getServerStatus(serverUuid, panelConfig); 

            if (status === 'offline' || status === 'stopped') {
              inactiveServers.push({
                id: serverId,
                name: serverName,
                status: status,
              });
            }
          }
          

          const itemsPerChunk = 50; 
          const totalServers = inactiveServers.length;
          
          if (totalServers === 0) {
            return editReply(xy, sentMessage.message_id, `<blockquote>✅ Tidak ada server yang <b>Offline/Stopped</b> di server <b>${serverVersion.toUpperCase()}</b>.</blockquote>`);
          }

          // Total chunk yang dibutuhkan
          const totalChunks = Math.ceil(totalServers / itemsPerChunk);
          let firstMessageId = sentMessage.message_id;

          for (let i = 0; i < totalChunks; i++) {
              const startIndex = i * itemsPerChunk;
              const endIndex = startIndex + itemsPerChunk;
              const serversToDisplay = inactiveServers.slice(startIndex, endIndex);

              // --- Membangun Pesan ---
              let summary = `⚠️ <b>Daftar Server Offline/Stopped (${serverVersion.toUpperCase()})</b> ⚠️\n`;
              summary += `[Bagian ${i + 1}/${totalChunks}]\n`;
              summary += `Total Server Offline: ${totalServers}\n`;
              summary += "━━━━━━━━━━━━━━━━━━━━━━━\n";

              // Iterasi item untuk chunk saat ini
              serversToDisplay.forEach(srv => { 
                summary += `🆔 <b>ID</b>: <code>${srv.id}</code>\n`;
                summary += `🔹 <b>Nama</b>: ${srv.name}\n`;
                summary += `💤 <b>Status</b>: ${srv.status.toUpperCase()}\n`;
                summary += "───────────────────────\n";
              });
              

              if (i === 0) {

                   await editReply(xy, firstMessageId, `<blockquote>${summary}</blockquote>`, null);
              } else {

                   await xy.reply(`<blockquote>${summary}</blockquote>`, { parse_mode: 'HTML' });
              }
          }
          
          if (totalChunks > 1) {
              await xy.reply(`<blockquote>✅ Selesai menampilkan semua ${totalServers} server offline/stopped dalam ${totalChunks} pesan.</blockquote>`, { parse_mode: 'HTML' });
          }


        } catch (err) {
          console.error("Error fetching servers for status check:", err);
          await editReply(xy, sentMessage.message_id, `<blockquote>❌ Gagal mengambil status server: ${err.message}</blockquote>`);
        }
      })();
      break;
    }



    case "pay": {
      if (!text) return reply('<blockquote>Lengkapi Command kamu!\n\nContoh: <code>.pay 1000</code></blockquote>', {
        parse_mode: 'HTML'
      });
      if (text < 1000) return reply(`<blockquote>Minimal Transaksi harus Rp ${minimalDeposit}</blockquote>`, {
        parse_mode: 'HTML'
      });

      const sentMessage = await reply(`<blockquote>⏳ <b>Memproses pembayaran...</b></blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        let val = text
          .replace(/[^0-9\-\/+*×÷πEe()piPI/]/g, '')
          .replace(/×/g, '*')
          .replace(/÷/g, '/')
          .replace(/π|pi/gi, 'Math.PI')
          .replace(/e/gi, 'Math.E')
          .replace(/\/+/g, '/')
          .replace(/\++/g, '+')
          .replace(/-+/g, '-');

        let deponya;
        try {
          let result = (new Function('return ' + val))();
          if (!result) throw new Error('Format perhitungan salah');
          deponya = result;
        } catch (e) {
          return editReply(xy, sentMessage.message_id, '<blockquote>Format salah, hanya 0-9 dan simbol -, +, *, /, ×, ÷, π, e, (, ) yang disupport</blockquote>');
        }

        let ref = Math.floor(Math.random() * 100000000);
        let h2hkey = apikeyhost

        try {
          // 1. Buat Deposit
          let config = {
            method: 'POST',
            url: 'https://atlantich2h.com/deposit/create',
            data: new URLSearchParams({
              api_key: h2hkey,
              reff_id: ref,
              nominal: deponya,
              type: 'ewallet',
              metode: 'qris'
            })
          };

          const res = await axios(config);
          if (!res.data.status) throw new Error(res.data.message || 'Unknown error');

          const qrData = res.data.data.qr_string;
          const qrMessage = `Silahkan scan Qriss diatas untuk membayar sejumlah:\n
        Bill: ${res.data.data.nominal}\n
        Status: ${res.data.data.status}\n\n
        Jika ingin cancel transaksi ketik :\n
        <code>/cancelpay</code>\n
        note: ketik command itu sekalian reply pesan ini (khusus owner)`;

          const qrImageUrl = await toqrcode(qrData);
          const sentQR = await xy.api.sendPhoto(sender, qrImageUrl, {
            caption: qrMessage,
            parse_mode: 'HTML'
          });

          // Hapus pesan "memproses"
          await xy.api.deleteMessage(xy.chat.id, sentMessage.message_id);

          let obj = {
            id: sender,
            ref: res.data.data.id,
            messageId: sentQR.message_id,
            status: res.data.data.status
          };

          if (!fs.existsSync('./src/database/datasaldo')) fs.mkdirSync('./src/database/datasaldo');
          fs.writeFileSync(`./src/database/datasaldo/${sender}.json`, JSON.stringify(obj));

          // 2. Loop Cek Status
          let status = res.data.data.status;
          const topup = {
            method: 'POST',
            url: 'https://atlantich2h.com/deposit/status',
            data: new URLSearchParams({
              api_key: h2hkey,
              id: res.data.data.id
            })
          };
          const acc = {
            method: 'POST',
            url: 'https://atlantich2h.com/deposit/instant',
            data: new URLSearchParams({
              api_key: h2hkey,
              id: res.data.data.id,
              action: 'true'
            })
          };

          while (status !== 'processing') {
            await sleep(1000);

            const response = await axios(topup);
            status = response.data.data.status;

            if (status === 'cancel' || status === 'expired') {
              await xy.api.sendMessage(xy.chat.id, `<blockquote>Transaksi ${status}</blockquote>`, {
                parse_mode: 'HTML'
              });
              break;
            }

            if (status === 'processing') {
              await axios(acc);
              status = 'success';
              await xy.api.deleteMessage(sender, sentQR.message_id);
              await xy.api.sendMessage(xy.chat.id, `<blockquote>Transaksi telah sukses\n\nTerimakasih atas pembelian Anda</blockquote>`, {
                parse_mode: 'HTML'
              });
              fs.unlinkSync(`./src/database/datasaldo/${sender}.json`);
              break;
            }
          }
        } catch (error) {
          console.log('Deposit error:', error.message);
          await editReply(xy, sentMessage.message_id, `<blockquote>Terjadi error saat membuat deposit. Silakan coba lagi. Error: ${error.message}</blockquote>`);
        }
      })();
      break;
    }

    case "cancelpay": {
      if (!isOwner) return reply(mess.owner);
      const dbPath = `./src/database/datasaldo/${sender}.json`;

      if (!fs.existsSync(dbPath)) {
        return reply("<blockquote>❌ Kamu tidak memiliki deposit yang sedang berlangsung.</blockquote>", {
          parse_mode: 'HTML'
        });
      }

      const sentMessage = await reply(`<blockquote>⏳ <b>Membatalkan pembayaran...</b></blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        const data = JSON.parse(fs.readFileSync(dbPath, "utf8"));
        const config = {
          method: "POST",
          url: "https://atlantich2h.com/deposit/cancel",
          data: new URLSearchParams({
            api_key: apikeyhost,
            id: data.ref
          })
        };

        try {
          await axios(config);
          await xy.api.deleteMessage(sender, data.messageId);
          fs.unlinkSync(dbPath);
          await editReply(xy, sentMessage.message_id, "<blockquote>✅ Deposit berhasil dibatalkan.</blockquote>");
        } catch (error) {
          console.error("❌ Gagal membatalkan deposit:", error?.response?.data || error.message);
          await editReply(xy, sentMessage.message_id, "<blockquote>❌ Gagal membatalkan deposit. Mungkin sudah dibayar atau ID tidak ditemukan.</blockquote>");
        }
      })();
      break;
    }

    case "saldo":
    case "cek": {
      if (!isOwner) return reply(mess.owner);

      const sentMessage = await reply(`<blockquote>⏳ <b>Mengecek saldo...</b></blockquote>`, {
        parse_mode: 'HTML'
      });

      (async () => {
        try {
          const response = await axios("https://atlantich2h.com/get_profile", {
            method: "POST",
            data: new URLSearchParams({
              api_key: apikeyhost
            })
          });

          const res = response.data;
          if (!res.status || !res.data) throw new Error("Gagal mengambil data profil.");

          const {
            name,
            username,
            balance,
            status
          } = res.data;

          const message = `💼 Informasi Akun

👤 Nama: ${name}
🆔 Username: ${username}
💰 Saldo: Rp${Number(balance).toLocaleString("id-ID")}
📌 Status: ${status}`;

          await editReply(xy, sentMessage.message_id, `<blockquote>${message}</blockquote>`);

        } catch (err) {
          console.error(err);
          await editReply(xy, sentMessage.message_id, "<blockquote>❌ Terjadi kesalahan saat mengambil data saldo.</blockquote>");
        }
      })();
      break;
    }

    
    case 'open': {
      if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
      if (!isGroupAdmins) return reply(mess.admin);
      if (!isBotGroupAdmins) return reply(mess.botAdmin);

      try {
        await xy.api.setChatPermissions(xy.chat.id, {
          can_send_messages: true,
          can_send_audios: true,
          can_send_photos: true,
          can_send_videos: true,
          can_send_voice_notes: true,
          can_send_video_notes: true,
          can_send_stickers: true,
          can_send_animations: true,
          can_send_polls: true,
          can_send_other_messages: true,
          can_add_web_page_previews: true,
        });
        reply(`<blockquote>✅ Grup <b>${xy.chat.title}</b> berhasil <b>DIBUKA</b>!\n\nSemua anggota sekarang dapat mengirim pesan.</blockquote>`, { parse_mode: 'HTML' });
      } catch (e) {
        console.error("Error /open:", e);
        reply(`<blockquote>❌ Gagal membuka grup.\n\nPastikan bot memiliki hak admin untuk <b>mengubah izin grup</b>.</blockquote>`, { parse_mode: 'HTML' });
      }
      break;
    }

    case 'close': {
      if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
      if (!isGroupAdmins) return reply(mess.admin);
      if (!isBotGroupAdmins) return reply(mess.botAdmin);

      try {
        await xy.api.setChatPermissions(xy.chat.id, {
          can_send_messages: false,
        });
        reply(`<blockquote>🔒 Grup <b>${xy.chat.title}</b> berhasil <b>DITUTUP</b>!\n\nHanya admin yang dapat mengirim pesan.</blockquote>`, { parse_mode: 'HTML' });
      } catch (e) {
        console.error("Error /close:", e);
        reply(`<blockquote>❌ Gagal menutup grup.\n\nPastikan bot memiliki hak admin untuk <b>mengubah izin grup</b>.</blockquote>`, { parse_mode: 'HTML' });
      }
      break;
    }

    case 'changetitle': {
      if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
      if (!isGroupAdmins) return reply(mess.admin);
      if (!isBotGroupAdmins) return reply(mess.botAdmin);

      if (!text) return reply(`<blockquote>❌ Format salah! Gunakan: <code>${prefix + command} [Judul Baru]</code></blockquote>`, { parse_mode: 'HTML' });

      try {
        await xy.api.setChatTitle(xy.chat.id, text);
        reply(`<blockquote>✅ Nama grup berhasil diubah menjadi: <b>${text}</b></blockquote>`, { parse_mode: 'HTML' });
      } catch (e) {
        console.error("Error /changetitle:", e);
        reply(`<blockquote>❌ Gagal mengubah nama grup.\n\nPastikan bot memiliki hak admin untuk <b>mengubah judul</b>.</blockquote>`, { parse_mode: 'HTML' });
      }
      break;
    }

    case 'changedesk': {
      if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
      if (!isGroupAdmins) return reply(mess.admin);
      if (!isBotGroupAdmins) return reply(mess.botAdmin);
      
      const newDescription = text.trim() || "Tidak ada deskripsi.";

      try {
        await xy.api.setChatDescription(xy.chat.id, newDescription);
        reply(`<blockquote>✅ Deskripsi grup berhasil diubah:\n\n<i>${newDescription}</i></blockquote>`, { parse_mode: 'HTML' });
      } catch (e) {
        console.error("Error /changedesk:", e);
        reply(`<blockquote>❌ Gagal mengubah deskripsi grup.\n\nPastikan bot memiliki hak admin untuk <b>mengubah deskripsi</b>.</blockquote>`, { parse_mode: 'HTML' });
      }
      break;
    }

    case 'pin': {
      if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
      if (!isGroupAdmins) return reply(mess.admin);
      if (!isBotGroupAdmins) return reply(mess.botAdmin);
      
      if (!xy.message.reply_to_message) return reply('<blockquote>❌ Harap balas pesan yang ingin Anda <b>sematkan</b>.</blockquote>', { parse_mode: 'HTML' });

      try {
        const messageId = xy.message.reply_to_message.message_id;
        await xy.api.pinChatMessage(xy.chat.id, messageId, { disable_notification: true }); 
        reply(`<blockquote>📌 Pesan berhasil <b>disematkan</b>.</blockquote>`, { parse_mode: 'HTML' });
      } catch (e) {
        console.error("Error /pin:", e);
        reply(`<blockquote>❌ Gagal menyematkan pesan.\n\nPastikan bot memiliki hak admin untuk <b>menyematkan pesan</b>.</blockquote>`, { parse_mode: 'HTML' });
      }
      break;
    }

    case 'unpin': {
      if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
      if (!isGroupAdmins) return reply(mess.admin);
      if (!isBotGroupAdmins) return reply(mess.botAdmin);

      try {
        if (xy.message.reply_to_message) {
          const messageId = xy.message.reply_to_message.message_id;
          await xy.api.unpinChatMessage(xy.chat.id, messageId);
          reply(`<blockquote>📌 Sematan pesan berhasil <b>dilepaskan</b>.</blockquote>`, { parse_mode: 'HTML' });
        } else {
          await xy.api.unpinAllChatMessages(xy.chat.id);
          reply(`<blockquote>📌 Semua pesan sematan berhasil <b>dilepaskan</b>.</blockquote>`, { parse_mode: 'HTML' });
        }
      } catch (e) {
        console.error("Error /unpin:", e);
        reply(`<blockquote>❌ Gagal melepaskan sematan pesan.\n\nPastikan bot memiliki hak admin untuk <b>menyematkan pesan</b>.</blockquote>`, { parse_mode: 'HTML' });
      }
      break;
    }
    


    case 'add':
    case 'kick': {
      if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
      if (!isGroupAdmins) return reply(mess.admin);
      if (!isBotGroupAdmins) return reply(mess.botAdmin);

      const targetUser = xy.message.reply_to_message?.from;
      if (!targetUser) return reply(`<blockquote>❌ Harap balas pesan anggota yang ingin di${command}.</blockquote>`, { parse_mode: 'HTML' });

      try {
        if (command === 'add') {
          // Telegram API tidak memiliki metode 'add', tapi bisa menggunakan inviteLink (lebih rumit) atau menunggu anggota sendiri yang masuk.
          // Untuk bot Telegram, cara paling mudah adalah meminta pengguna join link.
          return reply(`<blockquote>Untuk menambahkan <b>${targetUser.first_name}</b>, kirim link undangan grup ini kepadanya.</blockquote>`, { parse_mode: 'HTML' });
        } else if (command === 'kick') {
          await xy.api.banChatMember(xy.chat.id, targetUser.id);
          reply(`<blockquote>✅ Anggota <b>${targetUser.first_name}</b> telah berhasil dikeluarkan dari grup.</blockquote>`, { parse_mode: 'HTML' });
        }
      } catch (e) {
        console.error(`Error /${command}:`, e);
        reply(`<blockquote>❌ Gagal menjalankan perintah /${command}. Pastikan bot memiliki hak admin yang sesuai.</blockquote>`, { parse_mode: 'HTML' });
      }
      break;
    }
    
    case 'promote':
    case 'demote': {
      if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
      if (!isGroupAdmins) return reply(mess.admin);
      if (!isBotGroupAdmins) return reply(mess.botAdmin);

      const targetUser = xy.message.reply_to_message?.from;
      if (!targetUser) return reply(`<blockquote>❌ Harap balas pesan anggota yang ingin di${command}.</blockquote>`, { parse_mode: 'HTML' });
      
      try {
        if (command === 'promote') {
            await xy.api.promoteChatMember(xy.chat.id, targetUser.id, {
                can_change_info: true,
                can_delete_messages: true,
                can_invite_users: true,
                can_restrict_members: true,
                can_pin_messages: true,
                can_manage_topics: true,
                can_manage_video_chats: true,
                can_promote_members: false // Bot tidak boleh mempromosikan admin lain untuk mempromosikan
            });
            reply(`<blockquote>✅ Anggota <b>${targetUser.first_name}</b> telah berhasil diangkat menjadi Admin.</blockquote>`, { parse_mode: 'HTML' });
        } else if (command === 'demote') {
            await xy.api.promoteChatMember(xy.chat.id, targetUser.id, {
                can_change_info: false,
                can_delete_messages: false,
                can_invite_users: false,
                can_restrict_members: false,
                can_pin_messages: false,
                can_manage_topics: false,
                can_manage_video_chats: false,
                can_promote_members: false
            });
            reply(`<blockquote>✅ Admin <b>${targetUser.first_name}</b> telah berhasil diturunkan pangkatnya menjadi anggota biasa.</blockquote>`, { parse_mode: 'HTML' });
        }
      } catch (e) {
        console.error(`Error /${command}:`, e);
        reply(`<blockquote>❌ Gagal menjalankan perintah /${command}. Pastikan bot memiliki hak admin yang lebih tinggi dari target.</blockquote>`, { parse_mode: 'HTML' });
      }
      break;
    }

    case 'welcome':
    case 'leave': {
      if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
      if (!isGroupAdmins) return reply(mess.admin);

      const groupID = xy.chat.id;
      let listData = readJson(WELEAVE_FILE, []);
      let foundIndex = listData.findIndex(item => item.id === groupID);

      const action = text.toLowerCase().trim();
      const statusKey = command === 'welcome' ? 'welcome' : 'leave';

      if (action === 'on') {
          if (foundIndex === -1) {
              listData.push({ id: groupID, welcome: command === 'welcome', leave: command === 'leave' });
          } else {
              listData[foundIndex][statusKey] = true;
          }
          writeJson(WELEAVE_FILE, listData);
          reply(`<blockquote>✅ Pesan ${statusKey} berhasil <b>DIAKTIFKAN</b> di grup ini.</blockquote>`, { parse_mode: 'HTML' });
      } else if (action === 'off') {
          if (foundIndex !== -1) {
              listData[foundIndex][statusKey] = false;
              writeJson(WELEAVE_FILE, listData);
          }
          reply(`<blockquote>❌ Pesan ${statusKey} berhasil <b>DINONAKTIFKAN</b> di grup ini.</blockquote>`, { parse_mode: 'HTML' });
      } else {
          reply(`<blockquote>📌 Penggunaan: <code>/${command} on</code> atau <code>/${command} off</code></blockquote>`, { parse_mode: 'HTML' });
      }
      break;
    }

    case 'antilink': {
      if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
      if (!isGroupAdmins) return reply(mess.admin);

      const groupID = xy.chat.id;
      let listData = readJson(ANTILINK_FILE, []);
      let foundIndex = listData.findIndex(item => item.id === groupID);
      const action = text.toLowerCase().trim();

      if (action === 'on') {
          if (foundIndex === -1) {
              listData.push({ id: groupID, active: true });
          } else {
              listData[foundIndex].active = true;
          }
          writeJson(ANTILINK_FILE, listData);
          reply(`<blockquote>✅ Fitur Anti-Link berhasil <b>DIAKTIFKAN</b>. Bot akan menghapus pesan yang mengandung link (kecuali admin).</blockquote>`, { parse_mode: 'HTML' });
      } else if (action === 'off') {
          if (foundIndex !== -1) {
              listData[foundIndex].active = false;
              writeJson(ANTILINK_FILE, listData);
          }
          reply(`<blockquote>❌ Fitur Anti-Link berhasil <b>DINONAKTIFKAN</b>.</blockquote>`, { parse_mode: 'HTML' });
      } else {
          const status = foundIndex !== -1 && listData[foundIndex].active ? 'AKTIF' : 'NONAKTIF';
          reply(`<blockquote>⚙️ Status Anti-Link saat ini: <b>${status}</b>\n\n📌 Penggunaan: <code>/${command} on</code> atau <code>/${command} off</code></blockquote>`, { parse_mode: 'HTML' });
      }
      break;
    }
    
    case 'linkgroup': {
        if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
        if (!isGroupAdmins) return reply(mess.admin);
        if (!isBotGroupAdmins) return reply(mess.botAdmin);

        try {
            const inviteLink = await xy.api.exportChatInviteLink(xy.chat.id);
            reply(`<blockquote>🔗 Link Undangan Grup <b>${xy.chat.title}</b>:\n\n${inviteLink}</blockquote>`, { parse_mode: 'HTML' });
        } catch (e) {
            console.error("Error /linkgroup:", e);
            reply(`<blockquote>❌ Gagal mendapatkan link grup. Pastikan bot memiliki hak admin untuk <b>mengundang pengguna</b>.</blockquote>`, { parse_mode: 'HTML' });
        }
        break;
    }
    
    case 'delete': {
        if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
        if (!isGroupAdmins) return reply(mess.admin);
        if (!isBotGroupAdmins) return reply(mess.botAdmin);

        if (!xy.message.reply_to_message) return reply('<blockquote>❌ Harap balas pesan yang ingin Anda <b>hapus</b>.</blockquote>', { parse_mode: 'HTML' });
        
        try {
            await xy.api.deleteMessage(xy.chat.id, xy.message.reply_to_message.message_id);
            await xy.api.deleteMessage(xy.chat.id, xy.message.message_id); // Hapus perintah user
        } catch (e) {
            console.error("Error /delete:", e);
            reply(`<blockquote>❌ Gagal menghapus pesan. Pastikan bot memiliki hak admin untuk <b>menghapus pesan</b>.</blockquote>`, { parse_mode: 'HTML' });
        }
        break;
    }
    
    case 'warn': {
        if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
        if (!isGroupAdmins) return reply(mess.admin);
        
        const targetUser = xy.message.reply_to_message?.from;
        if (!targetUser) return reply(`<blockquote>❌ Harap balas pesan anggota yang ingin diwarn.</blockquote>`, { parse_mode: 'HTML' });
        
        const targetId = String(targetUser.id);
        const groupID = String(xy.chat.id);
        const maxWarn = 3;

        let groupWarns = warnDB[groupID] || {};
        let userWarns = groupWarns[targetId] || 0;

        userWarns++;
        groupWarns[targetId] = userWarns;
        warnDB[groupID] = groupWarns;
        saveWarnDB(warnDB);

        if (userWarns >= maxWarn) {
            try {
                await xy.api.banChatMember(xy.chat.id, targetUser.id);
                delete groupWarns[targetId];
                warnDB[groupID] = groupWarns;
                saveWarnDB(warnDB);
                reply(`<blockquote>⚠️ <b>PERINGATAN!</b> (${userWarns}/${maxWarn})\n\nAnggota <b>${targetUser.first_name}</b> telah mencapai batas peringatan dan dikeluarkan dari grup.</blockquote>`, { parse_mode: 'HTML' });
            } catch (e) {
                console.error("Error kick warn:", e);
                reply(`<blockquote>⚠️ <b>PERINGATAN!</b> (${userWarns}/${maxWarn})\n\nAnggota <b>${targetUser.first_name}</b> telah mencapai batas peringatan, namun gagal dikeluarkan.</blockquote>`, { parse_mode: 'HTML' });
            }
        } else {
            reply(`<blockquote>⚠️ <b>PERINGATAN!</b> (${userWarns}/${maxWarn})\n\nAnggota <b>${targetUser.first_name}</b> menerima peringatan. Jika mencapai ${maxWarn} kali, dia akan dikeluarkan.</blockquote>`, { parse_mode: 'HTML' });
        }
        break;
    }
    
    case 'warns': {
        if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
        
        const targetUser = xy.message.reply_to_message?.from || xy.from;
        const targetId = String(targetUser.id);
        const groupID = String(xy.chat.id);
        const maxWarn = 3;

        const groupWarns = warnDB[groupID] || {};
        const userWarns = groupWarns[targetId] || 0;
        
        reply(`<blockquote>👤 <b>${targetUser.first_name}</b>\n\nTotal Peringatan: <b>${userWarns}/${maxWarn}</b></blockquote>`, { parse_mode: 'HTML' });
        break;
    }

    case 'resetwarn': {
        if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
        if (!isGroupAdmins) return reply(mess.admin);

        const targetUser = xy.message.reply_to_message?.from;
        if (!targetUser) return reply(`<blockquote>❌ Harap balas pesan anggota untuk me-reset peringatannya.</blockquote>`, { parse_mode: 'HTML' });

        const targetId = String(targetUser.id);
        const groupID = String(xy.chat.id);

        let groupWarns = warnDB[groupID] || {};
        if (groupWarns[targetId]) {
            delete groupWarns[targetId];
            warnDB[groupID] = groupWarns;
            saveWarnDB(warnDB);
            reply(`<blockquote>✅ Peringatan anggota <b>${targetUser.first_name}</b> telah di-reset (0/3).</blockquote>`, { parse_mode: 'HTML' });
        } else {
            reply(`<blockquote>⚠️ Anggota <b>${targetUser.first_name}</b> tidak memiliki peringatan untuk di-reset.</blockquote>`, { parse_mode: 'HTML' });
        }
        break;
    }
    
    case 'createpolling':
    case 'groupstats': {
        reply(`<blockquote>Fitur <b>/${command}</b> (Grup) memerlukan integrasi API atau proses yang lebih kompleks dan masih dalam tahap pengembangan.</blockquote>`, { parse_mode: 'HTML' });
        break;
    }



    case 'addlist': {
        if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);

        const productInfo = text.split('|');
        if (productInfo.length < 2) return reply(`<blockquote>❌ Format salah!\n\nPenggunaan: <code>/addlist [Key Produk] | [Deskripsi/Respon]</code>\n(Opsional: Reply foto/video untuk menambahkan media)</blockquote>`, { parse_mode: 'HTML' });
        
        const [key, responseText] = productInfo.map(s => s.trim());
        const groupID = xy.chat.id;

        let listData = readJson(LIST_FILE);
        const isExist = listData.some(item => item.id === groupID && item.key.toLowerCase() === key.toLowerCase());
        if (isExist) return reply(`<blockquote>⚠️ Key produk "<b>${key}</b>" sudah ada di grup ini. Gunakan <code>/updatelist</code> untuk mengubahnya.</blockquote>`, { parse_mode: 'HTML' });

        const newItem = {
            id: groupID,
            key: key,
            response: responseText,
            isImage: false,
            image_url: ''
        };

        const replyMessage = xy.message.reply_to_message;
        if (replyMessage && (replyMessage.photo || replyMessage.video)) {

            const mediaType = replyMessage.photo ? 'Photo' : 'Video';
            newItem.isImage = true;
            newItem.image_url = 'https://telegra.ph/file/134ccbbd0dfc434a910ab.png'; 
            
            reply(`<blockquote>⏳ Media sedang diunggah... (Menggunakan URL placeholder sementara)</blockquote>`, { parse_mode: 'HTML' });
            

            
            listData.push(newItem);
            writeJson(LIST_FILE, listData);
            reply(`<blockquote>✅ Produk/Respon <b>${key}</b> berhasil ditambahkan dengan ${mediaType} sebagai media!</blockquote>`, { parse_mode: 'HTML' });
            
        } else {
            listData.push(newItem);
            writeJson(LIST_FILE, listData);
            reply(`<blockquote>✅ Produk/Respon <b>${key}</b> berhasil ditambahkan (Teks saja).</blockquote>`, { parse_mode: 'HTML' });
        }
        break;
    }

    case 'dellist': {
        if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
        if (!text) return reply(`<blockquote>❌ Format salah!\n\nPenggunaan: <code>/dellist [Key Produk]</code></blockquote>`, { parse_mode: 'HTML' });

        const key = text.trim();
        const groupID = xy.chat.id;
        let listData = readJson(LIST_FILE);
        
        const initialLength = listData.length;
        listData = listData.filter(item => !(item.id === groupID && item.key.toLowerCase() === key.toLowerCase()));

        if (listData.length < initialLength) {
            writeJson(LIST_FILE, listData);
            reply(`<blockquote>✅ Produk/Respon <b>${key}</b> berhasil dihapus dari grup ini.</blockquote>`, { parse_mode: 'HTML' });
        } else {
            reply(`<blockquote>⚠️ Key produk "<b>${key}</b>" tidak ditemukan di grup ini.</blockquote>`, { parse_mode: 'HTML' });
        }
        break;
    }

    case 'updatelist': {
        if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);

        const productInfo = text.split('|');
        if (productInfo.length < 2) return reply(`<blockquote>❌ Format salah!\n\nPenggunaan: <code>/updatelist [Key Produk] | [Deskripsi/Respon Baru]</code>\n(Opsional: Reply foto/video untuk menambahkan media baru)</blockquote>`, { parse_mode: 'HTML' });
        
        const [key, responseText] = productInfo.map(s => s.trim());
        const groupID = xy.chat.id;

        let listData = readJson(LIST_FILE);
        const foundIndex = listData.findIndex(item => item.id === groupID && item.key.toLowerCase() === key.toLowerCase());

        if (foundIndex === -1) return reply(`<blockquote>⚠️ Key produk "<b>${key}</b>" tidak ditemukan. Gunakan <code>/addlist</code> untuk menambahkannya.</blockquote>`, { parse_mode: 'HTML' });

        listData[foundIndex].response = responseText;
        listData[foundIndex].isImage = false;
        listData[foundIndex].image_url = '';

        const replyMessage = xy.message.reply_to_message;
        if (replyMessage && (replyMessage.photo || replyMessage.video)) {
            const mediaType = replyMessage.photo ? 'Photo' : 'Video';
            listData[foundIndex].isImage = true;
            listData[foundIndex].image_url = 'https://telegra.ph/file/134ccbbd0dfc434a910ab.png'; // Placeholder

            // Implementasi upload media sebenarnya di sini jika memungkinkan
            
            writeJson(LIST_FILE, listData);
            reply(`<blockquote>✅ Produk/Respon <b>${key}</b> berhasil diperbarui dengan ${mediaType} baru!</blockquote>`, { parse_mode: 'HTML' });
        } else {
            writeJson(LIST_FILE, listData);
            reply(`<blockquote>✅ Produk/Respon <b>${key}</b> berhasil diperbarui (Teks saja).</blockquote>`, { parse_mode: 'HTML' });
        }
        break;
    }

    case 'dellistall': {
        if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
        
        const groupID = xy.chat.id;
        let listData = readJson(LIST_FILE);
        
        const initialLength = listData.length;
        listData = listData.filter(item => item.id !== groupID);

        if (listData.length < initialLength) {
            writeJson(LIST_FILE, listData);
            reply(`<blockquote>✅ Semua Produk/Respon (${initialLength - listData.length} item) berhasil dihapus dari grup ini.</blockquote>`, { parse_mode: 'HTML' });
        } else {
            reply(`<blockquote>⚠️ Tidak ada Produk/Respon yang terdaftar di grup ini.</blockquote>`, { parse_mode: 'HTML' });
        }
        break;
    }

    case 'listproduk': {
        if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
        
        const groupID = xy.chat.id;
        const listData = readJson(LIST_FILE);
        const groupList = listData.filter(item => item.id === groupID);

        if (groupList.length === 0) return reply(`<blockquote>⚠️ Tidak ada Produk/Respon yang terdaftar di grup ini.</blockquote>`, { parse_mode: 'HTML' });

        let responseText = `📜 <b>DAFTAR PRODUK/RESPON GRUP</b> (${groupList.length} item)\n\n`;
        groupList.forEach((item, index) => {
            const media = item.isImage ? '🖼️ (Media)' : '';
            responseText += `${index + 1}. <b>${item.key}</b> ${media}\n`;
        });
        
        responseText += `\n📌 Untuk melihat detail, ketik <b>Key</b> produk (misalnya: ${groupList[0].key})`;

        reply(`<blockquote>${responseText}</blockquote>`, { parse_mode: 'HTML' });
        break;
    }

    case 'searchproduk': {
        if (xy.chat.type !== 'group' && xy.chat.type !== 'supergroup') return reply(mess.group);
        if (!text) return reply(`<blockquote>❌ Format salah!\n\nPenggunaan: <code>/searchproduk [Kata Kunci]</code></blockquote>`, { parse_mode: 'HTML' });

        const keyword = text.trim().toLowerCase();
        const groupID = xy.chat.id;
        const listData = readJson(LIST_FILE);
        
        const results = listData.filter(item => 
            item.id === groupID && 
            (item.key.toLowerCase().includes(keyword) || item.response.toLowerCase().includes(keyword))
        );

        if (results.length === 0) return reply(`<blockquote>⚠️ Tidak ditemukan Produk/Respon yang cocok dengan kata kunci "<b>${text}</b>".</blockquote>`, { parse_mode: 'HTML' });

        let responseText = `🔍 <b>HASIL PENCARIAN PRODUK</b> (${results.length} item)\n\n`;
        results.forEach((item, index) => {
            const media = item.isImage ? '🖼️ (Media)' : '';
            responseText += `${index + 1}. <b>${item.key}</b> ${media}\n`;
        });

        responseText += `\n📌 Untuk melihat detail, ketik <b>Key</b> produk.`;
        
        reply(`<blockquote>${responseText}</blockquote>`, { parse_mode: 'HTML' });
        break;
    }
    

    case 'stop': {
        if (!isOwner) return reply(mess.owner);

        const confirmationMessage = '<blockquote>✅ <b>Bot dihentikan!</b>\n\nSistem Node.js telah dimatikan. \n\n⚠️ **PENTING:** Jika bot otomatis menyala lagi, ini berarti Anda menggunakan **PM2** atau **forever**.\nUntuk mematikan total, jalankan perintah ini di terminal server Anda: \n`pm2 stop <nama_aplikasi>` atau `kill <ID_PROSES_BOT>`</blockquote>';
        
        reply(confirmationMessage, { parse_mode: 'HTML' })
          .catch(e => {
            console.error("Gagal mengirim notifikasi stop, tetap melanjutkan penghentian:", e.message);
          })
          .finally(() => {
            setTimeout(() => {
                 console.log("STOP: Bot dihentikan secara paksa melalui SIGTERM.");

                 process.kill(process.pid, 'SIGTERM'); 
            }, 500); 
          });
        
        return; 
    }


    case "restart": {
      if (!isOwner) return reply(mess.owner);

      const sentMessage = await reply("<blockquote>🔄 <b>Memulai Restart Bot...</b>\n\n<i>Bot akan offline sebentar dan kembali otomatis.</i></blockquote>", {
        parse_mode: 'HTML'
      });

      setTimeout(() => {
        try {        
          const child = spawn(process.argv[0], [path.join(__dirname, '../index.js'), '--restarted'], {
            detached: true,
            stdio: 'inherit',
          });
          child.unref();
          

          process.kill(process.pid, 'SIGTERM'); 
        } catch (e) {
          console.error("Gagal melakukan restart:", e);
          reply("<blockquote>❌ Gagal melakukan restart. Cek log server.</blockquote>", {
            parse_mode: 'HTML'
          });
        }
      }, 3000); 

      break;
    }
    

    default:
  }
}

module.exports = {
  handleMessage,
  checkAndStopAbnormalCpu 
};
