const { User, Group, Broadcast } = require('../lib/database');
const { generateMainMenu, mainMenuMessage } = require('./utils');

// Handler untuk callback query (button)
async function handleCallbackQuery(ctx) {
    const data = ctx.callbackQuery.data;
    const userId = ctx.callbackQuery.from.id;
    const isCreator = userId.toString() === process.env.OWNER_ID;
    
    try {
        switch (data) {
            case 'jasher_menu':
                await ctx.editMessageText(
                    '<b>Jasher Menu</b>\n\n' +
                    '• Share - Bagikan pesan (2 kredit)\n' +
                    '• ShareVIP - Bagikan pesan cepat (5 kredit, premium only)\n' +
                    '• Credit - Cek kredit Anda\n' +
                    '• Help - Bantuan penggunaan bot',
                    {
                        parse_mode: 'HTML',
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: "Share", callback_data: "share_option" }],
                                [{ text: "ShareVIP", callback_data: "share_vip" }],
                                [{ text: "Credit", callback_data: "credit_info" }],
                                [{ text: "Help", callback_data: "help_info" }],
                                [{ text: "Kembali", callback_data: "main_menu" }]
                            ]
                        }
                    }
                );
                break;
                
            case 'owner_menu':
                if (!isCreator) {
                    await ctx.answerCbQuery('Anda bukan owner!');
                    return;
                }
                
                await ctx.editMessageText(
                    '<b>Owner Menu</b>\n\n' +
                    '• Broadcast - Kirim pesan ke semua user\n' +
                    '• Add Premium - Tambahkan user premium\n' +
                    '• Delete Premium - Hapus user premium\n' +
                    '• List Premium - Lihat daftar user premium',
                    {
                        parse_mode: 'HTML',
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: "Broadcast", callback_data: "broadcast_option" }],
                                [{ text: "Add Premium", callback_data: "add_premium" }],
                                [{ text: "Delete Premium", callback_data: "delete_premium" }],
                                [{ text: "List Premium", callback_data: "list_premium" }],
                                [{ text: "Kembali", callback_data: "main_menu" }]
                            ]
                        }
                    }
                );
                break;
                
            case 'main_menu':
                const user = await User.findOne({ userId });
                const message = mainMenuMessage(ctx, user);
                const menu = generateMainMenu(isCreator);
                
                await ctx.editMessageText(message, {
                    parse_mode: 'HTML',
                    ...menu
                });
                break;
                
            case 'credit_info':
                const userData = await User.findOne({ userId });
                await ctx.answerCbQuery(`Kredit Anda: ${userData.credit}`);
                break;
                
            case 'help_info':
                await ctx.answerCbQuery('Ketik /help untuk informasi bantuan');
                break;
                
            case 'share_option':
                await ctx.answerCbQuery('Ketik "share" di chat private untuk membagikan pesan');
                break;
                
            case 'share_vip':
                const userVip = await User.findOne({ userId });
                if (!userVip.isPremium) {
                    await ctx.answerCbQuery('Fitur ini hanya untuk user premium!');
                    return;
                }
                await ctx.answerCbQuery('Ketik "sharevip" di chat private untuk membagikan pesan cepat');
                break;
                
            default:
                await ctx.answerCbQuery('Fitur belum tersedia');
        }
    } catch (error) {
        console.error('Error handling callback query:', error);
        await ctx.answerCbQuery('Terjadi kesalahan');
    }
}

// Handler untuk pesan teks "share"
async function handleShare(ctx) {
    // Hanya bisa di private chat
    if (ctx.chat.type !== 'private') {
        await ctx.reply('Perintah share hanya bisa digunakan di private chat!');
        return;
    }
    
    try {
        const user = await User.findOne({ userId: ctx.from.id });
        if (!user) {
            await ctx.reply('Anda belum terdaftar. Ketik /start untuk memulai.');
            return;
        }
        
        // Cek kredit
        if (user.credit < 2) {
            await ctx.reply('Kredit Anda tidak cukup. Tambahkan bot ke 3 group untuk mendapatkan 10 kredit.');
            return;
        }
        
        // Cek apakah ada pesan yang di-reply
        if (!ctx.message.reply_to_message) {
            await ctx.reply('Anda harus mereply pesan yang ingin dibagikan!');
            return;
        }
        
        // Kurangi kredit
        user.credit -= 2;
        await user.save();
        
        // Proses broadcast (disini hanya simulasi)
        await ctx.reply('Pesan sedang dibagikan ke group...');
        
        // Simpan broadcast ke database
        const broadcast = new Broadcast({
            messageId: ctx.message.reply_to_message.message_id.toString(),
            senderId: ctx.from.id,
            messageText: ctx.message.reply_to_message.text || '[Media Content]',
            receivers: [] // Diisi dengan ID group yang menerima
        });
        await broadcast.save();
        
        await ctx.reply(`Pesan berhasil dibagikan! Kredit tersisa: ${user.credit}`);
    } catch (error) {
        console.error('Error handling share:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

// Handler untuk pesan teks "sharevip" (premium only)
async function handleShareVip(ctx) {
    // Hanya bisa di private chat
    if (ctx.chat.type !== 'private') {
        await ctx.reply('Perintah sharevip hanya bisa digunakan di private chat!');
        return;
    }
    
    try {
        const user = await User.findOne({ userId: ctx.from.id });
        if (!user) {
            await ctx.reply('Anda belum terdaftar. Ketik /start untuk memulai.');
            return;
        }
        
        if (!user.isPremium) {
            await ctx.reply('Fitur ini hanya untuk user premium!');
            return;
        }
        
        // Cek kredit
        if (user.credit < 5) {
            await ctx.reply('Kredit VIP Anda tidak cukup. Hubungi owner untuk top up.');
            return;
        }
        
        // Cek apakah ada pesan yang di-reply
        if (!ctx.message.reply_to_message) {
            await ctx.reply('Anda harus mereply pesan yang ingin dibagikan!');
            return;
        }
        
        // Kurangi kredit
        user.credit -= 5;
        await user.save();
        
        // Proses broadcast (disini hanya simulasi)
        await ctx.reply('Pesan sedang dibagikan cepat ke group...');
        
        // Simpan broadcast ke database
        const broadcast = new Broadcast({
            messageId: ctx.message.reply_to_message.message_id.toString(),
            senderId: ctx.from.id,
            messageText: ctx.message.reply_to_message.text || '[Media Content]',
            receivers: [] // Diisi dengan ID group yang menerima
        });
        await broadcast.save();
        
        await ctx.reply(`Pesan VIP berhasil dibagikan! Kredit tersisa: ${user.credit}`);
    } catch (error) {
        console.error('Error handling sharevip:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

// Handler untuk bot yang ditambahkan ke group
async function handleNewChatMembers(ctx) {
    if (ctx.message.new_chat_members.some(member => member.is_bot && member.id === ctx.botInfo.id)) {
        // Bot ditambahkan ke group
        const groupId = ctx.chat.id.toString();
        const groupName = ctx.chat.title;
        
        try {
            // Cek apakah group sudah ada di database
            const existingGroup = await Group.findOne({ groupId });
            
            if (!existingGroup) {
                // Simpan group baru
                const newGroup = new Group({
                    groupId,
                    groupName,
                    groupUsername: ctx.chat.username || '',
                    memberCount: await ctx.getChatMembersCount(),
                    addedBy: ctx.from.id
                });
                await newGroup.save();
                
                // Beri kredit kepada user yang menambahkan bot
                const user = await User.findOne({ userId: ctx.from.id });
                if (user) {
                    user.joinedGroups.push(groupId);
                    
                    // Beri 10 kredit jika sudah menambahkan ke 3 group
                    if (user.joinedGroups.length >= 3) {
                        user.credit += 10;
                        await user.save();
                        await ctx.reply(`Terima kasih! Anda telah menambahkan bot ke 3 group. Anda mendapatkan 10 kredit! Total kredit: ${user.credit}`);
                    } else {
                        await user.save();
                        await ctx.reply(`Terima kasih! Anda telah menambahkan bot ke group. Sekarang Anda telah menambahkan ke ${user.joinedGroups.length} group. Butuh ${3 - user.joinedGroups.length} group lagi untuk mendapatkan 10 kredit.`);
                    }
                }
            }
        } catch (error) {
            console.error('Error handling new group:', error);
        }
    }
}

module.exports = {
    handleCallbackQuery,
    handleShare,
    handleShareVip,
    handleNewChatMembers
};