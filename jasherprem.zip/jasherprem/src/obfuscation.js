const JsConfuser = require("js-confuser");
const fs = require("fs-extra");
const path = require("path");
const fetch = require("node-fetch");
const { updateProgress, log } = require("../lib/utils");

// Konfigurasi obfuscation
function getMandarinObfuscationConfig() {
  return {
    target: "browser",
    preset: "high",
    stringEncoding: true,
    stringCompression: true,
    stringSplitting: true,
    controlFlowFlattening: true,
    deadCode: true,
    dispatcher: true,
    duplicateLiteralsRemoval: true,
    identifierGenerator: "hexadecimal",
    mba: true,
    memberExpressionGenerator: "hexadecimal",
    mode: "hardened",
    opaquePredicates: true,
    stack: true,
    globalConcealing: true,
    minify: true
  };
}

function getArabObfuscationConfig() {
  return {
    target: "browser",
    preset: "high",
    stringEncoding: true,
    stringCompression: true,
    stringSplitting: true,
    controlFlowFlattening: true,
    deadCode: true,
    dispatcher: true,
    duplicateLiteralsRemoval: true,
    identifierGenerator: "arabic",
    mba: true,
    memberExpressionGenerator: "arabic",
    mode: "hardened",
    opaquePredicates: true,
    stack: true,
    globalConcealing: true,
    minify: true
  };
}

function getJapanObfuscationConfig() {
  return {
    target: "browser",
    preset: "high",
    stringEncoding: true,
    stringCompression: true,
    stringSplitting: true,
    controlFlowFlattening: true,
    deadCode: true,
    dispatcher: true,
    duplicateLiteralsRemoval: true,
    identifierGenerator: "japanese",
    mba: true,
    memberExpressionGenerator: "japanese",
    mode: "hardened",
    opaquePredicates: true,
    stack: true,
    globalConcealing: true,
    minify: true
  };
}

function getStrongObfuscationConfig() {
  return {
    target: "browser",
    preset: "high",
    stringEncoding: true,
    stringCompression: true,
    stringSplitting: true,
    controlFlowFlattening: true,
    deadCode: true,
    dispatcher: true,
    duplicateLiteralsRemoval: true,
    identifierGenerator: "invisible",
    mba: true,
    memberExpressionGenerator: "invisible",
    mode: "hardened",
    opaquePredicates: true,
    stack: true,
    globalConcealing: true,
    minify: true
  };
}

function getCustomObfuscationConfig(customName) {
  return {
    target: "browser",
    preset: "high",
    stringEncoding: true,
    stringCompression: true,
    stringSplitting: true,
    controlFlowFlattening: true,
    deadCode: true,
    dispatcher: true,
    duplicateLiteralsRemoval: true,
    identifierGenerator: "custom",
    customIdentifierGenerator: customName,
    mba: true,
    memberExpressionGenerator: "custom",
    customMemberExpressionGenerator: customName,
    mode: "hardened",
    opaquePredicates: true,
    stack: true,
    globalConcealing: true,
    minify: true
  };
}

function getNovaObfuscationConfig() {
  return {
    target: "browser",
    preset: "high",
    stringEncoding: true,
    stringCompression: true,
    stringSplitting: true,
    controlFlowFlattening: true,
    deadCode: true,
    dispatcher: true,
    duplicateLiteralsRemoval: true,
    identifierGenerator: "numeric",
    mba: true,
    memberExpressionGenerator: "numeric",
    mode: "hardened",
    opaquePredicates: true,
    stack: true,
    globalConcealing: true,
    minify: true
  };
}

function getNebulaObfuscationConfig() {
  return {
    target: "browser",
    preset: "high",
    stringEncoding: true,
    stringCompression: true,
    stringSplitting: true,
    controlFlowFlattening: true,
    deadCode: true,
    dispatcher: true,
    duplicateLiteralsRemoval: true,
    identifierGenerator: "randomized",
    mba: true,
    memberExpressionGenerator: "randomized",
    mode: "hardened",
    opaquePredicates: true,
    stack: true,
    globalConcealing: true,
    minify: true,
    lock: {
      domain: ["telegram.org"],
      time: {
        start: new Date(),
        end: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000) // 1 year
      }
    }
  };
}

function getSiuCalcrickObfuscationConfig() {
  return {
    target: "browser",
    preset: "high",
    stringEncoding: true,
    stringCompression: true,
    stringSplitting: true,
    controlFlowFlattening: true,
    deadCode: true,
    dispatcher: true,
    duplicateLiteralsRemoval: true,
    identifierGenerator: "mixed",
    mba: true,
    memberExpressionGenerator: "mixed",
    mode: "hardened",
    opaquePredicates: true,
    stack: true,
    globalConcealing: true,
    minify: true,
    calculator: true,
    rickroll: true
  };
}

// Fungsi untuk obfuscate dengan time lock
async function obfuscateTimeLocked(code, days) {
  const expiryDate = new Date();
  expiryDate.setDate(expiryDate.getDate() + parseInt(days));
  
  const lockedCode = `
// Time-Locked Encryption - Expires: ${expiryDate.toISOString()}
(function() {
  var currentDate = new Date();
  var expiryDate = new Date("${expiryDate.toISOString()}");
  
  if (currentDate > expiryDate) {
    console.error("Script has expired. Please contact the provider.");
    return;
  }
  
  ${code}
})();
`;
  
  const obfuscated = await JsConfuser.obfuscate(lockedCode, {
    target: "browser",
    preset: "high",
    stringEncoding: true,
    stringCompression: true,
    controlFlowFlattening: true,
    deadCode: true,
    dispatcher: true,
    duplicateLiteralsRemoval: true,
    identifierGenerator: "hexadecimal",
    mba: true,
    mode: "hardened",
    opaquePredicates: true,
    stack: true,
    globalConcealing: true,
    minify: true
  });
  
  return obfuscated;
}

// Fungsi untuk obfuscate quantum
async function obfuscateQuantum(code) {
  const quantumCode = `
// Quantum Vortex Encryption
(function() {
  var _0xquantum = {
    'decode': function(str) {
      return atob(str);
    },
    'execute': function(code) {
      return eval(code);
    }
  };
  
  var _0xentangled = [
    "${btoa(code)}"
  ];
  
  try {
    var _0xdecoded = _0xquantum.decode(_0xentangled[0]);
    _0xquantum.execute(_0xdecoded);
  } catch(_0xerror) {
    console.error("Quantum decoherence detected:", _0xerror);
  }
})();
`;
  
  const obfuscated = await JsConfuser.obfuscate(quantumCode, {
    target: "browser",
    preset: "high",
    stringEncoding: true,
    stringCompression: true,
    stringSplitting: true,
    controlFlowFlattening: true,
    deadCode: true,
    dispatcher: true,
    duplicateLiteralsRemoval: true,
    identifierGenerator: "hexadecimal",
    mba: true,
    memberExpressionGenerator: "hexadecimal",
    mode: "hardened",
    opaquePredicates: true,
    stack: true,
    globalConcealing: true,
    minify: true
  });
  
  return obfuscated;
}

// Command obfuscation
function setupObfuscationCommands(bot) {
  // enc3 - Mandarin Obfuscation
  bot.command("enc3", async (ctx) => {
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown(`
╭━━━「 ❌ ERROR 」━━━⬣
│ Terjadi kesalahan saat
│ memproses file!
╰━━━━━━━━━━━━━━━━⬣`);
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown(`
╭━━━「 ❌ ERROR 」━━━⬣
│ File harus berekstensi .js!
╰━━━━━━━━━━━━━━━━⬣`);
    }

    const encryptedPath = path.join(__dirname, "..", `china-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          ` ⚙️ Memulai (Hardened Mandarin) (1%)\n` +
          ` ${createProgressBar(1)}\n` +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Mandarin obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Mandarin yang diperkuat`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Hardened Mandarin Obfuscation"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getMandarinObfuscationConfig()
      );
      await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
      await fs.writeFile(encryptedPath, obfuscated);
      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscated);
      } catch (postObfuscationError) {
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      log(`Mengirim file terenkripsi gaya Mandarin: ${file.file_name}`);
      await ctx.replyWithDocument(
        { source: encryptedPath, filename: `china-encrypted-${file.file_name}` },
        {
          caption:
            "✅ *File terenkripsi (Hardened Mandarin) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Hardened Mandarin Obfuscation Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Mandarin obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // enc4 - Arab Obfuscation
  bot.command("enc4", async (ctx) => {
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc4`!");
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, "..", `arab-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          ` ⚙️ Memulai (Hardened Arab) (1%)\n` +
          ` ${createProgressBar(1)}\n` +
          "```\n" +
          "PROSES ENCRYPT"
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Arab obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Arab yang diperkuat`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Hardened Arab Obfuscation"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getArabObfuscationConfig()
      );
      await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
      await fs.writeFile(encryptedPath, obfuscated);
      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscated);
      } catch (postObfuscationError) {
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      log(`Mengirim file terenkripsi gaya Arab: ${file.file_name}`);
      await ctx.replyWithDocument(
        { source: encryptedPath, filename: `arab-encrypted-${file.file_name}` },
        {
          caption:
            "✅ *File terenkripsi (Hardened Arab) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Hardened Arab Obfuscation Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Arab obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // japan - Japan Obfuscation
  bot.command("japan", async (ctx) => {
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/japan`!");
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, "..", `japan-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          ` ⚙️ Memulai (Hardened Japan) (1%)\n` +
          ` ${createProgressBar(1)}\n` +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Japan obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Japan yang diperkuat`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Hardened Japan Obfuscation"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getJapanObfuscationConfig()
      );
      await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
      await fs.writeFile(encryptedPath, obfuscated);
      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscated);
      } catch (postObfuscationError) {
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      log(`Mengirim file terenkripsi gaya Japan: ${file.file_name}`);
      await ctx.replyWithDocument(
        { source: encryptedPath, filename: `japan-encrypted-${file.file_name}` },
        {
          caption:
            "✅ *File terenkripsi (Hardened Japan) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Hardened Japan Obfuscation Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Japan obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // zenc - Invisible Obfuscation
  bot.command("zenc", async (ctx) => {
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/zenc`!");
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, "..", `invisible-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          ` ⚙️ Memulai (InvisiBle) (1%)\n` +
          ` ${createProgressBar(1)}\n` +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Strong obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Strong`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Hardened Invisible Obfuscation"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getStrongObfuscationConfig()
      );
      await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
      await fs.writeFile(encryptedPath, obfuscated);
      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscated);
      } catch (postObfuscationError) {
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      log(`Mengirim file terenkripsi gaya Invisible: ${file.file_name}`);
      await ctx.replyWithDocument(
        {
          source: encryptedPath,
          filename: `Invisible-encrypted-${file.file_name}`,
        },
        {
          caption: "✅ *File terenkripsi (Invisible) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Hardened Invisible Obfuscation Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Invisible obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // xx - Custom Obfuscation
  bot.command("xx", async (ctx) => {
    // Ambil nama kustom dari perintah
    const args = ctx.message.text.split(" ");
    if (args.length < 2 || !args[1]) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Gunakan format `/enc <nama>` dengan nama kustom!"
      );
    }
    const customName = args[1].replace(/[^a-zA-Z0-9_]/g, ""); // Sanitasi input, hanya huruf, angka, dan underscore
    if (!customName) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Nama kustom harus berisi huruf, angka, atau underscore!"
      );
    }

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Balas file .js dengan `/enc <nama>`!"
      );
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, "..", `custom-${customName}-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          ` ⚙️ Memulai (Hardened Custom: ${customName}) (1%)\n` +
          ` ${createProgressBar(1)}\n` +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Custom obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Custom (${customName}) yang diperkuat`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Hardened Custom Obfuscation"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getCustomObfuscationConfig(customName)
      );
      await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
      await fs.writeFile(encryptedPath, obfuscated);
      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

      log(`Memvalidasi kode hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscated);
      } catch (postObfuscationError) {
        log(
          `Kode hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      log(`Mengirim file terenkripsi gaya Custom: ${file.file_name}`);
      await ctx.replyWithDocument(
        {
          source: encryptedPath,
          filename: `custom-${customName}-encrypted-${file.file_name}`,
        },
        {
          caption: `✅ *File terenkripsi (Hardened Custom: ${customName}) siap!*\nSUKSES ENCRYPT 🕊`,
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        `Hardened Custom (${customName}) Obfuscation Selesai`
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Custom obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // quantum - Quantum Obfuscation
  bot.command("quantum", async (ctx) => {
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Balas file .js dengan `/quantum`!"
      );
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, "..", `quantum-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          " ⚙️ Memulai (Quantum Vortex Encryption) (1%)\n" +
          " " +
          createProgressBar(1) +
          "\n" +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Quantum Vortex Encryption: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan Quantum Vortex Encryption`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Quantum Vortex Encryption"
      );
      const obfuscatedCode = await obfuscateQuantum(fileContent);
      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscatedCode);

      log(`Mengirim file terenkripsi quantum: ${file.file_name}`);
      await ctx.replyWithDocument(
        {
          source: encryptedPath,
          filename: `quantum-encrypted-${file.file_name}`,
        },
        {
          caption:
            "✅ *File terenkripsi (Quantum Vortex Encryption) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Quantum Vortex Encryption Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Quantum obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // var - Nova Obfuscation
  bot.command("var", async (ctx) => {
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/var`!");
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, "..", `var-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          " ⚙️ Memulai (Var) (1%)\n" +
          " " +
          createProgressBar(1) +
          "\n" +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Var obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Var`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Var Dynamic Obfuscation"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getNovaObfuscationConfig()
      );
      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscated);

      log(`Mengirim file terenkripsi gaya Var: ${file.file_name}`);
      await ctx.replyWithDocument(
        { source: encryptedPath, filename: `Var-encrypted-${file.file_name}` },
        {
          caption: "✅ *File terenkripsi (Var) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(ctx, progressMessage, 100, "Var Obfuscation Selesai");

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Nova obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // nebula - Nebula Obfuscation
  bot.command("nebula", async (ctx) => {
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Balas file .js dengan `/nebula`!"
      );
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, "..", `nebula-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          " ⚙️ Memulai (Nebula Polymorphic Storm) (1%)\n" +
          " " +
          createProgressBar(1) +
          "\n" +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Nebula obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Nebula`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Nebula Polymorphic Storm"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getNebulaObfuscationConfig()
      );
      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscated);

      log(`Mengirim file terenkripsi gaya Nebula: ${file.file_name}`);
      await ctx.replyWithDocument(
        { source: encryptedPath, filename: `nebula-encrypted-${file.file_name}` },
        {
          caption:
            "✅ *File terenkripsi (Nebula Polymorphic Storm) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Nebula Polymorphic Storm Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Nebula obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // enc5 - Siu+Calcrick Obfuscation
  bot.command("enc5", async (ctx) => {
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Balas file .js dengan `/enc5`!"
      );
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, "..", `siucalcrick-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          " ⚙️ Memulai (Calcrick Chaos Core) (1%)\n" +
          " " +
          createProgressBar(1) +
          "\n" +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Siu+Calcrick obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Siu+Calcrick`);
      await updateProgress(
        ctx,
        progressMessage,
        ctx,
        progressMessage,
        40,
        "Inisialisasi Calcrick Chaos Core"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getSiuCalcrickObfuscationConfig()
      );
      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscated);

      log(`Mengirim file terenkripsi gaya Siu+Calcrick: ${file.file_name}`);
      await ctx.replyWithDocument(
        {
          source: encryptedPath,
          filename: `siucalcrick-encrypted-${file.file_name}`,
        },
        {
          caption:
            "✅ *File terenkripsi (Calcrick Chaos Core) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Calcrick Chaos Core Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Siu+Calcrick obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // enc2 - Custom Text Obfuscation
  bot.command("enc2", async (ctx) => {
    const customString = ctx.message.text.split(" ")[1];

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Balas file .js dengan `/enc2 <text>`!"
      );
    }

    if (!customString) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Balas file .js dengan `/enc2 <text>`!"
      );
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, "..", `custom-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          " ⚙️ Memulai (custom enc) (1%)\n" +
          " " +
          createProgressBar(1) +
          "\n" +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk custom obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya custom (${customString})`);
      await updateProgress(ctx, progressMessage, 40, `Inisialisasi custom (${customString})`);

      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getCustomObfuscationConfig(customString)
      );
      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscated);

      log(`Mengirim file terenkripsi gaya custom (${customString}): ${file.file_name}`);
      await ctx.replyWithDocument(
        {
          source: encryptedPath,
          filename: `custom-encrypted-${file.file_name}`,
        },
        {
          caption: `✅ *File terenkripsi custom (${customString}) siap!*\nSUKSES ENCRYPT 🕊`,
          parse_mode: "Markdown",
        }
      );
      await updateProgress(ctx, progressMessage, 100, `custom (${customString}) Selesai`);

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat custom enc obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // enc - Time-Locked Obfuscation
  bot.command("enc", async (ctx) => {
    const args = ctx.message.text.split(" ").slice(1);
    if (
      args.length !== 1 ||
      !/^\d+$/.test(args[0]) ||
      parseInt(args[0]) < 1 ||
      parseInt(args[0]) > 365
    ) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Gunakan format `/locked [1-365]` untuk jumlah hari (misal: `/enc 7`)!"
      );
    }

    const days = args[0];
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + parseInt(days));
    const expiryFormatted = expiryDate.toLocaleDateString();

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Balas file .js dengan `/enc [1-365]`!"
      );
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, "..", `locked-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          " ⚙️ Memulai (Time-Locked Encryption) (1%)\n" +
          " " +
          createProgressBar(1) +
          "\n" +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Time-Locked Encryption: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan Time-Locked Encryption`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Time-Locked Encryption"
      );
      const obfuscatedCode = await obfuscateTimeLocked(fileContent, days);
      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscatedCode);

      log(`Mengirim file terenkripsi time-locked: ${file.file_name}`);
      await ctx.replyWithMarkdown(
        `✅ *File terenkripsi (Time-Locked Encryption) siap!*\n` +
          `⏰ Masa aktif: ${days} hari (Kedaluwarsa: ${expiryFormatted})\n` +
          `_Powered by Ginaa_`,
        { parse_mode: "Markdown" }
      );
      await ctx.replyWithDocument({
        source: encryptedPath,
        filename: `locked-encrypted-${file.file_name}`,
      });
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Time-Locked Encryption Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Time-Locked obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });
}

module.exports = {
  setupObfuscationCommands
};