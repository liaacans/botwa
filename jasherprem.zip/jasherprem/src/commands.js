const { Markup } = require('telegraf');
const db = require('../lib/database');
const { formatUserInfo } = require('../lib/utils');

async function handleStart(ctx) {
  const userId = ctx.from.id;
  let user = await db.getUser(userId);
  
  if (!user) {
    user = {
      id: userId,
      username: ctx.from.username,
      first_name: ctx.from.first_name,
      last_name: ctx.from.last_name,
      credit: 0,
      groups: [],
      createdAt: new Date()
    };
    await db.createUser(user);
  }
  
  const isPremium = await db.isPremium(userId);
  const menuText = formatUserInfo(ctx, user, db);
  
  const buttons = [
    [Markup.button.callback('🎯 Jasher Menu', 'jasher_menu')],
    [Markup.button.callback('👤 Owner Menu', 'owner_menu')],
    [Markup.button.url('➕ Add Group', 'https://t.me/your_bot_username?startgroup=true')]
  ];
  
  if (isPremium || userId.toString() === global.OWNER_ID) {
    buttons.push([Markup.button.callback('⭐ VIP Share', 'vip_share')]);
  }
  
  if (userId.toString() === global.OWNER_ID) {
    buttons.push([Markup.button.callback('🔊 Broadcast', 'owner_broadcast')]);
  }
  
  try {
    await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
      caption: menuText,
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard(buttons)
    });
  } catch (error) {
    await ctx.reply(menuText, {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard(buttons)
    });
  }
}

async function handleHelp(ctx) {
  const helpText = `🤖 <b>Jasher Bot Help</b>

<b>Fitur Umum:</b>
/start - Memulai bot
/help - Menampilkan bantuan
/credit - Menampilkan kredit Anda
/share - Berbagi pesan ke grup (2 kredit)

<b>Fitur Premium:</b>
/sharevip - Berbagi pesan ke grup (prioritas tinggi)

<b>Fitur Owner:</b>
/addprem [user_id] - Menambah user premium
/delprem [user_id] - Menghapus user premium
/listprem - Menampilkan daftar premium
/broadcast - Broadcast ke semua user

<b>Cara Mendapatkan Kredit:</b>
1. Tambahkan bot ke 3 grup untuk mendapatkan 10 kredit
2. Setiap grup yang ditambahkan memberikan 10 kredit`;

  await ctx.reply(helpText, { parse_mode: 'HTML' });
}

async function handleCredit(ctx) {
  const userId = ctx.from.id;
  const user = await db.getUser(userId);
  
  if (!user) {
    return ctx.reply('Anda belum terdaftar. Ketik /start untuk memulai.');
  }
  
  await ctx.reply(`💰 Kredit Anda: ${user.credit}`);
}

async function handleShare(ctx) {
  if (ctx.chat.type !== 'private') {
    return ctx.reply('❌ Perintah ini hanya bisa digunakan di chat private!');
  }
  
  const userId = ctx.from.id;
  const user = await db.getUser(userId);
  
  if (!user) {
    return ctx.reply('Anda belum terdaftar. Ketik /start untuk memulai.');
  }
  
  if (user.credit < 2) {
    return ctx.reply('❌ Kredit tidak cukup. Minimal 2 kredit untuk share. Tambahkan bot ke grup untuk mendapatkan kredit.');
  }
  
  if (!ctx.message.reply_to_message) {
    return ctx.reply('❌ Balas pesan yang ingin di-share dengan perintah /share');
  }
  
  // Simpan pesan yang akan di-share
  ctx.session.shareMessage = ctx.message.reply_to_message;
  ctx.session.shareType = 'regular';
  
  await ctx.reply(
    'Pilih grup tujuan untuk share:',
    Markup.inlineKeyboard([
      [Markup.button.callback('📢 Broadcast ke Semua Grup', 'confirm_share')],
      [Markup.button.callback('❌ Batal', 'cancel_share')]
    ])
  );
}

async function handleShareVip(ctx) {
  if (ctx.chat.type !== 'private') {
    return ctx.reply('❌ Perintah ini hanya bisa digunakan di chat private!');
  }
  
  const userId = ctx.from.id;
  const user = await db.getUser(userId);
  const isPremium = await db.isPremium(userId);
  
  if (!user) {
    return ctx.reply('Anda belum terdaftar. Ketik /start untuk memulai.');
  }
  
  if (!isPremium && userId.toString() !== global.OWNER_ID) {
    return ctx.reply('❌ Fitur ini hanya untuk user premium!');
  }
  
  if (!ctx.message.reply_to_message) {
    return ctx.reply('❌ Balas pesan yang ingin di-share dengan perintah /sharevip');
  }
  
  // Simpan pesan yang akan di-share
  ctx.session.shareMessage = ctx.message.reply_to_message;
  ctx.session.shareType = 'vip';
  
  await ctx.reply(
    'Pilih grup tujuan untuk share VIP:',
    Markup.inlineKeyboard([
      [Markup.button.callback('🚀 Broadcast VIP ke Semua Grup', 'confirm_vip_share')],
      [Markup.button.callback('❌ Batal', 'cancel_share')]
    ])
  );
}

async function handleAddPrem(ctx) {
  if (ctx.from.id.toString() !== global.OWNER_ID) {
    return ctx.reply('❌ Hanya owner yang dapat menggunakan perintah ini!');
  }
  
  const args = ctx.message.text.split(' ');
  if (args.length < 2) {
    return ctx.reply('❌ Format: /addprem <user_id>');
  }
  
  const userId = args[1];
  await db.addPremiumUser(userId);
  
  ctx.reply(`✅ User ${userId} berhasil ditambahkan ke premium.`);
}

async function handleDelPrem(ctx) {
  if (ctx.from.id.toString() !== global.OWNER_ID) {
    return ctx.reply('❌ Hanya owner yang dapat menggunakan perintah ini!');
  }
  
  const args = ctx.message.text.split(' ');
  if (args.length < 2) {
    return ctx.reply('❌ Format: /delprem <user_id>');
  }
  
  const userId = args[1];
  await db.removePremiumUser(userId);
  
  ctx.reply(`✅ User ${userId} berhasil dihapus dari premium.`);
}

async function handleListPrem(ctx) {
  if (ctx.from.id.toString() !== global.OWNER_ID) {
    return ctx.reply('❌ Hanya owner yang dapat menggunakan perintah ini!');
  }
  
  const premiumUsers = await db.getPremiumUsers();
  if (premiumUsers.length === 0) {
    return ctx.reply('❌ Tidak ada user premium.');
  }
  
  let listText = '📋 Daftar User Premium:\n\n';
  premiumUsers.forEach((user, index) => {
    listText += `${index + 1}. User ID: ${user.userId}\n   Ditambahkan: ${user.addedAt.toLocaleDateString()}\n\n`;
  });
  
  ctx.reply(listText);
}

async function handleBroadcast(ctx) {
  if (ctx.from.id.toString() !== global.OWNER_ID) {
    return ctx.reply('❌ Hanya owner yang dapat menggunakan perintah ini!');
  }
  
  if (!ctx.message.reply_to_message) {
    return ctx.reply('❌ Balas pesan yang ingin di-broadcast dengan perintah /broadcast');
  }
  
  ctx.session.broadcastMessage = ctx.message.reply_to_message;
  
  await ctx.reply(
    'Yakin ingin mengirim broadcast ke semua user?',
    Markup.inlineKeyboard([
      [Markup.button.callback('✅ Ya, Kirim', 'confirm_broadcast')],
      [Markup.button.callback('❌ Batal', 'cancel_broadcast')]
    ])
  );
}

module.exports = {
  handleStart,
  handleHelp,
  handleCredit,
  handleShare,
  handleShareVip,
  handleAddPrem,
  handleDelPrem,
  handleListPrem,
  handleBroadcast
};