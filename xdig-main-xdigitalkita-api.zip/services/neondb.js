require("dotenv").config();

const { neon } = require("@neondatabase/serverless");

const databaseUrl = 'postgresql://neondb_owner:npg_KX2OW1jwRYpv@ep-weathered-smoke-b71s5tcg-pooler.c-13.us-east-1.aws.neon.tech/x?sslmode=require&channel_binding=require';

if (!databaseUrl) {
  throw new Error("DATABASE_URL belum diatur. Tambahkan URL koneksi Neon ke file .env atau environment server.");
}

const sql = neon(databaseUrl);
let schemaPromise;

function ensureSchema() {
  if (!schemaPromise) {
    schemaPromise = sql`
      CREATE TABLE IF NOT EXISTS xdk_app_store (
        store_key TEXT PRIMARY KEY,
        data JSONB NOT NULL,
        updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
      )
    `.catch(error => {
      schemaPromise = null;
      throw error;
    });
  }

  return schemaPromise;
}

function cleanTransaction(transaction) {
  if (!transaction || typeof transaction !== "object") return transaction;
  const removedKey = ["payment", "url"].join("");
  return Object.fromEntries(
    Object.entries(transaction).filter(([key]) => key.toLowerCase() !== removedKey)
  );
}

async function ensureFile(path, defaultContent) {
  await ensureSchema();
  await sql`
    INSERT INTO xdk_app_store (store_key, data)
    VALUES (${path}, ${JSON.stringify(defaultContent)}::jsonb)
    ON CONFLICT (store_key) DO NOTHING
  `;
}

async function read(path) {
  await ensureSchema();
  const rows = await sql`
    SELECT data
    FROM xdk_app_store
    WHERE store_key = ${path}
    LIMIT 1
  `;

  return rows[0] ? rows[0].data : null;
}

async function write(path, data) {
  await ensureSchema();
  const serialized = JSON.stringify(data);

  if (typeof serialized !== "string") {
    throw new TypeError("Data database harus berupa nilai JSON yang valid.");
  }

  await sql`
    INSERT INTO xdk_app_store (store_key, data, updated_at)
    VALUES (${path}, ${serialized}::jsonb, CURRENT_TIMESTAMP)
    ON CONFLICT (store_key)
    DO UPDATE SET
      data = EXCLUDED.data,
      updated_at = CURRENT_TIMESTAMP
  `;
}

async function listUsers() {
  const data = await read("users.json");
  return Array.isArray(data) ? data : [];
}

async function saveUsers(users) {
  await write("users.json", Array.isArray(users) ? users : []);
}

async function findUserById(id) {
  const users = await listUsers();
  return users.find(user => user.id === id);
}

async function findUserByEmail(email) {
  const users = await listUsers();
  return users.find(user => user.email === email);
}

async function findUserByApiKey(apiKey) {
  const users = await listUsers();
  return users.find(user => user.apiKey === apiKey);
}

async function saveUser(user) {
  const users = await listUsers();
  const index = users.findIndex(item => item.id === user.id);

  if (index >= 0) {
    users[index] = user;
  } else {
    users.push(user);
  }

  await saveUsers(users);
}

async function getTransactions(userId) {
  const data = await read(`transactions/${userId}.json`);
  return Array.isArray(data) ? data.map(cleanTransaction) : [];
}

async function saveTransactions(userId, list) {
  const cleaned = Array.isArray(list) ? list.map(cleanTransaction) : [];
  await write(`transactions/${userId}.json`, cleaned);
}

async function getWithdrawals(userId) {
  const data = await read(`withdrawals/${userId}.json`);
  return Array.isArray(data) ? data : [];
}

async function saveWithdrawals(userId, list) {
  await write(`withdrawals/${userId}.json`, Array.isArray(list) ? list : []);
}

async function getActivity(userId) {
  const data = await read(`activity/${userId}.json`);
  return Array.isArray(data) ? data : [];
}

async function saveActivity(userId, list) {
  await write(`activity/${userId}.json`, Array.isArray(list) ? list : []);
}

async function getAllWithdrawals() {
  const users = await listUsers();
  const results = await Promise.all(
    users.map(async user => {
      const withdrawals = await getWithdrawals(user.id);
      return withdrawals.map(withdrawal => ({
        ...withdrawal,
        userName: withdrawal.userName || user.name || "-",
        userEmail: withdrawal.userEmail || user.email || "-",
        userSaldo: Number(user.saldo || 0)
      }));
    })
  );

  return results.flat().sort(
    (first, second) => new Date(second.createdAt || 0) - new Date(first.createdAt || 0)
  );
}

async function findWithdrawalById(withdrawalId) {
  const users = await listUsers();

  for (const user of users) {
    const list = await getWithdrawals(user.id);
    const index = list.findIndex(item => item.id === withdrawalId);

    if (index >= 0) {
      return { user, list, withdrawal: list[index], index };
    }
  }

  return null;
}

async function getGlobalStats() {
  const users = await listUsers();
  const transactionLists = await Promise.all(
    users.map(user => getTransactions(user.id))
  );
  const totalTransactions = transactionLists.reduce(
    (total, list) => total + list.length,
    0
  );
  const withdrawals = await getAllWithdrawals();

  return {
    realUsers: users.length,
    realTransactions: totalTransactions,
    realWithdrawals: withdrawals.length
  };
}

module.exports = {
  ensureFile,
  read,
  write,
  listUsers,
  saveUsers,
  findUserById,
  findUserByEmail,
  findUserByApiKey,
  saveUser,
  getTransactions,
  saveTransactions,
  getWithdrawals,
  saveWithdrawals,
  getAllWithdrawals,
  findWithdrawalById,
  getActivity,
  saveActivity,
  getGlobalStats
};
