global.BOT_TOKEN = "8198305874:AAGhlBEYItkhH2mxD265kLIMXVEcWMiwkMM";
global.developer = "ginaabaikhati";
global.creatorId = 8135269613;
global.mongodbURL = "mongodb://mybot_todaytime:94a632154d44683eb18a23ee50f3a31a69e621f8@2kred.h.filess.io:61004/mybot_todaytime";

module.exports = {
    BOT_TOKEN: global.BOT_TOKEN,
    developer: global.developer,
    mongodbURL: global.mongodbURL
};