const db = require('../lib/database');
const utils = require('../lib/utils');
const keyboards = require('./keyboards');
const { CREDITS } = require('../config');

// Command handler untuk /start
async function startCommand(ctx) {
    const user = ctx.from;
    const sender = user.username || user.first_name;
    const userTelelu = user.username ? `@${user.username}` : user.first_name;
    const isCreator = user.id === global.CREATOR_ID;
    
    // Cek atau buat user di database
    let userData = await db.getUser(user.id);
    if (!userData) {
        await db.createUser(user);
        userData = await db.getUser(user.id);
    }
    
    const runtimeText = utils.runtime(process.uptime());
    
    const message = `
Hi kak @${sender}
╭─❒ 「 User Info 」 
├ Creator : @${userTelelu}
├ Name : ${user.first_name}${user.last_name ? ' ' + user.last_name : ''}
├ Profile : <a href="tg://user?id=${user.id}">Profile</a>
├ ID Telegram Anda: ${user.id}
├ Hostname : Linux
├ Platform : Bot Telegram
├ Runtime : ${runtimeText}
├ Tanggal Server : ${utils.moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${utils.moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreator ? 'True' : 'False'}
Silahkan pilih button dibawah ini!`;
    
    await ctx.replyWithHTML(message, keyboards.mainMenuKeyboard(isCreator));
}

// Command handler untuk /help
async function helpCommand(ctx) {
    const helpMessage = `
<b>Jasher Bot Help</b>

<b>Perintah Umum:</b>
/start - Memulai bot
/help - Menampilkan bantuan
/credit - Menampilkan credit Anda
/share - Membagikan pesan (harus di chat private)

<b>Perintah Admin:</b>
/addprem - Menambah user premium
/delprem - Menghapus user premium
/listprem - Menampilkan daftar premium
/broadcast - Mengirim pesan ke semua user

<b>Cara Mendapatkan Credit:</b>
1. Tambahkan bot ke 3 group untuk mendapatkan 10 credit
2. Setiap share dikenakan biaya 2 credit
3. ShareVIP untuk premium user`;
    
    await ctx.replyWithHTML(helpMessage);
}

// Command handler untuk /credit
async function creditCommand(ctx) {
    const user = ctx.from;
    let userData = await db.getUser(user.id);
    
    if (!userData) {
        await db.createUser(user);
        userData = await db.getUser(user.id);
    }
    
    const message = `
<b>💎 Credit Info</b>

Nama: ${user.first_name}${user.last_name ? ' ' + user.last_name : ''}
Credit: ${utils.formatCredits(userData.credits)}
Group ditambahkan: ${userData.added_groups}
Status: ${userData.is_premium ? 'Premium 🎖' : 'Regular'}

Untuk menambah credit, tambahkan bot ke group (minimal 3 group untuk bisa menggunakan fitur share)`;
    
    await ctx.replyWithHTML(message, keyboards.backButton('jasher_menu'));
}

// Command handler untuk /share (hanya di private chat)
async function shareCommand(ctx) {
    if (ctx.chat.type !== 'private') {
        await ctx.reply('❌ Perintah /share hanya bisa digunakan di chat private!');
        return;
    }
    
    const user = ctx.from;
    let userData = await db.getUser(user.id);
    
    if (!userData) {
        await db.createUser(user);
        userData = await db.getUser(user.id);
    }
    
    // Cek apakah user sudah menambahkan minimal 3 group
    if (userData.added_groups < CREDITS.MIN_GROUPS_FOR_SHARE) {
        await ctx.replyWithHTML(`❌ Anda harus menambahkan bot ke minimal <b>${CREDITS.MIN_GROUPS_FOR_SHARE} group</b> sebelum bisa menggunakan fitur share.\n\nGroup ditambahkan: <b>${userData.added_groups}/${CREDITS.MIN_GROUPS_FOR_SHARE}</b>`);
        return;
    }
    
    // Cek apakah punya cukup credit
    if (userData.credits < CREDITS.SHARE_COST) {
        await ctx.replyWithHTML(`❌ Credit tidak cukup! Dibutuhkan <b>${CREDITS.SHARE_COST} credit</b> untuk share.\n\nCredit Anda: <b>${utils.formatCredits(userData.credits)}</b>`);
        return;
    }
    
    const repliedMessage = ctx.message.reply_to_message;
    if (!repliedMessage) {
        await ctx.reply('❌ Balas pesan yang ingin di-share dengan perintah /share');
        return;
    }
    
    // Kurangi credit
    const newCredits = userData.credits - CREDITS.SHARE_COST;
    await db.updateUserCredits(user.id, newCredits);
    
    // Kirim pesan ke semua group
    const groups = await db.getAllGroups();
    let successCount = 0;
    
    for (const group of groups) {
        try {
            // Forward pesan yang di-reply
            await ctx.telegram.forwardMessage(group.group_id, ctx.chat.id, repliedMessage.message_id);
            successCount++;
        } catch (error) {
            console.error(`Gagal mengirim ke group ${group.group_id}:`, error.message);
        }
    }
    
    await ctx.replyWithHTML(`✅ Pesan berhasil di-share ke <b>${successCount}/${groups.length}</b> group\nCredit berkurang: <b>${CREDITS.SHARE_COST}</b>\nSisa credit: <b>${utils.formatCredits(newCredits)}</b>`);
}

// Command handler untuk /sharevip (hanya untuk premium)
async function shareVipCommand(ctx) {
    if (ctx.chat.type !== 'private') {
        await ctx.reply('❌ Perintah /sharevip hanya bisa digunakan di chat private!');
        return;
    }
    
    const user = ctx.from;
    let userData = await db.getUser(user.id);
    
    if (!userData) {
        await db.createUser(user);
        userData = await db.getUser(user.id);
    }
    
    // Cek status premium
    if (!userData.is_premium) {
        await ctx.reply('❌ Fitur ini hanya untuk user premium!');
        return;
    }
    
    const repliedMessage = ctx.message.reply_to_message;
    if (!repliedMessage) {
        await ctx.reply('❌ Balas pesan yang ingin di-share dengan perintah /sharevip');
        return;
    }
    
    // Kirim pesan ke semua group
    const groups = await db.getAllGroups();
    let successCount = 0;
    
    for (const group of groups) {
        try {
            // Forward pesan yang di-reply
            await ctx.telegram.forwardMessage(group.group_id, ctx.chat.id, repliedMessage.message_id);
            successCount++;
        } catch (error) {
            console.error(`Gagal mengirim ke group ${group.group_id}:`, error.message);
        }
    }
    
    await ctx.replyWithHTML(`✅ Pesan VIP berhasil di-share ke <b>${successCount}/${groups.length}</b> group`);
}

// Command handler untuk /broadcast (admin only)
async function broadcastCommand(ctx) {
    const user = ctx.from;
    
    if (!global.ADMINS.includes(user.id)) {
        await ctx.reply('❌ Perintah ini hanya untuk admin!');
        return;
    }
    
    const repliedMessage = ctx.message.reply_to_message;
    if (!repliedMessage) {
        await ctx.reply('❌ Balas pesan yang ingin di-broadcast dengan perintah /broadcast');
        return;
    }
    
    const users = await db.getAllUsers();
    let successCount = 0;
    
    for (const user of users) {
        try {
            // Forward pesan yang di-reply
            await ctx.telegram.forwardMessage(user.user_id, ctx.chat.id, repliedMessage.message_id);
            successCount++;
        } catch (error) {
            console.error(`Gagal mengirim ke user ${user.user_id}:`, error.message);
        }
    }
    
    await ctx.replyWithHTML(`✅ Broadcast berhasil dikirim ke <b>${successCount}/${users.length}</b> user`);
}

// Command handler untuk /addprem (admin only)
async function addPremiumCommand(ctx) {
    const user = ctx.from;
    
    if (!global.ADMINS.includes(user.id)) {
        await ctx.reply('❌ Perintah ini hanya untuk admin!');
        return;
    }
    
    const repliedMessage = ctx.message.reply_to_message;
    if (!repliedMessage) {
        await ctx.reply('❌ Balas pesan user yang ingin ditambahkan sebagai premium dengan perintah /addprem');
        return;
    }
    
    const targetUser = repliedMessage.from;
    let userData = await db.getUser(targetUser.id);
    
    if (!userData) {
        await db.createUser(targetUser);
        userData = await db.getUser(targetUser.id);
    }
    
    if (userData.is_premium) {
        await ctx.reply('❌ User sudah premium!');
        return;
    }
    
    await db.setPremium(targetUser.id, true);
    await ctx.replyWithHTML(`✅ User <a href="tg://user?id=${targetUser.id}">${targetUser.first_name}</a> berhasil ditambahkan sebagai premium!`);
    
    // Kirim notifikasi ke user
    try {
        await ctx.telegram.sendMessage(targetUser.id, '🎉 Selamat! Anda sekarang adalah user premium Jasher Bot!');
    } catch (error) {
        console.error('Gagal mengirim notifikasi ke user:', error.message);
    }
}

// Command handler untuk /delprem (admin only)
async function removePremiumCommand(ctx) {
    const user = ctx.from;
    
    if (!global.ADMINS.includes(user.id)) {
        await ctx.reply('❌ Perintah ini hanya untuk admin!');
        return;
    }
    
    const repliedMessage = ctx.message.reply_to_message;
    if (!repliedMessage) {
        await ctx.reply('❌ Balas pesan user yang ingin dihapus dari premium dengan perintah /delprem');
        return;
    }
    
    const targetUser = repliedMessage.from;
    let userData = await db.getUser(targetUser.id);
    
    if (!userData || !userData.is_premium) {
        await ctx.reply('❌ User bukan premium!');
        return;
    }
    
    await db.setPremium(targetUser.id, false);
    await ctx.replyWithHTML(`✅ User <a href="tg://user?id=${targetUser.id}">${targetUser.first_name}</a> berhasil dihapus dari premium!`);
}

// Command handler untuk /listprem (admin only)
async function listPremiumCommand(ctx) {
    const user = ctx.from;
    
    if (!global.ADMINS.includes(user.id)) {
        await ctx.reply('❌ Perintah ini hanya untuk admin!');
        return;
    }
    
    const premiumUsers = await db.getPremiumUsers();
    
    if (premiumUsers.length === 0) {
        await ctx.reply('❌ Tidak ada user premium!');
        return;
    }
    
    let message = '<b>📋 Daftar User Premium</b>\n\n';
    
    for (const user of premiumUsers) {
        message += `👤 ${user.first_name}${user.last_name ? ' ' + user.last_name : ''} (ID: ${user.user_id})\n`;
        if (user.username) message += `@${user.username}\n`;
        message += `Credit: ${utils.formatCredits(user.credits)}\n`;
        message += `Group: ${user.added_groups}\n`;
        message += `Joined: ${new Date(user.created_at).toLocaleDateString('id-ID')}\n`;
        message += '─\n';
    }
    
    await ctx.replyWithHTML(message);
}

module.exports = {
    startCommand,
    helpCommand,
    creditCommand,
    shareCommand,
    shareVipCommand,
    broadcastCommand,
    addPremiumCommand,
    removePremiumCommand,
    listPremiumCommand
};