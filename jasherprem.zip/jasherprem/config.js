global.BOT_TOKEN = "8198305874:AAH1Sfr54fyWkPSdfuLQTK_5hSyW69V2C7o";
global.DEVELOPER_ID = "8135269613";
global.DEVELOPER_USERNAME = "@ginaabaikhati";

// Ekspor untuk digunakan di file lain
module.exports = {
  BOT_TOKEN: global.BOT_TOKEN,
  DEVELOPER_ID: global.DEVELOPER_ID,
  DEVELOPER_USERNAME: global.DEVELOPER_USERNAME
};