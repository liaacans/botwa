global.BOT_TOKEN = process.env.BOT_TOKEN || '8404410811:AAEZIftEDvh7qfQ-zRxfCLbLuwMK3d9Vzc0';
global.PREFIX = '/';
global.OWNER_ID = process.env.OWNER_ID || '8373026763';

// Database configuration
global.DB_CONFIG = {
  host: process.env.DB_HOST || '2kred.h.filess.io',
  user: process.env.DB_USER || 'mybot_todaytime',
  password: process.env.DB_PASSWORD || '94a632154d44683eb18a23ee50f3a31a69e621f8',
  database: process.env.DB_NAME || 'mybot_todaytime'
};

module.exports = {
  BOT_TOKEN: global.BOT_TOKEN,
  PREFIX: global.PREFIX,
  OWNER_ID: global.OWNER_ID,
  DB_CONFIG: global.DB_CONFIG
};