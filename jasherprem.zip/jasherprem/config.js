global.BOT_TOKEN = "8198305874:AAH1Sfr54fyWkPSdfuLQTK_5hSyW69V2C7o";
global.OWNER_ID = "8135269613";
global.ADMIN_IDS = ["8135269613"];

module.exports = {
    BOT_TOKEN: global.BOT_TOKEN,
    OWNER_ID: global.OWNER_ID,
    ADMIN_IDS: global.ADMIN_IDS,
    PREMIUM_PRICE: 5000, // Harga premium dalam Rupiah
    SCRIPT_PRICE: 10000, // Harga script dalam Rupiah
    PREMIUM_DAYS: 30,
    FREE_TRIAL_DAYS: 1,
    REQUIRED_GROUPS: 3,
    UPLOAD_API: "https://uguu.se/upload.php"
};