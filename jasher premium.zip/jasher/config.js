global.BOT_TOKEN = process.env.BOT_TOKEN || '8108984883:AAH-Ycluwiw8Df9yNHziW8Tr83Dsym73UPI';
global.PREFIX = '/';
global.ADMIN_ID = [8373026763]; // Ganti dengan ID admin Anda

// Ekspor konfigurasi lainnya jika diperlukan
module.exports = {
    // Tambahan konfigurasi jika ada
};