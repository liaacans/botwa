global.BOT_TOKEN = process.env.BOT_TOKEN || '8384359584:AAHpNwlMPBmOGy29kpXhPBKQ6iPl7xGxmQk';
global.ADMIN_ID = process.env.ADMIN_ID || '8373026763';

module.exports = {
    BOT_TOKEN: global.BOT_TOKEN,
    ADMIN_ID: global.ADMIN_ID
};