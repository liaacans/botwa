const moment = require('moment-timezone');

// Format runtime
function runtime(seconds) {
    seconds = Math.floor(seconds);
    const days = Math.floor(seconds / (3600 * 24));
    seconds %= 3600 * 24;
    const hours = Math.floor(seconds / 3600);
    seconds %= 3600;
    const minutes = Math.floor(seconds / 60);
    seconds %= 60;
    
    return `${days}d ${hours}h ${minutes}m ${seconds}s`;
}

// Validasi URL
function isValidUrl(string) {
    try {
        new URL(string);
        return true;
    } catch (_) {
        return false;
    }
}

module.exports = { runtime, isValidUrl, moment };