const { Telegraf } = require('telegraf');
const path = require('path');
const fs = require('fs-extra');
const fetch = require('node-fetch');
const { updateProgress, log } = require('../../lib/functions');
const obfuscation = require('../../lib/obfuscation');

module.exports = (bot, users, groups, premium, blacklist) => {
    
    // Obf Menu
    bot.action('obf_menu', async (ctx) => {
        const obfText = `
╭─❒ 「 🔒 OBFUSCATION MENU 」 
├ enc3 - Mandarin Encryption
├ enc4 - Arab Encryption  
├ japan - Japan Encryption
├ zenc - Invisible Encryption
├ var - Var Encryption
├ nebula - Nebula Encryption
├ enc5 - Calcrick Encryption
├ quantum - Quantum Encryption
├ enc - Time-Locked Encryption
├ enc2 - Custom Encryption
├ deobfuscate - Deobfuscate
╰❒
Reply file .js dengan command diatas!`;

        const keyboard = Telegraf.Markup.inlineKeyboard([
            [Telegraf.Markup.button.callback('🔙 Kembali', 'main_menu')]
        ]);

        await ctx.editMessageCaption(obfText, {
            parse_mode: 'Markdown',
            ...keyboard
        });
    });

    // Helper function untuk obfuscation
    async function handleObfuscation(ctx, configFunction, encryptionName, filenamePrefix) {
        users.add(ctx.from.id);
        await require('../../lib/database').saveUsers(users);

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown(`
╭━━━「 ❌ ERROR 」━━━⬣
│ Terjadi kesalahan saat
│ memproses file!
╰━━━━━━━━━━━━━━━━⬣`);
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown(`
╭━━━「 ❌ ERROR 」━━━⬣
│ File harus berekstensi .js!
╰━━━━━━━━━━━━━━━━⬣`);
        }

        const encryptedPath = path.join(__dirname, `../../temp/${filenamePrefix}-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                ` ⚙️ Memulai (${encryptionName}) (1%)\n` +
                ` ${createProgressBar(1)}\n` +
                "```\n" +
                "PROSES ENCRYPT"
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk ${encryptionName}: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            log(`Memvalidasi kode: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode tidak valid: ${syntaxError.message}`);
            }

            log(`Mengenkripsi file dengan ${encryptionName}`);
            await updateProgress(ctx, progressMessage, 40, `Inisialisasi ${encryptionName}`);
            const obfuscated = await obfuscation[configFunction](fileContent);
            await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
            await fs.writeFile(encryptedPath, obfuscated.code || obfuscated);
            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

            log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
            try {
                new Function(obfuscated.code || obfuscated);
            } catch (postObfuscationError) {
                throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
            }

            log(`Mengirim file terenkripsi ${encryptionName}: ${file.file_name}`);
            await ctx.replyWithDocument(
                { source: encryptedPath, filename: `${filenamePrefix}-${file.file_name}` },
                {
                    caption: `✅ *File terenkripsi (${encryptionName}) siap!*\\nSUKSES ENCRYPT 🕊`,
                    parse_mode: "Markdown"
                }
            );
            await updateProgress(ctx, progressMessage, 100, `${encryptionName} Selesai`);

            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus: ${encryptedPath}`);
            }
        } catch (error) {
            log(`Kesalahan saat ${encryptionName} obfuscation`, error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\\n_Coba lagi dengan kode Javascript yang valid!_`
            );
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus setelah error: ${encryptedPath}`);
            }
        }
    }

    function createProgressBar(percent, length = 20) {
        const filled = Math.round(length * percent / 100);
        const empty = length - filled;
        return '█'.repeat(filled) + '░'.repeat(empty);
    }

    // enc3 - Mandarin Encryption
    bot.command("enc3", async (ctx) => {
        await handleObfuscation(ctx, 'getMandarinObfuscationConfig', 'Hardened Mandarin', 'china-encrypted');
    });

    // enc4 - Arab Encryption
    bot.command("enc4", async (ctx) => {
        await handleObfuscation(ctx, 'getArabObfuscationConfig', 'Hardened Arab', 'arab-encrypted');
    });

    // japan - Japan Encryption
    bot.command("japan", async (ctx) => {
        await handleObfuscation(ctx, 'getJapanObfuscationConfig', 'Hardened Japan', 'japan-encrypted');
    });

    // zenc - Invisible Encryption
    bot.command("zenc", async (ctx) => {
        await handleObfuscation(ctx, 'getStrongObfuscationConfig', 'Invisible', 'invisible-encrypted');
    });

    // var - Var Encryption
    bot.command("var", async (ctx) => {
        await handleObfuscation(ctx, 'getNovaObfuscationConfig', 'Var Dynamic', 'var-encrypted');
    });

    // nebula - Nebula Encryption
    bot.command("nebula", async (ctx) => {
        await handleObfuscation(ctx, 'getNebulaObfuscationConfig', 'Nebula Polymorphic Storm', 'nebula-encrypted');
    });

    // enc5 - Calcrick Encryption
    bot.command("enc5", async (ctx) => {
        await handleObfuscation(ctx, 'getSiuCalcrickObfuscationConfig', 'Calcrick Chaos Core', 'siucalcrick-encrypted');
    });

    // quantum - Quantum Encryption
    bot.command("quantum", async (ctx) => {
        users.add(ctx.from.id);
        await require('../../lib/database').saveUsers(users);

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/quantum`!");
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const encryptedPath = path.join(__dirname, `../../temp/quantum-encrypted-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                " ⚙️ Memulai (Quantum Vortex Encryption) (1%)\n" +
                " " + createProgressBar(1) + "\n" +
                "```\n" +
                "PROSES ENCRYPT"
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk Quantum Vortex Encryption: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            log(`Memvalidasi kode awal: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
            }

            log(`Mengenkripsi file dengan Quantum Vortex Encryption`);
            await updateProgress(ctx, progressMessage, 40, "Inisialisasi Quantum Vortex Encryption");
            const obfuscatedCode = await obfuscation.obfuscateQuantum(fileContent);
            await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");

            log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
            try {
                new Function(obfuscatedCode);
            } catch (postObfuscationError) {
                throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
            }

            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
            await fs.writeFile(encryptedPath, obfuscatedCode);

            log(`Mengirim file terenkripsi quantum: ${file.file_name}`);
            await ctx.replyWithDocument(
                { source: encryptedPath, filename: `quantum-encrypted-${file.file_name}` },
                {
                    caption: "✅ *File terenkripsi (Quantum Vortex Encryption) siap!*\\nSUKSES ENCRYPT 🕊",
                    parse_mode: "Markdown"
                }
            );
            await updateProgress(ctx, progressMessage, 100, "Quantum Vortex Encryption Selesai");

            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
            }
        } catch (error) {
            log("Kesalahan saat Quantum obfuscation", error);
            await ctx.replyWithMarkdown(`❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\\n_Coba lagi dengan kode Javascript yang valid!_`);
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
            }
        }
    });

    // enc - Time-Locked Encryption
    bot.command("enc", async (ctx) => {
        users.add(ctx.from.id);
        await require('../../lib/database').saveUsers(users);

        const args = ctx.message.text.split(" ").slice(1);
        if (args.length !== 1 || !/^\d+$/.test(args[0]) || parseInt(args[0]) < 1 || parseInt(args[0]) > 365) {
            return ctx.replyWithMarkdown("❌ *Error:* Gunakan format `/enc [1-365]` untuk jumlah hari (misal: `/enc 7`)!");
        }

        const days = args[0];
        const expiryDate = new Date();
        expiryDate.setDate(expiryDate.getDate() + parseInt(days));

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc [1-365]`!");
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const encryptedPath = path.join(__dirname, `../../temp/locked-encrypted-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                " ⚙️ Memulai (Time-Locked Encryption) (1%)\n" +
                " " + createProgressBar(1) + "\n" +
                "```\n" +
                "PROSES ENCRYPT"
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk Time-Locked Encryption: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            log(`Memvalidasi kode awal: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
            }

            log(`Mengenkripsi file dengan Time-Locked Encryption`);
            await updateProgress(ctx, progressMessage, 40, "Inisialisasi Time-Locked Encryption");
            const obfuscatedCode = await obfuscation.obfuscateTimeLocked(fileContent, days);
            await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");

            log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
            try {
                new Function(obfuscatedCode);
            } catch (postObfuscationError) {
                throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
            }

            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
            await fs.writeFile(encryptedPath, obfuscatedCode);

            log(`Mengirim file terenkripsi time-locked: ${file.file_name}`);
            await ctx.replyWithMarkdown(
                `✅ *File terenkripsi (Time-Locked Encryption) siap!*\\n` +
                `⏰ Masa aktif: ${days} hari (Kedaluwarsa: ${expiryDate.toLocaleDateString()})\\n` +
                `_Powered by Ginaa_`,
                { parse_mode: "Markdown" }
            );
            await ctx.replyWithDocument({ source: encryptedPath, filename: `locked-encrypted-${file.file_name}` });
            await updateProgress(ctx, progressMessage, 100, "Time-Locked Encryption Selesai");

            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
            }
        } catch (error) {
            log("Kesalahan saat Time-Locked obfuscation", error);
            await ctx.replyWithMarkdown(`❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\\n_Coba lagi dengan kode Javascript yang valid!_`);
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
            }
        }
    });

    // enc2 - Custom Encryption
    bot.command("enc2", async (ctx) => {
        users.add(ctx.from.id);
        await require('../../lib/database').saveUsers(users);

        const customString = ctx.message.text.split(" ")[1];
        if (!customString) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc2 <text>`!");
        }

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc2 <text>`!");
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const encryptedPath = path.join(__dirname, `../../temp/custom-encrypted-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                " ⚙️ Memulai (custom enc) (1%)\n" +
                " " + createProgressBar(1) + "\n" +
                "```\n" +
                "PROSES ENCRYPT"
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk custom obfuscation: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            log(`Memvalidasi kode awal: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
            }

            log(`Mengenkripsi file dengan gaya custom (${customString})`);
            await updateProgress(ctx, progressMessage, 40, `Inisialisasi custom (${customString})`);

            const obfuscated = await obfuscation.getCustomObfuscationConfig(customString)(fileContent);
            await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
            await fs.writeFile(encryptedPath, obfuscated.code || obfuscated);
            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

            log(`Mengirim file terenkripsi gaya custom (${customString}): ${file.file_name}`);
            await ctx.replyWithDocument(
                { source: encryptedPath, filename: `custom-encrypted-${file.file_name}` },
                {
                    caption: `✅ *File terenkripsi custom (${customString}) siap!*\\nSUKSES ENCRYPT 🕊`,
                    parse_mode: "Markdown"
                }
            );
            await updateProgress(ctx, progressMessage, 100, `custom (${customString}) Selesai`);

            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
            }
        } catch (error) {
            log("Kesalahan saat custom enc obfuscation", error);
            await ctx.replyWithMarkdown(`❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\\n_Coba lagi dengan kode Javascript yang valid!_`);
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
            }
        }
    });

    // deobfuscate - Deobfuscate
    bot.command("deobfuscate", async (ctx) => {
        users.add(ctx.from.id);
        await require('../../lib/database').saveUsers(users);

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js yang diobfuscate dengan `/deobfuscate`!");
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const deobfuscatedPath = path.join(__dirname, `../../temp/deobfuscated-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                " ⚙️ Memulai Deobfuscation (1%)\n" +
                " " + createProgressBar(1) + "\n" +
                "```\n" +
                "PROSES DECRYPT"
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk deobfuscation: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            // Simple deobfuscation attempt (basic string cleaning)
            await updateProgress(ctx, progressMessage, 40, "Memulai Deobfuscation");
            let deobfuscatedCode = fileContent;
            
            // Basic cleanup attempts
            deobfuscatedCode = deobfuscatedCode
                .replace(/\\x[0-9A-Fa-f]{2}/g, match => {
                    return String.fromCharCode(parseInt(match.substr(2), 16));
                })
                .replace(/\\u[0-9A-Fa-f]{4}/g, match => {
                    return String.fromCharCode(parseInt(match.substr(2), 16));
                });

            await updateProgress(ctx, progressMessage, 80, "Menyimpan Hasil");
            await fs.writeFile(deobfuscatedPath, deobfuscatedCode);

            await ctx.replyWithDocument(
                { source: deobfuscatedPath, filename: `deobfuscated-${file.file_name}` },
                {
                    caption: "✅ *File berhasil dideobfuscate!*\\nSUKSES DECRYPT 🕊",
                    parse_mode: "Markdown"
                }
            );
            await updateProgress(ctx, progressMessage, 100, "Deobfuscation Selesai");

            if (await fs.pathExists(deobfuscatedPath)) {
                await fs.unlink(deobfuscatedPath);
            }
        } catch (error) {
            log("Kesalahan saat deobfuscation", error);
            await ctx.replyWithMarkdown(`❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\\n_Coba lagi dengan file Javascript yang valid!_`);
            if (await fs.pathExists(deobfuscatedPath)) {
                await fs.unlink(deobfuscatedPath);
            }
        }
    });
};