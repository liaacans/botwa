const { getDB } = require('../lib/database');

// Handler ketika bot ditambahkan ke group
async function handleNewChatMembers(ctx) {
  const db = getDB();
  
  // Jika bot yang ditambahkan ke group
  if (ctx.message.new_chat_members.some(member => member.is_bot && member.id === ctx.botInfo.id)) {
    const groupId = ctx.chat.id;
    const groupName = ctx.chat.title;
    
    // Simpan group ke database
    await db.collection('groups').updateOne(
      { groupId },
      { $set: { groupId, groupName, addedAt: new Date() } },
      { upsert: true }
    );
    
    await ctx.reply('✅ Terima kasih telah menambahkan Jasher Bot ke group ini!\n\nKetik /register untuk mendaftarkan group dan mendapatkan kredit.');
  }
}

// Handler ketika bot dihapus dari group
async function handleLeftChatMember(ctx) {
  const db = getDB();
  
  // Jika bot yang dihapus dari group
  if (ctx.message.left_chat_member && ctx.message.left_chat_member.id === ctx.botInfo.id) {
    const groupId = ctx.chat.id;
    
    // Hapus group dari database
    await db.collection('groups').deleteOne({ groupId });
  }
}

// Handler untuk command register di group
async function handleRegisterGroup(ctx) {
  const db = getDB();
  const userId = ctx.from.id;
  const groupId = ctx.chat.id;
  
  // Cek apakah di group
  if (ctx.chat.type === 'private') {
    await ctx.reply('❌ Command /register hanya bisa digunakan di group!');
    return;
  }
  
  // Cek apakah user sudah menambahkan group ini
  const user = await db.collection('users').findOne({ userId });
  const alreadyAdded = user && user.joinedGroups && user.joinedGroups.includes(groupId);
  
  if (alreadyAdded) {
    await ctx.reply('❌ Group ini sudah terdaftar!');
    return;
  }
  
  // Tambahkan group ke user
  await db.collection('users').updateOne(
    { userId },
    { $push: { joinedGroups: groupId } },
    { upsert: true }
  );
  
  // Jika sudah 3 group, beri 10 kredit
  const updatedUser = await db.collection('users').findOne({ userId });
  const groupCount = updatedUser.joinedGroups ? updatedUser.joinedGroups.length : 1;
  
  if (groupCount === 3) {
    await db.collection('users').updateOne(
      { userId },
      { $inc: { credits: 10 } }
    );
    
    await ctx.reply(`✅ Group berhasil didaftarkan!\n🎉 Selamat! Anda telah menambahkan 3 group dan mendapatkan 10 kredit!`);
  } else {
    await ctx.reply(`✅ Group berhasil didaftarkan!\n📊 Group terdaftar: ${groupCount}/3`);
  }
}

module.exports = {
  handleNewChatMembers,
  handleLeftChatMember,
  handleRegisterGroup
};