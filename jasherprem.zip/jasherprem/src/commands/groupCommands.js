const { Markup } = require('telegraf');
const { isOwner, log } = require('../../lib/utils');
const { addGroup, getGroup, updateUserGroups, getUser } = require('../../lib/database');

module.exports = (bot) => {
    // Addgroup command - untuk menambah group ke database
    bot.command('addgroup', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ Command ini hanya bisa digunakan di group!');
        }

        const groupId = ctx.chat.id;
        const groupName = ctx.chat.title;
        const userId = ctx.from.id;

        // Cek apakah user sudah menambah 3 group
        const user = getUser(userId);
        const groupsAdded = user?.groups_added || 0;

        if (groupsAdded >= 3) {
            return ctx.reply(
                `✅ Anda sudah menambahkan ${groupsAdded} group. ` +
                `Premium gratis 3 hari sudah aktif!`
            );
        }

        // Tambah group ke database
        addGroup(groupId, {
            title: groupName,
            username: ctx.chat.username,
            added_by: userId,
            member_count: ctx.chat.members_count
        });

        // Update count groups added by user
        updateUserGroups(userId, groupsAdded + 1);

        await ctx.reply(
            `✅ *Group berhasil ditambahkan!*\n\n` +
            `🏷️ Group: ${groupName}\n` +
            `👤 Ditambah oleh: ${ctx.from.first_name}\n` +
            `📊 Status: ${groupsAdded + 1}/3 group\n\n` +
            `Tambahkan bot ke 2 group lagi untuk mendapatkan premium gratis 3 hari!`,
            { parse_mode: 'Markdown' }
        );

        log(`Group ditambahkan: ${groupName} (${groupId}) oleh ${ctx.from.first_name} (${userId})`);
    });

    // Group settings commands (hanya admin group)
    bot.command('antispam', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ Command ini hanya bisa digunakan di group!');
        }

        // Cek apakah pengguna adalah admin
        try {
            const member = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(member.status)) {
                return ctx.reply('❌ Hanya admin group yang bisa menggunakan command ini!');
            }
        } catch (error) {
            return ctx.reply('❌ Gagal memverifikasi status admin.');
        }

        await ctx.reply(
            `✅ *Anti-Spam Diaktifkan!*\n\n` +
            `Fitur anti-spam sekarang aktif di group ini.\n` +
            `• Blokir pesan spam otomatis\n` +
            `• Deteksi flood message\n` +
            `• Blokir user spam`,
            { parse_mode: 'Markdown' }
        );
    });

    bot.command('noevent', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ Command ini hanya bisa digunakan di group!');
        }

        try {
            const member = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(member.status)) {
                return ctx.reply('❌ Hanya admin group yang bisa menggunakan command ini!');
            }
        } catch (error) {
            return ctx.reply('❌ Gagal memverifikasi status admin.');
        }

        await ctx.reply(
            `✅ *No Event Mode Diaktifkan!*\n\n` +
            `Event seperti pin message, group title change, dll akan dibatasi.`,
            { parse_mode: 'Markdown' }
        );
    });

    bot.command('nolinks', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ Command ini hanya bisa digunakan di group!');
        }

        try {
            const member = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(member.status)) {
                return ctx.reply('❌ Hanya admin group yang bisa menggunakan command ini!');
            }
        } catch (error) {
            return ctx.reply('❌ Gagal memverifikasi status admin.');
        }

        await ctx.reply(
            `✅ *No Links Mode Diaktifkan!*\n\n` +
            `Semua link/http/https akan dihapus otomatis.`,
            { parse_mode: 'Markdown' }
        );
    });

    bot.command('noforwards', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ Command ini hanya bisa digunakan di group!');
        }

        try {
            const member = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(member.status)) {
                return ctx.reply('❌ Hanya admin group yang bisa menggunakan command ini!');
            }
        } catch (error) {
            return ctx.reply('❌ Gagal memverifikasi status admin.');
        }

        await ctx.reply(
            `✅ *No Forwards Mode Diaktifkan!*\n\n` +
            `Pesan yang di-forward dari chat lain akan dihapus.`,
            { parse_mode: 'Markdown' }
        );
    });

    bot.command('nocontacts', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ Command ini hanya bisa digunakan di group!');
        }

        try {
            const member = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(member.status)) {
                return ctx.reply('❌ Hanya admin group yang bisa menggunakan command ini!');
            }
        } catch (error) {
            return ctx.reply('❌ Gagal memverifikasi status admin.');
        }

        await ctx.reply(
            `✅ *No Contacts Mode Diaktifkan!*\n\n` +
            `Sharing kontak telepon akan diblokir.`,
            { parse_mode: 'Markdown' }
        );
    });

    bot.command('nohashtags', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ Command ini hanya bisa digunakan di group!');
        }

        try {
            const member = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(member.status)) {
                return ctx.reply('❌ Hanya admin group yang bisa menggunakan command ini!');
            }
        } catch (error) {
            return ctx.reply('❌ Gagal memverifikasi status admin.');
        }

        await ctx.reply(
            `✅ *No Hashtags Mode Diaktifkan!*\n\n` +
            `Penggunaan hashtag (#) akan dibatasi.`,
            { parse_mode: 'Markdown' }
        );
    });

    bot.command('nocommands', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ Command ini hanya bisa digunakan di group!');
        }

        try {
            const member = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(member.status)) {
                return ctx.reply('❌ Hanya admin group yang bisa menggunakan command ini!');
            }
        } catch (error) {
            return ctx.reply('❌ Gagal memverifikasi status admin.');
        }

        await ctx.reply(
            `✅ *No Commands Mode Diaktifkan!*\n\n` +
            `Command bot (/) dari member biasa akan diabaikan.`,
            { parse_mode: 'Markdown' }
        );
    });

    // Group info command
    bot.command('groupinfo', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ Command ini hanya bisa digunakan di group!');
        }

        const group = getGroup(ctx.chat.id);
        if (!group) {
            return ctx.reply('❌ Group belum terdaftar. Gunakan /addgroup terlebih dahulu.');
        }

        try {
            const chat = await ctx.getChat();
            const membersCount = await ctx.telegram.getChatMembersCount(ctx.chat.id);

            await ctx.reply(
                `🏷️ *Group Info*\n\n` +
                `📝 Nama: ${chat.title}\n` +
                `🆔 ID: ${ctx.chat.id}\n` +
                `👥 Members: ${membersCount}\n` +
                `👤 Added by: ${group.added_by}\n` +
                `📅 Ditambahkan: ${new Date(group.added).toLocaleDateString('id-ID')}\n` +
                `🌐 Username: ${chat.username ? '@' + chat.username : 'Tidak ada'}`,
                { parse_mode: 'Markdown' }
            );
        } catch (error) {
            await ctx.reply('❌ Gagal mendapatkan info group.');
        }
    });

    // Message handler untuk fitur group
    bot.on('message', async (ctx) => {
        // Skip jika private chat
        if (ctx.chat.type === 'private') return;

        // Handle pesan yang di-reply dengan "sharefree" atau "sharevip"
        if (ctx.message.reply_to_message && ctx.message.text) {
            const text = ctx.message.text.toLowerCase();
            
            if (text.includes('sharefree')) {
                await handleShare(ctx, 'free');
            } else if (text.includes('sharevip')) {
                await handleShare(ctx, 'vip');
            }
        }

        // Handle fitur group protection
        await handleGroupProtection(ctx);
    });

    async function handleShare(ctx, type) {
        const originalMessage = ctx.message.reply_to_message;
        const user = getUser(ctx.from.id);
        
        if (type === 'free') {
            // Share free - cek apakah sudah menambah 3 group
            if ((user?.groups_added || 0) < 3) {
                await ctx.reply(
                    `❌ Anda harus menambahkan bot ke 3 group terlebih dahulu!\n` +
                    `📊 Status: ${user?.groups_added || 0}/3 group\n\n` +
                    `Gunakan /addgroup di group yang berbeda.`
                );
                return;
            }
        } else {
            // Share VIP - cek premium
            const { isPremium } = require('../../lib/utils');
            if (!isPremium(ctx.from.id)) {
                await ctx.reply(
                    `❌ Anda harus premium untuk menggunakan Share VIP!\n\n` +
                    `Gunakan Share Free terlebih dahulu atau beli premium.`
                );
                return;
            }
        }

        try {
            // Forward message dengan caption
            const caption = type === 'free' ? '🆓 Shared via Share Free' : '💎 Shared via Share VIP';
            
            if (originalMessage.text) {
                await ctx.telegram.sendMessage(
                    ctx.chat.id,
                    `*${caption}*\n\n${originalMessage.text}`,
                    { parse_mode: 'Markdown' }
                );
            } else if (originalMessage.photo) {
                await ctx.telegram.sendPhoto(
                    ctx.chat.id,
                    originalMessage.photo[originalMessage.photo.length - 1].file_id,
                    { caption: caption }
                );
            } else if (originalMessage.document) {
                await ctx.telegram.sendDocument(
                    ctx.chat.id,
                    originalMessage.document.file_id,
                    { caption: caption }
                );
            } else {
                await ctx.reply('❌ Jenis pesan tidak didukung untuk sharing.');
            }

            // Hapus perintah share
            await ctx.deleteMessage();

        } catch (error) {
            log('Error handling share:', error);
            await ctx.reply('❌ Gagal melakukan sharing pesan.');
        }
    }

    async function handleGroupProtection(ctx) {
        // Basic group protection features
        const message = ctx.message.text || ctx.message.caption || '';
        
        // Anti-link protection
        if (message.match(/https?:\/\/[^\s]+/g)) {
            try {
                const member = await ctx.getChatMember(ctx.from.id);
                if (!['administrator', 'creator'].includes(member.status)) {
                    await ctx.deleteMessage();
                    await ctx.reply(
                        `❌ Link tidak diizinkan di group ini!\n` +
                        `👤 User: ${ctx.from.first_name}`
                    );
                    log(`Link dihapus dari ${ctx.from.first_name} di group ${ctx.chat.title}`);
                }
            } catch (error) {
                // Ignore errors
            }
        }

        // Anti-hashtag protection
        if (message.match(/#\w+/g) && message.split('#').length > 5) {
            try {
                const member = await ctx.getChatMember(ctx.from.id);
                if (!['administrator', 'creator'].includes(member.status)) {
                    await ctx.deleteMessage();
                    await ctx.reply(
                        `❌ Terlalu banyak hashtag!\n` +
                        `👤 User: ${ctx.from.first_name}`
                    );
                }
            } catch (error) {
                // Ignore errors
            }
        }
    }

    // Handle new chat members
    bot.on('new_chat_members', async (ctx) => {
        if (ctx.message.new_chat_members.some(member => member.is_bot && member.id !== ctx.botInfo.id)) {
            // Bot lain ditambahkan - notifikasi
            await ctx.reply(
                `⚠️ *Bot lain terdeteksi!*\n\n` +
                `Disarankan untuk hanya menggunakan ${global.BOT_NAME} ` +
                `untuk keamanan group.`,
                { parse_mode: 'Markdown' }
            );
        }
    });

    // Handle left chat member
    bot.on('left_chat_member', async (ctx) => {
        if (ctx.message.left_chat_member.id === ctx.botInfo.id) {
            // Bot dikeluarkan dari group
            const { removeGroup } = require('../../lib/database');
            removeGroup(ctx.chat.id);
            log(`Bot dikeluarkan dari group: ${ctx.chat.title} (${ctx.chat.id})`);
        }
    });
};