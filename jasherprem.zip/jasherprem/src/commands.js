const { getDB } = require('../lib/database');
const { runtime, parseMode, moment } = require('./utils');

// Handler untuk command start
async function handleStart(ctx) {
  const db = getDB();
  const userId = ctx.from.id;
  const username = ctx.from.username || ctx.from.first_name;
  
  // Cek apakah user sudah terdaftar
  let user = await db.collection('users').findOne({ userId });
  
  if (!user) {
    // Buat user baru dengan kredit 0
    user = {
      userId,
      username,
      credits: 0,
      joinedGroups: [],
      createdAt: new Date(),
      isPremium: false
    };
    await db.collection('users').insertOne(user);
  }
  
  // Cek apakah user adalah owner
  const isCreator = userId.toString() === global.OWNER_ID;
  
  const message = `Hi kak @${username}
╭─❒ 「 User Info 」 
├ Creator : @${username}
├ Name : @${username}
├ Profile : @${username}
├ ID Telegram Anda: ${userId}
├ Hostname : Linux
├ Platform : Bot Telegram
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreator ? 'True' : 'False'}
Silahkan pilih button dibawah ini!`;

  const keyboard = {
    reply_markup: {
      inline_keyboard: [
        [
          { text: 'Jasher Menu', callback_data: 'jasher_menu' },
          { text: 'Owner Menu', callback_data: 'owner_menu' }
        ],
        [
          { text: 'AddGroup', callback_data: 'add_group' },
          { text: 'Owner', url: 'https://t.me/your_username' } // Ganti dengan username Anda
        ]
      ]
    }
  };

  await ctx.reply(message, keyboard);
}

// Handler untuk command help
async function handleHelp(ctx) {
  const helpMessage = `🔷 *Jasher Bot Help* 🔷

*Available Commands:*
/start - Memulai bot
/help - Menampilkan bantuan
/credit - Menampilkan kredit Anda
/share - Membagikan pesan (3 group diperlukan)

*Cara Mendapatkan Kredit:*
1. Tambahkan bot ke 3 group untuk mendapatkan 10 kredit
2. Setiap share mengurangi 2 kredit

*Share Premium:*
Gunakan /sharevip untuk broadcast yang lebih cepat (hanya untuk user premium)`;

  await ctx.reply(helpMessage, { parse_mode: 'Markdown' });
}

// Handler untuk command credit
async function handleCredit(ctx) {
  const db = getDB();
  const userId = ctx.from.id;
  
  const user = await db.collection('users').findOne({ userId });
  const creditCount = user ? user.credits : 0;
  const groupCount = user && user.joinedGroups ? user.joinedGroups.length : 0;
  
  const message = `💎 *Credit Information*

👤 User: @${ctx.from.username || ctx.from.first_name}
💰 Credits: ${creditCount}
👥 Groups Added: ${groupCount}/3

${groupCount < 3 ? '⚠️ Tambahkan bot ke 3 group untuk mendapatkan 10 kredit!' : '✅ Anda sudah memenuhi syarat group!'}`;

  await ctx.reply(message, { parse_mode: 'Markdown' });
}

// Handler untuk command share
async function handleShare(ctx) {
  // Cek apakah di private chat
  if (ctx.chat.type !== 'private') {
    await ctx.reply('❌ Command /share hanya bisa digunakan di private chat!');
    return;
  }

  const db = getDB();
  const userId = ctx.from.id;
  const user = await db.collection('users').findOne({ userId });
  
  // Cek apakah user sudah menambahkan 3 group
  if (!user || user.joinedGroups.length < 3) {
    await ctx.reply(`❌ Anda harus menambahkan bot ke 3 group terlebih dahulu!\nGroup terdaftar: ${user ? user.joinedGroups.length : 0}/3`);
    return;
  }
  
  // Cek apakah punya cukup kredit
  if (user.credits < 2) {
    await ctx.reply(`❌ Kredit tidak cukup! Anda membutuhkan 2 kredit untuk share.\nKredit Anda: ${user.credits}`);
    return;
  }
  
  // Cek apakah ada pesan yang di-reply
  if (!ctx.message.reply_to_message) {
    await ctx.reply('❌ Balas pesan yang ingin di-share dengan command /share');
    return;
  }
  
  const messageToShare = ctx.message.reply_to_message;
  
  // Kurangi kredit user
  await db.collection('users').updateOne(
    { userId },
    { $inc: { credits: -2 } }
  );
  
  // Broadcast ke semua group yang terdaftar
  const groups = await db.collection('groups').find({}).toArray();
  
  let successCount = 0;
  let failCount = 0;
  
  for (const group of groups) {
    try {
      await ctx.telegram.copyMessage(group.groupId, ctx.chat.id, messageToShare.message_id);
      successCount++;
    } catch (error) {
      console.error(`Error sending to group ${group.groupId}:`, error);
      failCount++;
    }
  }
  
  await ctx.reply(`✅ Pesan berhasil di-share ke ${successCount} group!\n❌ Gagal: ${failCount} group\n💰 Kredit dikurangi: 2`);
}

// Handler untuk command sharevip (premium)
async function handleShareVip(ctx) {
  // Cek apakah di private chat
  if (ctx.chat.type !== 'private') {
    await ctx.reply('❌ Command /sharevip hanya bisa digunakan di private chat!');
    return;
  }

  const db = getDB();
  const userId = ctx.from.id;
  const user = await db.collection('users').findOne({ userId });
  
  // Cek apakah user premium
  if (!user || !user.isPremium) {
    await ctx.reply('❌ Fitur ini hanya untuk user premium!');
    return;
  }
  
  // Cek apakah ada pesan yang di-reply
  if (!ctx.message.reply_to_message) {
    await ctx.reply('❌ Balas pesan yang ingin di-share dengan command /sharevip');
    return;
  }
  
  const messageToShare = ctx.message.reply_to_message;
  
  // Broadcast ke semua group yang terdaftar (lebih cepat)
  const groups = await db.collection('groups').find({}).toArray();
  
  let successCount = 0;
  let failCount = 0;
  
  // Menggunakan Promise.all untuk broadcast lebih cepat
  const sendPromises = groups.map(async (group) => {
    try {
      await ctx.telegram.copyMessage(group.groupId, ctx.chat.id, messageToShare.message_id);
      successCount++;
    } catch (error) {
      console.error(`Error sending to group ${group.groupId}:`, error);
      failCount++;
    }
  });
  
  await Promise.all(sendPromises);
  
  await ctx.reply(`✅ Pesan berhasil di-share VIP ke ${successCount} group!\n❌ Gagal: ${failCount} group`);
}

// Handler untuk command addprem (owner only)
async function handleAddPrem(ctx) {
  const db = getDB();
  const userId = ctx.from.id;
  
  // Cek apakah owner
  if (userId.toString() !== global.OWNER_ID) {
    await ctx.reply('❌ Command ini hanya untuk owner!');
    return;
  }
  
  // Cek apakah ada user yang di-reply atau disebutkan
  let targetUserId;
  if (ctx.message.reply_to_message) {
    targetUserId = ctx.message.reply_to_message.from.id;
  } else if (ctx.message.text.split(' ').length > 1) {
    targetUserId = ctx.message.text.split(' ')[1];
  } else {
    await ctx.reply('❌ Balas pesan user atau sertakan user ID!');
    return;
  }
  
  // Tambahkan user ke premium
  await db.collection('users').updateOne(
    { userId: targetUserId },
    { $set: { isPremium: true } },
    { upsert: true }
  );
  
  await db.collection('premiumUsers').updateOne(
    { userId: targetUserId },
    { $set: { userId: targetUserId, addedAt: new Date() } },
    { upsert: true }
  );
  
  await ctx.reply(`✅ User ${targetUserId} berhasil ditambahkan ke premium!`);
}

// Handler untuk command delprem (owner only)
async function handleDelPrem(ctx) {
  const db = getDB();
  const userId = ctx.from.id;
  
  // Cek apakah owner
  if (userId.toString() !== global.OWNER_ID) {
    await ctx.reply('❌ Command ini hanya untuk owner!');
    return;
  }
  
  // Cek apakah ada user yang di-reply atau disebutkan
  let targetUserId;
  if (ctx.message.reply_to_message) {
    targetUserId = ctx.message.reply_to_message.from.id;
  } else if (ctx.message.text.split(' ').length > 1) {
    targetUserId = ctx.message.text.split(' ')[1];
  } else {
    await ctx.reply('❌ Balas pesan user atau sertakan user ID!');
    return;
  }
  
  // Hapus user dari premium
  await db.collection('users').updateOne(
    { userId: targetUserId },
    { $set: { isPremium: false } }
  );
  
  await db.collection('premiumUsers').deleteOne({ userId: targetUserId });
  
  await ctx.reply(`✅ User ${targetUserId} berhasil dihapus dari premium!`);
}

// Handler untuk command listprem (owner only)
async function handleListPrem(ctx) {
  const db = getDB();
  const userId = ctx.from.id;
  
  // Cek apakah owner
  if (userId.toString() !== global.OWNER_ID) {
    await ctx.reply('❌ Command ini hanya untuk owner!');
    return;
  }
  
  const premiumUsers = await db.collection('premiumUsers').find({}).toArray();
  
  if (premiumUsers.length === 0) {
    await ctx.reply('❌ Tidak ada user premium!');
    return;
  }
  
  let message = '📋 *Daftar User Premium*\n\n';
  premiumUsers.forEach((user, index) => {
    message += `${index + 1}. User ID: ${user.userId}\n   Ditambahkan: ${moment(user.addedAt).format('DD/MM/YY HH:mm:ss')}\n\n`;
  });
  
  await ctx.reply(message, { parse_mode: 'Markdown' });
}

// Handler untuk callback queries (button presses)
async function handleCallbackQuery(ctx) {
  const data = ctx.update.callback_query.data;
  const userId = ctx.from.id;
  const db = getDB();
  
  switch (data) {
    case 'jasher_menu':
      const user = await db.collection('users').findOne({ userId });
      const creditCount = user ? user.credits : 0;
      
      const jasherMenu = `🔷 *Jasher Menu* 🔷

💰 Credits: ${creditCount}
👥 Groups: ${user && user.joinedGroups ? user.joinedGroups.length : 0}/3

📊 *Fitur:*
- /share - Broadcast pesan (2 credits)
- /sharevip - Broadcast premium (hanya premium user)`;
      
      await ctx.editMessageText(jasherMenu, {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: 'Kembali', callback_data: 'back_to_main' }]
          ]
        }
      });
      break;
      
    case 'owner_menu':
      // Cek apakah owner
      if (userId.toString() !== global.OWNER_ID) {
        await ctx.answerCbQuery('❌ Menu ini hanya untuk owner!');
        return;
      }
      
      const ownerMenu = `🔷 *Owner Menu* 🔷

📊 *Fitur Owner:*
- /addprem - Tambah user premium
- /delprem - Hapus user premium
- /listprem - List user premium
- Broadcast ke semua user`;
      
      await ctx.editMessageText(ownerMenu, {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: 'Kembali', callback_data: 'back_to_main' }]
          ]
        }
      });
      break;
      
    case 'add_group':
      await ctx.editMessageText('📌 Untuk menambahkan group:\n\n1. Tambahkan bot @jasherbot ke group Anda\n2. Jadikan bot sebagai admin\n3. Ketik /register di group tersebut', {
        reply_markup: {
          inline_keyboard: [
            [{ text: 'Kembali', callback_data: 'back_to_main' }]
          ]
        }
      });
      break;
      
    case 'back_to_main':
      const username = ctx.from.username || ctx.from.first_name;
      const isCreator = userId.toString() === global.OWNER_ID;
      
      const mainMessage = `Hi kak @${username}
╭─❒ 「 User Info 」 
├ Creator : @${username}
├ Name : @${username}
├ Profile : @${username}
├ ID Telegram Anda: ${userId}
├ Hostname : Linux
├ Platform : Bot Telegram
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreator ? 'True' : 'False'}
Silahkan pilih button dibawah ini!`;

      await ctx.editMessageText(mainMessage, {
        reply_markup: {
          inline_keyboard: [
            [
              { text: 'Jasher Menu', callback_data: 'jasher_menu' },
              { text: 'Owner Menu', callback_data: 'owner_menu' }
            ],
            [
              { text: 'AddGroup', callback_data: 'add_group' },
              { text: 'Owner', url: 'https://t.me/your_username' } // Ganti dengan username Anda
            ]
          ]
        }
      });
      break;
      
    default:
      await ctx.answerCbQuery('❌ Action tidak dikenali!');
  }
  
  await ctx.answerCbQuery();
}

module.exports = {
  handleStart,
  handleHelp,
  handleCredit,
  handleShare,
  handleShareVip,
  handleAddPrem,
  handleDelPrem,
  handleListPrem,
  handleCallbackQuery
};