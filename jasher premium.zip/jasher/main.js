const { Telegraf } = require('telegraf');
const config = require('./config');
const { handleStart, handleHelp, handleCredit, handleShare, handleBroadcast, handleAddPrem, handleDelPrem, handleListPrem, handleShareVip } = require('./src/commands');
const { handleCallbackQuery, handleMessage } = require('./src/handlers');
const { initDatabase } = require('./lib/database');

// Inisialisasi bot
const bot = new Telegraf(config.BOT_TOKEN);

// Inisialisasi database
initDatabase();

// Middleware untuk menangani pengguna yang belum terdaftar
bot.use(async (ctx, next) => {
    const db = require('./lib/database');
    const userId = ctx.from?.id;
    
    if (userId && !db.getUser(userId)) {
        db.addUser(userId, ctx.from);
    }
    
    await next();
});

// Command handlers
bot.command('start', handleStart);
bot.command('help', handleHelp);
bot.command('credit', handleCredit);
bot.command('share', handleShare);
bot.command('broadcast', handleBroadcast);
bot.command('addprem', handleAddPrem);
bot.command('delprem', handleDelPrem);
bot.command('listprem', handleListPrem);
bot.command('sharevip', handleShareVip);

// Callback query handler
bot.on('callback_query', handleCallbackQuery);

// Message handler
bot.on('message', handleMessage);

// Error handling
bot.catch((err, ctx) => {
    console.error(`Error for ${ctx.updateType}:`, err);
    ctx.reply('Terjadi kesalahan pada bot. Silakan coba lagi nanti.');
});

// Jalankan bot
bot.launch().then(() => {
    console.log('Bot Jasher berhasil dijalankan!');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));