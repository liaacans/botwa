const { isPremium, isOwner, log, saveUsers, savePremiumUsers, saveGroups, saveBlacklistGroups, saveGroupSettings, uploadToUguu } = require('../lib/utils');
const { users, premiumUsers, groups, blacklistGroups, groupSettings, FREE_TRIAL_DAYS } = require('../lib/database');

// Handle new chat members
function handleNewChatMembers(bot) {
    bot.on('new_chat_members', async (ctx) => {
        const newMembers = ctx.message.new_chat_members;
        
        for (const member of newMembers) {
            if (member.is_bot && member.username === ctx.botInfo.username) {
                // Bot added to a group
                const groupId = ctx.chat.id.toString();
                
                if (blacklistGroups.has(groupId)) {
                    await ctx.reply('❌ Bot tidak dapat digunakan di grup ini (terblacklist).');
                    await ctx.leaveChat();
                    return;
                }
                
                groups.add(groupId);
                saveGroups(groups);
                
                await ctx.reply(`
🤖 Terima kasih telah menambahkan Jasher Bot ke grup ini!

⚙️ *Fitur yang tersedia:*
- 🔒 Obfuscation JavaScript
- 👥 Manajemen grup
- 📢 Sistem broadcast

🔧 *Setup Admin:*
Gunakan /settings untuk melihat pengaturan grup
Gunakan command admin untuk mengatur grup

📖 *Bantuan:*
Gunakan /help untuk bantuan penggunaan
Gunakan /menu untuk menu utama

👨‍💻 *Developer:* @ginaaforyou
                `, { parse_mode: 'Markdown' });
            }
        }
    });
}

// Handle left chat member
function handleLeftChatMember(bot) {
    bot.on('left_chat_member', async (ctx) => {
        const leftMember = ctx.message.left_chat_member;
        
        if (leftMember.is_bot && leftMember.username === ctx.botInfo.username) {
            // Bot removed from a group
            const groupId = ctx.chat.id.toString();
            
            if (groups.has(groupId)) {
                groups.delete(groupId);
                saveGroups(groups);
            }
            
            if (groupSettings.has(groupId)) {
                groupSettings.delete(groupId);
                saveGroupSettings(groupSettings);
            }
            
            log(`Bot removed from group: ${groupId}`);
        }
    });
}

// Handle message for group settings
function handleGroupMessages(bot) {
    bot.on('message', async (ctx) => {
        if (ctx.chat.type === 'private') return;
        
        const groupId = ctx.chat.id.toString();
        const settings = groupSettings.get(groupId) || {};
        
        // Check if group is blacklisted
        if (blacklistGroups.has(groupId)) {
            if (ctx.message.text && ctx.message.text.startsWith('/')) {
                await ctx.reply('❌ Bot tidak dapat digunakan di grup ini (terblacklist).');
            }
            return;
        }
        
        // Check no commands setting
        if (settings.nocommands && ctx.message.text && ctx.message.text.startsWith('/')) {
            try {
                await ctx.deleteMessage();
                await ctx.reply('❌ Penggunaan command tidak diizinkan di grup ini.');
            } catch (error) {
                console.log('Tidak dapat menghapus pesan command:', error.message);
            }
            return;
        }
        
        // Check anti-spam setting
        if (settings.antispam) {
            // Simple anti-spam logic - can be enhanced
            // This is a basic implementation
            const message = ctx.message.text || '';
            if (message.length > 500) {
                try {
                    await ctx.deleteMessage();
                    await ctx.reply('❌ Pesan terlalu panjang (anti-spam).');
                } catch (error) {
                    console.log('Tidak dapat menghapus pesan spam:', error.message);
                }
                return;
            }
        }
        
        // Check no links setting
        if (settings.nolinks) {
            const message = ctx.message.text || '';
            const urlRegex = /https?:\/\/[^\s]+/g;
            if (urlRegex.test(message)) {
                try {
                    await ctx.deleteMessage();
                    await ctx.reply('❌ Penggunaan link tidak diizinkan di grup ini.');
                } catch (error) {
                    console.log('Tidak dapat menghapus pesan dengan link:', error.message);
                }
                return;
            }
        }
        
        // Check no forwards setting
        if (settings.noforwards && ctx.message.forward_from) {
            try {
                await ctx.deleteMessage();
                await ctx.reply('❌ Forward pesan tidak diizinkan di grup ini.');
            } catch (error) {
                console.log('Tidak dapat menghapus pesan forward:', error.message);
            }
            return;
        }
        
        // Check no contacts setting
        if (settings.nocontacts && ctx.message.contact) {
            try {
                await ctx.deleteMessage();
                await ctx.reply('❌ Berbagi kontak tidak diizinkan di grup ini.');
            } catch (error) {
                console.log('Tidak dapat menghapus pesan kontak:', error.message);
            }
            return;
        }
        
        // Check no hashtags setting
        if (settings.nohastags) {
            const message = ctx.message.text || '';
            if (message.includes('#')) {
                try {
                    await ctx.deleteMessage();
                    await ctx.reply('❌ Penggunaan hashtag tidak diizinkan di grup ini.');
                } catch (error) {
                    console.log('Tidak dapat menghapus pesan dengan hashtag:', error.message);
                }
                return;
            }
        }
        
        // Check no event setting
        if (settings.noevent && ctx.message.new_chat_members) {
            try {
                await ctx.deleteMessage();
            } catch (error) {
                console.log('Tidak dapat menghapus pesan event:', error.message);
            }
            return;
        }
    });
}



module.exports = {
    handleNewChatMembers,
    handleLeftChatMember,
    handleGroupMessages
};