const { Telegraf } = require('telegraf');
const { connectDB } = require('./lib/database');
const { handleTextMessage } = require('./src/handlers');
const {
    handleStart,
    handleHelp,
    handleCredit,
    handleAddGroup,
    handleShare,
    handleShareVIP,
    handleBroadcast,
    handleAddPrem,
    handleDelPrem,
    handleListPrem
} = require('./src/commands');
const config = require('./config');

// Connect to database
connectDB();

// Initialize bot
const bot = new Telegraf(config.BOT_TOKEN);

// Register commands
bot.command('start', handleStart);
bot.command('help', handleHelp);
bot.command('credit', handleCredit);
bot.command('addgroup', handleAddGroup);
bot.command('share', handleShare);
bot.command('sharevip', handleShareVIP);
bot.command('broadcast', handleBroadcast);
bot.command('addprem', handleAddPrem);
bot.command('delprem', handleDelPrem);
bot.command('listprem', handleListPrem);

// Handle text messages
bot.on('text', handleTextMessage);

// Error handling
bot.catch((err, ctx) => {
    console.error(`Error for ${ctx.updateType}:`, err);
    ctx.reply('Terjadi kesalahan, silakan coba lagi.');
});

// Start bot
bot.launch().then(() => {
    console.log('Bot Jasher started successfully');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));