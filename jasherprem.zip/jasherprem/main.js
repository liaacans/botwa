const { Telegraf, Markup } = require('telegraf');
const fs = require('fs-extra');
const moment = require('moment-timezone');
require('./config');

// Import libraries
const { log, isPremium, isOwner } = require('./lib/utils');
const { addUser, getUser, addGroup, getGroup, removeGroup, isBlacklisted } = require('./lib/database');

const bot = new Telegraf(global.BOT_TOKEN);

// Import command handlers
const userCommands = require('./src/commands/userCommands');
const ownerCommands = require('./src/commands/ownerCommands');
const obfuscationCommands = require('./src/commands/obfuscation');
const groupCommands = require('./src/commands/groupCommands');

// Import handlers
const messageHandler = require('./src/handlers/messageHandler');
const callbackHandler = require('./src/handlers/callbackHandler');
const groupHandler = require('./src/handlers/groupHandler');
const authMiddleware = require('./src/middleware/authMiddleware');

// Register middleware dan handlers
authMiddleware(bot);
messageHandler(bot);
callbackHandler(bot);
groupHandler(bot);

// Middleware untuk logging dan blacklist
bot.use(async (ctx, next) => {
  if (ctx.from) {
    // Cek blacklist
    if (isBlacklisted(ctx.from.id)) {
      if (ctx.chat.type === 'private') {
        await ctx.reply('❌ Anda telah diblacklist dari menggunakan bot ini.');
      }
      return;
    }
    
    // Tambah user ke database
    addUser(ctx.from.id, {
      username: ctx.from.username,
      first_name: ctx.from.first_name,
      last_name: ctx.from.last_name
    });
    
    log(`Pesan dari: ${ctx.from.first_name} (${ctx.from.id}) di ${ctx.chat.type}`);
  }
  
  await next();
});

// Handle new group members
bot.on('new_chat_members', async (ctx) => {
  if (ctx.message.new_chat_members.some(member => member.id === ctx.botInfo.id)) {
    // Bot ditambahkan ke group
    const groupId = ctx.chat.id;
    const groupName = ctx.chat.title;
    
    addGroup(groupId, {
      title: groupName,
      username: ctx.chat.username,
      added_by: ctx.from.id
    });
    
    await ctx.reply(
      `🤖 Terima kasih telah menambahkan ${global.BOT_NAME} ke group ini!\n\n` +
      `Gunakan /menu untuk melihat fitur yang tersedia.`
    );
    
    log(`Bot ditambahkan ke group: ${groupName} (${groupId})`);
  }
});

// Handle bot removed from group
bot.on('left_chat_member', async (ctx) => {
  if (ctx.message.left_chat_member.id === ctx.botInfo.id) {
    const groupId = ctx.chat.id;
    removeGroup(groupId);
    log(`Bot dikeluarkan dari group: ${ctx.chat.title} (${groupId})`);
  }
});

// Register commands
userCommands(bot);
ownerCommands(bot);
obfuscationCommands(bot);
groupCommands(bot);

// Error handling
bot.catch((err, ctx) => {
  log('Error occurred:', err);
  ctx.reply('❌ Terjadi kesalahan internal. Silakan coba lagi nanti.');
});

// Start bot
bot.launch().then(() => {
  log(`Bot ${global.BOT_NAME} berhasil dijalankan!`);
  console.log('╔════════════════════════════════╗');
  console.log('║        JASHER BOT v3.0         ║');
  console.log('║     Premium Obfuscation Bot    ║');
  console.log('╚════════════════════════════════╝');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));