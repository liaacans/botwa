const { Telegraf } = require('telegraf');
const Imap = require('imap');
const { simpleParser } = require('mailparser');
const nodemailer = require('nodemailer');
const { inspect } = require('util');

// Konfigurasi Bot Telegram
const BOT_TOKEN = '7569137877:AAHnvva5p9SFclkDpDio8QcJsSfbzlrK6IY';
const ALLOWED_GROUP_ID = '-1002793801544';

// Konfigurasi Email
const EMAIL_CONFIG = {
  imap: {
    host: 'newpinwheel.indowebsite.net',
    port: 993,
    tls: true,
    user: 'nokosmerah@buatkamu.web.id',
    password: 'Grki6Vv1gdlA'
  },
  smtp: {
    host: 'newpinwheel.indowebsite.net',
    port: 587,
    secure: false,
    auth: {
      user: 'nokosmerah@buatkamu.web.id',
      pass: 'Grki6Vv1gdlA'
    }
  }
};

const bot = new Telegraf(BOT_TOKEN);
let imapConnection = null;
let processedEmails = new Set();

// Inisialisasi SMTP Transporter
const transporter = nodemailer.createTransport(EMAIL_CONFIG.smtp);

// Fungsi untuk menghubungkan ke IMAP
function connectIMAP() {
  imapConnection = new Imap(EMAIL_CONFIG.imap);

  imapConnection.once('ready', () => {
    console.log('Connected to IMAP server');
    openInbox();
  });

  imapConnection.once('error', (err) => {
    console.error('IMAP connection error:', err);
  });

  imapConnection.once('end', () => {
    console.log('IMAP connection ended');
    setTimeout(connectIMAP, 5000); // Reconnect after 5 seconds
  });

  imapConnection.connect();
}

// Fungsi untuk membuka inbox
function openInbox() {
  imapConnection.openBox('INBOX', true, (err, box) => {
    if (err) {
      console.error('Error opening inbox:', err);
      return;
    }
    console.log('Inbox opened successfully');
    fetchNewEmails();
    startListening();
  });
}

// Fungsi untuk mengambil email baru
function fetchNewEmails() {
  imapConnection.search(['UNSEEN'], (err, results) => {
    if (err) {
      console.error('Search error:', err);
      return;
    }

    if (results.length === 0) return;

    const fetch = imapConnection.fetch(results, {
      bodies: '',
      markSeen: true
    });

    fetch.on('message', (msg) => {
      msg.on('body', async (stream) => {
        try {
          const parsed = await simpleParser(stream);
          processNewEmail(parsed);
        } catch (error) {
          console.error('Error parsing email:', error);
        }
      });
    });

    fetch.once('error', (err) => {
      console.error('Fetch error:', err);
    });
  });
}

// Fungsi untuk memproses email baru
async function processNewEmail(email) {
  const messageId = email.messageId;
  
  // Cek apakah email sudah diproses sebelumnya
  if (processedEmails.has(messageId)) {
    return;
  }

  processedEmails.add(messageId);

  const emailContent = `
📧 *Email Baru*

*Dari:* ${email.from?.text || 'Unknown'}
*Kepada:* ${email.to?.text || 'Unknown'}
*Subjek:* ${email.subject || 'No Subject'}

*Isi:*
${email.text || 'Tidak ada konten teks'}

${email.html ? '*HTML content available*' : ''}
  `.trim();

  try {
    await bot.telegram.sendMessage(ALLOWED_GROUP_ID, emailContent, {
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: '📧 Balas Email',
              callback_data: `reply_${email.from?.value[0]?.address}`
            }
          ]
        ]
      }
    });
  } catch (error) {
    console.error('Error sending message to Telegram:', error);
  }
}

// Fungsi untuk mulai mendengarkan email baru
function startListening() {
  imapConnection.on('mail', () => {
    console.log('New email detected');
    fetchNewEmails();
  });
}

// Command: /sendmail
bot.command('sendmail', async (ctx) => {
  // Cek jika bukan di grup yang diizinkan
  if (ctx.chat.id.toString() !== ALLOWED_GROUP_ID) {
    await ctx.reply('❌ Bot hanya dapat digunakan di grup yang diizinkan');
    return;
  }

  const args = ctx.message.text.split(' ').slice(1);
  if (args.length < 2) {
    await ctx.reply('Format: /sendmail <email_tujuan> <subjek> <isi_pesan>\nContoh: /sendmail example@email.com "Test Subject" "Isi pesan"');
    return;
  }

  const toEmail = args[0];
  const subject = args[1];
  const text = args.slice(2).join(' ');

  try {
    await transporter.sendMail({
      from: EMAIL_CONFIG.imap.user,
      to: toEmail,
      subject: subject,
      text: text
    });

    await ctx.reply(`✅ Email berhasil dikirim ke ${toEmail}`);
  } catch (error) {
    console.error('Error sending email:', error);
    await ctx.reply('❌ Gagal mengirim email');
  }
});

// Handle callback query untuk membalas email
bot.action(/reply_(.+)/, async (ctx) => {
  const email = ctx.match[1];
  
  await ctx.reply(`Silakan ketik balasan untuk ${email}:\nFormat: <isi_balasan>`);
  
  // Simpan state untuk menunggu balasan
  ctx.session = { waitingForReply: true, replyTo: email };
});

// Handle pesan balasan
bot.on('text', async (ctx) => {
  if (ctx.session?.waitingForReply) {
    const email = ctx.session.replyTo;
    const text = ctx.message.text;

    try {
      await transporter.sendMail({
        from: EMAIL_CONFIG.imap.user,
        to: email,
        subject: 'Re: Balasan dari Telegram Bot',
        text: text
      });

      await ctx.reply(`✅ Balasan berhasil dikirim ke ${email}`);
      
      // Reset state
      ctx.session = {};
    } catch (error) {
      console.error('Error sending reply:', error);
      await ctx.reply('❌ Gagal mengirim balasan');
    }
  }
});

// Handle ketika bot ditambahkan ke grup
bot.on('chat_member', async (ctx) => {
  const chatMember = ctx.chatMember;
  
  if (chatMember.new_chat_member.status === 'member' && 
      chatMember.new_chat_member.user.id === ctx.botInfo.id) {
    
    if (ctx.chat.id.toString() !== ALLOWED_GROUP_ID) {
      await ctx.leaveChat();
      console.log(`Left unauthorized group: ${ctx.chat.id}`);
    }
  }
});

// Middleware untuk memeriksa grup yang diizinkan
bot.use(async (ctx, next) => {
  if (ctx.chat && ctx.chat.type === 'group' || ctx.chat.type === 'supergroup') {
    if (ctx.chat.id.toString() !== ALLOWED_GROUP_ID) {
      if (ctx.message && ctx.message.text && ctx.message.text.startsWith('/')) {
        await ctx.reply('❌ Bot tidak diizinkan di grup ini');
      }
      return;
    }
  }
  await next();
});

// Start bot dan koneksi IMAP
async function startBot() {
  try {
    await bot.launch();
    console.log('Bot started successfully');
    
    connectIMAP();
    
    // Graceful shutdown
    process.once('SIGINT', () => {
      bot.stop('SIGINT');
      if (imapConnection) imapConnection.end();
    });
    process.once('SIGTERM', () => {
      bot.stop('SIGTERM');
      if (imapConnection) imapConnection.end();
    });
  } catch (error) {
    console.error('Error starting bot:', error);
  }
}

startBot();