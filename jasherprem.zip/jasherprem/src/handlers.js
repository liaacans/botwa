const { Markup } = require('telegraf');
const { User, Group } = require('../lib/database');
const { OWNER_ID } = require('../config');

// Handler untuk callback queries
module.exports = (bot) => {
  // Handler untuk callback query: jasher_menu
  bot.action('jasher_menu', async (ctx) => {
    try {
      const isCreator = ctx.from.id.toString() === OWNER_ID;
      
      const menuText = `
╭─❒ 「 Jasher Menu 」 
├ /start - Memulai bot
├ /buyprem - Beli premium
├ /buycmd - Beli command custom
├ /sharefree - Share gratis (perlu 3 group)
├ /sharevip - Share premium
├ /tourl - Upload file ke URL
╰❒
Status Premium: ${ctx.isPremium ? 'Aktif' : 'Tidak Aktif'}`;

      const menuButtons = Markup.inlineKeyboard([
        [Markup.button.callback('Kembali', 'back_menu')]
      ]);

      await ctx.editMessageCaption(menuText, {
        parse_mode: 'Markdown',
        ...menuButtons
      });
    } catch (error) {
      console.error('Jasher Menu Error:', error);
      await ctx.answerCbQuery('❌ Terjadi kesalahan!');
    }
  });

  // Handler untuk callback query: owner_menu
  bot.action('owner_menu', async (ctx) => {
    try {
      const isCreator = ctx.from.id.toString() === OWNER_ID;
      
      if (!isCreator) {
        await ctx.answerCbQuery('❌ Hanya owner yang dapat mengakses menu ini!');
        return;
      }
      
      const menuText = `
╭─❒ 「 Owner Menu 」 
├ /addprem - Tambah premium user
├ /delprem - Hapus premium user
├ /listprem - List user premium
├ /addbl - Blacklist group
├ /delbl - Hapus blacklist group
├ /listbl - List blacklist
├ /listgrup - List grup aktif
├ /bc - Broadcast ke semua user
╰❒
Hanya untuk owner bot!`;

      const menuButtons = Markup.inlineKeyboard([
        [Markup.button.callback('Kembali', 'back_menu')]
      ]);

      await ctx.editMessageCaption(menuText, {
        parse_mode: 'Markdown',
        ...menuButtons
      });
    } catch (error) {
      console.error('Owner Menu Error:', error);
      await ctx.answerCbQuery('❌ Terjadi kesalahan!');
    }
  });

  // Handler untuk callback query: obf_menu
  bot.action('obf_menu', async (ctx) => {
    try {
      const menuText = `
╭─❒ 「 Obfuscation Menu 」 
├ /enc3 - Mandarin Obfuscation
├ /enc4 - Arab Obfuscation
├ /japan - Japan Obfuscation
├ /zenc - Invisible Obfuscation
├ /xx - Custom Name Obfuscation
├ /quantum - Quantum Obfuscation
├ /var - Var Obfuscation
├ /nebula - Nebula Obfuscation
├ /enc5 - Siu+Calcrick Obfuscation
├ /enc2 - Custom Text Obfuscation
├ /enc - Time-Locked Obfuscation
╰❒
Balas file .js dengan command di atas!`;

      const menuButtons = Markup.inlineKeyboard([
        [Markup.button.callback('Kembali', 'back_menu')]
      ]);

      await ctx.editMessageCaption(menuText, {
        parse_mode: 'Markdown',
        ...menuButtons
      });
    } catch (error) {
      console.error('Obf Menu Error:', error);
      await ctx.answerCbQuery('❌ Terjadi kesalahan!');
    }
  });

  // Handler untuk callback query: back_menu
  bot.action('back_menu', async (ctx) => {
    try {
      const isCreator = ctx.from.id.toString() === OWNER_ID;
      const sender = ctx.from.username || ctx.from.first_name;
      
      const menuText = `
╭─❒ 「 User Info 」 
├ Owner : ${isCreator ? 'True' : 'False'}
├ Name : ${ctx.from.first_name} ${ctx.from.last_name || ''}
├ Profile : @${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${require('../lib/utils').runtime(process.uptime())}
├ Tanggal Server : ${require('moment-timezone')().tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${require('moment-timezone')().tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`;

      const menuButtons = Markup.inlineKeyboard([
        [
          Markup.button.callback('Jasher Menu', 'jasher_menu'),
          Markup.button.callback('Owner Menu', 'owner_menu')
        ],
        [
          Markup.button.callback('Obf Menu', 'obf_menu'),
          Markup.button.callback('Kembali', 'back_menu')
        ]
      ]);

      await ctx.editMessageCaption(menuText, {
        parse_mode: 'Markdown',
        ...menuButtons
      });
    } catch (error) {
      console.error('Back Menu Error:', error);
      await ctx.answerCbQuery('❌ Terjadi kesalahan!');
    }
  });

  // Handler untuk new chat members (bot ditambahkan ke group)
  bot.on('new_chat_members', async (ctx) => {
    try {
      const newMembers = ctx.message.new_chat_members;
      
      // Cek jika bot yang ditambahkan
      const botMember = newMembers.find(member => member.is_bot && member.username === ctx.botInfo.username);
      if (botMember) {
        const groupId = ctx.chat.id;
        const groupTitle = ctx.chat.title;
        const groupUsername = ctx.chat.username || '';
        
        // Simpan group ke database
        let group = await Group.findOne({ groupId });
        if (!group) {
          group = new Group({
            groupId,
            title: groupTitle,
            username: groupUsername,
            addedBy: ctx.from.id
          });
          await group.save();
        } else {
          group.isActive = true;
          await group.save();
        }
        
        // Tambahkan group ke daftar joinedGroups user yang menambahkan
        const user = await User.findOne({ userId: ctx.from.id });
        if (user && !user.joinedGroups.includes(groupId)) {
          user.joinedGroups.push(groupId);
          await user.save();
        }
        
        await ctx.reply(
          `✅ Terima kasih telah menambahkan saya ke group ini!\n` +
          `📊 Group ini adalah group ke-${user ? user.joinedGroups.length : 1} yang Anda tambahkan.\n` +
          `🔓 Untuk menggunakan fitur share, Anda perlu menambahkan bot ke 3 group.`
        );
      }
    } catch (error) {
      console.error('New Chat Members Error:', error);
    }
  });

  // Handler untuk left chat member (bot dikick dari group)
  bot.on('left_chat_member', async (ctx) => {
    try {
      const leftMember = ctx.message.left_chat_member;
      
      // Cek jika bot yang dikick
      if (leftMember.is_bot && leftMember.username === ctx.botInfo.username) {
        const groupId = ctx.chat.id;
        
        // Update status group menjadi tidak aktif
        await Group.updateOne({ groupId }, { isActive: false });
        
        // Hapus group dari daftar joinedGroups semua user
        await User.updateMany(
          { joinedGroups: groupId },
          { $pull: { joinedGroups: groupId } }
        );
      }
    } catch (error) {
      console.error('Left Chat Member Error:', error);
    }
  });

  // Handler untuk pesan yang dihapus (menghandle blacklist group)
  bot.on('message', async (ctx, next) => {
    try {
      // Cek jika pesan dari group yang diblacklist
      if (ctx.chat && ctx.chat.type.includes('group')) {
        const blacklist = await require('../lib/database').Blacklist.findOne({ groupId: ctx.chat.id });
        if (blacklist) {
          // Hapus pesan yang dikirim di group yang diblacklist
          try {
            await ctx.deleteMessage();
          } catch (error) {
            console.log('Tidak dapat menghapus pesan di group yang diblacklist:', error);
          }
          return; // Jangan proses pesan lebih lanjut
        }
      }
      
      await next();
    } catch (error) {
      console.error('Message Handler Error:', error);
      await next();
    }
  });
};