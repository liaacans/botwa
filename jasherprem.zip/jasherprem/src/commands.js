const { Markup } = require('telegraf');
const { User, Group, Broadcast } = require('../lib/database');
const { runtime, formatCredit, escapeMarkdown, moment } = require('./utils');
const { OWNER_ID } = require('../config');

async function handleStart(ctx) {
    const sender = ctx.from;
    const userTelelu = ctx.botInfo.username;
    const isCreator = sender.id.toString() === OWNER_ID;
    
    try {
        let user = await User.findOne({ userId: sender.id });
        if (!user) {
            user = new User({
                userId: sender.id,
                username: sender.username,
                firstName: sender.first_name,
                lastName: sender.last_name,
                isCreator: isCreator
            });
            await user.save();
        }
        
        const menuText = `Hi kak @${sender.username || sender.first_name}
╭─❒ 「 User Info 」 
├ Creator : @${userTelelu}
├ Name : ${escapeMarkdown(sender.first_name)} ${sender.last_name ? escapeMarkdown(sender.last_name) : ''}
├ Username : @${sender.username || 'Tidak ada'}
├ ID Telegram Anda: ${sender.id}
├ Hostname : Linux
├ Platform : Bot Telegram
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
├ Credit : ${formatCredit(user.credit)}
╰❒ Owner : ${isCreator ? 'True' : 'False'}

Silahkan pilih menu dibawah ini!`;

        const buttons = Markup.inlineKeyboard([
            [
                Markup.button.callback('🎯 Jasher Menu', 'jasher_menu'),
                Markup.button.callback('👤 Owner Menu', 'owner_menu')
            ],
            [
                Markup.button.callback('➕ AddGroup', 'add_group'),
                Markup.button.callback('🔙 Kembali', 'main_menu')
            ]
        ]);

        if (ctx.message) {
            await ctx.replyWithMarkdownV2(menuText, buttons);
        } else {
            await ctx.editMessageText(menuText, { 
                ...buttons,
                parse_mode: 'MarkdownV2'
            });
        }
    } catch (error) {
        console.error('Error in start command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleHelp(ctx) {
    const helpText = `*🤖 BOT JASHER HELP*

*📋 DAFTAR PERINTAH:*
/start - Memulai bot
/help - Menampilkan bantuan
/credit - Cek credit Anda
/share - Share pesan (Private chat only)

*🎯 FITUR:*
- Tambah credit dengan add group
- Share pesan ke banyak group
- Premium features untuk user VIP

*💡 CATATAN:*
- Untuk share, harus di private chat
- Tambah 3 group untuk dapat 10 credit
- Share mengurangi 2 credit per pesan
- ShareVIP lebih cepat untuk user premium`;

    await ctx.replyWithMarkdownV2(helpText);
}

async function handleCredit(ctx) {
    try {
        const user = await User.findOne({ userId: ctx.from.id });
        if (!user) {
            return ctx.reply('Anda belum terdaftar. Ketik /start untuk memulai.');
        }
        
        const creditText = `*💳 CREDIT INFO*

👤 *Nama:* ${escapeMarkdown(ctx.from.first_name)} ${ctx.from.last_name ? escapeMarkdown(ctx.from.last_name) : ''}
🆔 *ID:* ${ctx.from.id}
💎 *Credit:* ${formatCredit(user.credit)}
⭐ *Status:* ${user.isPremium ? 'Premium' : 'Regular'}

${user.credit < 2 ? '❌ Credit tidak cukup untuk share! Tambah group dulu.' : '✅ Credit cukup untuk share.'}`;

        await ctx.replyWithMarkdownV2(creditText);
    } catch (error) {
        console.error('Error in credit command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleShare(ctx) {
    if (ctx.chat.type !== 'private') {
        return ctx.reply('❌ Perintah /share hanya bisa digunakan di private chat!');
    }
    
    try {
        const user = await User.findOne({ userId: ctx.from.id });
        if (!user) {
            return ctx.reply('Anda belum terdaftar. Ketik /start untuk memulai.');
        }
        
        if (user.credit < 2) {
            return ctx.reply('❌ Credit Anda tidak cukup! Minimal 2 credit untuk share. Tambah group dulu dengan /addgroup.');
        }
        
        let messageText = '';
        if (ctx.message.reply_to_message) {
            const repliedMessage = ctx.message.reply_to_message;
            if (repliedMessage.text) {
                messageText = repliedMessage.text;
            } else if (repliedMessage.caption) {
                messageText = repliedMessage.caption;
            } else {
                return ctx.reply('❌ Hanya bisa membalas pesan teks!');
            }
        } else if (ctx.message.text && ctx.message.text.split(' ').length > 1) {
            messageText = ctx.message.text.split(' ').slice(1).join(' ');
        } else {
            return ctx.reply('❌ Gunakan format: /share [teks] atau balas pesan dengan /share');
        }
        
        if (messageText.length === 0) {
            return ctx.reply('❌ Teks tidak boleh kosong!');
        }
        
        // Simpan broadcast
        const broadcast = new Broadcast({
            messageId: Date.now(),
            senderId: ctx.from.id,
            messageText: messageText
        });
        await broadcast.save();
        
        // Kurangi credit
        user.credit -= 2;
        await user.save();
        
        // Broadcast ke groups
        const groups = await Group.find();
        let successCount = 0;
        
        for (const group of groups) {
            try {
                await ctx.telegram.sendMessage(group.groupId, messageText);
                successCount++;
            } catch (error) {
                console.error(`Error sending to group ${group.groupId}:`, error.message);
            }
        }
        
        await ctx.reply(`✅ Broadcast berhasil dikirim ke ${successCount} group!\n💎 Credit berkurang 2, sisa: ${formatCredit(user.credit)}`);
    } catch (error) {
        console.error('Error in share command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleAddPrem(ctx) {
    if (ctx.from.id.toString() !== OWNER_ID) {
        return ctx.reply('❌ Hanya owner yang bisa menggunakan perintah ini!');
    }
    
    const args = ctx.message.text.split(' ');
    if (args.length < 2) {
        return ctx.reply('❌ Format: /addprem [user_id]');
    }
    
    const userId = parseInt(args[1]);
    if (isNaN(userId)) {
        return ctx.reply('❌ User ID harus angka!');
    }
    
    try {
        let user = await User.findOne({ userId: userId });
        if (!user) {
            // Coba dapatkan info user dari Telegram
            try {
                const userInfo = await ctx.telegram.getChat(userId);
                user = new User({
                    userId: userId,
                    username: userInfo.username,
                    firstName: userInfo.first_name,
                    lastName: userInfo.last_name,
                    isPremium: true,
                    credit: user.credit + 100 // Bonus credit untuk premium
                });
            } catch (error) {
                return ctx.reply('❌ User tidak ditemukan! Pastikan bot sudah berinteraksi dengan user tersebut.');
            }
        } else {
            user.isPremium = true;
            user.credit += 100; // Bonus credit untuk premium
        }
        
        await user.save();
        await ctx.reply(`✅ User ${userId} berhasil dijadikan premium dan mendapat 100 credit bonus!`);
    } catch (error) {
        console.error('Error in addprem command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleDelPrem(ctx) {
    if (ctx.from.id.toString() !== OWNER_ID) {
        return ctx.reply('❌ Hanya owner yang bisa menggunakan perintah ini!');
    }
    
    const args = ctx.message.text.split(' ');
    if (args.length < 2) {
        return ctx.reply('❌ Format: /delprem [user_id]');
    }
    
    const userId = parseInt(args[1]);
    if (isNaN(userId)) {
        return ctx.reply('❌ User ID harus angka!');
    }
    
    try {
        const user = await User.findOne({ userId: userId });
        if (!user) {
            return ctx.reply('❌ User tidak ditemukan!');
        }
        
        user.isPremium = false;
        await user.save();
        await ctx.reply(`✅ User ${userId} berhasil dihapus dari premium!`);
    } catch (error) {
        console.error('Error in delprem command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleListPrem(ctx) {
    if (ctx.from.id.toString() !== OWNER_ID) {
        return ctx.reply('❌ Hanya owner yang bisa menggunakan perintah ini!');
    }
    
    try {
        const premiumUsers = await User.find({ isPremium: true });
        if (premiumUsers.length === 0) {
            return ctx.reply('❌ Tidak ada user premium!');
        }
        
        let listText = '*📋 DAFTAR USER PREMIUM*\n\n';
        premiumUsers.forEach((user, index) => {
            listText += `${index + 1}. ${user.firstName} ${user.lastName || ''} (@${user.username || 'no_username'}) - ID: ${user.userId}\n`;
        });
        
        await ctx.replyWithMarkdownV2(escapeMarkdown(listText));
    } catch (error) {
        console.error('Error in listprem command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleBroadcast(ctx) {
    if (ctx.from.id.toString() !== OWNER_ID) {
        return ctx.reply('❌ Hanya owner yang bisa menggunakan perintah ini!');
    }
    
    if (!ctx.message.reply_to_message) {
        return ctx.reply('❌ Balas pesan yang ingin di-broadcast dengan perintah /broadcast');
    }
    
    const repliedMessage = ctx.message.reply_to_message;
    let messageText = '';
    
    if (repliedMessage.text) {
        messageText = repliedMessage.text;
    } else if (repliedMessage.caption) {
        messageText = repliedMessage.caption;
    } else {
        return ctx.reply('❌ Hanya bisa membroadcast pesan teks!');
    }
    
    try {
        const allUsers = await User.find();
        let successCount = 0;
        
        for (const user of allUsers) {
            try {
                await ctx.telegram.sendMessage(user.userId, `📢 *BROADCAST FROM OWNER*\n\n${messageText}`, { 
                    parse_mode: 'MarkdownV2',
                    disable_web_page_preview: true 
                });
                successCount++;
            } catch (error) {
                console.error(`Error sending to user ${user.userId}:`, error.message);
            }
        }
        
        await ctx.reply(`✅ Broadcast berhasil dikirim ke ${successCount} user!`);
    } catch (error) {
        console.error('Error in broadcast command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

module.exports = {
    handleStart,
    handleHelp,
    handleCredit,
    handleShare,
    handleAddPrem,
    handleDelPrem,
    handleListPrem,
    handleBroadcast
};