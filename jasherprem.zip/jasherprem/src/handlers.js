const { Markup } = require('telegraf');
const { User, Group } = require('../lib/database');
const { formatUserInfo } = require('./utils');
const config = require('../config');

async function handleCallbackQuery(ctx) {
  const data = ctx.callbackQuery.data;
  const userId = ctx.from.id;
  const isCreator = userId.toString() === config.CREATOR_ID;
  
  try {
    switch (data) {
      case 'jasher_menu':
        {
          const user = await User.findOne({ userId });
          const message = `
<b>Jasher Menu</b>

Kredit: ${user.credit}
Status: ${user.isPremium ? 'Premium' : 'Regular'}

Fitur:
- Share pesan ke semua grup (${config.SHARE_COST} kredit)
- ShareVIP pesan ke semua grup (${config.SHAREVIP_COST} kredit, hanya premium)

Tambahkan bot ke 3 grup untuk mendapatkan 10 kredit!
          `;
          
          const buttons = Markup.inlineKeyboard([
            [Markup.button.callback('Credit', 'show_credit')],
            [Markup.button.callback('Share', 'share_message')],
            [Markup.button.callback('ShareVIP', 'sharevip_message')],
            [Markup.button.callback('Kembali', 'back_main')]
          ]);
          
          await ctx.editMessageText(message, { 
            parse_mode: 'HTML', 
            ...buttons 
          });
        }
        break;
        
      case 'owner_menu':
        if (!isCreator) {
          await ctx.answerCbQuery('Hanya owner yang dapat mengakses menu ini!');
          return;
        }
        
        {
          const message = `
<b>Owner Menu</b>

Fitur khusus owner:
- Add premium user
- Remove premium user
- List premium users
- Broadcast ke semua user
          `;
          
          const buttons = Markup.inlineKeyboard([
            [Markup.button.callback('Add Premium', 'add_premium')],
            [Markup.button.callback('Remove Premium', 'remove_premium')],
            [Markup.button.callback('List Premium', 'list_premium')],
            [Markup.button.callback('Broadcast', 'broadcast_message')],
            [Markup.button.callback('Kembali', 'back_main')]
          ]);
          
          await ctx.editMessageText(message, { 
            parse_mode: 'HTML', 
            ...buttons 
          });
        }
        break;
        
      case 'back_main':
        {
          const user = await User.findOne({ userId });
          const message = formatUserInfo(ctx, user, isCreator);
          
          const buttons = Markup.inlineKeyboard([
            [Markup.button.callback('Jasher Menu', 'jasher_menu')],
            [Markup.button.callback('Owner Menu', 'owner_menu')],
            [Markup.button.callback('Kembali', 'back_main')],
            [Markup.button.callback('AddGroup', 'add_group')],
            [Markup.button.callback('Owner', 'show_owner')]
          ]);
          
          await ctx.editMessageText(message, { 
            parse_mode: 'HTML', 
            ...buttons 
          });
        }
        break;
        
      case 'add_group':
        await ctx.answerCbQuery('Tambahkan bot ke grup Anda dan promosikan jasher group!');
        break;
        
      case 'show_owner':
        await ctx.answerCbQuery(`Owner bot: @${config.CHANNEL_USERNAME}`);
        break;
        
      case 'show_credit':
        {
          const user = await User.findOne({ userId });
          await ctx.answerCbQuery(`Kredit Anda: ${user.credit}`);
        }
        break;
        
      case 'share_message':
        await ctx.answerCbQuery('Gunakan perintah /share di chat private untuk membagikan pesan');
        break;
        
      case 'sharevip_message':
        await ctx.answerCbQuery('Gunakan perintah /sharevip di chat private untuk membagikan pesan VIP');
        break;
        
      case 'add_premium':
        if (!isCreator) {
          await ctx.answerCbQuery('Hanya owner yang dapat menggunakan fitur ini!');
          return;
        }
        await ctx.answerCbQuery('Gunakan perintah /addprem <user_id>');
        break;
        
      case 'remove_premium':
        if (!isCreator) {
          await ctx.answerCbQuery('Hanya owner yang dapat menggunakan fitur ini!');
          return;
        }
        await ctx.answerCbQuery('Gunakan perintah /delprem <user_id>');
        break;
        
      case 'list_premium':
        if (!isCreator) {
          await ctx.answerCbQuery('Hanya owner yang dapat menggunakan fitur ini!');
          return;
        }
        await ctx.answerCbQuery('Gunakan perintah /listprem');
        break;
        
      case 'broadcast_message':
        if (!isCreator) {
          await ctx.answerCbQuery('Hanya owner yang dapat menggunakan fitur ini!');
          return;
        }
        await ctx.answerCbQuery('Balas pesan dengan perintah /broadcast untuk mengirim ke semua user');
        break;
        
      default:
        await ctx.answerCbQuery('Perintah tidak dikenali');
    }
  } catch (error) {
    console.error('Error in handleCallbackQuery:', error);
    await ctx.answerCbQuery('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleNewChatMembers(ctx) {
  try {
    // Cek jika bot yang ditambahkan ke grup
    if (ctx.message.new_chat_members.some(member => member.is_bot && member.id === ctx.botInfo.id)) {
      const groupId = ctx.chat.id;
      const groupTitle = ctx.chat.title;
      const groupUsername = ctx.chat.username;
      const addedBy = ctx.from.id;
      
      // Cek jika grup sudah ada di database
      const existingGroup = await Group.findOne({ groupId });
      if (!existingGroup) {
        const newGroup = new Group({
          groupId,
          title: groupTitle,
          username: groupUsername,
          addedBy
        });
        await newGroup.save();
      }
      
      // Beri kredit kepada user yang menambahkan bot
      if (addedBy) {
        const user = await User.findOne({ userId: addedBy });
        if (user) {
          // Cek berapa banyak grup yang sudah user tambahkan
          if (!user.joinedGroups.includes(groupId)) {
            user.joinedGroups.push(groupId);
            
            // Jika sudah menambahkan 3 grup, beri 10 kredit
            if (user.joinedGroups.length >= config.MIN_GROUPS) {
              user.credit += 10;
              await ctx.telegram.sendMessage(addedBy, `Terima kasih! Anda telah menambahkan bot ke ${user.joinedGroups.length} grup. Anda mendapatkan 10 kredit! Total kredit: ${user.credit}`);
            }
            
            await user.save();
          }
        }
      }
      
      await ctx.reply('Terima kasih telah menambahkan Jasher Bot ke grup ini!');
    }
  } catch (error) {
    console.error('Error in handleNewChatMembers:', error);
  }
}

module.exports = { handleCallbackQuery, handleNewChatMembers };