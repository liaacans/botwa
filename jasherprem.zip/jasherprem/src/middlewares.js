const { User, Blacklist, Group } = require('../lib/database');
const { Markup } = require('telegraf');

// Middleware untuk mengecek apakah user terdaftar
async function userMiddleware(ctx, next) {
  try {
    const userId = ctx.from.id;
    
    // Cek blacklist
    const isBlacklisted = await Blacklist.findOne({ userId });
    if (isBlacklisted) {
      return ctx.reply('❌ Anda telah diblacklist dan tidak dapat menggunakan bot ini.');
    }
    
    // Cek atau buat user
    let user = await User.findOne({ userId });
    if (!user) {
      user = new User({
        userId,
        username: ctx.from.username,
        firstName: ctx.from.first_name,
        lastName: ctx.from.last_name,
        referralCode: require('../lib/utils').generateReferralCode()
      });
      await user.save();
    }
    
    ctx.user = user;
    return next();
  } catch (error) {
    console.error('User middleware error:', error);
    return ctx.reply('❌ Terjadi kesalahan, silakan coba lagi.');
  }
}

// Middleware untuk mengecek apakah user premium
async function premiumMiddleware(ctx, next) {
  try {
    const user = ctx.user;
    const now = new Date();
    
    if (user.isPremium && user.premiumUntil && user.premiumUntil > now) {
      return next();
    } else {
      // Reset status premium jika sudah kedaluwarsa
      if (user.isPremium) {
        user.isPremium = false;
        user.premiumUntil = null;
        await user.save();
      }
      
      return ctx.reply('❌ Fitur ini hanya untuk user premium. Gunakan /buyprem untuk membeli premium.');
    }
  } catch (error) {
    console.error('Premium middleware error:', error);
    return ctx.reply('❌ Terjadi kesalahan, silakan coba lagi.');
  }
}

// Middleware untuk mengecek apakah user adalah owner
function ownerMiddleware(ctx, next) {
  const { OWNER_ID } = require('../config');
  
  if (ctx.from.id.toString() === OWNER_ID) {
    return next();
  } else {
    return ctx.reply('❌ Perintah ini hanya untuk owner bot.');
  }
}

// Middleware untuk mengecek apakah di group
function groupMiddleware(ctx, next) {
  if (ctx.chat.type === 'group' || ctx.chat.type === 'supergroup') {
    return next();
  } else {
    return ctx.reply('❌ Perintah ini hanya bisa digunakan di grup.');
  }
}

// Middleware untuk mengecek apakah di private chat
function privateMiddleware(ctx, next) {
  if (ctx.chat.type === 'private') {
    return next();
  } else {
    return ctx.reply('❌ Perintah ini hanya bisa digunakan di chat private.');
  }
}

// Middleware untuk mengecek apakah admin group
async function adminMiddleware(ctx, next) {
  try {
    if (ctx.chat.type === 'private') {
      return ctx.reply('❌ Perintah ini hanya bisa digunakan di grup.');
    }
    
    const chatMember = await ctx.getChatMember(ctx.from.id);
    if (chatMember.status === 'administrator' || chatMember.status === 'creator') {
      return next();
    } else {
      return ctx.reply('❌ Perintah ini hanya untuk admin grup.');
    }
  } catch (error) {
    console.error('Admin middleware error:', error);
    return ctx.reply('❌ Terjadi kesalahan, silakan coba lagi.');
  }
}

module.exports = {
  userMiddleware,
  premiumMiddleware,
  ownerMiddleware,
  groupMiddleware,
  privateMiddleware,
  adminMiddleware
};