const { Telegraf, session } = require('telegraf');
const db = require('./lib/database');
const commands = require('./src/commands');
const handlers = require('./src/handlers');

// Load config
require('./config');

const bot = new Telegraf(global.BOT_TOKEN);

// Middleware
bot.use(session());
bot.use(async (ctx, next) => {
  // Simpan user data di context
  if (ctx.from) {
    ctx.userData = await db.getUser(ctx.from.id);
  }
  return next();
});

// Command handlers
bot.start(commands.handleStart);
bot.help(commands.handleHelp);
bot.command('credit', commands.handleCredit);
bot.command('share', commands.handleShare);
bot.command('sharevip', commands.handleShareVip);
bot.command('addprem', commands.handleAddPrem);
bot.command('delprem', commands.handleDelPrem);
bot.command('listprem', commands.handleListPrem);
bot.command('broadcast', commands.handleBroadcast);

// Callback query handler
bot.on('callback_query', handlers.handleCallbackQuery);

// Error handling
bot.catch((err, ctx) => {
  console.error(`Error for ${ctx.updateType}:`, err);
  ctx.reply('❌ Terjadi kesalahan. Silakan coba lagi.');
});

// Initialize and start bot
async function startBot() {
  try {
    await db.connect();
    console.log('Database connected');
    
    await bot.launch();
    console.log('Bot started');
  } catch (error) {
    console.error('Failed to start bot:', error);
    process.exit(1);
  }
}

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));

startBot();