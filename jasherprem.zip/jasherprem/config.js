global.BOT_TOKEN = "8198305874:AAGdj8p_m2anVPF0PpqEHQzGs4k2AQ2V3_c";
global.DEVELOPER_ID = "8135269613";
global.DEVELOPER_USERNAME = "@ginaabaikhati";

// Database configuration
global.db = require('./lib/database');

// Other global variables
global.groupRequirements = 3;
global.premiumDaysPerGroup = 3;