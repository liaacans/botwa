const { Markup } = require('telegraf');
const { User } = require('../lib/database');
const { formatUserInfo } = require('./utils');
const { 
    handleStart, 
    handleHelp, 
    handleCredit, 
    handleShare, 
    handleShareVip,
    handleAddPrem,
    handleDelPrem,
    handleListPrem
} = require('./commands');

async function handleCallbackQuery(ctx) {
    const data = ctx.callbackQuery.data;
    
    try {
        switch (data) {
            case 'main_menu':
                await handleStart(ctx);
                break;
                
            case 'jasher_menu':
                await handleJasherMenu(ctx);
                break;
                
            case 'owner_menu':
                await handleOwnerMenu(ctx);
                break;
                
            case 'owner_info':
                await handleOwnerInfo(ctx);
                break;
                
            case 'credit_info':
                await handleCredit(ctx);
                break;
                
            default:
                await ctx.answerCbQuery('Menu tidak dikenali!');
                break;
        }
    } catch (error) {
        console.error('Error handling callback query:', error);
        await ctx.answerCbQuery('Terjadi kesalahan!');
    }
}

async function handleJasherMenu(ctx) {
    const menuText = `
🤖 <b>Jasher Menu</b>

Pilih opsi di bawah ini:

💳 /credit - Lihat credit Anda
📤 /share - Share broadcast (2 credit)
🚀 /sharevip - Share broadcast VIP (1 credit, premium only)
❓ /help - Bantuan

Anda juga bisa langsung menggunakan command di atas.
    `;
    
    const buttons = Markup.inlineKeyboard([
        [Markup.button.callback('Credit Info', 'credit_info')],
        [Markup.button.callback('Kembali', 'main_menu')]
    ]);
    
    await ctx.editMessageCaption(menuText, {
        parse_mode: 'HTML',
        ...buttons
    });
}

async function handleOwnerMenu(ctx) {
    // Cek jika pengguna adalah admin
    if (ctx.from.id.toString() !== process.env.ADMIN_ID) {
        await ctx.answerCbQuery('Anda bukan owner!');
        return;
    }
    
    const menuText = `
👑 <b>Owner Menu</b>

Command yang tersedia:

➕ /addprem <user_id> - Tambah user premium
➖ /delprem <user_id> - Hapus user premium
📋 /listprem - List user premium
📢 /broadcast - Broadcast ke semua user

Gunakan command di atas langsung di chat.
    `;
    
    const buttons = Markup.inlineKeyboard([
        [Markup.button.callback('Kembali', 'main_menu')]
    ]);
    
    await ctx.editMessageCaption(menuText, {
        parse_mode: 'HTML',
        ...buttons
    });
}

async function handleOwnerInfo(ctx) {
    const ownerInfo = `
👑 <b>Owner Information</b>

Nama: Your Name
Username: @tiaaxl
ID: ${process.env.ADMIN_ID}

Hubungi owner untuk pertanyaan atau kerja sama.
    `;
    
    const buttons = Markup.inlineKeyboard([
        [Markup.button.url('Hubungi Owner', 'https://t.me/tiaaxl')],
        [Markup.button.callback('Kembali', 'main_menu')]
    ]);
    
    await ctx.editMessageCaption(ownerInfo, {
        parse_mode: 'HTML',
        ...buttons
    });
}

module.exports = {
    handleCallbackQuery,
    handleJasherMenu,
    handleOwnerMenu,
    handleOwnerInfo
};