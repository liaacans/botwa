const { Telegraf, session } = require('telegraf');
const { message } = require('telegraf/filters');
require('./config');
const commandHandler = require('./src/commands');
const { Markup } = require('telegraf');

const bot = new Telegraf(BOT_TOKEN);

// Session middleware
bot.use(session());

// Command handlers
bot.command('start', async (ctx) => {
    await commandHandler.handleStart(ctx);
});

bot.command('menu', async (ctx) => {
    await commandHandler.handleMenu(ctx);
});

bot.command('obf', async (ctx) => {
    await commandHandler.handleObf(ctx);
});

bot.command('owner', async (ctx) => {
    await commandHandler.handleOwner(ctx);
});

bot.command('sharevip', async (ctx) => {
    await commandHandler.handleShareVip(ctx);
});

bot.command('addprem', async (ctx) => {
    await commandHandler.handleAddPrem(ctx);
});

bot.command('delprem', async (ctx) => {
    await commandHandler.handleDelPrem(ctx);
});

bot.command('listprem', async (ctx) => {
    await commandHandler.handleListPrem(ctx);
});

bot.command('addbl', async (ctx) => {
    await commandHandler.handleAddBl(ctx);
});

bot.command('delbl', async (ctx) => {
    await commandHandler.handleDelBl(ctx);
});

bot.command('listbl', async (ctx) => {
    await commandHandler.handleListBl(ctx);
});

bot.command('autojasher', async (ctx) => {
    await commandHandler.handleAutoJasher(ctx);
});

bot.command('stopautojasher', async (ctx) => {
    await commandHandler.handleStopAutoJasher(ctx);
});

bot.command('listgrup', async (ctx) => {
    await commandHandler.handleListGrup(ctx);
});

bot.command('tourl', async (ctx) => {
    await commandHandler.handleToUrl(ctx);
});

// Handle callback queries
bot.on('callback_query', async (ctx) => {
    await commandHandler.handleCallbackQuery(ctx);
});

// Handle new chat members (bot added to group)
bot.on('chat_member', async (ctx) => {
    await commandHandler.handleChatMember(ctx);
});

// Handle text messages
bot.on('message', async (ctx) => {
    await commandHandler.handleMessage(ctx);
});

// Error handling
bot.catch((err, ctx) => {
    console.error(`Error for ${ctx.updateType}`, err);
});

// Start bot
bot.launch().then(() => {
    console.log('Bot Jasher Premium started!');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));