const { Markup } = require('telegraf');
const moment = require('moment-timezone');
const { User, Group, Blacklist, Payment } = require('../lib/database');
const { runtime, log } = require('../lib/utils');
const { OWNER_ID, PREMIUM_PRICE, FREE_PREMIUM_DAYS, REQUIRED_GROUPS } = require('../config');
const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs-extra');
const path = require('path');
const QRCode = require('qrcode');

// Handler untuk start command
async function startHandler(ctx) {
  try {
    const user = ctx.user;
    const isCreator = ctx.from.id.toString() === OWNER_ID;
    const sender = ctx.from.username || `${ctx.from.first_name}${ctx.from.last_name ? ' ' + ctx.from.last_name : ''}`;
    
    const welcomeMessage = `
╭─❒ 「 User Info 」 
├ Owner : ${isCreator ? 'True' : 'False'}
├ Name : ${ctx.from.first_name}${ctx.from.last_name ? ' ' + ctx.from.last_name : ''}
├ Profile : @${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`;

    const photoUrl = 'https://f.top4top.io/p_3530xky9e4.jpg';
    
    await ctx.replyWithPhoto(photoUrl, {
      caption: welcomeMessage,
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [
          Markup.button.callback('Jasher Menu', 'jasher_menu'),
          Markup.button.callback('Owner Menu', 'owner_menu')
        ],
        [
          Markup.button.callback('Obf Menu', 'obf_menu'),
          Markup.button.callback('Kembali', 'back_menu')
        ]
      ])
    });
  } catch (error) {
    console.error('Start handler error:', error);
    await ctx.reply('❌ Terjadi kesalahan, silakan coba lagi.');
  }
}

// Handler untuk callback queries
async function callbackQueryHandler(ctx) {
  try {
    const data = ctx.callbackQuery.data;
    const user = ctx.user;
    const isCreator = ctx.from.id.toString() === OWNER_ID;
    const sender = ctx.from.username || `${ctx.from.first_name}${ctx.from.last_name ? ' ' + ctx.from.last_name : ''}`;
    
    switch (data) {
      case 'jasher_menu':
        await ctx.editMessageCaption({
          caption: `
╭─❒ 「 Jasher Menu 」 
├ /start - Memulai bot
├ /help - Bantuan
├ /profile - Profile user
├ /buyprem - Beli premium
├ /mysc - Lihat script saya
├ /sharefree - Share free
├ /sharevip - Share VIP
├ /tourl - Upload file ke URL
├ /status - Status bot
╰❒
Silahkan pilih button dibawah ini!`,
          parse_mode: 'Markdown',
          ...Markup.inlineKeyboard([
            [Markup.button.callback('Kembali', 'back_menu')]
          ])
        });
        break;
        
      case 'owner_menu':
        if (!isCreator) {
          await ctx.answerCbQuery('❌ Menu ini hanya untuk owner!');
          return;
        }
        
        await ctx.editMessageCaption({
          caption: `
╭─❒ 「 Owner Menu 」 
├ /addbl - Tambahkan blacklist
├ /delbl - Hapus blacklist
├ /listbl - List blacklist
├ /addprem - Tambahkan premium
├ /delprem - Hapus premium
├ /listprem - List premium
├ /bc - Broadcast ke semua user
├ /stats - Statistik bot
├ /listgroup - List grup
├ /gb - Hapus grup tidak aktif
╰❒
Silahkan pilih button dibawah ini!`,
          parse_mode: 'Markdown',
          ...Markup.inlineKeyboard([
            [Markup.button.callback('Kembali', 'back_menu')]
          ])
        });
        break;
        
      case 'obf_menu':
        await ctx.editMessageCaption({
          caption: `
╭─❒ 「 Obf Menu 」 
├ /enc - Time-Locked Encryption
├ /enc2 - Custom Encryption
├ /enc3 - Mandarin Encryption
├ /enc4 - Arab Encryption
├ /enc5 - Siu+Calcrick Encryption
├ /japan - Japan Encryption
├ /nebula - Nebula Encryption
├ /quantum - Quantum Encryption
├ /var - Var Encryption
├ /zenc - Invisible Encryption
├ /deobfuscate - Deobfuscate
╰❒
Silahkan pilih button dibawah ini!`,
          parse_mode: 'Markdown',
          ...Markup.inlineKeyboard([
            [Markup.button.callback('Kembali', 'back_menu')]
          ])
        });
        break;
        
      case 'back_menu':
        const welcomeMessage = `
╭─❒ 「 User Info 」 
├ Owner : ${isCreator ? 'True' : 'False'}
├ Name : ${ctx.from.first_name}${ctx.from.last_name ? ' ' + ctx.from.last_name : ''}
├ Profile : @${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`;

        await ctx.editMessageCaption({
          caption: welcomeMessage,
          parse_mode: 'Markdown',
          ...Markup.inlineKeyboard([
            [
              Markup.button.callback('Jasher Menu', 'jasher_menu'),
              Markup.button.callback('Owner Menu', 'owner_menu')
            ],
            [
              Markup.button.callback('Obf Menu', 'obf_menu'),
              Markup.button.callback('Kembali', 'back_menu')
            ]
          ])
        });
        break;
      default:
        await ctx.answerCbQuery('❌ Perintah tidak dikenali');
        break;
    }
    
    await ctx.answerCbQuery();
  } catch (error) {
    console.error('Callback query handler error:', error);
    await ctx.answerCbQuery('❌ Terjadi kesalahan');
  }
}

// Handler untuk menangani new chat members (bot ditambahkan ke grup)
async function newChatMembersHandler(ctx) {
  try {
    for (const member of ctx.message.new_chat_members) {
      if (member.is_bot && member.username === ctx.botInfo.username) {
        // Bot ditambahkan ke grup
        const groupId = ctx.chat.id;
        const groupTitle = ctx.chat.title;
        const groupUsername = ctx.chat.username;
        
        // Cek apakah grup sudah terdaftar
        let group = await Group.findOne({ groupId });
        if (!group) {
          group = new Group({
            groupId,
            title: groupTitle,
            username: groupUsername
          });
          await group.save();
        } else {
          group.isActive = true;
          await group.save();
        }
        
        await ctx.reply(`✅ Terima kasih telah menambahkan saya ke grup ini!\n\nGunakan /help untuk melihat perintah yang tersedia.`);
      }
    }
  } catch (error) {
    console.error('New chat members handler error:', error);
  }
}

// Handler untuk menangani left chat member (bot dikick dari grup)
async function leftChatMemberHandler(ctx) {
  try {
    if (ctx.message.left_chat_member.is_bot && 
        ctx.message.left_chat_member.username === ctx.botInfo.username) {
      // Bot dikick dari grup
      const groupId = ctx.chat.id;
      
      // Update status grup menjadi tidak aktif
      await Group.findOneAndUpdate(
        { groupId },
        { isActive: false },
        { new: true }
      );
    }
  } catch (error) {
    console.error('Left chat member handler error:', error);
  }
}

// Handler untuk upload file ke URL (tourl)
async function tourlHandler(ctx) {
  try {
    if (!ctx.message.reply_to_message) {
      return ctx.reply('❌ Balas file atau foto dengan perintah /tourl');
    }
    
    const message = ctx.message.reply_to_message;
    let fileId, fileName;
    
    if (message.document) {
      fileId = message.document.file_id;
      fileName = message.document.file_name;
    } else if (message.photo) {
      fileId = message.photo[message.photo.length - 1].file_id;
      fileName = `photo_${Date.now()}.jpg`;
    } else {
      return ctx.reply('❌ Hanya dokumen dan foto yang didukung');
    }
    
    // Download file
    const fileLink = await ctx.telegram.getFileLink(fileId);
    const response = await axios({
      method: 'GET',
      url: fileLink,
      responseType: 'stream'
    });
    
    // Upload ke uguu.se
    const formData = new FormData();
    formData.append('files[]', response.data, fileName);
    
    const uploadResponse = await axios.post('https://uguu.se/upload.php', formData, {
      headers: formData.getHeaders()
    });
    
    if (uploadResponse.data && uploadResponse.data.files && uploadResponse.data.files[0]) {
      const fileUrl = uploadResponse.data.files[0].url;
      await ctx.reply(`✅ Berhasil diupload!\n\n🔗 URL: ${fileUrl}`);
    } else {
      throw new Error('Upload gagal');
    }
  } catch (error) {
    console.error('Tourl handler error:', error);
    await ctx.reply('❌ Gagal mengupload file');
  }
}

// Handler untuk membeli premium
async function buypremHandler(ctx) {
  try {
    const user = ctx.user;
    
    // Jika user sudah premium
    if (user.isPremium && user.premiumUntil > new Date()) {
      const remaining = Math.ceil((user.premiumUntil - new Date()) / (1000 * 60 * 60 * 24));
      return ctx.reply(`✅ Anda sudah premium selama ${remaining} hari lagi.`);
    }
    
    // Generate QR code untuk pembayaran
    const paymentData = {
      nama: `${user.firstName}${user.lastName ? ' ' + user.lastName : ''}`,
      email: `${user.userId}@jasher.com`,
      phone: '081234567890', // Default phone
      amount: PREMIUM_PRICE,
      paymentMethod: 'qris',
      produk: 'Premium Jasher Bot'
    };
    
    // Panggil API YAB-Group
    const response = await axios.post('https://yab-group.com/api/live/create', paymentData, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    });
    
    if (response.data.status === 'success') {
      // Simpan data payment
      const payment = new Payment({
        userId: user.userId,
        amount: PREMIUM_PRICE,
        method: 'qris',
        status: 'pending',
        referenceId: response.data.id_reference,
        checkoutUrl: response.data.checkout_url,
        product: 'Premium Jasher Bot'
      });
      await payment.save();
      
      // Generate QR code
      const qrCodeData = await QRCode.toDataURL(response.data.checkout_url);
      const qrCodeBuffer = Buffer.from(qrCodeData.split(',')[1], 'base64');
      
      // Kirim QR code
      await ctx.replyWithPhoto({ source: qrCodeBuffer }, {
        caption: `💳 *Pembayaran Premium*\n\n` +
                 `💰 Harga: Rp ${PREMIUM_PRICE.toLocaleString('id-ID')}\n` +
                 `⏰ Durasi: 30 hari\n\n` +
                 `Silakan scan QR code di atas untuk melakukan pembayaran.`,
        parse_mode: 'Markdown'
      });
    } else {
      throw new Error('Gagal membuat pembayaran');
    }
  } catch (error) {
    console.error('Buyprem handler error:', error);
    await ctx.reply('❌ Gagal memproses pembayaran');
  }
}

// Handler untuk share free
async function sharefreeHandler(ctx) {
  try {
    const user = ctx.user;
    
    // Cek apakah di private chat
    if (ctx.chat.type !== 'private') {
      return ctx.reply('❌ Perintah ini hanya bisa digunakan di chat private');
    }
    
    // Cek apakah user sudah menambahkan bot ke cukup grup
    const userGroups = await Group.find({ _id: { $in: user.addedGroups }, isActive: true });
    
    if (userGroups.length < REQUIRED_GROUPS) {
      return ctx.reply(`❌ Anda harus menambahkan bot ke ${REQUIRED_GROUPS} grup terlebih dahulu untuk menggunakan fitur ini.\n\nSaat ini Anda telah menambahkan bot ke ${userGroups.length} grup.`);
    }
    
    // Jika user belum premium, berikan premium gratis
    if (!user.isPremium || user.premiumUntil <= new Date()) {
      user.isPremium = true;
      user.premiumUntil = new Date(Date.now() + FREE_PREMIUM_DAYS * 24 * 60 * 60 * 1000);
      await user.save();
      
      await ctx.reply(`✅ Anda mendapatkan premium gratis selama ${FREE_PREMIUM_DAYS} hari karena telah menambahkan bot ke ${userGroups.length} grup!`);
    }
    
    // Jika tidak ada pesan yang dibalas
    if (!ctx.message.reply_to_message) {
      return ctx.reply('❌ Balas pesan atau file dengan perintah /sharefree');
    }
    
    const message = ctx.message.reply_to_message;
    let caption = `🔊 *Share Free*\n\n` +
                  `Dari: @${user.username || user.firstName}\n` +
                  `Tanggal: ${moment().tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss')}`;
    
    // Forward pesan ke semua grup
    for (const group of userGroups) {
      try {
        if (message.document) {
          await ctx.telegram.sendDocument(group.groupId, message.document.file_id, {
            caption: caption,
            parse_mode: 'Markdown'
          });
        } else if (message.photo) {
          await ctx.telegram.sendPhoto(group.groupId, message.photo[message.photo.length - 1].file_id, {
            caption: caption,
            parse_mode: 'Markdown'
          });
        } else if (message.text) {
          await ctx.telegram.sendMessage(group.groupId, `${caption}\n\n${message.text}`, {
            parse_mode: 'Markdown'
          });
        } else {
          await ctx.telegram.sendMessage(group.groupId, caption, {
            parse_mode: 'Markdown'
          });
          await ctx.telegram.forwardMessage(group.groupId, message.chat.id, message.message_id);
        }
        
        // Tunggu sebentar agar tidak spam
        await new Promise(resolve => setTimeout(resolve, 1000));
      } catch (error) {
        console.error(`Gagal mengirim ke grup ${group.groupId}:`, error.message);
      }
    }
    
    await ctx.reply(`✅ Berhasil membagikan ke ${userGroups.length} grup!`);
  } catch (error) {
    console.error('Sharefree handler error:', error);
    await ctx.reply('❌ Gagal membagikan pesan');
  }
}

// Handler untuk share VIP (hanya untuk premium)
async function sharevipHandler(ctx) {
  try {
    const user = ctx.user;
    
    // Cek apakah di private chat
    if (ctx.chat.type !== 'private') {
      return ctx.reply('❌ Perintah ini hanya bisa digunakan di chat private');
    }
    
    // Jika tidak ada pesan yang dibalas
    if (!ctx.message.reply_to_message) {
      return ctx.reply('❌ Balas pesan atau file dengan perintah /sharevip');
    }
    
    const message = ctx.message.reply_to_message;
    const allGroups = await Group.find({ isActive: true });
    
    let caption = `🌟 *Share VIP*\n\n` +
                  `Dari: @${user.username || user.firstName}\n` +
                  `Tanggal: ${moment().tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss')}`;
    
    let successCount = 0;
    
    // Forward pesan ke semua grup aktif
    for (const group of allGroups) {
      try {
        if (message.document) {
          await ctx.telegram.sendDocument(group.groupId, message.document.file_id, {
            caption: caption,
            parse_mode: 'Markdown'
          });
        } else if (message.photo) {
          await ctx.telegram.sendPhoto(group.groupId, message.photo[message.photo.length - 1].file_id, {
            caption: caption,
            parse_mode: 'Markdown'
          });
        } else if (message.text) {
          await ctx.telegram.sendMessage(group.groupId, `${caption}\n\n${message.text}`, {
            parse_mode: 'Markdown'
          });
        } else {
          await ctx.telegram.sendMessage(group.groupId, caption, {
            parse_mode: 'Markdown'
          });
          await ctx.telegram.forwardMessage(group.groupId, message.chat.id, message.message_id);
        }
        
        successCount++;
        // Tunggu sebentar agar tidak spam
        await new Promise(resolve => setTimeout(resolve, 500));
      } catch (error) {
        console.error(`Gagal mengirim ke grup ${group.groupId}:`, error.message);
      }
    }
    
    await ctx.reply(`✅ Berhasil membagikan ke ${successCount} grup!`);
  } catch (error) {
    console.error('Sharevip handler error:', error);
    await ctx.reply('❌ Gagal membagikan pesan');
  }
}

// Handler untuk menampilkan profile user
async function profileHandler(ctx) {
  try {
    const user = ctx.user;
    const isPremium = user.isPremium && user.premiumUntil > new Date();
    const premiumUntil = isPremium ? moment(user.premiumUntil).tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss') : 'Tidak aktif';
    const groups = await Group.find({ _id: { $in: user.addedGroups }, isActive: true });
    
    const profileText = `
╭─❒ 「 User Profile 」 
├ Nama: ${user.firstName}${user.lastName ? ' ' + user.lastName : ''}
├ Username: @${user.username || 'Tidak ada'}
├ User ID: ${user.userId}
├ Premium: ${isPremium ? 'Aktif' : 'Tidak aktif'}
├ Sampai: ${premiumUntil}
├ Grup ditambahkan: ${groups.length}
├ Referral Code: ${user.referralCode}
╰❒
    `;
    
    await ctx.reply(profileText);
  } catch (error) {
    console.error('Profile handler error:', error);
    await ctx.reply('❌ Gagal menampilkan profile');
  }
}

module.exports = {
  startHandler,
  callbackQueryHandler,
  newChatMembersHandler,
  leftChatMemberHandler,
  tourlHandler,
  buypremHandler,
  sharefreeHandler,
  sharevipHandler,
  profileHandler
};