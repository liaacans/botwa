const { Markup } = require('telegraf');
const { User, Group } = require('../lib/database');
const { escapeMarkdown, formatCredit } = require('./utils');
const { OWNER_ID } = require('../config');

async function handleCallbackQuery(ctx) {
    const data = ctx.callbackQuery.data;
    const user = ctx.from;
    
    try {
        switch (data) {
            case 'main_menu':
                await require('./commands').handleStart(ctx);
                break;
                
            case 'jasher_menu':
                await showJasherMenu(ctx);
                break;
                
            case 'owner_menu':
                await showOwnerMenu(ctx);
                break;
                
            case 'add_group':
                await handleAddGroup(ctx);
                break;
                
            default:
                await ctx.answerCbQuery('❌ Perintah tidak dikenali!');
        }
    } catch (error) {
        console.error('Error in callback query handler:', error);
        await ctx.answerCbQuery('❌ Terjadi kesalahan!');
    }
}

async function showJasherMenu(ctx) {
    const userData = await User.findOne({ userId: ctx.from.id });
    if (!userData) return;
    
    const menuText = `*🎯 JASHER MENU*

💎 *Credit:* ${formatCredit(userData.credit)}
👥 *Groups Added:* ${userData.addedGroups.length}
⭐ *Status:* ${userData.isPremium ? 'Premium' : 'Regular'}

*📋 FITUR:*
- /share - Share pesan ke banyak group
- /credit - Cek credit Anda
- /help - Bantuan penggunaan bot

${userData.addedGroups.length < 3 ? '❌ Tambah 3 group dulu untuk unlock fitur share!' : '✅ Fitur share sudah terbuka!'}`;

    const buttons = Markup.inlineKeyboard([
        [Markup.button.callback('💎 Cek Credit', 'check_credit')],
        [Markup.button.callback('🔙 Kembali', 'main_menu')]
    ]);

    await ctx.editMessageText(menuText, {
        ...buttons,
        parse_mode: 'MarkdownV2'
    });
}

async function showOwnerMenu(ctx) {
    if (ctx.from.id.toString() !== OWNER_ID) {
        await ctx.answerCbQuery('❌ Hanya owner yang bisa mengakses menu ini!');
        return;
    }
    
    const totalUsers = await User.countDocuments();
    const totalGroups = await Group.countDocuments();
    const premiumUsers = await User.countDocuments({ isPremium: true });
    
    const menuText = `*👤 OWNER MENU*

📊 *Statistik Bot:*
👥 Total Users: ${totalUsers}
⭐ Premium Users: ${premiumUsers}
👥 Total Groups: ${totalGroups}

*⚙️ PERINTAH OWNER:*
/addprem [user_id] - Jadikan user premium
/delprem [user_id] - Hapus user premium
/listprem - List user premium
/broadcast - Broadcast ke semua user (reply pesan)`;

    const buttons = Markup.inlineKeyboard([
        [Markup.button.callback('⭐ List Premium', 'list_premium')],
        [Markup.button.callback('🔙 Kembali', 'main_menu')]
    ]);

    await ctx.editMessageText(menuText, {
        ...buttons,
        parse_mode: 'MarkdownV2'
    });
}

async function handleAddGroup(ctx) {
    if (ctx.chat.type === 'private') {
        await ctx.answerCbQuery('❌ Tambah group harus dilakukan di group, bukan di private chat!');
        return;
    }
    
    try {
        const user = await User.findOne({ userId: ctx.from.id });
        if (!user) return;
        
        // Cek apakah group sudah ditambahkan
        const existingGroup = await Group.findOne({ groupId: ctx.chat.id });
        if (existingGroup) {
            await ctx.answerCbQuery('❌ Group sudah pernah ditambahkan!');
            return;
        }
        
        // Tambah group
        const group = new Group({
            groupId: ctx.chat.id,
            title: ctx.chat.title,
            username: ctx.chat.username,
            addedBy: ctx.from.id
        });
        await group.save();
        
        // Tambah ke list user dan tambah credit jika belum ada
        if (!user.addedGroups.includes(ctx.chat.id.toString())) {
            user.addedGroups.push(ctx.chat.id.toString());
            
            // Beri bonus 10 credit setelah menambah 3 group
            if (user.addedGroups.length % 3 === 0) {
                user.credit += 10;
                await user.save();
                
                await ctx.reply(
                    `✅ Group berhasil ditambahkan!\n🎉 Bonus! Anda telah menambah 3 group dan mendapatkan 10 credit!\n💎 Total credit: ${formatCredit(user.credit)}`
                );
            } else {
                await user.save();
                await ctx.reply('✅ Group berhasil ditambahkan!');
            }
        }
        
        await ctx.answerCbQuery('✅ Group berhasil ditambahkan!');
    } catch (error) {
        console.error('Error adding group:', error);
        await ctx.answerCbQuery('❌ Gagal menambah group!');
    }
}

module.exports = {
    handleCallbackQuery
};