const { Markup } = require('telegraf');
const { isPrivateChat, isCreator, getUserCredits, deductCredits } = require('./utils');
const db = require('../lib/database');
const config = require('../config');

function handleStart(ctx) {
  const sender = ctx.from.username || `user_${ctx.from.id}`;
  const userTelelu = ctx.from.username || `user_${ctx.from.id}`;
  const isCreatorUser = isCreator(ctx.from.id);
  const moment = require('moment-timezone');
  
  ctx.reply(
    `Hi kak @${sender}
╭─❒ 「 User Info 」 
├ Creator : @${userTelelu}
├ Name : @${sender}
├ Profile : @${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : Linux
├ Platform : Bot Telegram
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreatorUser ? 'True' : 'False'}
Silahkan pilih button dibawah ini!`,
    {
      reply_markup: {
        inline_keyboard: [
          [
            Markup.button.callback('Jasher Menu', 'jasher_menu'),
            Markup.button.callback('Owner Menu', 'owner_menu')
          ],
          [
            Markup.button.callback('Kembali', 'main_menu'),
            Markup.button.callback('AddGroup', 'add_group')
          ],
          [
            Markup.button.callback('Owner', 'owner_info')
          ]
        ]
      }
    }
  );
}

function handleHelp(ctx) {
  ctx.reply(
    `Bot Jasher Group Telegram Premium\n\n` +
    `Perintah yang tersedia:\n` +
    `/start - Memulai bot\n` +
    `/help - Menampilkan bantuan\n` +
    `/credit - Mengecek kredit Anda\n` +
    `/share - Share pesan (2 kredit)\n` +
    `/sharevip - Share VIP (hanya untuk premium)\n\n` +
    `Untuk menambah kredit, tambahkan bot ke 3 group terlebih dahulu.`
  );
}

function handleCredit(ctx) {
  const credits = getUserCredits(ctx.from.id);
  ctx.reply(`Kredit Anda: ${credits}`);
}

function handleShare(ctx) {
  if (!isPrivateChat(ctx)) {
    ctx.reply('Perintah share hanya bisa digunakan di private chat!');
    return;
  }
  
  const credits = getUserCredits(ctx.from.id);
  if (credits < config.SHARE_COST) {
    ctx.reply(`Kredit Anda tidak cukup. Dibutuhkan ${config.SHARE_COST} kredit untuk share.`);
    return;
  }
  
  const messageText = ctx.message.text.replace('/share', '').trim();
  if (!messageText && !ctx.message.reply_to_message) {
    ctx.reply('Silahkan ketik pesan yang ingin di-share atau reply pesan yang ingin di-share.');
    return;
  }
  
  const shareText = messageText || 
                   (ctx.message.reply_to_message && 
                    (ctx.message.reply_to_message.text || 
                     ctx.message.reply_to_message.caption || 
                     'Pesan tidak dapat di-share'));
  
  // Deduct credits
  if (deductCredits(ctx.from.id, config.SHARE_COST)) {
    // Di sini Anda perlu mengimplementasikan logika broadcast ke group
    // Ini hanya contoh sederhana
    ctx.reply(`Pesan berhasil di-share! Kredit berkurang ${config.SHARE_COST}.`);
    ctx.reply(`Pesan yang di-share: ${shareText}`);
  } else {
    ctx.reply('Gagal mengurangi kredit. Silahkan coba lagi.');
  }
}

function handleShareVip(ctx) {
  if (!isPrivateChat(ctx)) {
    ctx.reply('Perintah sharevip hanya bisa digunakan di private chat!');
    return;
  }
  
  if (!db.isPremiumUser(ctx.from.id)) {
    ctx.reply('Fitur ini hanya untuk user premium!');
    return;
  }
  
  const messageText = ctx.message.text.replace('/sharevip', '').trim();
  if (!messageText && !ctx.message.reply_to_message) {
    ctx.reply('Silahkan ketik pesan yang ingin di-share atau reply pesan yang ingin di-share.');
    return;
  }
  
  const shareText = messageText || 
                   (ctx.message.reply_to_message && 
                    (ctx.message.reply_to_message.text || 
                     ctx.message.reply_to_message.caption || 
                     'Pesan tidak dapat di-share'));
  
  // Di sini Anda perlu mengimplementasikan logika broadcast VIP ke group
  // Ini hanya contoh sederhana
  ctx.reply(`Pesan VIP berhasil di-share! (Lebih cepat dari share biasa)`);
  ctx.reply(`Pesan yang di-share: ${shareText}`);
}

function handleBroadcast(ctx) {
  if (!isCreator(ctx.from.id)) {
    ctx.reply('Hanya owner yang bisa menggunakan perintah ini!');
    return;
  }
  
  const messageText = ctx.message.text.replace('/broadcast', '').trim();
  if (!messageText) {
    ctx.reply('Silahkan ketik pesan yang ingin di-broadcast.');
    return;
  }
  
  // Di sini Anda perlu mengimplementasikan logika broadcast ke semua user
  // Ini hanya contoh sederhana
  ctx.reply(`Broadcast berhasil dikirim ke semua user!`);
}

function handleAddPrem(ctx) {
  if (!isCreator(ctx.from.id)) {
    ctx.reply('Hanya owner yang bisa menggunakan perintah ini!');
    return;
  }
  
  const userId = ctx.message.text.replace('/addprem', '').trim();
  if (!userId) {
    ctx.reply('Silahkan sertakan user ID. Contoh: /addprem 123456789');
    return;
  }
  
  db.addPremiumUser(parseInt(userId));
  ctx.reply(`User ${userId} berhasil ditambahkan sebagai premium.`);
}

function handleDelPrem(ctx) {
  if (!isCreator(ctx.from.id)) {
    ctx.reply('Hanya owner yang bisa menggunakan perintah ini!');
    return;
  }
  
  const userId = ctx.message.text.replace('/delprem', '').trim();
  if (!userId) {
    ctx.reply('Silahkan sertakan user ID. Contoh: /delprem 123456789');
    return;
  }
  
  db.removePremiumUser(parseInt(userId));
  ctx.reply(`User ${userId} berhasil dihapus dari premium.`);
}

function handleListPrem(ctx) {
  if (!isCreator(ctx.from.id)) {
    ctx.reply('Hanya owner yang bisa menggunakan perintah ini!');
    return;
  }
  
  const premiumUsers = db.getPremiumUsers();
  if (premiumUsers.length === 0) {
    ctx.reply('Tidak ada user premium.');
    return;
  }
  
  ctx.reply(`Daftar user premium:\n${premiumUsers.join('\n')}`);
}

module.exports = {
  handleStart,
  handleHelp,
  handleCredit,
  handleShare,
  handleShareVip,
  handleBroadcast,
  handleAddPrem,
  handleDelPrem,
  handleListPrem
};