const { Markup } = require('telegraf');
const { User, Group } = require('../lib/database');
const { formatUserInfo } = require('./utils');

async function handleCallbackQuery(ctx) {
  const data = ctx.callbackQuery.data;
  
  try {
    switch (data) {
      case 'jasher_menu':
        await ctx.editMessageCaption(
          `🎯 *Jasher Menu*\n\nPilih opsi di bawah ini:`,
          {
            parse_mode: 'Markdown',
            reply_markup: {
              inline_keyboard: [
                [Markup.button.callback('💳 Cek Kredit', 'check_credit')],
                [Markup.button.callback('📢 Share Broadcast', 'share_broadcast')],
                [Markup.button.callback('🚀 Share VIP', 'share_vip')],
                [Markup.button.callback('🔙 Kembali', 'main_menu')]
              ]
            }
          }
        );
        break;
        
      case 'owner_menu':
        if (ctx.from.id.toString() !== global.OWNER_ID) {
          await ctx.answerCbQuery('Menu ini hanya untuk owner!');
          return;
        }
        
        await ctx.editMessageCaption(
          `👑 *Owner Menu*\n\nPilih opsi di bawah ini:`,
          {
            parse_mode: 'Markdown',
            reply_markup: {
              inline_keyboard: [
                [Markup.button.callback('➕ Tambah Premium', 'add_premium')],
                [Markup.button.callback('➖ Hapus Premium', 'remove_premium')],
                [Markup.button.callback('📋 List Premium', 'list_premium')],
                [Markup.button.callback('📢 Broadcast', 'owner_broadcast')],
                [Markup.button.callback('🔙 Kembali', 'main_menu')]
              ]
            }
          }
        );
        break;
        
      case 'main_menu':
        const user = await User.findOne({ userId: ctx.from.id });
        const menuText = formatUserInfo(ctx, user);
        
        await ctx.editMessageCaption(menuText, {
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [Markup.button.callback('🎯 Jasher Menu', 'jasher_menu')],
              [Markup.button.callback('👤 Owner Menu', 'owner_menu')],
              [Markup.button.url('➕ Add Group', 'https://t.me/your_bot_username?startgroup=true')]
            ]
          }
        });
        break;
        
      case 'check_credit':
        const userData = await User.findOne({ userId: ctx.from.id });
        await ctx.answerCbQuery(`Kredit Anda: ${userData.credit}`);
        break;
        
      default:
        await ctx.answerCbQuery('Fitur belum tersedia!');
    }
  } catch (error) {
    console.error('Error handling callback query:', error);
    await ctx.answerCbQuery('Terjadi kesalahan!');
  }
}

async function handleNewChatMembers(ctx) {
  try {
    // Cek jika bot yang ditambahkan ke grup
    if (ctx.message.new_chat_members.some(member => member.is_bot && member.id === ctx.botInfo.id)) {
      const groupId = ctx.chat.id;
      const groupTitle = ctx.chat.title;
      const groupUsername = ctx.chat.username;
      const addedBy = ctx.from.id;
      
      // Cek jika grup sudah ada di database
      const existingGroup = await Group.findOne({ groupId });
      if (!existingGroup) {
        const newGroup = new Group({
          groupId,
          title: groupTitle,
          username: groupUsername,
          addedBy
        });
        await newGroup.save();
        
        // Beri kredit kepada user yang menambahkan bot
        const user = await User.findOne({ userId: addedBy });
        if (user) {
          // Hitung berapa banyak grup yang sudah user tambahkan
          const userGroups = await Group.find({ addedBy: addedBy });
          
          if (userGroups.length % 3 === 0) {
            // Setiap 3 grup, beri 10 kredit
            user.credit += 10;
            await user.save();
            
            await ctx.reply(
              `Terima kasih telah menambahkan bot ke grup ini! 🎉\n` +
              `Anda telah mendapatkan 10 kredit. Total kredit: ${user.credit}`
            );
          } else {
            await ctx.reply(
              `Terima kasih telah menambahkan bot ke grup ini! 🎉\n` +
              `Anda telah menambahkan bot ke ${userGroups.length} grup. ` +
              `Tambahkan ke ${3 - (userGroups.length % 3)} grup lagi untuk mendapatkan 10 kredit.`
            );
          }
        }
      }
    }
  } catch (error) {
    console.error('Error handling new chat members:', error);
  }
}

module.exports = {
  handleCallbackQuery,
  handleNewChatMembers
};