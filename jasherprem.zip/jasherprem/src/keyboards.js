const { Markup } = require('telegraf');

function mainMenu(ctx, userData) {
  const isCreator = String(ctx.from.id) === process.env.OWNER_ID;
  const sender = ctx.from.username || ctx.from.first_name;
  const userTelelu = ctx.from.username || 'No username';
  
  return Markup.inlineKeyboard([
    [
      Markup.button.callback('🎯 Jasher Menu', 'jasher_menu'),
      Markup.button.callback('👤 Owner Menu', 'owner_menu')
    ],
    [
      Markup.button.callback('➕ AddGroup', 'add_group'),
      Markup.button.callback('👑 Owner', 'owner_info')
    ],
    [
      Markup.button.callback('🔄 Kembali', 'main_menu')
    ]
  ]);
}

function jasherMenu(ctx) {
  return Markup.inlineKeyboard([
    [
      Markup.button.callback('📤 Share Free', 'share_free'),
      Markup.button.callback('💎 Share VIP', 'share_vip')
    ],
    [
      Markup.button.callback('ℹ️ Credit Info', 'credit_info'),
      Markup.button.callback('📊 Stats', 'user_stats')
    ],
    [
      Markup.button.callback('🔙 Kembali', 'main_menu')
    ]
  ]);
}

function ownerMenu(ctx) {
  const isOwner = String(ctx.from.id) === process.env.OWNER_ID;
  
  if (!isOwner) {
    return mainMenu(ctx);
  }
  
  return Markup.inlineKeyboard([
    [
      Markup.button.callback('📢 Broadcast', 'owner_broadcast'),
      Markup.button.callback('👑 Add Premium', 'add_premium')
    ],
    [
      Markup.button.callback('🚫 Remove Premium', 'remove_premium'),
      Markup.button.callback('📋 List Premium', 'list_premium')
    ],
    [
      Markup.button.callback('🔙 Kembali', 'main_menu')
    ]
  ]);
}

function backButton(menu) {
  return Markup.inlineKeyboard([
    [Markup.button.callback('🔙 Kembali', menu)]
  ]);
}

module.exports = {
  mainMenu,
  jasherMenu,
  ownerMenu,
  backButton
};