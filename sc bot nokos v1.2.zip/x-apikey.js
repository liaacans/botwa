const axios = require('axios');
const config = require('./config');

const x_apikey = config.apikey;
const x_domain = config.domain;

async function getServices() {
    try {
        const response = await axios.get(`${x_domain}/v2/services`, {
            headers: {
                'x-apikey': x_apikey,
                'Accept': 'application/json'
            },
            timeout: 10000
        });
        return response.data;
    } catch (error) {
        if (error.response) {
            return {
                success: false,
                message: error.response.data?.error?.message || `API Error ${error.response.status}`
            };
        }
        return {
            success: false,
            message: error.message || 'Gagal mengambil data layanan'
        };
    }
}

async function getCountries(serviceId) {
    try {
        const response = await axios.get(`${x_domain}/v2/countries?service_id=${serviceId}`, {
            headers: {
                'x-apikey': x_apikey,
                'Accept': 'application/json'
            },
            timeout: 15000
        });
        return response.data;
    } catch (error) {
        if (error.response) {
            return {
                success: false,
                message: error.response.data?.error?.message || `API Error ${error.response.status}`
            };
        }
        return {
            success: false,
            message: error.message || 'Gagal mengambil data negara'
        };
    }
}

async function getOperators(country, providerId) {
    try {
        const cleanCountry = country.toString().trim();
        const encodedCountry = encodeURIComponent(cleanCountry);
        const url = `${x_domain}/v2/operators?country=${encodedCountry}&provider_id=${providerId}`;
        
        const response = await axios.get(url, {
            headers: {
                'x-apikey': x_apikey,
                'Accept': 'application/json'
            },
            timeout: 20000
        });
        return response.data;
    } catch (error) {
        if (error.response) {
            return {
                success: false,
                message: error.response.data?.error?.message || `API Error ${error.response.status}`,
                error: error.response.data
            };
        }
        return {
            success: false,
            message: error.message || 'Gagal mengambil data operator'
        };
    }
}

async function createOrder(numberId, providerId, operatorId) {
    try {
        const url = `${x_domain}/v2/orders?number_id=${numberId}&provider_id=${providerId}&operator_id=${operatorId}`;
        
        const response = await axios.get(url, {
            headers: {
                'x-apikey': x_apikey,
                'Accept': 'application/json'
            },
            timeout: 15000
        });
        return response.data;
    } catch (error) {
        if (error.response) {
            return {
                success: false,
                error: {
                    message: error.response.data?.error?.message || 
                           error.response.data?.message || 
                           `API Error ${error.response.status}`,
                    data: error.response.data
                }
            };
        }
        return {
            success: false,
            error: {
                message: error.message || 'Gagal membuat order'
            }
        };
    }
}

async function getOrderStatus(orderId) {
    try {
        const response = await axios.get(`${x_domain}/v1/orders/get_status?order_id=${orderId}`, {
            headers: {
                'x-apikey': x_apikey,
                'Accept': 'application/json'
            },
            timeout: 10000
        });
        return response.data;
    } catch (error) {
        if (error.response) {
            return {
                success: false,
                message: error.response.data?.error?.message || `API Error ${error.response.status}`
            };
        }
        return {
            success: false,
            message: error.message || 'Gagal mengambil status order'
        };
    }
}

async function setOrderStatus(orderId, status) {
    try {
        const response = await axios.get(`${x_domain}/v1/orders/set_status?order_id=${orderId}&status=${status}`, {
            headers: {
                'x-apikey': x_apikey,
                'Accept': 'application/json'
            },
            timeout: 10000
        });
        return response.data;
    } catch (error) {
        if (error.response) {
            return {
                success: false,
                message: error.response.data?.error?.message || `API Error ${error.response.status}`
            };
        }
        return {
            success: false,
            message: error.message || 'Gagal mengubah status order'
        };
    }
}

async function getUserBalanceAPI() {
    try {
        const response = await axios.get(`${x_domain}/v1/user/balance`, {
            headers: {
                'x-apikey': x_apikey,
                'Accept': 'application/json'
            },
            timeout: 10000
        });
        return response.data;
    } catch (error) {
        if (error.response) {
            return {
                success: false,
                message: error.response.data?.error?.message || `API Error ${error.response.status}`
            };
        }
        return {
            success: false,
            message: error.message || 'Gagal mengambil saldo sistem'
        };
    }
}

async function createRumahOTPDeposit(amount, paymentMethod = 'qris') {
    try {
        const response = await axios.get(`${x_domain}/v2/deposit/create?amount=${amount}&payment_id=${paymentMethod}`, {
            headers: {
                'x-apikey': x_apikey,
                'Accept': 'application/json'
            },
            timeout: 15000
        });
        return response.data;
    } catch (error) {
        if (error.response) {
            return {
                success: false,
                error: {
                    message: error.response.data?.error?.message || `API Error ${error.response.status}`,
                    data: error.response.data
                }
            };
        }
        return {
            success: false,
            message: error.message || 'Gagal membuat deposit'
        };
    }
}

async function checkRumahOTPDepositStatus(depositId) {
    try {
        const response = await axios.get(`${x_domain}/v2/deposit/get_status?deposit_id=${depositId}`, {
            headers: {
                'x-apikey': x_apikey,
                'Accept': 'application/json'
            },
            timeout: 10000
        });
        return response.data;
    } catch (error) {
        if (error.response) {
            return {
                success: false,
                message: error.response.data?.error?.message || `API Error ${error.response.status}`
            };
        }
        return {
            success: false,
            message: error.message || 'Gagal memeriksa status deposit'
        };
    }
}

async function cancelRumahOTPDeposit(depositId) {
    try {
        const response = await axios.get(`${x_domain}/v1/deposit/cancel?deposit_id=${depositId}`, {
            headers: {
                'x-apikey': x_apikey,
                'Accept': 'application/json'
            },
            timeout: 10000
        });
        return response.data;
    } catch (error) {
        if (error.response) {
            return {
                success: false,
                message: error.response.data?.error?.message || `API Error ${error.response.status}`
            };
        }
        return {
            success: false,
            message: error.message || 'Gagal membatalkan deposit'
        };
    }
}

module.exports = {
    getServices,
    getCountries,
    getOperators,
    createOrder,
    getOrderStatus,
    setOrderStatus,
    getUserBalanceAPI,
    createRumahOTPDeposit,
    checkRumahOTPDepositStatus,
    cancelRumahOTPDeposit
};