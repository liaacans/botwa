const { Markup } = require('telegraf');
const database = require('../../lib/database');
const { isPremium, isOwner, loadJSON, saveJSON } = require('../../lib/utils');
const config = require('../../config');
const moment = require('moment-timezone');

module.exports = (bot) => {
    // Command status
    bot.command('status', async (ctx) => {
        const userId = ctx.from.id;
        const user = database.getUser(userId);
        const isPrem = isPremium(userId);
        const stats = database.getStats();
        
        const statusText = `
📊 *Status User*

*Informasi Anda:*
• 🆔 ID: ${userId}
• 👤 Username: @${ctx.from.username || 'Tidak ada'}
• 💎 Status Premium: ${isPrem ? '✅ AKTIF' : '❌ NON-AKTIF'}
• 📅 Bergabung: ${user ? moment(user.join_date).format('DD/MM/YYYY HH:mm') : 'Baru'}

*Statistik Bot:*
• 👥 Total Users: ${stats.total_users}
• 💎 Premium Users: ${stats.premium_users}
• 👥 Grup Aktif: ${stats.active_groups}

${isPrem ? '🎉 Anda menikmati fitur premium!' : '💡 Upgrade premium untuk akses penuh!'}`;

        await ctx.replyWithMarkdown(statusText);
    });

    // Command sharefree
    bot.command('sharefree', async (ctx) => {
        if (ctx.chat.type !== 'private') {
            return ctx.reply('❌ Command ini hanya bisa digunakan di private chat!');
        }

        const userId = ctx.from.id;
        const user = database.getUser(userId);
        
        // Cek apakah user sudah menambahkan bot ke 3 group
        if (user.groups.length < config.REQUIRED_GROUPS) {
            return ctx.replyWithMarkdown(`
❌ *Akses Ditolak!*

Anda harus menambahkan bot ke *${config.REQUIRED_GROUPS} group* terlebih dahulu untuk menggunakan fitur share.

*Group Anda saat ini:* ${user.groups.length}/${config.REQUIRED_GROUPS}

💡 Tambahkan bot ke group lain dan gunakan /start di group tersebut.`);
        }

        // Cek apakah ada pesan yang di-reply
        if (!ctx.message.reply_to_message) {
            return ctx.replyWithMarkdown(`
📤 *Share Free*

*Cara penggunaan:*
1. Reply pesan yang ingin di-share dengan command /sharefree
2. Pesan akan di-share ke semua group secara gratis

*Fitur:*
• ⏱️ Proses lambat (antrian gratis)
• 📊 Prioritas rendah
• 🔄 Maksimal 3 share per hari

*Contoh:* Reply pesan ini dengan /sharefree`);
        }

        // Update share count
        database.updateUser(userId, {
            share_count: (user.share_count || 0) + 1,
            last_share: moment().format()
        });

        // Proses share gratis
        const progressMsg = await ctx.reply('🔄 Memproses share gratis...');

        try {
            // Simulasi proses lambat
            setTimeout(async () => {
                const groupsData = loadJSON('groups.json');
                const activeGroups = groupsData.groups.filter(g => g.is_active);
                
                let successCount = 0;
                let failCount = 0;

                for (const group of activeGroups) {
                    try {
                        await ctx.telegram.copyMessage(
                            group.id,
                            ctx.chat.id,
                            ctx.message.reply_to_message.message_id
                        );
                        successCount++;
                        
                        // Delay untuk simulasi proses lambat
                        await new Promise(resolve => setTimeout(resolve, 2000));
                    } catch (error) {
                        console.log(`Gagal share ke group ${group.id}:`, error.message);
                        failCount++;
                    }
                }

                await ctx.telegram.editMessageText(
                    progressMsg.chat.id,
                    progressMsg.message_id,
                    null,
                    `✅ *Share Free Selesai!*\n\n` +
                    `✓ Berhasil: ${successCount} group\n` +
                    `✗ Gagal: ${failCount} group\n` +
                    `⏱️ Waktu: ${moment().format('HH:mm:ss')}`,
                    { parse_mode: 'Markdown' }
                );
            }, 3000);

        } catch (error) {
            await ctx.reply('❌ Gagal memproses share: ' + error.message);
        }
    });

    // Command sharevip
    bot.command('sharevip', async (ctx) => {
        if (ctx.chat.type !== 'private') {
            return ctx.reply('❌ Command ini hanya bisa digunakan di private chat!');
        }

        const userId = ctx.from.id;
        
        // Cek premium status
        if (!isPremium(userId)) {
            return ctx.replyWithMarkdown(`
❌ *Akses Premium Required!*

Fitur *Share VIP* hanya untuk user premium.

💎 *Keuntungan Premium:*
• 🚀 Proses cepat (prioritas tinggi)
• 📊 Unlimited share
• 🔒 Akses semua fitur obfuscation
• 👑 Support prioritas

💳 *Harga:* Rp ${config.PREMIUM_PRICE.toLocaleString()}
📅 *Durasi:* ${config.PREMIUM_DAYS} hari

Ketik /buypremium untuk upgrade!`);
        }

        if (!ctx.message.reply_to_message) {
            return ctx.replyWithMarkdown(`
🚀 *Share VIP*

*Cara penggunaan:*
1. Reply pesan yang ingin di-share dengan command /sharevip
2. Pesan akan di-share ke semua group dengan prioritas tinggi

*Fitur VIP:*
• ⚡ Proses cepat (real-time)
• 📊 Prioritas maksimal
• 🔄 Unlimited share per hari

*Contoh:* Reply pesan ini dengan /sharevip`);
        }

        const progressMsg = await ctx.reply('⚡ Memproses share VIP...');

        try {
            const groupsData = loadJSON('groups.json');
            const activeGroups = groupsData.groups.filter(g => g.is_active);
            
            let successCount = 0;
            let failCount = 0;

            // Proses cepat untuk VIP
            for (const group of activeGroups) {
                try {
                    await ctx.telegram.copyMessage(
                        group.id,
                        ctx.chat.id,
                        ctx.message.reply_to_message.message_id
                    );
                    successCount++;
                } catch (error) {
                    console.log(`Gagal share VIP ke group ${group.id}:`, error.message);
                    failCount++;
                }
            }

            await ctx.telegram.editMessageText(
                progressMsg.chat.id,
                progressMsg.message_id,
                null,
                `✅ *Share VIP Selesai!*\n\n` +
                `✓ Berhasil: ${successCount} group\n` +
                `✗ Gagal: ${failCount} group\n` +
                `⚡ Waktu: ${moment().format('HH:mm:ss')}\n` +
                `💎 Status: Premium User`,
                { parse_mode: 'Markdown' }
            );

        } catch (error) {
            await ctx.reply('❌ Gagal memproses share VIP: ' + error.message);
        }
    });

    // Command buypremium
    bot.command('buypremium', async (ctx) => {
        const userId = ctx.from.id;
        
        if (isPremium(userId)) {
            const user = database.getUser(userId);
            return ctx.replyWithMarkdown(`
💎 *Anda Sudah Premium!*

*Status Premium:*
• ✅ Aktif hingga: ${moment(user.premium_expiry).format('DD/MM/YYYY HH:mm')}
• ⏰ Sisa waktu: ${moment(user.premium_expiry).fromNow(true)}

Terima kasih telah berlangganan! 🎉`);
        }

        const premiumText = `
💎 *UPGRADE PREMIUM*

*Harga:* Rp ${config.PREMIUM_PRICE.toLocaleString()}
*Durasi:* ${config.PREMIUM_DAYS} hari

*Fitur Premium:*
• 🚀 Share VIP (cepat)
• 🔒 Semua fitur obfuscation
• 📊 Prioritas processing
• 👑 Support prioritas
• 🔄 Unlimited usage

*Cara Pembayaran:*
1. Transfer ke:
   • Bank BCA: 123-456-7890 (A/N JASHER PREMIUM)
   • Dana: 081234567890 (A/N JASHER PREMIUM)

2. Kirim bukti transfer ke @ginaaforyou
3. Premium akan diaktifkan dalam 1x24 jam

*Note:* Harap sertakan ID Anda: ${userId}`;

        await ctx.replyWithMarkdown(premiumText, 
            Markup.inlineKeyboard([
                [Markup.button.url('💬 Hubungi Owner', 'https://t.me/ginaaforyou')],
                [Markup.button.callback('✅ Sudah Transfer', 'confirm_payment')]
            ])
        );
    });

    // Command buyscript
    bot.command('buyscript', async (ctx) => {
        const scriptText = `
🛒 *BELI SCRIPT CUSTOM*

*Harga:* Rp ${config.SCRIPT_PRICE.toLocaleString()}
*Format:* File ZIP (include source code)

*Yang Anda Dapat:*
• 📦 File script lengkap
• 🔧 Source code asli
• 📚 Dokumentasi
• 🔧 Support instalasi

*Fitur Script:*
• 🔒 Obfuscation system
• 👥 User management
• 💎 Premium system
• 📊 Analytics

*Cara Pembayaran:*
1. Transfer ke:
   • Bank BCA: 123-456-7890 (A/N JASHER SCRIPT)
   • Dana: 081234567890 (A/N JASHER SCRIPT)

2. Kirim bukti transfer ke @ginaaforyou
3. Script akan dikirim via document/file

*Note:* Harap sertakan ID Anda: ${ctx.from.id}`;

        await ctx.replyWithMarkdown(scriptText,
            Markup.inlineKeyboard([
                [Markup.button.url('💬 Pesan Script', 'https://t.me/ginaaforyou')],
                [Markup.button.callback('📦 Lihat Demo', 'script_demo')]
            ])
        );
    });

    // Callback untuk konfirmasi pembayaran
    bot.action('confirm_payment', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.replyWithMarkdown(`
✅ *Konfirmasi Pembayaran*

Silakan kirim bukti transfer Anda ke @ginaaforyou dengan format:

*Format Pesan:*
Konfirmasi Premium - ID: ${ctx.from.id}
[Lampirkan screenshot bukti transfer]

*Pastikan bukti transfer jelas terlihat:*
• Nama pengirim
• Jumlah transfer
• Tanggal/waktu
• Bank tujuan

Premium akan diaktifkan maksimal 1x24 jam setelah konfirmasi.`);
    });

    // Info command
    bot.command('info', (ctx) => {
        ctx.replyWithMarkdown(`
🤖 *Jasher Bot Information*

*Version:* 2.0.0
*Developer:* @ginaaforyou
*Platform:* Node.js Telegraf

*Support:* @ginaaforyou
*Channel:* @jasherupdates

*Features:*
• 🔒 Advanced Obfuscation
• 👥 Group Management  
• 💎 Premium System
• 📊 Analytics
• ⚡ Fast Processing

*Thanks for using Jasher Bot!* 🎉`);
    });
};