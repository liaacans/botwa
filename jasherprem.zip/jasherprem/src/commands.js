const { User, Group } = require('../lib/database');
const { formatUserInfo } = require('./utils');

async function handleStart(ctx) {
  try {
    // Save or update user data
    const userData = {
      userId: ctx.from.id,
      username: ctx.from.username,
      firstName: ctx.from.first_name,
      lastName: ctx.from.last_name || ''
    };
    
    let user = await User.findOne({ userId: ctx.from.id });
    if (!user) {
      user = new User(userData);
      await user.save();
    } else {
      await User.updateOne({ userId: ctx.from.id }, userData);
    }
    
    const message = formatUserInfo(ctx, user);
    
    // Create menu buttons
    const buttons = [
      [{ text: 'Jasher Menu', callback_data: 'jasher_menu' }],
      [{ text: 'Owner Menu', callback_data: 'owner_menu' }],
      [{ text: 'AddGroup', callback_data: 'add_group' }],
      [{ text: 'Owner', url: 't.me/your_username' }]
    ];
    
    await ctx.reply(message, {
      reply_markup: {
        inline_keyboard: buttons
      },
      parse_mode: 'HTML'
    });
  } catch (error) {
    console.error('Error in start command:', error);
    await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleHelp(ctx) {
  const helpMessage = `🤖 *Jasher Bot Help*

*Perintah Umum:*
/start - Memulai bot
/help - Menampilkan bantuan
/credit - Melihat kredit Anda
/share - Membagikan pesan (2 kredit)

*Perintah Premium:*
/sharevip - Membagikan pesan dengan prioritas tinggi

*Perintah Owner:*
/addprem [userid] - Menambahkan user premium
/delprem [userid] - Menghapus user premium
/listprem - Melihat daftar user premium
/broadcast [pesan] - Broadcast ke semua user

Untuk menggunakan fitur share, Anda harus menambahkan bot ke 3 group terlebih dahulu.`;
  
  await ctx.reply(helpMessage, { parse_mode: 'Markdown' });
}

async function handleCredit(ctx) {
  try {
    const user = await User.findOne({ userId: ctx.from.id });
    const credit = user ? user.credit : 0;
    
    await ctx.reply(`💳 Kredit Anda: ${credit}`);
  } catch (error) {
    console.error('Error in credit command:', error);
    await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleShare(ctx) {
  try {
    // Check if in private chat
    if (ctx.chat.type !== 'private') {
      await ctx.reply('Perintah share hanya dapat digunakan di private chat.');
      return;
    }
    
    const user = await User.findOne({ userId: ctx.from.id });
    
    // Check if user has joined at least 3 groups
    if (!user || user.joinedGroups.length < 3) {
      await ctx.reply('Anda harus menambahkan bot ke 3 group terlebih dahulu untuk menggunakan fitur share.');
      return;
    }
    
    // Check if user has enough credit
    if (user.credit < 2) {
      await ctx.reply('Kredit Anda tidak cukup. Anda membutuhkan 2 kredit untuk share.');
      return;
    }
    
    // Check if user is replying to a message
    if (!ctx.message.reply_to_message) {
      await ctx.reply('Anda harus membalas pesan yang ingin di-share.');
      return;
    }
    
    // Deduct credit
    user.credit -= 2;
    await user.save();
    
    // Get all groups
    const groups = await Group.find({});
    
    // Share to all groups
    let successCount = 0;
    for (const group of groups) {
      try {
        await ctx.telegram.copyMessage(
          group.groupId,
          ctx.chat.id,
          ctx.message.reply_to_message.message_id
        );
        successCount++;
      } catch (error) {
        console.error(`Error sharing to group ${group.groupId}:`, error);
      }
    }
    
    await ctx.reply(`Pesan berhasil di-share ke ${successCount} group. Kredit berkurang 2.`);
  } catch (error) {
    console.error('Error in share command:', error);
    await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleShareVip(ctx) {
  try {
    // Check if in private chat
    if (ctx.chat.type !== 'private') {
      await ctx.reply('Perintah sharevip hanya dapat digunakan di private chat.');
      return;
    }
    
    const user = await User.findOne({ userId: ctx.from.id });
    
    // Check if user is premium
    if (!user || !user.isPremium) {
      await ctx.reply('Anda harus menjadi user premium untuk menggunakan fitur sharevip.');
      return;
    }
    
    // Check if user is replying to a message
    if (!ctx.message.reply_to_message) {
      await ctx.reply('Anda harus membalas pesan yang ingin di-share.');
      return;
    }
    
    // Get all groups
    const groups = await Group.find({});
    
    // Share to all groups with priority
    let successCount = 0;
    for (const group of groups) {
      try {
        await ctx.telegram.copyMessage(
          group.groupId,
          ctx.chat.id,
          ctx.message.reply_to_message.message_id
        );
        successCount++;
        
        // Add small delay for VIP to ensure delivery priority
        await new Promise(resolve => setTimeout(resolve, 100));
      } catch (error) {
        console.error(`Error sharing to group ${group.groupId}:`, error);
      }
    }
    
    await ctx.reply(`Pesan VIP berhasil di-share ke ${successCount} group.`);
  } catch (error) {
    console.error('Error in sharevip command:', error);
    await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

// Owner commands
async function handleAddPrem(ctx) {
  try {
    // Check if user is owner
    if (ctx.from.id.toString() !== process.env.OWNER_ID) {
      await ctx.reply('Anda tidak memiliki akses ke perintah ini.');
      return;
    }
    
    const userId = ctx.message.text.split(' ')[1];
    if (!userId) {
      await ctx.reply('Gunakan: /addprem [user_id]');
      return;
    }
    
    const user = await User.findOneAndUpdate(
      { userId: parseInt(userId) },
      { isPremium: true },
      { new: true, upsert: true }
    );
    
    await ctx.reply(`User ${userId} sekarang premium.`);
  } catch (error) {
    console.error('Error in addprem command:', error);
    await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleDelPrem(ctx) {
  try {
    // Check if user is owner
    if (ctx.from.id.toString() !== process.env.OWNER_ID) {
      await ctx.reply('Anda tidak memiliki akses ke perintah ini.');
      return;
    }
    
    const userId = ctx.message.text.split(' ')[1];
    if (!userId) {
      await ctx.reply('Gunakan: /delprem [user_id]');
      return;
    }
    
    const user = await User.findOneAndUpdate(
      { userId: parseInt(userId) },
      { isPremium: false }
    );
    
    if (user) {
      await ctx.reply(`User ${userId} tidak lagi premium.`);
    } else {
      await ctx.reply(`User ${userId} tidak ditemukan.`);
    }
  } catch (error) {
    console.error('Error in delprem command:', error);
    await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleListPrem(ctx) {
  try {
    // Check if user is owner
    if (ctx.from.id.toString() !== process.env.OWNER_ID) {
      await ctx.reply('Anda tidak memiliki akses ke perintah ini.');
      return;
    }
    
    const premiumUsers = await User.find({ isPremium: true });
    
    if (premiumUsers.length === 0) {
      await ctx.reply('Tidak ada user premium.');
      return;
    }
    
    let message = '📋 Daftar User Premium:\n\n';
    premiumUsers.forEach(user => {
      message += `👤 ${user.firstName}${user.lastName ? ' ' + user.lastName : ''} (ID: ${user.userId})${user.username ? ' @' + user.username : ''}\n`;
    });
    
    await ctx.reply(message);
  } catch (error) {
    console.error('Error in listprem command:', error);
    await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleBroadcast(ctx) {
  try {
    // Check if user is owner
    if (ctx.from.id.toString() !== process.env.OWNER_ID) {
      await ctx.reply('Anda tidak memiliki akses ke perintah ini.');
      return;
    }
    
    const message = ctx.message.text.split(' ').slice(1).join(' ');
    if (!message) {
      await ctx.reply('Gunakan: /broadcast [pesan]');
      return;
    }
    
    const allUsers = await User.find({});
    let successCount = 0;
    
    for (const user of allUsers) {
      try {
        await ctx.telegram.sendMessage(user.userId, `📢 Broadcast dari Owner:\n\n${message}`);
        successCount++;
        // Add delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 100));
      } catch (error) {
        console.error(`Error broadcasting to user ${user.userId}:`, error);
      }
    }
    
    await ctx.reply(`Broadcast berhasil dikirim ke ${successCount} user.`);
  } catch (error) {
    console.error('Error in broadcast command:', error);
    await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

module.exports = {
  handleStart,
  handleHelp,
  handleCredit,
  handleShare,
  handleShareVip,
  handleAddPrem,
  handleDelPrem,
  handleListPrem,
  handleBroadcast
};