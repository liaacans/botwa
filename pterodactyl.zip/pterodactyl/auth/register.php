<?php
include '../includes/config.php';
include '../includes/functions.php';

// Redirect jika sudah login
if (isset($_SESSION['user_id'])) {
    redirect('../panel.php');
}

$error = '';
$success = '';

// Proses pendaftaran
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $package = $_GET['package'] ?? 'free';
    
    // Validasi
    if (empty($username) || empty($email) || empty($password)) {
        $error = 'Semua field harus diisi';
    } elseif (!isValidEmail($email)) {
        $error = 'Format email tidak valid';
    } elseif ($password !== $confirm_password) {
        $error = 'Konfirmasi password tidak sesuai';
    } elseif (strlen($password) < 6) {
        $error = 'Password minimal 6 karakter';
    } else {
        // Cek apakah email sudah terdaftar di database
        $database = new Database();
        $db = $database->getConnection();
        
        $query = "SELECT id FROM users WHERE email = :email OR username = :username";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        
        if ($stmt->rowCount() > 0) {
            $error = 'Username atau email sudah terdaftar';
        } else {
            // Cek apakah user sudah ada di Pterodactyl
            $pteroUser = checkPterodactylUser($email);
            
            if ($pteroUser && !isset($pteroUser['errors'])) {
                $error = 'Email sudah terdaftar di sistem Pterodactyl';
            } else {
                // Buat user di Pterodactyl
                $pteroPassword = generatePassword();
                $newUser = createPterodactylUser($email, $username, $pteroPassword);
                
                if ($newUser) {
                    $userId = $newUser['attributes']['id'];
                    
                    // Simpan ke database
                    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                    $query = "INSERT INTO users (username, email, password, ptero_user_id, package) VALUES (:username, :email, :password, :ptero_user_id, :package)";
                    $stmt = $db->prepare($query);
                    $stmt->bindParam(':username', $username);
                    $stmt->bindParam(':email', $email);
                    $stmt->bindParam(':password', $hashedPassword);
                    $stmt->bindParam(':ptero_user_id', $userId);
                    $stmt->bindParam(':package', $package);
                    
                    if ($stmt->execute()) {
                        // Buat server untuk paket gratis
                        if ($package === 'free') {
                            $ram = 1024;
                            $disk = 10240;
                            $cpu = 100;
                            
                            $server = createPterodactylServer($userId, $username, $ram, $disk, $cpu);
                            
                            if ($server) {
                                $serverId = $server['attributes']['id'];
                                
                                // Update user dengan server ID
                                $query = "UPDATE users SET ptero_server_id = :server_id WHERE ptero_user_id = :user_id";
                                $stmt = $db->prepare($query);
                                $stmt->bindParam(':server_id', $serverId);
                                $stmt->bindParam(':user_id', $userId);
                                $stmt->execute();
                                
                                // Kirim email
                                $subject = "Akun Panel Pterodactyl Anda";
                                $message = "
                                <h2>Selamat datang di Panel Pterodactyl!</h2>
                                <p>Detail akun Anda:</p>
                                <ul>
                                    <li><strong>URL Panel:</strong> " . DOMAIN . "</li>
                                    <li><strong>Email:</strong> $email</li>
                                    <li><strong>Username:</strong> $username</li>
                                    <li><strong>Password:</strong> $pteroPassword</li>
                                </ul>
                                <p>Silakan login untuk mengelola server Anda.</p>
                                ";
                                
                                sendEmail($email, $subject, $message);
                                
                                $success = 'Pendaftaran berhasil! Silakan login. Detail akun telah dikirim ke email Anda.';
                            } else {
                                $error = 'Gagal membuat server. Silakan hubungi administrator.';
                            }
                        } else {
                            $success = 'Pendaftaran berhasil! Silakan lanjutkan ke pembayaran.';
                            // Redirect ke halaman pembayaran
                            $_SESSION['temp_user'] = [
                                'username' => $username,
                                'email' => $email,
                                'package' => $package
                            ];
                            redirect('../order.php?package=' . $package);
                        }
                    } else {
                        $error = 'Gagal menyimpan data. Silakan coba lagi.';
                    }
                } else {
                    $error = 'Gagal membuat akun di sistem. Silakan coba lagi.';
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar - Panel Pterodactyl</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white text-center">
                        <h3 class="card-title mb-0">Daftar Akun</h3>
                        <?php if (isset($_GET['package']) && $_GET['package'] == 'free'): ?>
                        <p class="mb-0">Paket Gratis 1GB</p>
                        <?php endif; ?>
                    </div>
                    <div class="card-body p-4">
                        <?php if ($error): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <?php if ($success): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                        <?php endif; ?>
                        
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <input type="text" class="form-control" id="username" name="username" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <div class="mb-3">
                                <label for="confirm_password" class="form-label">Konfirmasi Password</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Daftar</button>
                        </form>
                        <div class="text-center mt-3">
                            <p>Sudah punya akun? <a href="login.php">Login di sini</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>