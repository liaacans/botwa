const { User, Group } = require('../lib/database');
const { mainMenuKeyboard, jasherMenuKeyboard, adminMenuKeyboard, backButton } = require('./keyboards');
const { runtime, moment } = require('../lib/utils');

async function handleStart(ctx) {
  const sender = ctx.from.first_name;
  const userTelelu = ctx.from.username || 'No Username';
  const isCreator = ctx.from.id.toString() === process.env.ADMIN_ID;
  
  try {
    // Simpan atau update user data
    let user = await User.findOne({ userId: ctx.from.id });
    if (!user) {
      user = new User({
        userId: ctx.from.id,
        username: ctx.from.username,
        firstName: ctx.from.first_name,
        lastName: ctx.from.last_name,
        credit: 0,
        isPremium: false
      });
      await user.save();
    }
    
    // Kiram pesan dengan gambar dan menu
    await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
      caption: `Hi kak @${sender}
╭─❒ 「 User Info 」 
├ Creator : @${userTelelu}
├ Name : ${sender}
├ Profile : @${userTelelu}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS
├ Platform : Bot Telegram
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreator ? 'True' : 'False'}
Silahkan pilih button dibawah ini!`,
      parse_mode: 'HTML',
      reply_markup: mainMenuKeyboard(isCreator).reply_markup
    });
  } catch (error) {
    console.error('Error in start command:', error);
    ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleHelp(ctx) {
  const helpText = `
🤖 <b>Jasher Bot Help</b>

<b>Perintah yang tersedia:</b>
/start - Memulai bot
/help - Menampilkan bantuan
/credit - Menampilkan credit Anda
/share - Berbagi pesan (hanya di private chat)

<b>Cara menggunakan:</b>
1. Tambahkan bot ke 3 grup untuk mendapatkan 10 kredit
2. Gunakan kredit untuk berbagi pesan ke grup
3. Share free: 2 kredit per broadcast
4. Share VIP: Lebih cepat, untuk user premium

<b>Fitur Premium:</b>
- Prioritas broadcast
- Fitur eksklusif
- Dukungan prioritas
  `;
  
  await ctx.reply(helpText, {
    parse_mode: 'HTML',
    reply_markup: backButton('main_menu').reply_markup
  });
}

async function handleCredit(ctx) {
  try {
    const user = await User.findOne({ userId: ctx.from.id });
    const credit = user ? user.credit : 0;
    
    await ctx.reply(
      `💎 <b>Credit Information</b>\n\n` +
      `Credit Anda: <b>${credit}</b>\n` +
      `Status: ${user && user.isPremium ? '⭐ Premium User' : 'Regular User'}\n\n` +
      `Tambahkan bot ke 3 grup untuk mendapatkan 10 kredit!`,
      {
        parse_mode: 'HTML',
        reply_markup: backButton('main_menu').reply_markup
      }
    );
  } catch (error) {
    console.error('Error in credit command:', error);
    ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

module.exports = {
  handleStart,
  handleHelp,
  handleCredit
};