global.BOT_TOKEN = "8198305874:AAH1Sfr54fyWkPSdfuLQTK_5hSyW69V2C7o";
global.CREATOR_ID = "8135269613";
global.PREMIUM_PRICE = 25000;
global.PREMIUM_DAYS = 30;
global.FREE_TRIAL_DAYS = 3;

// Konfigurasi moderasi default
global.MODERATION_CONFIG = {
    antispam: false,
    noevent: false,
    nolinks: false,
    noforwards: false,
    nocontacts: false,
    nohashtags: false,
    nocommands: false // Default false agar bot tetap bisa menerima command
};

module.exports = {
    BOT_TOKEN: global.BOT_TOKEN,
    CREATOR_ID: global.CREATOR_ID,
    MODERATION_CONFIG: global.MODERATION_CONFIG
};