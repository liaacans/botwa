const { Telegraf, Markup } = require('telegraf');
const config = require('./config');
const database = require('./lib/database');
const { isOwner, isPremium, addUser } = require('./lib/utils');

// Import handlers
const callbackHandlers = require('./src/handlers/callback');
const messageHandlers = require('./src/handlers/message');

// Import command handlers
const userCommands = require('./src/commands/user');
const ownerCommands = require('./src/commands/owner');
const groupCommands = require('./src/commands/group');
const obfuscationCommands = require('./src/commands/obfuscation');

const bot = new Telegraf(config.BOT_TOKEN);


// Load handlers
callbackHandlers(bot);
messageHandlers(bot);


// Middleware untuk logging dan user management
bot.use(async (ctx, next) => {
    console.log(`Received update from ${ctx.from?.id} in ${ctx.chat?.type}`);
    
    if (ctx.from) {
        // Tambahkan user ke database
        addUser(ctx.from.id, ctx.from.username || '');
    }
    
    await next();
});

// Start command dengan menu utama
bot.start(async (ctx) => {
    const userId = ctx.from.id;
    const isCreator = isOwner(userId);
    const sender = ctx.from.username || ctx.from.first_name;
    
    const menuText = `
╭─❒ 「 User Info 」 
├ Owner : ${isCreator ? 'True' : 'False'}
├ Name : ${ctx.from.first_name || ''}
├ Profile : @${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${require('./lib/utils').runtime(process.uptime())}
├ Tanggal Server : ${require('moment-timezone')().tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${require('moment-timezone')().tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`;

    try {
        await ctx.replyWithPhoto(
            'https://f.top4top.io/p_3530xky9e4.jpg',
            {
                caption: menuText,
                parse_mode: 'Markdown',
                ...Markup.inlineKeyboard([
                    [Markup.button.callback('🎯 Jasher Menu', 'jasher_menu')],
                    [Markup.button.callback('👑 Owner Menu', 'owner_menu'), Markup.button.callback('🔒 Obf Menu', 'obf_menu')],
                    [Markup.button.callback('📊 Status', 'status'), Markup.button.callback('ℹ️ Info', 'info')]
                ])
            }
        );
    } catch (error) {
        await ctx.reply(menuText, Markup.inlineKeyboard([
            [Markup.button.callback('🎯 Jasher Menu', 'jasher_menu')],
            [Markup.button.callback('👑 Owner Menu', 'owner_menu'), Markup.button.callback('🔒 Obf Menu', 'obf_menu')],
            [Markup.button.callback('📊 Status', 'status'), Markup.button.callback('ℹ️ Info', 'info')]
        ]));
    }
});

// Help command
bot.help((ctx) => {
    return ctx.replyWithMarkdown(`
🤖 *Jasher Bot Help*

*Main Commands:*
/start - Mulai bot
/help - Bantuan ini
/menu - Tampilkan menu utama
/status - Status bot dan premium

*Obfuscation Commands:*
/enc [days] - Time-locked encryption (1-365 hari)
/enc2 [text] - Custom encryption
/enc3 - Mandarin encryption  
/enc4 - Arab encryption
/enc5 - Siu+Calcrick encryption
/japan - Japanese encryption
/nebula - Nebula encryption
/quantum - Quantum encryption
/var - Var encryption
/zenc - Invisible encryption
/deobfuscate - Deobfuscate file

*Premium Features:*
/sharefree - Share gratis (lambat)
/sharevip - Share VIP (cepat)
/buypremium - Beli premium
/buyscript - Beli script

*Owner Commands:*
/bc [text] - Broadcast ke semua user
/addprem [id] [days] - Tambah premium
/delprem [id] - Hapus premium
/listprem - List user premium
/addbl [id] - Blacklist user
/delbl [id] - Hapus blacklist
/listbl - List blacklist
/listgroup - List grup aktif
    `);
});

// Menu command
bot.command('menu', async (ctx) => {
    const userId = ctx.from.id;
    const isCreator = isOwner(userId);
    const sender = ctx.from.username || ctx.from.first_name;
    
    const menuText = `
╭─❒ 「 User Info 」 
├ Owner : ${isCreator ? 'True' : 'False'}
├ Name : ${ctx.from.first_name || ''}
├ Profile : @${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${require('./lib/utils').runtime(process.uptime())}
├ Tanggal Server : ${require('moment-timezone')().tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${require('moment-timezone')().tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`;

    try {
        await ctx.replyWithPhoto(
            'https://f.top4top.io/p_3530xky9e4.jpg',
            {
                caption: menuText,
                parse_mode: 'Markdown',
                ...Markup.inlineKeyboard([
                    [Markup.button.callback('🎯 Jasher Menu', 'jasher_menu')],
                    [Markup.button.callback('👑 Owner Menu', 'owner_menu'), Markup.button.callback('🔒 Obf Menu', 'obf_menu')],
                    [Markup.button.callback('📊 Status', 'status'), Markup.button.callback('ℹ️ Info', 'info')]
                ])
            }
        );
    } catch (error) {
        await ctx.reply(menuText, Markup.inlineKeyboard([
            [Markup.button.callback('🎯 Jasher Menu', 'jasher_menu')],
            [Markup.button.callback('👑 Owner Menu', 'owner_menu'), Markup.button.callback('🔒 Obf Menu', 'obf_menu')],
            [Markup.button.callback('📊 Status', 'status'), Markup.button.callback('ℹ️ Info', 'info')]
        ]));
    }
});

// Load semua commands
userCommands(bot);
ownerCommands(bot);
groupCommands(bot);
obfuscationCommands(bot);

// Callback query handler
bot.on('callback_query', async (ctx) => {
    const action = ctx.callbackQuery.data;
    const userId = ctx.from.id;
    
    try {
        switch (action) {
            case 'jasher_menu':
                await showJasherMenu(ctx);
                break;
            case 'owner_menu':
                if (isOwner(userId)) {
                    await showOwnerMenu(ctx);
                } else {
                    await ctx.answerCbQuery('❌ Hanya owner yang bisa mengakses menu ini!');
                }
                break;
            case 'obf_menu':
                await showObfMenu(ctx);
                break;
            case 'status':
                await showStatus(ctx);
                break;
            case 'info':
                await showInfo(ctx);
                break;
            case 'back_to_main':
                await ctx.editMessageCaption(
                    await getMainMenuText(ctx),
                    {
                        parse_mode: 'Markdown',
                        ...Markup.inlineKeyboard([
                            [Markup.button.callback('🎯 Jasher Menu', 'jasher_menu')],
                            [Markup.button.callback('👑 Owner Menu', 'owner_menu'), Markup.button.callback('🔒 Obf Menu', 'obf_menu')],
                            [Markup.button.callback('📊 Status', 'status'), Markup.button.callback('ℹ️ Info', 'info')]
                        ])
                    }
                );
                break;
            default:
                await ctx.answerCbQuery('⚠️ Perintah tidak dikenali');
        }
    } catch (error) {
        console.log('Callback error:', error);
        await ctx.answerCbQuery('❌ Terjadi kesalahan');
    }
    
    await ctx.answerCbQuery();
});

// Fungsi menu handlers
async function showJasherMenu(ctx) {
    const menuText = `
🎯 *Jasher Menu*

*Fitur Utama:*
• 🔒 Obfuscation berbagai jenis
• 📤 Share otomatis
• 👥 Multi-group support
• ⚡ Fast processing

*Premium Features:*
• 🚀 Share VIP (cepat)
• 🔑 Akses penuh semua fitur
• 📊 Prioritas processing

Pilih opsi di bawah:`;

    await ctx.editMessageCaption(menuText, {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
            [Markup.button.callback('🔒 Obfuscation', 'obf_menu'), Markup.button.callback('📤 Share', 'share_menu')],
            [Markup.button.callback('💎 Premium Info', 'premium_info'), Markup.button.callback('🛒 Beli Premium', 'buy_premium')],
            [Markup.button.callback('🔙 Kembali', 'back_to_main')]
        ])
    });
}

async function showOwnerMenu(ctx) {
    const stats = database.getStats();
    const menuText = `
👑 *Owner Menu*

*Statistics:*
• 👥 Total Users: ${stats.total_users}
• 💎 Premium Users: ${stats.premium_users}
• 👥 Active Groups: ${stats.active_groups}
• 📊 Total Groups: ${stats.total_groups}

*Owner Commands:*
• /bc - Broadcast message
• /addprem - Tambah premium
• /delprem - Hapus premium
• /addbl - Blacklist user
• /listgroup - List grup aktif`;

    await ctx.editMessageCaption(menuText, {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
            [Markup.button.callback('📊 Stats Detail', 'detailed_stats')],
            [Markup.button.callback('👥 Manage Users', 'manage_users')],
            [Markup.button.callback('🔧 Settings', 'bot_settings')],
            [Markup.button.callback('🔙 Kembali', 'back_to_main')]
        ])
    });
}

async function showObfMenu(ctx) {
    const menuText = `
🔒 *Obfuscation Menu*

*Available Methods:*
1. ⏰ Time-Locked (/enc [days])
2. 🎯 Custom (/enc2 [text])
3. 🇨🇳 Mandarin (/enc3)
4. 🇸🇦 Arab (/enc4)
5. 🎎 Japanese (/japan)
6. 🌌 Nebula (/nebula)
7. ⚛️ Quantum (/quantum)
8. 🔤 Var (/var)
9. 👻 Invisible (/zenc)
10. 🔄 Deobfuscate (/deobfuscate)

*Usage:* Balas file .js dengan command di atas`;

    await ctx.editMessageCaption(menuText, {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
            [Markup.button.callback('⏰ Time-Locked', 'obf_time_locked'), Markup.button.callback('🎯 Custom', 'obf_custom')],
            [Markup.button.callback('🇨🇳 Mandarin', 'obf_mandarin'), Markup.button.callback('🇸🇦 Arab', 'obf_arab')],
            [Markup.button.callback('🎎 Japan', 'obf_japan'), Markup.button.callback('🌌 Nebula', 'obf_nebula')],
            [Markup.button.callback('⚛️ Quantum', 'obf_quantum'), Markup.button.callback('🔤 Var', 'obf_var')],
            [Markup.button.callback('👻 Invisible', 'obf_invisible'), Markup.button.callback('🔄 Deobf', 'obf_deobf')],
            [Markup.button.callback('🔙 Kembali', 'back_to_main')]
        ])
    });
}

async function showStatus(ctx) {
    const userId = ctx.from.id;
    const user = database.getUser(userId);
    const isPrem = isPremium(userId);
    
    const statusText = `
📊 *Status Bot*

*User Info:*
• 🆔 ID: ${userId}
• 💎 Premium: ${isPrem ? '✅ Aktif' : '❌ Non-aktif'}
• 📅 Member sejak: ${user ? require('moment')(user.join_date).format('DD/MM/YY') : 'Baru'}

*Bot Status:*
• 🟢 Online
• ⏰ Uptime: ${require('./lib/utils').runtime(process.uptime())}
• 📊 Total users: ${database.getStats().total_users}`;

    await ctx.editMessageCaption(statusText, {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
            [Markup.button.callback('🔄 Refresh', 'status')],
            [Markup.button.callback('🔙 Kembali', 'back_to_main')]
        ])
    });
}

async function showInfo(ctx) {
    const infoText = `
ℹ️ *Jasher Bot Info*

*Version:* 2.0.0
*Developer:* @ginaaforyou
*Platform:* Node.js Telegraf

*Features:*
• 🔒 Advanced Obfuscation
• 👥 Group Management
• 💎 Premium System
• 📊 Analytics
• ⚡ Fast Processing

*Support:* @ginaaforyou`;

    await ctx.editMessageCaption(infoText, {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
            [Markup.button.callback('📚 Tutorial', 'tutorial')],
            [Markup.button.callback('🔙 Kembali', 'back_to_main')]
        ])
    });
}

async function getMainMenuText(ctx) {
    const userId = ctx.from.id;
    const isCreator = isOwner(userId);
    const sender = ctx.from.username || ctx.from.first_name;
    
    return `
╭─❒ 「 User Info 」 
├ Owner : ${isCreator ? 'True' : 'False'}
├ Name : ${ctx.from.first_name || ''}
├ Profile : @${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${require('./lib/utils').runtime(process.uptime())}
├ Tanggal Server : ${require('moment-timezone')().tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${require('moment-timezone')().tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`;
}

// Error handling
bot.catch((err, ctx) => {
    console.error('Bot error:', err);
    ctx.reply('❌ Terjadi kesalahan sistem. Silakan coba lagi.');
});

// Start bot
bot.launch().then(() => {
    console.log('🤖 Jasher Bot started successfully!');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));