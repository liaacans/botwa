// untuk mengaktifkan access bot nya
// password : KingGanteng
// biar apa? biar bisa jalan botnya

const settings = {
  token: '8201573377:AAH60xRvWdldlE2YbnG6x5M6DeHY9Ix3yIM', // token dari @BotFather
  apikey: 'ptla_cMhsBvy99Yw7EDJa1dE38sNXWLYCKbVznqVYzuS8Avl', // ini gausa di isi, diabaikan saja
  vercelToken: '9c0laRcYJhT7wW6OHWvigJwk', // token vercel
  ownerId: 7568960443, // user id
  dev: 'andinofficial', // wajib username tele
  dana: '085654127071', // nomer dana
  namaDana: 'Akhmad Aulia Rahman', // nama
  chUsn: '@testiandinxdurov', // ch tele
  exPGroupid: -1003011195058, // id group
  exGroupId: -1003011195058, // id group
  
//============= SETTINGS VPS ===============\\
  vpsPublic: "", // ip vps
  pwPublic: "", // pw vps
  vpsPrivate: "", // ip vps
  pwPrivate: "", // pw vps

//============= SETTINGS APIKEY DO ===============\\
  apiDigitalOcean: "APIKEY_DO", // apikey do
  apiDigitalOcean2: "APIKEY_DO2", // apikey do 2
  apiDigitalOcean3: "APIKEY_DO3", // apikey do 3
  
//============= SETTINGS FOTO ===============\\
  pp: 'https://files.catbox.moe/qu6ho9.jpg', // file catbox foto
  ppVid: 'https://files.catbox.moe/2zdg8d.mp4', // file catbox video
  panel: 'https://files.catbox.moe/a7ljii.jpeg', // foto panel
  qris: 'https://files.catbox.moe/vfw5fr.jpg', // qris
  
//============= SETTINGS CPANEL V1 ===============\\
  domain: 'https://naacantik.nefu.life', // domain panel
  plta: 'ptla_rz7QDrA5Xwr2qZOkPg6cwRFMQViYomBaomEdSkzdUWF', // ptla panel
  pltc: 'ptlc_mAXydYDKZfkhMgxxMe4f515VtVV83Crf7w68cng57fi', // ptlc panel
  
//============= SETTINGS CPANEL V2 ===============\\
    // PANEL SERVER 2
  domainV2: '', // domain v2
  pltaV2: '', // plta v2
  pltcV2: '', // ptlc v2

//============= SETTINGS CPANEL V3 ===============\\
    // PANEL SERVER 3
  domainV3: 'ISI_DOMAIN', // domain v3 
  pltaV3: 'ISI_PTLA', // ptla v3
  pltcV3: 'ISI_PTLC', // ptlc v3
  
//============= SETTINGS CPANEL V4 ===============\\
    // PANEL SERVER 4
  domainV4: 'ISI_DOMAIN', // domain v4
  pltaV4: 'ISI_PTLA', // ptla v4
  pltcV4: 'ISI_PTLC', // ptlc v4

//============= SETTINGS CPANEL V5 ===============\\
    // PANEL SERVER 5
  domainV5: 'ISI_DOMAIN', // domain v5
  pltaV5: 'ISI_PTLA', // ptla v5
  pltcV5: 'ISI_PTLC', // ptlc v5
  
//============= SETTINGS LAINNYA ===============\\
  PATH: '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',
  RAW: 'https://raw.githubusercontent.com/liaacans/MyDatabase/refs/heads/main/DB.json',
  API: 'https://api.github.com/repos/liaacans/MyDatabase/contents/DB.json',
  loc: '1',
  eggs: '15',
};

module.exports = settings;