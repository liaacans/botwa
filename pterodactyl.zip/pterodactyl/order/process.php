<?php
include 'includes/config.php';
include 'includes/functions.php';

// Redirect jika belum login
if (!isset($_SESSION['user_id'])) {
    redirect('auth/login.php');
}

// Cek package yang dipilih
$package = $_GET['package'] ?? '';
$packages = [
    '2gb' => ['ram' => 2048, 'disk' => 20480, 'cpu' => 100, 'price' => 25000],
    '3gb' => ['ram' => 3072, 'disk' => 30720, 'cpu' => 150, 'price' => 37500],
    '4gb' => ['ram' => 4096, 'disk' => 40960, 'cpu' => 200, 'price' => 50000],
    '5gb' => ['ram' => 5120, 'disk' => 51200, 'cpu' => 250, 'price' => 62500],
    '6gb' => ['ram' => 6144, 'disk' => 61440, 'cpu' => 300, 'price' => 75000],
    '7gb' => ['ram' => 7168, 'disk' => 71680, 'cpu' => 350, 'price' => 87500],
    '8gb' => ['ram' => 8192, 'disk' => 81920, 'cpu' => 400, 'price' => 100000],
    '9gb' => ['ram' => 9216, 'disk' => 92160, 'cpu' => 450, 'price' => 112500],
    '10gb' => ['ram' => 10240, 'disk' => 102400, 'cpu' => 500, 'price' => 125000],
    'unlimited' => ['ram' => 0, 'disk' => 0, 'cpu' => 0, 'price' => 0]
];

if (!array_key_exists($package, $packages)) {
    redirect('index.php');
}

$selectedPackage = $packages[$package];
$error = '';
$success = '';

// Proses pembayaran
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = trim($_POST['nama']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $paymentMethod = $_POST['paymentMethod'];
    
    // Validasi
    if (empty($nama) || empty($email) || empty($phone) || empty($paymentMethod)) {
        $error = 'Semua field harus diisi';
    } elseif (!isValidEmail($email)) {
        $error = 'Format email tidak valid';
    } else {
        // Proses pembayaran dengan YAB-Group
        $data = [
            'nama' => $nama,
            'email' => $email,
            'phone' => $phone,
            'amount' => $selectedPackage['price'],
            'paymentMethod' => $paymentMethod,
            'produk' => 'Paket ' . $package . ' Panel Pterodactyl'
        ];
        
        $result = processYabPayment($data);
        
        if ($result['status'] == 'success') {
            // Simpan data transaksi ke database
            $database = new Database();
            $db = $database->getConnection();
            
            $query = "INSERT INTO transactions (user_id, package, amount, payment_method, ref_code, status) 
                      VALUES (:user_id, :package, :amount, :payment_method, :ref_code, 'pending')";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':user_id', $_SESSION['user_id']);
            $stmt->bindParam(':package', $package);
            $stmt->bindParam(':amount', $selectedPackage['price']);
            $stmt->bindParam(':payment_method', $paymentMethod);
            $stmt->bindParam(':ref_code', $result['id_reference']);
            
            if ($stmt->execute()) {
                // Redirect ke halaman pembayaran
                header('Location: ' . $result['checkout_url']);
                exit();
            } else {
                $error = 'Gagal menyimpan data transaksi';
            }
        } else {
            $error = $result['message'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pembayaran - Panel Pterodactyl</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white text-center">
                        <h3 class="card-title mb-0">Pembayaran Paket <?php echo strtoupper($package); ?></h3>
                    </div>
                    <div class="card-body p-4">
                        <?php if ($error): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <h5>Detail Paket</h5>
                                <ul class="list-group">
                                    <li class="list-group-item">RAM: <?php echo number_format($selectedPackage['ram'] / 1024, 1); ?> GB</li>
                                    <li class="list-group-item">Disk: <?php echo number_format($selectedPackage['disk'] / 1024, 1); ?> GB</li>
                                    <li class="list-group-item">CPU: <?php echo $selectedPackage['cpu']; ?>%</li>
                                    <li class="list-group-item">Harga: Rp <?php echo number_format($selectedPackage['price'], 0, ',', '.'); ?></li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <h5>Informasi Pembayaran</h5>
                                <p>Setelah pembayaran berhasil, server akan dibuat secara otomatis dan detail login akan dikirim ke email Anda.</p>
                            </div>
                        </div>
                        
                        <form method="POST" action="">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="nama" class="form-label">Nama Lengkap</label>
                                    <input type="text" class="form-control" id="nama" name="nama" value="<?php echo $_SESSION['username']; ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" value="<?php echo $_SESSION['email']; ?>" required>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="form-label">Nomor Telepon</label>
                                <input type="text" class="form-control" id="phone" name="phone" required>
                            </div>
                            <div class="mb-3">
                                <label for="paymentMethod" class="form-label">Metode Pembayaran</label>
                                <select class="form-select" id="paymentMethod" name="paymentMethod" required>
                                    <option value="">Pilih Metode Pembayaran</option>
                                    <option value="qris">QRIS</option>
                                    <option value="bca">BCA</option>
                                    <option value="bni">BNI</option>
                                    <option value="bri">BRI</option>
                                    <option value="mandiri">Mandiri</option>
                                    <option value="gopay">GoPay</option>
                                    <option value="ovo">OVO</option>
                                    <option value="dana">DANA</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Bayar Sekarang</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>