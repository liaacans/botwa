const { Telegraf } = require('telegraf');
const { ImapFlow } = require('imapflow');
const nodemailer = require('nodemailer');
const { simpleParser } = require('mailparser');

// Konfigurasi
const BOT_TOKEN = '7569137877:AAHnvva5p9SFclkDpDio8QcJsSfbzlrK6IY'; // Ganti dengan token bot Anda
const ALLOWED_GROUP_ID = '-1002793801544';
const EMAIL_CONFIG = {
  imap: {
    host: 'newpinwheel.indowebsite.net',
    port: 993,
    auth: {
      user: 'nokosmerah@buatkamu.web.id',
      pass: 'Grki6Vv1gdlA'
    }
  },
  smtp: {
    host: 'newpinwheel.indowebsite.net',
    port: 587,
    secure: false,
    auth: {
      user: 'nokosmerah@buatkamu.web.id',
      pass: 'Grki6Vv1gdlA'
    }
  }
};

const bot = new Telegraf(BOT_TOKEN);
let imapClient = null;
let processedEmails = new Set();

// Setup transporter untuk mengirim email
const transporter = nodemailer.createTransporter({
  host: EMAIL_CONFIG.smtp.host,
  port: EMAIL_CONFIG.smtp.port,
  secure: EMAIL_CONFIG.smtp.secure,
  auth: EMAIL_CONFIG.smtp.auth
});

// Fungsi untuk koneksi IMAP
async function connectIMAP() {
  try {
    imapClient = new ImapFlow({
      host: EMAIL_CONFIG.imap.host,
      port: EMAIL_CONFIG.imap.port,
      secure: true,
      auth: EMAIL_CONFIG.imap.auth
    });

    await imapClient.connect();
    console.log('Connected to IMAP server');

    // Setup mailbox monitoring
    await imapClient.mailboxOpen('INBOX');
    
    // Monitor untuk email baru
    setInterval(checkNewEmails, 30000); // Cek setiap 30 detik
    await checkNewEmails(); // Cek email saat startup
    
  } catch (error) {
    console.error('IMAP Connection error:', error);
    setTimeout(connectIMAP, 60000); // Coba lagi setelah 1 menit
  }
}

// Fungsi untuk memeriksa email baru
async function checkNewEmails() {
  if (!imapClient) return;

  try {
    // Cari email yang belum dibaca
    const messages = await imapClient.search({ seen: false });
    
    for (const seq of messages) {
      const message = await imapClient.fetchOne(seq, { 
        source: true, 
        flags: true 
      });
      
      const emailId = message.uid.toString();
      
      // Hindari memproses email yang sudah diproses
      if (processedEmails.has(emailId)) continue;
      
      const parsed = await simpleParser(message.source);
      
      // Kirim notifikasi ke grup
      await sendEmailNotification(parsed);
      
      // Tandai sebagai sudah dibaca
      await imapClient.messageFlagsAdd(seq, '\\Seen');
      
      // Tambahkan ke set email yang sudah diproses
      processedEmails.add(emailId);
      
      console.log('Processed new email:', emailId);
    }
    
    // Bersihkan set yang sudah lama (opsional, untuk menghindari memory leak)
    if (processedEmails.size > 1000) {
      const array = Array.from(processedEmails);
      processedEmails = new Set(array.slice(-500));
    }
    
  } catch (error) {
    console.error('Error checking emails:', error);
  }
}

// Fungsi untuk mengirim notifikasi email ke grup
async function sendEmailNotification(email) {
  try {
    const message = `
📧 *Email Baru*

*Dari:* ${email.from?.text || 'Unknown'}
*Kepada:* ${email.to?.text || 'Unknown'}
*Subjek:* ${email.subject || 'No Subject'}

${email.text ? `*Isi:*\n${email.text.substring(0, 1000)}...` : 'Tidak ada teks'}
    `.trim();

    await bot.telegram.sendMessage(ALLOWED_GROUP_ID, message, {
      parse_mode: 'Markdown'
    });
    
  } catch (error) {
    console.error('Error sending notification:', error);
  }
}

// Command untuk mengirim email
bot.command('sendmail', async (ctx) => {
  // Cek jika di grup yang diizinkan
  if (ctx.chat.id.toString() !== ALLOWED_GROUP_ID) {
    await ctx.reply('❌ Bot hanya dapat digunakan di grup tertentu.');
    return;
  }

  const args = ctx.message.text.split(' ').slice(1);
  if (args.length < 2) {
    await ctx.reply('❌ Format: /sendmail <email_tujuan> <subjek> <isi_pesan>');
    return;
  }

  const toEmail = args[0];
  const subject = args[1];
  const body = args.slice(2).join(' ');

  try {
    const mailOptions = {
      from: EMAIL_CONFIG.imap.auth.user,
      to: toEmail,
      subject: subject,
      text: body
    };

    await transporter.sendMail(mailOptions);
    await ctx.reply('✅ Email berhasil dikirim!');
    
  } catch (error) {
    console.error('Send email error:', error);
    await ctx.reply('❌ Gagal mengirim email: ' + error.message);
  }
});

// Handler untuk ketika bot ditambahkan ke grup
bot.on('chat_member', async (ctx) => {
  const chatMember = ctx.chatMember;
  const chatId = ctx.chat.id.toString();
  
  if (chatMember.new_chat_member.status === 'member' && 
      chatMember.new_chat_member.user.id === ctx.botInfo.id) {
    
    if (chatId !== ALLOWED_GROUP_ID) {
      await ctx.leaveChat();
      console.log(`Left unauthorized group: ${chatId}`);
    }
  }
});

// Handler untuk pesan selain command
bot.on('message', async (ctx) => {
  // Jika bukan di grup yang diizinkan, abaikan
  if (ctx.chat.id.toString() !== ALLOWED_GROUP_ID) return;
  
  // Jika ada reply ke pesan notifikasi email, kirim balasan
  if (ctx.message.reply_to_message) {
    const repliedMessage = ctx.message.reply_to_message;
    
    // Cek jika pesan yang di-reply adalah notifikasi email
    if (repliedMessage.text && repliedMessage.text.includes('📧 Email Baru')) {
      const emailMatch = repliedMessage.text.match(/Dari:\s*(.*?)\n/);
      if (emailMatch && emailMatch[1]) {
        const fromEmail = emailMatch[1].trim();
        const replyText = ctx.message.text;
        
        try {
          const mailOptions = {
            from: EMAIL_CONFIG.imap.auth.user,
            to: fromEmail,
            subject: 'Re: ' + (repliedMessage.text.match(/Subjek:\s*(.*?)\n/) || [''])[1].trim(),
            text: replyText
          };

          await transporter.sendMail(mailOptions);
          await ctx.reply('✅ Balasan email berhasil dikirim!');
          
        } catch (error) {
          console.error('Reply email error:', error);
          await ctx.reply('❌ Gagal mengirim balasan email: ' + error.message);
        }
      }
    }
  }
});

// Startup bot
async function startBot() {
  try {
    console.log('Starting Telegram bot...');
    await bot.launch();
    console.log('Bot started successfully');
    
    // Mulai koneksi IMAP
    await connectIMAP();
    
    // Enable graceful stop
    process.once('SIGINT', () => bot.stop('SIGINT'));
    process.once('SIGTERM', () => bot.stop('SIGTERM'));
    
  } catch (error) {
    console.error('Failed to start bot:', error);
    process.exit(1);
  }
}

startBot();