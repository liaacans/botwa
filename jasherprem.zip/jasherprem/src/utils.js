const moment = require('moment-timezone');

function runtime(seconds) {
    seconds = Math.floor(seconds);
    const days = Math.floor(seconds / (3600 * 24));
    seconds -= days * 3600 * 24;
    const hours = Math.floor(seconds / 3600);
    seconds -= hours * 3600;
    const minutes = Math.floor(seconds / 60);
    seconds -= minutes * 60;
    
    return `${days}d ${hours}h ${minutes}m ${seconds}s`;
}

function formatUserInfo(ctx, user, isCreator) {
    const sender = ctx.from.first_name || ctx.from.username || 'User';
    const userTelelu = ctx.from.username ? `@${ctx.from.username}` : 'Tidak ada';
    
    return `Hi kak @${sender}
╭─❒ 「 User Info 」 
├ Creator : @${userTelelu}
├ Name : ${sender}
├ Profile : ${userTelelu}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : Linux
├ Platform : Bot Telegram
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Premium : ${user.isPremium ? 'True' : 'False'}
Silahkan pilih button dibawah ini!`;
}

module.exports = { runtime, formatUserInfo };