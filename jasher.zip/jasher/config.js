global.BOT_TOKEN = process.env.BOT_TOKEN || 'YOUR_BOT_TOKEN_HERE';
global.ADMIN_ID = process.env.ADMIN_ID || 'YOUR_ADMIN_ID_HERE';

module.exports = {
    BOT_TOKEN: global.BOT_TOKEN,
    ADMIN_ID: global.ADMIN_ID
};