const { Markup } = require('telegraf');
const { isPremium, getPremiumDaysLeft, runtime, formatDate } = require('../lib/utils');
const { obfuscateTimeLocked, obfuscateQuantum } = require('./obf');

// Handle messages
async function handleMessage(ctx) {
  const userId = ctx.from.id;
  const text = ctx.message.text;
  const chatType = ctx.chat.type;
  
  // Handle private chat only for certain features
  if (chatType === 'private') {
    // Check if user is replying to obfuscation request
    if (ctx.session && ctx.session.waitingForObfCode) {
      const obfType = ctx.session.obfType;
      const days = ctx.session.obfDays;
      
      try {
        let obfuscatedCode;
        
        if (obfType === 'time_locked') {
          obfuscatedCode = await obfuscateTimeLocked(text, days);
        } else if (obfType === 'quantum') {
          obfuscatedCode = await obfuscateQuantum(text);
        }
        
        ctx.reply('✅ Obfuscation berhasil! Kode hasil obfuscation:\n\n' + 
                 '```javascript\n' + obfuscatedCode + '\n```', {
          parse_mode: 'Markdown',
          reply_markup: Markup.inlineKeyboard([
            [Markup.button.callback('Kembali ke Menu', 'main_menu')]
          ])
        });
        
        // Clear session
        ctx.session.waitingForObfCode = false;
        ctx.session.obfType = null;
        ctx.session.obfDays = null;
      } catch (error) {
        ctx.reply('❌ Gagal melakukan obfuscation: ' + error.message);
      }
    }
  }
  
  // Handle group messages for adding groups
  if (chatType === 'group' || chatType === 'supergroup') {
    const groupId = ctx.chat.id;
    const groupName = ctx.chat.title;
    const userId = ctx.from.id;
    
    // Check if group is already added
    const existingGroup = await global.db.getGroup(groupId);
    if (!existingGroup) {
      // Add group to database
      await global.db.addGroup(groupId, groupName, userId);
      
      // Update user's group count
      const user = await global.db.getUser(userId);
      const newCount = (user ? user.groups_added || 0 : 0) + 1;
      await global.db.updateUserGroups(userId, newCount);
      
      // Add premium if user reached requirement
      if (newCount >= global.groupRequirements && !isPremium(userId)) {
        await global.db.setPremium(userId, global.premiumDaysPerGroup);
        ctx.reply(`🎉 Selamat! Anda telah menambahkan ${newCount} group dan mendapatkan ${global.premiumDaysPerGroup} hari premium!`);
      }
    }
  }
}

// Handle callback queries
async function handleCallbackQuery(ctx) {
  const data = ctx.callbackQuery.data;
  const userId = ctx.from.id;
  const isCreator = userId.toString() === global.DEVELOPER_ID;
  
  switch (data) {
    case 'main_menu':
      await ctx.deleteMessage();
      await require('./commands').menu(ctx);
      break;
      
    case 'jasher_menu':
      await ctx.editMessageCaption({
        caption: `*Jasher Menu*

Pilih fitur yang ingin digunakan:

🔒 *Obfuscation* - Obfuscate kode JavaScript
📤 *Share* - Share ke group
👥 *Group Management* - Kelola group
ℹ️ *Info* - Info akun dan premium

Gunakan button dibawah untuk navigasi:`,
        parse_mode: 'Markdown',
        reply_markup: Markup.inlineKeyboard([
          [Markup.button.callback('Obfuscation', 'obf_menu')],
          [Markup.button.callback('Share ke Group', 'share_menu')],
          [Markup.button.callback('Info Akun', 'account_info')],
          [Markup.button.callback('Kembali', 'main_menu')]
        ])
      });
      break;
      
    case 'owner_menu':
      if (!isCreator) {
        await ctx.answerCbQuery('❌ Anda bukan owner bot!');
        return;
      }
      
      await ctx.editMessageCaption({
        caption: `*Owner Menu*

Pilih fitur owner yang ingin digunakan:

👑 *Premium Management* - Kelola premium user
🚫 *Blacklist* - Kelola blacklist group
🤖 *AutoJasher* - Pengaturan AutoJasher
📊 *Group Stats* - Statistik group

Gunakan button dibawah untuk navigasi:`,
        parse_mode: 'Markdown',
        reply_markup: Markup.inlineKeyboard([
          [Markup.button.callback('Premium Management', 'premium_management')],
          [Markup.button.callback('Blacklist Management', 'blacklist_management')],
          [Markup.button.callback('AutoJasher Settings', 'autojasher_settings')],
          [Markup.button.callback('Group Stats', 'group_stats')],
          [Markup.button.callback('Kembali', 'main_menu')]
        ])
      });
      break;
      
    case 'obf_menu':
      await ctx.editMessageCaption({
        caption: `*Obfuscation Menu*

Pilih jenis obfuscation yang diinginkan:

1. *Time-Locked Encryption* - Obfuscation dengan masa aktif tertentu
2. *Quantum Vortex Encryption* - Obfuscation tingkat tinggi dengan fitur self-evolving

Balas pesan ini dengan kode JavaScript yang ingin di-obfuscate, lalu pilih jenis obfuscation.`,
        parse_mode: 'Markdown',
        reply_markup: Markup.inlineKeyboard([
          [Markup.button.callback('Time-Locked Encryption', 'obf_time_locked')],
          [Markup.button.callback('Quantum Vortex Encryption', 'obf_quantum')],
          [Markup.button.callback('Kembali', 'jasher_menu')]
        ])
      });
      break;
      
    case 'obf_time_locked':
      if (!ctx.session) ctx.session = {};
      ctx.session.waitingForObfCode = true;
      ctx.session.obfType = 'time_locked';
      ctx.session.obfDays = 30; // Default 30 days
      
      await ctx.editMessageText('⏰ *Time-Locked Encryption*\n\nSilakan kirim kode JavaScript yang ingin di-obfuscate. Obfuscation ini akan memiliki masa aktif 30 hari.', {
        parse_mode: 'Markdown',
        reply_markup: Markup.inlineKeyboard([
          [Markup.button.callback('Batal', 'obf_menu')]
        ])
      });
      break;
      
    case 'obf_quantum':
      if (!ctx.session) ctx.session = {};
      ctx.session.waitingForObfCode = true;
      ctx.session.obfType = 'quantum';
      
      await ctx.editMessageText('🌀 *Quantum Vortex Encryption*\n\nSilakan kirim kode JavaScript yang ingin di-obfuscate. Obfuscation ini menggunakan algoritma quantum dengan fitur self-evolving.', {
        parse_mode: 'Markdown',
        reply_markup: Markup.inlineKeyboard([
          [Markup.button.callback('Batal', 'obf_menu')]
        ])
      });
      break;
      
    case 'account_info':
      const user = await global.db.getUser(userId);
      const premiumStatus = isPremium(userId) ? `Aktif (${getPremiumDaysLeft(userId)} hari tersisa)` : 'Tidak Aktif';
      const groups = await global.db.getUserGroups(userId);
      
      const infoText = `*Info Akun*

👤 Nama: ${user.first_name}${user.last_name ? ' ' + user.last_name : ''}
📧 Username: @${user.username || 'tidak ada'}
🆔 ID: ${userId}
⭐ Status Premium: ${premiumStatus}
📊 Group Ditambahkan: ${user.groups_added || 0}
📈 Group Aktif: ${groups.length}

${isPremium(userId) ? '🎉 Nikmati fitur premium!' : '💡 Tambahkan 3 group untuk mendapatkan premium!'}`;

      await ctx.editMessageText(infoText, {
        parse_mode: 'Markdown',
        reply_markup: Markup.inlineKeyboard([
          [Markup.button.callback('Kembali', 'jasher_menu')]
        ])
      });
      break;
      
    case 'premium_management':
      if (!isCreator) {
        await ctx.answerCbQuery('❌ Anda bukan owner bot!');
        return;
      }
      
      await ctx.editMessageText('*Premium Management*\n\nGunakan command berikut:\n\n/addprem [user_id] [days] - Tambah premium user\n/delprem [user_id] - Hapus premium user\n/listprem - List semua premium user', {
        parse_mode: 'Markdown',
        reply_markup: Markup.inlineKeyboard([
          [Markup.button.callback('Kembali', 'owner_menu')]
        ])
      });
      break;
      
    case 'blacklist_management':
      if (!isCreator) {
        await ctx.answerCbQuery('❌ Anda bukan owner bot!');
        return;
      }
      
      await ctx.editMessageText('*Blacklist Management*\n\nGunakan command berikut:\n\n/addbl [group_id] [reason] - Tambah group ke blacklist\n/delbl [group_id] - Hapus group dari blacklist\n/listbl - List semua blacklisted group', {
        parse_mode: 'Markdown',
        reply_markup: Markup.inlineKeyboard([
          [Markup.button.callback('Kembali', 'owner_menu')]
        ])
      });
      break;
      
    case 'autojasher_settings':
      if (!isCreator) {
        await ctx.answerCbQuery('❌ Anda bukan owner bot!');
        return;
      }
      
      const settings = await global.db.getAutoJasherSettings();
      const status = settings.is_active ? `Aktif (${settings.interval_minutes} menit)` : 'Tidak Aktif';
      const lastRun = settings.last_run ? formatDate(settings.last_run) : 'Belum pernah dijalankan';
      
      await ctx.editMessageText(`*AutoJasher Settings*

Status: ${status}
Interval: ${settings.interval_minutes} menit
Terakhir dijalankan: ${lastRun}

Gunakan command berikut:
/autojasher [interval] - Aktifkan AutoJasher
/stopautojasher - Matikan AutoJasher`, {
        parse_mode: 'Markdown',
        reply_markup: Markup.inlineKeyboard([
          [Markup.button.callback('Kembali', 'owner_menu')]
        ])
      });
      break;
      
    case 'group_stats':
      if (!isCreator) {
        await ctx.answerCbQuery('❌ Anda bukan owner bot!');
        return;
      }
      
      const allGroups = await global.db.getAllGroups();
      const allUsers = await global.db.getAllPremiumUsers();
      
      await ctx.editMessageText(`*Group Stats*

Total Group: ${allGroups.length}
Total Premium Users: ${allUsers.length}
Total Active Users: ${(await global.db.getAllUsers()).length}

Gunakan command /listgroup untuk melihat daftar group`, {
        parse_mode: 'Markdown',
        reply_markup: Markup.inlineKeyboard([
          [Markup.button.callback('Kembali', 'owner_menu')]
        ])
      });
      break;
      
    case 'share_menu':
      if (!isPremium(userId)) {
        await ctx.editMessageText('❌ Fitur ini hanya untuk user premium!\n\nTambahkan 3 group untuk mendapatkan premium.', {
          reply_markup: Markup.inlineKeyboard([
            [Markup.button.callback('Kembali', 'jasher_menu')]
          ])
        });
        return;
      }
      
      await ctx.editMessageText('*Share Menu*\n\nBalas pesan dengan teks yang ingin di-share ke group, lalu gunakan command /sharevip untuk share cepat.', {
        parse_mode: 'Markdown',
        reply_markup: Markup.inlineKeyboard([
          [Markup.button.callback('Kembali', 'jasher_menu')]
        ])
      });
      break;
      
    default:
      await ctx.answerCbQuery('❌ Perintah tidak dikenali');
  }
  
  await ctx.answerCbQuery();
}

module.exports = {
  handleMessage,
  handleCallbackQuery
};