const { User, Group } = require('../lib/database');
const { formatUserInfo } = require('../lib/utils');
const { mainMenuKeyboard, jasherMenuKeyboard, ownerMenuKeyboard, backKeyboard } = require('./keyboards');
const { 
    handleStart, 
    handleHelp, 
    handleCredit, 
    handleShare, 
    handleShareVip, 
    handleAddPrem, 
    handleDelPrem, 
    handleListPrem, 
    handleBroadcast 
} = require('./commands');

async function handleTextMessage(ctx) {
    const text = ctx.message.text;
    const userId = ctx.from.id;
    
    switch (text) {
        case 'Jasher Menu':
            await ctx.reply('Pilih menu Jasher:', jasherMenuKeyboard());
            break;
            
        case 'Owner Menu':
            // Cek apakah owner
            if (userId.toString() === process.env.OWNER_ID) {
                await ctx.reply('Pilih menu Owner:', ownerMenuKeyboard());
            } else {
                await ctx.reply('Anda bukan owner bot!', mainMenuKeyboard());
            }
            break;
            
        case 'Kembali':
            await ctx.reply('Kembali ke menu utama', mainMenuKeyboard());
            break;
            
        case 'AddGroup':
            await ctx.reply('Untuk menambahkan group, undang bot @jasherbot ke group Anda dan kirim /start di group tersebut.', backKeyboard());
            break;
            
        case 'Owner':
            await ctx.replyWithHTML('Owner bot: <a href="https://t.me/username_owner">@username_owner</a>', backKeyboard());
            break;
            
        case 'Credit':
            await handleCredit(ctx);
            break;
            
        case 'Share':
            await handleShare(ctx);
            break;
            
        case 'ShareVIP':
            await handleShareVip(ctx);
            break;
            
        case 'Broadcast':
            await handleBroadcast(ctx);
            break;
            
        case 'AddPrem':
            await handleAddPrem(ctx);
            break;
            
        case 'DelPrem':
            await handleDelPrem(ctx);
            break;
            
        case 'ListPrem':
            await handleListPrem(ctx);
            break;
            
        default:
            // Jika tidak ada yang cocok, kirim menu utama
            const user = await User.findOne({ userId });
            if (user) {
                const message = formatUserInfo(ctx, user);
                await ctx.replyWithHTML(message, mainMenuKeyboard());
            } else {
                await handleStart(ctx);
            }
            break;
    }
}

async function handleNewChatMembers(ctx) {
    // Ketika bot ditambahkan ke group
    if (ctx.message.new_chat_members.some(member => member.is_bot && member.username === ctx.botInfo.username)) {
        const chat = ctx.chat;
        
        try {
            // Simpan info group ke database
            const groupData = {
                groupId: chat.id.toString(),
                groupName: chat.title,
                groupUsername: chat.username || '',
                memberCount: await ctx.getChatMembersCount(),
                addedBy: ctx.from.id
            };
            
            let group = await Group.findOne({ groupId: groupData.groupId });
            if (!group) {
                group = new Group(groupData);
                await group.save();
                
                // Tambah credit untuk user yang menambahkan bot
                await User.updateOne(
                    { userId: ctx.from.id },
                    { 
                        $inc: { credit: 10 },
                        $addToSet: { joinedGroups: groupData.groupId }
                    }
                );
                
                await ctx.reply(`Terima kasih telah menambahkan saya ke group ini! 10 credit telah ditambahkan ke akun @${ctx.from.username || ctx.from.first_name}`);
            }
        } catch (error) {
            console.error('Error saving group info:', error);
        }
    }
}

module.exports = {
    handleTextMessage,
    handleNewChatMembers
};