/*
*Dibuat oleh aulia rahman
*Ditambahkan fitur fiturnya oleh ginaa septiana ramadhani
Base Ori Rahman x Gina septiana ramadhani

Sosmed media :
Ig : @4xglrs_
Tele : @ginaabaikhati
Wa : Privet
Yt : A. Aulia Rahman Official (@auliarhmanproduction)

Thanks too::
Allah swt
Nabi Muhammad
Ortu
Aulia Rahman
Ginaa septiana ramadhani
And Pengguna Copy/Paste:v

Note : don't remove copyright of this script!



Eh jangan lupa ini diganti yaawww🌹
// Ganti ini:
const obfuscated = await JsConfuser.obfuscate(fileContent, getJapanObfuscationConfig());

// Menjadi ini:
const obfuscatedCode = await safeObfuscate(fileContent, getJapanObfuscationConfig(), 'Mandarin');
biar tidak error kalau mau enc / dec disitu ada decode sih:v
*/



const { Telegraf, Markup } = require('telegraf');
const moment = require('moment-timezone');
const JsConfuser = require('js-confuser');
const fetch = require('node-fetch');
const fs = require('fs-extra');
const path = require('path');

const { 
  addUser, 
  getUser, 
  addGroup, 
  removeGroup, 
  getActiveGroups,
  addPremium, 
  removePremium, 
  getAllPremium,
  addBlacklist, 
  removeBlacklist, 
  getAllBlacklist 
} = require('../lib/database');

const { 
  createProgressBar, 
  updateProgress, 
  runtime, 
  log, 
  isPremium, 
  isBlacklisted 
} = require('../lib/utils');

const {
  obfuscateTimeLocked,
  obfuscateQuantum,
  getSiuCalcrickObfuscationConfig,
  getCustomObfuscationConfig,
  getNebulaObfuscationConfig,
  getNovaObfuscationConfig,
  getStrongObfuscationConfig,
  getArabObfuscationConfig,
  getJapanxArabObfuscationConfig,
  getJapanObfuscationConfig
} = require('./obf');

// Inisialisasi bot
const bot = new Telegraf(BOT_TOKEN);

// Command handlers
function setupCommands() {
  // Command start
  bot.start(async (ctx) => {
    const userId = ctx.from.id;
    const username = ctx.from.username || 'Tidak ada';
    const isCreator = userId.toString() === global.DEVELOPER_ID;
    
    addUser(userId);
    
    const menuMessage = `
╭─❒ 「 User Info 」 
├ Creator : ${global.DEVELOPER_USERNAME}
├ Name : @${username}
├ Profile : @${ctx.from.first_name}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreator ? 'True' : 'False'}
Silahkan pilih button dibawah ini!`;

    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('Jasher Menu', 'jasher_menu')],
      [Markup.button.callback('Obf Menu', 'obf_menu')],
      [Markup.button.callback('Owner', 'owner_menu')]
    ]);

    try {
      await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
        caption: menuMessage,
        parse_mode: 'Markdown',
        ...keyboard
      });
    } catch (error) {
      await ctx.reply(menuMessage, {
        parse_mode: 'Markdown',
        ...keyboard
      });
    }
  });

  // Command menu
  bot.command('menu', async (ctx) => {
    const userId = ctx.from.id;
    const username = ctx.from.username || 'Tidak ada';
    const isCreator = userId.toString() === global.DEVELOPER_ID;
    
    const menuMessage = `
╭─❒ 「 User Info 」 
├ Creator : ${global.DEVELOPER_USERNAME}
├ Name : @${username}
├ Profile : @${ctx.from.first_name}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreator ? 'True' : 'False'}
Silahkan pilih button dibawah ini!`;

    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('Jasher Menu', 'jasher_menu')],
      [Markup.button.callback('Obf Menu', 'obf_menu')],
      [Markup.button.callback('Owner', 'owner_menu')]
    ]);

    try {
      await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
        caption: menuMessage,
        parse_mode: 'Markdown',
        ...keyboard
      });
    } catch (error) {
      await ctx.reply(menuMessage, {
        parse_mode: 'Markdown',
        ...keyboard
      });
    }
  });

  // Command untuk menambah premium
  bot.command('addprem', async (ctx) => {
    if (ctx.from.id.toString() !== global.DEVELOPER_ID) {
      return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
    }
    
    const args = ctx.message.text.split(' ');
    if (args.length < 3) {
      return ctx.reply('❌ Format: /addprem <user_id> <jumlah_hari>');
    }
    
    const userId = args[1];
    const days = parseInt(args[2]);
    
    if (isNaN(days) || days < 1) {
      return ctx.reply('❌ Jumlah hari harus angka positif!');
    }
    
    addPremium(userId, days);
    const expiryDate = new Date(Date.now() + (days * 24 * 60 * 60 * 1000));
    
    ctx.reply(`✅ Premium berhasil ditambahkan untuk user ${userId} selama ${days} hari.\n⏰ Kedaluwarsa: ${expiryDate.toLocaleDateString()}`);
  });

  // Command untuk menghapus premium
  bot.command('delprem', async (ctx) => {
    if (ctx.from.id.toString() !== global.DEVELOPER_ID) {
      return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
    }
    
    const args = ctx.message.text.split(' ');
    if (args.length < 2) {
      return ctx.reply('❌ Format: /delprem <user_id>');
    }
    
    const userId = args[1];
    const removed = removePremium(userId);
    
    if (removed) {
      ctx.reply(`✅ Premium berhasil dihapus untuk user ${userId}`);
    } else {
      ctx.reply(`❌ User ${userId} tidak memiliki premium`);
    }
  });

  // Command untuk melihat list premium
  bot.command('listprem', async (ctx) => {
    if (ctx.from.id.toString() !== global.DEVELOPER_ID) {
      return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
    }
    
    const premiumData = getAllPremium();
    if (Object.keys(premiumData).length === 0) {
      return ctx.reply('❌ Tidak ada user premium');
    }
    
    let message = '📋 Daftar User Premium:\n\n';
    for (const userId in premiumData) {
      const userData = premiumData[userId];
      const expiryDate = new Date(userData.expiry);
      const remainingDays = Math.ceil((userData.expiry - Date.now()) / (24 * 60 * 60 * 1000));
      
      message += `👤 User ID: ${userId}\n⏰ Kedaluwarsa: ${expiryDate.toLocaleDateString()}\n📅 Sisa hari: ${remainingDays}\n\n`;
    }
    
    ctx.reply(message);
  });

  // Command untuk menambah blacklist
  bot.command('addbl', async (ctx) => {
    if (ctx.from.id.toString() !== global.DEVELOPER_ID) {
      return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
    }
    
    const args = ctx.message.text.split(' ');
    if (args.length < 2) {
      return ctx.reply('❌ Format: /addbl <user_id>');
    }
    
    const userId = args[1];
    addBlacklist(userId);
    
    ctx.reply(`✅ User ${userId} berhasil ditambahkan ke blacklist`);
  });

  // Command untuk menghapus blacklist
  bot.command('delbl', async (ctx) => {
    if (ctx.from.id.toString() !== global.DEVELOPER_ID) {
      return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
    }
    
    const args = ctx.message.text.split(' ');
    if (args.length < 2) {
      return ctx.reply('❌ Format: /delbl <user_id>');
    }
    
    const userId = args[1];
    const removed = removeBlacklist(userId);
    
    if (removed) {
      ctx.reply(`✅ User ${userId} berhasil dihapus dari blacklist`);
    } else {
      ctx.reply(`❌ User ${userId} tidak ada dalam blacklist`);
    }
  });

  // Command untuk melihat list blacklist
  bot.command('listbl', async (ctx) => {
    if (ctx.from.id.toString() !== global.DEVELOPER_ID) {
      return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
    }
    
    const blacklistData = getAllBlacklist();
    if (blacklistData.length === 0) {
      return ctx.reply('✅ Tidak ada user dalam blacklist');
    }
    
    let message = '📋 Daftar User Blacklist:\n\n';
    blacklistData.forEach((userId, index) => {
      message += `${index + 1}. ${userId}\n`;
    });
    
    ctx.reply(message);
  });

  // Command untuk melihat list grup
  bot.command('listgrup', async (ctx) => {
    if (ctx.from.id.toString() !== global.DEVELOPER_ID) {
      return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
    }
    
    const groups = getActiveGroups();
    if (groups.length === 0) {
      return ctx.reply('❌ Tidak ada grup aktif');
    }
    
    let message = '📋 Daftar Grup Aktif:\n\n';
    groups.forEach((group, index) => {
      const joinDate = new Date(group.joined);
      message += `${index + 1}. ${group.name || 'Unknown'} (ID: ${group.id})\n📅 Bergabung: ${joinDate.toLocaleDateString()}\n\n`;
    });
    
    ctx.reply(message);
  });

  // Command untuk broadcast
  bot.command('bc', async (ctx) => {
    if (ctx.from.id.toString() !== global.DEVELOPER_ID) {
      return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
    }
    
    const message = ctx.message.text.replace('/bc', '').trim();
    if (!message) {
      return ctx.reply('❌ Format: /bc <pesan>');
    }
    
    const users = require('../data/users.json');
    let success = 0;
    let failed = 0;
    
    ctx.reply(`🚀 Memulai broadcast ke ${Object.keys(users).length} user...`);
    
    for (const userId in users) {
      try {
        await ctx.telegram.sendMessage(userId, `📢 *Broadcast dari Owner*:\n\n${message}`, { parse_mode: 'Markdown' });
        success++;
        // Delay untuk menghindari rate limit
        await new Promise(resolve => setTimeout(resolve, 100));
      } catch (error) {
        failed++;
      }
    }
    
    ctx.reply(`✅ Broadcast selesai!\n✔️ Berhasil: ${success}\n❌ Gagal: ${failed}`);
  });

  // Command untuk mengubah foto menjadi URL
  bot.command('tourl', async (ctx) => {
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.photo) {
      return ctx.reply('❌ Balas foto dengan command ini!');
    }
    
    const photo = ctx.message.reply_to_message.photo;
    const fileId = photo[photo.length - 1].file_id;
    const file = await ctx.telegram.getFile(fileId);
    const filePath = file.file_path;
    const fileUrl = `https://api.telegram.org/file/bot${global.BOT_TOKEN}/${filePath}`;
    
    ctx.reply(`📸 URL Foto:\n${fileUrl}`);
  });

  // Command untuk sharefree (hanya di private chat)
  bot.command('sharefree', async (ctx) => {
    if (ctx.chat.type !== 'private') {
      return ctx.reply('❌ Command ini hanya bisa digunakan di private chat!');
    }
    
    if (isBlacklisted(ctx.from.id.toString())) {
      return ctx.reply('❌ Anda terblacklist dan tidak dapat menggunakan fitur ini!');
    }
    
    let message = '';
    if (ctx.message.reply_to_message) {
      message = ctx.message.reply_to_message.text || '';
    } else {
      message = ctx.message.text.replace('/sharefree', '').trim();
    }
    
    if (!message) {
      return ctx.reply('❌ Balas pesan atau ketik pesan setelah command!');
    }
    
    const groups = getActiveGroups();
    let success = 0;
    let failed = 0;
    
    ctx.reply(`🚀 Memulai share free ke ${groups.length} grup...`);
    
    for (const group of groups) {
      try {
        await ctx.telegram.sendMessage(group.id, `📢 *Share Free*:\n\n${message}`, { parse_mode: 'Markdown' });
        success++;
        // Delay untuk menghindari spam
        await new Promise(resolve => setTimeout(resolve, 2000));
      } catch (error) {
        failed++;
        // Jika bot dikick dari grup, tandai sebagai tidak aktif
        if (error.description.includes('kicked') || error.description.includes('blocked')) {
          removeGroup(group.id);
        }
      }
    }
    
    ctx.reply(`✅ Share free selesai!\n✔️ Berhasil: ${success}\n❌ Gagal: ${failed}`);
  });

  // Command untuk sharevip (hanya di private chat dan untuk premium)
  bot.command('sharevip', async (ctx) => {
    if (ctx.chat.type !== 'private') {
      return ctx.reply('❌ Command ini hanya bisa digunakan di private chat!');
    }
    
    if (!isPremium(ctx.from.id.toString())) {
      return ctx.reply('❌ Fitur ini hanya untuk user premium!');
    }
    
    if (isBlacklisted(ctx.from.id.toString())) {
      return ctx.reply('❌ Anda terblacklist dan tidak dapat menggunakan fitur ini!');
    }
    
    let message = '';
    if (ctx.message.reply_to_message) {
      message = ctx.message.reply_to_message.text || '';
    } else {
      message = ctx.message.text.replace('/sharevip', '').trim();
    }
    
    if (!message) {
      return ctx.reply('❌ Balas pesan atau ketik pesan setelah command!');
    }
    
    const groups = getActiveGroups();
    let success = 0;
    let failed = 0;
    
    ctx.reply(`🚀 Memulai share VIP ke ${groups.length} grup...`);
    
    for (const group of groups) {
      try {
        await ctx.telegram.sendMessage(group.id, `🌟 *Share VIP*:\n\n${message}`, { parse_mode: 'Markdown' });
        success++;
        // Delay lebih pendek untuk VIP
        await new Promise(resolve => setTimeout(resolve, 1000));
      } catch (error) {
        failed++;
        // Jika bot dikick dari grup, tandai sebagai tidak aktif
        if (error.description.includes('kicked') || error.description.includes('blocked')) {
          removeGroup(group.id);
        }
      }
    }
    
    ctx.reply(`✅ Share VIP selesai!\n✔️ Berhasil: ${success}\n❌ Gagal: ${failed}`);
  });

  // Command untuk fitur obfuscation
  bot.command("enc3", async (ctx) => {
    const userId = ctx.from.id.toString();
    addUser(userId);
    
    if (!isPremium(userId)) {
      return ctx.reply('❌ Fitur ini hanya untuk user premium!');
    }

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown(`
╭━━━「 ❌ ERROR 」━━━⬣
│ Terjadi kesalahan saat
│ memproses file!
╰━━━━━━━━━━━━━━━━⬣`);
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown(`
╭━━━「 ❌ ERROR 」━━━⬣
│ File harus berekstensi .js!
╰━━━━━━━━━━━━━━━━⬣`);
    }

    const encryptedPath = path.join(__dirname, `china-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          ` ⚙️ Memulai (Hardened Mandarin) (1%)\n` +
          ` ${createProgressBar(1)}\n` +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Mandarin obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Mandarin yang diperkuat`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Hardened Mandarin Obfuscation"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getJapanObfuscationConfig()
      );
      await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
      await fs.writeFile(encryptedPath, obfuscated);
      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscated);
      } catch (postObfuscationError) {
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      log(`Mengirim file terenkripsi gaya Mandarin: ${file.file_name}`);
      await ctx.replyWithDocument(
        { source: encryptedPath, filename: `china-encrypted-${file.file_name}` },
        {
          caption:
            "✅ *File terenkripsi (Hardened Mandarin) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Hardened Mandarin Obfuscation Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Mandarin obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // Command enc4
  bot.command("enc4", async (ctx) => {
    const userId = ctx.from.id.toString();
    addUser(userId);
    
    if (!isPremium(userId)) {
      return ctx.reply('❌ Fitur ini hanya untuk user premium!');
    }

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc4`!");
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, `arab-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          ` ⚙️ Memulai (Hardened Arab) (1%)\n` +
          ` ${createProgressBar(1)}\n` +
          "```\n" +
          "PROSES ENCRYPT"
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Arab obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Arab yang diperkuat`);
      await updateProgress(
        ctx,
        progressMessage,
       40,
        "Inisialisasi Hardened Arab Obfuscation"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getArabObfuscationConfig()
      );
      await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
      await fs.writeFile(encryptedPath, obfuscated);
      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscated);
      } catch (postObfuscationError) {
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      log(`Mengirim file terenkripsi gaya Arab: ${file.file_name}`);
      await ctx.replyWithDocument(
        { source: encryptedPath, filename: `arab-encrypted-${file.file_name}` },
        {
          caption:
            "✅ *File terenkripsi (Hardened Arab) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Hardened Arab Obfuscation Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Arab obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // Command japan
  bot.command("japan", async (ctx) => {
    const userId = ctx.from.id.toString();
    addUser(userId);
    
    if (!isPremium(userId)) {
      return ctx.reply('❌ Fitur ini hanya untuk user premium!');
    }

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/japan`!");
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, `japan-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          ` ⚙️ Memulai (Hardened Japan) (1%)\n` +
          ` ${createProgressBar(1)}\n` +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Japan obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Japan yang diperkuat`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Hardened Japan Obfuscation"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getJapanObfuscationConfig()
      );
      await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
      await fs.writeFile(encryptedPath, obfuscated);
      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscated);
      } catch (postObfuscationError) {
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      log(`Mengirim file terenkripsi gaya Japan: ${file.file_name}`);
      await ctx.replyWithDocument(
        { source: encryptedPath, filename: `japan-encrypted-${file.file_name}` },
        {
          caption:
            "✅ *File terenkripsi (Hardened Japan) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Hardened Japan Obfuscation Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Japan obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // Command zenc
  bot.command("zenc", async (ctx) => {
    const userId = ctx.from.id.toString();
    addUser(userId);
    
    if (!isPremium(userId)) {
      return ctx.reply('❌ Fitur ini hanya untuk user premium!');
    }

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/zenc`!");
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, `invisible-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          ` ⚙️ Memulai (InvisiBle) (1%)\n` +
          ` ${createProgressBar(1)}\n` +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Strong obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Strong`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Hardened Invisible Obfuscation"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getStrongObfuscationConfig()
      );
      let obfuscatedCode = obfuscated;
      if (typeof obfuscatedCode !== "string") {
        throw new Error("Hasil obfuscation bukan string");
      }
      log(
        `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
          0,
          50
        )}...`
      );
      await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscatedCode);
      } catch (postObfuscationError) {
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscatedCode);

      log(`Mengirim file terenkripsi gaya Invisible: ${file.file_name}`);
      await ctx.replyWithDocument(
        {
          source: encryptedPath,
          filename: `Invisible-encrypted-${file.file_name}`,
        },
        {
          caption: "✅ *File terenkripsi (Invisible) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Hardened Invisible Obfuscation Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Invisible obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // Command xx
  bot.command("xx", async (ctx) => {
    const userId = ctx.from.id.toString();
    addUser(userId);
    
    if (!isPremium(userId)) {
      return ctx.reply('❌ Fitur ini hanya untuk user premium!');
    }

    // Ambil nama kustom dari perintah
    const args = ctx.message.text.split(" ");
    if (args.length < 2 || !args[1]) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Gunakan format `/enc <nama>` dengan nama kustom!"
      );
    }
    const customName = args[1].replace(/[^a-zA-Z0-9_]/g, ""); // Sanitasi input, hanya huruf, angka, dan underscore
    if (!customName) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Nama kustom harus berisi huruf, angka, atau underscore!"
      );
    }

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Balas file .js dengan `/enc <nama>`!"
      );
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(
      __dirname,
      `custom-${customName}-encrypted-${file.file_name}`
    );

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          ` ⚙️ Memulai (Hardened Custom: ${customName}) (1%)\n` +
          ` ${createProgressBar(1)}\n` +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Custom obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Custom (${customName}) yang diperkuat`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Hardened Custom Obfuscation"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getCustomObfuscationConfig(customName)
      );
      log(
        `Hasil obfuscation (50 char pertama): ${obfuscated.substring(
          0,
          50
        )}...`
      );
      await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");

      log(`Memvalidasi kode hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscated);
      } catch (postObfuscationError) {
        log(
          `Kode hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      await fs.writeFile(encryptedPath, obfuscated);
      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

      log(`Mengirim file terenkripsi gaya Custom: ${file.file_name}`);
      await ctx.replyWithDocument(
        {
          source: encryptedPath,
          filename: `custom-${customName}-encrypted-${file.file_name}`,
        },
        {
          caption: `✅ *File terenkripsi (Hardened Custom: ${customName}) siap!*\nSUKSES ENCRYPT 🕊`,
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        `Hardened Custom (${customName}) Obfuscation Selesai`
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Custom obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // Command quantum
  bot.command("quantum", async (ctx) => {
    const userId = ctx.from.id.toString();
    addUser(userId);
    
    if (!isPremium(userId)) {
      return ctx.reply('❌ Fitur ini hanya untuk user premium!');
    }

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Balas file .js dengan `/quantum`!"
      );
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(
      __dirname,
      `quantum-encrypted-${file.file_name}`
    );

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          " ⚙️ Memulai (Quantum Vortex Encryption) (1%)\n" +
          " " +
          createProgressBar(1) +
          "\n" +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Quantum Vortex Encryption: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan Quantum Vortex Encryption`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Quantum Vortex Encryption"
      );
      const obfuscatedCode = await obfuscateQuantum(fileContent);
      log(
        `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
          0,
          50
        )}...`
      );
      log(
        `Ukuran file setelah obfuscation: ${Buffer.byteLength(
          obfuscatedCode,
          "utf-8"
        )} bytes`
      );

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscatedCode);
      } catch (postObfuscationError) {
        log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscatedCode);

      log(`Mengirim file terenkripsi quantum: ${file.file_name}`);
      await ctx.replyWithDocument(
        {
          source: encryptedPath,
          filename: `quantum-encrypted-${file.file_name}`,
        },
        {
          caption:
            "✅ *File terenkripsi (Quantum Vortex Encryption) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Quantum Vortex Encryption Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Quantum obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // Command var
  bot.command("var", async (ctx) => {
    const userId = ctx.from.id.toString();
    addUser(userId);
    
    if (!isPremium(userId)) {
      return ctx.reply('❌ Fitur ini hanya untuk user premium!');
    }

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/var`!");
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, `var-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          " ⚙️ Memulai (Var) (1%)\n" +
          " " +
          createProgressBar(1) +
          "\n" +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Var obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Var`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Var Dynamic Obfuscation"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getNovaObfuscationConfig()
      );
      let obfuscatedCode = obfuscated;
      if (typeof obfuscatedCode !== "string") {
        throw new Error("Hasil obfuscation bukan string");
      }
      log(
        `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
          0,
          50
        )}...`
      );

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscatedCode);
      } catch (postObfuscationError) {
        log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscatedCode);

      log(`Mengirim file terenkripsi gaya Var: ${file.file_name}`);
      await ctx.replyWithDocument(
        { source: encryptedPath, filename: `Var-encrypted-${file.file_name}` },
        {
          caption: "✅ *File terenkripsi (Var) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(ctx, progressMessage, 100, "Var Obfuscation Selesai");

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Nova obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // Command nebula
  bot.command("nebula", async (ctx) => {
    const userId = ctx.from.id.toString();
    addUser(userId);
    
    if (!isPremium(userId)) {
      return ctx.reply('❌ Fitur ini hanya untuk user premium!');
    }

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Balas file .js dengan `/nebula`!"
      );
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(
      __dirname,
      `nebula-encrypted-${file.file_name}`
    );

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          " ⚙️ Memulai (Nebula Polymorphic Storm) (1%)\n" +
          " " +
          createProgressBar(1) +
          "\n" +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Nebula obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Nebula`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Nebula Polymorphic Storm"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getNebulaObfuscationConfig()
      );
      let obfuscatedCode = obfuscated;
      if (typeof obfuscatedCode !== "string") {
        throw new Error("Hasil obfuscation bukan string");
      }
      log(
        `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
          0,
          50
        )}...`
      );
      log(
        `Ukuran file setelah obfuscation: ${Buffer.byteLength(
          obfuscatedCode,
          "utf-8"
        )} bytes`
      );

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscatedCode);
      } catch (postObfuscationError) {
        log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscatedCode);

      log(`Mengirim file terenkripsi gaya Nebula: ${file.file_name}`);
      await ctx.replyWithDocument(
        { source: encryptedPath, filename: `nebula-encrypted-${file.file_name}` },
        {
          caption:
            "✅ *File terenkripsi (Nebula Polymorphic Storm) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Nebula Polymorphic Storm Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Nebula obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // Command enc5
  bot.command("enc5", async (ctx) => {
    const userId = ctx.from.id.toString();
    addUser(userId);
    
    if (!isPremium(userId)) {
      return ctx.reply('❌ Fitur ini hanya untuk user premium!');
    }

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Balas file .js dengan `/enc5`!"
      );
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(
      __dirname,
      `siucalcrick-encrypted-${file.file_name}`
    );

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          " ⚙️ Memulai (Calcrick Chaos Core) (1%)\n" +
          " " +
          createProgressBar(1) +
          "\n" +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Siu+Calcrick obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Siu+Calcrick`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Calcrick Chaos Core"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getSiuCalcrickObfuscationConfig()
      );
      let obfuscatedCode = obfuscated;
      if (typeof obfuscatedCode !== "string") {
        throw new Error("Hasil obfuscation bukan string");
      }
      log(
        `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
          0,
          50
        )}...`
      );
      log(
        `Ukuran file setelah obfuscation: ${Buffer.byteLength(
          obfuscatedCode,
          "utf-8"
        )} bytes`
      );

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscatedCode);
      } catch (postObfuscationError) {
        log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscatedCode);

      log(`Mengirim file terenkripsi gaya Siu+Calcrick: ${file.file_name}`);
      await ctx.replyWithDocument(
        {
          source: encryptedPath,
          filename: `siucalcrick-encrypted-${file.file_name}`,
        },
        {
          caption:
            "✅ *File terenkripsi (Calcrick Chaos Core) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Calcrick Chaos Core Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Siu+Calcrick obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // Command enc2
  bot.command("enc2", async (ctx) => {
    const userId = ctx.from.id.toString();
    addUser(userId);
    
    if (!isPremium(userId)) {
      return ctx.reply('❌ Fitur ini hanya untuk user premium!');
    }

    const customString = ctx.message.text.split(" ")[1];

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Balas file .js dengan `/enc2 <text>`!"
      );
    }

    if (!customString) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Balas file .js dengan `/enc2 <text>`!"
      );
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(
      __dirname,
      `custom-encrypted-${file.file_name}`
    );

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          " ⚙️ Memulai (custom enc) (1%)\n" +
          " " +
          createProgressBar(1) +
          "\n" +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk custom obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya custom (${customString})`);
      await updateProgress(ctx, progressMessage, 40, `Inisialisasi custom (${customString})`);

      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getCustomObfuscationConfig(customString)
      );

      let obfuscatedCode = obfuscated;
      if (typeof obfuscatedCode !== "string") {
        throw new Error("Hasil obfuscation bukan string");
      }
      log(
        `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
          0,
          50
        )}...`
      );
      log(
        `Ukuran file setelah obfuscation: ${Buffer.byteLength(
          obfuscatedCode,
          "utf-8"
        )} bytes`
      );

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscatedCode);
      } catch (postObfuscationError) {
        log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscatedCode);

      log(`Mengirim file terenkripsi gaya custom (${customString}): ${file.file_name}`);
      await ctx.replyWithDocument(
        {
          source: encryptedPath,
          filename: `custom-encrypted-${file.file_name}`,
        },
        {
          caption: `✅ *File terenkripsi custom (${customString}) siap!*\nSUKSES ENCRYPT 🕊`,
          parse_mode: "Markdown",
        }
      );
      await updateProgress(ctx, progressMessage, 100, `custom (${customString}) Selesai`);

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat custom enc obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // Command enc
  bot.command("enc", async (ctx) => {
    const userId = ctx.from.id.toString();
    addUser(userId);
    
    if (!isPremium(userId)) {
      return ctx.reply('❌ Fitur ini hanya untuk user premium!');
    }

    const args = ctx.message.text.split(" ").slice(1);
    if (
      args.length !== 1 ||
      !/^\d+$/.test(args[0]) ||
      parseInt(args[0]) < 1 ||
      parseInt(args[0]) > 365
    ) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Gunakan format `/locked [1-365]` untuk jumlah hari (misal: `/enc 7`)!"
      );
    }

    const days = args[0];
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + parseInt(days));
    const expiryFormatted = expiryDate.toLocaleDateString();

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Balas file .js dengan `/enc [1-365]`!"
      );
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(
      __dirname,
      `locked-encrypted-${file.file_name}`
    );

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          " ⚙️ Memulai (Time-Locked Encryption) (1%)\n" +
          " " +
          createProgressBar(1) +
          "\n" +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Time-Locked Encryption: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan Time-Locked Encryption`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Time-Locked Encryption"
      );
      const obfuscatedCode = await obfuscateTimeLocked(fileContent, days);
      log(
        `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
          0,
          50
        )}...`
      );
      log(
        `Ukuran file setelah obfuscation: ${Buffer.byteLength(
          obfuscatedCode,
          "utf-8"
        )} bytes`
      );

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscatedCode);
      } catch (postObfuscationError) {
        log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscatedCode);

      log(`Mengirim file terenkripsi time-locked: ${file.file_name}`);
      await ctx.replyWithMarkdown(
        `✅ *File terenkripsi (Time-Locked Encryption) siap!*\n` +
          `⏰ Masa aktif: ${days} hari (Kedaluwarsa: ${expiryFormatted})\n` +
          `_Powered by XHINN_`,
        { parse_mode: "Markdown" }
      );
      await ctx.replyWithDocument({
        source: encryptedPath,
        filename: `locked-encrypted-${file.file_name}`,
      });
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Time-Locked Encryption Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Time-Locked obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // Command untuk group management
  bot.command(['antispam', 'noevent', 'nolinks', 'noforwards', 'nocontacts', 'nohastags', 'nocommands'], async (ctx) => {
    if (ctx.chat.type === 'private') {
      return ctx.reply('❌ Command ini hanya bisa digunakan di grup!');
    }
    
    const command = ctx.message.text.substring(1);
    ctx.reply(`✅ Mode ${command} telah diaktifkan untuk grup ini.`);
  });
}

module.exports = {
  setupCommands,
  bot
};