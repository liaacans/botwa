const { User, Group } = require('../lib/database');
const { mainMenuMessage, generateMainMenu } = require('./utils');

// Command start
async function startCommand(ctx) {
    try {
        // Cek apakah user sudah ada di database
        let user = await User.findOne({ userId: ctx.from.id });
        
        if (!user) {
            // Buat user baru jika belum ada
            user = new User({
                userId: ctx.from.id,
                username: ctx.from.username,
                firstName: ctx.from.first_name,
                lastName: ctx.from.last_name || '',
                credit: 0
            });
            await user.save();
        }
        
        const isCreator = ctx.from.id.toString() === process.env.OWNER_ID;
        const message = mainMenuMessage(ctx, user);
        const menu = generateMainMenu(isCreator);
        
        await ctx.replyWithHTML(message, menu);
    } catch (error) {
        console.error('Error in start command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

// Command help
async function helpCommand(ctx) {
    const helpText = `
<b>Jasher Bot Help</b>

<b>Perintah Umum:</b>
/start - Memulai bot
/help - Menampilkan bantuan
/credit - Menampilkan kredit Anda

<b>Perintah Share:</b>
Ketik <code>share</code> di chat private untuk membagikan pesan (mengurangi 2 kredit)

<b>Perintah Premium:</b>
Hanya untuk owner:
/addprem [user_id] - Menambahkan user premium
/delprem [user_id] - Menghapus user premium
/listprem - Menampilkan daftar user premium

<b>Cara Mendapatkan Kredit:</b>
Tambahkan bot ke 3 group untuk mendapatkan 10 kredit.
    `;
    
    await ctx.replyWithHTML(helpText);
}

// Command credit
async function creditCommand(ctx) {
    try {
        const user = await User.findOne({ userId: ctx.from.id });
        if (!user) {
            await ctx.reply('Anda belum terdaftar. Ketik /start untuk memulai.');
            return;
        }
        
        await ctx.replyWithHTML(`Kredit Anda: <b>${user.credit}</b>\n\nTambahkan bot ke 3 group untuk mendapatkan 10 kredit.`);
    } catch (error) {
        console.error('Error in credit command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

// Command untuk menambah premium user (hanya owner)
async function addPremCommand(ctx) {
    if (ctx.from.id.toString() !== process.env.OWNER_ID) {
        await ctx.reply('Anda bukan owner bot!');
        return;
    }
    
    const userId = ctx.message.text.split(' ')[1];
    if (!userId) {
        await ctx.reply('Gunakan: /addprem [user_id]');
        return;
    }
    
    try {
        const user = await User.findOneAndUpdate(
            { userId: parseInt(userId) },
            { isPremium: true },
            { new: true, upsert: true }
        );
        
        await ctx.reply(`User ${user.firstName} (${user.userId}) telah ditambahkan sebagai premium.`);
    } catch (error) {
        console.error('Error adding premium user:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

// Command untuk menghapus premium user (hanya owner)
async function delPremCommand(ctx) {
    if (ctx.from.id.toString() !== process.env.OWNER_ID) {
        await ctx.reply('Anda bukan owner bot!');
        return;
    }
    
    const userId = ctx.message.text.split(' ')[1];
    if (!userId) {
        await ctx.reply('Gunakan: /delprem [user_id]');
        return;
    }
    
    try {
        const user = await User.findOneAndUpdate(
            { userId: parseInt(userId) },
            { isPremium: false },
            { new: true }
        );
        
        if (user) {
            await ctx.reply(`User ${user.firstName} (${user.userId}) telah dihapus dari premium.`);
        } else {
            await ctx.reply('User tidak ditemukan.');
        }
    } catch (error) {
        console.error('Error removing premium user:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

// Command untuk menampilkan daftar premium user (hanya owner)
async function listPremCommand(ctx) {
    if (ctx.from.id.toString() !== process.env.OWNER_ID) {
        await ctx.reply('Anda bukan owner bot!');
        return;
    }
    
    try {
        const premiumUsers = await User.find({ isPremium: true });
        
        if (premiumUsers.length === 0) {
            await ctx.reply('Tidak ada user premium.');
            return;
        }
        
        let message = '<b>Daftar User Premium:</b>\n\n';
        premiumUsers.forEach((user, index) => {
            message += `${index + 1}. ${user.firstName}${user.lastName ? ' ' + user.lastName : ''} (@${user.username || 'N/A'}) - ID: ${user.userId}\n`;
        });
        
        await ctx.replyWithHTML(message);
    } catch (error) {
        console.error('Error listing premium users:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

module.exports = {
    startCommand,
    helpCommand,
    creditCommand,
    addPremCommand,
    delPremCommand,
    listPremCommand
};