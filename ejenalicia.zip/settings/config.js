const fs = require('fs')
//~~~~~~~~~SETTING BOT~~~~~~~~~~//
global.owner = "62856541270715"
global.nama = "Ichaa Botz"
global.namaowner = "Ichaa M.P"
global.namaBot = "Ichaa Botz"
global.ch = 'https://whatsapp.com/channel/0029Vb21EcZ7YSd4OM5Cek1n'
global.status = true
global.foother = "© Created By Ichaa Botz"
global.namach = 'Error 403'
global.idch = '120363319853236200@newsletter'
global.namafile = 'You know apip? Yes Its Ichaa Botz'
global.yt = 'https://youtube.com/@auliarhmanproduction'
global.themeemoji = ['•','●','■','✿','▲','➩','➢','➣','➤','✦','✧','△','❀','○','□','♤','♡','◇','♧','々','〆']
global.packname = "Sticker By"
global.author = "© Ichaa Botz X Rahman"
global.creator = "62856541270715@s.whatsapp.net"
//~~~~~~~~~ Settings Payment ~~~~~~~~~//
global.dana = "085654127071"
global.ovo = "085654127071"
global.qris = false //"https://img86.pixhost.to/images/414/561641458_slnckyami.jpg"
//====== [ THEME URL & URL ] ========//
global.thumb = fs.readFileSync('./kyami.jpg'); // Buffer Image
global.thumbnail = 'https://f.top4top.io/p_3338tz6bm0.jpg'
global.Url = '-'
global.logodana = "https://img100.pixhost.to/images/667/540082364_skyzopedia.jpg", 
global.logoovo = "https://img100.pixhost.to/images/667/540082774_skyzopedia.jpg", 
//~~~~~~~~~ Settings panel ~~~~~~~~~//
global.domain = "-"
global.apikey = "-"
global.capikey = "-"
//~~~~~~~~~ Settings panel ~~~~~~~~~//
global.domain2 = "-"
global.apikey2 = "-"
global.capikey2 = "-"
//~~~~~~~~~ Settings panel ~~~~~~~~~//
global.domain3 = "-"
global.apikey3 = "-"
global.capikey3 = "-"
global.egg = "15"
global.loc = "1"
//~~~~~~~~~ Settings reply ~~~~~~~~~//
global.mess = {
    owner: "no, this is for owners only",
    group: "this is for groups only",
    private: "this is specifically for private chat"
}

global.packname = 'Shiroko Multi Device'
global.author = '\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n@Kyami Silence'

global.pairing = "" //jangan di isi

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
