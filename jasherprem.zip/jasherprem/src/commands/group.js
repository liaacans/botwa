const { Markup } = require('telegraf');
const database = require('../../lib/database');
const { isOwner, addGroup, loadJSON, saveJSON } = require('../../lib/utils');
const moment = require('moment-timezone');

module.exports = (bot) => {
    // Handler ketika bot ditambahkan ke group
    bot.on('new_chat_members', async (ctx) => {
        const newMembers = ctx.message.new_chat_members;
        const botId = ctx.botInfo.id;
        
        // Cek jika bot yang ditambahkan
        if (newMembers.some(member => member.id === botId)) {
            const chat = ctx.chat;
            const addedBy = ctx.from;
            
            // Tambahkan group ke database
            addGroup(chat.id, chat.title, addedBy.id);
            
            // Update user's groups
            const usersData = loadJSON('users.json');
            const userIndex = usersData.users.findIndex(u => u.id === addedBy.id);
            if (userIndex !== -1) {
                if (!usersData.users[userIndex].groups.includes(chat.id)) {
                    usersData.users[userIndex].groups.push(chat.id);
                    saveJSON('users.json', usersData);
                }
            }
            
            // Kirim pesan welcome
            await ctx.replyWithMarkdown(`
🤖 *Terima kasih telah menambahkan Jasher Bot!*

*Fitur Group:*
• 🔒 Auto moderation
• 📊 Group management
• ⚡ Fast response

*Admin Commands:*
• /antispam - Anti spam protection
• /noevent - Matikan event notifications
• /nolinks - Blokir link sharing
• /noforwards - Blokir pesan terusan
• /nocontacts - Blokir kontak sharing
• /nohashtags - Blokir hashtags
• /nocommands - Blokir commands dari member

*Setup:* Gunakan command di atas untuk mengatur group!

*Note:* Bot perlu admin rights untuk bekerja optimal.`);
        }
    });

    // Handler ketika bot dikick dari group
    bot.on('left_chat_member', async (ctx) => {
        const leftMember = ctx.message.left_chat_member;
        const botId = ctx.botInfo.id;
        
        if (leftMember.id === botId) {
            // Non-aktifkan group di database
            database.deactivateGroup(ctx.chat.id);
            console.log(`Bot removed from group: ${ctx.chat.title} (${ctx.chat.id})`);
        }
    });

    // Command antispam
    bot.command('antispam', async (ctx) => {
        if (!await isGroupAdmin(ctx)) {
            return ctx.reply('❌ Hanya admin group yang bisa menggunakan command ini!');
        }

        const args = ctx.message.text.split(' ').slice(1);
        const action = args[0] || 'status';

        const group = database.getGroup(ctx.chat.id);
        if (!group) {
            return ctx.reply('❌ Group belum terdaftar! Gunakan /start di group ini terlebih dahulu.');
        }

        switch (action) {
            case 'on':
                database.updateGroupSettings(ctx.chat.id, { antispam: true });
                await ctx.replyWithMarkdown(`
✅ *Anti-Spam Diaktifkan!*

*Fitur:*
• 🚫 Blokir spam messages
• ⏰ Rate limiting
• 📊 Flood protection

*Bot akan otomatis menghapus pesan spam.*`);
                break;

            case 'off':
                database.updateGroupSettings(ctx.chat.id, { antispam: false });
                await ctx.reply('❌ Anti-Spam Dimatikan!');
                break;

            case 'status':
            default:
                const status = group.settings.antispam ? '✅ AKTIF' : '❌ NON-AKTIF';
                await ctx.replyWithMarkdown(`*Status Anti-Spam:* ${status}\n\nGunakan:\n• /antispam on - Aktifkan\n• /antispam off - Matikan`);
                break;
        }
    });

    // Command noevent
    bot.command('noevent', async (ctx) => {
        if (!await isGroupAdmin(ctx)) {
            return ctx.reply('❌ Hanya admin group yang bisa menggunakan command ini!');
        }

        const args = ctx.message.text.split(' ').slice(1);
        const action = args[0] || 'status';

        const group = database.getGroup(ctx.chat.id);
        if (!group) return ctx.reply('❌ Group belum terdaftar!');

        switch (action) {
            case 'on':
                database.updateGroupSettings(ctx.chat.id, { noevent: true });
                await ctx.replyWithMarkdown(`
✅ *Event Notifications Dimatikan!*

*Yang diblokir:*
• 📅 Event reminders
• 🎉 Group celebrations
• 🔔 System notifications

*Event notifications tidak akan ditampilkan.*`);
                break;

            case 'off':
                database.updateGroupSettings(ctx.chat.id, { noevent: false });
                await ctx.reply('🔔 Event Notifications Diaktifkan!');
                break;

            default:
                const status = group.settings.noevent ? '✅ DIMATIKAN' : '🔔 AKTIF';
                await ctx.replyWithMarkdown(`*Event Notifications:* ${status}\n\nGunakan:\n• /noevent on - Matikan\n• /noevent off - Aktifkan`);
                break;
        }
    });

    // Command nolinks
    bot.command('nolinks', async (ctx) => {
        if (!await isGroupAdmin(ctx)) {
            return ctx.reply('❌ Hanya admin group yang bisa menggunakan command ini!');
        }

        const args = ctx.message.text.split(' ').slice(1);
        const action = args[0] || 'status';

        const group = database.getGroup(ctx.chat.id);
        if (!group) return ctx.reply('❌ Group belum terdaftar!');

        switch (action) {
            case 'on':
                database.updateGroupSettings(ctx.chat.id, { nolinks: true });
                await ctx.replyWithMarkdown(`
✅ *Link Sharing Diblokir!*

*Yang diblokir:*
• 🌐 HTTP/HTTPS links
• 🔗 URL shortened
• 📱 Deep links
• 🖼️ Media dengan caption link

*Member tidak bisa share link.*`);
                break;

            case 'off':
                database.updateGroupSettings(ctx.chat.id, { nolinks: false });
                await ctx.reply('🌐 Link Sharing Diizinkan!');
                break;

            default:
                const status = group.settings.nolinks ? '✅ DIBLOKIR' : '🌐 DIIZINKAN';
                await ctx.replyWithMarkdown(`*Link Sharing:* ${status}\n\nGunakan:\n• /nolinks on - Blokir\n• /nolinks off - Izinkan`);
                break;
        }
    });

    // Command noforwards
    bot.command('noforwards', async (ctx) => {
        if (!await isGroupAdmin(ctx)) {
            return ctx.reply('❌ Hanya admin group yang bisa menggunakan command ini!');
        }

        const args = ctx.message.text.split(' ').slice(1);
        const action = args[0] || 'status';

        const group = database.getGroup(ctx.chat.id);
        if (!group) return ctx.reply('❌ Group belum terdaftar!');

        switch (action) {
            case 'on':
                database.updateGroupSettings(ctx.chat.id, { noforwards: true });
                await ctx.replyWithMarkdown(`
✅ *Forwarded Messages Diblokir!*

*Yang diblokir:*
• 📨 Pesan terusan dari chat lain
• 🔄 Cross-chat forwarding
• 📊 Broadcast messages

*Member tidak bisa forward pesan.*`);
                break;

            case 'off':
                database.updateGroupSettings(ctx.chat.id, { noforwards: false });
                await ctx.reply('📨 Forwarded Messages Diizinkan!');
                break;

            default:
                const status = group.settings.noforwards ? '✅ DIBLOKIR' : '📨 DIIZINKAN';
                await ctx.replyWithMarkdown(`*Forwarded Messages:* ${status}\n\nGunakan:\n• /noforwards on - Blokir\n• /noforwards off - Izinkan`);
                break;
        }
    });

    // Command nocontacts
    bot.command('nocontacts', async (ctx) => {
        if (!await isGroupAdmin(ctx)) {
            return ctx.reply('❌ Hanya admin group yang bisa menggunakan command ini!');
        }

        const args = ctx.message.text.split(' ').slice(1);
        const action = args[0] || 'status';

        const group = database.getGroup(ctx.chat.id);
        if (!group) return ctx.reply('❌ Group belum terdaftar!');

        switch (action) {
            case 'on':
                database.updateGroupSettings(ctx.chat.id, { nocontacts: true });
                await ctx.replyWithMarkdown(`
✅ *Contact Sharing Diblokir!*

*Yang diblokir:*
• 👤 Contact cards
• 📞 Phone numbers
• 📇 VCard files

*Member tidak bisa share kontak.*`);
                break;

            case 'off':
                database.updateGroupSettings(ctx.chat.id, { nocontacts: false });
                await ctx.reply('👤 Contact Sharing Diizinkan!');
                break;

            default:
                const status = group.settings.nocontacts ? '✅ DIBLOKIR' : '👤 DIIZINKAN';
                await ctx.replyWithMarkdown(`*Contact Sharing:* ${status}\n\nGunakan:\n• /nocontacts on - Blokir\n• /nocontacts off - Izinkan`);
                break;
        }
    });

    // Command nohashtags
    bot.command('nohashtags', async (ctx) => {
        if (!await isGroupAdmin(ctx)) {
            return ctx.reply('❌ Hanya admin group yang bisa menggunakan command ini!');
        }

        const args = ctx.message.text.split(' ').slice(1);
        const action = args[0] || 'status';

        const group = database.getGroup(ctx.chat.id);
        if (!group) return ctx.reply('❌ Group belum terdaftar!');

        switch (action) {
            case 'on':
                database.updateGroupSettings(ctx.chat.id, { nohastags: true });
                await ctx.replyWithMarkdown(`
✅ *Hashtags Diblokir!*

*Yang diblokir:*
• #hashtag dalam pesan
• 🔖 Tag mentions
• 📌 Keyword markers

*Penggunaan hashtag akan diblokir.*`);
                break;

            case 'off':
                database.updateGroupSettings(ctx.chat.id, { nohastags: false });
                await ctx.reply('🔖 Hashtags Diizinkan!');
                break;

            default:
                const status = group.settings.nohastags ? '✅ DIBLOKIR' : '🔖 DIIZINKAN';
                await ctx.replyWithMarkdown(`*Hashtags:* ${status}\n\nGunakan:\n• /nohashtags on - Blokir\n• /nohashtags off - Izinkan`);
                break;
        }
    });

    // Command nocommands
    bot.command('nocommands', async (ctx) => {
        if (!await isGroupAdmin(ctx)) {
            return ctx.reply('❌ Hanya admin group yang bisa menggunakan command ini!');
        }

        const args = ctx.message.text.split(' ').slice(1);
        const action = args[0] || 'status';

        const group = database.getGroup(ctx.chat.id);
        if (!group) return ctx.reply('❌ Group belum terdaftar!');

        switch (action) {
            case 'on':
                database.updateGroupSettings(ctx.chat.id, { nocommands: true });
                await ctx.replyWithMarkdown(`
✅ *Member Commands Diblokir!*

*Yang diblokir:*
• 🔧 Bot commands dari member
• ⚙️ System commands
• 📋 Utility commands

*Hanya admin yang bisa menggunakan commands.*`);
                break;

            case 'off':
                database.updateGroupSettings(ctx.chat.id, { nocommands: false });
                await ctx.reply('🔧 Member Commands Diizinkan!');
                break;

            default:
                const status = group.settings.nocommands ? '✅ DIBLOKIR' : '🔧 DIIZINKAN';
                await ctx.replyWithMarkdown(`*Member Commands:* ${status}\n\nGunakan:\n• /nocommands on - Blokir\n• /nocommands off - Izinkan`);
                break;
        }
    });

    // Command group settings
    bot.command('groupsettings', async (ctx) => {
        if (!await isGroupAdmin(ctx)) {
            return ctx.reply('❌ Hanya admin group yang bisa menggunakan command ini!');
        }

        const group = database.getGroup(ctx.chat.id);
        if (!group) return ctx.reply('❌ Group belum terdaftar!');

        const settings = group.settings;
        
        const settingsText = `
⚙️ *Group Settings*

*Current Settings:*
• 🚫 Anti-Spam: ${settings.antispam ? '✅' : '❌'}
• 🔔 Event Notifications: ${settings.noevent ? '❌' : '✅'}
• 🌐 Link Sharing: ${settings.nolinks ? '❌' : '✅'}
• 📨 Forwarded Messages: ${settings.noforwards ? '❌' : '✅'}
• 👤 Contact Sharing: ${settings.nocontacts ? '❌' : '✅'}
• 🔖 Hashtags: ${settings.nohastags ? '❌' : '✅'}
• 🔧 Member Commands: ${settings.nocommands ? '❌' : '✅'}

*Commands untuk mengubah:*
• /antispam [on/off]
• /noevent [on/off]
• /nolinks [on/off]
• /noforwards [on/off]
• /nocontacts [on/off]
• /nohashtags [on/off]
• /nocommands [on/off]`;

        await ctx.replyWithMarkdown(settingsText);
    });

    // Message handler untuk moderation
    bot.on('message', async (ctx) => {
        // Hanya proses di group
        if (ctx.chat.type !== 'supergroup' && ctx.chat.type !== 'group') return;

        const group = database.getGroup(ctx.chat.id);
        if (!group || !group.settings.antispam) return;

        const message = ctx.message;
        const settings = group.settings;

        try {
            // Anti-spam: Cek flood
            if (settings.antispam) {
                await handleAntiSpam(ctx, message);
            }

            // Blokir links
            if (settings.nolinks && containsLinks(message)) {
                await deleteMessage(ctx, '❌ Link sharing tidak diizinkan di group ini!');
                return;
            }

            // Blokir forwarded messages
            if (settings.noforwards && message.forward_from) {
                await deleteMessage(ctx, '❌ Forwarded messages tidak diizinkan di group ini!');
                return;
            }

            // Blokir contacts
            if (settings.nocontacts && message.contact) {
                await deleteMessage(ctx, '❌ Contact sharing tidak diizinkan di group ini!');
                return;
            }

            // Blokir hashtags
            if (settings.nohastags && containsHashtags(message)) {
                await deleteMessage(ctx, '❌ Hashtags tidak diizinkan di group ini!');
                return;
            }

            // Blokir commands dari member
            if (settings.nocommands && isMemberCommand(ctx, message)) {
                await deleteMessage(ctx, '❌ Commands hanya untuk admin!');
                return;
            }

        } catch (error) {
            console.log('Moderation error:', error.message);
        }
    });

    // Fungsi helper untuk moderation
    async function isGroupAdmin(ctx) {
        try {
            const chatMember = await ctx.getChatMember(ctx.from.id);
            return ['administrator', 'creator'].includes(chatMember.status);
        } catch (error) {
            return false;
        }
    }

    function containsLinks(message) {
        const text = message.text || message.caption || '';
        const linkRegex = /https?:\/\/[^\s]+|www\.[^\s]+|t\.me\/[^\s]+/gi;
        return linkRegex.test(text);
    }

    function containsHashtags(message) {
        const text = message.text || message.caption || '';
        return /#\w+/gi.test(text);
    }

    function isMemberCommand(ctx, message) {
        if (!message.text) return false;
        if (await isGroupAdmin(ctx)) return false;
        
        return message.text.startsWith('/') && 
               !message.text.startsWith('/start') &&
               !message.text.startsWith('/help');
    }

    async function deleteMessage(ctx, warning) {
        try {
            await ctx.deleteMessage();
            const warnMsg = await ctx.reply(warning);
            
            // Hapus warning setelah 5 detik
            setTimeout(async () => {
                try {
                    await ctx.deleteMessage(warnMsg.message_id);
                } catch (e) {
                    console.log('Gagal hapus warning:', e.message);
                }
            }, 5000);
        } catch (error) {
            console.log('Gagal hapus pesan:', error.message);
        }
    }

    // Flood protection system
    const userMessageCounts = new Map();
    
    async function handleAntiSpam(ctx, message) {
        const userId = message.from.id;
        const now = Date.now();
        
        if (!userMessageCounts.has(userId)) {
            userMessageCounts.set(userId, []);
        }
        
        const userMessages = userMessageCounts.get(userId);
        userMessages.push(now);
        
        // Hapus messages yang lebih lama dari 10 detik
        const tenSecondsAgo = now - 10000;
        const recentMessages = userMessages.filter(time => time > tenSecondsAgo);
        userMessageCounts.set(userId, recentMessages);
        
        // Jika lebih dari 5 messages dalam 10 detik, anggap spam
        if (recentMessages.length > 5) {
            await deleteMessage(ctx, '🚫 Terlalu banyak pesan! Mohon jangan spam.');
            
            // Reset counter untuk user ini
            userMessageCounts.set(userId, []);
        }
    }
};