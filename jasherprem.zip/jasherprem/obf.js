// Konfigurasi obfuscation untuk berbagai style
module.exports = {
  getMandarinObfuscationConfig: function() {
    return {
      target: "browser",
      preset: "high",
      stringEncoding: true,
      stringCompression: true,
      stringSplitting: true,
      controlFlowFlattening: true,
      deadCode: true,
      dispatcher: true,
      duplicateLiteralsRemoval: true,
      identifierGenerator: "hexadecimal",
      mba: true,
      memberExpressionGenerator: "hexadecimal",
      mode: "hardened",
      opaquePredicates: true,
      stack: true,
      globalConcealing: true,
      minify: true
    };
  },

  getArabObfuscationConfig: function() {
    return {
      target: "browser",
      preset: "high",
      stringEncoding: true,
      stringCompression: true,
      stringSplitting: true,
      controlFlowFlattening: true,
      deadCode: true,
      dispatcher: true,
      duplicateLiteralsRemoval: true,
      identifierGenerator: "arabic",
      mba: true,
      memberExpressionGenerator: "arabic",
      mode: "hardened",
      opaquePredicates: true,
      stack: true,
      globalConcealing: true,
      minify: true
    };
  },

  getJapanObfuscationConfig: function() {
    return {
      target: "browser",
      preset: "high",
      stringEncoding: true,
      stringCompression: true,
      stringSplitting: true,
      controlFlowFlattening: true,
      deadCode: true,
      dispatcher: true,
      duplicateLiteralsRemoval: true,
      identifierGenerator: "japanese",
      mba: true,
      memberExpressionGenerator: "japanese",
      mode: "hardened",
      opaquePredicates: true,
      stack: true,
      globalConcealing: true,
      minify: true
    };
  },

  getStrongObfuscationConfig: function() {
    return {
      target: "browser",
      preset: "high",
      stringEncoding: true,
      stringCompression: true,
      stringSplitting: true,
      controlFlowFlattening: true,
      deadCode: true,
      dispatcher: true,
      duplicateLiteralsRemoval: true,
      identifierGenerator: "invisible",
      mba: true,
      memberExpressionGenerator: "invisible",
      mode: "hardened",
      opaquePredicates: true,
      stack: true,
      globalConcealing: true,
      minify: true
    };
  },

  getCustomObfuscationConfig: function(customName) {
    return {
      target: "browser",
      preset: "high",
      stringEncoding: true,
      stringCompression: true,
      stringSplitting: true,
      controlFlowFlattening: true,
      deadCode: true,
      dispatcher: true,
      duplicateLiteralsRemoval: true,
      identifierGenerator: "custom",
      customIdentifierGenerator: customName,
      mba: true,
      memberExpressionGenerator: "custom",
      customMemberExpressionGenerator: customName,
      mode: "hardened",
      opaquePredicates: true,
      stack: true,
      globalConcealing: true,
      minify: true
    };
  },

  getNovaObfuscationConfig: function() {
    return {
      target: "browser",
      preset: "high",
      stringEncoding: true,
      stringCompression: true,
      stringSplitting: true,
      controlFlowFlattening: true,
      deadCode: true,
      dispatcher: true,
      duplicateLiteralsRemoval: true,
      identifierGenerator: "numeric",
      mba: true,
      memberExpressionGenerator: "numeric",
      mode: "hardened",
      opaquePredicates: true,
      stack: true,
      globalConcealing: true,
      minify: true
    };
  },

  getNebulaObfuscationConfig: function() {
    return {
      target: "browser",
      preset: "high",
      stringEncoding: true,
      stringCompression: true,
      stringSplitting: true,
      controlFlowFlattening: true,
      deadCode: true,
      dispatcher: true,
      duplicateLiteralsRemoval: true,
      identifierGenerator: "randomized",
      mba: true,
      memberExpressionGenerator: "randomized",
      mode: "hardened",
      opaquePredicates: true,
      stack: true,
      globalConcealing: true,
      minify: true,
      lock: {
        domain: ["telegram.org"],
        time: {
          start: new Date(),
          end: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000) // 1 year
        }
      }
    };
  },

  getSiuCalcrickObfuscationConfig: function() {
    return {
      target: "browser",
      preset: "high",
      stringEncoding: true,
      stringCompression: true,
      stringSplitting: true,
      controlFlowFlattening: true,
      deadCode: true,
      dispatcher: true,
      duplicateLiteralsRemoval: true,
      identifierGenerator: "mixed",
      mba: true,
      memberExpressionGenerator: "mixed",
      mode: "hardened",
      opaquePredicates: true,
      stack: true,
      globalConcealing: true,
      minify: true,
      calculator: true,
      rickroll: true
    };
  }
};