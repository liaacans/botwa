const { Telegraf } = require('telegraf');
const { BOT_TOKEN } = require('./config');
const {
  setupStartCommand,
  setupHelpCommand,
  setupMenuCommand,
  setupPremiumCommand,
  setupAddPremCommand,
  setupDelPremCommand,
  setupListPremCommand,
  setupAddBlCommand,
  setupDelBlCommand,
  setupListBlCommand,
  setupListGrupCommand,
  setupHapusGbCommand,
  setupBcCommand,
  setupShareVipCommand,
  setupShareFreeCommand,
  setupTourlCommand,
  setupObfCommands
} = require('./src/commands');
const {
  setupCallbackQueryHandler,
  setupNewChatMembersHandler,
  setupLeftChatMemberHandler,
  setupMessageHandler
} = require('./src/handlers');
const { log } = require('./lib/utils');

// Inisialisasi bot
const bot = new Telegraf(BOT_TOKEN);

// Setup semua command
setupStartCommand(bot);
setupHelpCommand(bot);
setupMenuCommand(bot);
setupPremiumCommand(bot);
setupAddPremCommand(bot);
setupDelPremCommand(bot);
setupListPremCommand(bot);
setupAddBlCommand(bot);
setupDelBlCommand(bot);
setupListBlCommand(bot);
setupListGrupCommand(bot);
setupHapusGbCommand(bot);
setupBcCommand(bot);
setupShareVipCommand(bot);
setupShareFreeCommand(bot);
setupTourlCommand(bot);
setupObfCommands(bot);

// Setup handlers
setupCallbackQueryHandler(bot);
setupNewChatMembersHandler(bot);
setupLeftChatMemberHandler(bot);
setupMessageHandler(bot);

// Error handling
bot.catch((err, ctx) => {
  log(`Error for update ${ctx.updateType}:`, err);
  ctx.reply('❌ Terjadi kesalahan internal. Silakan coba lagi nanti.');
});

// Start bot
bot.launch().then(() => {
  log('Bot Jasher Premium started successfully!');
}).catch(err => {
  log('Failed to start bot:', err);
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));