const { Telegraf, Markup } = require('telegraf');
const moment = require('moment-timezone');
const { runtime, isPremium, addPremiumDays } = require('../lib/utils');
const { saveUserGroups, saveBlacklistedGroups } = require('../lib/database');
const axios = require('axios');
const fs = require('fs');

// Handler untuk command start
function handleStart(ctx) {
    const username = ctx.from.username || 'Tidak ada';
    const isCreator = ctx.from.id.toString() === global.DEVELOPER_ID;
    
    const menuMessage = `╭─❒ 「 User Info 」 
├ Creator : ${global.DEVELOPER_USERNAME}
├ Name : @${username}
├ Profile : @${ctx.from.first_name}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreator ? 'True' : 'False'}
Silahkan pilih button dibawah ini!`;

    const buttons = Markup.inlineKeyboard([
        [Markup.button.callback('Jasher Menu', 'jasher_menu')],
        [Markup.button.callback('Obf Menu', 'obf_menu')],
        [Markup.button.callback('Owner', 'owner_menu')]
    ]);

    ctx.replyWithPhoto({ url: 'https://f.top4top.io/p_3530xky9e4.jpg' }, {
        caption: menuMessage,
        parse_mode: 'HTML',
        ...buttons
    });
}

// Handler untuk callback queries
function handleCallbackQuery(ctx) {
    const data = ctx.callbackQuery.data;
    const userId = ctx.from.id.toString();
    const isCreator = userId === global.DEVELOPER_ID;
    
    switch(data) {
        case 'jasher_menu':
            showJasherMenu(ctx);
            break;
        case 'obf_menu':
            showObfMenu(ctx);
            break;
        case 'owner_menu':
            if (isCreator) {
                showOwnerMenu(ctx);
            } else {
                ctx.answerCbQuery('Hanya owner yang bisa mengakses menu ini!');
            }
            break;
        case 'main_menu':
            handleStart(ctx);
            break;
        case 'share_free':
            handleShareFree(ctx);
            break;
        case 'share_vip':
            if (isPremium(userId)) {
                handleShareVip(ctx);
            } else {
                ctx.answerCbQuery('Anda harus premium untuk menggunakan fitur ini!');
            }
            break;
        case 'addbl':
            if (isCreator) {
                handleAddBlacklist(ctx);
            }
            break;
        case 'delbl':
            if (isCreator) {
                handleDelBlacklist(ctx);
            }
            break;
        case 'listbl':
            if (isCreator) {
                handleListBlacklist(ctx);
            }
            break;
        case 'autojasher':
            if (isCreator) {
                handleAutoJasher(ctx);
            }
            break;
        case 'stopautojasher':
            if (isCreator) {
                handleStopAutoJasher(ctx);
            }
            break;
        case 'list_groups':
            if (isCreator) {
                handleListGroups(ctx);
            }
            break;
        case 'addprem':
            if (isCreator) {
                handleAddPremium(ctx);
            }
            break;
        case 'delprem':
            if (isCreator) {
                handleDelPremium(ctx);
            }
            break;
        case 'listprem':
            if (isCreator) {
                handleListPremium(ctx);
            }
            break;
        case 'tourl':
            handleToUrl(ctx);
            break;
        case 'back_to_main':
            handleStart(ctx);
            break;
        default:
            ctx.answerCbQuery('Fitur belum tersedia!');
    }
}

// Tampilkan menu Jasher
function showJasherMenu(ctx) {
    const userId = ctx.from.id.toString();
    const isPremiumUser = isPremium(userId);
    
    const buttons = Markup.inlineKeyboard([
        [Markup.button.callback('Share Free', 'share_free')],
        [Markup.button.callback('Share VIP', 'share_vip')],
        [Markup.button.callback('Kembali', 'back_to_main')]
    ]);
    
    const message = `╭─❒ 「 Jasher Menu 」 
├ Status : ${isPremiumUser ? 'Premium' : 'Free'}
├ Grup Terdaftar : ${(global.userGroups.get(userId) || []).length}
├ Expiry : ${isPremiumUser ? new Date(global.premiumUsers.get(userId).expiry).toLocaleString() : 'Tidak ada'}
╰❒ Fitur : Share ke grup untuk tambah premium`;
    
    ctx.editMessageCaption({
        caption: message,
        parse_mode: 'HTML',
        ...buttons
    });
}

// Tampilkan menu Obf
function showObfMenu(ctx) {
    const buttons = Markup.inlineKeyboard([
        [Markup.button.callback('Time-Locked Encryption', 'obf_timelocked')],
        [Markup.button.callback('Quantum Vortex Encryption', 'obf_quantum')],
        [Markup.button.callback('Nebula Obfuscation', 'obf_nebula')],
        [Markup.button.callback('Kembali', 'back_to_main')]
    ]);
    
    ctx.editMessageCaption({
        caption: '╭─❒ 「 Obfuscation Menu 」 \n╰❒ Pilih jenis obfuscation yang diinginkan:',
        parse_mode: 'HTML',
        ...buttons
    });
}

// Tampilkan menu Owner
function showOwnerMenu(ctx) {
    const buttons = Markup.inlineKeyboard([
        [Markup.button.callback('Add Blacklist', 'addbl'), Markup.button.callback('Del Blacklist', 'delbl')],
        [Markup.button.callback('List Blacklist', 'listbl')],
        [Markup.button.callback('Auto Jasher', 'autojasher'), Markup.button.callback('Stop Auto Jasher', 'stopautojasher')],
        [Markup.button.callback('List Groups', 'list_groups')],
        [Markup.button.callback('Add Premium', 'addprem'), Markup.button.callback('Del Premium', 'delprem')],
        [Markup.button.callback('List Premium', 'listprem')],
        [Markup.button.callback('Kembali', 'back_to_main')]
    ]);
    
    ctx.editMessageCaption({
        caption: '╭─❒ 「 Owner Menu 」 \n╰❒ Pilih opsi yang diinginkan:',
        parse_mode: 'HTML',
        ...buttons
    });
}

// Handle share free
function handleShareFree(ctx) {
    const userId = ctx.from.id.toString();
    
    // Cek jika di private chat
    if (ctx.chat.type !== 'private') {
        return ctx.reply('Command ini hanya bisa digunakan di private chat!');
    }
    
    // Berikan instruksi untuk share
    ctx.reply('Untuk menambah premium, silahkan tambahkan bot ke 3 grup dan share pesan berikut:');
    ctx.reply('Hai! Saya menggunakan Bot Jasher untuk obfuscation JavaScript. Coba juga di @YourBotUsername');
}

// Handle share VIP
function handleShareVip(ctx) {
    const userId = ctx.from.id.toString();
    
    // Cek jika di private chat
    if (ctx.chat.type !== 'private') {
        return ctx.reply('Command ini hanya bisa digunakan di private chat!');
    }
    
    // Berikan pesan VIP untuk di-share
    ctx.reply('Ini adalah pesan VIP untuk di-share ke grup:');
    ctx.reply('🔥 VIP MESSAGE 🔥\nSaya menggunakan Bot Jasher Premium! Dapatkan fitur eksklusif sekarang juga di @YourBotUsername');
}

// Handle ketika bot ditambahkan ke grup
function handleNewChatMembers(ctx) {
    const chatId = ctx.chat.id.toString();
    const userId = ctx.from.id.toString();
    
    // Skip jika blacklisted
    if (global.blacklistedGroups.has(chatId)) {
        return ctx.leaveChat();
    }
    
    // Simpan grup ke user
    if (!global.userGroups.has(userId)) {
        global.userGroups.set(userId, []);
    }
    
    const userGroups = global.userGroups.get(userId);
    if (!userGroups.includes(chatId)) {
        userGroups.push(chatId);
        global.userGroups.set(userId, userGroups);
        saveUserGroups();
        
        // Jika sudah 3 grup, tambah premium 3 hari
        if (userGroups.length >= 3) {
            const expiry = addPremiumDays(userId, 3);
            ctx.reply(`Selamat! Anda telah menambahkan bot ke 3 grup. Premium ditambahkan 3 hari hingga ${new Date(expiry).toLocaleString()}`);
        }
    }
}

// Handle ketika bot dikick dari grup
function handleLeftChatMember(ctx) {
    const chatId = ctx.chat.id.toString();
    const leftMember = ctx.message.left_chat_member;
    
    if (leftMember.id.toString() === ctx.botInfo.id.toString()) {
        // Hapus grup dari semua user
        for (let [userId, groups] of global.userGroups.entries()) {
            const updatedGroups = groups.filter(groupId => groupId !== chatId);
            global.userGroups.set(userId, updatedGroups);
        }
        saveUserGroups();
    }
}

// Handle add blacklist
function handleAddBlacklist(ctx) {
    ctx.reply('Balas pesan ini dengan ID grup yang ingin di-blacklist');
    ctx.session = { action: 'add_blacklist' };
}

// Handle del blacklist
function handleDelBlacklist(ctx) {
    ctx.reply('Balas pesan ini dengan ID grup yang ingin dihapus dari blacklist');
    ctx.session = { action: 'del_blacklist' };
}

// Handle list blacklist
function handleListBlacklist(ctx) {
    const blacklisted = Array.from(global.blacklistedGroups);
    if (blacklisted.length === 0) {
        return ctx.reply('Tidak ada grup yang di-blacklist');
    }
    
    ctx.reply(`Grup yang di-blacklist:\n${blacklisted.join('\n')}`);
}

// Handle auto jasher
function handleAutoJasher(ctx) {
    if (global.autoJasherInterval) {
        return ctx.reply('Auto Jasher sudah berjalan!');
    }
    
    global.autoJasherInterval = setInterval(() => {
        // Broadcast ke semua user premium
        for (let [userId, userData] of global.premiumUsers.entries()) {
            if (userData.expiry > Date.now()) {
                ctx.telegram.sendMessage(userId, '🔄 Auto Jasher: Waktunya share ke grup!').catch(() => {});
            }
        }
    }, 10 * 60 * 1000); // Setiap 10 menit
    
    ctx.reply('Auto Jasher telah diaktifkan!');
}

// Handle stop auto jasher
function handleStopAutoJasher(ctx) {
    if (global.autoJasherInterval) {
        clearInterval(global.autoJasherInterval);
        global.autoJasherInterval = null;
        ctx.reply('Auto Jasher telah dihentikan!');
    } else {
        ctx.reply('Auto Jasher tidak sedang berjalan!');
    }
}

// Handle list groups
function handleListGroups(ctx) {
    let message = 'Daftar Grup Aktif:\n\n';
    for (let [userId, groups] of global.userGroups.entries()) {
        if (groups.length > 0) {
            message += `User ${userId}: ${groups.length} grup\n`;
        }
    }
    
    ctx.reply(message || 'Tidak ada grup aktif');
}

// Handle add premium
function handleAddPremium(ctx) {
    ctx.reply('Balas pesan ini dengan ID user dan jumlah hari (format: id_hari), contoh: 123456789_30');
    ctx.session = { action: 'add_premium' };
}

// Handle del premium
function handleDelPremium(ctx) {
    ctx.reply('Balas pesan ini dengan ID user yang ingin dihapus dari premium');
    ctx.session = { action: 'del_premium' };
}

// Handle list premium
function handleListPremium(ctx) {
    let message = 'Daftar User Premium:\n\n';
    for (let [userId, userData] of global.premiumUsers.entries()) {
        const expiry = new Date(userData.expiry);
        const status = expiry > Date.now() ? 'Aktif' : 'Kadaluarsa';
        message += `User ${userId}: ${status} hingga ${expiry.toLocaleString()}\n`;
    }
    
    ctx.reply(message || 'Tidak ada user premium');
}

// Handle to URL
function handleToUrl(ctx) {
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.photo) {
        return ctx.reply('Balas sebuah foto dengan command ini untuk mengubahnya menjadi URL');
    }
    
    const photo = ctx.message.reply_to_message.photo;
    const fileId = photo[photo.length - 1].file_id;
    
    ctx.telegram.getFileLink(fileId).then(url => {
        ctx.reply(`URL gambar: ${url}`);
    }).catch(err => {
        ctx.reply('Gagal mendapatkan URL gambar');
    });
}

// Handle pesan yang dibalas
function handleReply(ctx) {
    if (!ctx.session || !ctx.session.action) return;
    
    const text = ctx.message.text;
    const action = ctx.session.action;
    
    switch(action) {
        case 'add_blacklist':
            global.blacklistedGroups.add(text);
            saveBlacklistedGroups();
            ctx.reply(`Grup ${text} berhasil ditambahkan ke blacklist!`);
            break;
        case 'del_blacklist':
            global.blacklistedGroups.delete(text);
            saveBlacklistedGroups();
            ctx.reply(`Grup ${text} berhasil dihapus dari blacklist!`);
            break;
        case 'add_premium':
            const [userId, days] = text.split('_');
            if (!userId || !days) {
                return ctx.reply('Format salah! Gunakan: id_hari');
            }
            
            const expiry = addPremiumDays(userId, parseInt(days));
            ctx.reply(`User ${userId} berhasil ditambahkan premium hingga ${new Date(expiry).toLocaleString()}`);
            break;
        case 'del_premium':
            global.premiumUsers.delete(text);
            // Simpan ke file
            const fs = require('fs');
            const data = JSON.stringify(Array.from(global.premiumUsers.entries()));
            fs.writeFileSync('premium-users.json', data);
            
            ctx.reply(`User ${text} berhasil dihapus dari premium!`);
            break;
    }
    
    // Reset session
    ctx.session = null;
}

module.exports = {
    handleStart,
    handleCallbackQuery,
    handleNewChatMembers,
    handleLeftChatMember,
    handleReply
};