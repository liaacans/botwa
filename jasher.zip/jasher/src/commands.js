const { Telegraf } = require('telegraf');
const db = require('../lib/database');

function setupCommands(bot) {
    // Start command
    bot.command('start', (ctx) => {
        const user = ctx.from;
        db.createUser(user, function(err) {
            if (err) {
                console.error('Error creating user:', err);
            }
        });

        let message = `👋 Hello ${user.first_name}! Welcome to Jasher Premium Bot.\n\n`;
        message += `🌟 Features:\n`;
        message += `- Add me to your group to get 10 free credits\n`;
        message += `- Share messages to all groups (1 credit per broadcast)\n`;
        message += `- Check your credit balance\n\n`;
        message += `Use /help to see all available commands.`;

        ctx.reply(message);
    });

    // Help command
    bot.command('help', (ctx) => {
        const helpMessage = `🤖 *Jasher Bot Commands*\n\n` +
            `*/start* - Start the bot\n` +
            `*/help* - Show this help message\n` +
            `*/credit* - Check your credit balance\n` +
            `*/share* - Share a message to all groups (reply to a message or type after command)\n` +
            `*/broadcast_list* - List your broadcast history\n` +
            `*/addgroup* - Add current group to broadcast list (group admins only)\n` +
            `*/groups* - List all groups in broadcast system\n\n` +
            `💡 *Note*: You must add the bot to a group first to get 10 free credits.`;

        ctx.reply(helpMessage, { parse_mode: 'Markdown' });
    });

    // Credit command
    bot.command('credit', (ctx) => {
        const userId = ctx.from.id;
        
        db.getUser(userId, (err, user) => {
            if (err) {
                console.error('Error getting user:', err);
                return ctx.reply('❌ Error checking your credit. Please try again.');
            }
            
            if (!user) {
                return ctx.reply('You are not registered yet. Please use /start first.');
            }
            
            ctx.reply(`💰 Your current credit: ${user.credit}`);
        });
    });

    // Share command
    bot.command('share', async (ctx) => {
        // Check if in private chat
        if (ctx.chat.type !== 'private') {
            return ctx.reply('❌ Please use this command in private chat with the bot.');
        }

        const userId = ctx.from.id;
        let messageText = '';

        // Check if replying to a message
        if (ctx.message.reply_to_message) {
            const repliedMessage = ctx.message.reply_to_message;
            
            // Handle different message types
            if (repliedMessage.text) {
                messageText = repliedMessage.text;
            } else if (repliedMessage.caption) {
                messageText = repliedMessage.caption;
            } else {
                return ctx.reply('❌ Only text messages can be shared.');
            }
        } else {
            // Get text from command
            const args = ctx.message.text.split(' ');
            args.shift(); // Remove the command
            messageText = args.join(' ');
            
            if (!messageText.trim()) {
                return ctx.reply('❌ Please provide a message to share or reply to a message.');
            }
        }

        // Check user credit
        db.getUser(userId, (err, user) => {
            if (err) {
                console.error('Error getting user:', err);
                return ctx.reply('❌ Error processing your request. Please try again.');
            }
            
            if (!user || user.credit < 1) {
                return ctx.reply('❌ You don\'t have enough credit. Add the bot to a group to get 10 free credits.');
            }

            // Get all groups
            db.getAllGroups((err, groups) => {
                if (err) {
                    console.error('Error getting groups:', err);
                    return ctx.reply('❌ Error getting groups. Please try again.');
                }

                if (groups.length === 0) {
                    return ctx.reply('❌ No groups available for broadcasting. Add the bot to a group first.');
                }

                // Send message to all groups
                let successCount = 0;
                let failCount = 0;
                
                groups.forEach(group => {
                    try {
                        ctx.telegram.sendMessage(group.group_id, `📢 Broadcast:\n\n${messageText}`)
                            .then(() => {
                                successCount++;
                            })
                            .catch(err => {
                                console.error(`Error sending to group ${group.group_id}:`, err);
                                failCount++;
                            });
                    } catch (error) {
                        console.error(`Error sending to group ${group.group_id}:`, error);
                        failCount++;
                    }
                });

                // Update user credit and add to broadcast history
                db.updateUserCredit(userId, -1, (err) => {
                    if (err) {
                        console.error('Error updating credit:', err);
                    }
                });
                
                db.addBroadcast(userId, messageText, (err) => {
                    if (err) {
                        console.error('Error adding broadcast:', err);
                    }
                });

                // Send result to user
                setTimeout(() => {
                    ctx.reply(`✅ Broadcast completed!\n\n` +
                             `Success: ${successCount} groups\n` +
                             `Failed: ${failCount} groups\n` +
                             `Remaining credit: ${user.credit - 1}`);
                }, 2000);
            });
        });
    });

    // Broadcast list command
    bot.command('broadcast_list', (ctx) => {
        const userId = ctx.from.id;
        
        db.getBroadcasts(userId, (err, broadcasts) => {
            if (err) {
                console.error('Error getting broadcasts:', err);
                return ctx.reply('❌ Error getting your broadcast history.');
            }
            
            if (!broadcasts || broadcasts.length === 0) {
                return ctx.reply('You haven\'t sent any broadcasts yet.');
            }
            
            let message = `📋 Your broadcast history (latest 10):\n\n`;
            
            // Show only latest 10 broadcasts
            const recentBroadcasts = broadcasts.slice(0, 10);
            
            recentBroadcasts.forEach((broadcast, index) => {
                const date = new Date(broadcast.sent_at).toLocaleDateString();
                const shortText = broadcast.message_text.length > 50 
                    ? broadcast.message_text.substring(0, 50) + '...' 
                    : broadcast.message_text;
                
                message += `${index + 1}. [${date}] ${shortText}\n`;
            });
            
            ctx.reply(message);
        });
    });

    // Addgroup command (only works in groups)
    bot.command('addgroup', (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ This command can only be used in groups.');
        }

        // Check if user is admin in the group
        ctx.getChatAdministrators().then(admins => {
            const isAdmin = admins.some(admin => admin.user.id === ctx.from.id);
            
            if (!isAdmin) {
                return ctx.reply('❌ You need to be an admin in this group to add it.');
            }

            const group = {
                id: ctx.chat.id,
                title: ctx.chat.title
            };

            db.addGroup(group, ctx.from.id, function(err) {
                if (err) {
                    console.error('Error adding group:', err);
                    return ctx.reply('❌ Error adding this group. It might already be added.');
                }

                // Give credit to user who added the group
                db.updateUserCredit(ctx.from.id, 10, (err) => {
                    if (err) {
                        console.error('Error updating credit:', err);
                    }
                });

                ctx.reply(`✅ Group "${group.title}" added successfully! You received 10 credits.`);
            });
        }).catch(err => {
            console.error('Error getting chat administrators:', err);
            ctx.reply('❌ Error verifying admin status.');
        });
    });

    // Groups command
    bot.command('groups', (ctx) => {
        if (ctx.from.id.toString() !== global.ADMIN_ID) {
            return ctx.reply('❌ This command is only available for admins.');
        }

        db.getAllGroups((err, groups) => {
            if (err) {
                console.error('Error getting groups:', err);
                return ctx.reply('❌ Error getting groups list.');
            }

            if (groups.length === 0) {
                return ctx.reply('No groups have been added yet.');
            }

            let message = `📋 Groups in broadcast system (${groups.length}):\n\n`;
            
            groups.forEach((group, index) => {
                const date = new Date(group.added_at).toLocaleDateString();
                message += `${index + 1}. ${group.title} (Added on ${date})\n`;
            });

            ctx.reply(message);
        });
    });
}

module.exports = { setupCommands };