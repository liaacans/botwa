const { Markup } = require('telegraf');
const { User, Group } = require('../lib/database');
const { formatUserInfo } = require('./utils');
const config = require('../config');

async function handleStart(ctx) {
  try {
    const userId = ctx.from.id;
    const isCreator = userId.toString() === config.CREATOR_ID;
    
    let user = await User.findOne({ userId });
    if (!user) {
      user = new User({
        userId,
        username: ctx.from.username,
        firstName: ctx.from.first_name,
        lastName: ctx.from.last_name
      });
      await user.save();
    }
    
    const message = formatUserInfo(ctx, user, isCreator);
    
    const buttons = Markup.inlineKeyboard([
      [Markup.button.callback('Jasher Menu', 'jasher_menu')],
      [Markup.button.callback('Owner Menu', 'owner_menu')],
      [Markup.button.callback('Kembali', 'back_main')],
      [Markup.button.callback('AddGroup', 'add_group')],
      [Markup.button.callback('Owner', 'show_owner')]
    ]);
    
    await ctx.replyWithHTML(message, buttons);
  } catch (error) {
    console.error('Error in handleStart:', error);
    await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleHelp(ctx) {
  const helpMessage = `
<b>Bantuan Jasher Bot</b>

<b>Perintah yang tersedia:</b>
/start - Memulai bot
/help - Menampilkan bantuan
/credit - Menampilkan kredit Anda
/share - Membagikan pesan (2 kredit)
/sharevip - Membagikan pesan VIP (5 kredit)

<b>Cara menambah kredit:</b>
- Tambahkan bot ke 3 grup untuk mendapatkan 10 kredit

<b>Catatan:</b>
- Share hanya bisa dilakukan di chat private
- Share di grup akan mengurangi kredit
- ShareVIP lebih cepat dari share biasa
  `;
  
  await ctx.replyWithHTML(helpMessage);
}

async function handleCredit(ctx) {
  try {
    const userId = ctx.from.id;
    const user = await User.findOne({ userId });
    
    if (!user) {
      await ctx.reply('Anda belum terdaftar. Ketik /start untuk memulai.');
      return;
    }
    
    await ctx.replyWithHTML(`Kredit Anda: <b>${user.credit}</b>\n\nTambahkan bot ke 3 grup untuk mendapatkan 10 kredit tambahan!`);
  } catch (error) {
    console.error('Error in handleCredit:', error);
    await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleShare(ctx) {
  try {
    if (ctx.chat.type !== 'private') {
      await ctx.reply('Perintah share hanya bisa digunakan di chat private!');
      return;
    }
    
    const userId = ctx.from.id;
    const user = await User.findOne({ userId });
    
    if (!user) {
      await ctx.reply('Anda belum terdaftar. Ketik /start untuk memulai.');
      return;
    }
    
    if (user.credit < config.SHARE_COST) {
      await ctx.reply(`Kredit Anda tidak cukup. Diperlukan ${config.SHARE_COST} kredit untuk share.`);
      return;
    }
    
    const messageToShare = ctx.message.reply_to_message || ctx.message;
    if (!messageToShare.text && !messageToShare.caption) {
      await ctx.reply('Balas pesan yang ingin di-share atau ketik pesan setelah perintah /share');
      return;
    }
    
    // Kurangi kredit user
    user.credit -= config.SHARE_COST;
    await user.save();
    
    // Broadcast ke semua grup yang ada di database
    const groups = await Group.find({});
    let successCount = 0;
    
    for (const group of groups) {
      try {
        if (messageToShare.text) {
          await ctx.telegram.sendMessage(group.groupId, messageToShare.text, {
            parse_mode: 'HTML'
          });
        } else if (messageToShare.caption) {
          // Handle media messages
          if (messageToShare.photo) {
            await ctx.telegram.sendPhoto(group.groupId, messageToShare.photo[messageToShare.photo.length - 1].file_id, {
              caption: messageToShare.caption,
              parse_mode: 'HTML'
            });
          } else if (messageToShare.video) {
            await ctx.telegram.sendVideo(group.groupId, messageToShare.video.file_id, {
              caption: messageToShare.caption,
              parse_mode: 'HTML'
            });
          } else if (messageToShare.document) {
            await ctx.telegram.sendDocument(group.groupId, messageToShare.document.file_id, {
              caption: messageToShare.caption,
              parse_mode: 'HTML'
            });
          }
        }
        successCount++;
      } catch (error) {
        console.error(`Error sending to group ${group.groupId}:`, error);
      }
    }
    
    await ctx.replyWithHTML(`Pesan berhasil di-share ke <b>${successCount}</b> grup. Kredit berkurang ${config.SHARE_COST}. Sisa kredit: <b>${user.credit}</b>`);
  } catch (error) {
    console.error('Error in handleShare:', error);
    await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleShareVip(ctx) {
  try {
    if (ctx.chat.type !== 'private') {
      await ctx.reply('Perintah sharevip hanya bisa digunakan di chat private!');
      return;
    }
    
    const userId = ctx.from.id;
    const user = await User.findOne({ userId });
    
    if (!user || !user.isPremium) {
      await ctx.reply('Fitur ini hanya untuk user premium!');
      return;
    }
    
    if (user.credit < config.SHAREVIP_COST) {
      await ctx.reply(`Kredit VIP Anda tidak cukup. Diperlukan ${config.SHAREVIP_COST} kredit untuk shareVIP.`);
      return;
    }
    
    const messageToShare = ctx.message.reply_to_message || ctx.message;
    if (!messageToShare.text && !messageToShare.caption) {
      await ctx.reply('Balas pesan yang ingin di-share atau ketik pesan setelah perintah /sharevip');
      return;
    }
    
    // Kurangi kredit user
    user.credit -= config.SHAREVIP_COST;
    await user.save();
    
    // Broadcast ke semua grup yang ada di database (lebih cepat)
    const groups = await Group.find({});
    let successCount = 0;
    
    // Gunakan Promise.all untuk mengirim lebih cepat (VIP feature)
    const sendPromises = groups.map(async (group) => {
      try {
        if (messageToShare.text) {
          await ctx.telegram.sendMessage(group.groupId, messageToShare.text, {
            parse_mode: 'HTML'
          });
        } else if (messageToShare.caption) {
          // Handle media messages
          if (messageToShare.photo) {
            await ctx.telegram.sendPhoto(group.groupId, messageToShare.photo[messageToShare.photo.length - 1].file_id, {
              caption: messageToShare.caption,
              parse_mode: 'HTML'
            });
          } else if (messageToShare.video) {
            await ctx.telegram.sendVideo(group.groupId, messageToShare.video.file_id, {
              caption: messageToShare.caption,
              parse_mode: 'HTML'
            });
          } else if (messageToShare.document) {
            await ctx.telegram.sendDocument(group.groupId, messageToShare.document.file_id, {
              caption: messageToShare.caption,
              parse_mode: 'HTML'
            });
          }
        }
        successCount++;
      } catch (error) {
        console.error(`Error sending to group ${group.groupId}:`, error);
      }
    });
    
    await Promise.all(sendPromises);
    
    await ctx.replyWithHTML(`Pesan VIP berhasil di-share ke <b>${successCount}</b> grup. Kredit VIP berkurang ${config.SHAREVIP_COST}. Sisa kredit: <b>${user.credit}</b>`);
  } catch (error) {
    console.error('Error in handleShareVip:', error);
    await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleAddPrem(ctx) {
  try {
    const userId = ctx.from.id;
    if (userId.toString() !== config.CREATOR_ID) {
      await ctx.reply('Hanya owner yang dapat menggunakan perintah ini!');
      return;
    }
    
    const targetUserId = ctx.message.text.split(' ')[1];
    if (!targetUserId) {
      await ctx.reply('Gunakan: /addprem <user_id>');
      return;
    }
    
    const user = await User.findOne({ userId: targetUserId });
    if (!user) {
      await ctx.reply('User tidak ditemukan!');
      return;
    }
    
    user.isPremium = true;
    await user.save();
    
    await ctx.reply(`User ${targetUserId} sekarang premium!`);
  } catch (error) {
    console.error('Error in handleAddPrem:', error);
    await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleDelPrem(ctx) {
  try {
    const userId = ctx.from.id;
    if (userId.toString() !== config.CREATOR_ID) {
      await ctx.reply('Hanya owner yang dapat menggunakan perintah ini!');
      return;
    }
    
    const targetUserId = ctx.message.text.split(' ')[1];
    if (!targetUserId) {
      await ctx.reply('Gunakan: /delprem <user_id>');
      return;
    }
    
    const user = await User.findOne({ userId: targetUserId });
    if (!user) {
      await ctx.reply('User tidak ditemukan!');
      return;
    }
    
    user.isPremium = false;
    await user.save();
    
    await ctx.reply(`User ${targetUserId} tidak lagi premium!`);
  } catch (error) {
    console.error('Error in handleDelPrem:', error);
    await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleListPrem(ctx) {
  try {
    const userId = ctx.from.id;
    if (userId.toString() !== config.CREATOR_ID) {
      await ctx.reply('Hanya owner yang dapat menggunakan perintah ini!');
      return;
    }
    
    const premiumUsers = await User.find({ isPremium: true });
    if (premiumUsers.length === 0) {
      await ctx.reply('Tidak ada user premium!');
      return;
    }
    
    let message = '<b>Daftar User Premium:</b>\n\n';
    premiumUsers.forEach((user, index) => {
      message += `${index + 1}. ID: ${user.userId}, Username: ${user.username || 'Tidak ada'}\n`;
    });
    
    await ctx.replyWithHTML(message);
  } catch (error) {
    console.error('Error in handleListPrem:', error);
    await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleBroadcast(ctx) {
  try {
    const userId = ctx.from.id;
    if (userId.toString() !== config.CREATOR_ID) {
      await ctx.reply('Hanya owner yang dapat menggunakan perintah ini!');
      return;
    }
    
    const message = ctx.message.reply_to_message;
    if (!message) {
      await ctx.reply('Balas pesan yang ingin di-broadcast!');
      return;
    }
    
    const users = await User.find({});
    let successCount = 0;
    
    for (const user of users) {
      try {
        if (message.text) {
          await ctx.telegram.sendMessage(user.userId, message.text, {
            parse_mode: 'HTML'
          });
        } else if (message.photo) {
          await ctx.telegram.sendPhoto(user.userId, message.photo[message.photo.length - 1].file_id, {
            caption: message.caption,
            parse_mode: 'HTML'
          });
        } else if (message.video) {
          await ctx.telegram.sendVideo(user.userId, message.video.file_id, {
            caption: message.caption,
            parse_mode: 'HTML'
          });
        } else if (message.document) {
          await ctx.telegram.sendDocument(user.userId, message.document.file_id, {
            caption: message.caption,
            parse_mode: 'HTML'
          });
        }
        successCount++;
      } catch (error) {
        console.error(`Error sending to user ${user.userId}:`, error);
      }
    }
    
    await ctx.reply(`Broadcast berhasil dikirim ke ${successCount} user!`);
  } catch (error) {
    console.error('Error in handleBroadcast:', error);
    await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

module.exports = {
  handleStart,
  handleHelp,
  handleCredit,
  handleShare,
  handleShareVip,
  handleAddPrem,
  handleDelPrem,
  handleListPrem,
  handleBroadcast
};