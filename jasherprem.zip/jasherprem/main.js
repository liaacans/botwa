const { Telegraf, session } = require('telegraf');
const config = require('./config');
const database = require('./lib/database');
const { log, isOwner } = require('./lib/functions');

// Import command handlers
const userCommands = require('./src/commands/user');
const ownerCommands = require('./src/commands/owner');
const groupCommands = require('./src/commands/group');
const obfuscationCommands = require('./src/commands/obfuscation');

// Import message handlers
const messageHandler = require('./src/handlers/message');
const callbackHandler = require('./src/handlers/callback');

class JasherBot {
    constructor() {
        this.bot = new Telegraf(config.BOT_TOKEN);
        this.users = new Set(); // Changed to Set
        this.groups = new Map();
        this.premium = new Map();
        this.blacklist = new Set(); // Changed to Set
        
        this.init().catch(error => {
            log('Failed to initialize bot:', error);
            process.exit(1);
        });
    }

    async init() {
        try {
            log('Starting Jasher Bot...');
            
            // Load databases
            await this.loadDatabases();
            
            // Setup middleware
            this.setupMiddleware();
            
            // Setup handlers
            this.setupHandlers();
            
            // Start bot
            await this.bot.launch();
            log('Jasher Bot started successfully!');
            
            // Enable graceful stop
            this.setupGracefulStop();
            
        } catch (error) {
            log('Initialization error:', error);
            throw error;
        }
    }

    async loadDatabases() {
        log('Loading databases...');
        
        this.users = await database.loadUsers();
        this.groups = await database.loadGroups();
        this.premium = await database.loadPremium();
        this.blacklist = await database.loadBlacklist();
        
        log(`Databases loaded: ${this.users.size} users, ${this.groups.size} groups, ${this.premium.size} premium, ${this.blacklist.size} blacklist`);
    }

    setupMiddleware() {
        // Session middleware
        this.bot.use(session());
        
        // Logging middleware
        this.bot.use(async (ctx, next) => {
            const userId = ctx.from?.id;
            const chatType = ctx.chat?.type;
            const text = ctx.message?.text || ctx.callbackQuery?.data;
            
            if (userId && !this.blacklist.has(userId.toString())) {
                log(`Message from ${userId} (${chatType}): ${text || 'Non-text message'}`);
            }
            
            await next();
        });
    }

    setupHandlers() {
        // Setup command handlers dengan parameter yang benar
        userCommands(this.bot, this.users, this.groups, this.premium, this.blacklist);
        ownerCommands(this.bot, this.users, this.groups, this.premium, this.blacklist);
        groupCommands(this.bot, this.users, this.groups, this.premium, this.blacklist);
        obfuscationCommands(this.bot, this.users, this.groups, this.premium, this.blacklist);
        
        // Setup message handlers
        messageHandler(this.bot, this.users, this.groups, this.premium, this.blacklist);
        callbackHandler(this.bot, this.users, this.groups, this.premium, this.blacklist);
        
        // Setup error handler
        this.bot.catch((error, ctx) => {
            log('Bot error:', error);
            
            try {
                if (ctx && ctx.reply) {
                    ctx.replyWithMarkdown(`
╭━━━「 ❌ SYSTEM ERROR 」━━━⬣
│ Terjadi kesalahan sistem!
│ 
│ Silahkan coba lagi nanti.
╰━━━━━━━━━━━━━━━━⬣`);
                }
            } catch (e) {
                log('Error sending error message:', e);
            }
        });
    }

    setupGracefulStop() {
        // Enable graceful stop
        process.once('SIGINT', () => this.shutdown('SIGINT'));
        process.once('SIGTERM', () => this.shutdown('SIGTERM'));
        
        process.on('uncaughtException', (error) => {
            log('Uncaught Exception:', error);
        });
        
        process.on('unhandledRejection', (reason, promise) => {
            log('Unhandled Rejection at:', promise, 'reason:', reason);
        });
    }

    async shutdown(signal) {
        log(`Received ${signal}, shutting down gracefully...`);
        
        try {
            // Save all data before shutdown
            await database.saveUsers(this.users);
            await database.saveGroups(this.groups);
            await database.savePremium(this.premium);
            await database.saveBlacklist(this.blacklist);
            
            log('Data saved successfully');
        } catch (error) {
            log('Error saving data during shutdown:', error);
        }
        
        this.bot.stop(signal);
        log('Jasher Bot stopped');
        process.exit(0);
    }
}

// Helper function untuk createProgressBar
global.createProgressBar = function(percent, length = 20) {
    const filled = Math.round(length * percent / 100);
    const empty = length - filled;
    return '█'.repeat(filled) + '░'.repeat(empty);
};

// Start the bot
const jasherBot = new JasherBot();

module.exports = jasherBot;