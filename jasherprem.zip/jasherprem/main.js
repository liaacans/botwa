const { Telegraf, Markup } = require('telegraf');
const { BOT_TOKEN } = require('./config');
const { connectDB } = require('./lib/database');
const { userMiddleware, premiumMiddleware, ownerMiddleware, groupMiddleware, privateMiddleware, adminMiddleware } = require('./src/middlewares');
const { startHandler, callbackQueryHandler, newChatMembersHandler, leftChatMemberHandler, tourlHandler, buypremHandler, sharefreeHandler, sharevipHandler, profileHandler } = require('./src/handlers');
const { helpCommand, statusCommand, myscCommand, addblCommand, delblCommand, listblCommand, addpremCommand, delpremCommand, listpremCommand, bcCommand, statsCommand, listgroupCommand, gbCommand, antispamCommand, noeventCommand, nolinksCommand, noforwardsCommand, nocontactsCommand, nohastagsCommand, nocommandsCommand, encCommand, enc2Command, enc3Command, enc4Command, enc5Command, japanCommand, nebulaCommand, quantumCommand, varCommand, zencCommand, deobfuscateCommand, xxCommand } = require('./src/commands');

// Buat instance bot
const bot = new Telegraf(BOT_TOKEN);

// Koneksi database
connectDB();

// Buat folder temp jika belum ada
const fs = require('fs-extra');
const path = require('path');
const tempDir = path.join(__dirname, 'temp');
if (!fs.existsSync(tempDir)) {
  fs.mkdirSync(tempDir);
}

// Middleware global
bot.use(userMiddleware);

// Handler untuk start command
bot.start(startHandler);

// Handler untuk callback queries
bot.on('callback_query', callbackQueryHandler);

// Handler untuk new chat members
bot.on('new_chat_members', newChatMembersHandler);

// Handler untuk left chat member
bot.on('left_chat_member', leftChatMemberHandler);

// Command untuk help
bot.command('help', helpCommand);

// Command untuk status
bot.command('status', statusCommand);

// Command untuk profile
bot.command('profile', profileHandler);

// Command untuk buyprem
bot.command('buyprem', privateMiddleware, buypremHandler);

// Command untuk mysc
bot.command('mysc', myscCommand);

// Command untuk sharefree
bot.command('sharefree', privateMiddleware, sharefreeHandler);

// Command untuk sharevip
bot.command('sharevip', privateMiddleware, premiumMiddleware, sharevipHandler);

// Command untuk tourl
bot.command('tourl', tourlHandler);

// Command untuk owner: addbl
bot.command('addbl', ownerMiddleware, addblCommand);

// Command untuk owner: delbl
bot.command('delbl', ownerMiddleware, delblCommand);

// Command untuk owner: listbl
bot.command('listbl', ownerMiddleware, listblCommand);

// Command untuk owner: addprem
bot.command('addprem', ownerMiddleware, addpremCommand);

// Command untuk owner: delprem
bot.command('delprem', ownerMiddleware, delpremCommand);

// Command untuk owner: listprem
bot.command('listprem', ownerMiddleware, listpremCommand);

// Command untuk owner: bc
bot.command('bc', ownerMiddleware, bcCommand);

// Command untuk owner: stats
bot.command('stats', ownerMiddleware, statsCommand);

// Command untuk owner: listgroup
bot.command('listgroup', ownerMiddleware, listgroupCommand);

// Command untuk owner: gb
bot.command('gb', ownerMiddleware, gbCommand);

// Command untuk admin grup: antispam
bot.command('antispam', groupMiddleware, adminMiddleware, antispamCommand);

// Command untuk admin grup: noevent
bot.command('noevent', groupMiddleware, adminMiddleware, noeventCommand);

// Command untuk admin grup: nolinks
bot.command('nolinks', groupMiddleware, adminMiddleware, nolinksCommand);

// Command untuk admin grup: noforwards
bot.command('noforwards', groupMiddleware, adminMiddleware, noforwardsCommand);

// Command untuk admin grup: nocontacts
bot.command('nocontacts', groupMiddleware, adminMiddleware, nocontactsCommand);

// Command untuk admin grup: nohastags
bot.command('nohastags', groupMiddleware, adminMiddleware, nohastagsCommand);

// Command untuk admin grup: nocommands
bot.command('nocommands', groupMiddleware, adminMiddleware, nocommandsCommand);

// Command untuk obfuscation: enc
bot.command('enc', encCommand);

// Command untuk obfuscation: enc2
bot.command('enc2', enc2Command);

// Command untuk obfuscation: enc3
bot.command('enc3', enc3Command);

// Command untuk obfuscation: enc4
bot.command('enc4', enc4Command);

// Command untuk obfuscation: enc5
bot.command('enc5', enc5Command);

// Command untuk obfuscation: japan
bot.command('japan', japanCommand);

// Command untuk obfuscation: nebula
bot.command('nebula', nebulaCommand);

// Command untuk obfuscation: quantum
bot.command('quantum', quantumCommand);

// Command untuk obfuscation: var
bot.command('var', varCommand);

// Command untuk obfuscation: zenc
bot.command('zenc', zencCommand);

// Command untuk obfuscation: deobfuscate
bot.command('deobfuscate', deobfuscateCommand);

// Command untuk obfuscation: xx
bot.command('xx', xxCommand);

// Handler untuk error
bot.catch((err, ctx) => {
  console.error(`Error for ${ctx.updateType}:`, err);
  ctx.reply('❌ Terjadi kesalahan internal');
});

// Jalankan bot
bot.launch().then(() => {
  console.log('Bot Jasher Premium started');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));