
require("dotenv").config();

module.exports = {
  port: 3000,
  baseUrl: "https://xdigitalkita.my.id",
  sessionSecret: "XDK_SESSION_9f8e7d6c5b4a3210",
  jwtSecret: "XDK_JWT_1a2b3c4d5e6f7a8b9c0d",

  buatqris: {
    baseUrl: "https://xdigitalkita.my.id/api/h2h",
    apiKey: "MASUKKAN_API_KEY_XDIGITALKITA_DI_SINI",
    adminFee: 100
  },

  oauth: {
    google: {
      clientId: "",
      clientSecret: "",
      callbackUrl: ""
    },

    github: {
      clientId: "",
      clientSecret: "",
      callbackUrl: ""
    }
  },

  admin: {
    emails: ["auliahostweb@gmail.com"]
  },

  telegram: {
    botToken: "8704165497:AAH8Nz4RjNhcaGRHzwB6aPo9S0G_wergKGY",
    adminChatId: "1147324679",
    transactionChannelId: "@achabaik",
    transactionBannerNewUrl: "https://xdigitalkita.my.id/assets/transaction-new.png",
    transactionBannerSuccessUrl: "https://xdigitalkita.my.id/assets/transaction-success.png",
    transactionPollIntervalMs: 15000,
    requiredChannel: "@achabaik",
    requiredChannelUrl: "https://t.me/achabaik",
    requiredChannelTitle: "Channel Information"
  },

  withdraw: {
    minAmount: 25000,
    maxAmount: 5000000,
    maxProofSizeBytes: 10 * 1024 * 1024,
    allowedProofMimeTypes: [
      "image/jpeg",
      "image/png",
      "image/webp",
      "image/gif",
      "video/mp4",
      "video/webm",
      "application/pdf"
    ]
  }
};
