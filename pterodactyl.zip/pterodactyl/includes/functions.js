<?php
include 'config.php';
include 'database.php';

// Fungsi untuk redirect
function redirect($url) {
    header("Location: $url");
    exit();
}

// Fungsi untuk menampilkan pesan
function displayMessage($msg, $type = 'info') {
    return '<div class="alert alert-'.$type.' alert-dismissible fade show" role="alert">
        '.$msg.'
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
}

// Fungsi untuk validasi email
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Fungsi untuk generate password
function generatePassword($length = 8) {
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $password = '';
    for ($i = 0; $i < $length; $i++) {
        $password .= $chars[rand(0, strlen($chars) - 1)];
    }
    return $password;
}

// Fungsi untuk mengecek user di Pterodactyl
function checkPterodactylUser($email) {
    $url = DOMAIN . '/api/application/users/email/' . $email;
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Accept: application/json',
        'Content-Type: application/json',
        'Authorization: Bearer ' . PLTA
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode == 200) {
        $data = json_decode($response, true);
        return $data;
    }
    
    return false;
}

// Fungsi untuk membuat user di Pterodactyl
function createPterodactylUser($email, $username, $password) {
    $url = DOMAIN . '/api/application/users';
    
    $data = [
        'email' => $email,
        'username' => $username,
        'first_name' => $username,
        'last_name' => $username,
        'language' => 'en',
        'password' => $password
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Accept: application/json',
        'Content-Type: application/json',
        'Authorization: Bearer ' . PLTA
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode == 201) {
        $data = json_decode($response, true);
        return $data;
    }
    
    return false;
}

// Fungsi untuk membuat server di Pterodactyl
function createPterodactylServer($userId, $username, $ram, $disk, $cpu) {
    // Dapatkan informasi egg
    $url = DOMAIN . '/api/application/nests/' . NESTS . '/eggs/' . EGGS;
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Accept: application/json',
        'Content-Type: application/json',
        'Authorization: Bearer ' . PLTC
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode != 200) {
        return false;
    }
    
    $eggData = json_decode($response, true);
    $startupCmd = $eggData['attributes']['startup'];
    
    // Buat server
    $url = DOMAIN . '/api/application/servers';
    
    $data = [
        'name' => $username,
        'description' => 'Panel Pterodactyl',
        'user' => (int)$userId,
        'egg' => (int)EGGS,
        'docker_image' => 'ghcr.io/parkervcp/yolks:nodejs_18',
        'startup' => $startupCmd,
        'environment' => [
            'INST' => 'npm',
            'USER_UPLOAD' => '0',
            'AUTO_UPDATE' => '0',
            'CMD_RUN' => 'npm start'
        ],
        'limits' => [
            'memory' => (int)$ram,
            'swap' => 0,
            'disk' => (int)$disk,
            'io' => 500,
            'cpu' => (int)$cpu
        ],
        'feature_limits' => [
            'databases' => 5,
            'backups' => 5,
            'allocations' => 5
        ],
        'deploy' => [
            'locations' => [(int)LOC],
            'dedicated_ip' => false,
            'port_range' => []
        ]
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Accept: application/json',
        'Content-Type: application/json',
        'Authorization: Bearer ' . PLTC
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode == 201) {
        $data = json_decode($response, true);
        return $data;
    }
    
    return false;
}

// Fungsi untuk mengirim email
function sendEmail($to, $subject, $message) {
    // Implementasi pengiriman email menggunakan PHPMailer atau fungsi mail()
    // Ini adalah implementasi sederhana, Anda mungkin perlu menyesuaikan dengan SMTP server Anda
    $headers = "From: no-reply@y2beta.web.id\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    
    return mail($to, $subject, $message, $headers);
}

// Fungsi untuk memproses pembayaran YAB-Group
function processYabPayment($data) {
    $postdata = [
        'api_key' => YAB_API_KEY,
        'secret_key' => YAB_SECRET_KEY,
        'channel_payment' => strtoupper($data['paymentMethod']),
        'ref_kode' => 'Pterodactyl-' . time() . rand(100, 999),
        'nominal' => (int)$data['amount'],
        'cus_nama' => $data['nama'],
        'cus_email' => $data['email'],
        'cus_phone' => $data['phone'],
        'produk' => $data['produk'],
        'url_redirect' => "http://" . $_SERVER['HTTP_HOST'] . "/order/success.php",
        'url_callback' => "https://" . $_SERVER['HTTP_HOST'] . "/order/callback.php",
        'expired_time' => (time() + (24 * 60 * 60)),
        'signature' => hash_hmac('sha256', 'Pterodactyl-' . time() . rand(100, 999) . YAB_API_KEY . (int)$data['amount'], YAB_SECRET_KEY)
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, YAB_API_URL);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postdata));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/x-www-form-urlencoded'
    ]);
    
    $response = curl_exec($ch);
    $error = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($error) {
        return ['status' => 'error', 'message' => 'Koneksi ke server pembayaran gagal: ' . $error];
    }
    
    $responseData = json_decode($response, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        return ['status' => 'error', 'message' => 'Format respon tidak valid dari server pembayaran'];
    }
    
    if ($httpCode !== 200) {
        return ['status' => 'error', 'message' => 'HTTP Error: ' . $httpCode];
    }
    
    if (isset($responseData['data']['status']) && $responseData['data']['status'] == "success") {
        return [
            'status' => 'success',
            'id_reference' => $responseData['data']['id_reference'],
            'checkout_url' => $responseData['data']['checkout_url']
        ];
    } else {
        $errorMsg = $responseData['message'] ?? 'Gagal memproses pembayaran';
        if (isset($responseData['data']['message'])) {
            $errorMsg = $responseData['data']['message'];
        }
        return ['status' => 'error', 'message' => $errorMsg];
    }
}
?>