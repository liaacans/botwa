const { Telegraf } = require('telegraf');
const config = require('./config');
const db = require('./lib/database');
const commands = require('./src/commands');
const handlers = require('./src/handlers');
const { CREDITS } = require('./config');

const bot = new Telegraf(global.BOT_TOKEN);

// Event ketika bot mulai
bot.start(commands.startCommand);

// Command handlers
bot.help(commands.helpCommand);
bot.command('credit', commands.creditCommand);
bot.command('share', commands.shareCommand);
bot.command('sharevip', commands.shareVipCommand);
bot.command('broadcast', commands.broadcastCommand);
bot.command('addprem', commands.addPremiumCommand);
bot.command('delprem', commands.removePremiumCommand);
bot.command('listprem', commands.listPremiumCommand);

// Command untuk addgroup (harus di group)
bot.command('addgroup', async (ctx) => {
    if (ctx.chat.type === 'private') {
        await ctx.reply('❌ Perintah ini hanya bisa digunakan di group!');
        return;
    }
    
    const user = ctx.from;
    const chat = ctx.chat;
    
    let userData = await db.getUser(user.id);
    if (!userData) {
        await db.createUser(user);
        userData = await db.getUser(user.id);
    }
    
    // Cek apakah user adalah admin di group
    try {
        const chatMember = await ctx.telegram.getChatMember(chat.id, user.id);
        if (!['administrator', 'creator'].includes(chatMember.status)) {
            await ctx.reply('❌ Anda harus menjadi admin di group ini untuk mendaftarkan group!');
            return;
        }
    } catch (error) {
        await ctx.reply('❌ Gagal memverifikasi status admin Anda!');
        return;
    }
    
    // Tambahkan group ke database
    const result = await db.addGroup(chat.id, chat.title, user.id);
    
    if (result === 0) {
        await ctx.reply('❌ Group sudah terdaftar sebelumnya!');
        return;
    }
    
    // Update jumlah group yang ditambahkan user
    const newGroupCount = userData.added_groups + 1;
    await db.updateAddedGroups(user.id, newGroupCount);
    
    // Berikan credit jika user menambahkan minimal 3 group
    let newCredits = userData.credits;
    let creditMessage = '';
    
    if (newGroupCount === CREDITS.MIN_GROUPS_FOR_SHARE) {
        newCredits += CREDITS.ADD_GROUP_REWARD;
        await db.updateUserCredits(user.id, newCredits);
        creditMessage = `\nAnda telah menambahkan ${CREDITS.MIN_GROUPS_FOR_SHARE} group dan mendapatkan ${CREDITS.ADD_GROUP_REWARD} credit!`;
    }
    
    await ctx.replyWithHTML(
        `✅ Group <b>${chat.title}</b> berhasil didaftarkan!${creditMessage}\n\nTotal group yang Anda tambahkan: <b>${newGroupCount}</b>`
    );
});

// Callback query handler (button clicks)
bot.on('callback_query', handlers.handleCallbackQuery);

// Event handlers
bot.on('new_chat_members', handlers.handleNewChatMembers);
bot.on('left_chat_member', handlers.handleLeftChatMember);

// Error handling
bot.catch((err, ctx) => {
    console.error(`Error for ${ctx.updateType}:`, err);
});

// Start bot
bot.launch().then(() => {
    console.log('Bot Jasher started successfully!');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));