/*
*Dibuat oleh aulia rahman
*Ditambahkan fitur fiturnya oleh ginaa septiana ramadhani
Base Ori Rahman x Gina septiana ramadhani

Sosmed media :
Ig : @4xglrs_
Tele : @ginaabaikhati
Wa : Privet
Yt : A. Aulia Rahman Official (@auliarhmanproduction)

Thanks too::
Allah swt
Nabi Muhammad
Ortu
Aulia Rahman
Ginaa septiana ramadhani
And Pengguna Copy/Paste:v

Note : don't remove copyright of this script!



Eh jangan lupa ini diganti yaawww🌹 dibagian src/commands
// Ganti ini:
const obfuscated = await JsConfuser.obfuscate(fileContent, getJapanObfuscationConfig());

// Menjadi ini:
const obfuscatedCode = await safeObfuscate(fileContent, getJapanObfuscationConfig(), 'Mandarin');
biar tidak error kalau mau enc / dec disitu ada decode sih:v
*/


const { Telegraf } = require('telegraf');
const { BOT_TOKEN } = require('./config');
const {
  setupStartCommand,
  setupHelpCommand,
  setupMenuCommand,
  setupPremiumCommand,
  setupAddPremCommand,
  setupDelPremCommand,
  setupListPremCommand,
  setupAddBlCommand,
  setupDelBlCommand,
  setupListBlCommand,
  setupListGrupCommand,
  setupHapusGbCommand,
  setupBcCommand,
  setupShareVipCommand,
  setupShareFreeCommand,
  setupTourlCommand,
  setupObfCommands
} = require('./src/commands');
const {
  setupCallbackQueryHandler,
  setupNewChatMembersHandler,
  setupLeftChatMemberHandler,
  setupMessageHandler
} = require('./src/handlers');
const { log } = require('./lib/utils');

// Inisialisasi bot
const bot = new Telegraf(BOT_TOKEN);

// Pastikan folder temp ada
const tempDir = path.join(__dirname, 'temp');
fs.ensureDirSync(tempDir);

// Setup semua command
setupStartCommand(bot);
setupHelpCommand(bot);
setupMenuCommand(bot);
setupPremiumCommand(bot);
setupAddPremCommand(bot);
setupDelPremCommand(bot);
setupListPremCommand(bot);
setupAddBlCommand(bot);
setupDelBlCommand(bot);
setupListBlCommand(bot);
setupListGrupCommand(bot);
setupHapusGbCommand(bot);
setupBcCommand(bot);
setupShareVipCommand(bot);
setupShareFreeCommand(bot);
setupTourlCommand(bot);
setupObfCommands(bot);

// Setup handlers
setupCallbackQueryHandler(bot);
setupNewChatMembersHandler(bot);
setupLeftChatMemberHandler(bot);
setupMessageHandler(bot);

// Error handling
bot.catch((err, ctx) => {
  log(`Error for update ${ctx.updateType}:`, err);
  ctx.reply('❌ Terjadi kesalahan internal. Silakan coba lagi nanti.');
});

// Start bot
bot.launch().then(() => {
  log('Bot Jasher Premium started successfully!');
}).catch(err => {
  log('Failed to start bot:', err);
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));