const { Telegraf, session } = require('telegraf');
const { message } = require('telegraf/filters');
const config = require('./config');
const commandHandler = require('./src/commands');
const { handleMessage, handleCallbackQuery } = require('./src/handlers');

const bot = new Telegraf(config.BOT_TOKEN);

// Session middleware
bot.use(session());

// Register handlers
bot.start(commandHandler.start);
bot.help(commandHandler.help);
bot.command('menu', commandHandler.menu);
bot.command('owner', commandHandler.owner);
bot.command('addprem', commandHandler.addPremium);
bot.command('delprem', commandHandler.delPremium);
bot.command('listprem', commandHandler.listPremium);
bot.command('addbl', commandHandler.addBlacklist);
bot.command('delbl', commandHandler.delBlacklist);
bot.command('listbl', commandHandler.listBlacklist);
bot.command('autojasher', commandHandler.autoJasher);
bot.command('stopautojasher', commandHandler.stopAutoJasher);
bot.command('listgroup', commandHandler.listGroup);
bot.command('tourl', commandHandler.toUrl);
bot.command('sharevip', commandHandler.shareVip);
bot.command('obf', commandHandler.obfMenu);

// Handle messages
bot.on(message('text'), handleMessage);
bot.on('callback_query', handleCallbackQuery);

// Handle group events
bot.on('chat_member', async (ctx) => {
  if (ctx.chatMember.new_chat_member.status === 'member') {
    // Add group to database
    const groupId = ctx.chat.id;
    const groupName = ctx.chat.title;
    await global.db.addGroup(groupId, groupName);
  }
});

// Error handling
bot.catch((err, ctx) => {
  console.error(`Error for ${ctx.updateType}:`, err);
  ctx.reply('Terjadi kesalahan pada bot. Silakan coba lagi nanti.');
});

// Start bot
bot.launch().then(() => {
  console.log('Bot Jasher Premium started!');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));