const { User, Group, Blacklist } = require('../lib/database');
const { log } = require('../lib/utils');
const { isPremium } = require('../lib/middleware');

// Handler untuk ketika bot ditambahkan ke group
async function handleNewChatMembers(ctx) {
  if (ctx.message.new_chat_members) {
    for (const member of ctx.message.new_chat_members) {
      if (member.id === ctx.botInfo.id) {
        // Bot ditambahkan ke group
        const groupId = ctx.chat.id;
        
        try {
          // Cek apakah group di blacklist
          const blacklisted = await Blacklist.findOne({ groupId });
          if (blacklisted) {
            await ctx.reply(
              `❌ Group ini telah di-blacklist!\n` +
              `Alasan: ${blacklisted.reason}\n\n` +
              `Bot akan keluar dari group.`
            );
            await ctx.leaveChat();
            return;
          }

          // Simpan/update group
          let group = await Group.findOne({ groupId });
          if (!group) {
            group = new Group({
              groupId,
              title: ctx.chat.title,
              username: ctx.chat.username || ''
            });
          } else {
            group.isActive = true;
          }
          await group.save();

          // Update user yang menambahkan bot
          const user = await User.findOne({ userId: ctx.from.id });
          if (user && !user.joinedGroups.includes(groupId)) {
            user.joinedGroups.push(groupId);
            await user.save();
          }

          await ctx.reply(
            `🤖 Terima kasih telah menambahkan Jasher Bot!\n\n` +
            `Gunakan /start untuk melihat command yang tersedia.\n` +
            `Tambahkan bot ke 3 group untuk mendapatkan akses premium gratis!`
          );
        } catch (error) {
          log(`Error handling new chat members: ${error.message}`);
        }
      }
    }
  }
}

// Handler untuk ketika bot dikick dari group
async function handleLeftChatMember(ctx) {
  if (ctx.message.left_chat_member && ctx.message.left_chat_member.id === ctx.botInfo.id) {
    const groupId = ctx.chat.id;
    
    try {
      // Update status group menjadi tidak aktif
      await Group.findOneAndUpdate(
        { groupId },
        { isActive: false }
      );
      
      log(`Bot removed from group: ${groupId}`);
    } catch (error) {
      log(`Error handling left chat member: ${error.message}`);
    }
  }
}

// Handler untuk pesan yang dikirim di group (moderasi)
async function handleGroupMessage(ctx) {
  if (ctx.chat.type === 'group' || ctx.chat.type === 'supergroup') {
    try {
      const group = await Group.findOne({ groupId: ctx.chat.id });
      if (!group || !group.isActive) return;

      const message = ctx.message.text || '';
      const settings = group.settings;

      // Cek antispam (jika pesan terlalu pendek dan berulang)
      if (settings.antispam) {
        // Implementasi deteksi spam sederhana
        const now = Date.now();
        const userKey = `${ctx.chat.id}_${ctx.from.id}`;
        
        if (!ctx.session.spamCount) ctx.session.spamCount = {};
        if (!ctx.session.spamCount[userKey]) {
          ctx.session.spamCount[userKey] = { count: 0, lastMessage: 0 };
        }
        
        const userSpam = ctx.session.spamCount[userKey];
        
        if (now - userSpam.lastMessage < 2000) { // 2 detik
          userSpam.count++;
          if (userSpam.count > 3) {
            await ctx.deleteMessage();
            await ctx.reply('❌ Pesan spam terdeteksi dan dihapus!');
            userSpam.count = 0;
            return;
          }
        } else {
          userSpam.count = 0;
        }
        
        userSpam.lastMessage = now;
      }

      // Cek noevent (jika mengandung kata event tertentu)
      if (settings.noevent && /event|acara|kumpul|meet|rapat/i.test(message)) {
        await ctx.deleteMessage();
        await ctx.reply('❌ Pembahasan event tidak diizinkan di group ini!');
        return;
      }

      // Cek nolinks (jika mengandung URL)
      if (settings.nolinks && /https?:\/\/|www\.|\.(com|org|net|id)/i.test(message)) {
        await ctx.deleteMessage();
        await ctx.reply('❌ Berbagi link tidak diizinkan di group ini!');
        return;
      }

      // Cek noforwards (jika pesan diforward)
      if (settings.noforwards && ctx.message.forward_from) {
        await ctx.deleteMessage();
        await ctx.reply('❌ Forward pesan tidak diizinkan di group ini!');
        return;
      }

      // Cek nocontacts (jika mengandung nomor telepon)
      if (settings.nocontacts && /(\+?\d{1,3}[-.\s]?)?\(?\d{2,4}\)?[-.\s]?\d{3,4}[-.\s]?\d{3,4}/.test(message)) {
        await ctx.deleteMessage();
        await ctx.reply('❌ Berbagi kontak tidak diizinkan di group ini!');
        return;
      }

      // Cek nohastags (jika mengandung hashtag)
      if (settings.nohastags && /#\w+/.test(message)) {
        await ctx.deleteMessage();
        await ctx.reply('❌ Penggunaan hashtag tidak diizinkan di group ini!');
        return;
      }

      // Cek nocommands (jika mengandung command)
      if (settings.nocommands && /^\//.test(message)) {
        // Allow bot commands but not user commands
        if (!ctx.message.entities || !ctx.message.entities.some(e => e.type === 'bot_command')) {
          await ctx.deleteMessage();
          await ctx.reply('❌ Penggunaan command tidak diizinkan di group ini!');
          return;
        }
      }

    } catch (error) {
      log(`Error handling group message: ${error.message}`);
    }
  }
}

// Handler untuk share (otomatis pilih mode berdasarkan status user)
async function handleShare(ctx) {
  // Hanya bisa dilakukan di private chat
  if (ctx.chat.type !== 'private') {
    return ctx.reply('❌ Fitur share hanya bisa digunakan di private chat!');
  }

  const user = ctx.user;
  const message = ctx.message.text || '';
  const repliedMessage = ctx.message.reply_to_message;

  // Cek apakah user memiliki akses premium
  const hasPremium = user.isPremium && user.premiumExpiry > new Date();

  if (!hasPremium && user.joinedGroups.length < 3) {
    return ctx.reply(
      `❌ Untuk menggunakan fitur share, Anda perlu:\n` +
      `1. Menambahkan bot ke 3 group (saat ini: ${user.joinedGroups.length}/3), atau\n` +
      `2. Membeli akses premium dengan /buyprem\n\n` +
      `Gunakan /sharefree jika sudah menambahkan bot ke 3 group.`
    );
  }

  let shareText = '';

  // Jika user reply ke pesan
  if (repliedMessage) {
    shareText = repliedMessage.text || repliedMessage.caption || '';
    
    if (!shareText) {
      return ctx.reply('❌ Tidak ada teks yang bisa dibagikan!');
    }
  } else if (message.startsWith('/share ')) {
    // Jika user mengirim teks langsung
    const textToShare = message.replace('/share', '').trim();
    
    if (!textToShare) {
      return ctx.reply('❌ Format: /share <teks> atau reply pesan dengan /share');
    }
    
    shareText = textToShare;
  } else {
    return;
  }

  try {
    // Kirim ke semua group yang user telah tambahkan bot
    let success = 0;
    let failed = 0;
    const groups = user.joinedGroups;

    if (groups.length === 0) {
      return ctx.reply('❌ Anda belum menambahkan bot ke group manapun!');
    }

    const progressMessage = await ctx.reply(
      `📤 Memulai share ke ${groups.length} group...\n` +
      `Mode: ${hasPremium ? '⚡ VIP (tanpa delay)' : '🐢 Free (delay 2 detik)'}`
    );

    for (let i = 0; i < groups.length; i++) {
      const groupId = groups[i];
      
      try {
        // Cek apakah group masih aktif dan tidak diblacklist
        const group = await Group.findOne({ groupId, isActive: true });
        const blacklisted = await Blacklist.findOne({ groupId });
        
        if (!group || blacklisted) {
          failed++;
          continue;
        }

        if (!hasPremium) {
          // Share Free - dengan delay 2 detik
          await new Promise(resolve => setTimeout(resolve, 2000));
        }
        
        await ctx.telegram.sendMessage(groupId, `📢 Share from @${user.username || user.firstName}:\n\n${shareText}`);
        success++;

        // Update progress
        if (i % 2 === 0 || i === groups.length - 1) {
          await ctx.telegram.editMessageText(
            progressMessage.chat.id,
            progressMessage.message_id,
            null,
            `📤 Sharing ke ${groups.length} group...\n` +
            `✅ Berhasil: ${success} | ❌ Gagal: ${failed}\n` +
            `Mode: ${hasPremium ? '⚡ VIP (tanpa delay)' : '🐢 Free (delay 2 detik)'}`
          );
        }
      } catch (error) {
        failed++;
        log(`Failed to share to group ${groupId}: ${error.message}`);
      }
    }

    await ctx.telegram.editMessageText(
      progressMessage.chat.id,
      progressMessage.message_id,
      null,
      `✅ Share selesai!\n` +
      `✔️ Berhasil: ${success} group\n` +
      `❌ Gagal: ${failed} group\n` +
      `Mode: ${hasPremium ? '⚡ VIP (tanpa delay)' : '🐢 Free (delay 2 detik)'}`
    );

    // Update share count
    user.shareCount += 1;
    await user.save();

  } catch (error) {
    ctx.reply('❌ Gagal melakukan share!');
    log(`Error sharing: ${error.message}`);
  }
}
  } else if (message.startsWith('/share')) {
    const textToShare = message.replace('/share', '').trim();
    
    if (!textToShare) {
      return ctx.reply('❌ Format: /share <teks> atau reply pesan dengan /share');
    }

    try {
      let success = 0;
      let failed = 0;
      const groups = user.joinedGroups;

      if (groups.length === 0) {
        return ctx.reply('❌ Anda belum menambahkan bot ke group manapun!');
      }

      for (const groupId of groups) {
        try {
          // Cek apakah group masih aktif dan tidak diblacklist
          const group = await Group.findOne({ groupId, isActive: true });
          const blacklisted = await Blacklist.findOne({ groupId });
          
          if (!group || blacklisted) {
            failed++;
            continue;
          }

          if (hasPremium) {
            await ctx.telegram.sendMessage(groupId, `📢 Share from @${user.username || user.firstName}:\n\n${textToShare}`);
          } else {
            await new Promise(resolve => setTimeout(resolve, 2000));
            await ctx.telegram.sendMessage(groupId, `📢 Share from @${user.username || user.firstName}:\n\n${textToShare}`);
          }
          success++;
        } catch (error) {
          failed++;
          log(`Failed to share to group ${groupId}: ${error.message}`);
        }
      }

      ctx.reply(
        `✅ Share berhasil!\n` +
        `✔️ Berhasil: ${success} group\n` +
        `❌ Gagal: ${failed} group\n` +
        `${hasPremium ? '⚡ Mode: VIP (cepat)' : '🐢 Mode: Free (lambat)'}`
      );

      user.shareCount += 1;
      await user.save();

    } catch (error) {
      ctx.reply('❌ Gagal melakukan share!');
      log(`Error sharing: ${error.message}`);
    }
  }
}

// Handler untuk tourl (upload ke uguu.se)
async function handleTourl(ctx) {
  if (!ctx.message.reply_to_message) {
    return ctx.reply('❌ Balas sebuah foto dengan /tourl');
  }

  const repliedMessage = ctx.message.reply_to_message;
  
  if (!repliedMessage.photo) {
    return ctx.reply('❌ Hanya foto yang didukung!');
  }

  try {
    // Dapatkan file photo dengan kualitas tertinggi
    const photo = repliedMessage.photo[repliedMessage.photo.length - 1];
    const fileLink = await ctx.telegram.getFileLink(photo.file_id);
    
    // Download photo
    const response = await fetch(fileLink);
    const buffer = await response.buffer();
    
    // Simpan sementara
    const tempPath = path.join(__dirname, '..', 'temp', `photo_${Date.now()}.jpg`);
    await fs.writeFile(tempPath, buffer);
    
    // Upload ke uguu.se
    const url = await uploadToUguu(tempPath);
    
    // Hapus file temp
    await fs.unlink(tempPath);
    
    // Kirim hasil
    await ctx.reply(`✅ Berhasil diupload!\n\n🔗 URL: ${url}`);
  } catch (error) {
    ctx.reply('❌ Gagal mengupload foto!');
    log(`Error uploading to uguu: ${error.message}`);
  }
}

module.exports = {
  handleNewChatMembers,
  handleLeftChatMember,
  handleGroupMessage,
  handleShare,
  handleTourl
};