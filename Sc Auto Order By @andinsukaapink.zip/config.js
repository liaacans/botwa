module.exports = {
    BOT_TOKEN: "8439733385:AAEiJwAI7cjS274oHOgEOdeVOVo3xzrw0MY",
    OWNER_IDS: ["7568960443"],
    OWNER_ID: "7568960443",
    CHANNEL_ID: "-1003011195058",
    chUsn: "@testiandinoffc",
    gbUsn: "@aboutfreepanel",
    CHANNEL_URL: "https://t.me/ginaimutp",
    BOT_NAME: "GINASTORE OFFICIAL",
    nomor_pencairan: "085654127071",
    type_ewallet: "dana",
    atas_nama_ewallet: "Akhmad Aulia Rahman",
    
    PAYMENT: {
        apiAtlantic: "s9rz6t3MREFEQxNvNwa0e6ObNj6NKCwQDwWQhNm06ZGAlWzUhE0RPffeYYnHk5XYM8lTITnCvHly0lRTHAbms3cVD9hVmhXtSs3V",
        FeeTransaksi: 50
    },
    
    PTERODACTYL: {
        domain: "https://masvilxpribadiv5.store-panell.my.id",
        apiKey: "ptla_PdvKiGK51OGSBH2iSJfvauXXrqe6tBfEU8R8LUGCrnk",
        clientKey: "ptlc_6mf5XLM1hoIlAtbsWJg89UFjUtyKXRSkSgIjrA1elPJ",
        loc: "1",
        nest: "5",
        eggs: {
            nodejs: "15",
            python: "16", 
            pm2: "17"
        }
    },
    
    PANEL_PRICES: {
        '5gb': 1000,
        '6gb': 2000,
        '7gb': 3000,
        '8gb': 4000,
        '9gb': 5000,
        '10gb': 6000,
        'unli': 7000
    },
    
    RESELLER_PRICES: {
        reseller: 5000
    },
    
    RESELLER: {
        reseller: {
            daily_limit: 5,
            max_ram: 0,
            sell_price: 5000
        }
    },
    
    SPECIAL_PANEL_PRICES: {
        admin_panel: 5000,
        reseller_panel: 5000,
        owner_panel: 10000,
        pt_panel: 7000,
        tk_panel: 9000
    }
};