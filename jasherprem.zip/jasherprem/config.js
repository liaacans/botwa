global.BOT_TOKEN = "8198305874:AAH1Sfr54fyWkPSdfuLQTK_5hSyW69V2C7o";
global.OWNER_ID = "8135269613";
global.PREMIUM_PRICE = 50000; // Harga premium dalam Rupiah
global.PREMIUM_DAYS = 30; // Durasi premium default
global.FREE_TRIAL_DAYS = 3; // Masa trial gratis

// Database setup
global.users = new Set();
global.premiumUsers = new Map(); // userid: {expiry: Date, addedBy: ownerid}
global.blacklistGroups = new Set();
global.groups = new Set();

// Group settings
global.groupSettings = new Map(); // groupid: {antispam: boolean, noevent: boolean, etc}

module.exports = {
  BOT_TOKEN: global.BOT_TOKEN,
  OWNER_ID: global.OWNER_ID
};