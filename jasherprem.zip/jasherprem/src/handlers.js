const { Markup } = require('telegraf');
const moment = require('moment-timezone');

const { 
  addUser, 
  addGroup, 
  deactivateGroup, 
  addPremium, 
  removePremium, 
  isPremium, 
  addBlacklist, 
  removeBlacklist, 
  isBlacklisted,
  setGroupSetting,
  getGroupSetting,
  getGroupSettings,
  users,
  groups,
  premiumUsers,
  blacklist
} = require('../lib/database');

const { log } = require('../lib/utils');
const { DEVELOPER_ID } = require('../config');

// Spam detection variables
const userMessageCounts = new Map();
const spamDetectionTime = 10000; // 10 seconds
const maxMessagesPerInterval = 5;

// Handler untuk new chat members (bot ditambahkan ke group)
function handleNewChatMembers(ctx) {
  if (ctx.message.new_chat_members.some(member => member.is_bot && member.id === ctx.botInfo.id)) {
    const groupId = ctx.chat.id;
    const groupName = ctx.chat.title;
    
    addGroup(groupId, groupName);
    
    ctx.reply(`Terima kasih telah menambahkan saya ke group ini! Saya akan membantu melindungi group dari spam.

Gunakan command berikut untuk mengatur keamanan group:
/antispam - Aktifkan/matikan anti spam
/noevent - Aktifkan/matikan pemblokiran event
/nolinks - Aktifkan/matikan pemblokiran link
/noforwards - Aktifkan/matikan pemblokiran pesan terusan
/nocontacts - Aktifkan/matikan pemblokiran kontak
/nohashtags - Aktifkan/matikan pemblokiran hashtag
/nocommands - Aktifkan/matikan pemblokiran command

Status default: Anti-spam dan anti-event aktif.`);
  }
}

// Handler untuk left chat member (bot dikick dari group)
function handleLeftChatMember(ctx) {
  if (ctx.message.left_chat_member && ctx.message.left_chat_member.id === ctx.botInfo.id) {
    const groupId = ctx.chat.id;
    deactivateGroup(groupId);
  }
}

// Handler untuk mendeteksi spam
function handleSpamDetection(ctx) {
  const groupId = ctx.chat.id;
  const userId = ctx.from.id;
  
  // Jika anti-spam tidak aktif, skip
  if (!getGroupSetting(groupId, 'antispam')) {
    return false;
  }
  
  const now = Date.now();
  const userKey = `${groupId}_${userId}`;
  
  // Initialize user message count
  if (!userMessageCounts.has(userKey)) {
    userMessageCounts.set(userKey, {
      count: 1,
      lastReset: now
    });
    return false;
  }
  
  const userData = userMessageCounts.get(userKey);
  
  // Reset count if interval has passed
  if (now - userData.lastReset > spamDetectionTime) {
    userData.count = 1;
    userData.lastReset = now;
    return false;
  }
  
  // Increment message count
  userData.count++;
  
  // Check if user is spamming
  if (userData.count > maxMessagesPerInterval) {
    // Delete spam messages
    try {
      ctx.deleteMessage();
    } catch (error) {
      log('Tidak bisa menghapus pesan spam:', error);
    }
    
    // Warn or restrict user
    if (userData.count === maxMessagesPerInterval + 1) {
      ctx.reply(`⚠️ @${ctx.from.username || ctx.from.first_name}, mohon jangan spam!`);
    } else if (userData.count > maxMessagesPerInterval + 3) {
      try {
        ctx.telegram.restrictChatMember(groupId, userId, {
          until_date: Math.floor(Date.now() / 1000) + 300, // 5 minutes
          can_send_messages: false
        });
        ctx.reply(`⛔ @${ctx.from.username || ctx.from.first_name} dibisukan selama 5 menit karena spam.`);
      } catch (error) {
        log('Tidak bisa membisukan user:', error);
      }
    }
    
    return true;
  }
  
  return false;
}

// Handler untuk memfilter konten terlarang
function handleContentFilter(ctx) {
  const groupId = ctx.chat.id;
  const message = ctx.message;
  
  // Cek event (jika noevent aktif)
  if (getGroupSetting(groupId, 'noevent') && (message.poll || message.dice)) {
    try {
      ctx.deleteMessage();
      ctx.reply(`❌ Event tidak diizinkan di group ini.`);
      return true;
    } catch (error) {
      log('Tidak bisa menghapus pesan event:', error);
    }
  }
  
  // Cek links (jika nolinks aktif)
  if (getGroupSetting(groupId, 'nolinks')) {
    const text = message.text || message.caption || '';
    const urlRegex = /https?:\/\/[^\s]+/g;
    
    if (urlRegex.test(text)) {
      try {
        ctx.deleteMessage();
        ctx.reply(`❌ Link tidak diizinkan di group ini.`);
        return true;
      } catch (error) {
        log('Tidak bisa menghapus pesan dengan link:', error);
      }
    }
  }
  
  // Cek forwards (jika noforwards aktif)
  if (getGroupSetting(groupId, 'noforwards') && message.forward_from_chat) {
    try {
      ctx.deleteMessage();
      ctx.reply(`❌ Pesan terusan tidak diizinkan di group ini.`);
      return true;
    } catch (error) {
      log('Tidak bisa menghapus pesan terusan:', error);
    }
  }
  
  // Cek contacts (jika nocontacts aktif)
  if (getGroupSetting(groupId, 'nocontacts') && message.contact) {
    try {
      ctx.deleteMessage();
      ctx.reply(`❌ Berbagi kontak tidak diizinkan di group ini.`);
      return true;
    } catch (error) {
      log('Tidak bisa menghapus pesan kontak:', error);
    }
  }
  
  // Cek hashtags (jika nohashtags aktif)
  if (getGroupSetting(groupId, 'nohashtags')) {
    const text = message.text || message.caption || '';
    const hashtagRegex = /#\w+/g;
    
    if (hashtagRegex.test(text)) {
      try {
        ctx.deleteMessage();
        ctx.reply(`❌ Hashtag tidak diizinkan di group ini.`);
        return true;
      } catch (error) {
        log('Tidak bisa menghapus pesan dengan hashtag:', error);
      }
    }
  }
  
  // Cek commands (jika nocommands aktif)
  if (getGroupSetting(groupId, 'nocommands')) {
    const text = message.text || '';
    const commandRegex = /^\/([a-zA-Z0-9_]+)(@\w+)?\b/;
    
    if (commandRegex.test(text) && !text.startsWith('/antispam') && 
        !text.startsWith('/noevent') && !text.startsWith('/nolinks') &&
        !text.startsWith('/noforwards') && !text.startsWith('/nocontacts') &&
        !text.startsWith('/nohashtags') && !text.startsWith('/nocommands') &&
        !text.startsWith('/settings')) {
      try {
        ctx.deleteMessage();
        ctx.reply(`❌ Command tidak diizinkan di group ini.`);
        return true;
      } catch (error) {
        log('Tidak bisa menghapus pesan command:', error);
      }
    }
  }
  
  return false;
}

// Handler untuk command admin (hanya di group)
function handleGroupCommands(ctx, command) {
  const chatId = ctx.chat.id;
  const isAdmin = ctx.from && (ctx.from.id.toString() === DEVELOPER_ID || 
                (ctx.chat.type === 'supergroup' && (ctx.from.status === 'administrator' || ctx.from.status === 'creator')));
  
  if (!isAdmin) {
    return ctx.reply('Hanya admin yang bisa menggunakan command ini!');
  }
  
  switch (command) {
    case 'antispam':
      const antispamCurrent = getGroupSetting(chatId, 'antispam');
      setGroupSetting(chatId, 'antispam', !antispamCurrent);
      ctx.reply(`Anti-spam ${!antispamCurrent ? 'diaktifkan' : 'dimatikan'}!`);
      break;
      
    case 'noevent':
      const noeventCurrent = getGroupSetting(chatId, 'noevent');
      setGroupSetting(chatId, 'noevent', !noeventCurrent);
      ctx.reply(`Pemblokiran event ${!noeventCurrent ? 'diaktifkan' : 'dimatikan'}!`);
      break;
      
    case 'nolinks':
      const nolinksCurrent = getGroupSetting(chatId, 'nolinks');
      setGroupSetting(chatId, 'nolinks', !nolinksCurrent);
      ctx.reply(`Pemblokiran link ${!nolinksCurrent ? 'diaktifkan' : 'dimatikan'}!`);
      break;
      
    case 'noforwards':
      const noforwardsCurrent = getGroupSetting(chatId, 'noforwards');
      setGroupSetting(chatId, 'noforwards', !noforwardsCurrent);
      ctx.reply(`Pemblokiran pesan terusan ${!noforwardsCurrent ? 'diaktifkan' : 'dimatikan'}!`);
      break;
      
    case 'nocontacts':
      const nocontactsCurrent = getGroupSetting(chatId, 'nocontacts');
      setGroupSetting(chatId, 'nocontacts', !nocontactsCurrent);
      ctx.reply(`Pemblokiran kontak ${!nocontactsCurrent ? 'diaktifkan' : 'dimatikan'}!`);
      break;
      
    case 'nohashtags':
      const nohashtagsCurrent = getGroupSetting(chatId, 'nohashtags');
      setGroupSetting(chatId, 'nohashtags', !nohashtagsCurrent);
      ctx.reply(`Pemblokiran hashtag ${!nohashtagsCurrent ? 'diaktifkan' : 'dimatikan'}!`);
      break;
      
    case 'nocommands':
      const nocommandsCurrent = getGroupSetting(chatId, 'nocommands');
      setGroupSetting(chatId, 'nocommands', !nocommandsCurrent);
      ctx.reply(`Pemblokiran command ${!nocommandsCurrent ? 'diaktifkan' : 'dimatikan'}!`);
      break;
      
    case 'settings':
      const settings = getGroupSettings(chatId);
      const settingsText = `
╭─❒ 「 Group Settings 」 
├ Anti-spam: ${settings.antispam ? '✅' : '❌'}
├ Blokir event: ${settings.noevent ? '✅' : '❌'}
├ Blokir link: ${settings.nolinks ? '✅' : '❌'}
├ Blokir terusan: ${settings.noforwards ? '✅' : '❌'}
├ Blokir kontak: ${settings.nocontacts ? '✅' : '❌'}
├ Blokir hashtag: ${settings.nohashtags ? '✅' : '❌'}
╰ Blokir command: ${settings.nocommands ? '✅' : '❌'}
      `.trim();
      ctx.reply(settingsText);
      break;
      
    default:
      ctx.reply('Command tidak dikenali!');
  }
}

// Handler untuk command owner
function handleOwnerCommands(ctx, command) {
  const userId = ctx.from.id;
  const isCreator = userId.toString() === DEVELOPER_ID;
  
  if (!isCreator) {
    return ctx.reply('Hanya owner yang bisa menggunakan command ini!');
  }
  
  const args = ctx.message.text.split(' ').slice(1);
  
  switch (command) {
    case 'addprem':
      if (!ctx.message.reply_to_message) {
        return ctx.reply('Balas pesan user untuk menambah premium!');
      }
      
      const targetUserId = ctx.message.reply_to_message.from.id;
      const days = args[0] ? parseInt(args[0]) : 3;
      
      if (isNaN(days) || days < 1) {
        return ctx.reply('Format: /addprem <jumlah_hari>');
      }
      
      addPremium(targetUserId, days);
      ctx.reply(`Berhasil menambah premium untuk user ${targetUserId} selama ${days} hari!`);
      break;
      
    case 'delprem':
      if (!ctx.message.reply_to_message) {
        return ctx.reply('Balas pesan user untuk menghapus premium!');
      }
      
      const delUserId = ctx.message.reply_to_message.from.id;
      removePremium(delUserId);
      ctx.reply(`Berhasil menghapus premium untuk user ${delUserId}!`);
      break;
      
    case 'listprem':
      const premiumList = premiumUsers.map(u => `- User ID: ${u.id} (Expiry: ${moment(u.expiry).format('DD/MM/YYYY')})`).join('\n');
      ctx.reply(`Daftar User Premium:\n${premiumList || 'Tidak ada user premium'}`);
      break;
      
    case 'bc':
      if (args.length === 0) {
        return ctx.reply('Format: /bc <pesan>');
      }
      
      const message = args.join(' ');
      let successCount = 0;
      let failCount = 0;
      
      users.forEach(userId => {
        try {
          ctx.telegram.sendMessage(userId, `📢 *Broadcast dari Owner:*\n\n${message}`, { parse_mode: 'Markdown' });
          successCount++;
        } catch (error) {
          failCount++;
          log(`Gagal mengirim broadcast ke ${userId}:`, error);
        }
      });
      
      ctx.reply(`Broadcast selesai!\nBerhasil: ${successCount}\nGagal: ${failCount}`);
      break;
      
    case 'addbl':
      if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.sender_chat) {
        return ctx.reply('Balas pesan dari group untuk menambah blacklist!');
      }
      
      const groupId = ctx.message.reply_to_message.sender_chat.id;
      addBlacklist(groupId);
      ctx.reply(`Group ${groupId} berhasil ditambahkan ke blacklist!`);
      break;
      
    case 'delbl':
      if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.sender_chat) {
        return ctx.reply('Balas pesan dari group untuk menghapus blacklist!');
      }
      
      const delGroupId = ctx.message.reply_to_message.sender_chat.id;
      removeBlacklist(delGroupId);
      ctx.reply(`Group ${delGroupId} berhasil dihapus dari blacklist!`);
      break;
      
    case 'listbl':
      const blacklistText = blacklist.length > 0 
        ? blacklist.map(id => `- ${id}`).join('\n') 
        : 'Tidak ada group dalam blacklist';
      ctx.reply(`Daftar Blacklist:\n${blacklistText}`);
      break;
      
    case 'hapusgb':
      if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.sender_chat) {
        return ctx.reply('Balas pesan dari group untuk menghapus group!');
      }
      
      const removeGroupId = ctx.message.reply_to_message.sender_chat.id;
      deactivateGroup(removeGroupId);
      ctx.reply(`Group ${removeGroupId} berhasil dihapus dari database!`);
      break;
      
    case 'listgb':
      const groupList = groups.map(g => `- ${g.name} (ID: ${g.id}) ${g.active ? '🟢' : '🔴'}`).join('\n');
      ctx.reply(`Daftar Group:\n${groupList || 'Tidak ada group'}`);
      break;
      
    case 'tourl':
      if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.photo) {
        return ctx.reply('Balas foto untuk mengubah menjadi URL!');
      }
      
      const photo = ctx.message.reply_to_message.photo[ctx.message.reply_to_message.photo.length - 1];
      ctx.telegram.getFileLink(photo.file_id)
        .then(link => {
          ctx.reply(`URL foto: ${link}`);
        })
        .catch(error => {
          ctx.reply('Gagal mendapatkan URL foto!');
          log('Error getting file link:', error);
        });
      break;
      
    default:
      ctx.reply('Command owner tidak dikenali!');
  }
}

// Handler untuk share pesan
function handleShare(ctx, isVip = false) {
  if (ctx.chat.type !== 'private') {
    return ctx.reply('Fitur share hanya bekerja di private chat!');
  }
  
  if (isVip && !isPremium(ctx.from.id)) {
    return ctx.reply('Anda bukan user premium! Silahkan upgrade untuk menggunakan fitur VIP.');
  }
  
  const message = ctx.message.text || ctx.message.caption;
  const replyToMessage = ctx.message.reply_to_message;
  
  if (!message && !replyToMessage) {
    return ctx.reply('Kirim pesan atau balas pesan untuk dishare!');
  }
  
  let shareText = '';
  let shareOptions = {};
  
  if (replyToMessage) {
    // Share pesan yang dibalas
    if (replyToMessage.text) shareText = replyToMessage.text;
    if (replyToMessage.caption) shareText = replyToMessage.caption;
    
    // Tambahkan media jika ada
    if (replyToMessage.photo) {
      const photo = replyToMessage.photo[replyToMessage.photo.length - 1];
      shareOptions = { caption: shareText };
      ctx.replyWithPhoto(photo.file_id, shareOptions);
    } else if (replyToMessage.video) {
      shareOptions = { caption: shareText };
      ctx.replyWithVideo(replyToMessage.video.file_id, shareOptions);
    } else if (replyToMessage.document) {
      shareOptions = { caption: shareText };
      ctx.replyWithDocument(replyToMessage.document.file_id, shareOptions);
    } else {
      ctx.reply(shareText);
    }
  } else {
    // Share pesan biasa
    ctx.reply(message);
  }
  
  // Broadcast ke groups
  let successCount = 0;
  let failCount = 0;
  
  groups.filter(g => g.active && !isBlacklisted(g.id)).forEach(group => {
    try {
      if (replyToMessage) {
        if (replyToMessage.photo) {
          const photo = replyToMessage.photo[replyToMessage.photo.length - 1];
          ctx.telegram.sendPhoto(group.id, photo.file_id, shareOptions);
        } else if (replyToMessage.video) {
          ctx.telegram.sendVideo(group.id, replyToMessage.video.file_id, shareOptions);
        } else if (replyToMessage.document) {
          ctx.telegram.sendDocument(group.id, replyToMessage.document.file_id, shareOptions);
        } else {
          ctx.telegram.sendMessage(group.id, shareText);
        }
      } else {
        ctx.telegram.sendMessage(group.id, message);
      }
      successCount++;
    } catch (error) {
      failCount++;
      deactivateGroup(group.id);
      log(`Gagal mengirim pesan ke group ${group.id}:`, error);
    }
  });
  
  ctx.reply(`Pesan berhasil dishare!\nBerhasil: ${successCount} group\nGagal: ${failCount} group`);
}

module.exports = {
  handleNewChatMembers,
  handleLeftChatMember,
  handleSpamDetection,
  handleContentFilter,
  handleGroupCommands,
  handleOwnerCommands,
  handleShare
};