const { Markup } = require('telegraf');
const database = require('../../lib/database');
const { isOwner, addUser, loadJSON, saveJSON } = require('../../lib/utils');
const moment = require('moment-timezone');
const config = require('../../config');

module.exports = (bot) => {
    // Handler untuk photo dengan caption (bukti pembayaran)
    bot.on('photo', async (ctx) => {
        // Cek jika ini adalah bukti pembayaran
        const caption = ctx.message.caption || '';
        const userId = ctx.from.id;
        
        if (caption.includes('bukti') || caption.includes('transfer') || caption.includes('pembayaran')) {
            // Forward ke owner jika user bukan owner
            if (!isOwner(userId)) {
                try {
                    await ctx.forwardMessage(config.OWNER_ID);
                    await ctx.replyWithMarkdown(`
✅ *Bukti pembayaran telah diteruskan ke owner!*

Terima kasih telah melakukan pembayaran. Owner akan memverifikasi dan mengaktifkan premium Anda dalam 1x24 jam.

*ID Anda:* ${userId}
*Waktu:* ${moment().format('DD/MM/YYYY HH:mm:ss')}

Untuk pertanyaan, hubungi @ginaaforyou`);
                } catch (error) {
                    await ctx.reply('❌ Gagal mengirim bukti pembayaran. Silakan hubungi @ginaaforyou secara manual.');
                }
            } else {
                // Jika owner yang mengirim photo
                await ctx.reply('📸 Photo received from owner.');
            }
        }
    });

    // Handler untuk document (file script)
    bot.on('document', async (ctx) => {
        const document = ctx.message.document;
        const userId = ctx.from.id;
        
        // Cek jika ini adalah script yang dikirim owner ke user
        if (isOwner(userId) && ctx.message.caption && ctx.message.caption.includes('SCRIPT')) {
            // Ini adalah script yang dikirim owner ke user
            await ctx.reply('📦 Script document telah dikirim ke user.');
            return;
        }
        
        // Cek jika user mengirim file untuk obfuscation
        const repliedTo = ctx.message.reply_to_message;
        if (repliedTo && repliedTo.from.id === ctx.botInfo.id) {
            // File di-reply ke pesan bot, mungkin untuk obfuscation
            const botMessageText = repliedTo.text || '';
            if (botMessageText.includes('obfuscation') || botMessageText.includes('encrypt')) {
                await ctx.reply('🔍 File diterima untuk processing... Gunakan command obfuscation yang sesuai.');
            }
        }
    });

    // Handler untuk text messages khusus
    bot.on('text', async (ctx) => {
        const text = ctx.message.text;
        const userId = ctx.from.id;
        
        // Skip jika ini adalah command
        if (text.startsWith('/')) return;
        
        // Handler untuk konfirmasi pembayaran manual
        if ((text.toLowerCase().includes('bukti') || text.toLowerCase().includes('transfer')) && 
            !isOwner(userId)) {
            
            await ctx.replyWithMarkdown(`
💳 *Konfirmasi Pembayaran*

Terima kasih telah mengirim konfirmasi pembayaran. Untuk proses lebih lanjut:

1. **Kirim screenshot bukti transfer** sebagai photo
2. **Pastikan bukti transfer jelas** terlihat:
   - Nama pengirim
   - Jumlah transfer  
   - Tanggal/waktu
   - Bank tujuan

3. **Caption photo** dengan format:
   "Konfirmasi Premium - ID: ${userId}"

Owner akan memverifikasi dalam 1x24 jam.`);
        }
        
        // Handler untuk pesan yang mengandung ID premium
        if (text.includes('premium') && text.includes('aktif') && isOwner(userId)) {
            // Owner mengkonfirmasi aktivasi premium
            const idMatch = text.match(/\d+/);
            if (idMatch) {
                const targetUserId = idMatch[0];
                const daysMatch = text.match(/(\d+)\s*hari/);
                const days = daysMatch ? parseInt(daysMatch[1]) : config.PREMIUM_DAYS;
                
                database.addPremium(targetUserId, days);
                
                await ctx.replyWithMarkdown(`
✅ *Premium Diaktifkan!*

*User ID:* ${targetUserId}
*Durasi:* ${days} hari
*Expiry:* ${moment().add(days, 'days').format('DD/MM/YYYY HH:mm')}

Premium berhasil diaktifkan.`);
                
                // Notify user
                try {
                    await ctx.telegram.sendMessage(targetUserId, 
                        `🎉 *PREMIUM AKTIF!*\\n\\nSelamat! Premium membership Anda telah diaktifkan.\\nDurasi: ${days} hari\\nExpiry: ${moment().add(days, 'days').format('DD/MM/YYYY HH:mm')}\\n\\nNikmati semua fitur premium! 💎`,
                        { parse_mode: 'Markdown' }
                    );
                } catch (error) {
                    console.log('Gagal notify user:', error.message);
                }
            }
        }
    });

    // Handler untuk new chat members (selain bot)
    bot.on('new_chat_members', async (ctx) => {
        const newMembers = ctx.message.new_chat_members;
        const botId = ctx.botInfo.id;
        
        // Skip jika bot yang ditambahkan (sudah dihandle di group.js)
        if (newMembers.some(member => member.id === botId)) return;
        
        // Welcome message untuk member baru
        const group = database.getGroup(ctx.chat.id);
        if (group && group.settings.antispam) {
            const welcomeText = `
👋 *Selamat Datang di Group!*

*Peraturan Group:*
• 🤝 Hormati semua member
• 📝 Gunakan bahasa yang sopan  
• 🚫 Dilarang spam dan promo tanpa ijin
• 🔗 Perhatikan aturan sharing link

*Bot Commands:*
• /groupsettings - Pengaturan group
• /help - Bantuan commands

Selamat bergabung! 🎉`;
            
            try {
                await ctx.replyWithMarkdown(welcomeText);
            } catch (error) {
                console.log('Gagal kirim welcome message:', error.message);
            }
        }
    });

    // Handler untuk left chat member
    bot.on('left_chat_member', async (ctx) => {
        const leftMember = ctx.message.left_chat_member;
        const botId = ctx.botInfo.id;
        
        // Skip jika bot yang keluar (sudah dihandle di group.js)
        if (leftMember.id === botId) return;
        
        // Goodbye message untuk member yang keluar
        const group = database.getGroup(ctx.chat.id);
        if (group) {
            try {
                await ctx.reply(`👋 Selamat tinggal ${leftMember.first_name}! Semoga sukses di perjalanan berikutnya.`);
            } catch (error) {
                console.log('Gagal kirim goodbye message:', error.message);
            }
        }
    });

    // Handler untuk message yang di-forward (anti-forward protection)
    bot.on('message', async (ctx) => {
        if (ctx.message.forward_from_chat || ctx.message.forward_from) {
            const group = database.getGroup(ctx.chat.id);
            if (group && group.settings.noforwards) {
                try {
                    await ctx.deleteMessage();
                    const warnMsg = await ctx.reply('🚫 Forwarded messages tidak diizinkan di group ini!');
                    
                    setTimeout(async () => {
                        try {
                            await ctx.deleteMessage(warnMsg.message_id);
                        } catch (e) {
                            console.log('Gagal hapus warning message:', e.message);
                        }
                    }, 5000);
                } catch (error) {
                    console.log('Gagal hapus forwarded message:', error.message);
                }
            }
        }
    });

    // Handler untuk messages dengan links (anti-link protection)
    bot.on('message', async (ctx) => {
        const message = ctx.message;
        const text = message.text || message.caption || '';
        const group = database.getGroup(ctx.chat.id);
        
        if (group && group.settings.nolinks) {
            const linkRegex = /https?:\/\/[^\s]+|www\.[^\s]+|t\.me\/[^\s]+/gi;
            if (linkRegex.test(text)) {
                try {
                    await ctx.deleteMessage();
                    const warnMsg = await ctx.reply('🚫 Sharing link tidak diizinkan di group ini!');
                    
                    setTimeout(async () => {
                        try {
                            await ctx.deleteMessage(warnMsg.message_id);
                        } catch (e) {
                            console.log('Gagal hapus warning message:', e.message);
                        }
                    }, 5000);
                } catch (error) {
                    console.log('Gagal hapus message dengan link:', error.message);
                }
            }
        }
    });

    // Handler untuk messages dengan hashtags
    bot.on('message', async (ctx) => {
        const message = ctx.message;
        const text = message.text || message.caption || '';
        const group = database.getGroup(ctx.chat.id);
        
        if (group && group.settings.nohastags) {
            const hashtagRegex = /#\w+/gi;
            if (hashtagRegex.test(text)) {
                try {
                    await ctx.deleteMessage();
                    const warnMsg = await ctx.reply('🚫 Penggunaan hashtag tidak diizinkan di group ini!');
                    
                    setTimeout(async () => {
                        try {
                            await ctx.deleteMessage(warnMsg.message_id);
                        } catch (e) {
                            console.log('Gagal hapus warning message:', e.message);
                        }
                    }, 5000);
                } catch (error) {
                    console.log('Gagal hapus message dengan hashtag:', error.message);
                }
            }
        }
    });

    // Handler untuk contact messages
    bot.on('contact', async (ctx) => {
        const group = database.getGroup(ctx.chat.id);
        if (group && group.settings.nocontacts) {
            try {
                await ctx.deleteMessage();
                const warnMsg = await ctx.reply('🚫 Sharing kontak tidak diizinkan di group ini!');
                
                setTimeout(async () => {
                    try {
                        await ctx.deleteMessage(warnMsg.message_id);
                    } catch (e) {
                        console.log('Gagal hapus warning message:', e.message);
                    }
                }, 5000);
            } catch (error) {
                console.log('Gagal hapus contact message:', error.message);
            }
        }
    });

    // Handler untuk group migration (supergroup upgrade)
    bot.on('migrate_to_chat_id', async (ctx) => {
        const oldChatId = ctx.message.chat.id;
        const newChatId = ctx.message.migrate_to_chat_id;
        
        // Update group ID di database
        const groupsData = loadJSON('groups.json');
        const groupIndex = groupsData.groups.findIndex(g => g.id === oldChatId);
        
        if (groupIndex !== -1) {
            groupsData.groups[groupIndex].id = newChatId;
            groupsData.groups[groupIndex].migrated_from = oldChatId;
            groupsData.groups[groupIndex].migrate_date = moment().format();
            
            if (saveJSON('groups.json', groupsData)) {
                console.log(`Group migrated: ${oldChatId} -> ${newChatId}`);
                
                try {
                    await ctx.reply('✅ Group telah diupgrade ke supergroup! Semua settings telah dipindahkan.');
                } catch (error) {
                    console.log('Gagal kirim migration message:', error.message);
                }
            }
        }
    });

    // Handler untuk video messages (anti-spam)
    bot.on('video', async (ctx) => {
        const group = database.getGroup(ctx.chat.id);
        if (group && group.settings.antispam) {
            // Cek flood protection untuk video
            await handleMediaFloodProtection(ctx, 'video');
        }
    });

    // Handler untuk sticker messages (anti-spam)
    bot.on('sticker', async (ctx) => {
        const group = database.getGroup(ctx.chat.id);
        if (group && group.settings.antispam) {
            // Cek flood protection untuk sticker
            await handleMediaFloodProtection(ctx, 'sticker');
        }
    });

    // Handler untuk voice messages (anti-spam)
    bot.on('voice', async (ctx) => {
        const group = database.getGroup(ctx.chat.id);
        if (group && group.settings.antispam) {
            // Cek flood protection untuk voice
            await handleMediaFloodProtection(ctx, 'voice');
        }
    });

    // Flood protection system untuk media
    const userMediaCounts = new Map();
    
    async function handleMediaFloodProtection(ctx, mediaType) {
        const userId = ctx.from.id;
        const now = Date.now();
        
        if (!userMediaCounts.has(userId)) {
            userMediaCounts.set(userId, {});
        }
        
        const userMedia = userMediaCounts.get(userId);
        if (!userMedia[mediaType]) {
            userMedia[mediaType] = [];
        }
        
        userMedia[mediaType].push(now);
        
        // Hapus media yang lebih lama dari 15 detik
        const fifteenSecondsAgo = now - 15000;
        userMedia[mediaType] = userMedia[mediaType].filter(time => time > fifteenSecondsAgo);
        
        // Jika lebih dari 3 media dalam 15 detik, anggap spam
        if (userMedia[mediaType].length > 3) {
            try {
                await ctx.deleteMessage();
                const warnMsg = await ctx.reply(`🚫 Terlalu banyak ${mediaType} messages! Mohon jangan spam.`);
                
                setTimeout(async () => {
                    try {
                        await ctx.deleteMessage(warnMsg.message_id);
                    } catch (e) {
                        console.log('Gagal hapus warning message:', e.message);
                    }
                }, 5000);
                
                // Reset counter untuk media type ini
                userMedia[mediaType] = [];
            } catch (error) {
                console.log(`Gagal hapus ${mediaType} spam:`, error.message);
            }
        }
    }

    // Error handler untuk messages
    bot.on('message', async (ctx) => {
        try {
            // Log message statistics
            if (ctx.chat.type === 'private') {
                const user = database.getUser(ctx.from.id);
                if (user) {
                    user.last_activity = moment().format();
                    database.updateUser(ctx.from.id, { last_activity: user.last_activity });
                }
            }
        } catch (error) {
            console.log('Message handler error:', error.message);
        }
    });

    // Handler untuk inline queries (jika ada)
    bot.on('inline_query', async (ctx) => {
        // Simple inline query response
        await ctx.answerInlineQuery([
            {
                type: 'article',
                id: '1',
                title: 'Jasher Bot Help',
                input_message_content: {
                    message_text: '🤖 *Jasher Bot Help*\\n\\nGunakan /help untuk melihat semua commands yang tersedia.\\n\\nSupport: @ginaaforyou',
                    parse_mode: 'Markdown'
                },
                description: 'Get help with Jasher Bot commands'
            },
            {
                type: 'article',
                id: '2',
                title: 'Premium Information',
                input_message_content: {
                    message_text: '💎 *Premium Features*\\n\\n• Fast processing\\n• Priority support\\n• All obfuscation methods\\n\\nUse /buypremium for details',
                    parse_mode: 'Markdown'
                },
                description: 'Learn about premium features'
            }
        ]);
    });

    // Handler untuk chosen inline result
    bot.on('chosen_inline_result', ({ chosenInlineResult }) => {
        console.log('Chosen inline result:', chosenInlineResult);
    });
};