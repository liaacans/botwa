const axios = require("axios");
const config = require("../config");

const client = axios.create({
  baseURL: String(config.buatqris.baseUrl || "").replace(/\/+$/, ""),
  timeout: 15000,
  headers: {
    Accept: "application/json",
    "Content-Type": "application/json"
  }
});

function getApiKey() {
  const apiKey = String(config.buatqris.apiKey || "").trim();

  if (!apiKey || apiKey === "MASUKKAN_API_KEY_XDIGITALKITA_DI_SINI") {
    throw new Error("API Key XDigitalKita belum diisi pada config.js.");
  }

  return apiKey;
}

async function requestApi(request) {
  try {
    const response = await request({
      headers: {
        "X-API-Key": getApiKey()
      }
    });
    const data = response.data;

    if (response.status < 200 || response.status >= 300 || data?.success === false) {
      return {
        success: false,
        message: data?.message || `API XDigitalKita merespons HTTP ${response.status}.`
      };
    }

    return data;
  } catch (error) {
    return {
      success: false,
      message: error.response?.data?.message || error.message || "Gagal menghubungi API XDigitalKita."
    };
  }
}

async function createQris(amount, description) {
  return requestApi(options => client.post("/create", {
    amount: Number(amount),
    description: String(description || "Pembayaran").trim().slice(0, 180)
  }, options));
}

async function checkStatus(transactionId) {
  const id = encodeURIComponent(String(transactionId || "").trim());

  if (!id) {
    return { success: false, message: "ID transaksi wajib diisi." };
  }

  return requestApi(options => client.get(`/status/${id}`, options));
}

module.exports = {
  createQris,
  checkStatus
};
