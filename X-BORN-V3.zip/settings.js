// OBEY COMMANDMENTS

global.prefa = ['','!','.',',','🐤','🗿'] //NOT CHANGE
global.owner = ['6281529400814'] //OWNER
global.botname = 'Xborn' //BOT NAME
global.versisc = "3.0.0" //NOT CHANGE
global.wsbail = require('@whiskeysockets/baileys') //NOT CHANGE
global.creator = "ᯓZipxz" //NOT CHANGE
global.packname = "Sticker By" //OPSIONAL
global.author = "ᯓZipxz" //OPSIONAL