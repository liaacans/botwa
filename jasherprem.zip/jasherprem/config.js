global.BOT_TOKEN = "8198305874:AAGhlBEYItkhH2mxD265kLIMXVEcWMiwkMM";
global.DEVELOPER = "@ginaabaikhati";
global.ADMINS = [8135269613]; // Ganti dengan ID admin

// Ekspor untuk modul lain jika diperlukan
module.exports = {
  BOT_TOKEN: global.BOT_TOKEN,
  DEVELOPER: global.DEVELOPER,
  ADMINS: global.ADMINS
};