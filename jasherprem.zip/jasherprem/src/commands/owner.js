const { Markup } = require('telegraf');
const database = require('../../lib/database');
const { isOwner, loadJSON, saveJSON } = require('../../lib/utils');
const moment = require('moment-timezone');

module.exports = (bot) => {
    // Middleware untuk cek owner
    bot.use((ctx, next) => {
        if (ctx.message && ctx.message.text && ctx.message.text.startsWith('/')) {
            const command = ctx.message.text.split(' ')[0];
            if (['/bc', '/addprem', '/delprem', '/listprem', '/addbl', '/delbl', '/listbl', '/listgroup'].includes(command)) {
                if (!isOwner(ctx.from.id)) {
                    return ctx.reply('❌ Command ini hanya untuk owner!');
                }
            }
        }
        return next();
    });

    // Broadcast command
    bot.command('bc', async (ctx) => {
        const args = ctx.message.text.split(' ').slice(1);
        if (args.length === 0) {
            return ctx.reply('❌ Format: /bc <pesan>');
        }

        const message = args.join(' ');
        const usersData = loadJSON('users.json');
        
        const progressMsg = await ctx.reply('🔄 Memulai broadcast...');
        
        let successCount = 0;
        let failCount = 0;

        for (const user of usersData.users) {
            try {
                await ctx.telegram.sendMessage(user.id, 
                    `📢 *Broadcast dari Owner*\n\n${message}`,
                    { parse_mode: 'Markdown' }
                );
                successCount++;
                
                // Delay untuk avoid rate limit
                await new Promise(resolve => setTimeout(resolve, 100));
            } catch (error) {
                console.log(`Gagal kirim ke user ${user.id}:`, error.message);
                failCount++;
            }
        }

        await ctx.telegram.editMessageText(
            progressMsg.chat.id,
            progressMsg.message_id,
            null,
            `✅ *Broadcast Selesai!*\n\n` +
            `✓ Berhasil: ${successCount} users\n` +
            `✗ Gagal: ${failCount} users\n` +
            `⏰ Waktu: ${moment().format('DD/MM/YYYY HH:mm:ss')}`,
            { parse_mode: 'Markdown' }
        );
    });

    // Add premium command
    bot.command('addprem', async (ctx) => {
        const args = ctx.message.text.split(' ').slice(1);
        if (args.length < 2) {
            return ctx.reply('❌ Format: /addprem <user_id> <days>');
        }

        const userId = args[0];
        const days = parseInt(args[1]);

        if (isNaN(days) || days < 1) {
            return ctx.reply('❌ Jumlah hari harus angka positif!');
        }

        try {
            const result = database.addPremium(userId, days);
            if (result) {
                const expiry = moment().add(days, 'days').format('DD/MM/YYYY HH:mm');
                await ctx.replyWithMarkdown(`
✅ *Premium Added!*

*User ID:* ${userId}
*Durasi:* ${days} hari
*Expiry:* ${expiry}
*Added by:* ${ctx.from.first_name}

Premium berhasil ditambahkan!`);
                
                // Notify user jika mungkin
                try {
                    await ctx.telegram.sendMessage(userId,
                        `🎉 *Selamat! Anda Mendapat Premium!*\n\n` +
                        `Durasi: ${days} hari\n` +
                        `Expiry: ${expiry}\n` +
                        `Status: ✅ AKTIF\n\n` +
                        `Nikmati semua fitur premium! 💎`,
                        { parse_mode: 'Markdown' }
                    );
                } catch (notifyError) {
                    console.log('Gagal notify user:', notifyError.message);
                }
            } else {
                await ctx.reply('❌ Gagal menambahkan premium!');
            }
        } catch (error) {
            await ctx.reply('❌ Error: ' + error.message);
        }
    });

    // Delete premium command
    bot.command('delprem', async (ctx) => {
        const args = ctx.message.text.split(' ').slice(1);
        if (args.length === 0) {
            return ctx.reply('❌ Format: /delprem <user_id>');
        }

        const userId = args[0];

        try {
            const result = database.removePremium(userId);
            if (result) {
                await ctx.replyWithMarkdown(`
✅ *Premium Removed!*

*User ID:* ${userId}
*Removed by:* ${ctx.from.first_name}
*Waktu:* ${moment().format('DD/MM/YYYY HH:mm:ss')}

Premium berhasil dihapus!`);
                
                // Notify user jika mungkin
                try {
                    await ctx.telegram.sendMessage(userId,
                        `ℹ️ *Premium Status Update*\n\n` +
                        `Premium membership Anda telah di-nonaktifkan.\n` +
                        `Silakan hubungi owner untuk info lebih lanjut.`,
                        { parse_mode: 'Markdown' }
                    );
                } catch (notifyError) {
                    console.log('Gagal notify user:', notifyError.message);
                }
            } else {
                await ctx.reply('❌ User tidak ditemukan atau bukan premium!');
            }
        } catch (error) {
            await ctx.reply('❌ Error: ' + error.message);
        }
    });

    // List premium command
    bot.command('listprem', async (ctx) => {
        const premiumData = loadJSON('premium.json');
        const usersData = loadJSON('users.json');
        
        if (premiumData.users.length === 0) {
            return ctx.reply('❌ Tidak ada user premium!');
        }

        let listText = '💎 *List User Premium*\n\n';
        let activeCount = 0;
        let expiredCount = 0;

        for (const premUser of premiumData.users) {
            const userInfo = usersData.users.find(u => u.id === premUser.id);
            const username = userInfo ? `@${userInfo.username}` : 'No username';
            const isActive = moment().isBefore(moment(premUser.expiry));
            
            if (isActive) activeCount++;
            else expiredCount++;

            listText += `🆔 ${premUser.id}\n` +
                       `👤 ${username}\n` +
                       `📅 Expiry: ${moment(premUser.expiry).format('DD/MM/YY HH:mm')}\n` +
                       `Status: ${isActive ? '✅ AKTIF' : '❌ EXPIRED'}\n` +
                       `Added: ${moment(premUser.added_date).format('DD/MM/YY')}\n` +
                       `━━━━━━━━━━━━━━━━━━━━\n`;
        }

        listText += `\n*Summary:*\n` +
                   `✅ Aktif: ${activeCount} users\n` +
                   `❌ Expired: ${expiredCount} users\n` +
                   `📊 Total: ${premiumData.users.length} users`;

        // Split message jika terlalu panjang
        if (listText.length > 4000) {
            const parts = listText.match(/[\s\S]{1,4000}/g);
            for (const part of parts) {
                await ctx.replyWithMarkdown(part);
                await new Promise(resolve => setTimeout(resolve, 500));
            }
        } else {
            await ctx.replyWithMarkdown(listText);
        }
    });

    // Add blacklist command
    bot.command('addbl', async (ctx) => {
        const args = ctx.message.text.split(' ').slice(1);
        if (args.length === 0) {
            return ctx.reply('❌ Format: /addbl <user_id> [reason]');
        }

        const userId = args[0];
        const reason = args.slice(1).join(' ') || 'No reason provided';

        try {
            const result = database.addBlacklist(userId, reason);
            if (result) {
                await ctx.replyWithMarkdown(`
🚫 *User Blacklisted!*

*User ID:* ${userId}
*Alasan:* ${reason}
*Oleh:* ${ctx.from.first_name}
*Waktu:* ${moment().format('DD/MM/YYYY HH:mm:ss')}

User berhasil ditambahkan ke blacklist.`);
            } else {
                await ctx.reply('❌ User sudah ada di blacklist!');
            }
        } catch (error) {
            await ctx.reply('❌ Error: ' + error.message);
        }
    });

    // Delete blacklist command
    bot.command('delbl', async (ctx) => {
        const args = ctx.message.text.split(' ').slice(1);
        if (args.length === 0) {
            return ctx.reply('❌ Format: /delbl <user_id>');
        }

        const userId = args[0];

        try {
            const result = database.removeBlacklist(userId);
            if (result) {
                await ctx.replyWithMarkdown(`
✅ *User Unblacklisted!*

*User ID:* ${userId}
*Oleh:* ${ctx.from.first_name}
*Waktu:* ${moment().format('DD/MM/YYYY HH:mm:ss')}

User berhasil dihapus dari blacklist.`);
            } else {
                await ctx.reply('❌ User tidak ditemukan di blacklist!');
            }
        } catch (error) {
            await ctx.reply('❌ Error: ' + error.message);
        }
    });

    // List blacklist command
    bot.command('listbl', async (ctx) => {
        const blacklistData = loadJSON('blacklist.json');
        
        if (blacklistData.users.length === 0) {
            return ctx.reply('✅ Tidak ada user yang di-blacklist!');
        }

        let listText = '🚫 *List Blacklisted Users*\n\n';

        for (const blUser of blacklistData.users) {
            listText += `🆔 ${blUser.id}\n` +
                       `📅 Date: ${moment(blUser.date).format('DD/MM/YY HH:mm')}\n` +
                       `🔍 Reason: ${blUser.reason}\n` +
                       `By: ${blUser.added_by}\n` +
                       `━━━━━━━━━━━━━━━━━━━━\n`;
        }

        listText += `\n*Total:* ${blacklistData.users.length} users`;

        await ctx.replyWithMarkdown(listText);
    });

    // List group command
    bot.command('listgroup', async (ctx) => {
        const groupsData = loadJSON('groups.json');
        const activeGroups = groupsData.groups.filter(g => g.is_active);
        const inactiveGroups = groupsData.groups.filter(g => !g.is_active);

        let listText = `👥 *List Groups*\n\n` +
                      `✅ Aktif: ${activeGroups.length} groups\n` +
                      `❌ Non-aktif: ${inactiveGroups.length} groups\n\n` +
                      `*Group Aktif:*\n`;

        for (const group of activeGroups) {
            listText += `🏷️ ${group.name || 'No name'}\n` +
                       `🆔 ${group.id}\n` +
                       `👤 Added by: ${group.added_by}\n` +
                       `📅 ${moment(group.add_date).format('DD/MM/YY')}\n` +
                       `━━━━━━━━━━━━━━━━━━━━\n`;
        }

        if (activeGroups.length === 0) {
            listText += `Tidak ada group aktif\n`;
        }

        // Kirim bagian inactive groups terpisah jika ada
        if (inactiveGroups.length > 0) {
            await ctx.replyWithMarkdown(listText);
            
            let inactiveText = `*Group Non-aktif:*\n`;
            for (const group of inactiveGroups) {
                inactiveText += `🏷️ ${group.name || 'No name'}\n` +
                              `🆔 ${group.id}\n` +
                              `📅 ${moment(group.add_date).format('DD/MM/YY')}\n` +
                              `━━━━━━━━━━━━━━━━━━━━\n`;
            }
            
            await ctx.replyWithMarkdown(inactiveText);
        } else {
            await ctx.replyWithMarkdown(listText);
        }
    });

    // Stats command detail
    bot.command('stats', async (ctx) => {
        const stats = database.getStats();
        const usersData = loadJSON('users.json');
        const premiumData = loadJSON('premium.json');
        
        // Hitung statistik tambahan
        const today = moment().format('YYYY-MM-DD');
        const todayUsers = usersData.users.filter(u => 
            moment(u.join_date).format('YYYY-MM-DD') === today
        ).length;
        
        const activePremium = premiumData.users.filter(p => 
            moment().isBefore(moment(p.expiry))
        ).length;

        const statsText = `
📈 *Detailed Statistics*

*User Statistics:*
• 👥 Total Users: ${stats.total_users}
• 📊 New Today: ${todayUsers}
• 💎 Premium Active: ${activePremium}
• 📅 Premium Total: ${stats.premium_users}

*Group Statistics:*
• 👥 Active Groups: ${stats.active_groups}
• 📊 Total Groups: ${stats.total_groups}
• 📈 Active Rate: ${((stats.active_groups / stats.total_groups) * 100).toFixed(1)}%

*System Info:*
• ⏰ Uptime: ${require('../../lib/utils').runtime(process.uptime())}
• 🗓️ Server Date: ${moment().format('DD/MM/YYYY')}
• ⏱️ Server Time: ${moment().format('HH:mm:ss')}

*Bot Status:* 🟢 Online`;

        await ctx.replyWithMarkdown(statsText);
    });
};