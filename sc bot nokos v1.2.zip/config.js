module.exports = {
  bot_token: '7515293027:AAEheb3F23FiLS4St9VLGh588AxUFrYgacg',
  owner_ids: ['7568960443'],
  channel: '@testiandinxdurov',
  domain: 'https://www.rumahotp.com/api',
  apikey: 'otp_tfBmAYGPHzRaIuHF',
  cashify_apikey: 'cashify_a07d6a70e8ae3adea963ec80f685c06d94cb037b77d006b0cb9fd2afde35b217',
  cashify_qr_id: '1bf2ac67-9d24-4d01-864b-5f93f5f4a2a4' 
};