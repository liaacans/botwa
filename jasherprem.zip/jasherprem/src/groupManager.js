const { Markup } = require('telegraf');
const { log } = require('../lib/utils');

// Handler untuk ketika bot ditambahkan ke grup
async function handleNewGroup(ctx) {
  const groupId = ctx.chat.id;
  const groupTitle = ctx.chat.title;
  
  // Tambahkan grup ke database
  global.groups.add(groupId);
  require('../lib/utils').saveGroups(global.groups);
  
  // Inisialisasi settings untuk grup ini
  if (!global.groupSettings.has(groupId)) {
    global.groupSettings.set(groupId, {
      antispam: false,
      noevent: false,
      nolinks: false,
      noforwards: false,
      nocontacts: false,
      nohastags: false,
      nocommands: false
    });
    require('../lib/utils').saveGroupSettings(global.groupSettings);
  }
  
  // Kirim pesan selamat datang
  await ctx.replyWithPhoto(
    'https://f.top4top.io/p_3530xky9e4.jpg',
    {
      caption: `╭─❒ 「 Terima Kasih 」 
├ Terima kasih telah menambahkan
├ ${ctx.botInfo.first_name} di grup ${groupTitle}
├ Bot ini memiliki fitur obfuscation
├ dan protection untuk grup Anda
╰❒
Silahkan gunakan /help untuk melihat fitur yang tersedia!`,
      parse_mode: "Markdown",
      ...Markup.inlineKeyboard([
        [Markup.button.url('Owner Bot', 'https://t.me/ginaaforyou')],
        [Markup.button.callback('Menu Utama', 'menu')]
      ])
    }
  );
  
  log(`Bot added to group: ${groupTitle} (${groupId})`);
}

// Handler untuk ketika bot dikick dari grup
async function handleGroupLeft(ctx) {
  const groupId = ctx.chat.id;
  
  // Hapus grup dari database
  global.groups.delete(groupId);
  global.groupSettings.delete(groupId);
  
  require('../lib/utils').saveGroups(global.groups);
  require('../lib/utils').saveGroupSettings(global.groupSettings);
  
  log(`Bot removed from group: ${groupId}`);
}

// Fungsi untuk menangani message di grup
async function handleGroupMessage(ctx, next) {
  // Skip jika bukan grup
  if (ctx.chat.type === 'private') return next();
  
  const groupId = ctx.chat.id;
  const settings = global.groupSettings.get(groupId) || {};
  
  // Cek jika grup di-blacklist
  if (global.blacklistGroups.has(groupId)) {
    return; // Jangan proses pesan dari grup yang di-blacklist
  }
  
  // Terapkan pengaturan grup
  if (settings.antispam) {
    // Implementasi antispam
    // (Bisa ditambahkan logika deteksi spam)
  }
  
  if (settings.nolinks && ctx.message.entities) {
    const hasLinks = ctx.message.entities.some(entity => 
      entity.type === 'url' || entity.type === 'text_link'
    );
    
    if (hasLinks) {
      try {
        await ctx.deleteMessage();
        await ctx.reply('❌ Tautan tidak diizinkan di grup ini!');
      } catch (error) {
        log('Error deleting message with links', error);
      }
      return;
    }
  }
  
  if (settings.noforwards && ctx.message.forward_from) {
    try {
      await ctx.deleteMessage();
      await ctx.reply('❌ Pesan terusan tidak diizinkan di grup ini!');
    } catch (error) {
      log('Error deleting forwarded message', error);
    }
    return;
  }
  
  if (settings.nocommands && ctx.message.text && ctx.message.text.startsWith('/')) {
    try {
      await ctx.deleteMessage();
      await ctx.reply('❌ Perintah tidak diizinkan di grup ini!');
    } catch (error) {
      log('Error deleting command message', error);
    }
    return;
  }
  
  // Lanjut ke middleware berikutnya
  next();
}

// Command untuk mengatur pengaturan grup (hanya admin)
async function setGroupSetting(ctx, setting, value) {
  if (ctx.chat.type === 'private') {
    return ctx.reply('❌ Perintah ini hanya bisa digunakan di grup!');
  }
  
  // Cek apakah pengirim adalah admin
  try {
    const chatMember = await ctx.getChatMember(ctx.from.id);
    if (!['administrator', 'creator'].includes(chatMember.status)) {
      return ctx.reply('❌ Hanya admin yang bisa mengatur pengaturan grup!');
    }
  } catch (error) {
    return ctx.reply('❌ Gagal memverifikasi status admin!');
  }
  
  const groupId = ctx.chat.id;
  
  // Pastikan settings untuk grup ini ada
  if (!global.groupSettings.has(groupId)) {
    global.groupSettings.set(groupId, {
      antispam: false,
      noevent: false,
      nolinks: false,
      noforwards: false,
      nocontacts: false,
      nohastags: false,
      nocommands: false
    });
  }
  
  const settings = global.groupSettings.get(groupId);
  settings[setting] = value;
  global.groupSettings.set(groupId, settings);
  
  require('../lib/utils').saveGroupSettings(global.groupSettings);
  
  const status = value ? 'diaktifkan' : 'dinonaktifkan';
  await ctx.reply(`✅ Pengaturan ${setting} telah ${status}!`);
}

module.exports = {
  handleNewGroup,
  handleGroupLeft,
  handleGroupMessage,
  setGroupSetting
};