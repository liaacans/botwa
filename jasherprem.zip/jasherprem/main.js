const { Telegraf, session } = require('telegraf');
const { connectDB, User, Group } = require('./lib/database');
const {
  handleStart,
  handleHelp,
  handleCredit,
  handleShare,
  handleShareVip,
  handleAddPrem,
  handleDelPrem,
  handleListPrem,
  handleBroadcast
} = require('./src/commands');
const {
  handleCallbackQuery,
  handleNewChatMembers
} = require('./src/handlers');

const { BOT_TOKEN } = require('./config');

// Connect to database
connectDB();

// Initialize bot
const bot = new Telegraf(BOT_TOKEN);

// Session middleware
bot.use(session());

// Event handlers
bot.start(handleStart);
bot.help(handleHelp);
bot.command('credit', handleCredit);
bot.command('share', handleShare);
bot.command('sharevip', handleShareVip);
bot.command('addprem', handleAddPrem);
bot.command('delprem', handleDelPrem);
bot.command('listprem', handleListPrem);
bot.command('broadcast', handleBroadcast);

// Callback query handler
bot.on('callback_query', handleCallbackQuery);

// Handle when bot is added to a group
bot.on('new_chat_members', handleNewChatMembers);

// Error handling
bot.catch((err, ctx) => {
  console.error(`Error for ${ctx.updateType}:`, err);
  ctx.reply('Terjadi kesalahan, silakan coba lagi.');
});

// Start bot
bot.launch().then(() => {
  console.log('Bot Jasher started successfully');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));