global.BOT_TOKEN = process.env.BOT_TOKEN || 'YOUR_BOT_TOKEN_HERE';
global.MONGO_URL = process.env.MONGO_URL || 'mongodb://localhost:27017/jasherbot';

module.exports = {
  BOT_TOKEN: global.BOT_TOKEN,
  MONGO_URL: global.MONGO_URL,
  CREATOR_ID: process.env.CREATOR_ID || '123456789', // Ganti dengan ID Telegram Anda
  CHANNEL_USERNAME: process.env.CHANNEL_USERNAME || '@JasherGroup',
  MIN_GROUPS: 3,
  SHARE_COST: 2,
  SHAREVIP_COST: 5
};