const { Telegraf } = require('telegraf');
const { BOT_TOKEN } = require('./config');
const { addUser } = require('./lib/database');
const { handleStart, handleCallbackQuery, handleObfCommand } = require('./src/commands');
const { 
  handleNewChatMembers, 
  handleLeftChatMember, 
  handleSpamDetection,
  handleContentFilter,
  handleGroupCommands, 
  handleOwnerCommands, 
  handleShare 
} = require('./src/handlers');

const bot = new Telegraf(BOT_TOKEN);

// Event handler untuk new chat members
bot.on('new_chat_members', handleNewChatMembers);

// Event handler untuk left chat member
bot.on('left_chat_member', handleLeftChatMember);

// Handler untuk semua pesan di group (deteksi spam dan filter konten)
bot.on('message', (ctx, next) => {
  // Hanya proses di group
  if (ctx.chat.type === 'group' || ctx.chat.type === 'supergroup') {
    // Deteksi spam
    const isSpam = handleSpamDetection(ctx);
    if (isSpam) return;
    
    // Filter konten terlarang
    const isBlocked = handleContentFilter(ctx);
    if (isBlocked) return;
  }
  
  return next();
});

// Command handler untuk start
bot.start(handleStart);

// Callback query handler
bot.on('callback_query', handleCallbackQuery);

// Command handler untuk obfuscation
bot.command(['enc3', 'enc4', 'japan', 'zenc', 'nebula', 'enc5', 'var', 'quantum', 'enc'], async (ctx) => {
  const command = ctx.message.text.split(' ')[0].substring(1);
  await handleObfCommand(ctx, command);
});

// Command handler untuk group commands
bot.command(['antispam', 'noevent', 'nolinks', 'noforwards', 'nocontacts', 'nohashtags', 'nocommands', 'settings'], (ctx) => {
  const command = ctx.message.text.substring(1);
  handleGroupCommands(ctx, command);
});

// Command handler untuk owner commands
bot.command(['addprem', 'delprem', 'listprem', 'bc', 'addbl', 'delbl', 'listbl', 'hapusgb', 'listgb', 'tourl'], (ctx) => {
  const command = ctx.message.text.split(' ')[0].substring(1);
  handleOwnerCommands(ctx, command);
});

// Command handler untuk share
bot.command('sharefree', (ctx) => {
  handleShare(ctx, false);
});

bot.command('sharevip', (ctx) => {
  handleShare(ctx, true);
});

// Error handling
bot.catch((err, ctx) => {
  console.error(`Error for ${ctx.updateType}:`, err);
  ctx.reply('Terjadi kesalahan! Silahkan coba lagi.');
});

// Jalankan bot
bot.launch()
  .then(() => {
    console.log('Bot Jasher Premium berhasil dijalankan!');
  })
  .catch((error) => {
    console.error('Gagal menjalankan bot:', error);
  });

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));

// Bersihkan spam detection cache setiap 1 menit
setInterval(() => {
  const now = Date.now();
  for (const [key, data] of userMessageCounts.entries()) {
    if (now - data.lastReset > spamDetectionTime * 2) {
      userMessageCounts.delete(key);
    }
  }
}, 60000);

// Spam detection variables
const userMessageCounts = new Map();
const spamDetectionTime = 10000; // 10 seconds
const maxMessagesPerInterval = 5;