const { Telegraf, Markup } = require('telegraf');
const { isOwner, log } = require('../../lib/functions');
const db = require('../../lib/database');

module.exports = (bot, users, groups, premium, blacklist) => {
    
    // Auto add group when bot is added
    bot.on('message', async (ctx) => {
        if (ctx.message.new_chat_members) {
            const newMembers = ctx.message.new_chat_members;
            const botId = ctx.botInfo.id;
            
            for (const member of newMembers) {
                if (member.id === botId) {
                    // Bot added to group
                    const groupId = ctx.chat.id.toString();
                    const groupTitle = ctx.chat.title || 'Unknown Group';
                    
                    if (!groups.has(groupId)) {
                        groups.set(groupId, {
                            id: groupId,
                            title: groupTitle,
                            members: [],
                            settings: {
                                antispam: true,
                                noevent: false,
                                nolinks: false,
                                noforwards: false,
                                nocontacts: false,
                                nohastags: false,
                                nocommands: false
                            },
                            active: true,
                            added: Date.now()
                        });
                        
                        await db.saveGroups(groups);
                        
                        log(`Bot added to group: ${groupTitle} (${groupId})`);
                        
                        await ctx.replyWithMarkdown(`
╭━━━「 🤖 BOT DITAMBAHKAN 」━━━⬣
│ Terima kasih telah menambahkan Jasher Bot!
│ 
│ Gunakan /menu untuk melihat fitur
│ Gunakan /help untuk bantuan
╰━━━━━━━━━━━━━━━━⬣`);
                    }
                    break;
                }
            }
        }
        
        // Update group members
        if (ctx.chat.type === 'group' || ctx.chat.type === 'supergroup') {
            const groupId = ctx.chat.id.toString();
            const userId = ctx.from.id;
            
            if (groups.has(groupId)) {
                const group = groups.get(groupId);
                if (!group.members.includes(userId)) {
                    group.members.push(userId);
                    group.active = true;
                    await db.saveGroups(groups);
                }
            }
        }
    });

    // Handle bot removed from group
    bot.on('left_chat_member', async (ctx) => {
        const leftMember = ctx.message.left_chat_member;
        const botId = ctx.botInfo.id;
        
        if (leftMember.id === botId) {
            const groupId = ctx.chat.id.toString();
            
            if (groups.has(groupId)) {
                const group = groups.get(groupId);
                group.active = false;
                await db.saveGroups(groups);
                
                log(`Bot removed from group: ${group.title} (${groupId})`);
            }
        }
    });

    // Group settings commands - hanya admin group
    bot.command('antispam', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.replyWithMarkdown('❌ *Error:* Command ini hanya untuk group!');
        }

        // Cek apakah user adalah admin
        try {
            const chatMember = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(chatMember.status)) {
                return ctx.replyWithMarkdown('❌ *Error:* Hanya admin group yang bisa menggunakan command ini!');
            }
        } catch (error) {
            return ctx.replyWithMarkdown('❌ *Error:* Gagal memverifikasi status admin!');
        }

        const groupId = ctx.chat.id.toString();
        if (!groups.has(groupId)) {
            return ctx.replyWithMarkdown('❌ *Error:* Group belum terdaftar!');
        }

        const group = groups.get(groupId);
        group.settings.antispam = !group.settings.antispam;
        await db.saveGroups(groups);

        await ctx.replyWithMarkdown(`
╭━━━「 ⚙️ ANTISPAM SETTINGS 」━━━⬣
│ Status : ${group.settings.antispam ? '✅ AKTIF' : '❌ NONAKTIF'}
│ 
│ Fitur anti spam sekarang ${group.settings.antispam ? 'diaktifkan' : 'dinonaktifkan'}
╰━━━━━━━━━━━━━━━━⬣`);
    });

    bot.command('noevent', async (ctx) => {
        if (ctx.chat.type === 'private') return;

        try {
            const chatMember = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(chatMember.status)) return;
        } catch (error) {
            return;
        }

        const groupId = ctx.chat.id.toString();
        if (!groups.has(groupId)) return;

        const group = groups.get(groupId);
        group.settings.noevent = !group.settings.noevent;
        await db.saveGroups(groups);

        await ctx.replyWithMarkdown(`✅ *No Event* ${group.settings.noevent ? 'diaktifkan' : 'dinonaktifkan'}!`);
    });

    bot.command('nolinks', async (ctx) => {
        if (ctx.chat.type === 'private') return;

        try {
            const chatMember = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(chatMember.status)) return;
        } catch (error) {
            return;
        }

        const groupId = ctx.chat.id.toString();
        if (!groups.has(groupId)) return;

        const group = groups.get(groupId);
        group.settings.nolinks = !group.settings.nolinks;
        await db.saveGroups(groups);

        await ctx.replyWithMarkdown(`✅ *No Links* ${group.settings.nolinks ? 'diaktifkan' : 'dinonaktifkan'}!`);
    });

    bot.command('noforwards', async (ctx) => {
        if (ctx.chat.type === 'private') return;

        try {
            const chatMember = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(chatMember.status)) return;
        } catch (error) {
            return;
        }

        const groupId = ctx.chat.id.toString();
        if (!groups.has(groupId)) return;

        const group = groups.get(groupId);
        group.settings.noforwards = !group.settings.noforwards;
        await db.saveGroups(groups);

        await ctx.replyWithMarkdown(`✅ *No Forwards* ${group.settings.noforwards ? 'diaktifkan' : 'dinonaktifkan'}!`);
    });

    bot.command('nocontacts', async (ctx) => {
        if (ctx.chat.type === 'private') return;

        try {
            const chatMember = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(chatMember.status)) return;
        } catch (error) {
            return;
        }

        const groupId = ctx.chat.id.toString();
        if (!groups.has(groupId)) return;

        const group = groups.get(groupId);
        group.settings.nocontacts = !group.settings.nocontacts;
        await db.saveGroups(groups);

        await ctx.replyWithMarkdown(`✅ *No Contacts* ${group.settings.nocontacts ? 'diaktifkan' : 'dinonaktifkan'}!`);
    });

    bot.command('nohastags', async (ctx) => {
        if (ctx.chat.type === 'private') return;

        try {
            const chatMember = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(chatMember.status)) return;
        } catch (error) {
            return;
        }

        const groupId = ctx.chat.id.toString();
        if (!groups.has(groupId)) return;

        const group = groups.get(groupId);
        group.settings.nohastags = !group.settings.nohastags;
        await db.saveGroups(groups);

        await ctx.replyWithMarkdown(`✅ *No Hashtags* ${group.settings.nohastags ? 'diaktifkan' : 'dinonaktifkan'}!`);
    });

    bot.command('nocommands', async (ctx) => {
        if (ctx.chat.type === 'private') return;

        try {
            const chatMember = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(chatMember.status)) return;
        } catch (error) {
            return;
        }

        const groupId = ctx.chat.id.toString();
        if (!groups.has(groupId)) return;

        const group = groups.get(groupId);
        group.settings.nocommands = !group.settings.nocommands;
        await db.saveGroups(groups);

        await ctx.replyWithMarkdown(`✅ *No Commands* ${group.settings.nocommands ? 'diaktifkan' : 'dinonaktifkan'}!`);
    });

    // Command untuk melihat settings group
    bot.command('settings', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.replyWithMarkdown('❌ *Error:* Command ini hanya untuk group!');
        }

        try {
            const chatMember = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(chatMember.status)) {
                return ctx.replyWithMarkdown('❌ *Error:* Hanya admin group yang bisa menggunakan command ini!');
            }
        } catch (error) {
            return ctx.replyWithMarkdown('❌ *Error:* Gagal memverifikasi status admin!');
        }

        const groupId = ctx.chat.id.toString();
        if (!groups.has(groupId)) {
            return ctx.replyWithMarkdown('❌ *Error:* Group belum terdaftar!');
        }

        const group = groups.get(groupId);
        
        const settingsText = `
╭─❒ 「 ⚙️ GROUP SETTINGS 」 
├ Anti Spam : ${group.settings.antispam ? '✅' : '❌'}
├ No Event : ${group.settings.noevent ? '✅' : '❌'}
├ No Links : ${group.settings.nolinks ? '✅' : '❌'}
├ No Forwards : ${group.settings.noforwards ? '✅' : '❌'}
├ No Contacts : ${group.settings.nocontacts ? '✅' : '❌'}
├ No Hashtags : ${group.settings.nohastags ? '✅' : '❌'}
├ No Commands : ${group.settings.nocommands ? '✅' : '❌'}
╰❒
Gunakan command masing-masing untuk mengubah settings.`;

        await ctx.replyWithMarkdown(settingsText);
    });

    // Message handler untuk filter konten berdasarkan settings
    bot.on('message', async (ctx) => {
        if (ctx.chat.type === 'private') return;
        
        const groupId = ctx.chat.id.toString();
        if (!groups.has(groupId)) return;
        
        const group = groups.get(groupId);
        if (!group.settings.antispam) return;

        // Cek apakah user adalah admin
        let isAdmin = false;
        try {
            const chatMember = await ctx.getChatMember(ctx.from.id);
            isAdmin = ['administrator', 'creator'].includes(chatMember.status);
        } catch (error) {
            return;
        }

        if (isAdmin) return; // Admin bebas

        // Filter berdasarkan settings
        if (group.settings.nolinks && ctx.message.entities) {
            const hasLinks = ctx.message.entities.some(entity => 
                entity.type === 'url' || entity.type === 'text_link'
            );
            if (hasLinks) {
                await ctx.deleteMessage();
                await ctx.replyWithMarkdown(`❌ *Link tidak diizinkan di group ini!*`);
                return;
            }
        }

        if (group.settings.noforwards && ctx.message.forward_from) {
            await ctx.deleteMessage();
            await ctx.replyWithMarkdown(`❌ *Forward tidak diizinkan di group ini!*`);
            return;
        }

        if (group.settings.nocontacts && ctx.message.contact) {
            await ctx.deleteMessage();
            await ctx.replyWithMarkdown(`❌ *Kontak tidak diizinkan di group ini!*`);
            return;
        }

        if (group.settings.nohastags && ctx.message.text && ctx.message.text.includes('#')) {
            await ctx.deleteMessage();
            await ctx.replyWithMarkdown(`❌ *Hashtag tidak diizinkan di group ini!*`);
            return;
        }

        if (group.settings.nocommands && ctx.message.text && ctx.message.text.startsWith('/')) {
            await ctx.deleteMessage();
            await ctx.replyWithMarkdown(`❌ *Commands tidak diizinkan di group ini!*`);
            return;
        }

        if (group.settings.noevent && ctx.message.new_chat_members) {
            await ctx.deleteMessage();
            return;
        }
    });

    // Command untuk menambahkan bot ke group
    bot.command('addgroup', async (ctx) => {
        if (ctx.chat.type !== 'private') {
            return ctx.replyWithMarkdown('❌ *Error:* Command ini hanya untuk private chat!');
        }

        await ctx.replyWithMarkdown(`
╭━━━「 🏠 TAMBAH KE GROUP 」━━━⬣
│ Untuk menambahkan bot ke group:
│ 
│ 1. Buka group yang ingin ditambahkan
│ 2. Klik tombol add members
│ 3. Cari @${ctx.botInfo.username}
│ 4. Tambahkan bot ke group
│ 
│ Setelah ditambahkan, bot akan otomatis
│ terdaftar dan bisa digunakan!
╰━━━━━━━━━━━━━━━━⬣`);
    });
};