const { isPremium, isOwner, log } = require('../lib/utils');

// Handle new chat members
function handleNewChatMembers(bot) {
    bot.on('new_chat_members', async (ctx) => {
        const newMembers = ctx.message.new_chat_members;
        
        for (const member of newMembers) {
            if (member.is_bot && member.username === ctx.botInfo.username) {
                // Bot added to a group
                const groupId = ctx.chat.id.toString();
                
                if (blacklistGroups.has(groupId)) {
                    await ctx.reply('❌ Bot tidak dapat digunakan di grup ini (terblacklist).');
                    await ctx.leaveChat();
                    return;
                }
                
                groups.add(groupId);
                saveGroups(groups);
                
                await ctx.reply(`
🤖 Terima kasih telah menambahkan Jasher Bot ke grup ini!

⚙️ *Fitur yang tersedia:*
- 🔒 Obfuscation JavaScript
- 👥 Manajemen grup
- 📢 Sistem broadcast

🔧 *Setup Admin:*
Gunakan /settings untuk melihat pengaturan grup
Gunakan command admin untuk mengatur grup

📖 *Bantuan:*
Gunakan /help untuk bantuan penggunaan
Gunakan /menu untuk menu utama

👨‍💻 *Developer:* @ginaaforyou
                `, { parse_mode: 'Markdown' });
            }
        }
    });
}

// Handle left chat member
function handleLeftChatMember(bot) {
    bot.on('left_chat_member', async (ctx) => {
        const leftMember = ctx.message.left_chat_member;
        
        if (leftMember.is_bot && leftMember.username === ctx.botInfo.username) {
            // Bot removed from a group
            const groupId = ctx.chat.id.toString();
            
            if (groups.has(groupId)) {
                groups.delete(groupId);
                saveGroups(groups);
            }
            
            if (groupSettings.has(groupId)) {
                groupSettings.delete(groupId);
                saveGroupSettings(groupSettings);
            }
            
            log(`Bot removed from group: ${groupId}`);
        }
    });
}

// Handle message for group settings
function handleGroupMessages(bot) {
    bot.on('message', async (ctx) => {
        if (ctx.chat.type === 'private') return;
        
        const groupId = ctx.chat.id.toString();
        const settings = groupSettings.get(groupId) || {};
        
        // Check if group is blacklisted
        if (blacklistGroups.has(groupId)) {
            if (ctx.message.text && ctx.message.text.startsWith('/')) {
                await ctx.reply('❌ Bot tidak dapat digunakan di grup ini (terblacklist).');
            }
            return;
        }
        
        // Check no commands setting
        if (settings.nocommands && ctx.message.text && ctx.message.text.startsWith('/')) {
            try {
                await ctx.deleteMessage();
                await ctx.reply('❌ Penggunaan command tidak diizinkan di grup ini.');
            } catch (error) {
                console.log('Tidak dapat menghapus pesan command:', error.message);
            }
            return;
        }
        
        // Check anti-spam setting
        if (settings.antispam) {
            // Simple anti-spam logic - can be enhanced
            // This is a basic implementation
            const message = ctx.message.text || '';
            if (message.length > 500) {
                try {
                    await ctx.deleteMessage();
                    await ctx.reply('❌ Pesan terlalu panjang (anti-spam).');
                } catch (error) {
                    console.log('Tidak dapat menghapus pesan spam:', error.message);
                }
                return;
            }
        }
        
        // Check no links setting
        if (settings.nolinks) {
            const message = ctx.message.text || '';
            const urlRegex = /https?:\/\/[^\s]+/g;
            if (urlRegex.test(message)) {
                try {
                    await ctx.deleteMessage();
                    await ctx.reply('❌ Penggunaan link tidak diizinkan di grup ini.');
                } catch (error) {
                    console.log('Tidak dapat menghapus pesan dengan link:', error.message);
                }
                return;
            }
        }
        
        // Check no forwards setting
        if (settings.noforwards && ctx.message.forward_from) {
            try {
                await ctx.deleteMessage();
                await ctx.reply('❌ Forward pesan tidak diizinkan di grup ini.');
            } catch (error) {
                console.log('Tidak dapat menghapus pesan forward:', error.message);
            }
            return;
        }
        
        // Check no contacts setting
        if (settings.nocontacts && ctx.message.contact) {
            try {
                await ctx.deleteMessage();
                await ctx.reply('❌ Berbagi kontak tidak diizinkan di grup ini.');
            } catch (error) {
                console.log('Tidak dapat menghapus pesan kontak:', error.message);
            }
            return;
        }
        
        // Check no hashtags setting
        if (settings.nohastags) {
            const message = ctx.message.text || '';
            if (message.includes('#')) {
                try {
                    await ctx.deleteMessage();
                    await ctx.reply('❌ Penggunaan hashtag tidak diizinkan di grup ini.');
                } catch (error) {
                    console.log('Tidak dapat menghapus pesan dengan hashtag:', error.message);
                }
                return;
            }
        }
        
        // Check no event setting
        if (settings.noevent && ctx.message.new_chat_members) {
            try {
                await ctx.deleteMessage();
            } catch (error) {
                console.log('Tidak dapat menghapus pesan event:', error.message);
            }
            return;
        }
    });
}

// Handle sharing commands
function handleSharingCommands(bot) {
    // sharefree command - Free sharing
    bot.command('sharefree', async (ctx) => {
        if (ctx.chat.type !== 'private') {
            await ctx.reply('❌ Command ini hanya dapat digunakan di private chat!');
            return;
        }
        
        if (!ctx.message.reply_to_message) {
            await ctx.reply('❌ Balas pesan yang ingin di-share dengan command ini!');
            return;
        }
        
        // Add user to database
        users.add(ctx.from.id);
        saveUsers(users);
        
        // Check if user is premium or has free trial
        const isUserPremium = isPremium(ctx.from.id);
        const hasFreeTrial = users.has(ctx.from.id); // Simple check, can be enhanced
        
        if (!isUserPremium && !hasFreeTrial) {
            // Give free trial
            const expiryDate = new Date();
            expiryDate.setDate(expiryDate.getDate() + FREE_TRIAL_DAYS);
            
            premiumUsers.set(ctx.from.id, { expiry: expiryDate.toISOString() });
            savePremiumUsers(premiumUsers);
            
            await ctx.reply(`🎉 Anda mendapatkan trial premium ${FREE_TRIAL_DAYS} hari! Berlaku hingga: ${expiryDate.toLocaleDateString()}`);
        }
        
        // Share the message to groups
        const groupsArray = Array.from(groups);
        let successCount = 0;
        let failCount = 0;
        
        const progressMessage = await ctx.reply(`📢 Mengirim pesan ke ${groupsArray.length} grup...\n\n✅ Berhasil: ${successCount}\n❌ Gagal: ${failCount}`);
        
        for (const groupId of groupsArray) {
            if (blacklistGroups.has(groupId)) {
                failCount++;
                continue;
            }
            
            try {
                // Forward the message or send a copy
                if (ctx.message.reply_to_message.text) {
                    await ctx.telegram.sendMessage(groupId, `📢 *Share from ${ctx.from.first_name}:*\n\n${ctx.message.reply_to_message.text}`, { parse_mode: 'Markdown' });
                } else if (ctx.message.reply_to_message.photo) {
                    await ctx.telegram.sendPhoto(groupId, ctx.message.reply_to_message.photo[0].file_id, {
                        caption: ctx.message.reply_to_message.caption ? `📢 Share from ${ctx.from.first_name}:\n\n${ctx.message.reply_to_message.caption}` : `📢 Share from ${ctx.from.first_name}`
                    });
                } else if (ctx.message.reply_to_message.document) {
                    await ctx.telegram.sendDocument(groupId, ctx.message.reply_to_message.document.file_id, {
                        caption: ctx.message.reply_to_message.caption ? `📢 Share from ${ctx.from.first_name}:\n\n${ctx.message.reply_to_message.caption}` : `📢 Share from ${ctx.from.first_name}`
                    });
                } else {
                    // Unsupported message type
                    failCount++;
                    continue;
                }
                
                successCount++;
                
                // Update progress every 5 messages
                if (successCount % 5 === 0) {
                    await ctx.telegram.editMessageText(
                        progressMessage.chat.id,
                        progressMessage.message_id,
                        null,
                        `📢 Mengirim pesan ke ${groupsArray.length} grup...\n\n✅ Berhasil: ${successCount}\n❌ Gagal: ${failCount}`
                    );
                }
                
                // Delay to avoid rate limiting
                await new Promise(resolve => setTimeout(resolve, 500));
            } catch (error) {
                failCount++;
                console.log(`Gagal mengirim pesan ke grup ${groupId}: ${error.message}`);
            }
        }
        
        await ctx.telegram.editMessageText(
            progressMessage.chat.id,
            progressMessage.message_id,
            null,
            `✅ Share selesai!\n\n📊 Statistik:\n✅ Berhasil: ${successCount}\n❌ Gagal: ${failCount}`
        );
    });
    
    // sharevip command - VIP sharing (faster)
    bot.command('sharevip', async (ctx) => {
        if (ctx.chat.type !== 'private') {
            await ctx.reply('❌ Command ini hanya dapat digunakan di private chat!');
            return;
        }
        
        if (!isPremium(ctx.from.id)) {
            await ctx.reply('❌ Hanya pengguna premium yang dapat menggunakan command ini!');
            return;
        }
        
        if (!ctx.message.reply_to_message) {
            await ctx.reply('❌ Balas pesan yang ingin di-share dengan command ini!');
            return;
        }
        
        // Share the message to groups (faster for VIP)
        const groupsArray = Array.from(groups);
        let successCount = 0;
        let failCount = 0;
        
        const progressMessage = await ctx.reply(`🚀 Mengirim pesan VIP ke ${groupsArray.length} grup...\n\n✅ Berhasil: ${successCount}\n❌ Gagal: ${failCount}`);
        
        // Use Promise.all for faster sending
        const sendPromises = groupsArray.map(async (groupId) => {
            if (blacklistGroups.has(groupId)) {
                failCount++;
                return;
            }
            
            try {
                // Forward the message or send a copy
                if (ctx.message.reply_to_message.text) {
                    await ctx.telegram.sendMessage(groupId, `🚀 *VIP Share from ${ctx.from.first_name}:*\n\n${ctx.message.reply_to_message.text}`, { parse_mode: 'Markdown' });
                } else if (ctx.message.reply_to_message.photo) {
                    await ctx.telegram.sendPhoto(groupId, ctx.message.reply_to_message.photo[0].file_id, {
                        caption: ctx.message.reply_to_message.caption ? `🚀 VIP Share from ${ctx.from.first_name}:\n\n${ctx.message.reply_to_message.caption}` : `🚀 VIP Share from ${ctx.from.first_name}`
                    });
                } else if (ctx.message.reply_to_message.document) {
                    await ctx.telegram.sendDocument(groupId, ctx.message.reply_to_message.document.file_id, {
                        caption: ctx.message.reply_to_message.caption ? `🚀 VIP Share from ${ctx.from.first_name}:\n\n${ctx.message.reply_to_message.caption}` : `🚀 VIP Share from ${ctx.from.first_name}`
                    });
                } else {
                    // Unsupported message type
                    failCount++;
                    return;
                }
                
                successCount++;
                
                // Update progress every 10 messages
                if (successCount % 10 === 0) {
                    await ctx.telegram.editMessageText(
                        progressMessage.chat.id,
                        progressMessage.message_id,
                        null,
                        `🚀 Mengirim pesan VIP ke ${groupsArray.length} grup...\n\n✅ Berhasil: ${successCount}\n❌ Gagal: ${failCount}`
                    );
                }
            } catch (error) {
                failCount++;
                console.log(`Gagal mengirim pesan VIP ke grup ${groupId}: ${error.message}`);
            }
        });
        
        // Wait for all promises to complete
        await Promise.all(sendPromises);
        
        await ctx.telegram.editMessageText(
            progressMessage.chat.id,
            progressMessage.message_id,
            null,
            `✅ VIP Share selesai!\n\n📊 Statistik:\n✅ Berhasil: ${successCount}\n❌ Gagal: ${failCount}`
        );
    });
}

// Handle tourl command - Upload to uguu.se
bot.command('tourl', async (ctx) => {
    if (!ctx.message.reply_to_message) {
        return ctx.reply('❌ Balas foto atau document dengan command ini!');
    }
    
    let fileBuffer;
    let filename;
    
    if (ctx.message.reply_to_message.photo) {
        // Get the highest quality photo
        const photo = ctx.message.reply_to_message.photo[ctx.message.reply_to_message.photo.length - 1];
        const fileLink = await ctx.telegram.getFileLink(photo.file_id);
        const response = await fetch(fileLink);
        fileBuffer = await response.buffer();
        filename = `photo_${Date.now()}.jpg`;
    } else if (ctx.message.reply_to_message.document) {
        const document = ctx.message.reply_to_message.document;
        const fileLink = await ctx.telegram.getFileLink(document.file_id);
        const response = await fetch(fileLink);
        fileBuffer = await response.buffer();
        filename = document.file_name || `file_${Date.now()}`;
    } else {
        return ctx.reply('❌ Hanya foto atau document yang didukung!');
    }
    
    try {
        const progressMessage = await ctx.reply('📤 Mengupload file ke uguu.se...');
        
        const url = await uploadToUguu(fileBuffer, filename);
        
        await ctx.telegram.editMessageText(
            progressMessage.chat.id,
            progressMessage.message_id,
            null,
            `✅ File berhasil diupload!\n\n🔗 URL: ${url}`
        );
    } catch (error) {
        log('Error uploading to uguu.se', error);
        ctx.reply('❌ Gagal mengupload file. Silakan coba lagi.');
    }
});

module.exports = {
    handleNewChatMembers,
    handleLeftChatMember,
    handleGroupMessages,
    handleSharingCommands
};