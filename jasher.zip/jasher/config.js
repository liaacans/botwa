global.BOT_TOKEN = process.env.BOT_TOKEN || '8301759166:AAEbcN0aEmdGDwGORvzNbMQXiuHkKWhoVT8';
global.ADMIN_ID = process.env.ADMIN_ID || '8373026763';

module.exports = {
    BOT_TOKEN: global.BOT_TOKEN,
    ADMIN_ID: global.ADMIN_ID
};