const { Telegraf, session } = require('telegraf');
require('./config');
require('./lib/database');

const {
  handleStart,
  handleHelp,
  handleEnclocked,
  handleQuantum,
  handleSiu,
  handleCustom,
  handleNebula,
  handleNova,
  handleStrong,
  handleArab,
  handleJapanxArab,
  handleJapan,
  handleCallbackQuery,
  handleNewChatMembers,
  handleLeftChatMember
} = require('./src/commands');

const {
  handleAddPrem,
  handleDelPrem,
  handleListPrem,
  handleAddBl,
  handleDelBl,
  handleListBl,
  handleAutoJasher,
  handleStopAutoJasher,
  handleListGroup,
  handleToUrl,
  handleBroadcast,
  handleTextMessage
} = require('./src/handlers');

const bot = new Telegraf(global.BOT_TOKEN);

// Middleware
bot.use(session());

// Start command
bot.start(handleStart);

// Help command
bot.help(handleHelp);

// Obfuscation commands
bot.command('enclocked', handleEnclocked);
bot.command('quantum', handleQuantum);
bot.command('siu', handleSiu);
bot.command('custom', handleCustom);
bot.command('nebula', handleNebula);
bot.command('nova', handleNova);
bot.command('strong', handleStrong);
bot.command('arab', handleArab);
bot.command('japanxarab', handleJapanxArab);
bot.command('japan', handleJapan);

// Owner commands
bot.command('addprem', handleAddPrem);
bot.command('delprem', handleDelPrem);
bot.command('listprem', handleListPrem);
bot.command('addbl', handleAddBl);
bot.command('delbl', handleDelBl);
bot.command('listbl', handleListBl);
bot.command('autojasher', handleAutoJasher);
bot.command('stopautojasher', handleStopAutoJasher);
bot.command('listgroup', handleListGroup);
bot.command('tourl', handleToUrl);
bot.command('bc', handleBroadcast);

// Events
bot.on('callback_query', handleCallbackQuery);
bot.on('new_chat_members', handleNewChatMembers);
bot.on('left_chat_member', handleLeftChatMember);
bot.on('text', handleTextMessage);

// Error handling
bot.catch((err, ctx) => {
  console.error(`Error for ${ctx.updateType}:`, err);
  ctx.reply('Terjadi kesalahan. Silakan coba lagi nanti.');
});

// Start bot
bot.launch().then(() => {
  console.log('Bot Jasher Premium started!');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));