/*
Base Ori Rahman x Ginaa imupp

Sosmed media :
Ig : private
Tele : @tiaaxl
Wa : Privet
Yt : A. Aulia Rahman Official (@auliarhmanproduction)


Thanks too::
Allah swt
Nabi Muhammad
Aulia Rahman
Ginaa Imupp

Create Bot Tokennya Di
@BotFather
Cek id tele nya Di
@CekID_tele_bot

Note : don't remove copyright of this script!
*/

const { Telegraf } = require('telegraf');
const { setupCommands } = require('./src/commands');
const { setupHandlers } = require('./src/handlers');
const { BOT_TOKEN } = require('./config');

// Initialize bot
const bot = new Telegraf(BOT_TOKEN);

// Setup commands and handlers
setupCommands(bot);
setupHandlers(bot);

// Start bot
bot.launch().then(() => {
    console.log('🤖 Jasher Bot is running...');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));