const { User, Group } = require('../lib/database');

// Handler untuk callback queries (button presses)
async function handleCallbackQuery(ctx) {
    const data = ctx.callbackQuery.data;
    
    try {
        switch (data) {
            case 'jasher_menu':
                await ctx.editMessageCaption(
                    `*🎯 Jasher Menu*\n\nPilih opsi di bawah ini:`,
                    {
                        parse_mode: 'Markdown',
                        reply_markup: {
                            inline_keyboard: [
                                [{
                                    text: '💎 Credit',
                                    callback_data: 'show_credit'
                                }],
                                [{
                                    text: '📤 Share',
                                    callback_data: 'share_info'
                                }],
                                [{
                                    text: '🔙 Kembali',
                                    callback_data: 'main_menu'
                                }]
                            ]
                        }
                    }
                );
                break;
                
            case 'owner_menu':
                // Cek apakah user adalah owner
                if (ctx.from.id.toString() !== process.env.OWNER_ID) {
                    await ctx.answerCbQuery('Menu ini hanya untuk owner!');
                    return;
                }
                
                await ctx.editMessageCaption(
                    `*👤 Owner Menu*\n\nPilih opsi di bawah ini:`,
                    {
                        parse_mode: 'Markdown',
                        reply_markup: {
                            inline_keyboard: [
                                [{
                                    text: '➕ Add Premium',
                                    callback_data: 'add_premium'
                                }],
                                [{
                                    text: '➖ Remove Premium',
                                    callback_data: 'remove_premium'
                                }],
                                [{
                                    text: '📋 List Premium',
                                    callback_data: 'list_premium'
                                }],
                                [{
                                    text: '📢 Broadcast',
                                    callback_data: 'broadcast_info'
                                }],
                                [{
                                    text: '🔙 Kembali',
                                    callback_data: 'main_menu'
                                }]
                            ]
                        }
                    }
                );
                break;
                
            case 'add_group':
                await ctx.reply(
                    'Untuk menambahkan grup, undang bot @JasherBot ke grup Anda, lalu gunakan perintah /addgroup di grup tersebut.'
                );
                break;
                
            case 'main_menu':
                const { caption, buttons } = require('./commands').getMainMenu(ctx, {});
                await ctx.editMessageCaption(caption, {
                    parse_mode: 'Markdown',
                    reply_markup: buttons.reply_markup
                });
                break;
                
            case 'show_credit':
                const user = await User.findOne({ userId: ctx.from.id });
                await ctx.answerCbQuery(`Kredit Anda: ${user.credit}`);
                break;
                
            case 'share_info':
                await ctx.answerCbQuery('Gunakan /share di chat private dengan membalas pesan yang ingin dibagikan.');
                break;
                
            case 'broadcast_info':
                await ctx.answerCbQuery('Gunakan /broadcast dengan membalas pesan yang ingin di-broadcast ke semua user.');
                break;
                
            default:
                await ctx.answerCbQuery('Opsi tidak dikenali');
        }
    } catch (error) {
        console.error('Error handling callback query:', error);
        await ctx.answerCbQuery('Terjadi kesalahan');
    }
}

// Handler ketika bot ditambahkan ke grup
async function handleNewChatMembers(ctx) {
    try {
        // Cek jika bot yang ditambahkan ke grup
        if (ctx.message.new_chat_members.some(member => member.is_bot && member.id === ctx.botInfo.id)) {
            const chatId = ctx.chat.id;
            const chatTitle = ctx.chat.title;
            const chatUsername = ctx.chat.username;
            const addedBy = ctx.from.id;
            
            // Cek apakah grup sudah ada di database
            const existingGroup = await Group.findOne({ groupId: chatId });
            if (existingGroup) {
                return;
            }
            
            // Simpan grup ke database
            const newGroup = new Group({
                groupId: chatId,
                groupName: chatTitle,
                groupUsername: chatUsername,
                addedBy: addedBy
            });
            
            await newGroup.save();
            
            // Tambahkan kredit ke user yang menambahkan bot
            const user = await User.findOne({ userId: addedBy });
            if (user) {
                user.addedGroups.push(chatId);
                
                // Beri 10 kredit jika sudah menambahkan 3 grup
                if (user.addedGroups.length >= 3 && user.credit < 10) {
                    user.credit += 10;
                    await user.save();
                    
                    // Kirim pesan ke user
                    await ctx.telegram.sendMessage(
                        addedBy,
                        `Anda telah menambahkan bot ke 3 grup! Anda mendapatkan 10 kredit. Total kredit: ${user.credit}`
                    );
                } else {
                    await user.save();
                }
            }
            
            await ctx.reply(
                `Terima kasih telah menambahkan saya ke grup ini!\n\n` +
                `Gunakan /help untuk melihat perintah yang tersedia.`
            );
        }
    } catch (error) {
        console.error('Error handling new chat members:', error);
    }
}

module.exports = {
    handleCallbackQuery,
    handleNewChatMembers
};