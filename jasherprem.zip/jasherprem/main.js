/*
*Dibuat oleh aulia rahman
*Ditambahkan fitur fiturnya oleh ginaa septiana ramadhani
Base Ori Rahman x Gina septiana ramadhani

Sosmed media :
Ig : @4xglrs_
Tele : @ginaabaikhati
Wa : Privet
Yt : A. Aulia Rahman Official (@auliarhmanproduction)

Thanks too::
Allah swt
Nabi Muhammad
Ortu
Aulia Rahman
Ginaa septiana ramadhani
And Pengguna Copy/Paste:v

Note : don't remove copyright of this script!



Eh jangan lupa ini diganti yaawww🌹 dibagian src/commands
// Ganti ini:
const obfuscated = await JsConfuser.obfuscate(fileContent, getJapanObfuscationConfig());

// Menjadi ini:
const obfuscatedCode = await safeObfuscate(fileContent, getJapanObfuscationConfig(), 'Mandarin');
biar tidak error kalau mau enc / dec disitu ada decode sih:v
*/


const { Telegraf } = require('telegraf');
const { bot, setupCommands } = require('./src/commands');
const { setupHandlers } = require('./src/handlers');
const { log } = require('./lib/utils');

// Load config
require('./config');

// Inisialisasi bot
const bot = new Telegraf(BOT_TOKEN);

// Setup commands dan handlers
setupCommands();
setupHandlers(bot);

// Error handling
bot.catch((err, ctx) => {
  log('Error occurred:', err);
  ctx.reply('❌ Terjadi kesalahan pada bot. Silakan coba lagi nanti.');
});

// Start bot
bot.launch().then(() => {
  log('Bot started successfully!');
}).catch(err => {
  log('Failed to start bot:', err);
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));