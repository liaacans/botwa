const { Markup } = require('telegraf');
const db = require('../lib/database');
const utils = require('../lib/utils');
const obf = require('./obf');

// Handle callback queries
async function handleCallbackQuery(ctx) {
  const data = ctx.callbackQuery.data;
  const userId = ctx.from.id;
  const isCreator = utils.isCreator(userId);
  
  switch (data) {
    case 'jasher_menu':
      await showJasherMenu(ctx);
      break;
      
    case 'owner_menu':
      if (isCreator) {
        await showOwnerMenu(ctx);
      } else {
        await ctx.answerCbQuery('Anda bukan owner bot!');
      }
      break;
      
    case 'obf_menu':
      await showObfMenu(ctx);
      break;
      
    case 'back_menu':
      await ctx.deleteMessage();
      await showMainMenu(ctx);
      break;
      
    case 'main_menu':
      await showMainMenu(ctx);
      break;
      
    case 'add_premium':
      if (isCreator) {
        await ctx.reply('Gunakan command /addprem <user_id> <days>');
      }
      break;
      
    case 'remove_premium':
      if (isCreator) {
        await ctx.reply('Gunakan command /delprem <user_id>');
      }
      break;
      
    case 'list_premium':
      if (isCreator) {
        await ctx.reply('Gunakan command /listprem');
      }
      break;
      
    case 'broadcast':
      if (isCreator) {
        await ctx.reply('Balas pesan dengan /broadcast untuk mengirim ke semua user');
      }
      break;
      
    case 'blacklist_group':
      if (isCreator) {
        await ctx.reply('Gunakan command /addbl <group_id> atau /delbl <group_id>');
      }
      break;
      
    case 'auto_jasher':
      if (isCreator) {
        await ctx.reply('Gunakan command /autojasher <minutes> atau /stopautojasher');
      }
      break;
      
    case 'list_groups':
      if (isCreator) {
        await ctx.reply('Gunakan command /listgrup');
      }
      break;
      
    default:
      await ctx.answerCbQuery('Menu tidak dikenali!');
  }
  
  await ctx.answerCbQuery();
}

// Show Jasher Menu
async function showJasherMenu(ctx) {
  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('Share Free', 'share_free')],
    [Markup.button.callback('Share VIP', 'share_vip')],
    [Markup.button.callback('Cek Premium', 'cek_premium')],
    [Markup.button.callback('Kembali', 'back_menu')]
  ]);
  
  await ctx.editMessageCaption('Jasher Menu:', keyboard);
}

// Show Owner Menu
async function showOwnerMenu(ctx) {
  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('Add Premium', 'add_premium')],
    [Markup.button.callback('Remove Premium', 'remove_premium')],
    [Markup.button.callback('List Premium', 'list_premium')],
    [Markup.button.callback('Broadcast', 'broadcast')],
    [Markup.button.callback('Blacklist Group', 'blacklist_group')],
    [Markup.button.callback('Auto Jasher', 'auto_jasher')],
    [Markup.button.callback('List Groups', 'list_groups')],
    [Markup.button.callback('Kembali', 'back_menu')]
  ]);
  
  await ctx.editMessageCaption('Owner Menu:', keyboard);
}

// Show Obf Menu
async function showObfMenu(ctx) {
  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('Time-Locked', 'obf_time_locked')],
    [Markup.button.callback('Quantum Vortex', 'obf_quantum')],
    [Markup.button.callback('Siu Calcrick', 'obf_siu_calcrick')],
    [Markup.button.callback('Custom', 'obf_custom')],
    [Markup.button.callback('Nebula', 'obf_nebula')],
    [Markup.button.callback('Nova', 'obf_nova')],
    [Markup.button.callback('Strong', 'obf_strong')],
    [Markup.button.callback('Arab', 'obf_arab')],
    [Markup.button.callback('Japan x Arab', 'obf_japanxarab')],
    [Markup.button.callback('Japan', 'obf_japan')],
    [Markup.button.callback('Kembali', 'back_menu')]
  ]);
  
  await ctx.editMessageCaption('Obf Menu:', keyboard);
}

// Show Main Menu
async function showMainMenu(ctx) {
  const userId = ctx.from.id;
  const username = ctx.from.username || '';
  const isCreator = utils.isCreator(userId);
  
  const user = await db.getUser(userId);
  const premiumStatus = user && user.is_premium && moment().isBefore(user.premium_until) 
    ? `Aktif hingga ${moment(user.premium_until).format('DD/MM/YYYY HH:mm')}` 
    : 'Tidak aktif';
  
  const message = `╭─❒ 「 User Info 」 
├ Creator : @${global.developer}
├ Name : @${username}
├ Profile : @${ctx.from.username || 'No username'}
├ ID Telegram Anda: ${ctx.from.id}
├ Status Premium: ${premiumStatus}
├ Groups Added: ${user ? user.groups_added : 0}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${utils.runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreator ? 'True' : 'False'}

Silahkan pilih button dibawah ini!`;
  
  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('Jasher Menu', 'jasher_menu')],
    [Markup.button.callback('Owner Menu', 'owner_menu')],
    [Markup.button.callback('Obf Menu', 'obf_menu')]
  ]);
  
  await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
    caption: message,
    parse_mode: 'HTML',
    ...keyboard
  });
}

// Handle text messages
async function handleText(ctx) {
  const text = ctx.message.text;
  const userId = ctx.from.id;
  
  // Check if it's a share request
  if (text.toLowerCase().includes('/share') || text.toLowerCase().includes('share')) {
    await handleShareRequest(ctx);
    return;
  }
  
  // Check if it's a broadcast from owner
  if (ctx.message.reply_to_message && ctx.message.reply_to_message.text && 
      ctx.message.reply_to_message.text.includes('/broadcast') && 
      utils.isCreator(userId)) {
    await handleBroadcast(ctx);
    return;
  }
}

// Handle share request
async function handleShareRequest(ctx) {
  if (ctx.chat.type !== 'private') {
    await ctx.reply('Share hanya bisa dilakukan di private chat!');
    return;
  }
  
  const userId = ctx.from.id;
  const user = await db.getUser(userId);
  
  // Check if user has added enough groups
  const userGroups = await db.getGroupsByUser(userId);
  const hasEnoughGroups = userGroups.length >= global.groupRequirements;
  
  // Check if user is premium
  const isPremium = user && user.is_premium && moment().isBefore(user.premium_until);
  
  if (!hasEnoughGroups && !isPremium) {
    await ctx.reply(`Anda harus menambahkan bot ke ${global.groupRequirements} group terlebih dahulu untuk menggunakan fitur share!`);
    return;
  }
  
  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.text) {
    await ctx.reply('Balas ke pesan yang ingin di-share!');
    return;
  }
  
  const textToShare = ctx.message.reply_to_message.text;
  const groups = await db.getAllGroups();
  
  if (groups.length === 0) {
    await ctx.reply('Tidak ada group yang terdaftar untuk di-share.');
    return;
  }
  
  let successCount = 0;
  let failCount = 0;
  
  // Send to all groups
  for (const group of groups) {
    try {
      await ctx.telegram.sendMessage(group.id, textToShare);
      successCount++;
    } catch (error) {
      console.error(`Gagal mengirim ke group ${group.id}:`, error.message);
      failCount++;
      
      // If bot was removed from group, deactivate it
      if (error.response && error.response.error_code === 403) {
        await db.deactivateGroup(group.id);
      }
    }
  }
  
  await ctx.reply(`Broadcast selesai!\nBerhasil: ${successCount}\nGagal: ${failCount}`);
  
  // If this was a free user's first successful share, add premium days
  if (!isPremium && hasEnoughGroups && successCount > 0) {
    const premiumUntil = moment().add(global.premiumDaysPerGroup, 'days').format('YYYY-MM-DD HH:mm:ss');
    await db.updateUserPremium(userId, true, premiumUntil);
    await ctx.reply(`Selamat! Anda mendapatkan ${global.premiumDaysPerGroup} hari premium untuk berhasil melakukan share.`);
  }
}

// Handle broadcast to all users
async function handleBroadcast(ctx) {
  const userId = ctx.from.id;
  
  if (!utils.isCreator(userId)) {
    await ctx.reply('Hanya owner yang bisa melakukan broadcast!');
    return;
  }
  
  const messageText = ctx.message.text;
  const users = await db.getAllUsers();
  
  let successCount = 0;
  let failCount = 0;
  
  for (const user of users) {
    try {
      await ctx.telegram.sendMessage(user.id, messageText);
      successCount++;
    } catch (error) {
      console.error(`Gagal mengirim ke user ${user.id}:`, error.message);
      failCount++;
    }
  }
  
  await ctx.reply(`Broadcast ke semua user selesai!\nBerhasil: ${successCount}\nGagal: ${failCount}`);
}

// Handle photo messages (for toUrl command)
async function handlePhoto(ctx) {
  // This is handled in the toUrl command
}

module.exports = {
  handleCallbackQuery,
  handleText,
  handlePhoto
};