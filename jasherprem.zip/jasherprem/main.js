const { Telegraf, session } = require('telegraf');
const { Markup } = require('telegraf');
const { updateProgress, runtime, checkPremium, addGroup, removeGroup, getUserGroups, addPremium, removePremium, listPremium, addBlacklist, removeBlacklist, listBlacklist, broadcastMessage, getStats, uploadToUrl, autoJasher, stopAutoJasher } = require('./lib/utils');
const { handleObfCommands } = require('./src/obf');
const { handleMessage } = require('./src/handlers');
const moment = require('moment-timezone');

const bot = new Telegraf(global.BOT_TOKEN);

// Middleware session
bot.use(session());

// Middleware untuk menangani pesan
bot.use(async (ctx, next) => {
  if (ctx.chat && ctx.chat.type === 'private') {
    // Simpan data pengguna ke database jika baru
    await db.getUser(ctx.from.id, ctx.from);
  }
  next();
});

// Command handlers
bot.start(async (ctx) => {
  const userId = ctx.from.id;
  const username = ctx.from.username || 'Tidak ada';
  const isCreator = global.ownerId.includes(userId);
  
  const menuText = `╭─❒ 「 User Info 」 
├ Creator : @${global.developer}
├ Name : @${username}
├ Profile : @${ctx.from.first_name}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreator ? 'True' : 'False'}

Silahkan pilih button dibawah ini!`;

  const buttons = Markup.inlineKeyboard([
    [Markup.button.callback('Jasher Menu', 'jasher_menu')],
    [Markup.button.callback('Obf Menu', 'obf_menu')],
    [Markup.button.callback('Main Menu', 'main_menu')],
    isCreator ? [Markup.button.callback('Owner Menu', 'owner_menu')] : []
  ]);

  try {
    await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
      caption: menuText,
      parse_mode: 'HTML',
      ...buttons
    });
  } catch (error) {
    await ctx.reply(menuText, { parse_mode: 'HTML', ...buttons });
  }
});

// Handle callback queries
bot.action('jasher_menu', async (ctx) => {
  const userId = ctx.from.id;
  const isPremium = await checkPremium(userId);
  
  const buttons = Markup.inlineKeyboard([
    [Markup.button.callback('Share VIP', 'share_vip')],
    [Markup.button.callback('Share Free', 'share_free')],
    [Markup.button.callback('Cek Premium', 'check_premium')],
    [Markup.button.callback('Kembali', 'main_menu')]
  ]);
  
  await ctx.editMessageCaption(
    `╭─❒ 「 Jasher Menu 」 
├ Status : ${isPremium ? 'Premium' : 'Free'}
├ Expired : ${isPremium ? '30 hari' : 'Tidak ada'}
╰❒ Fitur : Share ke grup untuk premium

Pilih opsi di bawah:`,
    { parse_mode: 'HTML', ...buttons }
  );
});

bot.action('obf_menu', async (ctx) => {
  const buttons = Markup.inlineKeyboard([
    [Markup.button.callback('Time-Locked Encryption', 'obf_timelocked')],
    [Markup.button.callback('Quantum Vortex Encryption', 'obf_quantum')],
    [Markup.button.callback('Siu Calcrick Obfuscation', 'obf_siu')],
    [Markup.button.callback('Custom Obfuscation', 'obf_custom')],
    [Markup.button.callback('Nebula Obfuscation', 'obf_nebula')],
    [Markup.button.callback('Nova Obfuscation', 'obf_nova')],
    [Markup.button.callback('Strong Obfuscation', 'obf_strong')],
    [Markup.button.callback('Arab Obfuscation', 'obf_arab')],
    [Markup.button.callback('Japan Obfuscation', 'obf_japan')],
    [Markup.button.callback('Japan x Arab Obfuscation', 'obf_japan_arab')],
    [Markup.button.callback('Kembali', 'main_menu')]
  ]);
  
  await ctx.editMessageCaption(
    `╭─❒ 「 Obfuscation Menu 」 
├ Pilih jenis obfuscation:
╰❒ Upload file JavaScript untuk diobfuscate`,
    { parse_mode: 'HTML', ...buttons }
  );
});

bot.action('owner_menu', async (ctx) => {
  if (!global.ownerId.includes(ctx.from.id)) {
    return ctx.answerCbQuery('Akses ditolak! Hanya owner yang bisa mengakses menu ini.');
  }
  
  const buttons = Markup.inlineKeyboard([
    [Markup.button.callback('Broadcast Message', 'broadcast_msg')],
    [Markup.button.callback('Add Premium', 'add_premium')],
    [Markup.button.callback('Remove Premium', 'remove_premium')],
    [Markup.button.callback('List Premium', 'list_premium')],
    [Markup.button.callback('Add Blacklist', 'add_blacklist')],
    [Markup.button.callback('Remove Blacklist', 'remove_blacklist')],
    [Markup.button.callback('List Blacklist', 'list_blacklist')],
    [Markup.button.callback('Auto Jasher', 'auto_jasher')],
    [Markup.button.callback('Stop Auto Jasher', 'stop_auto_jasher')],
    [Markup.button.callback('List Groups', 'list_groups')],
    [Markup.button.callback('Stats Bot', 'bot_stats')],
    [Markup.button.callback('Kembali', 'main_menu')]
  ]);
  
  await ctx.editMessageCaption(
    `╭─❒ 「 Owner Menu 」 
├ Hanya untuk owner bot
╰❒ Pilih opsi di bawah:`,
    { parse_mode: 'HTML', ...buttons }
  );
});

bot.action('main_menu', async (ctx) => {
  const userId = ctx.from.id;
  const username = ctx.from.username || 'Tidak ada';
  const isCreator = global.ownerId.includes(userId);
  
  const menuText = `╭─❒ 「 User Info 」 
├ Creator : @${global.developer}
├ Name : @${username}
├ Profile : @${ctx.from.first_name}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreator ? 'True' : 'False'}

Silahkan pilih button dibawah ini!`;

  const buttons = Markup.inlineKeyboard([
    [Markup.button.callback('Jasher Menu', 'jasher_menu')],
    [Markup.button.callback('Obf Menu', 'obf_menu')],
    [Markup.button.callback('Main Menu', 'main_menu')],
    isCreator ? [Markup.button.callback('Owner Menu', 'owner_menu')] : []
  ]);

  await ctx.editMessageCaption(menuText, { parse_mode: 'HTML', ...buttons });
});

// Handle obfuscation callbacks
bot.action(/obf_.+/, async (ctx) => {
  const obfType = ctx.match[0].replace('obf_', '');
  await ctx.reply(`Silakan upload file JavaScript untuk diobfuscate dengan metode ${obfType}.`);
  ctx.session.obfuscationType = obfType;
});

// Handle share callbacks
bot.action('share_vip', async (ctx) => {
  const userId = ctx.from.id;
  const isPremium = await checkPremium(userId);
  
  if (!isPremium) {
    return ctx.reply('Anda harus premium untuk menggunakan fitur Share VIP. Silakan share di 3 grup terlebih dahulu untuk mendapatkan premium.');
  }
  
  await ctx.reply('Silakan reply pesan yang ingin dishare dengan command /sharevip');
});

bot.action('share_free', async (ctx) => {
  await ctx.reply('Silakan reply pesan yang ingin dishare dengan command /sharefree');
});

// Handle owner menu callbacks
bot.action('broadcast_msg', async (ctx) => {
  if (!global.ownerId.includes(ctx.from.id)) {
    return ctx.answerCbQuery('Akses ditolak!');
  }
  
  await ctx.reply('Silakan ketik pesan yang ingin di-broadcast ke semua pengguna:');
  ctx.session.waitingForBroadcast = true;
});

bot.action('add_premium', async (ctx) => {
  if (!global.ownerId.includes(ctx.from.id)) {
    return ctx.answerCbQuery('Akses ditolak!');
  }
  
  await ctx.reply('Silakan reply pesan dengan user ID dan jumlah hari (format: userID:hari):');
  ctx.session.waitingForAddPremium = true;
});

bot.action('remove_premium', async (ctx) => {
  if (!global.ownerId.includes(ctx.from.id)) {
    return ctx.answerCbQuery('Akses ditolak!');
  }
  
  await ctx.reply('Silakan reply dengan user ID yang ingin dihapus dari premium:');
  ctx.session.waitingForRemovePremium = true;
});

bot.action('list_premium', async (ctx) => {
  if (!global.ownerId.includes(ctx.from.id)) {
    return ctx.answerCbQuery('Akses ditolak!');
  }
  
  const premiumList = await listPremium();
  await ctx.reply(`Daftar pengguna premium:\n${premiumList}`);
});

bot.action('add_blacklist', async (ctx) => {
  if (!global.ownerId.includes(ctx.from.id)) {
    return ctx.answerCbQuery('Akses ditolak!');
  }
  
  await ctx.reply('Silakan reply dengan user ID atau group ID yang ingin ditambahkan ke blacklist:');
  ctx.session.waitingForAddBlacklist = true;
});

bot.action('remove_blacklist', async (ctx) => {
  if (!global.ownerId.includes(ctx.from.id)) {
    return ctx.answerCbQuery('Akses ditolak!');
  }
  
  await ctx.reply('Silakan reply dengan user ID atau group ID yang ingin dihapus dari blacklist:');
  ctx.session.waitingForRemoveBlacklist = true;
});

bot.action('list_blacklist', async (ctx) => {
  if (!global.ownerId.includes(ctx.from.id)) {
    return ctx.answerCbQuery('Akses ditolak!');
  }
  
  const blacklist = await listBlacklist();
  await ctx.reply(`Daftar blacklist:\n${blacklist}`);
});

bot.action('auto_jasher', async (ctx) => {
  if (!global.ownerId.includes(ctx.from.id)) {
    return ctx.answerCbQuery('Akses ditolak!');
  }
  
  const result = await autoJasher(bot);
  await ctx.reply(result);
});

bot.action('stop_auto_jasher', async (ctx) => {
  if (!global.ownerId.includes(ctx.from.id)) {
    return ctx.answerCbQuery('Akses ditolak!');
  }
  
  const result = stopAutoJasher();
  await ctx.reply(result);
});

bot.action('list_groups', async (ctx) => {
  if (!global.ownerId.includes(ctx.from.id)) {
    return ctx.answerCbQuery('Akses ditolak!');
  }
  
  const userGroups = await getUserGroups(ctx.from.id);
  await ctx.reply(`Daftar grup Anda:\n${userGroups.join('\n')}`);
});

bot.action('bot_stats', async (ctx) => {
  if (!global.ownerId.includes(ctx.from.id)) {
    return ctx.answerCbQuery('Akses ditolak!');
  }
  
  const stats = await getStats();
  await ctx.reply(`Statistik Bot:\nTotal Users: ${stats.totalUsers}\nPremium Users: ${stats.premiumUsers}\nTotal Groups: ${stats.totalGroups}`);
});

// Handle text messages
bot.on('text', async (ctx) => {
  await handleMessage(ctx, bot);
});

// Handle document upload for obfuscation
bot.on('document', async (ctx) => {
  if (ctx.session.obfuscationType) {
    const fileId = ctx.message.document.file_id;
    const file = await ctx.telegram.getFile(fileId);
    const fileUrl = `https://api.telegram.org/file/bot${global.BOT_TOKEN}/${file.file_path}`;
    
    try {
      const response = await fetch(fileUrl);
      const fileContent = await response.text();
      
      let obfuscatedCode;
      switch (ctx.session.obfuscationType) {
        case 'timelocked':
          await ctx.reply('Berapa hari masa aktif obfuscation?');
          ctx.session.waitingForDays = true;
          ctx.session.fileContent = fileContent;
          break;
        case 'quantum':
          obfuscatedCode = await obfuscateQuantum(fileContent);
          await ctx.reply('Obfuscation berhasil!');
          await ctx.reply(obfuscatedCode, { parse_mode: 'HTML' });
          break;
        // Tambahkan case lainnya sesuai jenis obfuscation
        default:
          await ctx.reply('Jenis obfuscation tidak dikenali.');
      }
      
      delete ctx.session.obfuscationType;
    } catch (error) {
      await ctx.reply('Gagal memproses file: ' + error.message);
    }
  }
});

// Handle new chat members (bot added to group)
bot.on('new_chat_members', async (ctx) => {
  const newMembers = ctx.message.new_chat_members;
  const botId = ctx.botInfo.id;
  
  for (const member of newMembers) {
    if (member.id === botId) {
      // Bot ditambahkan ke grup
      const groupId = ctx.chat.id;
      const groupName = ctx.chat.title;
      await addGroup(groupId, groupName);
      await ctx.reply('Terima kasih telah menambahkan saya ke grup ini!');
    }
  }
});

// Handle bot being removed from group
bot.on('left_chat_member', async (ctx) => {
  const leftMember = ctx.message.left_chat_member;
  const botId = ctx.botInfo.id;
  
  if (leftMember.id === botId) {
    // Bot dihapus dari grup
    const groupId = ctx.chat.id;
    await removeGroup(groupId);
  }
});

// Start bot
bot.launch().then(() => {
  console.log('Bot Jasher Premium berjalan!');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));