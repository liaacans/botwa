const { getUser, updateUser, addUser, getPremiumUsers, addPremiumUser, removePremiumUser } = require('../lib/database');
const { formatCredit } = require('../lib/utils');
const { mainKeyboard, ownerKeyboard } = require('./keyboards');

const handleStart = (ctx) => {
    const user = ctx.from;
    addUser({
        userId: user.id,
        username: user.username,
        firstName: user.first_name,
        lastName: user.last_name
    });
    
    ctx.reply(
        `👋 Halo ${user.first_name}! Selamat datang di Jasher Bot Premium.\n\n` +
        'Gunakan bot ini untuk membagikan pesan ke banyak group secara otomatis.\n\n' +
        '✅ Ketik /credit untuk melihat kredit Anda\n' +
        '✅ Ketik /share untuk membagikan pesan (2 kredit)\n' +
        '✅ Ketik /sharevip untuk membagikan pesan lebih cepat (hanya premium)\n\n' +
        'Tambahkan 3 group untuk mendapatkan 10 kredit gratis!',
        mainKeyboard
    );
};

const handleHelp = (ctx) => {
    ctx.reply(
        '🆘 Bantuan Jasher Bot:\n\n' +
        '/start - Memulai bot\n' +
        '/help - Menampilkan bantuan\n' +
        '/credit - Mengecek kredit Anda\n' +
        '/share - Membagikan pesan (2 kredit)\n' +
        '/sharevip - Membagikan pesan VIP (hanya premium)\n\n' +
        '📝 Cara menambah kredit:\n' +
        '1. Tambahkan bot ke group Anda\n' +
        '2. Jadikan bot sebagai admin\n' +
        '3. Ketik /addgroup di group tersebut\n' +
        '4. Dapatkan 10 kredit setelah menambah 3 group',
        mainKeyboard
    );
};

const handleCredit = (ctx) => {
    getUser(ctx.from.id, (err, user) => {
        if (err || !user) {
            return ctx.reply('Terjadi error saat mengambil data kredit.');
        }
        
        ctx.reply(
            `💳 Kredit Anda: ${formatCredit(user.credit)}\n\n` +
            `📊 Group yang telah ditambahkan: ${user.groupsAdded}\n` +
            `⭐ Status Premium: ${user.isPremium ? 'Ya' : 'Tidak'}\n\n` +
            'Tambahkan 3 group untuk mendapatkan 10 kredit gratis!'
        );
    });
};

const handleShare = (ctx) => {
    // Cek apakah di private chat
    if (ctx.chat.type !== 'private') {
        return ctx.reply('❌ Perintah /share hanya bisa digunakan di private chat!');
    }
    
    // Cek apakah ada reply pesan
    if (!ctx.message.reply_to_message) {
        return ctx.reply('❌ Balas pesan yang ingin dibagikan dengan /share');
    }
    
    getUser(ctx.from.id, (err, user) => {
        if (err || !user) {
            return ctx.reply('Terjadi error saat mengambil data user.');
        }
        
        // Cek kredit
        if (user.credit < 2) {
            return ctx.reply('❌ Kredit tidak cukup. Anda perlu 2 kredit untuk membagikan pesan.');
        }
        
        // Kurangi kredit
        updateUser(ctx.from.id, { credit: user.credit - 2 }, (err) => {
            if (err) {
                return ctx.reply('Terjadi error saat mengurangi kredit.');
            }
            
            // Di sini seharusnya ada logika untuk membroadcast pesan ke group-group
            // Ini adalah placeholder, implementasi sebenarnya tergantung bagaimana Anda menyimpan daftar group
            
            ctx.reply(
                '✅ Pesan berhasil dibagikan ke semua group!\n\n' +
                `Kredit tersisa: ${formatCredit(user.credit - 2)}`
            );
        });
    });
};

const handleShareVip = (ctx) => {
    // Cek apakah di private chat
    if (ctx.chat.type !== 'private') {
        return ctx.reply('❌ Perintah /sharevip hanya bisa digunakan di private chat!');
    }
    
    // Cek apakah user premium
    getUser(ctx.from.id, (err, user) => {
        if (err || !user) {
            return ctx.reply('Terjadi error saat mengambil data user.');
        }
        
        if (!user.isPremium) {
            return ctx.reply('❌ Fitur ini hanya untuk user premium!');
        }
        
        // Cek apakah ada reply pesan
        if (!ctx.message.reply_to_message) {
            return ctx.reply('❌ Balas pesan yang ingin dibagikan dengan /sharevip');
        }
        
        // Di sini seharusnya ada logika untuk membroadcast pesan VIP ke group-group
        // Ini adalah placeholder, implementasi sebenarnya tergantung bagaimana Anda menyimpan daftar group
        
        ctx.reply('✅ Pesan VIP berhasil dibagikan ke semua group dengan cepat!');
    });
};

const handleBroadcast = (ctx) => {
    // Cek apakah user adalah admin
    if (!global.ADMIN_ID.includes(ctx.from.id)) {
        return ctx.reply('❌ Anda tidak memiliki akses untuk perintah ini!');
    }
    
    // Cek apakah ada teks setelah perintah
    const messageText = ctx.message.text.split(' ').slice(1).join(' ');
    if (!messageText) {
        return ctx.reply('❌ Gunakan: /broadcast <pesan>');
    }
    
    // Di sini seharusnya ada logika untuk membroadcast pesan ke semua user
    // Ini adalah placeholder, implementasi sebenarnya tergantung bagaimana Anda menyimpan daftar user
    
    ctx.reply('✅ Pesan broadcast berhasil dikirim ke semua user!');
};

const handleAddPrem = (ctx) => {
    // Cek apakah user adalah admin
    if (!global.ADMIN_ID.includes(ctx.from.id)) {
        return ctx.reply('❌ Anda tidak memiliki akses untuk perintah ini!');
    }
    
    // Cek apakah ada user ID yang disebutkan
    const args = ctx.message.text.split(' ').slice(1);
    if (args.length === 0) {
        return ctx.reply('❌ Gunakan: /addprem <user_id>');
    }
    
    const userId = parseInt(args[0]);
    if (isNaN(userId)) {
        return ctx.reply('❌ User ID harus angka!');
    }
    
    addPremiumUser(userId, ctx.from.id, (err) => {
        if (err) {
            return ctx.reply('❌ Gagal menambahkan user premium. Mungkin user sudah premium.');
        }
        
        ctx.reply(`✅ User ${userId} berhasil ditambahkan sebagai premium!`);
    });
};

const handleDelPrem = (ctx) => {
    // Cek apakah user adalah admin
    if (!global.ADMIN_ID.includes(ctx.from.id)) {
        return ctx.reply('❌ Anda tidak memiliki akses untuk perintah ini!');
    }
    
    // Cek apakah ada user ID yang disebutkan
    const args = ctx.message.text.split(' ').slice(1);
    if (args.length === 0) {
        return ctx.reply('❌ Gunakan: /delprem <user_id>');
    }
    
    const userId = parseInt(args[0]);
    if (isNaN(userId)) {
        return ctx.reply('❌ User ID harus angka!');
    }
    
    removePremiumUser(userId, (err) => {
        if (err) {
            return ctx.reply('❌ Gagal menghapus user premium.');
        }
        
        ctx.reply(`✅ User ${userId} berhasil dihapus dari premium!`);
    });
};

const handleListPrem = (ctx) => {
    // Cek apakah user adalah admin
    if (!global.ADMIN_ID.includes(ctx.from.id)) {
        return ctx.reply('❌ Anda tidak memiliki akses untuk perintah ini!');
    }
    
    getPremiumUsers((err, users) => {
        if (err) {
            return ctx.reply('❌ Gagal mengambil daftar user premium.');
        }
        
        if (users.length === 0) {
            return ctx.reply('📝 Tidak ada user premium.');
        }
        
        let message = '📝 Daftar User Premium:\n\n';
        users.forEach((user, index) => {
            message += `${index + 1}. ${user.firstName} ${user.lastName || ''} (@${user.username || 'tidak ada'}) - ID: ${user.userId}\n`;
        });
        
        ctx.reply(message);
    });
};

module.exports = {
    handleStart,
    handleHelp,
    handleCredit,
    handleShare,
    handleShareVip,
    handleBroadcast,
    handleAddPrem,
    handleDelPrem,
    handleListPrem
};