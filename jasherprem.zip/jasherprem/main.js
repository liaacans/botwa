const { Telegraf, Markup, session } = require('telegraf');
const { BOT_TOKEN } = require('./config');
const { initializeDatabase, addUser, getUser, addGroup, getGroups, isPremium, addPremium, removePremium, getPremiumUsers, addBlacklist, removeBlacklist, getBlacklist, addCredit, deductCredit, getCredit } = require('./lib/database');
const { runtime, formatTime, createProgressBar, updateProgress, log } = require('./lib/utils');
const moment = require('moment-timezone');
const fs = require('fs-extra');
const path = require('path');
const fetch = require('node-fetch');

// Import command handlers
const { setupCommands } = require('./src/commands');
const { setupHandlers } = require('./src/handlers');

// Initialize bot
const bot = new Telegraf(BOT_TOKEN);
bot.use(session());

// Initialize database
initializeDatabase();

// Middleware to track users and groups
bot.use(async (ctx, next) => {
    if (ctx.message) {
        const userId = ctx.from.id;
        const username = ctx.from.username || 'No Username';
        const firstName = ctx.from.first_name || '';
        const lastName = ctx.from.last_name || '';
        
        // Add user to database
        addUser(userId, username, firstName, lastName);
        
        // If this is a group message, add group to database
        if (ctx.chat.type !== 'private') {
            const groupId = ctx.chat.id;
            const groupName = ctx.chat.title || 'No Group Name';
            addGroup(groupId, groupName, userId);
        }
    }
    return next();
});

// Setup commands and handlers
setupCommands(bot);
setupHandlers(bot);

// Start bot
bot.launch().then(() => {
    console.log('Bot Jasher Premium started!');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));