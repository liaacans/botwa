const { Markup } = require('telegraf');
const { User, Group, Broadcast } = require('../lib/database');
const { isPremium, addDays, formatDate } = require('../lib/utils');
require('../config');
const axios = require('axios');
const imageToBase64 = require('image-to-base64');

module.exports = {
    handleJasherMenu: async (ctx) => {
        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('Share to Groups', 'share_groups')],
            [Markup.button.callback('Check Premium', 'check_premium')],
            [Markup.button.callback('My Groups', 'my_groups')],
            [Markup.button.callback('Kembali', 'main_menu')]
        ]);
        
        await ctx.editMessageCaption({
            caption: 'Jasher Menu - Pilih opsi yang tersedia:',
            parse_mode: 'HTML',
            ...keyboard
        });
        await ctx.answerCbQuery();
    },
    
    handleObfMenu: async (ctx) => {
        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('Time-Locked Encryption', 'obf_enclocked')],
            [Markup.button.callback('Quantum Vortex Encryption', 'obf_quantum')],
            [Markup.button.callback('Kembali', 'main_menu')]
        ]);
        
        await ctx.editMessageCaption({
            caption: 'Obfuscation Menu - Pilih jenis obfuscation:',
            parse_mode: 'HTML',
            ...keyboard
        });
        await ctx.answerCbQuery();
    },
    
    handleOwnerMenu: async (ctx) => {
        if (ctx.from.id !== global.creatorId) {
            await ctx.answerCbQuery('Akses ditolak. Hanya owner yang bisa mengakses menu ini.', { show_alert: true });
            return;
        }
        
        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('Broadcast', 'owner_broadcast')],
            [Markup.button.callback('User Stats', 'owner_stats')],
            [Markup.button.callback('Group Stats', 'owner_group_stats')],
            [Markup.button.callback('Kembali', 'main_menu')]
        ]);
        
        await ctx.editMessageCaption({
            caption: 'Owner Menu - Pilih opsi yang tersedia:',
            parse_mode: 'HTML',
            ...keyboard
        });
        await ctx.answerCbQuery();
    },
    
    handleAddPrem: async (ctx) => {
        if (ctx.from.id !== global.creatorId) {
            await ctx.reply('Hanya owner yang dapat menggunakan perintah ini.');
            return;
        }
        
        const args = ctx.message.text.split(' ');
        if (args.length < 3) {
            await ctx.reply('Format: /addprem [user_id] [days]');
            return;
        }
        
        const userId = parseInt(args[1]);
        const days = parseInt(args[2]);
        
        if (isNaN(userId) || isNaN(days)) {
            await ctx.reply('User ID dan hari harus berupa angka.');
            return;
        }
        
        try {
            const user = await User.findOne({ userId });
            if (!user) {
                await ctx.reply('User tidak ditemukan.');
                return;
            }
            
            const now = new Date();
            if (user.premiumExpiry && user.premiumExpiry > now) {
                user.premiumExpiry = addDays(user.premiumExpiry, days);
            } else {
                user.premiumExpiry = addDays(now, days);
            }
            
            await user.save();
            await ctx.reply(`Berhasil menambahkan ${days} hari premium untuk user ${userId}.`);
        } catch (error) {
            console.error(error);
            await ctx.reply('Terjadi kesalahan saat menambahkan premium.');
        }
    },
    
    handleDelPrem: async (ctx) => {
        if (ctx.from.id !== global.creatorId) {
            await ctx.reply('Hanya owner yang dapat menggunakan perintah ini.');
            return;
        }
        
        const args = ctx.message.text.split(' ');
        if (args.length < 2) {
            await ctx.reply('Format: /delprem [user_id]');
            return;
        }
        
        const userId = parseInt(args[1]);
        
        if (isNaN(userId)) {
            await ctx.reply('User ID harus berupa angka.');
            return;
        }
        
        try {
            const user = await User.findOne({ userId });
            if (!user) {
                await ctx.reply('User tidak ditemukan.');
                return;
            }
            
            user.premiumExpiry = null;
            await user.save();
            await ctx.reply(`Berhasil menghapus premium untuk user ${userId}.`);
        } catch (error) {
            console.error(error);
            await ctx.reply('Terjadi kesalahan saat menghapus premium.');
        }
    },
    
    handleListPrem: async (ctx) => {
        if (ctx.from.id !== global.creatorId) {
            await ctx.reply('Hanya owner yang dapat menggunakan perintah ini.');
            return;
        }
        
        try {
            const premiumUsers = await User.find({
                premiumExpiry: { $gt: new Date() }
            });
            
            if (premiumUsers.length === 0) {
                await ctx.reply('Tidak ada user premium.');
                return;
            }
            
            let message = 'Daftar User Premium:\n\n';
            premiumUsers.forEach((user, index) => {
                message += `${index + 1}. ID: ${user.userId} | Username: @${user.username || 'N/A'}\n`;
                message += `   Expiry: ${formatDate(user.premiumExpiry)}\n\n`;
            });
            
            await ctx.reply(message);
        } catch (error) {
            console.error(error);
            await ctx.reply('Terjadi kesalahan saat mengambil daftar premium.');
        }
    },
    
    handleAddBlacklist: async (ctx) => {
        if (ctx.from.id !== global.creatorId) {
            await ctx.reply('Hanya owner yang dapat menggunakan perintah ini.');
            return;
        }
        
        const args = ctx.message.text.split(' ');
        if (args.length < 2) {
            await ctx.reply('Format: /addbl [group_id]');
            return;
        }
        
        const groupId = parseInt(args[1]);
        
        if (isNaN(groupId)) {
            await ctx.reply('Group ID harus berupa angka.');
            return;
        }
        
        try {
            const group = await Group.findOne({ groupId });
            if (!group) {
                await ctx.reply('Group tidak ditemukan.');
                return;
            }
            
            group.isBlacklisted = true;
            await group.save();
            await ctx.reply(`Berhasil menambahkan group ${groupId} ke blacklist.`);
        } catch (error) {
            console.error(error);
            await ctx.reply('Terjadi kesalahan saat menambahkan blacklist.');
        }
    },
    
    handleDelBlacklist: async (ctx) => {
        if (ctx.from.id !== global.creatorId) {
            await ctx.reply('Hanya owner yang dapat menggunakan perintah ini.');
            return;
        }
        
        const args = ctx.message.text.split(' ');
        if (args.length < 2) {
            await ctx.reply('Format: /delbl [group_id]');
            return;
        }
        
        const groupId = parseInt(args[1]);
        
        if (isNaN(groupId)) {
            await ctx.reply('Group ID harus berupa angka.');
            return;
        }
        
        try {
            const group = await Group.findOne({ groupId });
            if (!group) {
                await ctx.reply('Group tidak ditemukan.');
                return;
            }
            
            group.isBlacklisted = false;
            await group.save();
            await ctx.reply(`Berhasil menghapus group ${groupId} dari blacklist.`);
        } catch (error) {
            console.error(error);
            await ctx.reply('Terjadi kesalahan saat menghapus blacklist.');
        }
    },
    
    handleListBlacklist: async (ctx) => {
        if (ctx.from.id !== global.creatorId) {
            await ctx.reply('Hanya owner yang dapat menggunakan perintah ini.');
            return;
        }
        
        try {
            const blacklistedGroups = await Group.find({ isBlacklisted: true });
            
            if (blacklistedGroups.length === 0) {
                await ctx.reply('Tidak ada group yang di-blacklist.');
                return;
            }
            
            let message = 'Daftar Group Blacklisted:\n\n';
            blacklistedGroups.forEach((group, index) => {
                message += `${index + 1}. ID: ${group.groupId} | Title: ${group.title}\n`;
            });
            
            await ctx.reply(message);
        } catch (error) {
            console.error(error);
            await ctx.reply('Terjadi kesalahan saat mengambil daftar blacklist.');
        }
    },
    
    handleAutoJasher: async (ctx) => {
        if (ctx.from.id !== global.creatorId) {
            await ctx.reply('Hanya owner yang dapat menggunakan perintah ini.');
            return;
        }
        
        // Implementation for auto jasher
        await ctx.reply('Fitur Auto Jasher akan diimplementasikan.');
    },
    
    handleStopAutoJasher: async (ctx) => {
        if (ctx.from.id !== global.creatorId) {
            await ctx.reply('Hanya owner yang dapat menggunakan perintah ini.');
            return;
        }
        
        // Implementation for stop auto jasher
        await ctx.reply('Fitur Stop Auto Jasher akan diimplementasikan.');
    },
    
    handleListGroups: async (ctx) => {
        if (ctx.from.id !== global.creatorId) {
            await ctx.reply('Hanya owner yang dapat menggunakan perintah ini.');
            return;
        }
        
        try {
            const groups = await Group.find({ isActive: true });
            
            if (groups.length === 0) {
                await ctx.reply('Tidak ada group aktif.');
                return;
            }
            
            let message = 'Daftar Group Aktif:\n\n';
            groups.forEach((group, index) => {
                message += `${index + 1}. ID: ${group.groupId} | Title: ${group.title}\n`;
                message += `   Members: ${group.memberCount} | Added: ${formatDate(group.addedAt)}\n\n`;
            });
            
            await ctx.reply(message);
        } catch (error) {
            console.error(error);
            await ctx.reply('Terjadi kesalahan saat mengambil daftar group.');
        }
    },
    
    handleToUrl: async (ctx) => {
        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.photo) {
            await ctx.reply('Balas pesan foto dengan perintah ini untuk mengubahnya menjadi URL.');
            return;
        }
        
        try {
            const photo = ctx.message.reply_to_message.photo;
            const fileId = photo[photo.length - 1].file_id;
            const fileLink = await ctx.telegram.getFileLink(fileId);
            
            // Convert image to base64
            const base64 = await imageToBase64(fileLink.href);
            const dataUrl = `data:image/jpeg;base64,${base64}`;
            
            await ctx.reply(`URL Gambar: ${dataUrl}`);
        } catch (error) {
            console.error(error);
            await ctx.reply('Terjadi kesalahan saat mengonversi gambar ke URL.');
        }
    },
    
    handleShareVip: async (ctx) => {
        if (!isPremium(ctx.user)) {
            await ctx.reply('Anda harus premium untuk menggunakan fitur ini.');
            return;
        }
        
        if (ctx.chat.type !== 'private') {
            await ctx.reply('Perintah ini hanya bisa digunakan di private chat.');
            return;
        }
        
        if (!ctx.message.reply_to_message) {
            await ctx.reply('Balas pesan yang ingin Anda share dengan perintah ini.');
            return;
        }
        
        try {
            const userGroups = ctx.user.groups;
            if (userGroups.length === 0) {
                await ctx.reply('Anda belum menambahkan bot ke group manapun.');
                return;
            }
            
            let successCount = 0;
            let failCount = 0;
            
            for (const group of userGroups) {
                try {
                    const groupInfo = await Group.findOne({ groupId: group.groupId });
                    if (groupInfo && groupInfo.isBlacklisted) {
                        failCount++;
                        continue;
                    }
                    
                    // Forward message to group
                    await ctx.forwardMessage(group.groupId, ctx.chat.id, ctx.message.reply_to_message.message_id);
                    successCount++;
                    
                    // Wait a bit to avoid rate limiting
                    await new Promise(resolve => setTimeout(resolve, 1000));
                } catch (error) {
                    console.error(`Error sharing to group ${group.groupId}:`, error);
                    failCount++;
                }
            }
            
            ctx.user.sharedCount += successCount;
            await ctx.user.save();
            
            await ctx.reply(`Berhasil share ke ${successCount} group, gagal: ${failCount} group.`);
        } catch (error) {
            console.error(error);
            await ctx.reply('Terjadi kesalahan saat melakukan share.');
        }
    },
    
    handleShare: async (ctx) => {
        if (ctx.chat.type !== 'private') {
            await ctx.reply('Share hanya bisa dilakukan dari private chat.');
            return;
        }
        
        // Check if user has added bot to at least 3 groups
        if (ctx.user.groups.length < 3 && !isPremium(ctx.user)) {
            await ctx.reply('Anda harus menambahkan bot ke minimal 3 group untuk bisa menggunakan fitur ini.');
            return;
        }
        
        try {
            const userGroups = ctx.user.groups;
            let successCount = 0;
            let failCount = 0;
            
            for (const group of userGroups) {
                try {
                    const groupInfo = await Group.findOne({ groupId: group.groupId });
                    if (groupInfo && groupInfo.isBlacklisted) {
                        failCount++;
                        continue;
                    }
                    
                    // Send message to group
                    await ctx.telegram.sendMessage(group.groupId, ctx.message.text);
                    successCount++;
                    
                    // Wait a bit to avoid rate limiting
                    await new Promise(resolve => setTimeout(resolve, 1000));
                } catch (error) {
                    console.error(`Error sharing to group ${group.groupId}:`, error);
                    failCount++;
                }
            }
            
            ctx.user.sharedCount += successCount;
            
            // Add premium days if user is not premium and shared successfully
            if (!isPremium(ctx.user) && successCount > 0) {
                const now = new Date();
                if (ctx.user.premiumExpiry && ctx.user.premiumExpiry > now) {
                    ctx.user.premiumExpiry = addDays(ctx.user.premiumExpiry, 3);
                } else {
                    ctx.user.premiumExpiry = addDays(now, 3);
                }
            }
            
            await ctx.user.save();
            
            await ctx.reply(`Berhasil share ke ${successCount} group, gagal: ${failCount} group.${!isPremium(ctx.user) && successCount > 0 ? ' Anda mendapatkan 3 hari premium!' : ''}`);
        } catch (error) {
            console.error(error);
            await ctx.reply('Terjadi kesalahan saat melakukan share.');
        }
    }
};