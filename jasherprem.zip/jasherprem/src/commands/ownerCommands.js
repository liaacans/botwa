const { Markup } = require('telegraf');
const moment = require('moment-timezone');
const { isOwner, log } = require('../../lib/utils');
const { addUser, getUser, getAllGroups, addBlacklist, removeBlacklist, getBlacklist } = require('../../lib/database');
const { addPremium, removePremium } = require('../../lib/utils');
const fs = require('fs-extra');

module.exports = (bot) => {
    // Owner menu
    bot.action('owner_menu', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            await ctx.answerCbQuery('❌ Hanya owner yang bisa mengakses menu ini!');
            return;
        }

        const totalUsers = Object.keys(fs.readJsonSync(global.USERS_DB)).length;
        const totalGroups = Object.keys(getAllGroups()).length;
        const totalPremium = Object.keys(fs.readJsonSync(global.PREMIUM_DB)).length;

        await ctx.editMessageCaption(
            `👑 *Owner Menu*\n\n` +
            `📊 Statistics:\n` +
            `👥 Total Users: ${totalUsers}\n` +
            `👥 Total Groups: ${totalGroups}\n` +
            `⭐ Total Premium: ${totalPremium}\n\n` +
            `Pilih opsi owner:`,
            {
                parse_mode: 'Markdown',
                ...Markup.inlineKeyboard([
                    [Markup.button.callback('📢 Broadcast', 'owner_broadcast'), Markup.button.callback('⭐ Add Premium', 'owner_addprem')],
                    [Markup.button.callback('🚫 Del Premium', 'owner_delprem'), Markup.button.callback('📋 List Premium', 'owner_listprem')],
                    [Markup.button.callback('⚫ Add Blacklist', 'owner_addbl'), Markup.button.callback('⚪ Del Blacklist', 'owner_delbl')],
                    [Markup.button.callback('📋 List Blacklist', 'owner_listbl'), Markup.button.callback('👥 List Groups', 'owner_listgroups')],
                    [Markup.button.callback('🔙 Kembali', 'main_menu')]
                ])
            }
        );
    });

    // Broadcast handler
    bot.action('owner_broadcast', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            await ctx.answerCbQuery('❌ Akses ditolak!');
            return;
        }

        await ctx.reply(
            '📢 *Broadcast Message*\n\n' +
            'Balas pesan ini dengan teks yang ingin di-broadcast ke semua user.',
            { 
                parse_mode: 'Markdown',
                reply_markup: { force_reply: true }
            }
        );

        // Handle broadcast reply
        bot.on('reply_to_message', async (ctx) => {
            if (ctx.message.reply_to_message.text.includes('Broadcast Message') && isOwner(ctx.from.id)) {
                const message = ctx.message.text;
                const users = fs.readJsonSync(global.USERS_DB);
                const userIds = Object.keys(users);
                
                let success = 0;
                let failed = 0;

                await ctx.reply(`🚀 Memulai broadcast ke ${userIds.length} users...`);

                for (const userId of userIds) {
                    try {
                        await ctx.telegram.sendMessage(userId, `📢 *Broadcast dari Owner:*\n\n${message}`, { 
                            parse_mode: 'Markdown' 
                        });
                        success++;
                        // Delay to avoid rate limiting
                        await new Promise(resolve => setTimeout(resolve, 100));
                    } catch (error) {
                        failed++;
                        log(`Gagal mengirim broadcast ke ${userId}: ${error.message}`);
                    }
                }

                await ctx.reply(
                    `✅ *Broadcast Selesai!*\n\n` +
                    `✅ Berhasil: ${success} users\n` +
                    `❌ Gagal: ${failed} users`,
                    { parse_mode: 'Markdown' }
                );
            }
        });
    });

    // Add Premium handler
    bot.action('owner_addprem', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            await ctx.answerCbQuery('❌ Akses ditolak!');
            return;
        }

        await ctx.reply(
            '⭐ *Add Premium*\n\n' +
            'Format: /addprem <user_id> <hari>\n' +
            'Contoh: /addprem 123456789 30',
            { parse_mode: 'Markdown' }
        );
    });

    // Add Premium command
    bot.command('addprem', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.reply('❌ Hanya owner yang bisa menggunakan command ini!');
        }

        const args = ctx.message.text.split(' ');
        if (args.length < 3) {
            return ctx.reply(
                '❌ Format salah!\n' +
                'Gunakan: /addprem <user_id> <hari>\n' +
                'Contoh: /addprem 123456789 30'
            );
        }

        const userId = args[1];
        const days = parseInt(args[2]);

        if (isNaN(days) || days < 1) {
            return ctx.reply('❌ Jumlah hari harus angka positif!');
        }

        try {
            const expiry = addPremium(userId, days);
            const user = getUser(userId);

            await ctx.reply(
                `✅ *Premium Berhasil Ditambahkan!*\n\n` +
                `👤 User: ${user?.first_name || 'Unknown'}\n` +
                `🆔 ID: ${userId}\n` +
                `⭐ Durasi: ${days} hari\n` +
                `⏰ Berakhir: ${moment(expiry).tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss')}`,
                { parse_mode: 'Markdown' }
            );

            // Notify user
            try {
                await ctx.telegram.sendMessage(
                    userId,
                    `🎉 *Selamat! Anda mendapat premium!*\n\n` +
                    `⭐ Status: Premium Aktif\n` +
                    `⏰ Durasi: ${days} hari\n` +
                    `📅 Berakhir: ${moment(expiry).tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss')}\n\n` +
                    `Nikmati fitur premium sekarang!`,
                    { parse_mode: 'Markdown' }
                );
            } catch (error) {
                log(`Gagal mengirim notifikasi ke user ${userId}: ${error.message}`);
            }
        } catch (error) {
            await ctx.reply(`❌ Gagal menambah premium: ${error.message}`);
        }
    });

    // Remove Premium command
    bot.command('delprem', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.reply('❌ Hanya owner yang bisa menggunakan command ini!');
        }

        const args = ctx.message.text.split(' ');
        if (args.length < 2) {
            return ctx.reply(
                '❌ Format salah!\n' +
                'Gunakan: /delprem <user_id>\n' +
                'Contoh: /delprem 123456789'
            );
        }

        const userId = args[1];
        const user = getUser(userId);

        removePremium(userId);

        await ctx.reply(
            `✅ *Premium Berhasil Dihapus!*\n\n` +
            `👤 User: ${user?.first_name || 'Unknown'}\n` +
            `🆔 ID: ${userId}\n` +
            `⏰ Dihapus pada: ${moment().tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss')}`,
            { parse_mode: 'Markdown' }
        );
    });

    // List Premium command
    bot.command('listprem', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.reply('❌ Hanya owner yang bisa menggunakan command ini!');
        }

        const premiumData = fs.readJsonSync(global.PREMIUM_DB);
        const premiumUsers = Object.entries(premiumData);

        if (premiumUsers.length === 0) {
            return ctx.reply('📭 Tidak ada user premium saat ini.');
        }

        let message = `⭐ *Daftar User Premium (${premiumUsers.length} users)*\n\n`;
        
        premiumUsers.forEach(([userId, data], index) => {
            const user = getUser(userId);
            const remaining = Math.ceil((data.expiry - Date.now()) / (24 * 60 * 60 * 1000));
            message += `${index + 1}. ${user?.first_name || 'Unknown'} (${userId})\n` +
                      `   ⏰ Sisa: ${remaining} hari\n` +
                      `   📅 Berakhir: ${moment(data.expiry).tz('Asia/Jakarta').format('DD/MM/YY HH:mm')}\n\n`;
        });

        // Split message if too long
        if (message.length > 4000) {
            const parts = message.match(/[\s\S]{1,4000}/g);
            for (const part of parts) {
                await ctx.reply(part, { parse_mode: 'Markdown' });
            }
        } else {
            await ctx.reply(message, { parse_mode: 'Markdown' });
        }
    });

    // Add Blacklist command
    bot.command('addbl', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.reply('❌ Hanya owner yang bisa menggunakan command ini!');
        }

        const args = ctx.message.text.split(' ').slice(1);
        if (args.length < 1) {
            return ctx.reply(
                '❌ Format salah!\n' +
                'Gunakan: /addbl <user_id> [alasan]\n' +
                'Contoh: /addbl 123456789 Melanggar rules'
            );
        }

        const userId = args[0];
        const reason = args.slice(1).join(' ') || 'No reason provided';

        addBlacklist(userId, reason);
        const user = getUser(userId);

        await ctx.reply(
            `✅ *User Berhasil Di-blacklist!*\n\n` +
            `👤 User: ${user?.first_name || 'Unknown'}\n` +
            `🆔 ID: ${userId}\n` +
            `📝 Alasan: ${reason}\n` +
            `⏰ Waktu: ${moment().tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss')}`,
            { parse_mode: 'Markdown' }
        );
    });

    // Remove Blacklist command
    bot.command('delbl', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.reply('❌ Hanya owner yang bisa menggunakan command ini!');
        }

        const args = ctx.message.text.split(' ');
        if (args.length < 2) {
            return ctx.reply(
                '❌ Format salah!\n' +
                'Gunakan: /delbl <user_id>\n' +
                'Contoh: /delbl 123456789'
            );
        }

        const userId = args[1];
        const user = getUser(userId);

        removeBlacklist(userId);

        await ctx.reply(
            `✅ *User Berhasil Dihapus dari Blacklist!*\n\n` +
            `👤 User: ${user?.first_name || 'Unknown'}\n` +
            `🆔 ID: ${userId}\n` +
            `⏰ Dihapus pada: ${moment().tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss')}`,
            { parse_mode: 'Markdown' }
        );
    });

    // List Blacklist command
    bot.command('listbl', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.reply('❌ Hanya owner yang bisa menggunakan command ini!');
        }

        const blacklist = getBlacklist();
        const blacklistedUsers = Object.entries(blacklist);

        if (blacklistedUsers.length === 0) {
            return ctx.reply('📭 Tidak ada user yang di-blacklist.');
        }

        let message = `⚫ *Daftar Blacklist (${blacklistedUsers.length} users)*\n\n`;
        
        blacklistedUsers.forEach(([userId, data], index) => {
            const user = getUser(userId);
            message += `${index + 1}. ${user?.first_name || 'Unknown'} (${userId})\n` +
                      `   📝 Alasan: ${data.reason}\n` +
                      `   📅 Ditambahkan: ${moment(data.added).tz('Asia/Jakarta').format('DD/MM/YY HH:mm')}\n\n`;
        });

        // Split message if too long
        if (message.length > 4000) {
            const parts = message.match(/[\s\S]{1,4000}/g);
            for (const part of parts) {
                await ctx.reply(part, { parse_mode: 'Markdown' });
            }
        } else {
            await ctx.reply(message, { parse_mode: 'Markdown' });
        }
    });

    // List Groups command
    bot.command('listgroups', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.reply('❌ Hanya owner yang bisa menggunakan command ini!');
        }

        const groups = getAllGroups();
        const groupList = Object.entries(groups);

        if (groupList.length === 0) {
            return ctx.reply('📭 Bot belum ditambahkan ke group manapun.');
        }

        let message = `👥 *Daftar Group (${groupList.length} groups)*\n\n`;
        
        groupList.forEach(([groupId, data], index) => {
            const daysAgo = Math.floor((Date.now() - data.added) / (24 * 60 * 60 * 1000));
            message += `${index + 1}. ${data.title || 'Unknown Group'}\n` +
                      `   🆔 ID: ${groupId}\n` +
                      `   👤 Added by: ${data.added_by}\n` +
                      `   📅 Ditambahkan: ${daysAgo} hari lalu\n\n`;
        });

        // Split message if too long
        if (message.length > 4000) {
            const parts = message.match(/[\s\S]{1,4000}/g);
            for (const part of parts) {
                await ctx.reply(part, { parse_mode: 'Markdown' });
            }
        } else {
            await ctx.reply(message, { parse_mode: 'Markdown' });
        }
    });

    // Clean inactive groups
    bot.command('cleangroups', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.reply('❌ Hanya owner yang bisa menggunakan command ini!');
        }

        const groups = getAllGroups();
        let removedCount = 0;

        for (const [groupId, groupData] of Object.entries(groups)) {
            try {
                // Check if bot is still in group
                const chatMember = await ctx.telegram.getChatMember(groupId, ctx.botInfo.id);
                if (chatMember.status === 'left' || chatMember.status === 'kicked') {
                    removeGroup(groupId);
                    removedCount++;
                    log(`Group dihapus dari database: ${groupData.title} (${groupId})`);
                }
            } catch (error) {
                // If error, assume bot is not in group anymore
                removeGroup(groupId);
                removedCount++;
                log(`Group dihapus dari database (error): ${groupData.title} (${groupId})`);
            }
        }

        await ctx.reply(
            `🧹 *Pembersihan Group Selesai!*\n\n` +
            `📊 Group aktif: ${Object.keys(getAllGroups()).length}\n` +
            `🗑️ Group dihapus: ${removedCount}`,
            { parse_mode: 'Markdown' }
        );
    });
};

// Handle callback functions
module.exports.handleOwnerMenu = async (ctx) => {
    if (!isOwner(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Hanya owner yang bisa mengakses menu ini!');
        return;
    }

    const totalUsers = Object.keys(fs.readJsonSync(global.USERS_DB)).length;
    const totalGroups = Object.keys(getAllGroups()).length;
    const totalPremium = Object.keys(fs.readJsonSync(global.PREMIUM_DB)).length;

    await ctx.editMessageCaption(
        `👑 *Owner Menu*\n\n` +
        `📊 Statistics:\n` +
        `👥 Total Users: ${totalUsers}\n` +
        `👥 Total Groups: ${totalGroups}\n` +
        `⭐ Total Premium: ${totalPremium}\n\n` +
        `Pilih opsi owner:`,
        {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
                [Markup.button.callback('📢 Broadcast', 'owner_broadcast'), Markup.button.callback('⭐ Add Premium', 'owner_addprem')],
                [Markup.button.callback('🚫 Del Premium', 'owner_delprem'), Markup.button.callback('📋 List Premium', 'owner_listprem')],
                [Markup.button.callback('⚫ Add Blacklist', 'owner_addbl'), Markup.button.callback('⚪ Del Blacklist', 'owner_delbl')],
                [Markup.button.callback('📋 List Blacklist', 'owner_listbl'), Markup.button.callback('👥 List Groups', 'owner_listgroups')],
                [Markup.button.callback('🔙 Kembali', 'main_menu')]
            ])
        }
    );
};

module.exports.handleOwnerCallback = async (ctx, callbackData) => {
    if (!isOwner(ctx.from.id)) {
        await ctx.answerCbQuery('❌ Akses ditolak!');
        return;
    }

    switch (callbackData) {
        case 'owner_broadcast':
            await ctx.reply(
                '📢 *Broadcast Message*\n\n' +
                'Balas pesan ini dengan teks yang ingin di-broadcast ke semua user.',
                { 
                    parse_mode: 'Markdown',
                    reply_markup: { force_reply: true }
                }
            );
            break;
        case 'owner_addprem':
            await ctx.reply(
                '⭐ *Add Premium*\n\n' +
                'Format: /addprem <user_id> <hari>\n' +
                'Contoh: /addprem 123456789 30',
                { parse_mode: 'Markdown' }
            );
            break;
        // ... tambahkan case lainnya sesuai kebutuhan
    }
};