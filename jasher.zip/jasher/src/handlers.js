const { getUser, addUser, updateUserCredits, addGroup } = require('../lib/database');
const { mainKeyboard, shareOptionsKeyboard, joinGroupKeyboard } = require('./keyboards');

const handleStart = async (ctx) => {
    const userId = ctx.from.id;
    const username = ctx.from.username || '';
    
    // Add user to database if not exists
    await addUser(userId, username);
    const user = await getUser(userId);
    
    let message = `Halo ${ctx.from.first_name}! Selamat datang di Bot Jasher.\n\n`;
    message += `Kredit Anda: ${user.credits}\n`;
    message += `Untuk mendapatkan 10 kredit gratis, tambahkan bot ke group Anda terlebih dahulu.`;
    
    await ctx.reply(message, mainKeyboard);
};

const handleShare = async (ctx) => {
    // Cek jika di private chat
    if (ctx.chat.type !== 'private') {
        await ctx.reply('Command /share hanya bisa digunakan di private chat.');
        return;
    }
    
    const user = await getUser(ctx.from.id);
    if (!user || user.credits < 1) {
        await ctx.reply('Kredit Anda tidak cukup untuk melakukan share. Tambahkan bot ke group untuk mendapatkan kredit gratis.');
        return;
    }
    
    await ctx.reply('Pilih opsi share:', shareOptionsKeyboard);
};

const handleAddGroup = async (ctx) => {
    if (ctx.chat.type !== 'private') {
        await ctx.reply('Command /addgroup hanya bisa digunakan di private chat.');
        return;
    }
    
    await ctx.reply(
        'Untuk menambahkan bot ke group Anda dan mendapatkan 10 kredit gratis, klik tombol di bawah:',
        joinGroupKeyboard
    );
};

const handleJoinGroup = async (ctx) => {
    await ctx.editMessageText(
        'Silakan tambahkan bot ke group Anda, lalu kirim command /addgroup di group tersebut untuk verifikasi.'
    );
};

module.exports = {
    handleStart,
    handleShare,
    handleAddGroup,
    handleJoinGroup
};