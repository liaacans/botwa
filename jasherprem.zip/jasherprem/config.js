global.BOT_TOKEN = "8198305874:AAH1Sfr54fyWkPSdfuLQTK_5hSyW69V2C7o";
global.MONGO_URL = "mongodb://mybot_todaytime:94a632154d44683eb18a23ee50f3a31a69e621f8@2kred.h.filess.io:61004/mybot_todaytime";
global.OWNER_ID = "8135269613";
global.PREMIUM_PRICE = 50000; // Harga premium dalam Rupiah
global.PREMIUM_DAYS = 30; // Durasi premium dalam hari
global.FREE_PREMIUM_DAYS = 3; // Durasi premium gratis dalam hari
global.REQUIRED_GROUPS = 3; // Jumlah grup yang harus ditambahkan untuk premium gratis

// Konfigurasi YAB-Group Payment
global.YAB_API_KEY = "tarjUb8mYusE5pdbHN8unB6snWA7CdSu";
global.YAB_SECRET_KEY = "zElY27dFNFOPKbd2jO0o8xglJ5PfMVQqnI55VPrXghPKCyitciWP";
global.YAB_API_URL = "https://yab-group.com/api/live/create";

// Konfigurasi Uguu.se API
global.UGUU_API_URL = "https://uguu.se/upload.php";

module.exports = {
  BOT_TOKEN: global.BOT_TOKEN,
  MONGO_URL: global.MONGO_URL,
  OWNER_ID: global.OWNER_ID
};