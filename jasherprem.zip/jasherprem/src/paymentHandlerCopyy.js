const { Payment, User } = require('../lib/database');
const { log } = require('../lib/utils');
const fetch = require('node-fetch');
const crypto = require('crypto');
const { Markup } = require('telegraf');

// Fungsi untuk validasi nomor telepon
function validatePhone(phone) {
  if (!phone) return false;
  
  // Hapus semua karakter non-digit
  phone = phone.replace(/[^0-9]/g, '');
  
  // Cek panjang nomor (min 10 digit, max 15 digit)
  if (phone.length < 10 || phone.length > 15) {
    return false;
  }
  
  return phone;
}

// Fungsi untuk validasi email
function validateEmail(email) {
  if (!email) return false;
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

// Fungsi untuk membuat signature pembayaran
function createSignature(refKode, apiKey, amount, secretKey) {
  return crypto
    .createHmac('sha256', secretKey)
    .update(refKode + apiKey + amount)
    .digest('hex');
}

// Fungsi untuk membuat pembayaran
async function createPayment(userData, productType, paymentMethod, amount = null) {
  try {
    const url = global.PAYMENT_URL;
    const apikey = global.PAYMENT_API_KEY;
    const secret_key = global.PAYMENT_SECRET_KEY;
    const method = paymentMethod.toUpperCase();
    
    // Tentukan produk dan amount berdasarkan jenis produk
    let product, nominal;
    if (productType === 'premium') {
      product = 'Jasher Bot Premium Access';
      nominal = amount || 50000; // Default 50k untuk premium
    } else if (productType === 'script') {
      product = 'Jasher Premium Script';
      nominal = amount || 100000; // Default 100k untuk script
    } else {
      product = productType;
      nominal = amount || 50000;
    }
    
    const ref_kode = `JASHER_${productType.toUpperCase()}_${userData.userId}_${Date.now()}`;
    
    // Siapkan data untuk API
    const postdata = {
      'api_key': apikey,
      'secret_key': secret_key,
      'channel_payment': method,
      'ref_kode': ref_kode,
      'nominal': nominal,
      'cus_nama': userData.firstName + (userData.lastName ? ' ' + userData.lastName : ''),
      'cus_email': userData.email || `${userData.userId}@jasher.user`,
      'cus_phone': userData.phone || '081234567890',
      'produk': product,
      'url_redirect': `https://t.me/jasherbot`,
      'url_callback': `https://your-domain.com/jasher/payment/callback`, // Ganti dengan domain Anda
      'expired_time': Math.floor(Date.now() / 1000) + (24 * 60 * 60), // 24 jam
      'signature': createSignature(ref_kode, apikey, nominal, secret_key)
    };
    
    log(`Creating payment for user ${userData.userId}: ${JSON.stringify(postdata)}`);
    
    // Panggil API YAB-Group
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: new URLSearchParams(postdata).toString()
    });
    
    const responseData = await response.json();
    log(`Payment API response: ${JSON.stringify(responseData)}`);
    
    if (responseData.data && responseData.data.status === "success") {
      // Simpan data pembayaran
      const payment = new Payment({
        userId: userData.userId,
        amount: nominal,
        product: product,
        productType: productType,
        paymentMethod: paymentMethod,
        status: 'pending',
        referenceId: responseData.data.id_reference,
        checkoutUrl: responseData.data.checkout_url,
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 jam
      });
      
      await payment.save();
      
      return {
        success: true,
        checkoutUrl: responseData.data.checkout_url,
        referenceId: responseData.data.id_reference,
        amount: nominal,
        product: product
      };
    } else {
      const errorMsg = responseData.message || (responseData.data && responseData.data.message) || 'Gagal memproses pembayaran';
      log(`Payment failed: ${errorMsg}`);
      throw new Error(errorMsg);
    }
  } catch (error) {
    log('Error creating payment: ' + error.message);
    throw error;
  }
}

// Handler untuk callback pembayaran (endpoint webhook)
async function handlePaymentCallback(data) {
  try {
    log(`Payment callback received: ${JSON.stringify(data)}`);
    
    // Verifikasi signature
    const expectedSignature = createSignature(
      data.reference_id, 
      global.PAYMENT_API_KEY, 
      data.amount, 
      global.PAYMENT_SECRET_KEY
    );
    
    if (expectedSignature !== data.signature) {
      log(`Invalid payment callback signature. Expected: ${expectedSignature}, Received: ${data.signature}`);
      return { success: false, message: 'Invalid signature' };
    }
    
    // Cari data pembayaran
    const payment = await Payment.findOne({ referenceId: data.reference_id });
    if (!payment) {
      log('Payment not found: ' + data.reference_id);
      return { success: false, message: 'Payment not found' };
    }
    
    // Update status pembayaran
    payment.status = data.status === 'success' ? 'success' : 'failed';
    payment.updatedAt = new Date();
    await payment.save();
    
    if (data.status === 'success') {
      // Berikan akses premium atau kirim script
      const user = await User.findOne({ userId: payment.userId });
      
      if (!user) {
        log('User not found for payment: ' + payment.userId);
        return { success: false, message: 'User not found' };
      }
      
      if (payment.productType === 'premium') {
        // Tambahkan premium
        const premiumDays = Math.floor(payment.amount / 50000); // 50k untuk 30 hari
        const premiumUntil = new Date();
        premiumUntil.setDate(premiumUntil.getDate() + (premiumDays > 0 ? premiumDays * 30 : 30));
        
        user.isPremium = true;
        user.premiumUntil = premiumUntil;
        await user.save();
        
        log(`Premium activated for user ${user.userId} until ${premiumUntil}`);
        
        // Kirim notifikasi ke user
        try {
          await bot.telegram.sendMessage(
            user.userId,
            `🎉 *Pembayaran Premium Berhasil!*\n\n` +
            `Anda sekarang memiliki akses premium selama ${premiumDays > 0 ? premiumDays * 30 : 30} hari.\n` +
            `Akses premium berlaku hingga: ${premiumUntil.toLocaleDateString('id-ID')}\n\n` +
            `Nikmati fitur-fitur eksklusif premium!`,
            { parse_mode: 'Markdown' }
          );
        } catch (error) {
          log(`Failed to send notification to user ${user.userId}: ${error.message}`);
        }
        
      } else if (payment.productType === 'script') {
        // Kirim script premium
        const scriptContent = generatePremiumScript(user, payment);
        
        try {
          // Simpan script sementara
          const tempFilePath = `./temp/script_${user.userId}_${Date.now()}.js`;
          require('fs').writeFileSync(tempFilePath, scriptContent);
          
          // Kirim file script
          await bot.telegram.sendDocument(
            user.userId,
            { source: tempFilePath, filename: `Jasher_Premium_Script_${user.userId}.js` },
            {
              caption: `📦 *Script Premium Anda*\n\n` +
                      `Berikut adalah script premium yang Anda beli.\n` +
                      `Jangan bagikan script ini kepada siapapun!\n\n` +
                      `Terima kasih telah membeli di Jasher Bot.`,
              parse_mode: 'Markdown'
            }
          );
          
          // Hapus file sementara
          require('fs').unlinkSync(tempFilePath);
          
          log(`Script sent to user ${user.userId}`);
        } catch (error) {
          log(`Failed to send script to user ${user.userId}: ${error.message}`);
          
          // Jika gagal kirim file, kirim sebagai text (potongan saja)
          await bot.telegram.sendMessage(
            user.userId,
            `📦 *Script Premium Anda*\n\n` +
            `Kami mengalami kendala mengirim file. Silahkan hubungi admin untuk mendapatkan script Anda.\n\n` +
            `Reference ID: ${payment.referenceId}`,
            { parse_mode: 'Markdown' }
          );
        }
      }
      
      // Kirim notifikasi ke owner
      try {
        await bot.telegram.sendMessage(
          global.OWNER_ID,
          `💰 *Pembayaran Berhasil*\n\n` +
          `User: ${user.firstName}${user.lastName ? ' ' + user.lastName : ''} (@${user.username || 'N/A'})\n` +
          `Produk: ${payment.product}\n` +
          `Amount: Rp ${payment.amount.toLocaleString('id-ID')}\n` +
          `Reference: ${payment.referenceId}`,
          { parse_mode: 'Markdown' }
        );
      } catch (error) {
        log(`Failed to send notification to owner: ${error.message}`);
      }
    } else {
      // Pembayaran gagal
      const user = await User.findOne({ userId: payment.userId });
      if (user) {
        try {
          await bot.telegram.sendMessage(
            user.userId,
            `❌ *Pembayaran Gagal*\n\n` +
            `Pembayaran Anda untuk ${payment.product} gagal diproses.\n` +
            `Silahkan coba lagi atau hubungi admin untuk bantuan.`,
            { parse_mode: 'Markdown' }
          );
        } catch (error) {
          log(`Failed to send failure notification to user ${user.userId}: ${error.message}`);
        }
      }
    }
    
    return { success: true };
  } catch (error) {
    log('Error handling payment callback: ' + error.message);
    return { success: false, message: error.message };
  }
}

// Fungsi untuk generate script premium
function generatePremiumScript(user, payment) {
  const creationDate = new Date().toISOString();
  const expiryDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(); // 30 hari
  
  return `
/**
 * Jasher Premium Script
 * User: ${user.firstName}${user.lastName ? ' ' + user.lastName : ''}
 * User ID: ${user.userId}
 * Product: ${payment.product}
 * Reference: ${payment.referenceId}
 * Created: ${creationDate}
 * Expires: ${expiryDate}
 */

const crypto = require('crypto');

class JasherPremium {
  constructor() {
    this.userId = ${user.userId};
    this.referenceId = "${payment.referenceId}";
    this.createdAt = "${creationDate}";
    this.expiresAt = "${expiryDate}";
    this.isValid = this.validateLicense();
  }
  
  validateLicense() {
    const now = new Date();
    const expiry = new Date(this.expiresAt);
    return now < expiry;
  }
  
  getInfo() {
    return {
      userId: this.userId,
      referenceId: this.referenceId,
      isValid: this.isValid,
      createdAt: this.createdAt,
      expiresAt: this.expiresAt,
      daysRemaining: Math.ceil((new Date(this.expiresAt) - new Date()) / (1000 * 60 * 60 * 24))
    };
  }
  
  // Contoh fitur premium
  premiumFeature() {
    if (!this.isValid) {
      throw new Error('License has expired. Please renew your premium subscription.');
    }
    
    return "This is a premium feature accessible only with valid license.";
  }
}

// Export class
module.exports = JasherPremium;

// Auto-execute jika dijalankan langsung
if (require.main === module) {
  const premium = new JasherPremium();
  console.log('Jasher Premium Script');
  console.log('=====================');
  console.log('User ID:', premium.userId);
  console.log('Reference:', premium.referenceId);
  console.log('Valid:', premium.isValid);
  console.log('Created:', premium.createdAt);
  console.log('Expires:', premium.expiresAt);
  
  if (premium.isValid) {
    console.log('Premium feature:', premium.premiumFeature());
  } else {
    console.log('License has expired. Please renew your subscription.');
  }
}
`;
}

// Handler untuk command buyprem
async function handleBuyPremium(ctx) {
  try {
    const user = ctx.userData;
    
    // Keyboard untuk metode pembayaran
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('💰 QRIS (Instant)', 'pay_premium_qris')],
      [Markup.button.callback('🏦 Bank Transfer', 'pay_premium_bank')],
      [Markup.button.callback('🔙 Kembali', 'main_menu')]
    ]);
    
    await ctx.replyWithMarkdown(
      `🎖️ *Beli Premium Access*\n\n` +
      `Dengan premium, Anda dapat:\n` +
      `• Menggunakan semua fitur obfuscation\n` +
      `• Share tanpa batas ke semua grup\n` +
      `• Prioritas support dan bantuan\n` +
      `• Akses fitur-fitur eksklusif\n\n` +
      `*Harga:* Rp 50.000 / 30 hari\n\n` +
      `Pilih metode pembayaran di bawah ini:`,
      keyboard
    );
  } catch (error) {
    log('Error in handleBuyPremium: ' + error.message);
    await ctx.reply('❌ Terjadi kesalahan saat memproses permintaan pembelian premium.');
  }
}

// Handler untuk command buysc
async function handleBuyScript(ctx) {
  try {
    const user = ctx.userData;
    
    // Keyboard untuk metode pembayaran
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('💰 QRIS (Instant)', 'pay_script_qris')],
      [Markup.button.callback('🏦 Bank Transfer', 'pay_script_bank')],
      [Markup.button.callback('🔙 Kembali', 'main_menu')]
    ]);
    
    await ctx.replyWithMarkdown(
      `🛒 *Beli Premium Script*\n\n` +
      `Script premium termasuk:\n` +
      `• Script JavaScript terobfuscation premium\n` +
      `• License valid 30 hari\n` +
      `• Update dan support\n` +
      `• Dokumentasi lengkap\n\n` +
      `*Harga:* Rp 100.000 / script\n\n` +
      `Pilih metode pembayaran di bawah ini:`,
      keyboard
    );
  } catch (error) {
    log('Error in handleBuyScript: ' + error.message);
    await ctx.reply('❌ Terjadi kesalahan saat memproses permintaan pembelian script.');
  }
}

// Handler untuk callback pembayaran QRIS premium
async function handlePayPremiumQris(ctx) {
  try {
    await ctx.answerCbQuery();
    const user = ctx.userData;
    
    // Buat pembayaran
    const paymentResult = await createPayment(user, 'premium', 'qris');
    
    if (paymentResult.success) {
      const keyboard = Markup.inlineKeyboard([
        [Markup.button.url('💳 Bayar Sekarang', paymentResult.checkoutUrl)],
        [Markup.button.callback('✅ Sudah Bayar', 'check_payment_' + paymentResult.referenceId)],
        [Markup.button.callback('🔙 Kembali', 'buy_premium')]
      ]);
      
      await ctx.editMessageText(
        `💳 *Pembayaran Premium via QRIS*\n\n` +
        `*Produk:* ${paymentResult.product}\n` +
        `*Amount:* Rp ${paymentResult.amount.toLocaleString('id-ID')}\n` +
        `*Reference:* ${paymentResult.referenceId}\n\n` +
        `Silahkan klik tombol di bawah untuk melakukan pembayaran:\n` +
        `• Pembayaran akan expired dalam 24 jam\n` +
        `• Setelah bayar, klik "Sudah Bayar" untuk verifikasi\n` +
        `• Script akan dikirim otomatis setelah pembayaran sukses`,
        {
          parse_mode: 'Markdown',
          ...keyboard
        }
      );
    } else {
      await ctx.editMessageText(
        '❌ Gagal membuat pembayaran. Silahkan coba lagi atau hubungi admin.',
        { reply_markup: { inline_keyboard: [[Markup.button.callback('🔙 Kembali', 'buy_premium')]] } }
      );
    }
  } catch (error) {
    log('Error in handlePayPremiumQris: ' + error.message);
    await ctx.answerCbQuery('❌ Terjadi kesalahan saat memproses pembayaran');
  }
}

// Handler untuk callback pembayaran QRIS script
async function handlePayScriptQris(ctx) {
  try {
    await ctx.answerCbQuery();
    const user = ctx.userData;
    
    // Buat pembayaran
    const paymentResult = await createPayment(user, 'script', 'qris');
    
    if (paymentResult.success) {
      const keyboard = Markup.inlineKeyboard([
        [Markup.button.url('💳 Bayar Sekarang', paymentResult.checkoutUrl)],
        [Markup.button.callback('✅ Sudah Bayar', 'check_payment_' + paymentResult.referenceId)],
        [Markup.button.callback('🔙 Kembali', 'buy_script')]
      ]);
      
      await ctx.editMessageText(
        `💳 *Pembayaran Script via QRIS*\n\n` +
        `*Produk:* ${paymentResult.product}\n` +
        `*Amount:* Rp ${paymentResult.amount.toLocaleString('id-ID')}\n` +
        `*Reference:* ${paymentResult.referenceId}\n\n` +
        `Silahkan klik tombol di bawah untuk melakukan pembayaran:\n` +
        `• Pembayaran akan expired dalam 24 jam\n` +
        `• Setelah bayar, klik "Sudah Bayar" untuk verifikasi\n` +
        `• Script akan dikirim otomatis setelah pembayaran sukses`,
        {
          parse_mode: 'Markdown',
          ...keyboard
        }
      );
    } else {
      await ctx.editMessageText(
        '❌ Gagal membuat pembayaran. Silahkan coba lagi atau hubungi admin.',
        { reply_markup: { inline_keyboard: [[Markup.button.callback('🔙 Kembali', 'buy_script')]] } }
      );
    }
  } catch (error) {
    log('Error in handlePayScriptQris: ' + error.message);
    await ctx.answerCbQuery('❌ Terjadi kesalahan saat memproses pembayaran');
  }
}

// Handler untuk cek status pembayaran
async function handleCheckPayment(ctx, referenceId) {
  try {
    await ctx.answerCbQuery();
    
    const payment = await Payment.findOne({ referenceId });
    if (!payment) {
      await ctx.editMessageText(
        '❌ Data pembayaran tidak ditemukan.',
        { reply_markup: { inline_keyboard: [[Markup.button.callback('🔙 Kembali', 'main_menu')]] } }
      );
      return;
    }
    
    if (payment.status === 'success') {
      await ctx.editMessageText(
        `✅ *Pembayaran Berhasil!*\n\n` +
        `Pembayaran Anda telah berhasil diproses.\n` +
        `*Produk:* ${payment.product}\n` +
        `*Amount:* Rp ${payment.amount.toLocaleString('id-ID')}\n` +
        `*Status:* Sukses\n\n` +
        `Terima kasih telah berbelanja di Jasher Bot!`,
        {
          parse_mode: 'Markdown',
          reply_markup: { inline_keyboard: [[Markup.button.callback('🔙 Ke Menu Utama', 'main_menu')]] }
        }
      );
    } else if (payment.status === 'pending') {
      await ctx.editMessageText(
        `⏳ *Menunggu Pembayaran*\n\n` +
        `Pembayaran Anda masih dalam proses.\n` +
        `*Reference:* ${payment.referenceId}\n` +
        `*Amount:* Rp ${payment.amount.toLocaleString('id-ID')}\n` +
        `*Status:* Pending\n\n` +
        `Silahkan selesaikan pembayaran Anda atau tunggu beberapa saat.`,
        {
          parse_mode: 'Markdown',
          reply_markup: { 
            inline_keyboard: [
              [Markup.button.url('💳 Bayar Sekarang', payment.checkoutUrl)],
              [Markup.button.callback('🔄 Cek Status', 'check_payment_' + referenceId)],
              [Markup.button.callback('🔙 Kembali', 'main_menu')]
            ]
          }
        }
      );
    } else {
      await ctx.editMessageText(
        `❌ *Pembayaran Gagal*\n\n` +
        `Pembayaran Anda gagal diproses.\n` +
        `*Reference:* ${payment.referenceId}\n` +
        `*Status:* Failed\n\n` +
        `Silahkan coba lagi atau hubungi admin untuk bantuan.`,
        {
          parse_mode: 'Markdown',
          reply_markup: { inline_keyboard: [[Markup.button.callback('🔙 Kembali', 'main_menu')]] }
        }
      );
    }
  } catch (error) {
    log('Error in handleCheckPayment: ' + error.message);
    await ctx.answerCbQuery('❌ Terjadi kesalahan saat memeriksa pembayaran');
  }
}

// Fungsi untuk mengecek pembayaran yang expired
async function checkExpiredPayments() {
  try {
    const expiredPayments = await Payment.find({
      status: 'pending',
      expiresAt: { $lt: new Date() }
    });
    
    for (const payment of expiredPayments) {
      payment.status = 'expired';
      await payment.save();
      
      log(`Payment expired: ${payment.referenceId}`);
      
      // Kirim notifikasi ke user
      const user = await User.findOne({ userId: payment.userId });
      if (user) {
        try {
          await bot.telegram.sendMessage(
            user.userId,
            `⏰ *Pembayaran Expired*\n\n` +
            `Pembayaran Anda untuk ${payment.product} telah expired.\n` +
            `*Reference:* ${payment.referenceId}\n` +
            `*Amount:* Rp ${payment.amount.toLocaleString('id-ID')}\n\n` +
            `Silahkan buat pembayaran baru jika masih ingin membeli.`,
            { parse_mode: 'Markdown' }
          );
        } catch (error) {
          log(`Failed to send expiration notification to user ${user.userId}: ${error.message}`);
        }
      }
    }
  } catch (error) {
    log('Error checking expired payments: ' + error.message);
  }
}

// Setup bot reference (akan di-set dari main.js)
let bot = null;
function setBotInstance(botInstance) {
  bot = botInstance;
}

// Jadwal pengecekan pembayaran expired setiap jam
setInterval(checkExpiredPayments, 60 * 60 * 1000);

module.exports = {
  validatePhone,
  validateEmail,
  createPayment,
  handlePaymentCallback,
  handleBuyPremium,
  handleBuyScript,
  handlePayPremiumQris,
  handlePayScriptQris,
  handleCheckPayment,
  checkExpiredPayments,
  setBotInstance
};