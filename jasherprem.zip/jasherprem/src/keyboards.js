const { Markup } = require('telegraf');

function mainMenu() {
    return Markup.inlineKeyboard([
        [
            Markup.button.callback('🎯 Jasher Menu', 'jasher_menu'),
            Markup.button.callback('👤 Owner Menu', 'owner_menu')
        ],
        [
            Markup.button.url('➕ Add Group', 'https://t.me/your_bot_username?startgroup=true'),
            Markup.button.callback('🔙 Kembali', 'main_menu')
        ],
        [
            Markup.button.callback('👨‍💻 Owner', 'contact_owner')
        ]
    ]);
}

function jasherMenu() {
    return Markup.inlineKeyboard([
        [
            Markup.button.callback('📤 Share', 'share_menu'),
            Markup.button.callback('💎 Credit', 'credit_info')
        ],
        [
            Markup.button.callback('📊 Stats', 'user_stats'),
            Markup.button.callback('👥 Add Group', 'add_group_info')
        ],
        [
            Markup.button.callback('🔙 Kembali', 'main_menu')
        ]
    ]);
}

function ownerMenu() {
    return Markup.inlineKeyboard([
        [
            Markup.button.callback('📢 Broadcast', 'broadcast_menu'),
            Markup.button.callback('⭐ Add Premium', 'add_premium')
        ],
        [
            Markup.button.callback('🗑️ Remove Premium', 'remove_premium'),
            Markup.button.callback('📋 List Premium', 'list_premium')
        ],
        [
            Markup.button.callback('🔙 Kembali', 'main_menu')
        ]
    ]);
}

function shareMenu() {
    return Markup.inlineKeyboard([
        [
            Markup.button.callback('📤 Share Regular', 'share_regular'),
            Markup.button.callback('🚀 Share VIP', 'share_vip')
        ],
        [
            Markup.button.callback('🔙 Kembali', 'jasher_menu')
        ]
    ]);
}

function backToMain() {
    return Markup.inlineKeyboard([
        [Markup.button.callback('🔙 Kembali', 'main_menu')]
    ]);
}

module.exports = {
    mainMenu,
    jasherMenu,
    ownerMenu,
    shareMenu,
    backToMain
};