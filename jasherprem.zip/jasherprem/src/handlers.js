const db = require('../lib/database');

async function handleNewChatMember(ctx) {
  try {
    const chat = ctx.chat;
    const newMembers = ctx.update.message.new_chat_members;
    
    // Cek jika bot yang ditambahkan ke group
    const botId = ctx.botInfo.id;
    const isBotAdded = newMembers.some(member => member.id === botId);
    
    if (isBotAdded && chat.type !== 'private') {
      // Dapatkan informasi group
      const chatMemberCount = await ctx.getChatMembersCount();
      
      // Tambahkan group ke database
      await db.addGroup({
        id: chat.id,
        title: chat.title,
        username: chat.username,
        member_count: chatMemberCount
      });
      
      // Cari user yang menambahkan bot (tidak bisa langsung diketahui, jadi kita asumsikan dari message)
      const addedBy = ctx.update.message.from;
      if (addedBy) {
        // Update user's joined groups count
        await db.updateUserGroups(addedBy.id, 1);
        
        const userData = await db.getUser(addedBy.id);
        
        // Berikan bonus credit jika sudah menambahkan 3 group
        if (userData && userData.joined_groups % 3 === 0) {
          await db.updateUserCredit(addedBy.id, 10);
          await ctx.telegram.sendMessage(
            addedBy.id, 
            `🎉 Terima kasih telah menambahkan bot ke group ke-${userData.joined_groups}! Anda mendapatkan bonus 10 credit.`
          );
        }
      }
      
      console.log(`Bot ditambahkan ke group: ${chat.title} (${chat.id})`);
    }
  } catch (error) {
    console.error('Error handling new chat member:', error);
  }
}

module.exports = {
  handleNewChatMember
};