const { User, Group, Broadcast } = require('../lib/database');
const keyboards = require('./keyboards');
const { formatUserInfo } = require('../lib/utils');

async function handleCallbackQuery(ctx) {
    const data = ctx.callbackQuery.data;
    const userId = ctx.from.id;
    const user = await User.findOne({ userId });
    
    switch (data) {
        case 'main_menu':
            const userInfo = formatUserInfo(ctx, user);
            await ctx.editMessageCaption(userInfo, {
                parse_mode: 'HTML',
                reply_markup: keyboards.mainMenu().reply_markup
            });
            break;
            
        case 'jasher_menu':
            await ctx.editMessageText('🎯 *Jasher Menu*', {
                parse_mode: 'Markdown',
                reply_markup: keyboards.jasherMenu().reply_markup
            });
            break;
            
        case 'owner_menu':
            // Cek apakah user adalah owner
            if (userId.toString() !== process.env.OWNER_ID) {
                return ctx.answerCbQuery('Akses ditolak. Hanya owner yang dapat mengakses menu ini.');
            }
            
            await ctx.editMessageText('👤 *Owner Menu*', {
                parse_mode: 'Markdown',
                reply_markup: keyboards.ownerMenu().reply_markup
            });
            break;
            
        case 'share_menu':
            await ctx.editMessageText('📤 *Pilih jenis share:*', {
                parse_mode: 'Markdown',
                reply_markup: keyboards.shareMenu().reply_markup
            });
            break;
            
        case 'credit_info':
            await ctx.editMessageText(`💎 *Kredit Anda: ${user.credit}*`, {
                parse_mode: 'Markdown',
                reply_markup: keyboards.jasherMenu().reply_markup
            });
            break;
            
        case 'share_regular':
            await handleShareRegular(ctx, user);
            break;
            
        case 'share_vip':
            await handleShareVip(ctx, user);
            break;
            
        case 'add_premium':
            await handleAddPremium(ctx);
            break;
            
        case 'remove_premium':
            await handleRemovePremium(ctx);
            break;
            
        case 'list_premium':
            await handleListPremium(ctx);
            break;
            
        case 'broadcast_menu':
            await handleBroadcastMenu(ctx);
            break;
            
        case 'contact_owner':
            await ctx.answerCbQuery('Hubungi owner di @username_owner');
            break;
            
        case 'add_group_info':
            await ctx.editMessageText('Untuk menambahkan grup, klik tombol "Add Group" di menu utama atau gunakan link berikut: https://t.me/your_bot_username?startgroup=true', {
                reply_markup: keyboards.jasherMenu().reply_markup
            });
            break;
            
        default:
            await ctx.answerCbQuery('Fitur belum tersedia');
    }
}

async function handleShareRegular(ctx, user) {
    if (user.credit < 2) {
        return ctx.answerCbQuery('Kredit tidak cukup. Anda perlu 2 kredit untuk share reguler.');
    }
    
    try {
        // Kurangi kredit
        user.credit -= 2;
        await user.save();
        
        // Proses share reguler
        const repliedMessage = ctx.callbackQuery.message.reply_to_message;
        if (repliedMessage) {
            // Simpan ke broadcast history
            const broadcast = new Broadcast({
                messageId: repliedMessage.message_id,
                senderId: user.userId,
                messageText: repliedMessage.text || 'Media message'
            });
            await broadcast.save();
            
            // Kirim ke semua grup (implementasi nyata akan mengirim ke grup yang terdaftar)
            ctx.answerCbQuery('Pesan berhasil dibagikan ke grup! (-2 kredit)');
        } else {
            ctx.answerCbQuery('Tidak ada pesan yang di-reply');
        }
    } catch (error) {
        console.error('Error in regular share:', error);
        ctx.answerCbQuery('Terjadi kesalahan saat membagikan pesan');
    }
}

async function handleShareVip(ctx, user) {
    if (user.credit < 5) {
        return ctx.answerCbQuery('Kredit tidak cukup. Anda perlu 5 kredit untuk share VIP.');
    }
    
    try {
        // Kurangi kredit
        user.credit -= 5;
        await user.save();
        
        // Proses share VIP
        const repliedMessage = ctx.callbackQuery.message.reply_to_message;
        if (repliedMessage) {
            // Simpan ke broadcast history
            const broadcast = new Broadcast({
                messageId: repliedMessage.message_id,
                senderId: user.userId,
                messageText: repliedMessage.text || 'Media message'
            });
            await broadcast.save();
            
            // Kirim ke semua grup dengan prioritas tinggi
            ctx.answerCbQuery('Pesan berhasil dibagikan ke grup dengan prioritas VIP! (-5 kredit)');
        } else {
            ctx.answerCbQuery('Tidak ada pesan yang di-reply');
        }
    } catch (error) {
        console.error('Error in VIP share:', error);
        ctx.answerCbQuery('Terjadi kesalahan saat membagikan pesan');
    }
}

async function handleAddPremium(ctx) {
    if (ctx.from.id.toString() !== process.env.OWNER_ID) {
        return ctx.answerCbQuery('Akses ditolak. Hanya owner yang dapat menambahkan premium.');
    }
    
    await ctx.editMessageText('Kirim perintah: /addprem [user_id] untuk menambahkan user premium.', {
        reply_markup: keyboards.ownerMenu().reply_markup
    });
}

async function handleRemovePremium(ctx) {
    if (ctx.from.id.toString() !== process.env.OWNER_ID) {
        return ctx.answerCbQuery('Akses ditolak. Hanya owner yang dapat menghapus premium.');
    }
    
    await ctx.editMessageText('Kirim perintah: /delprem [user_id] untuk menghapus user premium.', {
        reply_markup: keyboards.ownerMenu().reply_markup
    });
}

async function handleListPremium(ctx) {
    if (ctx.from.id.toString() !== process.env.OWNER_ID) {
        return ctx.answerCbQuery('Akses ditolak. Hanya owner yang dapat melihat list premium.');
    }
    
    const premiumUsers = await User.find({ isPremium: true });
    let message = '👑 *Daftar User Premium:*\n\n';
    
    if (premiumUsers.length === 0) {
        message += 'Tidak ada user premium.';
    } else {
        premiumUsers.forEach((user, index) => {
            message += `${index + 1}. ${user.firstName} (ID: ${user.userId}) @${user.username || 'N/A'}\n`;
        });
    }
    
    await ctx.editMessageText(message, {
        parse_mode: 'Markdown',
        reply_markup: keyboards.ownerMenu().reply_markup
    });
}

async function handleBroadcastMenu(ctx) {
    if (ctx.from.id.toString() !== process.env.OWNER_ID) {
        return ctx.answerCbQuery('Akses ditolak. Hanya owner yang dapat melakukan broadcast.');
    }
    
    await ctx.editMessageText('Untuk broadcast, reply pesan yang ingin di-broadcast dan ketik /broadcast', {
        reply_markup: keyboards.ownerMenu().reply_markup
    });
}

module.exports = {
    handleCallbackQuery,
    handleShareRegular,
    handleShareVip
};