//fix by andin official
const fs = require('fs');
const { loadJsonData, saveJsonData } = require('../lib/function');
const settings = require('../settings');

const OWNER_ID = settings.ownerId;
const OWNER_FILE = './db/users/ownerID.json'; // File untuk owner bot
const OWNERP_FILE = './db/users/adminID.json'; // File untuk owner panel
const PREMIUM_FILE = './db/users/premiumUsers.json';
const RESS_FILE = './db/users/resellerUsers.json';
const RESSVPS_FILE = './db/users/resellerVps.json';
const BUYERVPS_FILE = './db/users/buyerVps.json';

// Fungsi untuk load data realtime
function loadDataRealtime(filePath) {
    try {
        if (fs.existsSync(filePath)) {
            const data = fs.readFileSync(filePath, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error(`Error loading ${filePath}:`, error);
    }
    return [];
}

// Fungsi untuk save data realtime
function saveDataRealtime(filePath, data) {
    try {
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
        return true;
    } catch (error) {
        console.error(`Error saving ${filePath}:`, error);
        return false;
    }
}

module.exports = (bot) => {
// command /addprem
bot.onText(/^\/addprem(?:\s+(\d+))?$/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const owners = loadDataRealtime(OWNERP_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ᴘᴀɴᴇʟ');
    }

    let targetUserId;

    if (match[1]) {
        targetUserId = match[1];
    } else if (msg.reply_to_message) {
        targetUserId = msg.reply_to_message.from.id.toString();
    } else {
        return bot.sendMessage(chatId, '❌ Reply ke pesan user!\nContoh:\n/addprem id');
    }

    const premUsers = loadDataRealtime(PREMIUM_FILE);

    if (!premUsers.includes(targetUserId)) {
        premUsers.push(targetUserId);
        if (saveDataRealtime(PREMIUM_FILE, premUsers)) {
            return bot.sendMessage(chatId, `✅ User ID ${targetUserId} berhasil ditambahkan sebagai Premium!`, {
                parse_mode: "Markdown",
                reply_to_message_id: msg.message_id
            });
        } else {
            return bot.sendMessage(chatId, `❌ Gagal menyimpan data Premium!`);
        }
    } else {
       //bot.sendMessage(chatId, `⚠️ User ID ${targetUserId} sudah menjadi Premium!`);
    }
});

// command /address
bot.onText(/^\/address(?:\s+(\d+))?$/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const owners = loadDataRealtime(OWNERP_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ᴘᴀɴᴇʟ');
    }

    let targetUserId;

    if (match[1]) {
        targetUserId = match[1];
    } else if (msg.reply_to_message) {
        targetUserId = msg.reply_to_message.from.id.toString();
    } else {
        return bot.sendMessage(chatId, '❌ Reply ke pesan user!\nContoh:\n/address id');
    }

    const ressUsers = loadDataRealtime(RESS_FILE);

    if (!ressUsers.includes(targetUserId)) {
        ressUsers.push(targetUserId);
        if (saveDataRealtime(RESS_FILE, ressUsers)) {
            return bot.sendMessage(chatId, `✅ User ID ${targetUserId} berhasil ditambahkan sebagai Reseller Panel!`, {
                parse_mode: "Markdown",
                reply_to_message_id: msg.message_id
            });
        } else {
            return bot.sendMessage(chatId, `❌ Gagal menyimpan data Reseller!`);
        }
    } else {
       //bot.sendMessage(chatId, `⚠️ User ID ${targetUserId} sudah menjadi Reseller Panel!`);
    }
});
 
// command /addpublic - REALTIME VERSION
bot.onText(/^\/addpublic(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  
  if (!msg.reply_to_message) {
    return bot.sendMessage(chatId, '❌ Reply ke pesan user!\nContoh: reply pesan lalu ketik /addpublic');
  }

  const targetId = msg.reply_to_message.from.id.toString();

  // Cek akses - gunakan OWNER_FILE (adminID.json) untuk owner bot
  const owners = loadDataRealtime(OWNER_FILE);
  if (msg.from.id !== OWNER_ID && !owners.includes(msg.from.id.toString())) {
    return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
  }

  try {
    // cek apakah target bisa diakses
    const targetUser = await bot.getChat(targetId).catch(() => null);
    if (!targetUser) {
      return bot.sendMessage(chatId, '❌ User tidak ditemukan atau bot belum pernah chat dengan user tersebut.');
    }

    // Load data realtime
    const ownerData = loadDataRealtime(OWNERP_FILE);
    const premiumData = loadDataRealtime(PREMIUM_FILE);
    const resellerData = loadDataRealtime(RESS_FILE);

    const ownerMark = ownerData.includes(targetId) ? "✅" : "❌";
    const premiumMark = premiumData.includes(targetId) ? "✅" : "❌";
    const resellerMark = resellerData.includes(targetId) ? "✅" : "❌";

    const textMsg = `👤 *User Public Panel*\n\n📛 Username: @${targetUser.username || '-'}\n🆔 ID: \`${targetId}\`\n📊 Type: User Public`;

    await bot.sendMessage(chatId, textMsg, {
      parse_mode: "Markdown",
      reply_to_message_id: msg.message_id,
      reply_markup: {
        inline_keyboard: [
          [
            { text: `👑 Owner ${ownerMark}`, callback_data: `toggle_owner:${targetId}` }
          ],
          [
            { text: `⭐ Premium ${premiumMark}`, callback_data: `toggle_premium:${targetId}` },
            { text: `💼 Reseller ${resellerMark}`, callback_data: `toggle_reseller:${targetId}` }
          ]
        ]
      }
    });
  } catch (err) {
    console.error("Error di /addpublic:", err.message);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan.");
  }
});

// command /addpriv - REALTIME VERSION
bot.onText(/^\/addpriv(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  
  if (!msg.reply_to_message) {
   // return bot.sendMessage(chatId, '❌ Reply ke pesan user!\nContoh: reply pesan lalu ketik /addpriv');
  }

  const targetId = msg.reply_to_message.from.id.toString();
    
  // Cek akses - gunakan OWNER_FILE (adminID.json) untuk owner bot
  const owners = loadDataRealtime(OWNER_FILE);
  if (msg.from.id !== OWNER_ID && !owners.includes(msg.from.id.toString())) {
    return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
  }

  try {
    const targetUser = await bot.getChat(targetId);
    
    // Load data realtime
    const ownerPriv = loadDataRealtime("./db/users/private/privateID.json");
    const premiumPriv = loadDataRealtime("./db/users/private/privPrem.json");
    const resellerPriv = loadDataRealtime("./db/users/private/privRess.json");

    const ownerCheck = ownerPriv.includes(targetId) ? "✅" : "❌";
    const premiumCheck = premiumPriv.includes(targetId) ? "✅" : "❌";
    const resellerCheck = resellerPriv.includes(targetId) ? "✅" : "❌";

    const textMsg = `👤 *User Private Panel*\n\n📛 Username: @${targetUser.username || '-'}\n🆔 ID: \`${targetId}\`\n📊 Type: User Private`;

    bot.sendMessage(chatId, textMsg, {
      parse_mode: "Markdown",
      reply_to_message_id: msg.message_id,
      reply_markup: {
        inline_keyboard: [
          [
            { text: `👑 Owner ${ownerCheck}`, callback_data: `private_owner:${targetId}` }
          ],
          [
            { text: `⭐ Premium ${premiumCheck}`, callback_data: `private_premium:${targetId}` },
            { text: `💼 Reseller ${resellerCheck}`, callback_data: `private_reseller:${targetId}` }
          ]
        ]
      }
    });
  } catch (err) {
    console.error("Error di /addpriv:", err.message);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan.");
  }
});

// Single callback query handler untuk semua jenis toggle - REALTIME VERSION
bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;
  const messageId = query.message.message_id;
  const [action, targetId] = query.data.split(":");
  
  console.log("Callback received:", action, targetId);

  // Cek apakah user adalah owner bot (dari adminID.json)
  const owners = loadDataRealtime(OWNER_FILE);
  const ownerIdString = query.from.id.toString();
  
  if (!owners.includes(ownerIdString) && query.from.id !== OWNER_ID) {
    return bot.answerCallbackQuery(query.id, { text: "❌ Akses ditolak!" });
  }

  let filePath, label;
  let isPublic = false;

  // Tentukan file path berdasarkan action
  switch (action) {
    case "toggle_owner":
      filePath = OWNERP_FILE; // ownerID.json untuk public owner
      label = "Owner Public";
      isPublic = true;
      break;
    case "toggle_premium":
      filePath = PREMIUM_FILE;
      label = "Premium Public";
      isPublic = true;
      break;
    case "toggle_reseller":
      filePath = RESS_FILE;
      label = "Reseller Public";
      isPublic = true;
      break;
    case "private_owner":
      filePath = "./db/users/private/privateID.json";
      label = "Owner Private";
      break;
    case "private_premium":
      filePath = "./db/users/private/privPrem.json";
      label = "Premium Private";
      break;
    case "private_reseller":
      filePath = "./db/users/private/privRess.json";
      label = "Reseller Private";
      break;
    default:
      return bot.answerCallbackQuery(query.id, { text: "❌ Action tidak dikenali!" });
  }

  try {
    // Load data realtime dan update
    let jsonData = loadDataRealtime(filePath);
    let updatedMessage;

    if (jsonData.includes(targetId)) {
      // Hapus user dari list
      jsonData = jsonData.filter(id => id !== targetId);
      updatedMessage = `❌ User ID ${targetId} dihapus dari ${label}`;
    } else {
      // Tambah user ke list
      jsonData.push(targetId);
      updatedMessage = `✅ User ID ${targetId} ditambahkan ke ${label}`;
    }

    // Simpan perubahan realtime
    if (!saveDataRealtime(filePath, jsonData)) {
      return bot.answerCallbackQuery(query.id, { text: "❌ Gagal menyimpan perubahan!" });
    }

    // Update tombol dengan status baru (realtime)
    let ownerMark, premiumMark, resellerMark;
    let keyboard;

    if (isPublic) {
      // Untuk public user - load realtime
      const ownerData = loadDataRealtime(OWNERP_FILE);
      const premiumData = loadDataRealtime(PREMIUM_FILE);
      const resellerData = loadDataRealtime(RESS_FILE);

      ownerMark = ownerData.includes(targetId) ? "✅" : "❌";
      premiumMark = premiumData.includes(targetId) ? "✅" : "❌";
      resellerMark = resellerData.includes(targetId) ? "✅" : "❌";

      keyboard = [
        [
          { text: `👑 Owner ${ownerMark}`, callback_data: `toggle_owner:${targetId}` }
        ],
        [
          { text: `⭐ Premium ${premiumMark}`, callback_data: `toggle_premium:${targetId}` },
          { text: `💼 Reseller ${resellerMark}`, callback_data: `toggle_reseller:${targetId}` }
        ]
      ];
    } else {
      // Untuk private user - load realtime
      const ownerPriv = loadDataRealtime("./db/users/private/privateID.json");
      const premiumPriv = loadDataRealtime("./db/users/private/privPrem.json");
      const resellerPriv = loadDataRealtime("./db/users/private/privRess.json");

      ownerMark = ownerPriv.includes(targetId) ? "✅" : "❌";
      premiumMark = premiumPriv.includes(targetId) ? "✅" : "❌";
      resellerMark = resellerPriv.includes(targetId) ? "✅" : "❌";

      keyboard = [
        [
          { text: `👑 Owner ${ownerMark}`, callback_data: `private_owner:${targetId}` }
        ],
        [
          { text: `⭐ Premium ${premiumMark}`, callback_data: `private_premium:${targetId}` },
          { text: `💼 Reseller ${resellerMark}`, callback_data: `private_reseller:${targetId}` }
        ]
      ];
    }

    // Edit reply markup
    await bot.editMessageReplyMarkup(
      { inline_keyboard: keyboard },
      { chat_id: chatId, message_id: messageId }
    );

    // Beri feedback ke user
    bot.answerCallbackQuery(query.id, { text: updatedMessage });

  } catch (err) {
    console.error("Error di callback handler:", err);
    bot.answerCallbackQuery(query.id, { text: "❌ Error saat update user!" });
  }
});

// command /addrvps - REALTIME VERSION
bot.onText(/^\/addrvps(?:\s+(.+))?$/, (msg, match) => { 
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    // cek owner
    const owners = loadDataRealtime(OWNER_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }
    
    const text = match[1];
    if (!text) {
        bot.sendMessage(chatId, '❌ Format salah!\nContoh: /addrvps 123456789');
        return;
    }

    const targetUserId = match[1].trim();

    // validasi id
    if (!/^\d+$/.test(targetUserId)) {
        return bot.sendMessage(chatId, '❌ User ID harus berupa angka!');
    }

    // load file realtime
    const ressVps = loadDataRealtime(RESSVPS_FILE);

    let addedRessVps = false;
    
    // tambahkan ke reseller vps
    if (!ressVps.includes(targetUserId)) {
        ressVps.push(targetUserId);
        if (saveDataRealtime(RESSVPS_FILE, ressVps)) {
            addedRessVps = true;
        }
    }

    if (addedRessVps) {
        bot.sendMessage(chatId, `✅ User ID ${targetUserId} berhasil ditambahkan sebagai Reseller VPS!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    } else {
        bot.sendMessage(chatId, `⚠️ User ID ${targetUserId} sudah menjadi Reseller VPS!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    }
});
    
// command /addbvps - REALTIME VERSION
bot.onText(/^\/addbvps(?:\s+(.+))?$/, (msg, match) => { 
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    // cek owner
    const owners = loadDataRealtime(OWNER_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }
    
    const text = match[1];
    if (!text) {
        bot.sendMessage(chatId, '❌ Format salah!\nContoh:\n/addbvps 123456789');
        return;
    }

    const targetUserId = match[1].trim();

    // validasi id
    if (!/^\d+$/.test(targetUserId)) {
        return bot.sendMessage(chatId, '❌ User ID harus berupa angka!');
    }

    // load file realtime
    const buyerVps = loadDataRealtime(BUYERVPS_FILE);

    let addedBuyVps = false;
    
    // tambahkan ke buyer vps
    if (!buyerVps.includes(targetUserId)) {
        buyerVps.push(targetUserId);
        if (saveDataRealtime(BUYERVPS_FILE, buyerVps)) {
            addedBuyVps = true;
        }
    }

    if (addedBuyVps) {
        bot.sendMessage(chatId, `✅ User ID ${targetUserId} berhasil ditambahkan sebagai Buyer VPS!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    } else {
        bot.sendMessage(chatId, `⚠️ User ID ${targetUserId} sudah menjadi Buyer VPS!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    }
});
    
// command /addtk - REALTIME VERSION
bot.onText(/^\/addtk(?:\s+(.+))?$/, (msg, match) => { 
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    // cek owner
    const owners = loadDataRealtime(OWNER_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }
    
    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '❌ Reply ke pesan user!\nContoh: reply pesan lalu ketik /addtk');
    }

    const targetUserId = msg.reply_to_message.from.id.toString();

    // validasi id
    if (!/^\d+$/.test(targetUserId)) {
        return bot.sendMessage(chatId, '❌ User ID harus berupa angka!');
    }

    // load file realtime
    const premiumUsers = loadDataRealtime(PREMIUM_FILE);
    const ressUsers = loadDataRealtime(RESS_FILE);
    const ownerUsers = loadDataRealtime(OWNER_FILE);

    let addedPrem = false;
    let addedRes = false;
    let addedOwner = false;

    // tambahkan ke premium
    if (!premiumUsers.includes(targetUserId)) {
        premiumUsers.push(targetUserId);
        if (saveDataRealtime(PREMIUM_FILE, premiumUsers)) {
            addedPrem = true;
        }
    }

    // tambahkan ke reseller
    if (!ressUsers.includes(targetUserId)) {
        ressUsers.push(targetUserId);
        if (saveDataRealtime(RESS_FILE, ressUsers)) {
            addedRes = true;
        }
    }
    
    // tambahkan ke owner
    if (!ownerUsers.includes(targetUserId)) {
        ownerUsers.push(targetUserId);
        if (saveDataRealtime(OWNER_FILE, ownerUsers)) {
            addedOwner = true;
        }
    }

    if (addedPrem || addedRes || addedOwner) {
        bot.sendMessage(chatId, `✅ User ID ${targetUserId} berhasil ditambahkan sebagai Tangan Kanan Panel!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    } else {
        bot.sendMessage(chatId, `⚠️ User ID ${targetUserId} sudah menjadi Tangan Kanan Panel!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    }
});

// command /addpt - REALTIME VERSION
bot.onText(/^\/addpt(?:\s+(.+))?$/, (msg, match) => { 
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    // cek owner
    const owners = loadDataRealtime(OWNER_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }
    
    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '❌ Reply ke pesan user!\nContoh: reply pesan lalu ketik /addtk');
    }

    const targetUserId = msg.reply_to_message.from.id.toString();

    // validasi id
    if (!/^\d+$/.test(targetUserId)) {
        return bot.sendMessage(chatId, '❌ User ID harus berupa angka!');
    }

    // load file realtime
    const premiumUsers = loadDataRealtime(PREMIUM_FILE);
    const ressUsers = loadDataRealtime(RESS_FILE);
    const ownerUsers = loadDataRealtime(OWNER_FILE);

    let addedPrem = false;
    let addedRes = false;
    let addedOwner = false;

    // tambahkan ke premium
    if (!premiumUsers.includes(targetUserId)) {
        premiumUsers.push(targetUserId);
        if (saveDataRealtime(PREMIUM_FILE, premiumUsers)) {
            addedPrem = true;
        }
    }

    // tambahkan ke reseller
    if (!ressUsers.includes(targetUserId)) {
        ressUsers.push(targetUserId);
        if (saveDataRealtime(RESS_FILE, ressUsers)) {
            addedRes = true;
        }
    }
    
    // tambahkan ke owner
    if (!ownerUsers.includes(targetUserId)) {
        ownerUsers.push(targetUserId);
        if (saveDataRealtime(OWNER_FILE, ownerUsers)) {
            addedOwner = true;
        }
    }

    if (addedPrem || addedRes || addedOwner) {
        bot.sendMessage(chatId, `✅ User ID ${targetUserId} berhasil ditambahkan sebagai Partner Panel`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    } else {
        bot.sendMessage(chatId, `⚠️ User ID ${targetUserId} sudah menjadi Partner Panel!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    }
});

// command /addown panel - REALTIME VERSION
bot.onText(/^\/addown(?:\s+(.+))?$/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    // cek owner
    const owners = loadDataRealtime(OWNERP_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ᴘᴀɴᴇʟ');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '❌ Reply ke pesan user!\nContoh: reply pesan lalu ketik /addtk');
    }

    const targetUserId = msg.reply_to_message.from.id.toString();

    // validasi id
    if (!/^\d+$/.test(targetUserId)) {
        return bot.sendMessage(chatId, '❌ User ID harus berupa angka!');
    }

    // load file realtime
    const premiumUsers = loadDataRealtime(PREMIUM_FILE);
    const ressUsers = loadDataRealtime(RESS_FILE);
    const ownerpUsers = loadDataRealtime(OWNERP_FILE);

    let addedPrem = false;
    let addedRes = false;
    let addedOwnerP = false;

    // tambahkan ke premium
    if (!premiumUsers.includes(targetUserId)) {
        premiumUsers.push(targetUserId);
        if (saveDataRealtime(PREMIUM_FILE, premiumUsers)) {
            addedPrem = true;
        }
    }

    // tambahkan ke reseller
    if (!ressUsers.includes(targetUserId)) {
        ressUsers.push(targetUserId);
        if (saveDataRealtime(RESS_FILE, ressUsers)) {
            addedRes = true;
        }
    }
    
    // tambahkan ke owner panel
    if (!ownerpUsers.includes(targetUserId)) {
        ownerpUsers.push(targetUserId);
        if (saveDataRealtime(OWNERP_FILE, ownerpUsers)) {
            addedOwnerP = true;
        }
    }

    if (addedPrem || addedRes || addedOwnerP) {
        bot.sendMessage(chatId, `✅ User ID ${targetUserId} berhasil ditambahkan sebagai Owner Panel!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    } else {
        bot.sendMessage(chatId, `⚠️ User ID ${targetUserId} sudah menjadi Owner Panel!`);
    }
});
    
// command add premium & reseller - REALTIME VERSION
bot.onText(/^\/addpr (.+)$/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    // cek owner
    const owners = loadDataRealtime(OWNERP_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '❌ Reply ke pesan user!\nContoh: reply pesan lalu ketik /addtk');
    }

    const targetUserId = msg.reply_to_message.from.id.toString();

    // validasi id
    if (!/^\d+$/.test(targetUserId)) {
        return bot.sendMessage(chatId, '❌ User ID harus berupa angka!');
    }

    // load file realtime
    const premiumUsers = loadDataRealtime(PREMIUM_FILE);
    const ressUsers = loadDataRealtime(RESS_FILE);

    let addedPrem = false;
    let addedRes = false;

    // tambahkan ke premium
    if (!premiumUsers.includes(targetUserId)) {
        premiumUsers.push(targetUserId);
        if (saveDataRealtime(PREMIUM_FILE, premiumUsers)) {
            addedPrem = true;
        }
    }

    // tambahkan ke reseller
    if (!ressUsers.includes(targetUserId)) {
        ressUsers.push(targetUserId);
        if (saveDataRealtime(RESS_FILE, ressUsers)) {
            addedRes = true;
        }
    }

    if (addedPrem || addedRes) {
        bot.sendMessage(chatId, `✅ User ID ${targetUserId} berhasil ditambahkan menjadi Premium & Reseller`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    } else {
        bot.sendMessage(chatId, `⚠️ ᴜꜱᴇʀ ${targetUserId} ꜱᴜᴅᴀʜ ᴍᴇɴᴊᴀᴅɪ ᴘʀᴇᴍɪᴜᴍ ᴅᴀɴ ʀᴇꜱᴇʟʟᴇʀ!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    }
});

// command /delprem
bot.onText(/^\/delprem$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const owners = loadJsonData(OWNER_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '❌ Reply ke pesan user!\nContoh: reply pesan lalu ketik /delprem');
    }

    const targetUserId = msg.reply_to_message.from.id.toString();

    let premUsers = loadJsonData(PREMIUM_FILE);

    if (premUsers.includes(targetUserId)) {
        premUsers = premUsers.filter(uid => uid !== targetUserId);
        saveJsonData(PREMIUM_FILE, premUsers);

        bot.sendMessage(chatId, `✅ User ID ${targetUserId} berhasil dihapus dari Premium!`, {
            parse_mode: "Markdown",
            reply_to_message_id: msg.message_id
        });
    } else {
        bot.sendMessage(chatId, `⚠️ User ID ${targetUserId} tidak ditemukan di daftar Premium!`);
    }
});

// command /delress
bot.onText(/^\/delress$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const owners = loadJsonData(OWNER_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '❌ Reply ke pesan user!\nContoh: reply pesan lalu ketik /delress');
    }

    const targetUserId = msg.reply_to_message.from.id.toString();

    let ressUsers = loadJsonData(RESS_FILE);

    if (ressUsers.includes(targetUserId)) {
        ressUsers = ressUsers.filter(uid => uid !== targetUserId);
        saveJsonData(RESS_FILE, ressUsers);

        bot.sendMessage(chatId, `✅ User ID ${targetUserId} berhasil dihapus dari Reseller Panel!`, {
            parse_mode: "Markdown",
            reply_to_message_id: msg.message_id
        });
    } else {
        bot.sendMessage(chatId, `⚠️ User ID ${targetUserId} tidak ditemukan di daftar Reseller Panel!`);
    }
});

// command /delowner
bot.onText(/^\/delown(?:\s+(.+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    let owners = loadJsonData(OWNER_FILE);

    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
        return;
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '❌ Reply ke pesan user!\nContoh: reply pesan lalu ketik /delprem');
    }

    const targetUserId = msg.reply_to_message.from.id.toString();

    owners = owners.filter(id => id !== targetUserId);
    const success = saveJsonData(OWNER_FILE, owners);

    if (success) {
        bot.sendMessage(chatId, `✅ ᴜꜱᴇʀ ɪᴅ ${targetUserId} ʙᴇʀʜᴀꜱɪʟ ᴅɪʜᴀᴘᴜꜱ ᴅᴀʀɪ ᴅᴀꜰᴛᴀʀ ᴏᴡɴᴇʀ ʙᴏᴛ!`);
    } else {
        bot.sendMessage(chatId, '❌ Gagal menyimpan perubahan data Owner!');
    }
});
    
}