const db = require('../lib/database');

module.exports = (bot) => {
  // Command start
  bot.command('start', (ctx) => {
    const userId = ctx.from.id;
    db.createUser(ctx.from, (err) => {
      if (err) {
        console.error('Error creating user:', err);
        return ctx.reply('Terjadi kesalahan. Silakan coba lagi.');
      }
      
      ctx.reply(
        `Halo ${ctx.from.first_name}! Selamat datang di Bot Jasher.\n\n` +
        'Gunakan /help untuk melihat perintah yang tersedia.'
      );
    });
  });

  // Command help
  bot.command('help', (ctx) => {
    ctx.reply(
      '📋 Daftar Perintah Bot Jasher:\n\n' +
      '/start - Memulai bot\n' +
      '/help - Menampilkan bantuan\n' +
      '/credit - Cek kredit Anda\n' +
      '/share [teks] - Bagikan teks (menggunakan 1 kredit)\n' +
      'Balas pesan dengan /share - Bagikan pesan yang dibalas (menggunakan 1 kredit)'
    );
  });

  // Command credit
  bot.command('credit', (ctx) => {
    const userId = ctx.from.id;
    
    db.getUser(userId, (err, user) => {
      if (err) {
        console.error('Error getting user:', err);
        return ctx.reply('Terjadi kesalahan. Silakan coba lagi.');
      }
      
      if (!user) {
        return ctx.reply('Anda belum terdaftar. Gunakan /start untuk mendaftar.');
      }
      
      ctx.reply(`💰 Kredit Anda: ${user.credit}`);
    });
  });

  // Command share
  bot.command('share', async (ctx) => {
    const userId = ctx.from.id;
    const chatId = ctx.chat.id;
    const messageText = ctx.message.text.replace(/^\/share\s*/, '');
    const repliedMessage = ctx.message.reply_to_message;
    
    // Cek apakah di group
    if (ctx.chat.type === 'private') {
      return ctx.reply('Perintah ini hanya bisa digunakan di dalam group!');
    }
    
    // Cek apakah group sudah ditambahkan
    db.isGroupAdded(chatId, (err, isAdded) => {
      if (err) {
        console.error('Error checking group:', err);
        return ctx.reply('Terjadi kesalahan. Silakan coba lagi.');
      }
      
      if (!isAdded) {
        return ctx.reply('Bot harus ditambahkan ke group terlebih dahulu untuk menggunakan fitur ini!');
      }
      
      // Cek user
      db.getUser(userId, (err, user) => {
        if (err) {
          console.error('Error getting user:', err);
          return ctx.reply('Terjadi kesalahan. Silakan coba lagi.');
        }
        
        if (!user) {
          return ctx.reply('Anda belum terdaftar. Gunakan /start di private chat bot untuk mendaftar.');
        }
        
        // Cek kredit
        if (user.credit < 1) {
          return ctx.reply('Kredit Anda tidak cukup. Tambah kredit dengan menambahkan bot ke group lain!');
        }
        
        // Cek apakah ada teks atau reply
        if (!messageText && !repliedMessage) {
          return ctx.reply('Silakan ketik teks setelah /share atau balas pesan dengan /share');
        }
        
        let contentToShare = '';
        
        if (repliedMessage) {
          // Jika ada pesan yang dibalas
          if (repliedMessage.text) {
            contentToShare = repliedMessage.text;
          } else if (repliedMessage.caption) {
            contentToShare = repliedMessage.caption;
          } else {
            contentToShare = '📎 [Media]';
          }
        } else {
          // Jika ada teks setelah perintah
          contentToShare = messageText;
        }
        
        // Kurangi kredit
        db.updateUserCredit(userId, -1, (err) => {
          if (err) {
            console.error('Error updating credit:', err);
            return ctx.reply('Terjadi kesalahan. Silakan coba lagi.');
          }
          
          // Bagikan konten
          ctx.reply(
            `📤 Dibagikan oleh: ${ctx.from.first_name}\n\n` +
            `${contentToShare}\n\n` +
            `#JasherShare`
          );
        });
      });
    });
  });
};