const { Markup } = require('telegraf');
const { User, Group } = require('../lib/database');
const { formatUserInfo } = require('./utils');
const { ADMIN_ID } = require('../config');

async function handleStart(ctx) {
    try {
        const userId = ctx.from.id;
        const username = ctx.from.username;
        const firstName = ctx.from.first_name;
        const lastName = ctx.from.last_name || '';
        
        let user = await User.findOne({ userId });
        
        if (!user) {
            user = new User({
                userId,
                username,
                firstName,
                lastName,
                credit: 0
            });
            await user.save();
        }
        
        const isCreator = userId.toString() === ADMIN_ID;
        const message = formatUserInfo(ctx, user, isCreator);
        
        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('Jasher Menu', 'jasher_menu')],
            [Markup.button.callback('Owner Menu', 'owner_menu')],
            [Markup.button.url('Add Group', 'https://t.me/your_bot_username?startgroup=true')],
            [Markup.button.callback('Owner', 'owner_info')]
        ]);
        
        await ctx.reply(message, {
            parse_mode: 'HTML',
            ...keyboard
        });
    } catch (error) {
        console.error('Error in start command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleHelp(ctx) {
    const helpMessage = `
🤖 <b>Jasher Bot Commands</b>

🔹 <b>Untuk Semua Pengguna:</b>
/start - Memulai bot
/help - Menampilkan bantuan
/credit - Cek kredit Anda
/share - Share pesan (kurangi 2 kredit)

🔹 <b>Untuk Premium Users:</b>
/sharevip - Share pesan premium (lebih cepat)

🔹 <b>Untuk Owner:</b>
/addprem [user_id] - Tambah user premium
/delprem [user_id] - Hapus user premium
/listprem - List semua user premium
/broadcast - Broadcast ke semua user
    `;
    
    await ctx.reply(helpMessage, { parse_mode: 'HTML' });
}

async function handleCredit(ctx) {
    try {
        const userId = ctx.from.id;
        const user = await User.findOne({ userId });
        
        if (!user) {
            await ctx.reply('Anda belum terdaftar. Ketik /start untuk memulai.');
            return;
        }
        
        await ctx.reply(`💰 Kredit Anda: ${user.credit}`);
    } catch (error) {
        console.error('Error in credit command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleShare(ctx) {
    try {
        if (ctx.chat.type !== 'private') {
            await ctx.reply('Command ini hanya bisa digunakan di private chat.');
            return;
        }
        
        const userId = ctx.from.id;
        const user = await User.findOne({ userId });
        
        if (!user) {
            await ctx.reply('Anda belum terdaftar. Ketik /start untuk memulai.');
            return;
        }
        
        // Cek apakah user sudah join minimal 3 group
        if (user.joinedGroups.length < 3) {
            await ctx.reply(`Anda harus join minimal 3 group terlebih dahulu. Anda sudah join ${user.joinedGroups.length} group.`);
            return;
        }
        
        // Cek kredit
        if (user.credit < 2) {
            await ctx.reply(`Kredit Anda tidak cukup. Dibutuhkan 2 kredit, Anda memiliki ${user.credit} kredit.`);
            return;
        }
        
        const messageToShare = ctx.message.reply_to_message 
            ? ctx.message.reply_to_message.text 
            : ctx.message.text.split(' ').slice(1).join(' ');
        
        if (!messageToShare) {
            await ctx.reply('Balas pesan yang ingin di-share atau ketik pesan setelah command /share.');
            return;
        }
        
        // Kurangi kredit
        user.credit -= 2;
        await user.save();
        
        // Broadcast ke semua group
        const groups = await Group.find({});
        let successCount = 0;
        
        for (const group of groups) {
            try {
                await ctx.telegram.sendMessage(group.groupId, messageToShare);
                successCount++;
            } catch (error) {
                console.error(`Error sending to group ${group.groupId}:`, error);
            }
        }
        
        await ctx.reply(`Pesan berhasil di-share ke ${successCount} group. Kredit dikurangi 2. Sisa kredit: ${user.credit}`);
    } catch (error) {
        console.error('Error in share command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleShareVip(ctx) {
    try {
        if (ctx.chat.type !== 'private') {
            await ctx.reply('Command ini hanya bisa digunakan di private chat.');
            return;
        }
        
        const userId = ctx.from.id;
        const user = await User.findOne({ userId });
        
        if (!user) {
            await ctx.reply('Anda belum terdaftar. Ketik /start untuk memulai.');
            return;
        }
        
        if (!user.isPremium) {
            await ctx.reply('Fitur ini hanya untuk user premium.');
            return;
        }
        
        const messageToShare = ctx.message.reply_to_message 
            ? ctx.message.reply_to_message.text 
            : ctx.message.text.split(' ').slice(1).join(' ');
        
        if (!messageToShare) {
            await ctx.reply('Balas pesan yang ingin di-share atau ketik pesan setelah command /sharevip.');
            return;
        }
        
        // Broadcast ke semua group (lebih cepat)
        const groups = await Group.find({});
        const sendPromises = groups.map(group => {
            return ctx.telegram.sendMessage(group.groupId, messageToShare)
                .catch(error => console.error(`Error sending to group ${group.groupId}:`, error));
        });
        
        await Promise.all(sendPromises);
        
        await ctx.reply('Pesan premium berhasil di-share ke semua group.');
    } catch (error) {
        console.error('Error in sharevip command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

// Admin commands
async function handleAddPrem(ctx) {
    try {
        if (ctx.from.id.toString() !== ADMIN_ID) {
            await ctx.reply('Anda bukan owner bot.');
            return;
        }
        
        const targetUserId = parseInt(ctx.message.text.split(' ')[1]);
        if (isNaN(targetUserId)) {
            await ctx.reply('Gunakan: /addprem [user_id]');
            return;
        }
        
        const user = await User.findOneAndUpdate(
            { userId: targetUserId },
            { isPremium: true },
            { new: true, upsert: true }
        );
        
        await ctx.reply(`User ${targetUserId} sekarang premium.`);
    } catch (error) {
        console.error('Error in addprem command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleDelPrem(ctx) {
    try {
        if (ctx.from.id.toString() !== ADMIN_ID) {
            await ctx.reply('Anda bukan owner bot.');
            return;
        }
        
        const targetUserId = parseInt(ctx.message.text.split(' ')[1]);
        if (isNaN(targetUserId)) {
            await ctx.reply('Gunakan: /delprem [user_id]');
            return;
        }
        
        const user = await User.findOneAndUpdate(
            { userId: targetUserId },
            { isPremium: false },
            { new: true }
        );
        
        if (!user) {
            await ctx.reply('User tidak ditemukan.');
            return;
        }
        
        await ctx.reply(`User ${targetUserId} tidak premium lagi.`);
    } catch (error) {
        console.error('Error in delprem command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleListPrem(ctx) {
    try {
        if (ctx.from.id.toString() !== ADMIN_ID) {
            await ctx.reply('Anda bukan owner bot.');
            return;
        }
        
        const premiumUsers = await User.find({ isPremium: true });
        
        if (premiumUsers.length === 0) {
            await ctx.reply('Tidak ada user premium.');
            return;
        }
        
        let message = '📋 <b>Daftar User Premium</b>\n\n';
        premiumUsers.forEach((user, index) => {
            message += `${index + 1}. ID: ${user.userId}, Username: @${user.username || 'N/A'}\n`;
        });
        
        await ctx.reply(message, { parse_mode: 'HTML' });
    } catch (error) {
        console.error('Error in listprem command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleBroadcast(ctx) {
    try {
        if (ctx.from.id.toString() !== ADMIN_ID) {
            await ctx.reply('Anda bukan owner bot.');
            return;
        }
        
        const broadcastMessage = ctx.message.reply_to_message 
            ? ctx.message.reply_to_message.text 
            : ctx.message.text.split(' ').slice(1).join(' ');
        
        if (!broadcastMessage) {
            await ctx.reply('Balas pesan yang ingin di-broadcast atau ketik pesan setelah command /broadcast.');
            return;
        }
        
        const allUsers = await User.find({});
        let successCount = 0;
        
        for (const user of allUsers) {
            try {
                await ctx.telegram.sendMessage(user.userId, broadcastMessage);
                successCount++;
            } catch (error) {
                console.error(`Error sending to user ${user.userId}:`, error);
            }
        }
        
        await ctx.reply(`Broadcast berhasil dikirim ke ${successCount} user.`);
    } catch (error) {
        console.error('Error in broadcast command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

module.exports = {
    handleStart,
    handleHelp,
    handleCredit,
    handleShare,
    handleShareVip,
    handleAddPrem,
    handleDelPrem,
    handleListPrem,
    handleBroadcast
};