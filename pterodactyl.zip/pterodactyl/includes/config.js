<?php
// Konfigurasi Panel Pterodactyl
define('DOMAIN', 'https://xillo.naell.my.id');
define('PLTA', 'ptla_BZ1FMoDNRoXNNCdkEbx5MN9TzFTNZsurwYeG4ABPqa9');
define('PLTC', 'ptlc_qcIgclD2quKy0LATuP1VjlfQqcvOn2MdBltjQw9rrrY');
define('LOC', '1');
define('EGGS', '15');
define('NESTS', '5');

// Konfigurasi Database
define('DB_HOST', 'localhost');
define('DB_NAME', 'buatkam1_pteroda');
define('DB_USER', 'buatkam1_pteroda');
define('DB_PASS', 'JqeQdsnDyPte');

// Konfigurasi YAB-Group
define('YAB_API_KEY', 'tarjUb8mYusE5pdbHN8unB6snWA7CdSu');
define('YAB_SECRET_KEY', 'zElY27dFNFOPKbd2jO0o8xglJ5PfMVQqnI55VPrXghPKCyitciWP');
define('YAB_API_URL', 'https://yab-group.com/api/live/create');

// Konfigurasi Email
define('SMTP_HOST', 'newpinwheel.indowebsite.net');
define('SMTP_USER', 'support@y2beta.web.id');
define('SMTP_PASS', 'Aulia@1230##1');
define('SMTP_PORT', 465);

// Memulai session
session_start();
?>