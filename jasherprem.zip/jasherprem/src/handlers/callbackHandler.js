module.exports = (bot) => {
    // Handle callback queries untuk button menu
    bot.on('callback_query', async (ctx) => {
        const callbackData = ctx.callbackQuery.data;
        
        try {
            await ctx.answerCbQuery(); // Remove loading indicator

            switch (callbackData) {
                case 'main_menu':
                    await require('../commands/userCommands').handleMainMenu(ctx);
                    break;
                case 'jasher_menu':
                    await require('../commands/userCommands').handleJasherMenu(ctx);
                    break;
                case 'owner_menu':
                    await require('../commands/ownerCommands').handleOwnerMenu(ctx);
                    break;
                case 'obf_menu':
                    await require('../commands/obfuscation').handleObfMenu(ctx);
                    break;
                case 'share_free':
                    await require('../commands/userCommands').handleShareFree(ctx);
                    break;
                case 'share_vip':
                    await require('../commands/userCommands').handleShareVip(ctx);
                    break;
                case 'buy_premium':
                    await require('../commands/userCommands').handleBuyPremium(ctx);
                    break;
                case 'buy_script':
                    await require('../commands/userCommands').handleBuyScript(ctx);
                    break;
                default:
                    // Handle obfuscation callbacks
                    if (callbackData.startsWith('obf_')) {
                        await require('../commands/obfuscation').handleObfCallback(ctx, callbackData);
                    }
                    // Handle owner callbacks
                    else if (callbackData.startsWith('owner_')) {
                        await require('../commands/ownerCommands').handleOwnerCallback(ctx, callbackData);
                    }
                    break;
            }
        } catch (error) {
            console.error('Error handling callback:', error);
            await ctx.answerCbQuery('❌ Terjadi kesalahan!');
        }
    });
};