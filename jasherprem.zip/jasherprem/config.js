global.BOT_TOKEN = process.env.BOT_TOKEN || 'YOUR_BOT_TOKEN_HERE';
global.MONGO_URL = process.env.MONGO_URL || 'mongodb://localhost:27017/jasherbot';
global.OWNER_ID = process.env.OWNER_ID || '123456789'; // Ganti dengan ID Telegram Anda

// Ekspor konfigurasi
module.exports = {
    BOT_TOKEN: global.BOT_TOKEN,
    MONGO_URL: global.MONGO_URL,
    OWNER_ID: global.OWNER_ID
};