const { Markup } = require('telegraf');
const { getUser, isPremium, addCredit, getCredit, getGroups, addGroup, isBlacklisted } = require('../lib/database');
const { runtime, formatTime, log } = require('../lib/utils');
const moment = require('moment-timezone');

function setupHandlers(bot) {
    // Handle callback queries
    bot.on('callback_query', async (ctx) => {
        const data = ctx.callbackQuery.data;
        const userId = ctx.from.id;
        const user = await getUser(userId);
        const userPremium = await isPremium(userId);
        const userCredit = await getCredit(userId);

        switch (data) {
            case 'jasher_menu':
                const jasherText = `🎯 *Jasher Menu*\n\n` +
                                 `Status: ${userPremium ? '✅ Premium' : '❌ Free'}\n` +
                                 `Kredit: ${userCredit}\n\n` +
                                 `Pilih opsi di bawah ini:`;
                
                await ctx.editMessageCaption(jasherText, {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('📤 Share', 'share_option'), Markup.button.callback('🚀 Share VIP', 'sharevip_option')],
                        [Markup.button.callback('🔙 Kembali', 'main_menu')]
                    ]).reply_markup
                });
                break;
                
            case 'owner_menu':
                if (userId !== parseInt(process.env.CREATOR_ID)) {
                    await ctx.answerCbQuery('❌ Anda bukan owner bot!');
                    return;
                }
                
                const ownerText = `👑 *Owner Menu*\n\n` +
                                `Pilih opsi di bawah ini:`;
                
                await ctx.editMessageCaption(ownerText, {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('📊 Stats', 'stats_option'), Markup.button.callback('📢 Broadcast', 'broadcast_option')],
                        [Markup.button.callback('🚫 Blacklist', 'blacklist_option'), Markup.button.callback('👥 Groups', 'groups_option')],
                        [Markup.button.callback('⭐ Premium', 'premium_option')],
                        [Markup.button.callback('🔙 Kembali', 'main_menu')]
                    ]).reply_markup
                });
                break;
                
            case 'obf_menu':
                const obfText = `🔒 *Obfuscation Menu*\n\n` +
                              `Pilih metode obfuscation di bawah ini:`;
                
                await ctx.editMessageCaption(obfText, {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🔐 Time-Locked', 'obf_timelocked'), Markup.button.callback('🌌 Quantum', 'obf_quantum')],
                        [Markup.button.callback('🌀 Nebula', 'obf_nebula'), Markup.button.callback('✨ Nova', 'obf_nova')],
                        [Markup.button.callback('🛡️ Strong', 'obf_strong'), Markup.button.callback('🇯🇵 Japan', 'obf_japan')],
                        [Markup.button.callback('🇦🇪 Arab', 'obf_arab'), Markup.button.callback('🇨🇳 China', 'obf_china')],
                        [Markup.button.callback('🔙 Kembali', 'main_menu')]
                    ]).reply_markup
                });
                break;
                
            case 'main_menu':
                const sender = ctx.from.username || ctx.from.first_name;
                const developer = process.env.DEVELOPER || '@ginaaforyou';
                const username = ctx.from.username ? `${ctx.from.username}` : 'Tidak ada username';
                const isCreator = userId === parseInt(process.env.CREATOR_ID);
                
                const menuText = `Hi kak @${sender}
╭─❒ 「 User Info 」 
├ Creator : ${developer}
├ Name : ${username}
├ Profile : @${sender}
├ ID Telegram Anda: ${userId}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreator ? 'True' : 'False'}

Silahkan pilih button dibawah ini!`;

                await ctx.editMessageCaption(menuText, {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🎯 Jasher Menu', 'jasher_menu')],
                        [Markup.button.callback('👑 Owner Menu', 'owner_menu'), Markup.button.callback('🔒 Obf Menu', 'obf_menu')],
                        [Markup.button.callback('ℹ️ Info', 'info_menu')]
                    ]).reply_markup
                });
                break;
                
            case 'info_menu':
                const infoText = `ℹ️ *Bot Information*\n\n` +
                               `🤖 *Nama Bot:* Jasher Premium\n` +
                               `👨‍💻 *Developer:* ${process.env.DEVELOPER || '@ginaaforyou'}\n` +
                               `📅 *Dibuat:* 2025\n` +
                               `⚡ *Version:* 3.0.0\n\n` +
                               `*Fitur:*\n` +
                               `✅ Share ke semua grup\n` +
                               `✅ Obfuscation berbagai metode\n` +
                               `✅ Premium system\n` +
                               `✅ Auto jasher\n` +
                               `✅ Dan masih banyak lagi!\n\n` +
                               `Gunakan /start untuk kembali ke menu utama.`;
                
                await ctx.editMessageCaption(infoText, {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🔙 Kembali', 'main_menu')]
                    ]).reply_markup
                });
                break;
                
            case 'share_option':
                if (ctx.chat.type !== 'private') {
                    await ctx.answerCbQuery('❌ Fitur ini hanya bisa digunakan di private chat!');
                    return;
                }
                
                if (!userPremium) {
                    await ctx.answerCbQuery('❌ Anda harus premium untuk menggunakan fitur share!');
                    return;
                }
                
                if (userCredit < 1) {
                    await ctx.answerCbQuery('❌ Kredit Anda tidak cukup untuk share!');
                    return;
                }
                
                await ctx.editMessageCaption('📤 *Share Message*\n\nBalas pesan yang ingin di-share dengan perintah /share', {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🔙 Kembali', 'jasher_menu')]
                    ]).reply_markup
                });
                break;
                
            case 'sharevip_option':
                if (ctx.chat.type !== 'private') {
                    await ctx.answerCbQuery('❌ Fitur ini hanya bisa digunakan di private chat!');
                    return;
                }
                
                if (!userPremium) {
                    await ctx.answerCbQuery('❌ Anda harus premium untuk menggunakan fitur share VIP!');
                    return;
                }
                
                if (userCredit < 2) {
                    await ctx.answerCbQuery('❌ Kredit Anda tidak cukup untuk share VIP!');
                    return;
                }
                
                await ctx.editMessageCaption('🚀 *Share VIP Message*\n\nBalas pesan yang ingin di-share dengan perintah /sharevip', {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard([
                        [Markup.button.callback('🔙 Kembali', 'jasher_menu')]
                    ]).reply_markup
                });
                break;
                
            default:
                // Handle obfuscation methods
                if (data.startsWith('obf_')) {
                    const method = data.replace('obf_', '');
                    await handleObfuscation(ctx, method);
                }
                break;
        }
        
        await ctx.answerCbQuery();
    });

    // Handle new chat members (bot added to group)
    bot.on('new_chat_members', async (ctx) => {
        const newMembers = ctx.message.new_chat_members;
        const isBotAdded = newMembers.some(member => member.is_bot && member.username === ctx.botInfo.username);
        
        if (isBotAdded) {
            const groupId = ctx.chat.id;
            const groupName = ctx.chat.title;
            const addedBy = ctx.from.id;
            
            // Check if group is blacklisted
            const isBlacklisted = await isBlacklisted(groupId);
            if (isBlacklisted) {
                await ctx.reply('❌ Grup ini telah di-blacklist!');
                await ctx.telegram.leaveChat(groupId);
                return;
            }
            
            // Add group to database
            await addGroup(groupId, groupName, addedBy);
            
            await ctx.reply(`✅ Terima kasih telah menambahkan saya ke grup ini!\n\n` +
                          `Gunakan /start di private chat untuk melihat menu bot.`);
        }
    });

    // Handle left chat member (bot removed from group)
    bot.on('left_chat_member', async (ctx) => {
        const leftMember = ctx.message.left_chat_member;
        if (leftMember.is_bot && leftMember.username === ctx.botInfo.username) {
            const groupId = ctx.chat.id;
            await deactivateGroup(groupId);
        }
    });
}

// Handle obfuscation method selection
async function handleObfuscation(ctx, method) {
    const userId = ctx.from.id;
    const userPremium = await isPremium(userId);
    
    if (!userPremium) {
        await ctx.editMessageCaption('❌ *Akses Ditolak*\n\nAnda harus premium untuk menggunakan fitur obfuscation!', {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [Markup.button.callback('🔙 Kembali', 'obf_menu')]
            ]).reply_markup
        });
        return;
    }
    
    await ctx.editMessageCaption(`🔒 *Obfuscation ${method.toUpperCase()}*\n\nSilahkan kirim file JavaScript yang ingin di-obfuscate.`, {
        parse_mode: 'Markdown',
        reply_markup: Markup.inlineKeyboard([
            [Markup.button.callback('🔙 Kembali', 'obf_menu')]
        ]).reply_markup
    });
    
    // Set session state to wait for file
    ctx.session = { waitingForFile: true, obfMethod: method };
}

module.exports = {
    setupHandlers
};