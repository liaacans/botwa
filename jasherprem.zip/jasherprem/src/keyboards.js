const { Markup } = require('telegraf');

function mainMenuKeyboard() {
    return Markup.keyboard([
        ['Jasher Menu', 'Owner Menu'],
        ['AddGroup', 'Owner'],
        ['Kembali']
    ]).resize();
}

function jasherMenuKeyboard() {
    return Markup.keyboard([
        ['Share', 'ShareVIP'],
        ['Credit', 'Kembali']
    ]).resize();
}

function ownerMenuKeyboard(isCreator) {
    if (!isCreator) return null;
    
    return Markup.keyboard([
        ['Broadcast', 'ListPrem'],
        ['AddPrem', 'DelPrem'],
        ['Kembali']
    ]).resize();
}

function backKeyboard() {
    return Markup.keyboard(['Kembali']).resize();
}

module.exports = {
    mainMenuKeyboard,
    jasherMenuKeyboard,
    ownerMenuKeyboard,
    backKeyboard
};