global.BOT_TOKEN = "8198305874:AAH1Sfr54fyWkPSdfuLQTK_5hSyW69V2C7o";
global.MONGO_URL = "mongodb://mybot_todaytime:94a632154d44683eb18a23ee50f3a31a69e621f8@2kred.h.filess.io:61004/mybot_todaytime";
global.OWNER_ID = "8135269613";
global.PAYMENT_API_KEY = "tarjUb8mYusE5pdbHN8unB6snWA7CdSu";
global.PAYMENT_SECRET_KEY = "zElY27dFNFOPKbd2jO0o8xglJ5PfMVQqnI55VPrXghPKCyitciWP";
global.PAYMENT_URL = "https://yab-group.com/api/live/create";
global.UGUU_API = "https://uguu.se/upload.php";