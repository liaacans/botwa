const { Markup } = require('telegraf');
const { User, Group } = require('../lib/database');
const { formatUserInfo } = require('./utils');
const commands = require('./commands');

async function handleCallbackQuery(ctx) {
  const data = ctx.callbackQuery.data;
  const user = await User.findOne({ userId: ctx.from.id });
  
  switch (data) {
    case 'main_menu':
      try {
        const caption = formatUserInfo(ctx, user);
        const menuButtons = Markup.inlineKeyboard([
          [Markup.button.callback('🎯 Jasher Menu', 'jasher_menu')],
          [Markup.button.callback('👤 Owner Menu', 'owner_menu')],
          [Markup.button.url('➕ Add Group', 'https://t.me/your_bot_username?startgroup=true')]
        ]);
        
        await ctx.editMessageCaption(caption, {
          parse_mode: 'HTML',
          reply_markup: menuButtons.reply_markup
        });
      } catch (error) {
        console.error('Error showing main menu:', error);
        ctx.answerCbQuery('Error showing menu');
      }
      break;
      
    case 'jasher_menu':
      try {
        const jasherButtons = Markup.inlineKeyboard([
          [Markup.button.callback('💳 Cek Kredit', 'check_credit')],
          [Markup.button.callback('📤 Share Pesan', 'share_message')],
          [Markup.button.callback('🔙 Kembali', 'main_menu')]
        ]);
        
        await ctx.editMessageCaption(
          `🎯 <b>Jasher Menu</b>\n\n` +
          `Pilih opsi yang tersedia:`,
          {
            parse_mode: 'HTML',
            reply_markup: jasherButtons.reply_markup
          }
        );
      } catch (error) {
        console.error('Error showing jasher menu:', error);
        ctx.answerCbQuery('Error showing menu');
      }
      break;
      
    case 'owner_menu':
      if (ctx.from.id.toString() !== global.OWNER_ID) {
        ctx.answerCbQuery('Anda bukan owner!');
        return;
      }
      
      try {
        const ownerButtons = Markup.inlineKeyboard([
          [Markup.button.callback('👑 List Premium', 'list_premium')],
          [Markup.button.callback('📢 Broadcast', 'broadcast_menu')],
          [Markup.button.callback('🔙 Kembali', 'main_menu')]
        ]);
        
        await ctx.editMessageCaption(
          `👤 <b>Owner Menu</b>\n\n` +
          `Fitur khusus untuk owner bot:`,
          {
            parse_mode: 'HTML',
            reply_markup: ownerButtons.reply_markup
          }
        );
      } catch (error) {
        console.error('Error showing owner menu:', error);
        ctx.answerCbQuery('Error showing menu');
      }
      break;
      
    case 'check_credit':
      await commands.handleCredit(ctx);
      ctx.answerCbQuery();
      break;
      
    case 'share_message':
      ctx.reply('Balas pesan yang ingin Anda bagikan dengan perintah /share');
      ctx.answerCbQuery();
      break;
      
    case 'share_vip':
      try {
        if (!user) {
          ctx.answerCbQuery('Anda belum terdaftar');
          return;
        }
        
        if (user.credit < global.PREMIUM_COST) {
          ctx.answerCbQuery(`Kredit tidak cukup! Dibutuhkan ${global.PREMIUM_COST} kredit`);
          return;
        }
        
        // Simulasi proses share VIP
        ctx.answerCbQuery('Memproses share VIP...');
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Kurangi kredit
        user.credit -= global.PREMIUM_COST;
        await user.save();
        
        ctx.reply(`✅ Share VIP berhasil! ${global.PREMIUM_COST} kredit telah dikurangi.`);
      } catch (error) {
        console.error('Error in VIP share:', error);
        ctx.answerCbQuery('Error processing share');
      }
      break;
      
    case 'share_free':
      try {
        if (!user) {
          ctx.answerCbQuery('Anda belum terdaftar');
          return;
        }
        
        if (user.credit < global.FREE_COST) {
          ctx.answerCbQuery(`Kredit tidak cukup! Dibutuhkan ${global.FREE_COST} kredit`);
          return;
        }
        
        // Simulasi proses share Free
        ctx.answerCbQuery('Memproses share Free...');
        await new Promise(resolve => setTimeout(resolve, 5000));
        
        // Kurangi kredit
        user.credit -= global.FREE_COST;
        await user.save();
        
        ctx.reply(`✅ Share Free berhasil! ${global.FREE_COST} kredit telah dikurangi.`);
      } catch (error) {
        console.error('Error in Free share:', error);
        ctx.answerCbQuery('Error processing share');
      }
      break;
      
    case 'cancel_share':
      ctx.deleteMessage();
      ctx.answerCbQuery('Share dibatalkan');
      break;
      
    case 'add_group':
      ctx.reply(
        `Untuk menambahkan bot ke grup:\n\n` +
        `1. Klik tombol di bawah ini\n` +
        `2. Pilih grup yang ingin ditambahkan\n` +
        `3. Setelah ditambahkan, admin akan memverifikasi grup Anda\n` +
        `4. Setelah terverifikasi, Anda akan mendapatkan kredit`,
        Markup.inlineKeyboard([
          [Markup.button.url('➕ Tambahkan ke Grup', 'https://t.me/your_bot_username?startgroup=true')],
          [Markup.button.callback('🔙 Kembali', 'check_credit')]
        ])
      );
      ctx.answerCbQuery();
      break;
      
    case 'list_premium':
      await commands.handleListPrem(ctx);
      ctx.answerCbQuery();
      break;
      
    case 'broadcast_menu':
      ctx.reply('Kirim pesan broadcast dengan format: /bc [pesan]');
      ctx.answerCbQuery();
      break;
      
    default:
      ctx.answerCbQuery('Unknown action');
  }
}

// Handler ketika bot ditambahkan ke grup
async function handleNewChatMembers(ctx) {
  // Hanya tanggapi jika bot yang ditambahkan
  if (ctx.message.new_chat_members.some(member => member.is_bot && member.id === ctx.botInfo.id)) {
    try {
      const groupId = ctx.chat.id;
      const addedBy = ctx.from.id;
      const title = ctx.chat.title;
      const username = ctx.chat.username;
      
      // Cek apakah grup sudah terdaftar
      let group = await Group.findOne({ groupId });
      
      if (!group) {
        group = new Group({
          groupId,
          title,
          username,
          addedBy
        });
        await group.save();
        
        // Tambahkan group ke user's addedGroups
        const user = await User.findOne({ userId: addedBy });
        if (user) {
          user.addedGroups.push(group._id);
          
          // Beri kredit jika sudah memenuhi syarat
          const userGroups = await Group.find({ addedBy: addedBy });
          if (userGroups.length >= global.GROUPS_REQUIRED && user.credit === 0) {
            user.credit += global.PREMIUM_COST;
            await ctx.telegram.sendMessage(
              addedBy, 
              `🎉 Selamat! Anda telah menambahkan bot ke ${global.GROUPS_REQUIRED} grup.\n` +
              `Anda mendapatkan ${global.PREMIUM_COST} kredit!`
            );
          }
          
          await user.save();
        }
        
        await ctx.reply(
          `Terima kasih telah menambahkan saya ke grup ini!\n\n` +
          `Grup telah tercatat dan akan segera diverifikasi oleh admin.`
        );
      }
    } catch (error) {
      console.error('Error handling new chat members:', error);
    }
  }
}

module.exports = {
  handleCallbackQuery,
  handleNewChatMembers
};