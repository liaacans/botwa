const fs = require('fs');

global.prefix = '/';

global.namabot = '⚡ Dinaa Botz ⚡'
global.idowner = '8135269613'
global.apikeyhost = ``
global.domain = 'https://masvilxtheo.bokepp.biz.id',
global.plta ='ptla_Ht77DicVfevF04o3pIFlIOU23lM3Ed1WL14jNQhL4bn',
global.pltc ='ptlc_xqJ2gCWiaZK1M1o7DiBQVOPOFwOzTk30wYLO50hD8GO',
global.loc = '1', // Lokasi default
global.eggs = '15' // Egg default
global.nests = '5' // Nests Default

global.thumbnailPath = "https://img1.pixhost.to/images/7751/629368417_uploaded_image.jpg"
global.paket = "https://img1.pixhost.to/images/7751/629368417_uploaded_image.jpg"


global.mess = {
    wait: "⏳ Sabar ya... lagi diproses, jangan ditinggal dulu!",
    success: "✅ Mantap! Permintaan kamu berhasil diproses.",
    on: "🟢 Oke! Fitur ini sekarang aktif, silakan gunakan.",
    off: "🔴 Sip! Fitur ini dimatikan sementara.",
    text: "✍️ Ups! Kamu belum kasih teks, coba isi dulu ya.",
    link: "🔗 Hmmm... link-nya mana? Kirim dulu yang valid ya.",
    fitur: "⚠️ Wah, fitur ini lagi error. Sabar dulu atau lapor ke owner ya!",
    seller: "🛒 Eits! Fitur ini khusus buat Seller & Owner aja ya.",
    atmin: "🛡️ Maaf, fitur ini hanya dapat digunakan oleh Admin atau Owner!",
    private: "📩 Fitur ini cuma bisa dipakai di chat pribadi, kirim lewat private dong!",
    owner: "👑 Waduh! Cuma yang punya bot alias owner yang bisa akses ini.",
    admin: "🛑 Fitur ini hanya bisa digunakan oleh admin grup!",
    group: "👥 Fitur ini hanya bisa digunakan dalam grup!"
};