const fs = require('fs-extra');
const path = require('path');

async function setupProject() {
    console.log('Setting up Jasher Bot project...');
    
    // Create necessary directories
    const dirs = [
        'data',
        'temp',
        'src/commands',
        'src/handlers',
        'lib'
    ];
    
    for (const dir of dirs) {
        await fs.ensureDir(path.join(__dirname, dir));
        console.log(`Created directory: ${dir}`);
    }
    
    // Create .gitignore
    const gitignoreContent = `node_modules/
data/
temp/
.env
*.log
`;
    await fs.writeFile(path.join(__dirname, '.gitignore'), gitignoreContent);
    
    // Create environment template
    const envContent = `BOT_TOKEN=8198305874:AAHk3rqCM_-0kYlDvKoAuCaX3Yyi4lZQTKc
OWNER_ID=8135269613
`;
    await fs.writeFile(path.join(__dirname, '.env.example'), envContent);
    
    console.log(`
✅ Setup completed!

Next steps:
1. Edit config.js and set your BOT_TOKEN and OWNER_ID
2. Run 'npm install' to install dependencies
3. Run 'npm start' to start the bot

Bot features:
- Obfuscation with multiple algorithms
- Premium system with time-based access
- Group management with anti-spam features
- Broadcast functionality
- File sharing with restrictions
- Blacklist management

For support: @jasher_support
    `);
}

setupProject().catch(console.error);