const { handleStart } = require('./handlers');

function setupCommands(bot) {
    bot.start(async (ctx) => {
        await handleStart(ctx);
    });
    
    bot.command('help', async (ctx) => {
        await ctx.replyWithHTML(`
<b>Jasher Bot Help</b>

<b>Perintah yang tersedia:</b>
/start - Memulai bot dan menampilkan menu utama
/help - Menampilkan bantuan ini
/credit - Mengecek kredit Anda

<b>Cara menggunakan:</b>
1. Tambahkan bot ke 3 group untuk menjadi premium
2. Gunakan fitur share broadcast dengan mengklik menu Jasher Menu
3. Share pesan ke semua group yang telah ditambahkan

<b>Biaya:</b>
- Share Regular: 2 kredit
- Share VIP: 1 kredit

Untuk bantuan lebih lanjut, hubungi owner bot.
        `);
    });
    
    bot.command('credit', async (ctx) => {
        const { User } = require('../lib/database');
        const sender = ctx.from;
        const user = await User.findOne({ userId: sender.id });
        
        if (!user) {
            return await ctx.reply('User tidak ditemukan. Gunakan /start untuk memulai.');
        }
        
        await ctx.reply(`Sisa kredit Anda: ${user.credits}`);
    });
}

module.exports = { setupCommands };