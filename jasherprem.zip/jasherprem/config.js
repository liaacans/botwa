global.BOT_TOKEN = "8198305874:AAGhlBEYItkhH2mxD265kLIMXVEcWMiwkMM";
global.DEVELOPER = "@ginaabaikhati";
global.CHANNEL = "@yourchannel";
global.GROUP = "@yourgroup";

// Database configuration
global.db = {
  users: new Map(),
  groups: new Map(),
  premium: new Map(),
  blacklist: new Set(),
  autoShare: {
    enabled: false,
    interval: null
  }
};

// Simpan data secara periodik (dummy implementation)
setInterval(() => {
  // Simpan data ke file atau database
}, 30000);