const { Markup } = require('telegraf');
const db = require('../lib/database');
const { createMainMenu } = require('./utils');
const config = require('../config');

// Handler untuk command /start
function handleStart(ctx) {
    const user = db.addUser(ctx.from.id, ctx.from);
    const { message, keyboard } = createMainMenu(ctx, user);
    
    ctx.reply(message, keyboard);
}

// Handler untuk command /help
function handleHelp(ctx) {
    const helpMessage = `🤖 *BOT JASHER HELP*

*Perintah Umum:*
/start - Memulai bot
/help - Menampilkan bantuan
/credit - Cek kredit Anda
/share - Share pesan (kurang 2 kredit)

*Perintah Premium:*
/sharevip - Share pesan premium (lebih cepat)

*Perintah Owner:*
/broadcast - Broadcast ke semua user
/addprem - Tambah user premium
/delprem - Hapus user premium
/listprem - List user premium

Untuk menggunakan fitur share, Anda perlu menambahkan bot ke 3 group terlebih dahulu untuk mendapatkan 10 kredit.`;
    
    ctx.reply(helpMessage, { parse_mode: 'Markdown' });
}

// Handler untuk command /credit
function handleCredit(ctx) {
    const user = db.getUser(ctx.from.id);
    if (!user) {
        return ctx.reply('Anda belum terdaftar. Ketik /start untuk memulai.');
    }
    
    const groups = user.joinedGroups || [];
    const groupsNeeded = Math.max(0, 3 - groups.length);
    
    let message = `💰 *KREDIT ANDA*
    
Kredit: ${user.credits}
Group yang telah ditambahkan: ${groups.length}/3`;

    if (groupsNeeded > 0) {
        message += `\n\nAnda perlu menambahkan ${groupsNeeded} group lagi untuk mendapatkan 10 kredit tambahan.`;
    }
    
    ctx.reply(message, { parse_mode: 'Markdown' });
}

// Handler untuk command /share
function handleShare(ctx) {
    // Cek apakah di private chat
    if (ctx.chat.type !== 'private') {
        return ctx.reply('Fitur share hanya bisa digunakan di private chat. Silakan chat bot secara langsung.');
    }
    
    const user = db.getUser(ctx.from.id);
    if (!user) {
        return ctx.reply('Anda belum terdaftar. Ketik /start untuk memulai.');
    }
    
    // Cek apakah punya cukup kredit
    if (user.credits < config.CREDITS.SHARE_COST) {
        return ctx.reply(`Kredit Anda tidak cukup. Dibutuhkan ${config.CREDITS.SHARE_COST} kredit untuk share.`);
    }
    
    // Cek apakah ada pesan yang di-reply
    if (!ctx.message.reply_to_message) {
        return ctx.reply('Anda harus mereply pesan yang ingin di-share.');
    }
    
    // Kurangi kredit
    const success = db.deductCredits(ctx.from.id, config.CREDITS.SHARE_COST);
    if (!success) {
        return ctx.reply('Gagal mengurangi kredit. Silakan coba lagi.');
    }
    
    // Simpan broadcast
    const messageContent = ctx.message.reply_to_message;
    const messageId = Date.now().toString();
    db.addBroadcast(messageId, messageContent);
    
    // Kirim konfirmasi
    ctx.reply(`Pesan berhasil di-share! ${config.CREDITS.SHARE_COST} kredit telah dikurangi. Kredit Anda sekarang: ${user.credits - config.CREDITS.SHARE_COST}`);
}

// Handler untuk command /sharevip
function handleShareVip(ctx) {
    // Cek apakah di private chat
    if (ctx.chat.type !== 'private') {
        return ctx.reply('Fitur sharevip hanya bisa digunakan di private chat. Silakan chat bot secara langsung.');
    }
    
    // Cek apakah user premium
    if (!db.isPremiumUser(ctx.from.id)) {
        return ctx.reply('Anda bukan user premium. Hubungi owner untuk menjadi premium.');
    }
    
    // Cek apakah ada pesan yang di-reply
    if (!ctx.message.reply_to_message) {
        return ctx.reply('Anda harus mereply pesan yang ingin di-share.');
    }
    
    // Simpan broadcast
    const messageContent = ctx.message.reply_to_message;
    const messageId = `vip_${Date.now()}`;
    db.addBroadcast(messageId, messageContent);
    
    // Kirim konfirmasi
    ctx.reply('Pesan premium berhasil di-share! Pesan akan dikirim lebih cepat ke semua group.');
}

// Handler untuk command /broadcast (owner only)
function handleBroadcast(ctx) {
    if (ctx.from.id !== config.OWNER_ID) {
        return ctx.reply('Anda bukan owner bot!');
    }
    
    // Cek apakah ada pesan yang di-reply
    if (!ctx.message.reply_to_message) {
        return ctx.reply('Anda harus mereply pesan yang ingin di-broadcast.');
    }
    
    const messageContent = ctx.message.reply_to_message;
    const allUsers = db.getAllUsers();
    
    let successCount = 0;
    let failCount = 0;
    
    // Kirim ke semua user
    Object.keys(allUsers).forEach(userId => {
        try {
            ctx.telegram.copyMessage(userId, ctx.chat.id, messageContent.message_id);
            successCount++;
        } catch (error) {
            console.error(`Gagal mengirim broadcast ke user ${userId}:`, error);
            failCount++;
        }
    });
    
    ctx.reply(`Broadcast selesai! Berhasil: ${successCount}, Gagal: ${failCount}`);
}

// Handler untuk command /addprem (owner only)
function handleAddPrem(ctx) {
    if (ctx.from.id !== config.OWNER_ID) {
        return ctx.reply('Anda bukan owner bot!');
    }
    
    // Cek apakah ada user yang di-reply atau disebutkan
    let targetUserId;
    
    if (ctx.message.reply_to_message) {
        targetUserId = ctx.message.reply_to_message.from.id;
    } else if (ctx.message.text.split(' ').length > 1) {
        targetUserId = parseInt(ctx.message.text.split(' ')[1]);
    }
    
    if (!targetUserId || isNaN(targetUserId)) {
        return ctx.reply('Anda harus mereply pesan user atau menyertakan user ID.');
    }
    
    // Tambah user premium
    const success = db.addPremiumUser(targetUserId);
    if (success) {
        ctx.reply(`User ${targetUserId} berhasil ditambahkan ke premium.`);
    } else {
        ctx.reply(`User ${targetUserId} sudah premium.`);
    }
}

// Handler untuk command /delprem (owner only)
function handleDelPrem(ctx) {
    if (ctx.from.id !== config.OWNER_ID) {
        return ctx.reply('Anda bukan owner bot!');
    }
    
    // Cek apakah ada user yang di-reply atau disebutkan
    let targetUserId;
    
    if (ctx.message.reply_to_message) {
        targetUserId = ctx.message.reply_to_message.from.id;
    } else if (ctx.message.text.split(' ').length > 1) {
        targetUserId = parseInt(ctx.message.text.split(' ')[1]);
    }
    
    if (!targetUserId || isNaN(targetUserId)) {
        return ctx.reply('Anda harus mereply pesan user atau menyertakan user ID.');
    }
    
    // Hapus user premium
    const success = db.removePremiumUser(targetUserId);
    if (success) {
        ctx.reply(`User ${targetUserId} berhasil dihapus dari premium.`);
    } else {
        ctx.reply(`User ${targetUserId} bukan premium.`);
    }
}

// Handler untuk command /listprem (owner only)
function handleListPrem(ctx) {
    if (ctx.from.id !== config.OWNER_ID) {
        return ctx.reply('Anda bukan owner bot!');
    }
    
    const premiumUsers = db.getPremiumUsers();
    const allUsers = db.getAllUsers();
    
    if (premiumUsers.length === 0) {
        return ctx.reply('Tidak ada user premium.');
    }
    
    let message = '👑 *LIST USER PREMIUM*\n\n';
    
    premiumUsers.forEach(userId => {
        const user = allUsers[userId];
        if (user) {
            const username = user.username ? `@${user.username}` : 'No username';
            message += `• ${user.first_name} ${user.last_name || ''} (${username}) - ID: ${userId}\n`;
        } else {
            message += `• ID: ${userId} (User tidak ditemukan di database)\n`;
        }
    });
    
    ctx.reply(message, { parse_mode: 'Markdown' });
}

module.exports = {
    handleStart,
    handleHelp,
    handleCredit,
    handleShare,
    handleBroadcast,
    handleAddPrem,
    handleDelPrem,
    handleListPrem,
    handleShareVip
};