const { Telegraf } = require('telegraf');
require('./config');

const bot = new Telegraf(global.BOT_TOKEN);

// Import handlers
const setupCommands = require('./src/commands');
const setupHandlers = require('./src/handlers');

// Setup commands and handlers
setupCommands(bot);
setupHandlers(bot);

// Error handling
bot.catch((err, ctx) => {
  console.error(`Error for ${ctx.updateType}:`, err);
});

// Start bot
bot.launch().then(() => {
  console.log('Bot Jasher started!');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));