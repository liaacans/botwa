/*
Base Ori Rahman x Ginaa imupp

Sosmed media :
Ig : private
Tele : @tiaaxl
Wa : Privet
Yt : A. Aulia Rahman Official (@auliarhmanproduction)


Thanks too::
Allah swt
Nabi Muhammad
Aulia Rahman
Ginaa Imupp

Create Bot Tokennya Di
@BotFather
Cek id tele nya Di
@CekID_tele_bot

Note : don't remove copyright of this script!
*/

const db = require('../lib/database');

function setupCommands(bot) {
    // Start command
    bot.command('start', (ctx) => {
        const user = ctx.from;
        db.createUser(user, function(err) {
            if (err) {
                console.error('Error creating user:', err);
            }
        });

        let message = `👋 Hello ${user.first_name}! Welcome to Jasher Premium Bot.\n\n`;
        message += `🌟 Features:\n`;
        message += `- Add me to your group to get 10 free credits\n`;
        message += `- Share messages to all groups (1 credit per broadcast)\n`;
        message += `- Check your credit balance\n\n`;
        message += `Use commands:\n`;
        message += `/credit - Check your credit balance\n`;
        message += `/share - Share a message to all groups`;

        ctx.reply(message);
    });

    // Credit command
    bot.command('credit', (ctx) => {
        const userId = ctx.from.id;
        
        db.getUser(userId, (err, user) => {
            if (err) {
                console.error('Error getting user:', err);
                return ctx.reply('❌ Error checking your credit. Please try again.');
            }
            
            if (!user) {
                return ctx.reply('You are not registered yet. Please use /start first.');
            }
            
            ctx.reply(`💰 Your current credit: ${user.credit}`);
        });
    });

    // Share command
    bot.command('share', async (ctx) => {
        // Check if in private chat
        if (ctx.chat.type !== 'private') {
            return ctx.reply('❌ Please use this command in private chat with the bot.');
        }

        const userId = ctx.from.id;
        let messageText = '';

        // Check if replying to a message
        if (ctx.message.reply_to_message) {
            const repliedMessage = ctx.message.reply_to_message;
            
            // Handle different message types
            if (repliedMessage.text) {
                messageText = repliedMessage.text;
            } else if (repliedMessage.caption) {
                messageText = repliedMessage.caption;
            } else {
                return ctx.reply('❌ Only text messages can be shared.');
            }
        } else {
            // Get text from command
            const args = ctx.message.text.split(' ');
            args.shift(); // Remove the command
            messageText = args.join(' ');
            
            if (!messageText.trim()) {
                return ctx.reply('❌ Please provide a message to share or reply to a message.');
            }
        }

        // Check user credit
        db.getUser(userId, (err, user) => {
            if (err) {
                console.error('Error getting user:', err);
                return ctx.reply('❌ Error processing your request. Please try again.');
            }
            
            if (!user || user.credit < 1) {
                return ctx.reply('❌ You don\'t have enough credit. Add the bot to a group to get 10 free credits.');
            }

            // Get all groups
            db.getAllGroups((err, groups) => {
                if (err) {
                    console.error('Error getting groups:', err);
                    return ctx.reply('❌ Error getting groups. Please try again.');
                }

                if (groups.length === 0) {
                    return ctx.reply('❌ No groups available for broadcasting. Add the bot to a group first.');
                }

                // Send message to all groups
                let successCount = 0;
                let failCount = 0;
                
                groups.forEach(group => {
                    try {
                        ctx.telegram.sendMessage(group.group_id, `${messageText}`)
                            .then(() => {
                                successCount++;
                            })
                            .catch(err => {
                                console.error(`Error sending to group ${group.group_id}:`, err);
                                failCount++;
                            });
                    } catch (error) {
                        console.error(`Error sending to group ${group.group_id}:`, error);
                        failCount++;
                    }
                });

                // Update user credit and add to broadcast history
                db.updateUserCredit(userId, -1, (err) => {
                    if (err) {
                        console.error('Error updating credit:', err);
                    }
                });
                
                db.addBroadcast(userId, messageText, (err) => {
                    if (err) {
                        console.error('Error adding broadcast:', err);
                    }
                });

                // Send result to user
                setTimeout(() => {
                    ctx.reply(`✅ Broadcast completed!\n\n` +
                             `Success: ${successCount} groups\n` +
                             `Failed: ${failCount} groups\n` +
                             `Sisa kredit: ${user.credit - 1}`);
                }, 2000);
            });
        });
    });

    // Admin broadcast to all users
    bot.command('admin_broadcast', (ctx) => {
        if (ctx.from.id.toString() !== global.ADMIN_ID) {
            return ctx.reply('❌ This command is only available for admins.');
        }

        // Get message text
        const args = ctx.message.text.split(' ');
        args.shift(); // Remove the command
        const messageText = args.join(' ');
        
        if (!messageText.trim()) {
            return ctx.reply('❌ Please provide a message to broadcast.');
        }

        // Get all users
        db.getAllUsers((err, users) => {
            if (err) {
                console.error('Error getting users:', err);
                return ctx.reply('❌ Error getting users. Please try again.');
            }

            if (users.length === 0) {
                return ctx.reply('❌ No users available for broadcasting.');
            }

            // Send message to all users
            let successCount = 0;
            let failCount = 0;
            
            users.forEach(user => {
                try {
                    ctx.telegram.sendMessage(user.user_id, `📢 Admin Broadcast:\n\n${messageText}`)
                        .then(() => {
                            successCount++;
                        })
                        .catch(err => {
                            console.error(`Error sending to user ${user.user_id}:`, err);
                            failCount++;
                        });
                } catch (error) {
                    console.error(`Error sending to user ${user.user_id}:`, error);
                    failCount++;
                }
            });

            // Send result to admin
            setTimeout(() => {
                ctx.reply(`✅ Admin broadcast completed!\n\n` +
                         `Success: ${successCount} users\n` +
                         `Failed: ${failCount} users`);
            }, 2000);
        });
    });
}

module.exports = { setupCommands };