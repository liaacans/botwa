const { Markup } = require('telegraf');
const { log, isPremium, getPremiumRemaining } = require('../lib/utils');

// Fungsi untuk menambah premium user
function addPremium(userId, days, addedBy = 'system') {
  const expiry = new Date();
  expiry.setDate(expiry.getDate() + parseInt(days));
  
  global.premiumUsers.set(userId, {
    expiry: expiry.toISOString(),
    addedBy: addedBy,
    addedAt: new Date().toISOString()
  });
  
  require('../lib/utils').savePremiumUsers(global.premiumUsers);
  log(`Added premium for user ${userId} for ${days} days`);
  
  return true;
}

// Fungsi untuk menghapus premium user
function removePremium(userId) {
  const success = global.premiumUsers.delete(userId);
  
  if (success) {
    require('../lib/utils').savePremiumUsers(global.premiumUsers);
    log(`Removed premium for user ${userId}`);
  }
  
  return success;
}

// Fungsi untuk mendapatkan daftar premium users
function getPremiumList() {
  const list = [];
  
  for (const [userId, userData] of global.premiumUsers.entries()) {
    const remaining = getPremiumRemaining(userId);
    if (remaining !== "Tidak premium") {
      list.push({
        userId: userId,
        expiry: userData.expiry,
        addedBy: userData.addedBy,
        remaining: remaining
      });
    }
  }
  
  return list;
}

// Handler untuk command premium
async function handlePremiumCommand(ctx) {
  const userId = ctx.from.id;
  const isUserPremium = isPremium(userId);
  const remaining = getPremiumRemaining(userId);
  
  let message = `╭─❒ 「 Status Premium 」 \n`;
  
  if (isUserPremium) {
    message += `├ Status: ✅ Premium\n`;
    message += `├ Sisa waktu: ${remaining}\n`;
    message += `├ Fitur: ShareVIP, Priority Access\n`;
    message += `├ Harga: Rp ${global.PREMIUM_PRICE.toLocaleString()}/bulan\n`;
  } else {
    message += `├ Status: ❌ Regular\n`;
    message += `├ Trial: ${global.FREE_TRIAL_DAYS} hari gratis\n`;
    message += `├ Fitur: ShareFree, Standard Access\n`;
    message += `├ Upgrade: /buypremium\n`;
  }
  
  message += `╰❒\nGunakan /buypremium untuk upgrade ke premium!`;
  
  await ctx.replyWithPhoto(
    'https://f.top4top.io/p_3530xky9e4.jpg',
    {
      caption: message,
      parse_mode: "Markdown",
      ...Markup.inlineKeyboard([
        [Markup.button.callback('🛒 Beli Premium', 'buypremium')],
        [Markup.button.callback('📋 List Premium', 'listpremium')],
        [Markup.button.callback('🔙 Kembali', 'menu')]
      ])
    }
  );
}

// Handler untuk command buypremium
async function handleBuyPremium(ctx) {
  const userId = ctx.from.id;
  
  if (isPremium(userId)) {
    return ctx.reply('❌ Anda sudah premium!');
  }
  
  const message = `╭─❒ 「 Beli Premium 」 
├ Paket: 1 Bulan Premium
├ Harga: Rp ${global.PREMIUM_PRICE.toLocaleString()}
├ Fitur: ShareVIP, Priority Access
├ Support: @ginaaforyou
╰❒
Silahkan hubungi owner untuk pembelian!`;
  
  await ctx.replyWithPhoto(
    'https://f.top4top.io/p_3530xky9e4.jpg',
    {
      caption: message,
      parse_mode: "Markdown",
      ...Markup.inlineKeyboard([
        [Markup.button.url('💬 Hubungi Owner', 'https://t.me/ginaaforyou')],
        [Markup.button.callback('🔙 Kembali', 'premium')]
      ])
    }
  );
}

module.exports = {
  addPremium,
  removePremium,
  getPremiumList,
  handlePremiumCommand,
  handleBuyPremium
};