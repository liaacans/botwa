const { Telegraf, session } = require('telegraf');
require('./config');
const { loadPremiumUsers, loadUserGroups, loadBlacklistedGroups } = require('./lib/utils');
const { loadUserGroups: loadUserGroupsDB, loadBlacklistedGroups: loadBlacklistedGroupsDB } = require('./lib/database');
const handlers = require('./src/handlers');

// Load data
loadPremiumUsers();
loadUserGroupsDB();
loadBlacklistedGroupsDB();

// Inisialisasi bot
const bot = new Telegraf(BOT_TOKEN);

// Middleware session
bot.use(session());

// Command handlers
bot.start(handlers.handleStart);
bot.command('tourl', handlers.handleToUrl);

// Event handlers
bot.on('new_chat_members', handlers.handleNewChatMembers);
bot.on('left_chat_member', handlers.handleLeftChatMember);
bot.on('callback_query', handlers.handleCallbackQuery);
bot.on('message', (ctx, next) => {
    if (ctx.message.reply_to_message) {
        handlers.handleReply(ctx);
    }
    next();
});

// Error handling
bot.catch((err, ctx) => {
    console.error(`Error for ${ctx.updateType}:`, err);
    ctx.reply('Terjadi error! Silahkan coba lagi.');
});

// Jalankan bot
bot.launch().then(() => {
    console.log('Bot Jasher Premium berhasil dijalankan!');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));