const { Telegraf } = require('telegraf');
const Imap = require('imap');
const { simpleParser } = require('mailparser');
const cron = require('node-cron');
const nodemailer = require('nodemailer');
const { inspect } = require('util');

// Konfigurasi Bot Telegram
const BOT_TOKEN = '7569137877:AAHnvva5p9SFclkDpDio8QcJsSfbzlrK6IY'; // Ganti dengan token bot Anda
const ALLOWED_GROUP_ID = '-1002793801544'; // ID grup yang diizinkan

// Konfigurasi IMAP (Menerima Email)
const imapConfig = {
  user: 'nokosmerah@buatkamu.web.id',
  password: 'Grki6Vv1gdlA',
  host: 'newpinwheel.indowebsite.net',
  port: 993,
  tls: true,
  tlsOptions: { rejectUnauthorized: false }
};

// Konfigurasi SMTP (Mengirim Email)
const smtpConfig = {
  host: 'newpinwheel.indowebsite.net',
  port: 465,
  secure: true,
  auth: {
    user: 'nokosmerah@buatkamu.web.id',
    pass: 'Grki6Vv1gdlA'
  }
};

// Inisialisasi Bot
const bot = new Telegraf(BOT_TOKEN);
const transporter = nodemailer.createTransporter(smtpConfig);

// Objek untuk menyimpan status email yang sudah diproses
const processedEmails = new Set();

// Fungsi untuk memeriksa email baru
function checkNewEmails() {
  console.log('Memeriksa email baru...');
  
  const imap = new Imap(imapConfig);
  
  imap.once('ready', () => {
    console.log('Terhubung ke server IMAP');
    
    imap.openBox('INBOX', true, (err, box) => {
      if (err) {
        console.error('Error membuka mailbox:', err);
        imap.end();
        return;
      }
      
      console.log('Mailbox terbuka, mencari email yang belum dibaca...');
      
      // Cari email yang belum dibaca
      imap.search(['UNSEEN'], (err, results) => {
        if (err) {
          console.error('Error mencari email:', err);
          imap.end();
          return;
        }
        
        console.log(`Ditemukan ${results.length} email baru`);
        
        if (results.length === 0) {
          imap.end();
          return;
        }
        
        // Ambil setiap email yang belum dibaca
        const fetch = imap.fetch(results, { bodies: '' });
        
        fetch.on('message', (msg, seqno) => {
          console.log(`Memproses email #${seqno}`);
          
          msg.on('body', async (stream) => {
            try {
              const parsed = await simpleParser(stream);
              
              // Periksa apakah email sudah diproses sebelumnya
              const emailId = parsed.messageId || `${parsed.from.text}-${parsed.date}-${parsed.subject}`;
              if (processedEmails.has(emailId)) {
                console.log(`Email ${emailId} sudah diproses sebelumnya, dilewati`);
                return;
              }
              
              // Tandai sebagai sudah diproses
              processedEmails.add(emailId);
              
              console.log('Email baru diterima:', {
                from: parsed.from.text,
                subject: parsed.subject,
                date: parsed.date,
                id: emailId
              });
              
              // Format pesan untuk dikirim ke Telegram
              let message = `📧 *Email Baru Diterima* 📧\n\n`;
              message += `*Dari:* ${parsed.from.text}\n`;
              message += `*Kepada:* ${parsed.to.text}\n`;
              message += `*Tanggal:* ${parsed.date}\n`;
              message += `*Subjek:* ${parsed.subject}\n\n`;
              
              if (parsed.text) {
                const textPreview = parsed.text.length > 300 
                  ? parsed.text.substring(0, 300) + '...' 
                  : parsed.text;
                message += `*Isi:*\n${textPreview}\n\n`;
              }
              
              // Kirim notifikasi ke grup Telegram
              try {
                await bot.telegram.sendMessage(ALLOWED_GROUP_ID, message, { parse_mode: 'Markdown' });
                console.log('Notifikasi email terkirim ke grup Telegram');
              } catch (error) {
                console.error('Gagal mengirim notifikasi ke Telegram:', error);
              }
              
            } catch (error) {
              console.error('Error parsing email:', error);
            }
          });
        });
        
        fetch.once('error', (err) => {
          console.error('Error fetching emails:', err);
        });
        
        fetch.once('end', () => {
          console.log('Selesai memproses email');
          imap.end();
        });
      });
    });
  });
  
  imap.once('error', (err) => {
    console.error('Error koneksi IMAP:', err);
  });
  
  imap.once('end', () => {
    console.log('Koneksi IMAP ditutup');
  });
  
  imap.connect();
}

// Jadwalkan pengecekan email setiap 1 menit
cron.schedule('*/1 * * * *', () => {
  console.log('Jadwal pengecekan email berjalan');
  checkNewEmails();
});

// Command untuk mengirim email
bot.command('sendmail', async (ctx) => {
  console.log('Command sendmail diterima');
  
  // Periksa apakah perintah berasal dari grup yang diizinkan
  if (ctx.chat.id.toString() !== ALLOWED_GROUP_ID) {
    console.log(`Perintah dari grup tidak diizinkan: ${ctx.chat.id}`);
    await ctx.reply('Bot hanya dapat digunakan di grup tertentu.');
    return;
  }
  
  // Parsing pesan: /sendmail recipient@example.com Subject Pesan tubuh email
  const messageText = ctx.message.text;
  const parts = messageText.split(' ');
  
  if (parts.length < 4) {
    await ctx.reply('Format salah. Gunakan: /sendmail recipient@example.com "Subject" "Pesan"');
    return;
  }
  
  const recipient = parts[1];
  const subject = parts[2];
  let body = parts.slice(3).join(' ');
  
  // Hapus tanda kutip jika ada
  if (subject.startsWith('"') && subject.endsWith('"')) {
    subject = subject.slice(1, -1);
  }
  if (body.startsWith('"') && body.endsWith('"')) {
    body = body.slice(1, -1);
  }
  
  console.log('Mengirim email ke:', recipient);
  
  try {
    // Kirim email
    const info = await transporter.sendMail({
      from: '"Telegram Bot" <nokosmerah@buatkamu.web.id>',
      to: recipient,
      subject: subject,
      text: body
    });
    
    console.log('Email terkirim:', info.messageId);
    await ctx.reply(`✅ Email berhasil dikirim ke ${recipient}`);
    
  } catch (error) {
    console.error('Error mengirim email:', error);
    await ctx.reply(`❌ Gagal mengirim email: ${error.message}`);
  }
});

// Handler ketika bot ditambahkan ke grup
bot.on('chat_member', async (ctx) => {
  const chatId = ctx.chat.id.toString();
  const newStatus = ctx.update.chat_member.new_chat_member.status;
  
  console.log(`Bot ditambahkan ke grup: ${chatId}, status: ${newStatus}`);
  
  // Jika bot ditambahkan ke grup yang tidak diizinkan
  if (chatId !== ALLOWED_GROUP_ID && newStatus === 'member') {
    console.log(`Bot ditambahkan ke grup tidak diizinkan: ${chatId}, meninggalkan grup...`);
    
    try {
      await ctx.leaveChat();
      console.log('Berhasil meninggalkan grup tidak diizinkan');
    } catch (error) {
      console.error('Gagal meninggalkan grup:', error);
    }
  }
});

// Handler untuk pesan selain command
bot.on('message', async (ctx) => {
  // Abaikan pesan yang bukan dari grup yang diizinkan
  if (ctx.chat.id.toString() !== ALLOWED_GROUP_ID) {
    console.log(`Pesan dari grup tidak diizinkan: ${ctx.chat.id}`);
    return;
  }
  
  // Jika ada balasan ke pesan bot tentang email, tangani sebagai balasan email
  if (ctx.message.reply_to_message && ctx.message.reply_to_message.text.includes('Email Baru Diterima')) {
    console.log('Balasan untuk email diterima');
    
    // Ekstrak alamat email dari pesan asli
    const originalMessage = ctx.message.reply_to_message.text;
    const fromLine = originalMessage.split('\n').find(line => line.startsWith('*Dari:*'));
    
    if (!fromLine) {
      await ctx.reply('Tidak dapat menemukan pengirim email asli.');
      return;
    }
    
    const emailAddress = fromLine.replace('*Dari:*', '').trim();
    const replyText = ctx.message.text;
    
    console.log('Membalas email ke:', emailAddress);
    
    try {
      // Kirim balasan email
      const info = await transporter.sendMail({
        from: '"Telegram Bot" <nokosmerah@buatkamu.web.id>',
        to: emailAddress,
        subject: 'Re: Email dari Telegram',
        text: replyText
      });
      
      console.log('Balasan email terkirim:', info.messageId);
      await ctx.reply(`✅ Balasan email berhasil dikirim ke ${emailAddress}`);
      
    } catch (error) {
      console.error('Error mengirim balasan email:', error);
      await ctx.reply(`❌ Gagal mengirim balasan email: ${error.message}`);
    }
  }
});

// Handle errors
bot.catch((err, ctx) => {
  console.error(`Error untuk update ${ctx.updateType}:`, err);
});

// Jalankan bot
console.log('Bot sedang dimulai...');
bot.launch().then(() => {
  console.log('Bot berhasil dijalankan');
  // Jalankan pengecekan email pertama kali
  checkNewEmails();
}).catch(err => {
  console.error('Gagal menjalankan bot:', err);
});

// Enable graceful stop
process.once('SIGINT', () => {
  console.log('Menghentikan bot...');
  bot.stop('SIGINT');
});

process.once('SIGTERM', () => {
  console.log('Menghentikan bot...');
  bot.stop('SIGTERM');
});