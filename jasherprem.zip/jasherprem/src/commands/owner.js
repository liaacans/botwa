const { Telegraf, Markup } = require('telegraf');
const moment = require('moment-timezone');
const { isOwner, runtime, log, addPremiumTime } = require('../../lib/functions');
const db = require('../../lib/database');

module.exports = (bot, users, groups, premium, blacklist) => {
    
    // Owner Menu
    bot.action('owner_menu', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.replyWithMarkdown('❌ *Error:* Hanya owner yang bisa mengakses menu ini!');
        }

        const ownerText = `
╭─❒ 「 👑 OWNER MENU 」 
├ Total Users : ${users.size}
├ Total Groups : ${groups.size}
├ Premium Users : ${premium.size}
├ Blacklisted : ${blacklist.size}
╰❒
Pilih opsi owner:`;

        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('📊 Broadcast', 'owner_broadcast')],
            [Markup.button.callback('⭐ Add Premium', 'add_premium')],
            [Markup.button.callback('🗑️ Del Premium', 'del_premium')],
            [Markup.button.callback('⚫ Add Blacklist', 'add_blacklist')],
            [Markup.button.callback('⚪ Del Blacklist', 'del_blacklist')],
            [Markup.button.callback('📋 List Premium', 'owner_list_premium')],
            [Markup.button.callback('📜 List Blacklist', 'list_blacklist')],
            [Markup.button.callback('🏠 List Groups', 'list_groups')],
            [Markup.button.callback('🔙 Kembali', 'main_menu')]
        ]);

        await ctx.editMessageCaption(ownerText, {
            parse_mode: 'Markdown',
            ...keyboard
        });
    });

    // Add Premium
    bot.action('add_premium', async (ctx) => {
        if (!isOwner(ctx.from.id)) return;
        
        await ctx.replyWithMarkdown(`
╭━━━「 ⭐ ADD PREMIUM 」━━━⬣
│ Format: /addprem [user_id] [hari]
│ Contoh: /addprem 123456789 30
│ 
│ Note: Premium akan ditambahkan ke user
╰━━━━━━━━━━━━━━━━⬣`);
    });

    // Command addprem
    bot.command('addprem', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.replyWithMarkdown('❌ *Error:* Hanya owner yang bisa menggunakan command ini!');
        }

        const args = ctx.message.text.split(' ');
        if (args.length < 3) {
            return ctx.replyWithMarkdown('❌ *Format:* /addprem [user_id] [hari]\nContoh: /addprem 123456789 30');
        }

        const userId = args[1];
        const days = parseInt(args[2]);

        if (isNaN(days) || days < 1) {
            return ctx.replyWithMarkdown('❌ *Error:* Jumlah hari harus angka positif!');
        }

        try {
            const expiry = addPremiumTime(userId, days, premium);
            await db.savePremium(premium);
            
            const expiryDate = moment(expiry).tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss');
            
            await ctx.replyWithMarkdown(`
╭━━━「 ✅ PREMIUM DITAMBAHKAN 」━━━⬣
│ User ID : ${userId}
│ Durasi : ${days} hari
│ Expiry : ${expiryDate}
│ Status : ✅ Berhasil
╰━━━━━━━━━━━━━━━━⬣`);

            // Notify user
            try {
                await ctx.telegram.sendMessage(userId, `
╭━━━「 🎉 PREMIUM AKTIF 」━━━⬣
│ Selamat! Premium Anda telah diaktifkan
│ oleh owner selama ${days} hari.
│ 
│ Expiry: ${expiryDate}
│ Nikmati fitur premium!
╰━━━━━━━━━━━━━━━━⬣`);
            } catch (error) {
                log(`Cannot notify user ${userId}`, error);
            }

        } catch (error) {
            await ctx.replyWithMarkdown('❌ *Error:* Gagal menambahkan premium!');
        }
    });

    // Del Premium
    bot.action('del_premium', async (ctx) => {
        if (!isOwner(ctx.from.id)) return;
        
        await ctx.replyWithMarkdown(`
╭━━━「 🗑️ DEL PREMIUM 」━━━⬣
│ Format: /delprem [user_id]
│ Contoh: /delprem 123456789
│ 
│ Note: Premium user akan dihapus
╰━━━━━━━━━━━━━━━━⬣`);
    });

    // Command delprem
    bot.command('delprem', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.replyWithMarkdown('❌ *Error:* Hanya owner yang bisa menggunakan command ini!');
        }

        const args = ctx.message.text.split(' ');
        if (args.length < 2) {
            return ctx.replyWithMarkdown('❌ *Format:* /delprem [user_id]\nContoh: /delprem 123456789');
        }

        const userId = args[1];

        if (!premium.has(userId)) {
            return ctx.replyWithMarkdown('❌ *Error:* User tidak memiliki premium!');
        }

        premium.delete(userId);
        await db.savePremium(premium);

        await ctx.replyWithMarkdown(`
╭━━━「 ✅ PREMIUM DIHAPUS 」━━━⬣
│ User ID : ${userId}
│ Status : ✅ Berhasil dihapus
╰━━━━━━━━━━━━━━━━⬣`);

        // Notify user
        try {
            await ctx.telegram.sendMessage(userId, `
╭━━━「 ⚠️ PREMIUM DIBATALKAN 」━━━⬣
│ Premium Anda telah dibatalkan oleh owner.
│ 
│ Terima kasih telah menggunakan jasher bot.
╰━━━━━━━━━━━━━━━━⬣`);
        } catch (error) {
            log(`Cannot notify user ${userId}`, error);
        }
    });

    // List Premium (Owner)
    bot.action('owner_list_premium', async (ctx) => {
        if (!isOwner(ctx.from.id)) return;

        if (premium.size === 0) {
            return ctx.replyWithMarkdown('❌ *Tidak ada user premium!*');
        }

        let premiumList = '╭─❒ 「 📋 LIST PREMIUM USER 」 \n';
        let count = 0;
        
        for (const [userId, data] of premium) {
            if (count >= 20) {
                premiumList += '├ ... dan ' + (premium.size - 20) + ' user lainnya\n';
                break;
            }
            
            const expiryDate = moment(data.expiry).tz('Asia/Jakarta').format('DD/MM/YY');
            const remaining = moment.duration(data.expiry - Date.now()).humanize();
            
            premiumList += `├ ${userId} - ${data.days}hr (${expiryDate}) - ${remaining}\n`;
            count++;
        }
        premiumList += '╰❒';

        await ctx.replyWithMarkdown(premiumList);
    });

    // Add Blacklist
    bot.action('add_blacklist', async (ctx) => {
        if (!isOwner(ctx.from.id)) return;
        
        await ctx.replyWithMarkdown(`
╭━━━「 ⚫ ADD BLACKLIST 」━━━⬣
│ Format: /addbl [user_id/group_id]
│ Contoh: /addbl 123456789
│ 
│ Note: User/group akan diblacklist
╰━━━━━━━━━━━━━━━━⬣`);
    });

    // Command addbl
    bot.command('addbl', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.replyWithMarkdown('❌ *Error:* Hanya owner yang bisa menggunakan command ini!');
        }

        const args = ctx.message.text.split(' ');
        if (args.length < 2) {
            return ctx.replyWithMarkdown('❌ *Format:* /addbl [user_id/group_id]\nContoh: /addbl 123456789');
        }

        const targetId = args[1];
        blacklist.add(targetId);
        await db.saveBlacklist(blacklist);

        await ctx.replyWithMarkdown(`
╭━━━「 ✅ BLACKLIST DITAMBAHKAN 」━━━⬣
│ Target ID : ${targetId}
│ Status : ✅ Berhasil diblacklist
╰━━━━━━━━━━━━━━━━⬣`);
    });

    // Del Blacklist
    bot.action('del_blacklist', async (ctx) => {
        if (!isOwner(ctx.from.id)) return;
        
        await ctx.replyWithMarkdown(`
╭━━━「 ⚪ DEL BLACKLIST 」━━━⬣
│ Format: /delbl [user_id/group_id]
│ Contoh: /delbl 123456789
│ 
│ Note: User/group akan dihapus dari blacklist
╰━━━━━━━━━━━━━━━━⬣`);
    });

    // Command delbl
    bot.command('delbl', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.replyWithMarkdown('❌ *Error:* Hanya owner yang bisa menggunakan command ini!');
        }

        const args = ctx.message.text.split(' ');
        if (args.length < 2) {
            return ctx.replyWithMarkdown('❌ *Format:* /delbl [user_id/group_id]\nContoh: /delbl 123456789');
        }

        const targetId = args[1];
        
        if (!blacklist.has(targetId)) {
            return ctx.replyWithMarkdown('❌ *Error:* Target tidak ada dalam blacklist!');
        }

        blacklist.delete(targetId);
        await db.saveBlacklist(blacklist);

        await ctx.replyWithMarkdown(`
╭━━━「 ✅ BLACKLIST DIHAPUS 」━━━⬣
│ Target ID : ${targetId}
│ Status : ✅ Berhasil dihapus
╰━━━━━━━━━━━━━━━━⬣`);
    });

    // List Blacklist
    bot.action('list_blacklist', async (ctx) => {
        if (!isOwner(ctx.from.id)) return;

        if (blacklist.size === 0) {
            return ctx.replyWithMarkdown('✅ *Tidak ada yang diblacklist!*');
        }

        let blacklistText = '╭─❒ 「 📜 LIST BLACKLIST 」 \n';
        let count = 0;
        
        for (const targetId of blacklist) {
            if (count >= 30) {
                blacklistText += '├ ... dan ' + (blacklist.size - 30) + ' target lainnya\n';
                break;
            }
            blacklistText += `├ ${targetId}\n`;
            count++;
        }
        blacklistText += '╰❒';

        await ctx.replyWithMarkdown(blacklistText);
    });

    // List Groups
    bot.action('list_groups', async (ctx) => {
        if (!isOwner(ctx.from.id)) return;

        if (groups.size === 0) {
            return ctx.replyWithMarkdown('❌ *Tidak ada group yang terdaftar!*');
        }

        let groupsText = '╭─❒ 「 🏠 LIST GROUPS AKTIF 」 \n';
        let count = 0;
        
        for (const [groupId, groupData] of groups) {
            if (count >= 15) {
                groupsText += '├ ... dan ' + (groups.size - 15) + ' group lainnya\n';
                break;
            }
            
            const memberCount = groupData.members ? groupData.members.length : 0;
            const active = groupData.active ? '✅' : '❌';
            
            groupsText += `├ ${active} ${groupId} - ${memberCount} members\n`;
            count++;
        }
        groupsText += '╰❒';

        await ctx.replyWithMarkdown(groupsText);
    });

    // Command listgroups
    bot.command('listgroups', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.replyWithMarkdown('❌ *Error:* Hanya owner yang bisa menggunakan command ini!');
        }

        if (groups.size === 0) {
            return ctx.replyWithMarkdown('❌ *Tidak ada group yang terdaftar!*');
        }

        let groupsText = '╭─❒ 「 🏠 LIST GROUPS AKTIF 」 \n';
        let activeCount = 0;
        let inactiveCount = 0;
        
        for (const [groupId, groupData] of groups) {
            if (groupData.active) {
                activeCount++;
                const memberCount = groupData.members ? groupData.members.length : 0;
                groupsText += `├ ✅ ${groupId} - ${memberCount} members\n`;
            } else {
                inactiveCount++;
            }
        }
        
        groupsText += `├ Total Active: ${activeCount}\n`;
        groupsText += `├ Total Inactive: ${inactiveCount}\n`;
        groupsText += `├ Total Groups: ${groups.size}\n`;
        groupsText += '╰❒';

        await ctx.replyWithMarkdown(groupsText);
    });

    // Broadcast to all users
    bot.action('owner_broadcast', async (ctx) => {
        if (!isOwner(ctx.from.id)) return;
        
        await ctx.replyWithMarkdown(`
╭━━━「 📊 BROADCAST 」━━━⬣
│ Format: /bc [pesan]
│ Contoh: /bc Hello semua users!
│ 
│ Atau reply pesan dengan /bc
│ Note: Broadcast ke semua user
╰━━━━━━━━━━━━━━━━⬣`);
    });

    // Broadcast command
    bot.command('bc', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.replyWithMarkdown('❌ *Error:* Hanya owner yang bisa menggunakan command ini!');
        }

        let messageText = '';
        
        if (ctx.message.reply_to_message) {
            // Broadcast replied message
            const allUsers = Array.from(users);
            let success = 0;
            let failed = 0;

            const progressMsg = await ctx.replyWithMarkdown('🔄 *Memulai broadcast...*');

            for (const userId of allUsers) {
                try {
                    await ctx.telegram.copyMessage(
                        userId, 
                        ctx.chat.id, 
                        ctx.message.reply_to_message.message_id
                    );
                    success++;
                } catch (error) {
                    failed++;
                    users.delete(userId); // Remove invalid users
                }
                
                // Update progress every 50 users
                if ((success + failed) % 50 === 0) {
                    await ctx.telegram.editMessageText(
                        ctx.chat.id,
                        progressMsg.message_id,
                        null,
                        `🔄 *Broadcast Progress*\nBerhasil: ${success}\nGagal: ${failed}\nTotal: ${allUsers.length}`,
                        { parse_mode: 'Markdown' }
                    );
                }
            }

            await db.saveUsers(users);
            
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                progressMsg.message_id,
                null,
                `✅ *Broadcast Selesai!*\nBerhasil: ${success}\nGagal: ${failed}\nTotal: ${allUsers.length}`,
                { parse_mode: 'Markdown' }
            );

        } else {
            // Broadcast text message
            const args = ctx.message.text.split(' ');
            if (args.length < 2) {
                return ctx.replyWithMarkdown('❌ *Format:* /bc [pesan]\nContoh: /bc Hello semua!');
            }

            messageText = args.slice(1).join(' ');
            const allUsers = Array.from(users);
            let success = 0;
            let failed = 0;

            const progressMsg = await ctx.replyWithMarkdown('🔄 *Memulai broadcast...*');

            for (const userId of allUsers) {
                try {
                    await ctx.telegram.sendMessage(userId, messageText);
                    success++;
                } catch (error) {
                    failed++;
                    users.delete(userId);
                }
                
                if ((success + failed) % 50 === 0) {
                    await ctx.telegram.editMessageText(
                        ctx.chat.id,
                        progressMsg.message_id,
                        null,
                        `🔄 *Broadcast Progress*\nBerhasil: ${success}\nGagal: ${failed}\nTotal: ${allUsers.length}`,
                        { parse_mode: 'Markdown' }
                    );
                }
            }

            await db.saveUsers(users);
            
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                progressMsg.message_id,
                null,
                `✅ *Broadcast Selesai!*\nBerhasil: ${success}\nGagal: ${failed}\nTotal: ${allUsers.length}`,
                { parse_mode: 'Markdown' }
            );
        }
    });

    // Command untuk menghapus group yang tidak aktif
    bot.command('cleangroups', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.replyWithMarkdown('❌ *Error:* Hanya owner yang bisa menggunakan command ini!');
        }

        let removedCount = 0;
        const totalBefore = groups.size;

        for (const [groupId, groupData] of groups) {
            if (!groupData.active) {
                groups.delete(groupId);
                removedCount++;
            }
        }

        await db.saveGroups(groups);

        await ctx.replyWithMarkdown(`
╭━━━「 🧹 CLEAN GROUPS 」━━━⬣
│ Sebelum : ${totalBefore} groups
│ Dihapus : ${removedCount} groups
│ Sesudah : ${groups.size} groups
│ Status : ✅ Berhasil
╰━━━━━━━━━━━━━━━━⬣`);
    });

    // Command untuk mengecek statistik
    bot.command('stats', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.replyWithMarkdown('❌ *Error:* Hanya owner yang bisa menggunakan command ini!');
        }

        const activeGroups = Array.from(groups.values()).filter(g => g.active).length;
        const premiumActive = Array.from(premium.values()).filter(p => p.expiry > Date.now()).length;

        await ctx.replyWithMarkdown(`
╭─❒ 「 📊 BOT STATISTICS 」 
├ Total Users : ${users.size}
├ Total Groups : ${groups.size}
├ Active Groups : ${activeGroups}
├ Premium Users : ${premiumActive}
├ Blacklisted : ${blacklist.size}
├ Runtime : ${runtime(process.uptime())}
├ Server Time : ${moment().tz('Asia/Jakarta').format('DD/MM/YY HH:mm:ss')}
╰❒`);
    });
};