const { Markup } = require('telegraf');
const fs = require('fs-extra');
const path = require('path');
const fetch = require('node-fetch');
const moment = require('moment-timezone');
const JsConfuser = require('js-confuser');
const QRCode = require('qrcode');

const { User, Group, Blacklist, Transaction } = require('../lib/database');
const { updateProgress, runtime, uploadToUguu } = require('../lib/utils');
const { 
  obfuscateTimeLocked, 
  obfuscateQuantum, 
  getSiuCalcrickObfuscationConfig, 
  getCustomObfuscationConfig, 
  getNebulaObfuscationConfig, 
  getNovaObfuscationConfig, 
  getStrongObfuscationConfig, 
  getArabObfuscationConfig, 
  getJapanxArabObfuscationConfig, 
  getJapanObfuscationConfig 
} = require('./obf');

const { OWNER_ID, PREMIUM_PRICE, QRIS_URL } = require('../config');

// Fungsi untuk membuat pembayaran QRIS
async function createQRISPayment(userId, amount, product) {
  try {
    const user = await User.findOne({ userId });
    if (!user) throw new Error('User not found');

    const refCode = `JASHER-${userId}-${Date.now()}`;
    
    const postData = {
      api_key: "tarjUb8mYusE5pdbHN8unB6snWA7CdSu",
      secret_key: "zElY27dFNFOPKbd2jO0o8xglJ5PfMVQqnI55VPrXghPKCyitciWP",
      channel_payment: "QRIS",
      ref_kode: refCode,
      nominal: amount,
      cus_nama: user.firstName + ' ' + (user.lastName || ''),
      cus_email: user.username ? `${user.username}@telegram.com` : `user${userId}@telegram.com`,
      cus_phone: `62${userId.toString().slice(0, 11)}`,
      produk: product,
      url_redirect: `https://t.me/jasher_bot`,
      url_callback: `https://yourdomain.com/callback`,
      expired_time: Math.floor(Date.now() / 1000) + (24 * 60 * 60),
      signature: require('crypto').createHmac('sha256', "zElY27dFNFOPKbd2jO0o8xglJ5PfMVQqnI55VPrXghPKCyitciWP")
        .update(refCode + "tarjUb8mYusE5pdbHN8unB6snWA7CdSu" + amount)
        .digest('hex')
    };

    const response = await fetch(QRIS_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams(postData).toString()
    });

    const data = await response.json();
    
    if (data.status === 'success') {
      // Simpan transaksi ke database
      const transaction = new Transaction({
        userId,
        amount,
        paymentMethod: 'QRIS',
        status: 'pending',
        referenceId: data.data.id_reference,
        checkoutUrl: data.data.checkout_url
      });
      await transaction.save();
      
      return {
        success: true,
        checkoutUrl: data.data.checkout_url,
        referenceId: data.data.id_reference
      };
    } else {
      throw new Error(data.message || 'Payment creation failed');
    }
  } catch (error) {
    console.error('QRIS Payment Error:', error);
    return {
      success: false,
      error: error.message
    };
  }
}

// Command handler
module.exports = (bot) => {
  // Command: /start
  bot.start(async (ctx) => {
    const isCreator = ctx.from.id.toString() === OWNER_ID;
    const sender = ctx.from.username || ctx.from.first_name;
    
    const menuText = `
╭─❒ 「 User Info 」 
├ Owner : ${isCreator ? 'True' : 'False'}
├ Name : ${ctx.from.first_name} ${ctx.from.last_name || ''}
├ Profile : @${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`;

    const menuButtons = Markup.inlineKeyboard([
      [
        Markup.button.callback('Jasher Menu', 'jasher_menu'),
        Markup.button.callback('Owner Menu', 'owner_menu')
      ],
      [
        Markup.button.callback('Obf Menu', 'obf_menu'),
        Markup.button.callback('Kembali', 'back_menu')
      ]
    ]);

    await ctx.replyWithPhoto(
      { url: 'https://f.top4top.io/p_3530xky9e4.jpg' },
      {
        caption: menuText,
        parse_mode: 'Markdown',
        ...menuButtons
      }
    );
  });

  // Command: /buyprem
  bot.command('buyprem', async (ctx) => {
    try {
      const payment = await createQRISPayment(
        ctx.from.id, 
        PREMIUM_PRICE, 
        'Jasher Premium Account'
      );
      
      if (payment.success) {
        // Generate QR Code
        const qrCodePath = path.join(__dirname, '../temp', `qrcode-${ctx.from.id}.png`);
        await QRCode.toFile(qrCodePath, payment.checkoutUrl);
        
        await ctx.replyWithPhoto(
          { source: qrCodePath },
          {
            caption: `✅ *Pembayaran Premium Berhasil Dibuat!*\n\n` +
                     `💰 Harga: Rp ${PREMIUM_PRICE.toLocaleString('id-ID')}\n` +
                     `🔗 Link Pembayaran: ${payment.checkoutUrl}\n` +
                     `📋 Reference ID: ${payment.referenceId}\n\n` +
                     `Silahkan scan QR code di atas atau klik link untuk menyelesaikan pembayaran.`,
            parse_mode: 'Markdown'
          }
        );
        
        // Hapus file QR code setelah dikirim
        fs.unlinkSync(qrCodePath);
      } else {
        await ctx.reply(`❌ Gagal membuat pembayaran: ${payment.error}`);
      }
    } catch (error) {
      console.error('Buy Premium Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat memproses pembayaran.');
    }
  });

  // Command: /buycmd
  bot.command('buycmd', async (ctx) => {
    try {
      const args = ctx.message.text.split(' ');
      if (args.length < 2) {
        return ctx.reply('❌ Format: /buycmd <nama_command>');
      }
      
      const commandName = args[1];
      const price = 20000; // Harga default per command
      
      const payment = await createQRISPayment(
        ctx.from.id, 
        price, 
        `Jasher Command: ${commandName}`
      );
      
      if (payment.success) {
        // Generate QR Code
        const qrCodePath = path.join(__dirname, '../temp', `qrcode-${ctx.from.id}.png`);
        await QRCode.toFile(qrCodePath, payment.checkoutUrl);
        
        await ctx.replyWithPhoto(
          { source: qrCodePath },
          {
            caption: `✅ *Pembayaran Command Berhasil Dibuat!*\n\n` +
                     `⌨️ Command: /${commandName}\n` +
                     `💰 Harga: Rp ${price.toLocaleString('id-ID')}\n` +
                     `🔗 Link Pembayaran: ${payment.checkoutUrl}\n` +
                     `📋 Reference ID: ${payment.referenceId}\n\n` +
                     `Silahkan scan QR code di atas atau klik link untuk menyelesaikan pembayaran.`,
            parse_mode: 'Markdown'
          }
        );
        
        // Hapus file QR code setelah dikirim
        fs.unlinkSync(qrCodePath);
      } else {
        await ctx.reply(`❌ Gagal membuat pembayaran: ${payment.error}`);
      }
    } catch (error) {
      console.error('Buy Command Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat memproses pembayaran.');
    }
  });

  // Command: /addprem
  bot.command('addprem', async (ctx) => {
    if (ctx.from.id.toString() !== OWNER_ID) {
      return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
    }
    
    try {
      const args = ctx.message.text.split(' ');
      if (args.length < 3) {
        return ctx.reply('❌ Format: /addprem <user_id> <hari>');
      }
      
      const userId = parseInt(args[1]);
      const days = parseInt(args[2]);
      
      if (isNaN(userId) || isNaN(days)) {
        return ctx.reply('❌ User ID dan hari harus berupa angka!');
      }
      
      const user = await User.findOne({ userId });
      if (!user) {
        return ctx.reply('❌ User tidak ditemukan!');
      }
      
      const expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + days);
      
      user.isPremium = true;
      user.premiumExpiry = expiryDate;
      await user.save();
      
      await ctx.reply(`✅ Premium berhasil ditambahkan untuk user ${userId} selama ${days} hari.`);
      
      // Kirim notifikasi ke user
      try {
        await ctx.telegram.sendMessage(
          userId,
          `🎉 Selamat! Anda mendapatkan akses premium selama ${days} hari.\n` +
          `📅 Berlaku hingga: ${expiryDate.toLocaleDateString('id-ID')}`
        );
      } catch (error) {
        console.log('Tidak dapat mengirim notifikasi ke user:', error);
      }
    } catch (error) {
      console.error('Add Premium Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat menambahkan premium.');
    }
  });

  // Command: /delprem
  bot.command('delprem', async (ctx) => {
    if (ctx.from.id.toString() !== OWNER_ID) {
      return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
    }
    
    try {
      const args = ctx.message.text.split(' ');
      if (args.length < 2) {
        return ctx.reply('❌ Format: /delprem <user_id>');
      }
      
      const userId = parseInt(args[1]);
      
      if (isNaN(userId)) {
        return ctx.reply('❌ User ID harus berupa angka!');
      }
      
      const user = await User.findOne({ userId });
      if (!user) {
        return ctx.reply('❌ User tidak ditemukan!');
      }
      
      user.isPremium = false;
      user.premiumExpiry = null;
      await user.save();
      
      await ctx.reply(`✅ Premium berhasil dihapus untuk user ${userId}.`);
      
      // Kirim notifikasi ke user
      try {
        await ctx.telegram.sendMessage(
          userId,
          `ℹ️ Akses premium Anda telah dihentikan.`
        );
      } catch (error) {
        console.log('Tidak dapat mengirim notifikasi ke user:', error);
      }
    } catch (error) {
      console.error('Delete Premium Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat menghapus premium.');
    }
  });

  // Command: /listprem
  bot.command('listprem', async (ctx) => {
    if (ctx.from.id.toString() !== OWNER_ID) {
      return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
    }
    
    try {
      const premiumUsers = await User.find({ 
        isPremium: true,
        premiumExpiry: { $gt: new Date() }
      });
      
      if (premiumUsers.length === 0) {
        return ctx.reply('❌ Tidak ada user premium saat ini.');
      }
      
      let message = '📋 *Daftar User Premium:*\n\n';
      
      for (const user of premiumUsers) {
        const expiryDate = moment(user.premiumExpiry).format('DD/MM/YYYY HH:mm:ss');
        message += `👤 User: ${user.firstName} ${user.lastName || ''}\n`;
        message += `🆔 ID: ${user.userId}\n`;
        message += `📅 Expiry: ${expiryDate}\n`;
        message += `➖➖➖➖➖➖➖➖➖➖\n`;
      }
      
      await ctx.reply(message, { parse_mode: 'Markdown' });
    } catch (error) {
      console.error('List Premium Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat mengambil daftar premium.');
    }
  });

  // Command: /addbl (blacklist group)
  bot.command('addbl', async (ctx) => {
    if (ctx.from.id.toString() !== OWNER_ID) {
      return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
    }
    
    try {
      const args = ctx.message.text.split(' ');
      if (args.length < 2) {
        return ctx.reply('❌ Format: /addbl <group_id> [alasan]');
      }
      
      const groupId = parseInt(args[1]);
      const reason = args.slice(2).join(' ') || 'Tidak ada alasan';
      
      if (isNaN(groupId)) {
        return ctx.reply('❌ Group ID harus berupa angka!');
      }
      
      // Cek apakah group sudah di blacklist
      const existingBlacklist = await Blacklist.findOne({ groupId });
      if (existingBlacklist) {
        return ctx.reply('❌ Group sudah ada dalam blacklist!');
      }
      
      // Tambahkan ke blacklist
      const blacklist = new Blacklist({
        groupId,
        reason,
        bannedBy: ctx.from.id
      });
      
      await blacklist.save();
      
      await ctx.reply(`✅ Group ${groupId} berhasil ditambahkan ke blacklist.\nAlasan: ${reason}`);
    } catch (error) {
      console.error('Add Blacklist Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat menambahkan blacklist.');
    }
  });

  // Command: /delbl (hapus blacklist group)
  bot.command('delbl', async (ctx) => {
    if (ctx.from.id.toString() !== OWNER_ID) {
      return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
    }
    
    try {
      const args = ctx.message.text.split(' ');
      if (args.length < 2) {
        return ctx.reply('❌ Format: /delbl <group_id>');
      }
      
      const groupId = parseInt(args[1]);
      
      if (isNaN(groupId)) {
        return ctx.reply('❌ Group ID harus berupa angka!');
      }
      
      // Hapus dari blacklist
      const result = await Blacklist.deleteOne({ groupId });
      
      if (result.deletedCount === 0) {
        return ctx.reply('❌ Group tidak ditemukan dalam blacklist!');
      }
      
      await ctx.reply(`✅ Group ${groupId} berhasil dihapus dari blacklist.`);
    } catch (error) {
      console.error('Delete Blacklist Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat menghapus blacklist.');
    }
  });

  // Command: /listbl (list blacklist)
  bot.command('listbl', async (ctx) => {
    if (ctx.from.id.toString() !== OWNER_ID) {
      return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
    }
    
    try {
      const blacklists = await Blacklist.find();
      
      if (blacklists.length === 0) {
        return ctx.reply('✅ Tidak ada group yang di-blacklist.');
      }
      
      let message = '📋 *Daftar Group Blacklist:*\n\n';
      
      for (const bl of blacklists) {
        message += `👥 Group ID: ${bl.groupId}\n`;
        message += `📝 Alasan: ${bl.reason}\n`;
        message += `⏰ Tanggal: ${moment(bl.bannedAt).format('DD/MM/YYYY HH:mm:ss')}\n`;
        message += `➖➖➖➖➖➖➖➖➖➖\n`;
      }
      
      await ctx.reply(message, { parse_mode: 'Markdown' });
    } catch (error) {
      console.error('List Blacklist Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat mengambil daftar blacklist.');
    }
  });

  // Command: /listgrup (list grup aktif)
  bot.command('listgrup', async (ctx) => {
    if (ctx.from.id.toString() !== OWNER_ID) {
      return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
    }
    
    try {
      const groups = await Group.find({ isActive: true });
      
      if (groups.length === 0) {
        return ctx.reply('❌ Tidak ada group aktif.');
      }
      
      let message = '📋 *Daftar Group Aktif:*\n\n';
      
      for (const group of groups) {
        message += `👥 Group: ${group.title || 'No Title'}\n`;
        message += `🆔 ID: ${group.groupId}\n`;
        message += `📛 Username: @${group.username || 'Tidak ada'}\n`;
        message += `➖➖➖➖➖➖➖➖➖➖\n`;
      }
      
      await ctx.reply(message, { parse_mode: 'Markdown' });
    } catch (error) {
      console.error('List Groups Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat mengambil daftar group.');
    }
  });

  // Command: /bc (broadcast ke semua user)
  bot.command('bc', async (ctx) => {
    if (ctx.from.id.toString() !== OWNER_ID) {
      return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
    }
    
    try {
      const message = ctx.message.text.split(' ').slice(1).join(' ');
      
      if (!message) {
        return ctx.reply('❌ Format: /bc <pesan>');
      }
      
      const users = await User.find();
      let successCount = 0;
      let failCount = 0;
      
      await ctx.reply(`🚀 Memulai broadcast ke ${users.length} user...`);
      
      for (const user of users) {
        try {
          await ctx.telegram.sendMessage(user.userId, `📢 *Broadcast dari Admin:*\n\n${message}`, {
            parse_mode: 'Markdown'
          });
          successCount++;
          
          // Delay untuk menghindari rate limit
          await new Promise(resolve => setTimeout(resolve, 100));
        } catch (error) {
          console.log(`Gagal mengirim ke user ${user.userId}:`, error);
          failCount++;
        }
      }
      
      await ctx.reply(
        `✅ Broadcast selesai!\n` +
        `✔️ Berhasil: ${successCount}\n` +
        `❌ Gagal: ${failCount}`
      );
    } catch (error) {
      console.error('Broadcast Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat broadcast.');
    }
  });

  // Command: /sharefree (share teks gratis)
  bot.command('sharefree', async (ctx) => {
    if (ctx.chat.type !== 'private') {
      return ctx.reply('❌ Command ini hanya bisa digunakan di private chat!');
    }
    
    try {
      // Cek apakah user sudah menambahkan bot ke 3 group
      const user = await User.findOne({ userId: ctx.from.id });
      
      if (!user || user.joinedGroups.length < 3) {
        return ctx.reply(
          '❌ Untuk menggunakan fitur share, Anda harus menambahkan bot ke 3 group terlebih dahulu!\n' +
          `📊 Group saat ini: ${user ? user.joinedGroups.length : 0}/3`
        );
      }
      
      const message = ctx.message.text.split(' ').slice(1).join(' ');
      
      if (!message) {
        return ctx.reply('❌ Format: /sharefree <pesan>');
      }
      
      // Kirim ke semua group yang user telah tambahkan
      let successCount = 0;
      let failCount = 0;
      
      for (const groupId of user.joinedGroups) {
        try {
          await ctx.telegram.sendMessage(groupId, `📢 *Share dari @${ctx.from.username || ctx.from.first_name}:*\n\n${message}`, {
            parse_mode: 'Markdown'
          });
          successCount++;
          
          // Delay untuk menghindari rate limit
          await new Promise(resolve => setTimeout(resolve, 500));
        } catch (error) {
          console.log(`Gagal mengirim ke group ${groupId}:`, error);
          failCount++;
          
          // Jika group tidak aktif, hapus dari daftar
          if (error.response && error.response.error_code === 403) {
            user.joinedGroups = user.joinedGroups.filter(id => id !== groupId);
            await user.save();
          }
        }
      }
      
      await ctx.reply(
        `✅ Share selesai!\n` +
        `✔️ Berhasil: ${successCount}\n` +
        `❌ Gagal: ${failCount}`
      );
    } catch (error) {
      console.error('Share Free Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat share.');
    }
  });

  // Command: /sharevip (share teks premium)
  bot.command('sharevip', async (ctx) => {
    if (ctx.chat.type !== 'private') {
      return ctx.reply('❌ Command ini hanya bisa digunakan di private chat!');
    }
    
    try {
      // Cek status premium user
      if (!ctx.isPremium) {
        return ctx.reply(
          '❌ Fitur ini hanya untuk user premium!\n' +
          '💎 Gunakan /buyprem untuk upgrade ke premium'
        );
      }
      
      const message = ctx.message.text.split(' ').slice(1).join(' ');
      
      if (!message) {
        return ctx.reply('❌ Format: /sharevip <pesan>');
      }
      
      // Kirim ke semua group yang user telah tambahkan (lebih cepat tanpa delay)
      const user = await User.findOne({ userId: ctx.from.id });
      let successCount = 0;
      let failCount = 0;
      
      for (const groupId of user.joinedGroups) {
        try {
          await ctx.telegram.sendMessage(groupId, `💎 *VIP Share dari @${ctx.from.username || ctx.from.first_name}:*\n\n${message}`, {
            parse_mode: 'Markdown'
          });
          successCount++;
        } catch (error) {
          console.log(`Gagal mengirim ke group ${groupId}:`, error);
          failCount++;
        }
      }
      
      await ctx.reply(
        `✅ VIP Share selesai!\n` +
        `✔️ Berhasil: ${successCount}\n` +
        `❌ Gagal: ${failCount}`
      );
    } catch (error) {
      console.error('Share VIP Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat share.');
    }
  });

  // Command: /tourl (upload file ke uguu.se)
  bot.command('tourl', async (ctx) => {
    try {
      if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
        return ctx.reply('❌ Balas sebuah file dengan command ini!');
      }
      
      const file = ctx.message.reply_to_message.document;
      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      
      // Download file
      const response = await fetch(fileLink);
      const buffer = await response.buffer();
      
      // Simpan file sementara
      const tempDir = path.join(__dirname, '../temp');
      await fs.ensureDir(tempDir);
      
      const tempPath = path.join(tempDir, file.file_name);
      await fs.writeFile(tempPath, buffer);
      
      // Upload ke uguu.se
      await ctx.reply('⏳ Mengupload file...');
      const fileUrl = await uploadToUguu(tempPath);
      
      if (fileUrl) {
        await ctx.reply(`✅ File berhasil diupload!\n🔗 URL: ${fileUrl}`);
      } else {
        await ctx.reply('❌ Gagal mengupload file.');
      }
      
      // Hapus file sementara
      await fs.unlink(tempPath);
    } catch (error) {
      console.error('Upload to URL Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat mengupload file.');
    }
  });

  // Command: /antispam (hanya untuk admin group)
  bot.command('antispam', async (ctx) => {
    if (!ctx.chat.type.includes('group')) {
      return ctx.reply('❌ Command ini hanya bisa digunakan di group!');
    }
    
    try {
      const chatMember = await ctx.getChatMember(ctx.from.id);
      if (!['administrator', 'creator'].includes(chatMember.status)) {
        return ctx.reply('❌ Hanya admin group yang dapat menggunakan command ini!');
      }
      
      const group = await Group.findOne({ groupId: ctx.chat.id });
      if (!group) {
        return ctx.reply('❌ Group tidak terdaftar!');
      }
      
      // Toggle antispam setting
      group.settings.antispam = !group.settings.antispam;
      await group.save();
      
      await ctx.reply(
        `✅ Pengaturan antispam telah ${group.settings.antispam ? 'diaktifkan' : 'dinonaktifkan'}!`
      );
    } catch (error) {
      console.error('Anti Spam Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat mengubah pengaturan.');
    }
  });

  // Command: /noevent (hanya untuk admin group)
  bot.command('noevent', async (ctx) => {
    if (!ctx.chat.type.includes('group')) {
      return ctx.reply('❌ Command ini hanya bisa digunakan di group!');
    }
    
    try {
      const chatMember = await ctx.getChatMember(ctx.from.id);
      if (!['administrator', 'creator'].includes(chatMember.status)) {
        return ctx.reply('❌ Hanya admin group yang dapat menggunakan command ini!');
      }
      
      const group = await Group.findOne({ groupId: ctx.chat.id });
      if (!group) {
        return ctx.reply('❌ Group tidak terdaftar!');
      }
      
      // Toggle noevent setting
      group.settings.noevent = !group.settings.noevent;
      await group.save();
      
      await ctx.reply(
        `✅ Pengaturan noevent telah ${group.settings.noevent ? 'diaktifkan' : 'dinonaktifkan'}!`
      );
    } catch (error) {
      console.error('No Event Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat mengubah pengaturan.');
    }
  });

  // Command: /nolinks (hanya untuk admin group)
  bot.command('nolinks', async (ctx) => {
    if (!ctx.chat.type.includes('group')) {
      return ctx.reply('❌ Command ini hanya bisa digunakan di group!');
    }
    
    try {
      const chatMember = await ctx.getChatMember(ctx.from.id);
      if (!['administrator', 'creator'].includes(chatMember.status)) {
        return ctx.reply('❌ Hanya admin group yang dapat menggunakan command ini!');
      }
      
      const group = await Group.findOne({ groupId: ctx.chat.id });
      if (!group) {
        return ctx.reply('❌ Group tidak terdaftar!');
      }
      
      // Toggle nolinks setting
      group.settings.nolinks = !group.settings.nolinks;
      await group.save();
      
      await ctx.reply(
        `✅ Pengaturan nolinks telah ${group.settings.nolinks ? 'diaktifkan' : 'dinonaktifkan'}!`
      );
    } catch (error) {
      console.error('No Links Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat mengubah pengaturan.');
    }
  });

  // Command: /noforwards (hanya untuk admin group)
  bot.command('noforwards', async (ctx) => {
    if (!ctx.chat.type.includes('group')) {
      return ctx.reply('❌ Command ini hanya bisa digunakan di group!');
    }
    
    try {
      const chatMember = await ctx.getChatMember(ctx.from.id);
      if (!['administrator', 'creator'].includes(chatMember.status)) {
        return ctx.reply('❌ Hanya admin group yang dapat menggunakan command ini!');
      }
      
      const group = await Group.findOne({ groupId: ctx.chat.id });
      if (!group) {
        return ctx.reply('❌ Group tidak terdaftar!');
      }
      
      // Toggle noforwards setting
      group.settings.noforwards = !group.settings.noforwards;
      await group.save();
      
      await ctx.reply(
        `✅ Pengaturan noforwards telah ${group.settings.noforwards ? 'diaktifkan' : 'dinonaktifkan'}!`
      );
    } catch (error) {
      console.error('No Forwards Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat mengubah pengaturan.');
    }
  });

  // Command: /nocontacts (hanya untuk admin group)
  bot.command('nocontacts', async (ctx) => {
    if (!ctx.chat.type.includes('group')) {
      return ctx.reply('❌ Command ini hanya bisa digunakan di group!');
    }
    
    try {
      const chatMember = await ctx.getChatMember(ctx.from.id);
      if (!['administrator', 'creator'].includes(chatMember.status)) {
        return ctx.reply('❌ Hanya admin group yang dapat menggunakan command ini!');
      }
      
      const group = await Group.findOne({ groupId: ctx.chat.id });
      if (!group) {
        return ctx.reply('❌ Group tidak terdaftar!');
      }
      
      // Toggle nocontacts setting
      group.settings.nocontacts = !group.settings.nocontacts;
      await group.save();
      
      await ctx.reply(
        `✅ Pengaturan nocontacts telah ${group.settings.nocontacts ? 'diaktifkan' : 'dinonaktifkan'}!`
      );
    } catch (error) {
      console.error('No Contacts Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat mengubah pengaturan.');
    }
  });

  // Command: /nohashtags (hanya untuk admin group)
  bot.command('nohashtags', async (ctx) => {
    if (!ctx.chat.type.includes('group')) {
      return ctx.reply('❌ Command ini hanya bisa digunakan di group!');
    }
    
    try {
      const chatMember = await ctx.getChatMember(ctx.from.id);
      if (!['administrator', 'creator'].includes(chatMember.status)) {
        return ctx.reply('❌ Hanya admin group yang dapat menggunakan command ini!');
      }
      
      const group = await Group.findOne({ groupId: ctx.chat.id });
      if (!group) {
        return ctx.reply('❌ Group tidak terdaftar!');
      }
      
      // Toggle nohashtags setting
      group.settings.nohashtags = !group.settings.nohashtags;
      await group.save();
      
      await ctx.reply(
        `✅ Pengaturan nohashtags telah ${group.settings.nohashtags ? 'diaktifkan' : 'dinonaktifkan'}!`
      );
    } catch (error) {
      console.error('No Hashtags Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat mengubah pengaturan.');
    }
  });

  // Command: /nocommands (hanya untuk admin group)
  bot.command('nocommands', async (ctx) => {
    if (!ctx.chat.type.includes('group')) {
      return ctx.reply('❌ Command ini hanya bisa digunakan di group!');
    }
    
    try {
      const chatMember = await ctx.getChatMember(ctx.from.id);
      if (!['administrator', 'creator'].includes(chatMember.status)) {
        return ctx.reply('❌ Hanya admin group yang dapat menggunakan command ini!');
      }
      
      const group = await Group.findOne({ groupId: ctx.chat.id });
      if (!group) {
        return ctx.reply('❌ Group tidak terdaftar!');
      }
      
      // Toggle nocommands setting
      group.settings.nocommands = !group.settings.nocommands;
      await group.save();
      
      await ctx.reply(
        `✅ Pengaturan nocommands telah ${group.settings.nocommands ? 'diaktifkan' : 'dinonaktifkan'}!`
      );
    } catch (error) {
      console.error('No Commands Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat mengubah pengaturan.');
    }
  });

  // Command: /enc3 (obfuscation Mandarin)
  bot.command("enc3", async (ctx) => {
    try {
      if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
        return ctx.replyWithMarkdown(`
╭━━━「 ❌ ERROR 」━━━⬣
│ Terjadi kesalahan saat
│ memproses file!
╰━━━━━━━━━━━━━━━━⬣`);
      }

      const file = ctx.message.reply_to_message.document;
      if (!file.file_name.endsWith(".js")) {
        return ctx.replyWithMarkdown(`
╭━━━「 ❌ ERROR 」━━━⬣
│ File harus berekstensi .js!
╰━━━━━━━━━━━━━━━━⬣`);
      }

      const encryptedPath = path.join(__dirname, '../temp', `china-encrypted-${file.file_name}`);

      try {
        const progressMessage = await ctx.replyWithMarkdown(
          "```css\n" +
            "🔒 EncryptBot\n" +
            ` ⚙️ Memulai (Hardened Mandarin) (1%)\n` +
            ` ${createProgressBar(1)}\n` +
            "```\n" +
            "PROSES ENCRYPT "
        );

        const fileLink = await ctx.telegram.getFileLink(file.file_id);
        console.log(`Mengunduh file untuk Mandarin obfuscation: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 10, "Mengunduh");
        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

        console.log(`Memvalidasi kode: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
        try {
          new Function(fileContent);
        } catch (syntaxError) {
          throw new Error(`Kode tidak valid: ${syntaxError.message}`);
        }

        console.log(`Mengenkripsi file dengan gaya Mandarin yang diperkuat`);
        await updateProgress(
          ctx,
          progressMessage,
          40,
          "Inisialisasi Hardened Mandarin Obfuscation"
        );
        const obfuscated = await JsConfuser.obfuscate(
          fileContent,
          getJapanxArabObfuscationConfig()
        );
        await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
        await fs.writeFile(encryptedPath, obfuscated);
        await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

        console.log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
        try {
          new Function(obfuscated);
        } catch (postObfuscationError) {
          throw new Error(
            `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
          );
        }

        console.log(`Mengirim file terenkripsi gaya Mandarin: ${file.file_name}`);
        await ctx.replyWithDocument(
          { source: encryptedPath, filename: `china-encrypted-${file.file_name}` },
          {
            caption:
              "✅ *File terenkripsi (Hardened Mandarin) siap!*\nSUKSES ENCRYPT 🕊",
            parse_mode: "Markdown",
          }
        );
        await updateProgress(
          ctx,
          progressMessage,
          100,
          "Hardened Mandarin Obfuscation Selesai"
        );

        if (await fs.pathExists(encryptedPath)) {
          await fs.unlink(encryptedPath);
          console.log(`File sementara dihapus: ${encryptedPath}`);
        }
      } catch (error) {
        console.log("Kesalahan saat Mandarin obfuscation", error);
        await ctx.replyWithMarkdown(
          `❌ *Kesalahan:* ${
            error.message || "Tidak diketahui"
          }\n_Coba lagi dengan kode Javascript yang valid!_`
        );
        if (await fs.pathExists(encryptedPath)) {
          await fs.unlink(encryptedPath);
          console.log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
      }
    } catch (error) {
      console.error('Enc3 Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat obfuscation.');
    }
  });

  // Command: /enc4 (obfuscation Arab)
  bot.command("enc4", async (ctx) => {
    try {
      if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
        return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc4`!");
      }

      const file = ctx.message.reply_to_message.document;
      if (!file.file_name.endsWith(".js")) {
        return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
      }

      const encryptedPath = path.join(__dirname, '../temp', `arab-encrypted-${file.file_name}`);

      try {
        const progressMessage = await ctx.replyWithMarkdown(
          "```css\n" +
            "🔒 EncryptBot\n" +
            ` ⚙️ Memulai (Hardened Arab) (1%)\n` +
            ` ${createProgressBar(1)}\n` +
            "```\n" +
            "PROSES ENCRYPT"
        );

        const fileLink = await ctx.telegram.getFileLink(file.file_id);
        console.log(`Mengunduh file untuk Arab obfuscation: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 10, "Mengunduh");
        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

        console.log(`Memvalidasi kode: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
        try {
          new Function(fileContent);
        } catch (syntaxError) {
          throw new Error(`Kode tidak valid: ${syntaxError.message}`);
        }

        console.log(`Mengenkripsi file dengan gaya Arab yang diperkuat`);
        await updateProgress(
          ctx,
          progressMessage,
          40,
          "Inisialisasi Hardened Arab Obfuscation"
        );
        const obfuscated = await JsConfuser.obfuscate(
          fileContent,
          getArabObfuscationConfig()
        );
        await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
        await fs.writeFile(encryptedPath, obfuscated);
        await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

        console.log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
        try {
          new Function(obfuscated);
        } catch (postObfuscationError) {
          throw new Error(
            `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
          );
        }

        console.log(`Mengirim file terenkripsi gaya Arab: ${file.file_name}`);
        await ctx.replyWithDocument(
          { source: encryptedPath, filename: `arab-encrypted-${file.file_name}` },
          {
            caption:
              "✅ *File terenkripsi (Hardened Arab) siap!*\nSUKSES ENCRYPT 🕊",
            parse_mode: "Markdown",
          }
        );
        await updateProgress(
          ctx,
          progressMessage,
          100,
          "Hardened Arab Obfuscation Selesai"
        );

        if (await fs.pathExists(encryptedPath)) {
          await fs.unlink(encryptedPath);
          console.log(`File sementara dihapus: ${encryptedPath}`);
        }
      } catch (error) {
        console.log("Kesalahan saat Arab obfuscation", error);
        await ctx.replyWithMarkdown(
          `❌ *Kesalahan:* ${
            error.message || "Tidak diketahui"
          }\n_Coba lagi dengan kode Javascript yang valid!_`
        );
        if (await fs.pathExists(encryptedPath)) {
          await fs.unlink(encryptedPath);
          console.log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
      }
    } catch (error) {
      console.error('Enc4 Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat obfuscation.');
    }
  });

  // Command: /japan (obfuscation Japan)
  bot.command("japan", async (ctx) => {
    try {
      if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
        return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/japan`!");
      }

      const file = ctx.message.reply_to_message.document;
      if (!file.file_name.endsWith(".js")) {
        return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
      }

      const encryptedPath = path.join(__dirname, '../temp', `japan-encrypted-${file.file_name}`);

      try {
        const progressMessage = await ctx.replyWithMarkdown(
          "```css\n" +
            "🔒 EncryptBot\n" +
            ` ⚙️ Memulai (Hardened Japan) (1%)\n` +
            ` ${createProgressBar(1)}\n` +
            "```\n" +
            "PROSES ENCRYPT "
        );

        const fileLink = await ctx.telegram.getFileLink(file.file_id);
        console.log(`Mengunduh file untuk Japan obfuscation: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 10, "Mengunduh");
        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

        console.log(`Memvalidasi kode: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
        try {
          new Function(fileContent);
        } catch (syntaxError) {
          throw new Error(`Kode tidak valid: ${syntaxError.message}`);
        }

        console.log(`Mengenkripsi file dengan gaya Japan yang diperkuat`);
        await updateProgress(
          ctx,
          progressMessage,
          40,
          "Inisialisasi Hardened Japan Obfuscation"
        );
        const obfuscated = await JsConfuser.obfuscate(
          fileContent,
          getJapanObfuscationConfig()
        );
        await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
        await fs.writeFile(encryptedPath, obfuscated);
        await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

        console.log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
        try {
          new Function(obfuscated);
        } catch (postObfuscationError) {
          throw new Error(
            `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
          );
        }

        console.log(`Mengirim file terenkripsi gaya Japan: ${file.file_name}`);
        await ctx.replyWithDocument(
          { source: encryptedPath, filename: `japan-encrypted-${file.file_name}` },
          {
            caption:
              "✅ *File terenkripsi (Hardened Japan) siap!*\nSUKSES ENCRYPT 🕊",
            parse_mode: "Markdown",
          }
        );
        await updateProgress(
          ctx,
          progressMessage,
          100,
          "Hardened Japan Obfuscation Selesai"
        );

        if (await fs.pathExists(encryptedPath)) {
          await fs.unlink(encryptedPath);
          console.log(`File sementara dihapus: ${encryptedPath}`);
        }
      } catch (error) {
        console.log("Kesalahan saat Japan obfuscation", error);
        await ctx.replyWithMarkdown(
          `❌ *Kesalahan:* ${
            error.message || "Tidak diketahui"
          }\n_Coba lagi dengan kode Javascript yang valid!_`
        );
        if (await fs.pathExists(encryptedPath)) {
          await fs.unlink(encryptedPath);
          console.log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
      }
    } catch (error) {
      console.error('Japan Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat obfuscation.');
    }
  });

  // Command: /zenc (obfuscation Invisible)
  bot.command("zenc", async (ctx) => {
    try {
      if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
        return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/zenc`!");
      }

      const file = ctx.message.reply_to_message.document;
      if (!file.file_name.endsWith(".js")) {
        return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
      }

      const encryptedPath = path.join(__dirname, '../temp', `invisible-encrypted-${file.file_name}`);

      try {
        const progressMessage = await ctx.replyWithMarkdown(
          "```css\n" +
            "🔒 EncryptBot\n" +
            ` ⚙️ Memulai (InvisiBle) (1%)\n` +
            ` ${createProgressBar(1)}\n` +
            "```\n" +
            "PROSES ENCRYPT "
        );

        const fileLink = await ctx.telegram.getFileLink(file.file_id);
        console.log(`Mengunduh file untuk Strong obfuscation: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 10, "Mengunduh");
        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

        console.log(`Memvalidasi kode awal: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
        try {
          new Function(fileContent);
        } catch (syntaxError) {
          throw new Error(`Kode tidak valid: ${syntaxError.message}`);
        }

        console.log(`Mengenkripsi file dengan gaya Strong`);
        await updateProgress(
          ctx,
          progressMessage,
          40,
          "Inisialisasi Hardened Invisible Obfuscation"
        );
        const obfuscated = await JsConfuser.obfuscate(
          fileContent,
          getStrongObfuscationConfig()
        );
        let obfuscatedCode = obfuscated;
        if (typeof obfuscatedCode !== "string") {
          throw new Error("Hasil obfuscation bukan string");
        }
        console.log(
          `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
            0,
            50
          )}...`
        );
        await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");

        console.log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
        try {
          new Function(obfuscatedCode);
        } catch (postObfuscationError) {
          throw new Error(
            `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
          );
        }

        await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
        await fs.writeFile(encryptedPath, obfuscatedCode);

        console.log(`Mengirim file terenkripsi gaya Invisible: ${file.file_name}`);
        await ctx.replyWithDocument(
          {
            source: encryptedPath,
            filename: `Invisible-encrypted-${file.file_name}`,
          },
          {
            caption: "✅ *File terenkripsi (Invisible) siap!*\nSUKSES ENCRYPT 🕊",
            parse_mode: "Markdown",
          }
        );
        await updateProgress(
          ctx,
          progressMessage,
          100,
          "Hardened Invisible Obfuscation Selesai"
        );

        if (await fs.pathExists(encryptedPath)) {
          await fs.unlink(encryptedPath);
          console.log(`File sementara dihapus: ${encryptedPath}`);
        }
      } catch (error) {
        console.log("Kesalahan saat Invisible obfuscation", error);
        await ctx.replyWithMarkdown(
          `❌ *Kesalahan:* ${
            error.message || "Tidak diketahui"
          }\n_Coba lagi dengan kode Javascript yang valid!_`
        );
        if (await fs.pathExists(encryptedPath)) {
          await fs.unlink(encryptedPath);
          console.log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
      }
    } catch (error) {
      console.error('Zenc Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat obfuscation.');
    }
  });

  // Command: /xx (obfuscation custom)
  bot.command("xx", async (ctx) => {
    try {
      // Ambil nama kustom dari perintah
      const args = ctx.message.text.split(" ");
      if (args.length < 2 || !args[1]) {
        return ctx.replyWithMarkdown(
          "❌ *Error:* Gunakan format `/enc <nama>` dengan nama kustom!"
        );
      }
      const customName = args[1].replace(/[^a-zA-Z0-9_]/g, ""); // Sanitasi input, hanya huruf, angka, dan underscore
      if (!customName) {
        return ctx.replyWithMarkdown(
          "❌ *Error:* Nama kustom harus berisi huruf, angka, atau underscore!"
        );
      }

      if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
        return ctx.replyWithMarkdown(
          "❌ *Error:* Balas file .js dengan `/enc <nama>`!"
        );
      }

      const file = ctx.message.reply_to_message.document;
      if (!file.file_name.endsWith(".js")) {
        return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
      }

      const encryptedPath = path.join(
        __dirname, '../temp',
        `custom-${customName}-encrypted-${file.file_name}`
      );

      try {
        const progressMessage = await ctx.replyWithMarkdown(
          "```css\n" +
            "🔒 EncryptBot\n" +
            ` ⚙️ Memulai (Hardened Custom: ${customName}) (1%)\n` +
            ` ${createProgressBar(1)}\n` +
            "```\n" +
            "PROSES ENCRYPT "
        );

        const fileLink = await ctx.telegram.getFileLink(file.file_id);
        console.log(`Mengunduh file untuk Custom obfuscation: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 10, "Mengunduh");
        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

        console.log(`Memvalidasi kode awal: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
        try {
          new Function(fileContent);
        } catch (syntaxError) {
          throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
        }

        console.log(`Mengenkripsi file dengan gaya Custom (${customName}) yang diperkuat`);
        await updateProgress(
          ctx,
          progressMessage,
          40,
          "Inisialisasi Hardened Custom Obfuscation"
        );
        const obfuscated = await JsConfuser.obfuscate(
          fileContent,
          getCustomObfuscationConfig(customName)
        );
        console.log(
          `Hasil obfuscation (50 char pertama): ${obfuscated.substring(
            0,
            50
          )}...`
        );
        await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");

        console.log(`Memvalidasi kode hasil obfuscation: ${file.file_name}`);
        try {
          new Function(obfuscated);
        } catch (postObfuscationError) {
          console.log(
            `Kode hasil obfuscation tidak valid: ${postObfuscationError.message}`
          );
          throw new Error(
            `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
          );
        }

        await fs.writeFile(encryptedPath, obfuscated);
        await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

        console.log(`Mengirim file terenkripsi gaya Custom: ${file.file_name}`);
        await ctx.replyWithDocument(
          {
            source: encryptedPath,
            filename: `custom-${customName}-encrypted-${file.file_name}`,
          },
          {
            caption: `✅ *File terenkripsi (Hardened Custom: ${customName}) siap!*\nSUKSES ENCRYPT 🕊`,
            parse_mode: "Markdown",
          }
        );
        await updateProgress(
          ctx,
          progressMessage,
          100,
          `Hardened Custom (${customName}) Obfuscation Selesai`
        );

        if (await fs.pathExists(encryptedPath)) {
          await fs.unlink(encryptedPath);
          console.log(`File sementara dihapus: ${encryptedPath}`);
        }
      } catch (error) {
        console.log("Kesalahan saat Custom obfuscation", error);
        await ctx.replyWithMarkdown(
          `❌ *Kesalahan:* ${
            error.message || "Tidak diketahui"
          }\n_Coba lagi dengan kode Javascript yang valid!_`
        );
        if (await fs.pathExists(encryptedPath)) {
          await fs.unlink(encryptedPath);
          console.log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
      }
    } catch (error) {
      console.error('XX Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat obfuscation.');
    }
  });

  // Command: /quantum (obfuscation Quantum)
  bot.command("quantum", async (ctx) => {
    try {
      if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
        return ctx.replyWithMarkdown(
          "❌ *Error:* Balas file .js dengan `/quantum`!"
        );
      }

      const file = ctx.message.reply_to_message.document;
      if (!file.file_name.endsWith(".js")) {
        return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
      }

      const encryptedPath = path.join(__dirname, '../temp', `quantum-encrypted-${file.file_name}`);

      try {
        const progressMessage = await ctx.replyWithMarkdown(
          "```css\n" +
            "🔒 EncryptBot\n" +
            " ⚙️ Memulai (Quantum Vortex Encryption) (1%)\n" +
            " " +
            createProgressBar(1) +
            "\n" +
            "```\n" +
            "PROSES ENCRYPT "
        );

        const fileLink = await ctx.telegram.getFileLink(file.file_id);
        console.log(`Mengunduh file untuk Quantum Vortex Encryption: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 10, "Mengunduh");
        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

        console.log(`Memvalidasi kode awal: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
        try {
          new Function(fileContent);
        } catch (syntaxError) {
          throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
        }

        console.log(`Mengenkripsi file dengan Quantum Vortex Encryption`);
        await updateProgress(
          ctx,
          progressMessage,
          40,
          "Inisialisasi Quantum Vortex Encryption"
        );
        const obfuscatedCode = await obfuscateQuantum(fileContent);
        console.log(
          `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
            0,
            50
          )}...`
        );
        console.log(
          `Ukuran file setelah obfuscation: ${Buffer.byteLength(
            obfuscatedCode,
            "utf-8"
          )} bytes`
        );

        console.log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
        try {
          new Function(obfuscatedCode);
        } catch (postObfuscationError) {
          console.log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
          throw new Error(
            `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
          );
        }

        await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
        await fs.writeFile(encryptedPath, obfuscatedCode);

        console.log(`Mengirim file terenkripsi quantum: ${file.file_name}`);
        await ctx.replyWithDocument(
          {
            source: encryptedPath,
            filename: `quantum-encrypted-${file.file_name}`,
          },
          {
            caption:
              "✅ *File terenkripsi (Quantum Vortex Encryption) siap!*\nSUKSES ENCRYPT 🕊",
            parse_mode: "Markdown",
          }
        );
        await updateProgress(
          ctx,
          progressMessage,
          100,
          "Quantum Vortex Encryption Selesai"
        );

        if (await fs.pathExists(encryptedPath)) {
          await fs.unlink(encryptedPath);
          console.log(`File sementara dihapus: ${encryptedPath}`);
        }
      } catch (error) {
        console.log("Kesalahan saat Quantum obfuscation", error);
        await ctx.replyWithMarkdown(
          `❌ *Kesalahan:* ${
            error.message || "Tidak diketahui"
          }\n_Coba lagi dengan kode Javascript yang valid!_`
        );
        if (await fs.pathExists(encryptedPath)) {
          await fs.unlink(encryptedPath);
          console.log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
      }
    } catch (error) {
      console.error('Quantum Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat obfuscation.');
    }
  });

  // Command: /var (obfuscation Var)
  bot.command("var", async (ctx) => {
    try {
      if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
        return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/var`!");
      }

      const file = ctx.message.reply_to_message.document;
      if (!file.file_name.endsWith(".js")) {
        return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
      }

      const encryptedPath = path.join(__dirname, '../temp', `var-encrypted-${file.file_name}`);

      try {
        const progressMessage = await ctx.replyWithMarkdown(
          "```css\n" +
            "🔒 EncryptBot\n" +
            " ⚙️ Memulai (Var) (1%)\n" +
            " " +
            createProgressBar(1) +
            "\n" +
            "```\n" +
            "PROSES ENCRYPT "
        );

        const fileLink = await ctx.telegram.getFileLink(file.file_id);
        console.log(`Mengunduh file untuk Var obfuscation: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 10, "Mengunduh");
        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

        console.log(`Memvalidasi kode awal: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
        try {
          new Function(fileContent);
        } catch (syntaxError) {
          throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
        }

        console.log(`Mengenkripsi file dengan gaya Var`);
        await updateProgress(
          ctx,
          progressMessage,
          40,
          "Inisialisasi Var Dynamic Obfuscation"
        );
        const obfuscated = await JsConfuser.obfuscate(
          fileContent,
          getNovaObfuscationConfig()
        );
        let obfuscatedCode = obfuscated;
        if (typeof obfuscatedCode !== "string") {
          throw new Error("Hasil obfuscation bukan string");
        }
        console.log(
          `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
            0,
            50
          )}...`
        );

        console.log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
        try {
          new Function(obfuscatedCode);
        } catch (postObfuscationError) {
          console.log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
          throw new Error(
            `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
          );
        }

        await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
        await fs.writeFile(encryptedPath, obfuscatedCode);

        console.log(`Mengirim file terenkripsi gaya Var: ${file.file_name}`);
        await ctx.replyWithDocument(
          { source: encryptedPath, filename: `Var-encrypted-${file.file_name}` },
          {
            caption: "✅ *File terenkripsi (Var) siap!*\nSUKSES ENCRYPT 🕊",
            parse_mode: "Markdown",
          }
        );
        await updateProgress(ctx, progressMessage, 100, "Var Obfuscation Selesai");

        if (await fs.pathExists(encryptedPath)) {
          await fs.unlink(encryptedPath);
          console.log(`File sementara dihapus: ${encryptedPath}`);
        }
      } catch (error) {
        console.log("Kesalahan saat Nova obfuscation", error);
        await ctx.replyWithMarkdown(
          `❌ *Kesalahan:* ${
            error.message || "Tidak diketahui"
          }\n_Coba lagi dengan kode Javascript yang valid!_`
        );
        if (await fs.pathExists(encryptedPath)) {
          await fs.unlink(encryptedPath);
          console.log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
      }
    } catch (error) {
      console.error('Var Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat obfuscation.');
    }
  });

  // Command: /nebula (obfuscation Nebula)
  bot.command("nebula", async (ctx) => {
    try {
      if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
        return ctx.replyWithMarkdown(
          "❌ *Error:* Balas file .js dengan `/nebula`!"
        );
      }

      const file = ctx.message.reply_to_message.document;
      if (!file.file_name.endsWith(".js")) {
        return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
      }

      const encryptedPath = path.join(__dirname, '../temp', `nebula-encrypted-${file.file_name}`);

      try {
        const progressMessage = await ctx.replyWithMarkdown(
          "```css\n" +
            "🔒 EncryptBot\n" +
            " ⚙️ Memulai (Nebula Polymorphic Storm) (1%)\n" +
            " " +
            createProgressBar(1) +
            "\n" +
            "```\n" +
            "PROSES ENCRYPT "
        );

        const fileLink = await ctx.telegram.getFileLink(file.file_id);
        console.log(`Mengunduh file untuk Nebula obfuscation: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 10, "Mengunduh");
        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

        console.log(`Memvalidasi kode awal: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
        try {
          new Function(fileContent);
        } catch (syntaxError) {
          throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
        }

        console.log(`Mengenkripsi file dengan gaya Nebula`);
        await updateProgress(
          ctx,
          progressMessage,
          40,
          "Inisialisasi Nebula Polymorphic Storm"
        );
        const obfuscated = await JsConfuser.obfuscate(
          fileContent,
          getNebulaObfuscationConfig()
        );
        let obfuscatedCode = obfuscated;
        if (typeof obfuscatedCode !== "string") {
          throw new Error("Hasil obfuscation bukan string");
        }
        console.log(
          `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
            0,
            50
          )}...`
        );
        console.log(
          `Ukuran file setelah obfuscation: ${Buffer.byteLength(
            obfuscatedCode,
            "utf-8"
          )} bytes`
        );

        console.log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
        try {
          new Function(obfuscatedCode);
        } catch (postObfuscationError) {
          console.log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
          throw new Error(
            `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
          );
        }

        await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
        await fs.writeFile(encryptedPath, obfuscatedCode);

        console.log(`Mengirim file terenkripsi gaya Nebula: ${file.file_name}`);
        await ctx.replyWithDocument(
          { source: encryptedPath, filename: `nebula-encrypted-${file.file_name}` },
          {
            caption:
              "✅ *File terenkripsi (Nebula Polymorphic Storm) siap!*\nSUKSES ENCRYPT 🕊",
            parse_mode: "Markdown",
          }
        );
        await updateProgress(
          ctx,
          progressMessage,
          100,
          "Nebula Polymorphic Storm Selesai"
        );

        if (await fs.pathExists(encryptedPath)) {
          await fs.unlink(encryptedPath);
          console.log(`File sementara dihapus: ${encryptedPath}`);
        }
      } catch (error) {
        console.log("Kesalahan saat Nebula obfuscation", error);
        await ctx.replyWithMarkdown(
          `❌ *Kesalahan:* ${
            error.message || "Tidak diketahui"
          }\n_Coba lagi dengan kode Javascript yang valid!_`
        );
        if (await fs.pathExists(encryptedPath)) {
          await fs.unlink(encryptedPath);
          console.log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
      }
    } catch (error) {
      console.error('Nebula Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat obfuscation.');
    }
  });

  // Command: /enc5 (obfuscation Siu+Calcrick)
  bot.command("enc5", async (ctx) => {
    try {
      if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
        return ctx.replyWithMarkdown(
          "❌ *Error:* Balas file .js dengan `/enc5`!"
        );
      }

      const file = ctx.message.reply_to_message.document;
      if (!file.file_name.endsWith(".js")) {
        return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
      }

      const encryptedPath = path.join(__dirname, '../temp', `siucalcrick-encrypted-${file.file_name}`);

      try {
        const progressMessage = await ctx.replyWithMarkdown(
          "```css\n" +
            "🔒 EncryptBot\n" +
            " ⚙️ Memulai (Calcrick Chaos Core) (1%)\n" +
            " " +
            createProgressBar(1) +
            "\n" +
            "```\n" +
            "PROSES ENCRYPT "
        );

        const fileLink = await ctx.telegram.getFileLink(file.file_id);
        console.log(`Mengunduh file untuk Siu+Calcrick obfuscation: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 10, "Mengunduh");
        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

        console.log(`Memvalidasi kode awal: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
        try {
          new Function(fileContent);
        } catch (syntaxError) {
          throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
        }

        console.log(`Mengenkripsi file dengan gaya Siu+Calcrick`);
        await updateProgress(
          ctx,
          progressMessage,
          40,
          "Inisialisasi Calcrick Chaos Core"
        );
        const obfuscated = await JsConfuser.obfuscate(
          fileContent,
          getSiuCalcrickObfuscationConfig()
        );
        let obfuscatedCode = obfuscated;
        if (typeof obfuscatedCode !== "string") {
          throw new Error("Hasil obfuscation bukan string");
        }
        console.log(
          `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
            0,
            50
          )}...`
        );
        console.log(
          `Ukuran file setelah obfuscation: ${Buffer.byteLength(
            obfuscatedCode,
            "utf-8"
          )} bytes`
        );

        console.log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
        try {
          new Function(obfuscatedCode);
        } catch (postObfuscationError) {
          console.log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
          throw new Error(
            `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
          );
        }

        await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
        await fs.writeFile(encryptedPath, obfuscatedCode);

        console.log(`Mengirim file terenkripsi gaya Siu+Calcrick: ${file.file_name}`);
        await ctx.replyWithDocument(
          {
            source: encryptedPath,
            filename: `siucalcrick-encrypted-${file.file_name}`,
          },
          {
            caption:
              "✅ *File terenkripsi (Calcrick Chaos Core) siap!*\nSUKSES ENCRYPT 🕊",
            parse_mode: "Markdown",
          }
        );
        await updateProgress(
          ctx,
          progressMessage,
          100,
          "Calcrick Chaos Core Selesai"
        );

        if (await fs.pathExists(encryptedPath)) {
          await fs.unlink(encryptedPath);
          console.log(`File sementara dihapus: ${encryptedPath}`);
        }
      } catch (error) {
        console.log("Kesalahan saat Siu+Calcrick obfuscation", error);
        await ctx.replyWithMarkdown(
          `❌ *Kesalahan:* ${
            error.message || "Tidak diketahui"
          }\n_Coba lagi dengan kode Javascript yang valid!_`
        );
        if (await fs.pathExists(encryptedPath)) {
          await fs.unlink(encryptedPath);
          console.log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
      }
    } catch (error) {
      console.error('Enc5 Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat obfuscation.');
    }
  });

  // Command: /enc2 (obfuscation custom dengan teks)
  bot.command("enc2", async (ctx) => {
    try {
      const customString = ctx.message.text.split(" ")[1];

      if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
        return ctx.replyWithMarkdown(
          "❌ *Error:* Balas file .js dengan `/enc2 <text>`!"
        );
      }

      if (!customString) {
        return ctx.replyWithMarkdown(
          "❌ *Error:* Balas file .js dengan `/enc2 <text>`!"
        );
      }

      const file = ctx.message.reply_to_message.document;
      if (!file.file_name.endsWith(".js")) {
        return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
      }

      const encryptedPath = path.join(__dirname, '../temp', `custom-encrypted-${file.file_name}`);

      try {
        const progressMessage = await ctx.replyWithMarkdown(
          "```css\n" +
            "🔒 EncryptBot\n" +
            " ⚙️ Memulai (custom enc) (1%)\n" +
            " " +
            createProgressBar(1) +
            "\n" +
            "```\n" +
            "PROSES ENCRYPT "
        );

        const fileLink = await ctx.telegram.getFileLink(file.file_id);
        console.log(`Mengunduh file untuk custom obfuscation: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 10, "Mengunduh");
        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

        console.log(`Memvalidasi kode awal: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
        try {
          new Function(fileContent);
        } catch (syntaxError) {
          throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
        }

        console.log(`Mengenkripsi file dengan gaya custom (${customString})`);
        await updateProgress(ctx, progressMessage, 40, `Inisialisasi custom (${customString})`);

        const obfuscated = await JsConfuser.obfuscate(
          fileContent,
          getCustomObfuscationConfig(customString)
        );

        let obfuscatedCode = obfuscated;
        if (typeof obfuscatedCode !== "string") {
          throw new Error("Hasil obfuscation bukan string");
        }
        console.log(
          `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
            0,
            50
          )}...`
        );
        console.log(
          `Ukuran file setelah obfuscation: ${Buffer.byteLength(
            obfuscatedCode,
            "utf-8"
          )} bytes`
        );

        console.log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
        try {
          new Function(obfuscatedCode);
        } catch (postObfuscationError) {
          console.log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
          throw new Error(
            `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
          );
        }

        await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
        await fs.writeFile(encryptedPath, obfuscatedCode);

        console.log(`Mengirim file terenkripsi gaya custom (${customString}): ${file.file_name}`);
        await ctx.replyWithDocument(
          {
            source: encryptedPath,
            filename: `custom-encrypted-${file.file_name}`,
          },
          {
            caption: `✅ *File terenkripsi custom (${customString}) siap!*\nSUKSES ENCRYPT 🕊`,
            parse_mode: "Markdown",
          }
        );
        await updateProgress(ctx, progressMessage, 100, `custom (${customString}) Selesai`);

        if (await fs.pathExists(encryptedPath)) {
          await fs.unlink(encryptedPath);
          console.log(`File sementara dihapus: ${encryptedPath}`);
        }
      } catch (error) {
        console.log("Kesalahan saat custom enc obfuscation", error);
        await ctx.replyWithMarkdown(
          `❌ *Kesalahan:* ${
            error.message || "Tidak diketahui"
          }\n_Coba lagi dengan kode Javascript yang valid!_`
        );
        if (await fs.pathExists(encryptedPath)) {
          await fs.unlink(encryptedPath);
          console.log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
      }
    } catch (error) {
      console.error('Enc2 Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat obfuscation.');
    }
  });

  // Command: /enc (obfuscation time-locked)
  bot.command("enc", async (ctx) => {
    try {
      const args = ctx.message.text.split(" ").slice(1);
      if (
        args.length !== 1 ||
        !/^\d+$/.test(args[0]) ||
        parseInt(args[0]) < 1 ||
        parseInt(args[0]) > 365
      ) {
        return ctx.replyWithMarkdown(
          "❌ *Error:* Gunakan format `/locked [1-365]` untuk jumlah hari (misal: `/enc 7`)!"
        );
      }

      const days = args[0];
      const expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + parseInt(days));
      const expiryFormatted = expiryDate.toLocaleDateString();

      if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
        return ctx.replyWithMarkdown(
          "❌ *Error:* Balas file .js dengan `/enc [1-365]`!"
        );
      }

      const file = ctx.message.reply_to_message.document;
      if (!file.file_name.endsWith(".js")) {
        return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
      }

      const encryptedPath = path.join(__dirname, '../temp', `locked-encrypted-${file.file_name}`);

      try {
        const progressMessage = await ctx.replyWithMarkdown(
          "```css\n" +
            "🔒 EncryptBot\n" +
            " ⚙️ Memulai (Time-Locked Encryption) (1%)\n" +
            " " +
            createProgressBar(1) +
            "\n" +
            "```\n" +
            "PROSES ENCRYPT "
        );

        const fileLink = await ctx.telegram.getFileLink(file.file_id);
        console.log(`Mengunduh file untuk Time-Locked Encryption: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 10, "Mengunduh");
        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

        console.log(`Memvalidasi kode awal: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
        try {
          new Function(fileContent);
        } catch (syntaxError) {
          throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
        }

        console.log(`Mengenkripsi file dengan Time-Locked Encryption`);
        await updateProgress(
          ctx,
          progressMessage,
          40,
          "Inisialisasi Time-Locked Encryption"
        );
        const obfuscatedCode = await obfuscateTimeLocked(fileContent, days);
        console.log(
          `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
            0,
            50
          )}...`
        );
        console.log(
          `Ukuran file setelah obfuscation: ${Buffer.byteLength(
            obfuscatedCode,
            "utf-8"
          )} bytes`
        );

        console.log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
        try {
          new Function(obfuscatedCode);
        } catch (postObfuscationError) {
          console.log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
          throw new Error(
            `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
          );
        }

        await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
        await fs.writeFile(encryptedPath, obfuscatedCode);

        console.log(`Mengirim file terenkripsi time-locked: ${file.file_name}`);
        await ctx.replyWithMarkdown(
          `✅ *File terenkripsi (Time-Locked Encryption) siap!*\n` +
            `⏰ Masa aktif: ${days} hari (Kedaluwarsa: ${expiryFormatted})\n` +
            `_Powered by Ginaa_`,
          { parse_mode: "Markdown" }
        );
        await ctx.replyWithDocument({
          source: encryptedPath,
          filename: `locked-encrypted-${file.file_name}`,
        });
        await updateProgress(
          ctx,
          progressMessage,
          100,
          "Time-Locked Encryption Selesai"
        );

        if (await fs.pathExists(encryptedPath)) {
          await fs.unlink(encryptedPath);
          console.log(`File sementara dihapus: ${encryptedPath}`);
        }
      } catch (error) {
        console.log("Kesalahan saat Time-Locked obfuscation", error);
        await ctx.replyWithMarkdown(
          `❌ *Kesalahan:* ${
            error.message || "Tidak diketahui"
          }\n_Coba lagi dengan kode Javascript yang valid!_`
        );
        if (await fs.pathExists(encryptedPath)) {
          await fs.unlink(encryptedPath);
          console.log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
      }
    } catch (error) {
      console.error('Enc Error:', error);
      await ctx.reply('❌ Terjadi kesalahan saat obfuscation.');
    }
  });
};