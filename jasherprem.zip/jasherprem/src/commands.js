const { Markup } = require('telegraf');
const { getUser, isPremium, addPremium, removePremium, getPremiumUsers, addBlacklist, removeBlacklist, getBlacklist, getGroups, deactivateGroup, addCredit, deductCredit, getCredit } = require('../lib/database');
const { runtime, formatTime, log } = require('../lib/utils');
const moment = require('moment-timezone');
const fs = require('fs-extra');
const path = require('path');
const fetch = require('node-fetch');

// Import obfuscation functions from obf.js
const obfuscationFunctions = require('./obf');

let autoJasherInterval = null;

function setupCommands(bot) {
    // Main menu command
    bot.command('start', async (ctx) => {
        const sender = ctx.from.username || ctx.from.first_name;
        const developer = process.env.DEVELOPER || '@ginaaforyou';
        const username = ctx.from.username ? `${ctx.from.username}` : 'Tidak ada username';
        const isCreator = ctx.from.id === parseInt(process.env.CREATOR_ID) || false;
        
        const menuText = `Hi kak @${sender}
╭─❒ 「 User Info 」 
├ Creator : ${developer}
├ Name : ${username}
├ Profile : @${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreator ? 'True' : 'False'}

Silahkan pilih button dibawah ini!`;

        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('🎯 Jasher Menu', 'jasher_menu')],
            [Markup.button.callback('👑 Owner Menu', 'owner_menu'), Markup.button.callback('🔒 Obf Menu', 'obf_menu')],
            [Markup.button.callback('ℹ️ Info', 'info_menu')]
        ]);

        try {
            await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
                caption: menuText,
                parse_mode: 'Markdown',
                ...keyboard
            });
        } catch (error) {
            await ctx.reply(menuText, {
                parse_mode: 'Markdown',
                ...keyboard
            });
        }
    });

    // Add premium command (owner only)
    bot.command('addprem', async (ctx) => {
        if (ctx.from.id !== parseInt(process.env.CREATOR_ID)) {
            return ctx.reply('❌ Anda bukan owner bot!');
        }

        const args = ctx.message.text.split(' ');
        if (args.length < 3) {
            return ctx.reply('❌ Format: /addprem [user_id] [days]');
        }

        const userId = parseInt(args[1]);
        const days = parseInt(args[2]);

        if (isNaN(userId) || isNaN(days) || days <= 0) {
            return ctx.reply('❌ User ID dan days harus angka yang valid!');
        }

        try {
            await addPremium(userId, days);
            ctx.reply(`✅ Berhasil menambahkan ${days} hari premium untuk user ${userId}`);
        } catch (error) {
            ctx.reply('❌ Gagal menambahkan premium: ' + error.message);
        }
    });

    // Remove premium command (owner only)
    bot.command('delprem', async (ctx) => {
        if (ctx.from.id !== parseInt(process.env.CREATOR_ID)) {
            return ctx.reply('❌ Anda bukan owner bot!');
        }

        const args = ctx.message.text.split(' ');
        if (args.length < 2) {
            return ctx.reply('❌ Format: /delprem [user_id]');
        }

        const userId = parseInt(args[1]);

        if (isNaN(userId)) {
            return ctx.reply('❌ User ID harus angka yang valid!');
        }

        try {
            await removePremium(userId);
            ctx.reply(`✅ Berhasil menghapus premium untuk user ${userId}`);
        } catch (error) {
            ctx.reply('❌ Gagal menghapus premium: ' + error.message);
        }
    });

    // List premium users command (owner only)
    bot.command('listprem', async (ctx) => {
        if (ctx.from.id !== parseInt(process.env.CREATOR_ID)) {
            return ctx.reply('❌ Anda bukan owner bot!');
        }

        try {
            const premiumUsers = await getPremiumUsers();
            if (premiumUsers.length === 0) {
                return ctx.reply('❌ Tidak ada user premium saat ini.');
            }

            let message = '👑 Daftar User Premium:\n\n';
            premiumUsers.forEach(user => {
                const expiry = formatTime(user.premium_expiry);
                message += `👤 User: ${user.user_id} (${user.username})\n⏰ Expiry: ${expiry}\n\n`;
            });

            ctx.reply(message);
        } catch (error) {
            ctx.reply('❌ Gagal mengambil daftar premium: ' + error.message);
        }
    });

    // Add blacklist command (owner only)
    bot.command('addbl', async (ctx) => {
        if (ctx.from.id !== parseInt(process.env.CREATOR_ID)) {
            return ctx.reply('❌ Anda bukan owner bot!');
        }

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.forward_from_chat) {
            return ctx.reply('❌ Balas pesan yang diforward dari grup yang ingin di-blacklist!');
        }

        const groupId = ctx.message.reply_to_message.forward_from_chat.id;
        const reason = ctx.message.text.split(' ').slice(1).join(' ') || 'Tidak ada alasan';

        try {
            await addBlacklist(groupId, reason);
            ctx.reply(`✅ Berhasil menambahkan grup ${groupId} ke blacklist.`);
        } catch (error) {
            ctx.reply('❌ Gagal menambahkan blacklist: ' + error.message);
        }
    });

    // Remove blacklist command (owner only)
    bot.command('delbl', async (ctx) => {
        if (ctx.from.id !== parseInt(process.env.CREATOR_ID)) {
            return ctx.reply('❌ Anda bukan owner bot!');
        }

        const args = ctx.message.text.split(' ');
        if (args.length < 2) {
            return ctx.reply('❌ Format: /delbl [group_id]');
        }

        const groupId = parseInt(args[1]);

        if (isNaN(groupId)) {
            return ctx.reply('❌ Group ID harus angka yang valid!');
        }

        try {
            await removeBlacklist(groupId);
            ctx.reply(`✅ Berhasil menghapus grup ${groupId} dari blacklist.`);
        } catch (error) {
            ctx.reply('❌ Gagal menghapus blacklist: ' + error.message);
        }
    });

    // List blacklist command (owner only)
    bot.command('listbl', async (ctx) => {
        if (ctx.from.id !== parseInt(process.env.CREATOR_ID)) {
            return ctx.reply('❌ Anda bukan owner bot!');
        }

        try {
            const blacklist = await getBlacklist();
            if (blacklist.length === 0) {
                return ctx.reply('✅ Tidak ada grup dalam blacklist.');
            }

            let message = '🚫 Daftar Blacklist Grup:\n\n';
            blacklist.forEach(item => {
                message += `👥 Group ID: ${item.group_id}\n📝 Reason: ${item.reason}\n⏰ Added: ${formatTime(item.created_at)}\n\n`;
            });

            ctx.reply(message);
        } catch (error) {
            ctx.reply('❌ Gagal mengambil daftar blacklist: ' + error.message);
        }
    });

    // Auto Jasher command (owner only)
    bot.command('autojasher', async (ctx) => {
        if (ctx.from.id !== parseInt(process.env.CREATOR_ID)) {
            return ctx.reply('❌ Anda bukan owner bot!');
        }

        if (autoJasherInterval) {
            return ctx.reply('❌ Auto Jasher sudah berjalan!');
        }

        // Start auto jasher every 10 minutes
        autoJasherInterval = setInterval(async () => {
            try {
                const groups = await getGroups();
                const premiumUsers = await getPremiumUsers();
                
                if (groups.length === 0 || premiumUsers.length === 0) {
                    return;
                }

                // Send message to all groups
                for (const group of groups) {
                    try {
                        const message = `🔔 *Auto Jasher Notification* 🔔\n\n` +
                                      `Hai members! Bot Jasher sedang berjalan otomatis.\n` +
                                      `Gunakan /start untuk melihat menu bot.`;
                        
                        await ctx.telegram.sendMessage(group.group_id, message, {
                            parse_mode: 'Markdown'
                        });
                    } catch (error) {
                        if (error.response && error.response.error_code === 403) {
                            // Bot was kicked from the group, deactivate it
                            await deactivateGroup(group.group_id);
                        }
                    }
                }
            } catch (error) {
                console.error('Error in auto jasher:', error);
            }
        }, 10 * 60 * 1000); // 10 minutes

        ctx.reply('✅ Auto Jasher telah diaktifkan dan akan berjalan setiap 10 menit.');
    });

    // Stop Auto Jasher command (owner only)
    bot.command('stopautojasher', async (ctx) => {
        if (ctx.from.id !== parseInt(process.env.CREATOR_ID)) {
            return ctx.reply('❌ Anda bukan owner bot!');
        }

        if (!autoJasherInterval) {
            return ctx.reply('❌ Auto Jasher tidak sedang berjalan!');
        }

        clearInterval(autoJasherInterval);
        autoJasherInterval = null;
        ctx.reply('✅ Auto Jasher telah dihentikan.');
    });

    // List groups command (owner only)
    bot.command('listgrup', async (ctx) => {
        if (ctx.from.id !== parseInt(process.env.CREATOR_ID)) {
            return ctx.reply('❌ Anda bukan owner bot!');
        }

        try {
            const groups = await getGroups();
            if (groups.length === 0) {
                return ctx.reply('❌ Tidak ada grup yang terdaftar.');
            }

            let message = '👥 Daftar Grup Aktif:\n\n';
            groups.forEach((group, index) => {
                message += `${index + 1}. ${group.group_name} (ID: ${group.group_id})\n` +
                          `   Ditambahkan oleh: ${group.added_by}\n` +
                          `   Tanggal: ${formatTime(group.created_at)}\n\n`;
            });

            // Split message if too long
            if (message.length > 4096) {
                const parts = message.match(/[\s\S]{1,4096}/g) || [];
                for (const part of parts) {
                    await ctx.reply(part);
                }
            } else {
                ctx.reply(message);
            }
        } catch (error) {
            ctx.reply('❌ Gagal mengambil daftar grup: ' + error.message);
        }
    });

    // To URL command (convert photo to URL)
    bot.command('tourl', async (ctx) => {
        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.photo) {
            return ctx.reply('❌ Balas sebuah foto dengan perintah ini untuk mengconvertnya ke URL!');
        }

        try {
            const photo = ctx.message.reply_to_message.photo;
            const fileId = photo[photo.length - 1].file_id;
            const file = await ctx.telegram.getFile(fileId);
            const fileUrl = `https://api.telegram.org/file/bot${process.env.BOT_TOKEN}/${file.file_path}`;
            
            ctx.reply(`✅ Berhasil convert foto ke URL:\n${fileUrl}`);
        } catch (error) {
            ctx.reply('❌ Gagal convert foto ke URL: ' + error.message);
        }
    });

    // Share command (for premium users)
    bot.command('share', async (ctx) => {
        if (ctx.chat.type !== 'private') {
            return ctx.reply('❌ Perintah ini hanya bisa digunakan di private chat!');
        }

        const userPremium = await isPremium(ctx.from.id);
        if (!userPremium) {
            return ctx.reply('❌ Anda harus premium untuk menggunakan fitur share!');
        }

        const userCredit = await getCredit(ctx.from.id);
        if (userCredit < 1) {
            return ctx.reply('❌ Kredit Anda tidak cukup untuk share!');
        }

        if (!ctx.message.reply_to_message) {
            return ctx.reply('❌ Balas pesan yang ingin di-share dengan perintah ini!');
        }

        try {
            // Deduct credit
            await deductCredit(ctx.from.id, 1);
            
            const groups = await getGroups();
            let successCount = 0;
            let failCount = 0;
            
            // Send to all groups
            for (const group of groups) {
                try {
                    if (ctx.message.reply_to_message.text) {
                        await ctx.telegram.sendMessage(group.group_id, ctx.message.reply_to_message.text, {
                            parse_mode: 'Markdown'
                        });
                    } else if (ctx.message.reply_to_message.photo) {
                        const photo = ctx.message.reply_to_message.photo;
                        const caption = ctx.message.reply_to_message.caption || '';
                        await ctx.telegram.sendPhoto(group.group_id, photo[photo.length - 1].file_id, {
                            caption: caption,
                            parse_mode: 'Markdown'
                        });
                    }
                    successCount++;
                } catch (error) {
                    failCount++;
                    if (error.response && error.response.error_code === 403) {
                        // Bot was kicked from the group, deactivate it
                        await deactivateGroup(group.group_id);
                    }
                }
            }
            
            ctx.reply(`✅ Share berhasil!\nBerhasil: ${successCount} grup\nGagal: ${failCount} grup\nSisa kredit: ${userCredit - 1}`);
        } catch (error) {
            ctx.reply('❌ Gagal melakukan share: ' + error.message);
        }
    });

    // Share VIP command (faster share for premium users)
    bot.command('sharevip', async (ctx) => {
        if (ctx.chat.type !== 'private') {
            return ctx.reply('❌ Perintah ini hanya bisa digunakan di private chat!');
        }

        const userPremium = await isPremium(ctx.from.id);
        if (!userPremium) {
            return ctx.reply('❌ Anda harus premium untuk menggunakan fitur share VIP!');
        }

        const userCredit = await getCredit(ctx.from.id);
        if (userCredit < 2) {
            return ctx.reply('❌ Kredit Anda tidak cukup untuk share VIP!');
        }

        if (!ctx.message.reply_to_message) {
            return ctx.reply('❌ Balas pesan yang ingin di-share dengan perintah ini!');
        }

        try {
            // Deduct credit
            await deductCredit(ctx.from.id, 2);
            
            const groups = await getGroups();
            const messagePromises = [];
            
            // Create promises for all groups
            for (const group of groups) {
                try {
                    if (ctx.message.reply_to_message.text) {
                        messagePromises.push(
                            ctx.telegram.sendMessage(group.group_id, ctx.message.reply_to_message.text, {
                                parse_mode: 'Markdown'
                            }).catch(async error => {
                                if (error.response && error.response.error_code === 403) {
                                    await deactivateGroup(group.group_id);
                                }
                                throw error;
                            })
                        );
                    } else if (ctx.message.reply_to_message.photo) {
                        const photo = ctx.message.reply_to_message.photo;
                        const caption = ctx.message.reply_to_message.caption || '';
                        messagePromises.push(
                            ctx.telegram.sendPhoto(group.group_id, photo[photo.length - 1].file_id, {
                                caption: caption,
                                parse_mode: 'Markdown'
                            }).catch(async error => {
                                if (error.response && error.response.error_code === 403) {
                                    await deactivateGroup(group.group_id);
                                }
                                throw error;
                            })
                        );
                    }
                } catch (error) {
                    // Continue with next group
                }
            }
            
            // Wait for all promises to settle
            const results = await Promise.allSettled(messagePromises);
            const successCount = results.filter(r => r.status === 'fulfilled').length;
            const failCount = results.filter(r => r.status === 'rejected').length;
            
            ctx.reply(`✅ Share VIP berhasil!\nBerhasil: ${successCount} grup\nGagal: ${failCount} grup\nSisa kredit: ${userCredit - 2}`);
        } catch (error) {
            ctx.reply('❌ Gagal melakukan share VIP: ' + error.message);
        }
    });

    // Broadcast command (owner only)
    bot.command('broadcast', async (ctx) => {
        if (ctx.from.id !== parseInt(process.env.CREATOR_ID)) {
            return ctx.reply('❌ Anda bukan owner bot!');
        }

        if (!ctx.message.reply_to_message) {
            return ctx.reply('❌ Balas pesan yang ingin di-broadcast dengan perintah ini!');
        }

        try {
            const users = await getAllUsers();
            let successCount = 0;
            let failCount = 0;
            
            for (const user of users) {
                try {
                    if (ctx.message.reply_to_message.text) {
                        await ctx.telegram.sendMessage(user.user_id, ctx.message.reply_to_message.text, {
                            parse_mode: 'Markdown'
                        });
                    } else if (ctx.message.reply_to_message.photo) {
                        const photo = ctx.message.reply_to_message.photo;
                        const caption = ctx.message.reply_to_message.caption || '';
                        await ctx.telegram.sendPhoto(user.user_id, photo[photo.length - 1].file_id, {
                            caption: caption,
                            parse_mode: 'Markdown'
                        });
                    }
                    successCount++;
                } catch (error) {
                    failCount++;
                }
                
                // Delay to avoid rate limiting
                await new Promise(resolve => setTimeout(resolve, 100));
            }
            
            ctx.reply(`✅ Broadcast berhasil!\nBerhasil: ${successCount} user\nGagal: ${failCount} user`);
        } catch (error) {
            ctx.reply('❌ Gagal melakukan broadcast: ' + error.message);
        }
    });

    // Helper function to get all users
    async function getAllUsers() {
        return new Promise((resolve, reject) => {
            db.all('SELECT user_id FROM users', (err, rows) => {
                if (err) reject(err);
                else resolve(rows);
            });
        });
    }
}

module.exports = {
    setupCommands
};