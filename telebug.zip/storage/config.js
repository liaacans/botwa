const global = {
    owner: [7953031989], // ganti jadi id mu
    botToken: "7713715332:AAHs2sw0-Eahs1N1paytMdsziTtPX3EVjtw", //isi make token bot mu
}

module.exports = global;