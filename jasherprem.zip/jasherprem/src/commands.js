const { User, Group } = require('../lib/database');
const { formatUserInfo } = require('../lib/utils');
const { mainMenuKeyboard, jasherMenuKeyboard, ownerMenuKeyboard, backKeyboard } = require('./keyboards');
const config = require('../config');

async function handleStart(ctx) {
    try {
        let user = await User.findOne({ userId: ctx.from.id });
        
        if (!user) {
            user = new User({
                userId: ctx.from.id,
                username: ctx.from.username,
                firstName: ctx.from.first_name,
                lastName: ctx.from.last_name,
                isCreator: ctx.from.id.toString() === config.CREATOR_ID
            });
            await user.save();
        }
        
        const message = formatUserInfo(ctx, user);
        await ctx.replyWithHTML(message, mainMenuKeyboard());
    } catch (error) {
        console.error('Error in start command:', error);
        ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleHelp(ctx) {
    const helpText = `
<b>Jasher Bot Commands:</b>
/start - Memulai bot
/help - Menampilkan bantuan

<b>Fitur:</b>
- Share: Berbagi pesan ke grup (2 kredit)
- ShareVIP: Berbagi pesan ke grup lebih cepat (1 kredit)
- Credit: Melihat kredit Anda
- AddGroup: Menambahkan bot ke grup untuk mendapatkan kredit

<b>Untuk Premium:</b>
- AddPrem: Menambahkan user premium (Owner only)
- DelPrem: Menghapus user premium (Owner only)
- ListPrem: Melihat daftar premium (Owner only)
- Broadcast: Mengirim pesan ke semua user (Owner only)
    `;
    
    await ctx.replyWithHTML(helpText, mainMenuKeyboard());
}

async function handleCredit(ctx) {
    try {
        const user = await User.findOne({ userId: ctx.from.id });
        if (!user) return ctx.reply('Silakan jalankan /start terlebih dahulu.');
        
        await ctx.replyWithHTML(`Kredit Anda: <b>${user.credit}</b>\n\nTambahkan bot ke ${config.GROUP_REQUIREMENT - user.addedGroups.length} grup lagi untuk mendapatkan ${config.CREDIT_REWARD} kredit!`, mainMenuKeyboard());
    } catch (error) {
        console.error('Error in credit command:', error);
        ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleAddGroup(ctx) {
    try {
        if (ctx.chat.type === 'private') {
            return ctx.reply('Perintah ini hanya bisa digunakan di dalam grup!');
        }
        
        const user = await User.findOne({ userId: ctx.from.id });
        if (!user) return ctx.reply('Silakan jalankan /start terlebih dahulu.');
        
        // Cek apakah grup sudah pernah ditambahkan
        const existingGroup = await Group.findOne({ groupId: ctx.chat.id });
        if (existingGroup) {
            return ctx.reply('Grup ini sudah pernah ditambahkan sebelumnya.');
        }
        
        // Simpan grup
        const group = new Group({
            groupId: ctx.chat.id,
            groupTitle: ctx.chat.title,
            addedBy: ctx.from.id
        });
        await group.save();
        
        // Tambahkan ke daftar grup user
        user.addedGroups.push({
            groupId: ctx.chat.id,
            groupTitle: ctx.chat.title
        });
        
        // Beri kredit jika sudah memenuhi syarat
        if (user.addedGroups.length >= config.GROUP_REQUIREMENT && user.credit < config.CREDIT_REWARD) {
            user.credit += config.CREDIT_REWARD;
            await ctx.reply(`Terima kasih! Anda telah menambahkan bot ke ${config.GROUP_REQUIREMENT} grup. Anda mendapatkan ${config.CREDIT_REWARD} kredit!`);
        }
        
        await user.save();
        await ctx.reply(`Grup "${ctx.chat.title}" berhasil ditambahkan!`);
    } catch (error) {
        console.error('Error in addgroup command:', error);
        ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleShare(ctx) {
    try {
        if (ctx.chat.type !== 'private') {
            return ctx.reply('Fitur share hanya bisa digunakan di private chat!');
        }
        
        const user = await User.findOne({ userId: ctx.from.id });
        if (!user) return ctx.reply('Silakan jalankan /start terlebih dahulu.');
        
        if (user.credit < config.SHARE_COST) {
            return ctx.reply(`Kredit Anda tidak cukup. Dibutuhkan ${config.SHARE_COST} kredit untuk share.`);
        }
        
        if (!ctx.message.reply_to_message) {
            return ctx.reply('Anda harus membalas pesan yang ingin di-share!');
        }
        
        // Kurangi kredit
        user.credit -= config.SHARE_COST;
        await user.save();
        
        // Kirim ke semua grup
        const groups = await Group.find();
        let successCount = 0;
        
        for (const group of groups) {
            try {
                await ctx.telegram.copyMessage(group.groupId, ctx.chat.id, ctx.message.reply_to_message.message_id);
                successCount++;
            } catch (error) {
                console.error(`Error sending to group ${group.groupId}:`, error);
            }
        }
        
        await ctx.reply(`Pesan berhasil di-share ke ${successCount} grup! Kredit berkurang ${config.SHARE_COST}.`);
    } catch (error) {
        console.error('Error in share command:', error);
        ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleShareVIP(ctx) {
    try {
        if (ctx.chat.type !== 'private') {
            return ctx.reply('Fitur shareVIP hanya bisa digunakan di private chat!');
        }
        
        const user = await User.findOne({ userId: ctx.from.id });
        if (!user) return ctx.reply('Silakan jalankan /start terlebih dahulu.');
        
        if (!user.isPremium) {
            return ctx.reply('Anda bukan user premium!');
        }
        
        if (user.credit < config.PREMIUM_SHARE_COST) {
            return ctx.reply(`Kredit Anda tidak cukup. Dibutuhkan ${config.PREMIUM_SHARE_COST} kredit untuk shareVIP.`);
        }
        
        if (!ctx.message.reply_to_message) {
            return ctx.reply('Anda harus membalas pesan yang ingin di-share!');
        }
        
        // Kurangi kredit
        user.credit -= config.PREMIUM_SHARE_COST;
        await user.save();
        
        // Kirim ke semua grup (lebih cepat dengan Promise.all)
        const groups = await Group.find();
        const sendPromises = groups.map(group => 
            ctx.telegram.copyMessage(group.groupId, ctx.chat.id, ctx.message.reply_to_message.message_id)
                .catch(error => console.error(`Error sending to group ${group.groupId}:`, error))
        );
        
        await Promise.all(sendPromises);
        await ctx.reply(`Pesan berhasil di-shareVIP ke ${groups.length} grup! Kredit berkurang ${config.PREMIUM_SHARE_COST}.`);
    } catch (error) {
        console.error('Error in shareVIP command:', error);
        ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

// Owner commands
async function handleBroadcast(ctx) {
    try {
        const user = await User.findOne({ userId: ctx.from.id });
        if (!user || !user.isCreator) {
            return ctx.reply('Anda tidak memiliki akses untuk perintah ini!');
        }
        
        if (!ctx.message.reply_to_message) {
            return ctx.reply('Anda harus membalas pesan yang ingin di-broadcast!');
        }
        
        const users = await User.find();
        let successCount = 0;
        
        for (const u of users) {
            try {
                await ctx.telegram.copyMessage(u.userId, ctx.chat.id, ctx.message.reply_to_message.message_id);
                successCount++;
            } catch (error) {
                console.error(`Error broadcasting to user ${u.userId}:`, error);
            }
        }
        
        await ctx.reply(`Broadcast berhasil dikirim ke ${successCount} user!`);
    } catch (error) {
        console.error('Error in broadcast command:', error);
        ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleAddPrem(ctx) {
    try {
        const user = await User.findOne({ userId: ctx.from.id });
        if (!user || !user.isCreator) {
            return ctx.reply('Anda tidak memiliki akses untuk perintah ini!');
        }
        
        if (!ctx.message.reply_to_message) {
            return ctx.reply('Anda harus membalas pesan user yang ingin ditambahkan sebagai premium!');
        }
        
        const targetUserId = ctx.message.reply_to_message.from.id;
        const targetUser = await User.findOne({ userId: targetUserId });
        
        if (!targetUser) {
            return ctx.reply('User tidak ditemukan!');
        }
        
        targetUser.isPremium = true;
        await targetUser.save();
        
        await ctx.reply('User berhasil ditambahkan sebagai premium!');
        await ctx.telegram.sendMessage(targetUserId, 'Selamat! Anda sekarang adalah user premium!');
    } catch (error) {
        console.error('Error in addprem command:', error);
        ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleDelPrem(ctx) {
    try {
        const user = await User.findOne({ userId: ctx.from.id });
        if (!user || !user.isCreator) {
            return ctx.reply('Anda tidak memiliki akses untuk perintah ini!');
        }
        
        if (!ctx.message.reply_to_message) {
            return ctx.reply('Anda harus membalas pesan user yang ingin dihapus dari premium!');
        }
        
        const targetUserId = ctx.message.reply_to_message.from.id;
        const targetUser = await User.findOne({ userId: targetUserId });
        
        if (!targetUser) {
            return ctx.reply('User tidak ditemukan!');
        }
        
        targetUser.isPremium = false;
        await targetUser.save();
        
        await ctx.reply('User berhasil dihapus dari premium!');
        await ctx.telegram.sendMessage(targetUserId, 'Status premium Anda telah dicabut.');
    } catch (error) {
        console.error('Error in delprem command:', error);
        ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleListPrem(ctx) {
    try {
        const user = await User.findOne({ userId: ctx.from.id });
        if (!user || !user.isCreator) {
            return ctx.reply('Anda tidak memiliki akses untuk perintah ini!');
        }
        
        const premiumUsers = await User.find({ isPremium: true });
        
        if (premiumUsers.length === 0) {
            return ctx.reply('Tidak ada user premium!');
        }
        
        let listText = '<b>Daftar User Premium:</b>\n\n';
        premiumUsers.forEach((u, index) => {
            listText += `${index + 1}. ${u.firstName} ${u.lastName || ''} (${u.username ? '@' + u.username : 'no username'}) - ID: ${u.userId}\n`;
        });
        
        await ctx.replyWithHTML(listText);
    } catch (error) {
        console.error('Error in listprem command:', error);
        ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

module.exports = {
    handleStart,
    handleHelp,
    handleCredit,
    handleAddGroup,
    handleShare,
    handleShareVIP,
    handleBroadcast,
    handleAddPrem,
    handleDelPrem,
    handleListPrem
};