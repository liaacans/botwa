const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const crypto = require('crypto');
const qs = require('qs');
const { createCanvas, loadImage } = require('canvas');
const QRCode = require('qrcode');
const moment = require('moment');

// Load Config
const config = require('./config.js');

const bot = new TelegramBot(config.BOT_TOKEN, { polling: true });

// ==================== DATABASE PATHS ====================
const databaseDir = './library/database';
const saldoPath = path.join(databaseDir, 'saldo.json');
const usersFile = path.join(databaseDir, 'users.json');
const transaksiPath = path.join(databaseDir, 'transaksi.json');
const panelPurchasesPath = path.join(databaseDir, 'panel_purchases.json');
const warrantyClaimsPath = path.join(databaseDir, 'warranty_claims.json');
const resellerPath = path.join(databaseDir, 'reseller.json');
const resellerStatsPath = path.join(databaseDir, 'reseller_stats.json');
const specialPanelsPath = path.join(databaseDir, 'special_panels.json');
const appsPath = path.join(databaseDir, 'apps.json');
const documentsPath = path.join(databaseDir, 'documents.json');
const userStartPath = path.join(databaseDir, 'user_start.json');

//let startAutoBackup = true

// Ensure directories exist
[ databaseDir, './library/functions', './source/src' ].forEach(dir => {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

// Initialize database files
const dbFiles = {
    [saldoPath]: {},
    [usersFile]: [],
    [transaksiPath]: [],
    [panelPurchasesPath]: [],
    [warrantyClaimsPath]: [],
    [resellerPath]: {},
    [resellerStatsPath]: {},
    [specialPanelsPath]: [],
    [appsPath]: [],
    [documentsPath]: [],
    [userStartPath]: []
};

// ==================== GLOBAL VARIABLES ====================
const activeDeposit = {};
const activeDirectQRIS = {};
const pendingPurchases = {};
const pendingResellerCreation = {};
const pendingUsername = {};
const pendingWarrantyClaims = {};
const adminChatSessions = {};
const userChatSessions = {};
const resellerSellSessions = {};
const loadingMessages = {};
const botStartTime = Date.now();

// Track notified users to avoid duplicate notifications
const notifiedUsers = new Set();

Object.entries(dbFiles).forEach(([filePath, defaultData]) => {
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify(defaultData, null, 2));
    }
});

// ==================== LOADING FRAMES ====================
const loadingFrames = [
  "💠 *[ GINA AI - SYSTEM BOOT SEQUENCE ]*\n\n[░░░░░░░░░░] 0%  \n🌌 Initializing quantum cores...\n🌀 Calibrating neural matrix...\n💡 *Operator, prepare for launch!*",
  
  "🌐 *[ STAGE 1: NETWORK LINKING ]*\n\n[█░█░░░░░░░] 10%  \n📡 Connecting to GINA Cloud Nodes...\n🔑 TLS 1.3 handshake success\n⚠️ Firewall scanning...",
  
  "🔐 *[ STAGE 2: SECURITY PROTOCOLS ]*\n\n[██░█░░░░░░] 20%  \n🛡 RSA-8192 keys generated\n🚨 Intrusion detection active\n🗝 Session key ready: `#E7F-1X4-A9Z`",
  
  "📦 *[ STAGE 3: MODULE INJECTION ]*\n\n[███░█░░░░░] 30%  \n📁 Loading AI cognitive modules...\n💾 RAM blocks allocated\n✅ Module injection complete",
  
  "🧠 *[ STAGE 4: NEURAL ENGINE ENGAGE ]*\n\n[████░█░░░░] 45%  \n⚙️ Neural Engine `GINA-GPTx` online\n🌀 Synapse links synchronized\n🌌 Deep learning modules activated",
  
  "☁️ *[ STAGE 5: CLOUD SYNCING ]*\n\n[█████░█░░░] 55%  \n🔗 Establishing uplinks\n📡 Telemetry streaming online\n🛰 Cloud nodes fully linked",
  
  "📊 *[ STAGE 6: SYSTEM VALIDATION ]*\n\n[██████░█░░] 65%  \n📑 Running integrity checks\n✅ Subsystems verified\n🔍 Performance metrics stable",
  
  "🎨 *[ STAGE 7: INTERFACE RENDERING ]*\n\n[███████░█░] 75%  \n🌟 Loading holographic UI\n🎛 Console initialized\n✨ Shaders applied",
  
  "💥 *[ STAGE 8: MODULE CALIBRATION ]*\n\n[████████░█] 85%  \n🛠 Optimizing algorithms\n⚡ Neural pathways stabilized\n🧬 Quantum cache refreshed",
  
  "🌀 *[ STAGE 9: FINALIZATION ]*\n\n[█████████░] 95%  \n💎 Core optimization complete\n🔄 Cluster cache refreshed\n📡 Systems green",
  
  "✅ *[ SYSTEM ONLINE ]*\n\n[██████████] 100%  \n🧠 GINA AI fully operational\n🌌 Cloud links active\n🚀 Ready for operator commands",
  
  "\`\`\`Javascript 🎉 *ACCESS GRANTED!* 🎉\n\n👨‍💻 Welcome, Operator Elite\n🤖 AI Assistant active\n📦 GinaOfficial Shop ONLINE\n💳 Payment Gateway READY\n🔑 Security protocols verified\`\`\`"
];

// ==================== FUNGSI HELPER ====================
function startAutoBackup() {
    // Jalankan backup pertama kali setelah bot start (dalam 1 menit)
    setTimeout(() => {
        sendBackupToOwner();
    }, 60000);

    // Jadwalkan backup setiap 30 menit
    setInterval(() => {
        sendBackupToOwner();
    }, 30 * 60 * 1000); // 30 menit dalam milidetik

    console.log('🔄 Sistem backup otomatis diaktifkan (setiap 30 menit)');
}

function toRupiah(number) {
    return Number(number).toLocaleString("id-ID");
}

function generateSecurePassword(username) {
    const randomNum = Math.floor(Math.random() * 1000);
    const specialChars = '@#%&*';
    const randomChar = specialChars[Math.floor(Math.random() * specialChars.length)];
    return `${username}${randomNum}${randomChar}`;
}

function getUserSaldo(userId) {
    try {
        const data = JSON.parse(fs.readFileSync(saldoPath));
        return data[userId] || 0;
    } catch (e) {
        return 0;
    }
}

function setUserSaldo(userId, saldo) {
    try {
        const data = JSON.parse(fs.readFileSync(saldoPath));
        data[userId] = saldo;
        fs.writeFileSync(saldoPath, JSON.stringify(data, null, 2));
    } catch (e) {
        console.error("❌ Gagal simpan saldo:", e.message);
    }
}

function isReseller(userId) {
    try {
        const resellers = JSON.parse(fs.readFileSync(resellerPath));
        return !!resellers[userId];
    } catch (e) {
        return false;
    }
}

function getResellerInfo(userId) {
    try {
        const resellers = JSON.parse(fs.readFileSync(resellerPath));
        return resellers[userId] || null;
    } catch (e) {
        return null;
    }
}

function saveReseller(userId, packageType) {
    try {
        const resellers = JSON.parse(fs.readFileSync(resellerPath));
        resellers[userId] = {
            package: packageType,
            joinDate: new Date().toISOString(),
            daily_limit: config.RESELLER[packageType].daily_limit,
            max_ram: config.RESELLER[packageType].max_ram,
            status: 'active'
        };
        fs.writeFileSync(resellerPath, JSON.stringify(resellers, null, 2));
    } catch (e) {
        console.error("❌ Gagal simpan reseller:", e.message);
    }
}

// ==================== RUNTIME & STATS FUNCTIONS ====================
function getRuntime() {
    const now = Date.now();
    const diff = now - botStartTime;
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);
    
    return `${days}d ${hours}h ${minutes}m ${seconds}s`;
}

function getTotalUsers() {
    try {
        const saldoData = JSON.parse(fs.readFileSync(saldoPath));
        return Object.keys(saldoData).length;
    } catch (e) {
        return 0;
    }
}

function getTotalTransactions() {
    try {
        const transaksi = JSON.parse(fs.readFileSync(transaksiPath));
        return transaksi.length;
    } catch (e) {
        return 0;
    }
}

function getTotalPanels() {
    try {
        const panels = JSON.parse(fs.readFileSync(panelPurchasesPath));
        const specialPanels = JSON.parse(fs.readFileSync(specialPanelsPath));
        return panels.length + specialPanels.length;
    } catch (e) {
        return 0;
    }
}

// ==================== BACKUP SYSTEM ====================
const backupFiles = [
    saldoPath,
    usersFile,
    transaksiPath,
    panelPurchasesPath,
    warrantyClaimsPath,
    resellerPath,
    resellerStatsPath,
    specialPanelsPath,
    appsPath,
    documentsPath,
    userStartPath
];

async function createBackup() {
    try {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const backupDir = './library/backup';
        
        // Ensure backup directory exists
        if (!fs.existsSync(backupDir)) {
            fs.mkdirSync(backupDir, { recursive: true });
        }

        const backupData = {};
        
        // Read all database files
        for (const filePath of backupFiles) {
            try {
                if (fs.existsSync(filePath)) {
                    const fileName = path.basename(filePath);
                    const fileContent = fs.readFileSync(filePath, 'utf8');
                    backupData[fileName] = fileContent;
                }
            } catch (error) {
                console.error(`❌ Gagal membaca file ${filePath}:`, error.message);
            }
        }

        // Create backup file
        const backupFileName = `backup-${timestamp}.json`;
        const backupFilePath = path.join(backupDir, backupFileName);
        
        fs.writeFileSync(backupFilePath, JSON.stringify({
            timestamp: new Date().toISOString(),
            data: backupData
        }, null, 2));

        console.log(`✅ Backup created: ${backupFileName}`);
        return backupFilePath;
        
    } catch (error) {
        console.error('❌ Backup creation error:', error);
        return null;
    }
}

async function sendBackupToOwner() {
    try {
        console.log('🔄 Memulai proses backup otomatis...');
        
        const backupFilePath = await createBackup();
        if (!backupFilePath) {
            throw new Error('Gagal membuat file backup');
        }

        // Read backup file
        const backupFile = fs.readFileSync(backupFilePath);
        const backupData = JSON.parse(backupFile.toString());
        const timestamp = new Date(backupData.timestamp).toLocaleString('id-ID');

        // Prepare statistics
        const stats = {
            totalUsers: getTotalUsers(),
            totalTransactions: getTotalTransactions(),
            totalPanels: getTotalPanels(),
            totalResellers: Object.keys(JSON.parse(fs.readFileSync(resellerPath))).length,
            totalApps: getAllApps().length,
            totalDocuments: getAllDocuments().length,
            totalWarrantyClaims: getAllWarrantyClaims().length,
            botRuntime: getRuntime()
        };

        const caption = `\`\`\`Javascript
💾 *BACKUP DATA OTOMATIS*
━━━━━━━━━━━━━━━━━━━━━━━━━━
🕐 Waktu: ${timestamp}
⏱️ Runtime: ${stats.botRuntime}

📊 *STATISTIK SISTEM:*
• 👥 Total Users: ${stats.totalUsers}
• 📦 Total Transaksi: ${stats.totalTransactions}
• 🖥️ Total Panel: ${stats.totalPanels}
• 💼 Total Reseller: ${stats.totalResellers}
• 📱 Total Apps: ${stats.totalApps}
• 💻 Total Documents: ${stats.totalDocuments}
• 🛡️ Total Klaim Garansi: ${stats.totalWarrantyClaims}

✅ Backup berhasil dibuat dan disimpan.
File backup terlampir.
\`\`\``;

        // Send backup file to owner
        await bot.sendDocument(config.OWNER_ID, backupFilePath, {
            caption: caption,
            parse_mode: "Markdown"
        });

        console.log('✅ Backup berhasil dikirim ke owner');

        // Clean up backup file after sending
        setTimeout(() => {
            try {
                fs.unlinkSync(backupFilePath);
                console.log('🧹 File backup lokal dibersihkan');
            } catch (cleanupError) {
                console.error('❌ Gagal membersihkan file backup:', cleanupError.message);
            }
        }, 5000);

    } catch (error) {
        console.error('❌ Backup sending error:', error);
        
        // Notify owner about backup failure
        try {
            await bot.sendMessage(config.OWNER_ID, 
                `❌ *BACKUP GAGAL*\n\nError: ${error.message}\n\nWaktu: ${new Date().toLocaleString('id-ID')}`,
                { parse_mode: "Markdown" }
            );
        } catch (notificationError) {
            console.error('❌ Gagal mengirim notifikasi error backup:', notificationError);
        }
    }
}

// ==================== OWNER FUNCTIONS ====================
function isOwner(userId) {
    return config.OWNER_IDS.includes(userId.toString());
}

function addUserSaldo(userId, amount) {
    try {
        const data = JSON.parse(fs.readFileSync(saldoPath));
        if (!data[userId]) {
            data[userId] = 0;
        }
        data[userId] += amount;
        fs.writeFileSync(saldoPath, JSON.stringify(data, null, 2));
        return data[userId];
    } catch (e) {
        console.error("❌ Gagal tambah saldo:", e.message);
        return null;
    }
}

function getAllUsers() {
    try {
        const saldoData = JSON.parse(fs.readFileSync(saldoPath));
        return Object.keys(saldoData).map(userId => ({ 
            userId: parseInt(userId) 
        }));
    } catch (e) {
        return [];
    }
}

function getAllPurchases() {
    try {
        const purchases = JSON.parse(fs.readFileSync(panelPurchasesPath));
        const grouped = {};
        purchases.forEach(purchase => {
            if (!grouped[purchase.userId]) {
                grouped[purchase.userId] = [];
            }
            grouped[purchase.userId].push(purchase);
        });
        return grouped;
    } catch (e) {
        return {};
    }
}

function savePanelPurchase(purchaseData) {
    try {
        const purchases = JSON.parse(fs.readFileSync(panelPurchasesPath));
        purchases.push(purchaseData);
        fs.writeFileSync(panelPurchasesPath, JSON.stringify(purchases, null, 2));
    } catch (e) {
        console.error("❌ Gagal simpan purchase:", e.message);
    }
}

function getUserPurchases(userId) {
    try {
        const purchases = JSON.parse(fs.readFileSync(panelPurchasesPath));
        return purchases.filter(p => p.userId === userId);
    } catch (e) {
        return [];
    }
}

// ==================== APPS & DOCUMENTS FUNCTIONS ====================
function getAllApps() {
    try {
        return JSON.parse(fs.readFileSync(appsPath));
    } catch (e) {
        return [];
    }
}

function saveApp(appData) {
    try {
        const apps = getAllApps();
        apps.push(appData);
        fs.writeFileSync(appsPath, JSON.stringify(apps, null, 2));
        return true;
    } catch (e) {
        console.error("❌ Gagal simpan app:", e.message);
        return false;
    }
}

function deleteApp(appId) {
    try {
        const apps = getAllApps();
        const filteredApps = apps.filter(app => app.id !== appId);
        fs.writeFileSync(appsPath, JSON.stringify(filteredApps, null, 2));
        return true;
    } catch (e) {
        console.error("❌ Gagal hapus app:", e.message);
        return false;
    }
}

function getAllDocuments() {
    try {
        return JSON.parse(fs.readFileSync(documentsPath));
    } catch (e) {
        return [];
    }
}

function saveDocument(docData) {
    try {
        const documents = getAllDocuments();
        documents.push(docData);
        fs.writeFileSync(documentsPath, JSON.stringify(documents, null, 2));
        return true;
    } catch (e) {
        console.error("❌ Gagal simpan document:", e.message);
        return false;
    }
}

function deleteDocument(docId) {
    try {
        const documents = getAllDocuments();
        const filteredDocs = documents.filter(doc => doc.id !== docId);
        fs.writeFileSync(documentsPath, JSON.stringify(filteredDocs, null, 2));
        return true;
    } catch (e) {
        console.error("❌ Gagal hapus document:", e.message);
        return false;
    }
}

function getResellerPrice(ramSize) {
    const prices = {
        '5gb': 5000,
        '6gb': 6000,
        '7gb': 7000,
        '8gb': 8000,
        '9gb': 9000,
        '10gb': 10000,
        'unli': 12000
    };
    return prices[ramSize] || prices['5gb'];
}

// ==================== CONFIG MANAGEMENT FUNCTIONS ====================
async function showConfigMenu(chatId, messageId = null) {
    if (!isOwner(chatId)) {
        return bot.sendMessage(chatId, "❌ Hanya owner yang bisa mengakses menu ini!");
    }

    const menuText = `
\`\`\`Javascript ⚙️ *MANAJEMEN KONFIGURASI*
━━━━━━━━━━━━━━━━━━━━━━━━━━
*Ubah pengaturan bot tanpa restart*

📋 *Pilihan Konfigurasi:*
• 🤖 Token Bot
• 🌐 Domain Panel  
• 🔑 PLTA Pterodactyl
• 🔑 PLTC Pterodactyl
• 📱 Nomor Pencairan Dana
• 👤 Nama E-wallet Dana
• 💳 API H2H Atlantic
• 🏷️ Nama Bot
• 👑 Owner IDs
• 📢 Channel ID & URL

💡 *Perubahan akan langsung aktif!*
    \`\`\``.trim();

    const keyboard = [
        [
            { text: "🤖 TOKEN BOT", callback_data: "config_bot_token" },
            { text: "🌐 DOMAIN PANEL", callback_data: "config_domain" }
        ],
        [
            { text: "🔑 PLTA PTERO", callback_data: "config_plta" },
            { text: "🔑 PLTC PTERO", callback_data: "config_pltc" }
        ],
        [
            { text: "📱 NOMOR DANA", callback_data: "config_nomor_dana" },
            { text: "👤 NAMA EWALLET", callback_data: "config_nama_ewallet" }
        ],
        [
            { text: "💳 API ATLANTIC", callback_data: "config_api_atlantic" },
            { text: "🏷️ NAMA BOT", callback_data: "config_bot_name" }
        ],
        [
            { text: "👑 OWNER IDS", callback_data: "config_owner_ids" },
            { text: "📢 CHANNEL INFO", callback_data: "config_channel" }
        ],
        [
            { text: "🔄 RELOAD CONFIG", callback_data: "config_reload" },
            { text: "🔙 KEMBALI", callback_data: "owner_menu" }
        ]
    ];

    const menuOptions = {
        reply_markup: { inline_keyboard: keyboard },
        parse_mode: "Markdown"
    };

    if (messageId) {
        bot.editMessageText(menuText, {
            chat_id: chatId,
            message_id: messageId,
            ...menuOptions
        });
    } else {
        bot.sendMessage(chatId, menuText, menuOptions);
    }
}

async function handleConfigChange(chatId, configType, messageId) {
    if (!isOwner(chatId)) {
        return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Akses ditolak!" });
    }

    const prompts = {
        'config_bot_token': "🤖 Masukkan token bot baru:",
        'config_domain': "🌐 Masukkan domain panel baru:\n\nContoh: https://panel.domain.com",
        'config_plta': "🔑 Masukkan PLTA (API Key) baru:",
        'config_pltc': "🔑 Masukkan PLTC (Client Key) baru:",
        'config_nomor_dana': "📱 Masukkan nomor pencairan Dana baru:",
        'config_nama_ewallet': "👤 Masukkan nama pemilik e-wallet baru:",
        'config_api_atlantic': "💳 Masukkan API Key Atlantic baru:",
        'config_bot_name': "🏷️ Masukkan nama bot baru:",
        'config_owner_ids': "👑 Masukkan Owner IDs baru (pisahkan dengan koma):\n\nContoh: 123456789,987654321",
        'config_channel': "📢 Masukkan Channel ID dan URL (format: ID|URL):\n\nContoh: -100123456789|https://t.me/channelname"
    };

    adminChatSessions[chatId] = {
        action: 'waiting_config_value',
        configType: configType
    };

    await bot.editMessageText(prompts[configType], {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "Markdown"
    });
}

async function updateConfigValue(chatId, value) {
    try {
        const session = adminChatSessions[chatId];
        if (!session || session.action !== 'waiting_config_value') {
            return false;
        }

        const configType = session.configType;
        delete adminChatSessions[chatId];

        // Load current config
        const configPath = './config.js';
        let configContent = fs.readFileSync(configPath, 'utf8');

        // Update config based on type
        switch (configType) {
            case 'config_bot_token':
                configContent = configContent.replace(
                    /BOT_TOKEN:\s*"[^"]*"/,
                    `BOT_TOKEN: "${value}"`
                );
                break;

            case 'config_domain':
                configContent = configContent.replace(
                    /domain:\s*"[^"]*"/,
                    `domain: "${value}"`
                );
                break;

            case 'config_plta':
                configContent = configContent.replace(
                    /apiKey:\s*"[^"]*"/,
                    `apiKey: "${value}"`
                );
                break;

            case 'config_pltc':
                configContent = configContent.replace(
                    /clientKey:\s*"[^"]*"/,
                    `clientKey: "${value}"`
                );
                break;

            case 'config_nomor_dana':
                configContent = configContent.replace(
                    /nomor_pencairan:\s*"[^"]*"/,
                    `nomor_pencairan: "${value}"`
                );
                break;

            case 'config_nama_ewallet':
                configContent = configContent.replace(
                    /atas_nama_ewallet:\s*"[^"]*"/,
                    `atas_nama_ewallet: "${value}"`
                );
                break;

            case 'config_api_atlantic':
                configContent = configContent.replace(
                    /apiAtlantic:\s*"[^"]*"/,
                    `apiAtlantic: "${value}"`
                );
                break;

            case 'config_bot_name':
                configContent = configContent.replace(
                    /BOT_NAME:\s*"[^"]*"/,
                    `BOT_NAME: "${value}"`
                );
                break;

            case 'config_owner_ids':
                const ownerIds = value.split(',').map(id => id.trim());
                const ownerId = ownerIds[0]; // Use first ID as main owner
                
                configContent = configContent.replace(
                    /OWNER_IDS:\s*\[[^\]]*\]/,
                    `OWNER_IDS: [${ownerIds.map(id => `"${id}"`).join(', ')}]`
                );
                configContent = configContent.replace(
                    /OWNER_ID:\s*"[^"]*"/,
                    `OWNER_ID: "${ownerId}"`
                );
                break;

            case 'config_channel':
                const [channelId, channelUrl] = value.split('|');
                configContent = configContent.replace(
                    /CHANNEL_ID:\s*"[^"]*"/,
                    `CHANNEL_ID: "${channelId.trim()}"`
                );
                configContent = configContent.replace(
                    /CHANNEL_URL:\s*"[^"]*"/,
                    `CHANNEL_URL: "${channelUrl.trim()}"`
                );
                break;
        }

        // Save updated config
        fs.writeFileSync(configPath, configContent);

        // Reload config
        delete require.cache[require.resolve('./config.js')];
        const newConfig = require('./config.js');
        
        // Update global config object
        Object.keys(newConfig).forEach(key => {
            config[key] = newConfig[key];
        });

        await bot.sendMessage(chatId, 
            `\`\`\`Javascript ✅ *KONFIGURASI BERHASIL DIUBAH!*\n\n` +
            `⚙️ *Tipe:* ${configType.replace('config_', '').toUpperCase()}\n` +
            `🔄 *Config telah direload*\n\n` +
            `💡 Perubahan sudah aktif tanpa restart!\`\`\``,
            { parse_mode: "Markdown" }
        );

        return true;

    } catch (error) {
        console.error('❌ Config update error:', error);
        await bot.sendMessage(chatId, 
            `❌ Gagal mengubah konfigurasi: ${error.message}`
        );
        return false;
    }
}

async function reloadConfig(chatId, messageId = null) {
    if (!isOwner(chatId)) {
        return bot.sendMessage(chatId, "❌ Hanya owner yang bisa mengakses perintah ini!");
    }

    try {
        // Clear require cache and reload config
        delete require.cache[require.resolve('./config.js')];
        const newConfig = require('./config.js');
        
        // Update global config object
        Object.keys(newConfig).forEach(key => {
            config[key] = newConfig[key];
        });

        const successMsg = `\`\`\`Javascript 🔄 *CONFIG RELOADED!*\n\n` +
            `✅ Konfigurasi berhasil direload\n` +
            `📊 Config yang aktif:\n` +
            `• 🤖 Bot: ${config.BOT_NAME}\n` +
            `• 👑 Owner: ${config.OWNER_ID}\n` +
            `• 🌐 Domain: ${config.PTERODACTYL.domain}\n` +
            `• 💳 API: ${config.PAYMENT.apiAtlantic ? '✅' : '❌'}\n\n` +
            `🚀 Bot berjalan dengan config terbaru!\`\`\``;

        if (messageId) {
            await bot.editMessageText(successMsg, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: "Markdown"
            });
        } else {
            await bot.sendMessage(chatId, successMsg, { parse_mode: "Markdown" });
        }

    } catch (error) {
        console.error('❌ Config reload error:', error);
        const errorMsg = `❌ Gagal reload config: ${error.message}`;
        
        if (messageId) {
            await bot.editMessageText(errorMsg, {
                chat_id: chatId,
                message_id: messageId
            });
        } else {
            await bot.sendMessage(chatId, errorMsg);
        }
    }
}

// ==================== FUNGSI DELETE APP & DOCUMENT DENGAN CONFIRMATION ====================
async function showDeleteAppMenu(chatId, messageId = null) {
    const apps = getAllApps();
    
    let menuText = `\`\`\`Javascript  
🗑️ *HAPUS APPS*
━━━━━━━━━━━━━━━━━━━━━━━━━━
*Pilih apps yang ingin dihapus:*

`;
    
    if (apps.length === 0) {
        menuText += `❌ *Tidak ada apps yang tersedia*\`\`\``;
    } else {
        apps.forEach((app, index) => {
            menuText += `${index + 1}. ${app.name}\n`;
            menuText += `   └ ID: ${app.id}\n`;
            menuText += `   └ Harga: Rp ${toRupiah(app.price)}\n\n`;
        });
        menuText += `💡 *Klik ID apps untuk menghapus*\`\`\``;
    }

    const keyboard = [];
    
    if (apps.length > 0) {
        apps.forEach((app, index) => {
            if (index % 2 === 0) {
                const row = [];
                row.push({ 
                    text: `${app.name}`, 
                    callback_data: `confirm_delete_app_${app.id}` 
                });
                
                if (apps[index + 1]) {
                    row.push({ 
                        text: `${apps[index + 1].name}`, 
                        callback_data: `confirm_delete_app_${apps[index + 1].id}` 
                    });
                }
                
                keyboard.push(row);
            }
        });
    }
    
    keyboard.push([
        { text: "🔄 REFRESH", callback_data: "owner_delete_app" },
        { text: "🔙 KEMBALI", callback_data: "owner_manage_apps" }
    ]);

    const menuOptions = {
        reply_markup: { inline_keyboard: keyboard },
        parse_mode: "Markdown"
    };

    if (messageId) {
        bot.editMessageText(menuText, {
            chat_id: chatId,
            message_id: messageId,
            ...menuOptions
        });
    } else {
        bot.sendMessage(chatId, menuText, menuOptions);
    }
}

async function showDeleteDocumentMenu(chatId, messageId = null) {
    const documents = getAllDocuments();
    
    let menuText = `\`\`\`Javascript  
🗑️ *HAPUS DOCUMENTS*
━━━━━━━━━━━━━━━━━━━━━━━━━━
*Pilih document yang ingin dihapus:*

`;
    
    if (documents.length === 0) {
        menuText += `❌ *Tidak ada documents yang tersedia*\`\`\``;
    } else {
        documents.forEach((doc, index) => {
            menuText += `${index + 1}. ${doc.name}\n`;
            menuText += `   └ ID: ${doc.id}\n`;
            menuText += `   └ Harga: Rp ${toRupiah(doc.price)}\n\n`;
        });
        menuText += `💡 *Klik ID document untuk menghapus*\`\`\``;
    }

    const keyboard = [];
    
    if (documents.length > 0) {
        documents.forEach((doc, index) => {
            if (index % 2 === 0) {
                const row = [];
                row.push({ 
                    text: `${doc.name}`, 
                    callback_data: `confirm_delete_doc_${doc.id}` 
                });
                
                if (documents[index + 1]) {
                    row.push({ 
                        text: `${documents[index + 1].name}`, 
                        callback_data: `confirm_delete_doc_${documents[index + 1].id}` 
                    });
                }
                
                keyboard.push(row);
            }
        });
    }
    
    keyboard.push([
        { text: "🔄 REFRESH", callback_data: "owner_delete_document" },
        { text: "🔙 KEMBALI", callback_data: "owner_manage_documents" }
    ]);

    const menuOptions = {
        reply_markup: { inline_keyboard: keyboard },
        parse_mode: "Markdown"
    };

    if (messageId) {
        bot.editMessageText(menuText, {
            chat_id: chatId,
            message_id: messageId,
            ...menuOptions
        });
    } else {
        bot.sendMessage(chatId, menuText, menuOptions);
    }
}

async function confirmDeleteApp(chatId, appId, messageId) {
    const apps = getAllApps();
    const app = apps.find(a => a.id === appId);
    
    if (!app) {
        return bot.editMessageText("❌ Apps tidak ditemukan!", {
            chat_id: chatId,
            message_id: messageId
        });
    }

    const menuText = `\`\`\`Javascript  
⚠️ *KONFIRMASI HAPUS APPS*
━━━━━━━━━━━━━━━━━━━━━━━━━━
*Detail Apps:*
• Nama: ${app.name}
• ID: ${app.id}
• Harga: Rp ${toRupiah(app.price)}
• Deskripsi: ${app.description}

❌ *Apakah Anda yakin ingin menghapus apps ini?*
Tindakan ini tidak dapat dibatalkan!\`\`\``;

    const keyboard = [
        [
            { text: "✅ YA, HAPUS", callback_data: `execute_delete_app_${appId}` },
            { text: "❌ BATAL", callback_data: "owner_delete_app" }
        ]
    ];

    await bot.editMessageText(menuText, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "Markdown",
        reply_markup: { inline_keyboard: keyboard }
    });
}

async function confirmDeleteDocument(chatId, docId, messageId) {
    const documents = getAllDocuments();
    const doc = documents.find(d => d.id === docId);
    
    if (!doc) {
        return bot.editMessageText("❌ Document tidak ditemukan!", {
            chat_id: chatId,
            message_id: messageId
        });
    }

    const menuText = `\`\`\`Javascript  
⚠️ *KONFIRMASI HAPUS DOCUMENT*
━━━━━━━━━━━━━━━━━━━━━━━━━━
*Detail Document:*
• Nama: ${doc.name}
• ID: ${doc.id}
• Harga: Rp ${toRupiah(doc.price)}
• Deskripsi: ${doc.description}

❌ *Apakah Anda yakin ingin menghapus document ini?*
Tindakan ini tidak dapat dibatalkan!\`\`\``;

    const keyboard = [
        [
            { text: "✅ YA, HAPUS", callback_data: `execute_delete_doc_${docId}` },
            { text: "❌ BATAL", callback_data: "owner_delete_document" }
        ]
    ];

    await bot.editMessageText(menuText, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "Markdown",
        reply_markup: { inline_keyboard: keyboard }
    });
}

async function executeDeleteApp(chatId, appId, messageId) {
    const apps = getAllApps();
    const app = apps.find(a => a.id === appId);
    
    if (!app) {
        return bot.editMessageText("❌ Apps tidak ditemukan!", {
            chat_id: chatId,
            message_id: messageId
        });
    }

    const success = deleteApp(appId);
    
    if (success) {
        await bot.editMessageText(`\`\`\`Javascript  ✅ *APPS BERHASIL DIHAPUS!*\n\n` +
            `📱 *Nama:* ${app.name}\n` +
            `💰 *Harga:* Rp ${toRupiah(app.price)}\n` +
            `🆔 *ID:* ${app.id}\n\n` +
            `🗑️ *Apps telah dihapus permanen*\`\`\``, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: "Markdown",
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: "📱 KELOLA APPS", callback_data: "owner_manage_apps" },
                        { text: "🗑️ HAPUS LAGI", callback_data: "owner_delete_app" }
                    ]
                ]
            }
        });
    } else {
        await bot.editMessageText("❌ Gagal menghapus apps. Silakan coba lagi.", {
            chat_id: chatId,
            message_id: messageId
        });
    }
}

async function executeDeleteDocument(chatId, docId, messageId) {
    const documents = getAllDocuments();
    const doc = documents.find(d => d.id === docId);
    
    if (!doc) {
        return bot.editMessageText("❌ Document tidak ditemukan!", {
            chat_id: chatId,
            message_id: messageId
        });
    }

    const success = deleteDocument(docId);
    
    if (success) {
        await bot.editMessageText(`\`\`\`Javascript  ✅ *DOCUMENT BERHASIL DIHAPUS!*\n\n` +
            `💻 *Nama:* ${doc.name}\n` +
            `💰 *Harga:* Rp ${toRupiah(doc.price)}\n` +
            `🆔 *ID:* ${doc.id}\n\n` +
            `🗑️ *Document telah dihapus permanen*\`\`\``, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: "Markdown",
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: "💻 KELOLA DOCUMENTS", callback_data: "owner_manage_documents" },
                        { text: "🗑️ HAPUS LAGI", callback_data: "owner_delete_document" }
                    ]
                ]
            }
        });
    } else {
        await bot.editMessageText("❌ Gagal menghapus document. Silakan coba lagi.", {
            chat_id: chatId,
            message_id: messageId
        });
    }
}

// ==================== WARRANTY FUNCTIONS ====================
function getAllWarrantyClaims() {
    try {
        return JSON.parse(fs.readFileSync(warrantyClaimsPath));
    } catch (e) {
        return [];
    }
}

function updateWarrantyClaim(claimId, updates) {
    try {
        const claims = getAllWarrantyClaims();
        const claimIndex = claims.findIndex(claim => claim.id === claimId);
        if (claimIndex !== -1) {
            claims[claimIndex] = { ...claims[claimIndex], ...updates };
            fs.writeFileSync(warrantyClaimsPath, JSON.stringify(claims, null, 2));
            return true;
        }
        return false;
    } catch (e) {
        console.error("❌ Gagal update warranty claim:", e.message);
        return false;
    }
}

// ==================== SPECIAL PANEL FUNCTIONS ====================
function saveSpecialPanel(purchaseData) {
    try {
        const specialPanels = JSON.parse(fs.readFileSync(specialPanelsPath));
        specialPanels.push(purchaseData);
        fs.writeFileSync(specialPanelsPath, JSON.stringify(specialPanels, null, 2));
    } catch (e) {
        console.error("❌ Gagal simpan special panel:", e.message);
    }
}

function getUserSpecialPanels(userId) {
    try {
        const specialPanels = JSON.parse(fs.readFileSync(specialPanelsPath));
        return specialPanels.filter(p => p.userId === userId);
    } catch (e) {
        return [];
    }
}

// ==================== USER START TRACKING ====================
function hasUserStarted(userId) {
    try {
        const userStarts = JSON.parse(fs.readFileSync(userStartPath));
        return userStarts.includes(userId.toString());
    } catch (e) {
        return false;
    }
}

function markUserStarted(userId) {
    try {
        const userStarts = JSON.parse(fs.readFileSync(userStartPath));
        if (!userStarts.includes(userId.toString())) {
            userStarts.push(userId.toString());
            fs.writeFileSync(userStartPath, JSON.stringify(userStarts, null, 2));
        }
    } catch (e) {
        console.error("❌ Gagal simpan user start:", e.message);
    }
}

// ==================== NOTIFICATION SYSTEM ====================
async function sendNewUserNotification(userId, username) {
    if (notifiedUsers.has(userId)) return;
    
    notifiedUsers.add(userId);
    
    const notificationText = `\`\`\`Javascript 👤 *USER BARU MULAI BOT!*\n\n` +
        `🆔 *User ID:* ${userId}\n` +
        `👤 *Username:* @${username || 'Tidak ada'}\n` +
        `⏰ *Waktu:* ${new Date().toLocaleString('id-ID')}\n\n` +
        `🚀 *Selamat datang di ${config.BOT_NAME}!*\`\`\``;
    
    try {
        await bot.sendMessage(config.OWNER_ID, notificationText, { parse_mode: "Markdown" });
        if (config.CHANNEL_ID) {
            await bot.sendMessage(config.CHANNEL_ID, notificationText, { parse_mode: "Markdown" });
        }
    } catch (error) {
        console.error("❌ Gagal kirim notifikasi user baru:", error);
    }
}

async function sendDepositNotification(userId, amount, username) {
    const notificationText = `\`\`\`Javascript 💰 *DEPOSIT BERHASIL!*\n\n` +
        `👤 *User:* @${username || userId}\n` +
        `💵 *Jumlah:* Rp ${toRupiah(amount)}\n` +
        `⏰ *Waktu:* ${new Date().toLocaleString('id-ID')}\n\n` +
        `🎉 *Saldo berhasil ditambahkan!*\`\`\``;
    
    try {
        await bot.sendMessage(config.OWNER_ID, notificationText, { parse_mode: "Markdown" });
        if (config.CHANNEL_ID) {
            await bot.sendMessage(config.CHANNEL_ID, notificationText, { parse_mode: "Markdown" });
        }
    } catch (error) {
        console.error("❌ Gagal kirim notifikasi deposit:", error);
    }
}

async function sendPanelNotification(userId, panelType, username, harga) {
    const notificationText = `\`\`\`Javascript 🛒 *PANEL BARU DIBUAT!*\n\n` +
        `👤 *User:* @${username || userId}\n` +
        `📦 *Tipe:* ${panelType}\n` +
        `💵 *Harga:* Rp ${toRupiah(harga)}\n` +
        `⏰ *Waktu:* ${new Date().toLocaleString('id-ID')}\n\n` +
        `🚀 *Panel berhasil dibuat!*\`\`\``;
    
    try {
        await bot.sendMessage(config.OWNER_ID, notificationText, { parse_mode: "Markdown" });
        if (config.CHANNEL_ID) {
            await bot.sendMessage(config.CHANNEL_ID, notificationText, { parse_mode: "Markdown" });
        }
    } catch (error) {
        console.error("❌ Gagal kirim notifikasi panel:", error);
    }
}

async function sendResellerNotification(userId, packageType, username) {
    const notificationText = `\`\`\`Javascript 💼 *RESELLER BARU!*\n\n` +
        `👤 *User:* @${username || userId}\n` +
        `📦 *Paket:* ${packageType.toUpperCase()}\n` +
        `⏰ *Waktu:* ${new Date().toLocaleString('id-ID')}\n\n` +
        `🎉 *Selamat bergabung di program reseller!*\`\`\``;
    
    try {
        await bot.sendMessage(config.OWNER_ID, notificationText, { parse_mode: "Markdown" });
        if (config.CHANNEL_ID) {
            await bot.sendMessage(config.CHANNEL_ID, notificationText, { parse_mode: "Markdown" });
        }
    } catch (error) {
        console.error("❌ Gagal kirim notifikasi reseller:", error);
    }
}

// ==================== LOADING ANIMATION ====================
async function showLoadingAnimation(chatId, userId) {
    const loadingMsg = await bot.sendMessage(chatId, loadingFrames[0], { 
        parse_mode: "Markdown" 
    });
    
    loadingMessages[userId] = loadingMsg.message_id;
    
    for (let i = 1; i < loadingFrames.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 500));
        
        try {
            await bot.editMessageText(loadingFrames[i], {
                chat_id: chatId,
                message_id: loadingMsg.message_id,
                parse_mode: "Markdown"
            });
        } catch (error) {
            // Ignore edit errors
            break;
        }
    }
    
    // Clean up
    delete loadingMessages[userId];
}

// ==================== PAYMENT SYSTEM ====================
async function generateCustomQRFromString(qrText) {
    const canvas = createCanvas(500, 600);
    const ctx = canvas.getContext('2d');
    
    const gradient = ctx.createLinearGradient(0, 0, 500, 600);
    gradient.addColorStop(0, '#667eea');
    gradient.addColorStop(1, '#764ba2');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 500, 600);
    
    ctx.fillStyle = 'white';
    ctx.fillRect(50, 50, 400, 400);
    
    const qrCanvas = createCanvas(350, 350);
    await QRCode.toCanvas(qrCanvas, qrText, {
        errorCorrectionLevel: 'H',
        margin: 1,
        width: 350
    });
    
    ctx.drawImage(qrCanvas, 75, 75, 350, 350);
    
    ctx.fillStyle = 'white';
    ctx.font = 'bold 20px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('SCAN QR UNTUK BAYAR', 250, 480);
    ctx.font = '16px Arial';
    ctx.fillText('Valid 5 menit', 250, 510);
    
    return canvas.toBuffer();
}

// ==================== DEPOSIT SYSTEM (QRIS FAST) ====================
async function processDeposit(chatId, userId, jumlah) {
    const adminFee = 300;
    const total = jumlah + adminFee;
    const ref = `DEPO-${Math.floor(1000000 + Math.random() * 9000000)}`;

    try {
        const processingMsg = await bot.sendMessage(chatId, "⏳ *Memproses pembayaran...*", { parse_mode: "Markdown" });

        const depositData = qs.stringify({
            api_key: config.PAYMENT.apiAtlantic,
            reff_id: ref,
            nominal: total,
            type: 'ewallet',
            metode: 'qrisfast'
        });

        const res = await axios.post('https://atlantich2h.com/deposit/create', depositData, {
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            timeout: 30000
        });

        const data = res.data;
        if (!data.status) {
            await bot.deleteMessage(chatId, processingMsg.message_id);
            return bot.sendMessage(chatId, `❌ Gagal buat QRIS: ${data.message}`);
        }

        const trx = data.data;
        
        await bot.editMessageText("🎨 *Membuat QR Code...*", {
            chat_id: chatId,
            message_id: processingMsg.message_id,
            parse_mode: "Markdown"
        });

        const qrImage = await generateCustomQRFromString(trx.qr_string);

        const caption = `
\`\`\`Javascript 💰 *DETAIL DEPOSIT SALDO*

💵 *Nominal Deposit:* Rp ${toRupiah(jumlah)}
📦 *Biaya Admin:* Rp ${toRupiah(adminFee)}
💠 *Total Bayar: Rp ${toRupiah(total)}*
📊 *Status:* ${trx.status.toUpperCase()}
🆔 *Ref ID:* ${ref}

📲 *Scan QR Code di bawah ini:*
⏰ *Berlaku 15 menit*

❌ *Batalkan:* Klik button BATALKAN DEPOSIT
        \`\`\``.trim();

        await bot.deleteMessage(chatId, processingMsg.message_id);
        
        const sentMsg = await bot.sendPhoto(
            chatId,
            qrImage,
            {
                caption: caption,
                parse_mode: "Markdown",
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "❌ BATALKAN DEPOSIT", callback_data: "bataldeposit" }]
                    ]
                }
            }
        );

        activeDeposit[userId] = {
            msgId: sentMsg.message_id,
            chatId: chatId,
            id: trx.id,
            amount: jumlah,
            adminFee: adminFee,
            totalAmount: total,
            ref: ref,
            status: true,
            timeout: setTimeout(async () => {
                if (activeDeposit[userId]?.status) {
                    try {
                        await bot.deleteMessage(chatId, sentMsg.message_id);
                        await bot.sendMessage(chatId, "⏰ Waktu deposit habis! Silakan buat ulang.");
                    } catch (e) {}
                    delete activeDeposit[userId];
                }
            }, 900000)
        };

        checkDepositStatusNew(userId, trx.id, sentMsg.message_id, jumlah, adminFee, total, ref);

    } catch (err) {
        console.error("❌ Deposit error:", err);
        try {
            await bot.deleteMessage(chatId, processingMsg.message_id);
        } catch (e) {}
        bot.sendMessage(chatId, "❌ Gagal memproses deposit. Silakan coba lagi.");
    }
}

// ==================== NEW DEPOSIT STATUS CHECK ====================
async function checkDepositStatusNew(userId, trxId, msgId, nominal, adminFee, totalAmount, ref) {
    const maxAttempts = 300;
    let attempts = 0;
    
    const transaksi = activeDeposit[userId];
    if (!transaksi) return;

    while (attempts < maxAttempts && transaksi.status) {
        await new Promise(r => setTimeout(r, 3000));
        attempts++;
        
        if (!activeDeposit[userId]) {
            console.log(`🔍 Deposit ${userId} sudah tidak aktif, stop monitoring`);
            return;
        }
        
        try {
            const check = await axios.post('https://atlantich2h.com/deposit/status', 
                qs.stringify({
                    api_key: config.PAYMENT.apiAtlantic,
                    id: trxId
                }), { 
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    timeout: 10000
                }
            );

            const checkData = check.data;
            console.log(`🔍 Deposit API Response:`, JSON.stringify(checkData));

            let status = '';
            
            if (checkData.data?.status) {
                status = checkData.data.status.toLowerCase();
            } else if (checkData.get?.data?.status) {
                status = checkData.get.data.status.toLowerCase();
            } else if (checkData.status) {
                status = checkData.status.toLowerCase();
            } else if (checkData.message?.status) {
                status = checkData.message.status.toLowerCase();
            }
            
            console.log(`🔍 Deposit status check: ${status || 'undefined'} (Attempt ${attempts})`);

            if (status && ['cancel', 'expired', 'failed', 'error'].includes(status)) {
                transaksi.status = false;
                clearTimeout(transaksi.timeout);
                
                try {
                    await bot.deleteMessage(transaksi.chatId, msgId);
                    await bot.sendMessage(transaksi.chatId, `❌ Deposit ${status}`);
                } catch (e) {}
                
                delete activeDeposit[userId];
                return;
            }

            if (status && ['success', 'paid', 'completed', 'processing', 'settlement', 'success settlement'].includes(status)) {
                if (status === 'processing') {
                    try {
                        await axios.post('https://atlantich2h.com/deposit/instant', 
                            qs.stringify({
                                api_key: config.PAYMENT.apiAtlantic,
                                id: trxId,
                                action: 'true'
                            }), {
                                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
                            }
                        );
                    } catch (e) {
                        console.log("⚠️ Instant confirmation failed, continue...");
                    }
                }

                transaksi.status = false;
                clearTimeout(transaksi.timeout);

                try {
                    await bot.deleteMessage(transaksi.chatId, msgId);
                    
                    const currentSaldo = getUserSaldo(userId);
                    const newSaldo = currentSaldo + nominal;
                    setUserSaldo(userId, newSaldo);

                    const successMsg = `\`\`\`Javascript
✅ *DEPOSIT BERHASIL!*

💵 *Nominal:* Rp ${toRupiah(nominal)}
📦 *Biaya Admin:* Rp ${toRupiah(adminFee)}
💰 *Total:* Rp ${toRupiah(totalAmount)}
🆔 *Ref:* ${ref}
💎 *Saldo Baru:* Rp ${toRupiah(newSaldo)}
🕒 *Waktu:* ${new Date().toLocaleString('id-ID')}

🎉 *Saldo berhasil ditambahkan!*
                    \`\`\``.trim();

                    await bot.sendMessage(transaksi.chatId, successMsg, {
                        parse_mode: "Markdown",
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: "🛒 BELI PANEL SEKARANG", callback_data: "buy_panel" }]
                            ]
                        }
                    });

                    // Kirim notifikasi ke owner dan channel
                    const userInfo = await bot.getChat(userId);
                    const username = userInfo.username ? `@${userInfo.username}` : `User ID: ${userId}`;
                    
                    await sendDepositNotification(userId, nominal, userInfo.username);

                } catch (msgError) {
                    console.error("❌ Error sending success message:", msgError);
                }

                delete activeDeposit[userId];
                return;
            }
                
        } catch (err) {
            console.error(`❌ Deposit status check error (attempt ${attempts}):`, err.message);
            continue;
        }
    }

    if (transaksi.status) {
        transaksi.status = false;
        clearTimeout(transaksi.timeout);
        
        try {
            const finalCheck = await axios.post('https://atlantich2h.com/deposit/status', 
                qs.stringify({
                    api_key: config.PAYMENT.apiAtlantic,
                    id: trxId
                }), { 
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
                }
            );

            console.log(`🔍 Final check response:`, JSON.stringify(finalCheck.data));

            const finalData = finalCheck.data;
            let finalStatus = '';
            
            if (finalData.data?.status) {
                finalStatus = finalData.data.status.toLowerCase();
            } else if (finalData.get?.data?.status) {
                finalStatus = finalData.get.data.status.toLowerCase();
            } else if (finalData.status) {
                finalStatus = finalData.status.toLowerCase();
            }

            if (finalStatus && ['success', 'paid', 'completed', 'processing', 'settlement'].includes(finalStatus)) {
                const currentSaldo = getUserSaldo(userId);
                const newSaldo = currentSaldo + nominal;
                setUserSaldo(userId, newSaldo);

                await bot.deleteMessage(transaksi.chatId, msgId);
                await bot.sendMessage(transaksi.chatId, 
                    `✅ *DEPOSIT BERHASIL!*\n\n` +
                    `💵 Rp ${toRupiah(nominal)} telah ditambahkan\n` +
                    `💎 Saldo Baru: Rp ${toRupiah(newSaldo)}`,
                    { parse_mode: "Markdown" }
                );
                
                const userInfo = await bot.getChat(userId);
                await sendDepositNotification(userId, nominal, userInfo.username);
            } else {
                await bot.deleteMessage(transaksi.chatId, msgId);
                await bot.sendMessage(transaksi.chatId, "⏰ Waktu deposit habis");
            }
        } catch (finalError) {
            console.error("❌ Final check error:", finalError.message);
            await bot.deleteMessage(transaksi.chatId, msgId);
            await bot.sendMessage(transaksi.chatId, "⏰ Waktu deposit habis");
        }
        
        delete activeDeposit[userId];
    }
}

// ==================== FIXED DIRECT QRIS PAYMENT ====================
async function processDirectQRIS(chatId, userId, productType, productData, harga) {
    const total = harga + config.PAYMENT.FeeTransaksi;
    const randomChars = crypto.randomBytes(4).toString('hex').toUpperCase();
    const reff = `${productType.toUpperCase()}-${randomChars}`;

    try {
        const depositData = qs.stringify({
            api_key: config.PAYMENT.apiAtlantic,
            reff_id: reff,
            nominal: total,
            type: 'ewallet',
            metode: 'qrisfast'
        });

        const res = await axios.post('https://atlantich2h.com/deposit/create', depositData, {
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        });

        const data = res.data;
        if (!data.status) {
            return bot.sendMessage(chatId, `❌ Gagal buat QRIS: ${data.message}`);
        }

        const info = data.data;
        const qrImage = await generateCustomQRFromString(info.qr_string);

        let teks = '';
        if (productType === 'panel') {
            teks = `\`\`\`Javascript
🛒 PEMBAYARAN PANEL VIA QRIS
━━━━━━━━━━━━━━━━━━━━━━━━━━
📦 Detail Pesanan:
• 💾 RAM: ${productData.ramSize.toUpperCase()}
• 💰 Harga Panel: Rp ${toRupiah(harga)}

💳 Detail Pembayaran:
🔐 Kode Transaksi: ${reff}
🧾 Biaya Admin: Rp ${toRupiah(config.PAYMENT.FeeTransaksi)}
💳 Total Bayar: Rp ${toRupiah(total)}
⏰ Batas Waktu: 5 Menit

📱 Cara Bayar:
1. Buka aplikasi e-wallet/m-banking
2. Pilih menu QRIS / Scan QR
3. Scan kode QR di atas
4. Konfirmasi pembayaran

✅ Panel akan otomatis dibuat setelah pembayaran berhasil!
            \`\`\``.trim();
        } else if (productType === 'reseller') {
            teks = `\`\`\`Javascript
💼 PEMBAYARAN RESELLER VIA QRIS
━━━━━━━━━━━━━━━━━━━━━━━━━━
📦 Detail Paket:
• 📊 Paket: ${productData.packageType.toUpperCase()}
• 💰 Harga: Rp ${toRupiah(harga)}

💳 Detail Pembayaran:
🔐 Kode Transaksi: ${reff}
🧾 Biaya Admin: Rp ${toRupiah(config.PAYMENT.FeeTransaksi)}
💳 Total Bayar: Rp ${toRupiah(total)}
⏰ Batas Waktu: 5 Menit

📱 Cara Bayar:
1. Buka aplikasi e-wallet/m-banking
2. Pilih menu QRIS / Scan QR
3. Scan kode QR di atas
4. Konfirmasi pembayaran

✅ Akun reseller akan aktif setelah pembayaran berhasil!
            \`\`\``.trim();
        } else if (productType === 'special_panel') {
            teks = `\`\`\`Javascript 
👑 PEMBAYARAN SPECIAL PANEL VIA QRIS
━━━━━━━━━━━━━━━━━━━━━━━━━━
📦 Detail Pesanan:
• 🎯 Tipe: ${productData.panelType.toUpperCase()}
• 💰 Harga: Rp ${toRupiah(harga)}

💳 Detail Pembayaran:
🔐 Kode Transaksi: ${reff}
🧾 Biaya Admin: Rp ${toRupiah(config.PAYMENT.FeeTransaksi)}
💳 Total Bayar: Rp ${toRupiah(total)}
⏰ Batas Waktu: 5 Menit

📱 Cara Bayar:
1. Buka aplikasi e-wallet/m-banking
2. Pilih menu QRIS / Scan QR
3. Scan kode QR di atas
4. Konfirmasi pembayaran

✅ Panel akan otomatis dibuat setelah pembayaran berhasil!
            \`\`\``.trim();
        } else if (productType === 'app') {
            teks = `\`\`\`Javascript 
📱 PEMBAYARAN APPS PREMIUM VIA QRIS
━━━━━━━━━━━━━━━━━━━━━━━━━━
📦 Detail Pesanan:
• 🎯 Aplikasi: ${productData.appName}
• 💰 Harga: Rp ${toRupiah(harga)}

💳 Detail Pembayaran:
🔐 Kode Transaksi: ${reff}
🧾 Biaya Admin: Rp ${toRupiah(config.PAYMENT.FeeTransaksi)}
💳 Total Bayar: Rp ${toRupiah(total)}
⏰ Batas Waktu: 5 Menit

📱 Cara Bayar:
1. Buka aplikasi e-wallet/m-banking
2. Pilih menu QRIS / Scan QR
3. Scan kode QR di atas
4. Konfirmasi pembayaran

✅ File akan otomatis dikirim setelah pembayaran berhasil!
            \`\`\``.trim();
        } else if (productType === 'document') {
            teks = `\`\`\`Javascript 
📄 PEMBAYARAN DOCUMENT VIA QRIS
━━━━━━━━━━━━━━━━━━━━━━━━━━
📦 Detail Pesanan:
• 🎯 Document: ${productData.docName}
• 💰 Harga: Rp ${toRupiah(harga)}

💳 Detail Pembayaran:
🔐 Kode Transaksi: ${reff}
🧾 Biaya Admin: Rp ${toRupiah(config.PAYMENT.FeeTransaksi)}
💳 Total Bayar: Rp ${toRupiah(total)}
⏰ Batas Waktu: 5 Menit

📱 Cara Bayar:
1. Buka aplikasi e-wallet/m-banking
2. Pilih menu QRIS / Scan QR
3. Scan kode QR di atas
4. Konfirmasi pembayaran

✅ File akan otomatis dikirim setelah pembayaran berhasil!
            \`\`\``.trim();
        }

        const sentMsg = await bot.sendPhoto(chatId, qrImage, {
            caption: teks,
            parse_mode: "Markdown",
            reply_markup: {
                inline_keyboard: [
                    [{ text: "❌ BATALKAN PEMBAYARAN", callback_data: `cancel_qris_${reff}` }]
                ]
            }
        });

        activeDirectQRIS[reff] = {
            msgId: sentMsg.message_id,
            chatId: chatId,
            userId: userId,
            id: info.id,
            productType: productType,
            productData: productData,
            harga: harga,
            status: true,
            timeout: setTimeout(async () => {
                if (activeDirectQRIS[reff]?.status) {
                    delete activeDirectQRIS[reff];
                    await bot.sendMessage(chatId, "⏰ Waktu pembayaran habis! Silakan buat ulang.");
                }
            }, 300000)
        };

        checkDirectQRISStatus(userId, reff);

    } catch (err) {
        console.error("❌ Direct QRIS error:", err);
        bot.sendMessage(chatId, "❌ Gagal memproses pembayaran QRIS. Silakan coba lagi.");
    }
}

async function checkDirectQRISStatus(userId, reff) {
    const transaksi = activeDirectQRIS[reff];
    if (!transaksi) return;

    const maxAttempts = 300;
    let attempts = 0;

    while (transaksi.status && attempts < maxAttempts) {
        await new Promise(r => setTimeout(r, 2000));
        attempts++;
        
        try {
            const check = await axios.post('https://atlantich2h.com/deposit/status', qs.stringify({
                api_key: config.PAYMENT.apiAtlantic,
                id: transaksi.id
            }), { 
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' } 
            });

            const checkData = check.data;
            let status = '';
            
            if (checkData.data?.status) {
                status = checkData.data.status.toLowerCase();
            } else if (checkData.get?.data?.status) {
                status = checkData.get.data.status.toLowerCase();
            } else if (checkData.status) {
                status = checkData.status.toLowerCase();
            }

            console.log(`🔍 Direct QRIS status check: ${status || 'undefined'} (Attempt ${attempts})`);

            if (status && ['cancel', 'expired', 'failed', 'error'].includes(status)) {
                transaksi.status = false;
                clearTimeout(transaksi.timeout);
                await bot.sendMessage(transaksi.chatId, `❌ Pembayaran gagal: ${status}`);
                delete activeDirectQRIS[reff];
                return;
            }

            if (status && ['success', 'paid', 'completed', 'processing', 'settlement'].includes(status)) {
                if (status === 'processing') {
                    try {
                        await axios.post('https://atlantich2h.com/deposit/instant', 
                            qs.stringify({
                                api_key: config.PAYMENT.apiAtlantic,
                                id: transaksi.id,
                                action: 'true'
                            }), {
                                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
                            }
                        );
                    } catch (e) {
                        console.log("⚠️ Instant confirmation failed, continue...");
                    }
                }

                transaksi.status = false;
                clearTimeout(transaksi.timeout);

                await bot.deleteMessage(transaksi.chatId, transaksi.msgId).catch(() => {});
                
                if (transaksi.productType === 'panel') {
                    pendingPurchases[userId] = {
                        ramSize: transaksi.productData.ramSize,
                        harga: transaksi.harga,
                        paymentMethod: 'qris'
                    };
                    
                    await bot.sendMessage(transaksi.chatId,
                        `\`\`\`Javascript ✅ *PEMBAYARAN BERHASIL!*\n\n` +
                        `💰 *Total Bayar:* Rp ${toRupiah(transaksi.harga + config.PAYMENT.FeeTransaksi)}\n` +
                        `📦 *RAM:* ${transaksi.productData.ramSize.toUpperCase()}\n\n` +
                        `📝 *Silakan masukkan username untuk panel Anda:*\`\`\``,
                        { parse_mode: "Markdown" }
                    );
                    
                    pendingUsername[userId] = true;
                } else if (transaksi.productType === 'reseller') {
                    await handleResellerPurchase(transaksi.chatId, userId, transaksi.productData.packageType);
                } else if (transaksi.productType === 'special_panel') {
                    pendingPurchases[userId] = {
                        panelType: transaksi.productData.panelType,
                        harga: transaksi.harga,
                        paymentMethod: 'qris'
                    };
                    
                    await bot.sendMessage(transaksi.chatId,
                        `\`\`\`Javascript ✅ *PEMBAYARAN SPECIAL PANEL BERHASIL!*\n\n` +
                        `🎯 *Tipe Panel:* ${transaksi.productData.panelType.toUpperCase()}\n` +
                        `💰 *Total Bayar:* Rp ${toRupiah(transaksi.harga + config.PAYMENT.FeeTransaksi)}\n\n` +
                        `📝 *Silakan masukkan username untuk panel Anda:*\`\`\``,
                        { parse_mode: "Markdown" }
                    );
                    
                    pendingUsername[userId] = true;
                } else if (transaksi.productType === 'app') {
                    // Send app file to user
                    await sendAppFile(transaksi.chatId, userId, transaksi.productData.appId);
                } else if (transaksi.productType === 'document') {
                    // Send document file to user
                    await sendDocumentFile(transaksi.chatId, userId, transaksi.productData.docId);
                }

                delete activeDirectQRIS[reff];
                return;
            }
        } catch (err) {
            console.error(`❌ Direct QRIS check error:`, err.message);
        }
    }

    if (transaksi.status) {
        transaksi.status = false;
        clearTimeout(transaksi.timeout);
        await bot.sendMessage(transaksi.chatId, "⏰ Waktu pembayaran habis!");
        delete activeDirectQRIS[reff];
    }
}

// ==================== APPS & DOCUMENTS DELIVERY ====================
async function sendAppFile(chatId, userId, appId) {
    try {
        const apps = getAllApps();
        const app = apps.find(a => a.id === appId);
        
        if (!app) {
            return bot.sendMessage(chatId, "❌ Aplikasi tidak ditemukan!");
        }

        await bot.sendDocument(chatId, app.fileId, {
            caption: `\`\`\`Text📱 *${app.name}*\n\n` +
                     `💰 *Harga:* Rp ${toRupiah(app.price)}\n` +
                     `📝 *Deskripsi:* ${app.description}\n\n` +
                     `✅ *Terima kasih telah berbelanja!*\`\`\``,
            parse_mode: "Markdown"
        });

        // Save transaction
        const transaksi = {
            id: `APP-${Math.floor(100000 + Math.random() * 900000)}`,
            userId: userId,
            productType: 'app',
            productName: app.name,
            price: app.price,
            paymentMethod: 'qris',
            createdAt: new Date().toISOString()
        };

        const allTransaksi = JSON.parse(fs.readFileSync(transaksiPath));
        allTransaksi.push(transaksi);
        fs.writeFileSync(transaksiPath, JSON.stringify(allTransaksi, null, 2));

    } catch (error) {
        console.error("❌ Gagal kirim file app:", error);
        await bot.sendMessage(chatId, "❌ Gagal mengirim file. Silakan hubungi admin.");
    }
}

async function sendDocumentFile(chatId, userId, docId) {
    try {
        const documents = getAllDocuments();
        const doc = documents.find(d => d.id === docId);
        
        if (!doc) {
            return bot.sendMessage(chatId, "❌ Document tidak ditemukan!");
        }

        await bot.sendDocument(chatId, doc.fileId, {
            caption: `\`\`\`Text 📄 *${doc.name}*\n\n` +
                     `💰 *Harga:* Rp ${toRupiah(doc.price)}\n` +
                     `📝 *Deskripsi:* ${doc.description}\n\n` +
                     `✅ *Terima kasih telah berbelanja!*\`\`\``,
            parse_mode: "Markdown"
        });

        // Save transaction
        const transaksi = {
            id: `DOC-${Math.floor(100000 + Math.random() * 900000)}`,
            userId: userId,
            productType: 'document',
            productName: doc.name,
            price: doc.price,
            paymentMethod: 'qris',
            createdAt: new Date().toISOString()
        };

        const allTransaksi = JSON.parse(fs.readFileSync(transaksiPath));
        allTransaksi.push(transaksi);
        fs.writeFileSync(transaksiPath, JSON.stringify(allTransaksi, null, 2));

    } catch (error) {
        console.error("❌ Gagal kirim file document:", error);
        await bot.sendMessage(chatId, "❌ Gagal mengirim file. Silakan hubungi admin.");
    }
}

// ==================== FIXED PTERODACTYL PANEL CREATION FUNCTION ====================
async function createPterodactylPanel(panelName, ramSize, eggType = 'nodejs') {
    try {
        const domain = config.PTERODACTYL.domain;
        const plta = config.PTERODACTYL.apiKey;
        const password = generateSecurePassword(panelName);
        
        const ramMap = {
            '5gb': 5120,
            '6gb': 6144,
            '7gb': 7168,
            '8gb': 8192,
            '9gb': 9216,
            '10gb': 10240,
            'unli': 0
        };

        const cpuMap = {
            '5gb': 200,
            '6gb': 250,
            '7gb': 300,
            '8gb': 350,
            '9gb': 400,
            '10gb': 450,
            'unli': 0
        };

        const diskMap = {
            '5gb': 5120,
            '6gb': 6144,
            '7gb': 7168,
            '8gb': 8192,
            '9gb': 9216,
            '10gb': 10240,
            'unli': 0
        };

        const eggMap = {
            'nodejs': config.PTERODACTYL.eggs.nodejs,
            'python': config.PTERODACTYL.eggs.python,
            'pm2': config.PTERODACTYL.eggs.pm2
        };

        const memo = ramMap[ramSize] || 5120;
        const cpu = cpuMap[ramSize] || 200;
        const disk = diskMap[ramSize] || 5120;
        const egg = eggMap[eggType] || config.PTERODACTYL.eggs.nodejs;
        const loc = config.PTERODACTYL.loc;
        const nest = config.PTERODACTYL.nest;

        // CREATE USER
        const response = await fetch(`${domain}/api/application/users`, {
            method: "POST",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${plta}`,
            },
            body: JSON.stringify({
                email: `${panelName}@user.king`,
                username: panelName,
                first_name: panelName,
                last_name: "user",
                language: "en",
                root_admin: false,
                password: password,
            }),
        });

        const data = await response.json();
        if (data.errors) {
            return { success: false, error: JSON.stringify(data.errors[0], null, 2) };
        }

        const user = data.attributes;

        // CREATE SERVER dengan konfigurasi yang benar berdasarkan egg type
        let serverData = {
            name: panelName,
            description: "",
            user: user.id,
            egg: parseInt(egg),
            limits: {
                memory: memo,
                swap: 0,
                disk: disk,
                io: 500,
                cpu: cpu,
            },
            feature_limits: {
                databases: 5,
                backups: 5,
                allocations: 1,
            },
            deploy: {
                locations: [parseInt(loc)],
                dedicated_ip: false,
                port_range: [],
            },
        };

        // Konfigurasi berdasarkan egg type
        if (eggType === 'nodejs') {
            serverData.docker_image = "ghcr.io/parkervcp/yolks:nodejs_24";
            serverData.startup = "if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == \"1\" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}";
            serverData.environment = {
                AUTO_UPDATE: "0",
                NODE_PACKAGES: "",
                UNNODE_PACKAGES: "",
                CMD_RUN: "npm start"
            };
        } 
        else if (eggType === 'python') {
            serverData.docker_image = "ghcr.io/parkervcp/yolks:python_3.11";
            serverData.startup = "if [[ -d .git ]] && [[ \"{{AUTO_UPDATE}}\" == \"1\" ]]; then git pull; fi; if [[ ! -z \"{{PY_PACKAGES}}\" ]]; then pip install -U --prefix .local {{PY_PACKAGES}}; fi; if [[ -f /home/container/${REQUIREMENTS_FILE} ]]; then pip install -U --prefix .local -r ${REQUIREMENTS_FILE}; fi; /usr/local/bin/python /home/container/{{PY_FILE}}";
            serverData.environment = {
                AUTO_UPDATE: "0",
                PY_PACKAGES: "",
                REQUIREMENTS_FILE: "requirements.txt",
                PY_FILE: "app.py"
            };
        } 
        else if (eggType === 'pm2') {
            serverData.docker_image = "ghcr.io/parkervcp/yolks:nodejs_24";
            serverData.startup = "if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == \"1\" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; pm2 start {{JS_FILE}} --name=\"app\"; pm2 logs";
            serverData.environment = {
                AUTO_UPDATE: "0",
                NODE_PACKAGES: "",
                UNNODE_PACKAGES: "",
                JS_FILE: "index.js"
            };
        }

        console.log("📦 Creating server with data:", JSON.stringify(serverData, null, 2));

        const response2 = await fetch(`${domain}/api/application/servers`, {
            method: "POST",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${plta}`,
            },
            body: JSON.stringify(serverData),
        });

        const data2 = await response2.json();
        console.log("📦 Server creation response:", JSON.stringify(data2, null, 2));
        
        if (data2.errors) {
            return { success: false, error: JSON.stringify(data2.errors[0], null, 2) };
        }

        const server = data2.attributes;

        return {
            success: true,
            data: {
                id: user.id,
                username: user.username,
                email: user.email,
                password: password,
                serverId: server.id,
                serverName: server.name,
                domain: domain,
                memory: memo,
                cpu: cpu,
                disk: disk,
                eggType: eggType
            }
        };

    } catch (error) {
        console.error("❌ Pterodactyl creation error:", error);
        return { success: false, error: error.message };
    }
}

// ==================== ALTERNATIVE FIXED VERSION (BACKUP) ====================
async function createPterodactylPanelFixed(panelName, ramSize, eggType = 'nodejs') {
    try {
        const domain = config.PTERODACTYL.domain;
        const plta = config.PTERODACTYL.apiKey;
        const password = generateSecurePassword(panelName);
        
        const ramMap = {
            '5gb': 5120,
            '6gb': 6144,
            '7gb': 7168,
            '8gb': 8192,
            '9gb': 9216,
            '10gb': 10240,
            'unli': 0
        };

        const cpuMap = {
            '5gb': 200,
            '6gb': 250,
            '7gb': 300,
            '8gb': 350,
            '9gb': 400,
            '10gb': 450,
            'unli': 0
        };

        const diskMap = {
            '5gb': 5120,
            '6gb': 6144,
            '7gb': 7168,
            '8gb': 8192,
            '9gb': 9216,
            '10gb': 10240,
            'unli': 0
        };

        const eggMap = {
            'nodejs': config.PTERODACTYL.eggs.nodejs,
            'python': config.PTERODACTYL.eggs.python,
            'pm2': config.PTERODACTYL.eggs.pm2
        };

        const memo = ramMap[ramSize] || 5120;
        const cpu = cpuMap[ramSize] || 200;
        const disk = diskMap[ramSize] || 5120;
        const egg = eggMap[eggType] || config.PTERODACTYL.eggs.nodejs;
        const loc = config.PTERODACTYL.loc;
        const nest = config.PTERODACTYL.nest;

        // CREATE USER
        const response = await fetch(`${domain}/api/application/users`, {
            method: "POST",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${plta}`,
            },
            body: JSON.stringify({
                email: `${panelName}@user.king`,
                username: panelName,
                first_name: panelName,
                last_name: "user",
                language: "en",
                root_admin: false,
                password: password,
            }),
        });

        const data = await response.json();
        if (data.errors) {
            return { success: false, error: JSON.stringify(data.errors[0], null, 2) };
        }

        const user = data.attributes;

        // CREATE SERVER dengan environment variables yang lengkap
        let serverData = {
            name: panelName,
            description: `Panel ${ramSize} - ${eggType}`,
            user: user.id,
            egg: parseInt(egg),
            docker_image: "ghcr.io/parkervcp/yolks:nodejs_24",
            startup: "",
            environment: {
                USER_UPLOAD: "0",
                AUTO_UPDATE: "0",
                STARTUP: ""
            },
            limits: {
                memory: memo,
                swap: 0,
                disk: disk,
                io: 500,
                cpu: cpu,
            },
            feature_limits: {
                databases: 5,
                backups: 5,
                allocations: 1,
            },
            deploy: {
                locations: [parseInt(loc)],
                dedicated_ip: false,
                port_range: [],
            },
        };

        // Konfigurasi spesifik berdasarkan egg type
        if (eggType === 'nodejs') {
            serverData.docker_image = "ghcr.io/parkervcp/yolks:nodejs_24";
            serverData.startup = "npm start";
            serverData.environment = {
                ...serverData.environment,
                NODE_VERSION: "24",
                JS_FILE: "index.js",
                NODE_PACKAGES: "",
                UNNODE_PACKAGES: "",
                STARTUP: "npm start"
            };
        } else if (eggType === 'python') {
            serverData.docker_image = "ghcr.io/parkervcp/yolks:python_3.12";
            serverData.startup = "python app.py";
            serverData.environment = {
                ...serverData.environment,
                PYTHON_VERSION: "3.11",
                PY_FILE: "app.py",
                REQUIREMENTS_FILE: "requirements.txt",
                STARTUP: "python app.py"
            };
        } else if (eggType === 'pm2') {
            serverData.docker_image = "ghcr.io/parkervcp/yolks:nodejs_24";
            serverData.startup = "pm2 start ecosystem.config.js && pm2 logs";
            serverData.environment = {
                ...serverData.environment,
                NODE_VERSION: "24",
                JS_FILE: "index.js",
                PM2_VERSION: "5",
                PM2_INSTANCE: "1",
                STARTUP: "pm2 start ecosystem.config.js"
            };
        }

        console.log("📦 Creating server with fixed data:", JSON.stringify(serverData, null, 2));

        const response2 = await fetch(`${domain}/api/application/servers`, {
            method: "POST",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${plta}`,
            },
            body: JSON.stringify(serverData),
        });

        const data2 = await response2.json();
        console.log("📦 Server creation response:", JSON.stringify(data2, null, 2));
        
        if (data2.errors) {
            // Coba dengan approach yang lebih sederhana
            return await createPterodactylPanelSimple(panelName, ramSize, eggType, user.id);
        }

        const server = data2.attributes;

        return {
            success: true,
            data: {
                id: user.id,
                username: user.username,
                email: user.email,
                password: password,
                serverId: server.id,
                serverName: server.name,
                domain: domain,
                memory: memo,
                cpu: cpu,
                disk: disk,
                eggType: eggType
            }
        };

    } catch (error) {
        console.error("❌ Pterodactyl creation error:", error);
        return { success: false, error: error.message };
    }
}

// ==================== FIXED SPECIAL PANEL CREATION ====================
async function createSpecialPanel(panelName, panelType) {
    try {
        const domain = config.PTERODACTYL.domain;
        const plta = config.PTERODACTYL.apiKey;
        const password = generateSecurePassword(panelName);
        
        let email = '';
        let root_admin = false;
        let lastName = '';

        switch (panelType) {
            case 'admin_panel':
                email = `${panelName}@admin.king`;
                root_admin = true;
                lastName = 'admin';
                break;
            case 'owner_panel':
                email = `${panelName}@owner.king`;
                root_admin = true;
                lastName = 'owner';
                break;
            case 'tk_panel':
                email = `${panelName}@tk.king`;
                root_admin = true;
                lastName = 'tk';
                break;
            case 'pt_panel':
                email = `${panelName}@pt.king`;
                root_admin = true;
                lastName = 'pt';
                break;
            case 'reseller_panel':
                email = `${panelName}@reseller.king`;
                root_admin = false;
                lastName = 'reseller';
                break;
            default:
                email = `${panelName}@user.king`;
                root_admin = false;
                lastName = 'user';
        }

        console.log(`🔧 Creating special panel: ${panelName}, Type: ${panelType}`);
        console.log(`📧 Email: ${email}, Admin: ${root_admin}`);

        // CREATE USER
        const response = await fetch(`${domain}/api/application/users`, {
            method: "POST",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${plta}`,
            },
            body: JSON.stringify({
                email: email,
                username: panelName,
                first_name: panelName,
                last_name: lastName,
                language: "en",
                root_admin: root_admin,
                password: password,
            }),
        });

        const data = await response.json();
        if (data.errors) {
            console.error("❌ Pterodactyl user creation error:", data.errors);
            return { success: false, error: JSON.stringify(data.errors[0], null, 2) };
        }

        const user = data.attributes;
        console.log(`✅ Special user created: ${user.id}, Admin: ${root_admin}`);

        // Untuk special panel, kita hanya membuat user account saja
        // Server creation bisa dilakukan manual atau melalui panel

        return {
            success: true,
            data: {
                id: user.id,
                username: user.username,
                email: user.email,
                password: password,
                domain: domain,
                panelType: panelType,
                root_admin: root_admin
            }
        };

    } catch (error) {
        console.error("❌ Special panel creation error:", error);
        return { success: false, error: error.message };
    }
}

// ==================== HANDLE RESELLER PURCHASE ====================
async function handleResellerPurchase(chatId, userId, packageType) {
    try {
        saveReseller(userId, packageType);
        
        const packageInfo = config.RESELLER[packageType];
        
        await bot.sendMessage(chatId,
            `\`\`\`Javascript 🎉 *PAKET RESELLER AKTIF!*\n\n` +
            `📦 *Paket:* ${packageType.toUpperCase()}\n` +
            `💎 *Limit Harian:* ${packageInfo.daily_limit} panel\n` +
            `⚡ *Max RAM:* ${packageInfo.max_ram} MB\n` +
            `💰 *Harga Jual:* Sesuai keinginan\n\n` +
            `📖 *Cara Jual Panel:*\n` +
            `1. Gunakan menu "🛒 Jual Panel"\n` +
            `2. Pilih RAM yang ingin dijual\n` +
            `3. Masukkan username customer\n` +
            `4. Panel akan dibuat otomatis\n\n` +
            `💡 *Tips:* Atur harga jual yang kompetitif!\`\`\``,
            { parse_mode: "Markdown" }
        );

        const userInfo = await bot.getChat(userId);
        await sendResellerNotification(userId, packageType, userInfo.username);

    } catch (error) {
        console.error("❌ Reseller activation error:", error);
        await bot.sendMessage(chatId, "❌ Gagal mengaktifkan paket reseller. Silakan hubungi admin.");
    }
}

// ==================== RESELLER SELL SYSTEM ====================
// ==================== RESELLER SELL SYSTEM WITH EGG TYPE ====================
async function showSellPanelMenu(chatId, userId, messageId = null) {
    const resellerInfo = getResellerInfo(userId);
    if (!resellerInfo) {
        return bot.sendMessage(chatId, "❌ Anda bukan reseller!");
    }

    const menuText = `
\`\`\`Javascript 🛒 *JUAL PANEL*
━━━━━━━━━━━━━━━━━━━━━━━━━━
💼 *Status Reseller:* ${resellerInfo.package.toUpperCase()}
📊 *Limit Harian:* ${resellerInfo.daily_limit} panel
💾 *Max RAM:* ${resellerInfo.max_ram} MB

*Pilih RAM untuk dijual:*\`\`\`
    `.trim();

    const keyboard = [
        [
            { text: "5GB", callback_data: "sell_5gb" },
            { text: "6GB", callback_data: "sell_6gb" },
            { text: "7GB", callback_data: "sell_7gb" }
        ],
        [
            { text: "8GB", callback_data: "sell_8gb" },
            { text: "9GB", callback_data: "sell_9gb" },
            { text: "10GB", callback_data: "sell_10gb" }
        ],
        [
            { text: "UNLI", callback_data: "sell_unli" }
        ],
        [
            { text: "🔙 KEMBALI", callback_data: "reseller_menu" }
        ]
    ];

    const menuOptions = {
        reply_markup: { inline_keyboard: keyboard },
        parse_mode: "Markdown"
    };

    if (messageId) {
        bot.editMessageText(menuText, {
            chat_id: chatId,
            message_id: messageId,
            ...menuOptions
        });
    } else {
        bot.sendMessage(chatId, menuText, menuOptions);
    }
}

async function handleSellPanel(chatId, userId, ramSize, messageId) {
    const resellerInfo = getResellerInfo(userId);
    if (!resellerInfo) {
        return bot.sendMessage(chatId, "❌ Anda bukan reseller!");
    }

    // Check daily limit
    const today = moment().format('YYYY-MM-DD');
    const statsPath = resellerStatsPath;
    let stats = {};
    
    try {
        stats = JSON.parse(fs.readFileSync(statsPath));
    } catch (e) {
        stats = {};
    }

    if (!stats[userId]) {
        stats[userId] = {
            total_sales: 0,
            total_income: 0,
            daily_sales: {}
        };
    }

    const todaySales = stats[userId].daily_sales[today] || 0;
    
    if (todaySales >= resellerInfo.daily_limit) {
        return bot.editMessageText(
            `❌ *LIMIT HARIAN HABIS!*\n\n` +
            `📊 *Limit Harian:* ${resellerInfo.daily_limit} panel\n` +
            `📈 *Terjual Hari Ini:* ${todaySales} panel\n\n` +
            `💡 Limit akan direset besok pagi.`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: "Markdown"
            }
        );
    }

    // Check saldo cukup untuk modal
    const modalPrice = getResellerPrice(ramSize);
    const currentSaldo = getUserSaldo(userId);
    
    if (currentSaldo < modalPrice) {
        return bot.editMessageText(
            `\`\`\`Javascript ❌ *SALDO TIDAK CUKUP!*\n\n` +
            `💰 *Modal yang dibutuhkan:* Rp ${toRupiah(modalPrice)}\n` +
            `💎 *Saldo Anda:* Rp ${toRupiah(currentSaldo)}\n\n` +
            `💡 Deposit terlebih dahulu untuk melanjutkan penjualan.\`\`\``,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: "Markdown",
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: "💰 DEPOSIT", callback_data: "deposit_menu" },
                            { text: "🔙 KEMBALI", callback_data: "sell_panel" }
                        ]
                    ]
                }
            }
        );
    }

    // Store sell session
    resellerSellSessions[userId] = {
        ramSize: ramSize,
        modalPrice: modalPrice,
        step: 'waiting_username'
    };

    await bot.editMessageText(
        `\`\`\`Javascript 🛒 *JUAL PANEL ${ramSize.toUpperCase()}*\n\n` +
        `📦 *RAM:* ${ramSize.toUpperCase()}\n` +
        `💰 *Modal:* Rp ${toRupiah(modalPrice)}\n` +
        `💎 *Saldo Tersedia:* Rp ${toRupiah(currentSaldo)}\n\n` +
        `📝 *Masukkan username untuk customer:*\`\`\``,
        {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: "Markdown"
        }
    );
}

// ==================== MENU FUNCTIONS ====================
async function showMainMenu(chatId, userId, messageId = null) {
    const saldo = getUserSaldo(userId);
    const isResellerUser = isReseller(userId);
    const isOwnerUser = isOwner(userId);
    const userInfo = await bot.getChat(userId);
    const username = userInfo.username || 'User';
    
    const menuText = `\`\`\`Javascript 
╔═══ ✦ 𓆩🌐𓆪 GINASTORE OFFICIAL𓆩🌐𓆪 ✦ ═══╗
        ⚡ ELITE DIGITAL AUTOMATION ⚡
╚══════════════════════════════╝

👑 *Welcome, @${username || 'User'}!*  
Selamat datang di ekosistem *AutoOrder Premium 2025* 🚀  

━━━━━━━━〔 🔥 LAYANAN ELITE 🔥 〕━━━━━━━━
💎 Apps Premium → Netflix, YT, Canva, Prime, dll   
💻 Script & Template Premium → Source Terbaik    
🛠️ Admin / Reseller / TK Panel / Pt Panel/ Owner Panel → Instant   
💳 Saldo Otomatis + QRIS Support  

━━━━━━━━〔 💠 KEUNGGULAN 💠 〕━━━━━━━━
✅ 100% Realtime Auto Delivery  
💲 Termurah + Banyak Bonus  
🛡️ Garansi Full & Support 24/7  
🚫 Anti PHP – Tanpa Ribet  

╔════ ✦ JOIN • ORDER • DOMINATE ✦ ═══╗
        🔥 The Future is Here 🔥
╚════════════════════════════╝

🛸 ─────〔 *GINASTORE AUTOORDER* 〕───── 🛸

👤 User    : @${username}
📍 Status  : ✅ Aktif & Siap Order  

═══════〔 ⚡ DASHBOARD ⚡ 〕═══════
🕒 Waktu Sekarang : ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}
⏱️ Runtime Bot    : ${getRuntime()}
💳 Saldo Kamu     : Rp ${saldo.toLocaleString("id-ID")}
👥 Total Pengguna : ${getTotalUsers()}
══════════════════════════════

💡 *Pro Tips:*  
Gunakan button untuk menjelajahi dan button lainnya untuk melihat semua fiture
produk premium, panel, VPS, & promo eksklusif 🚀

🛸 ───────〔 *GINA OFFICIAL* 〕─────── 🛸
    \`\`\``.trim();

    const keyboard = [];
    
    if (isOwnerUser) {
        keyboard.push([{ text: "👑 OWNER MENU", callback_data: "owner_menu" }]);
    }
    
    keyboard.push(
        [{ text: "🛒 BELI PANEL", callback_data: "buy_panel" },
        { text: "💼 RESELLER PANEL", callback_data: "reseller_menu" }],
        [{ text: "👑 SPECIAL PANEL", callback_data: "special_panel_menu" },
        { text: "📱 APPS PREMIUM", callback_data: "apps_menu" }],
        [{ text: "💻 SCRIPT & TEMPLATE", callback_data: "documents_menu" },
        { text: "💰 DEPOSIT SALDO", callback_data: "deposit_menu" }],
        [
            { text: "📦 PANEL SAYA", callback_data: "my_panels" },
            { text: "ℹ️ BANTUAN", callback_data: "help_menu" }
        ]
    );

    if (isResellerUser) {
        keyboard.push([{ text: "🛒 JUAL PANEL", callback_data: "sell_panel" }]);
    }

    const menuOptions = {
        reply_markup: { inline_keyboard: keyboard },
        parse_mode: "Markdown"
    };

    if (messageId) {
        bot.editMessageText(menuText, {
            chat_id: chatId,
            message_id: messageId,
            ...menuOptions
        });
    } else {
        bot.sendMessage(chatId, menuText, menuOptions);
    }
}

async function showPanelMenu(chatId, messageId = null) {
    const menuText = `
\`\`\`Javascript 🛒 *PANEL PREMIUM*
━━━━━━━━━━━━━━━━━━━━━━━━━━
*Pilih RAM Panel:*

• 5GB  - Rp ${toRupiah(config.PANEL_PRICES['5gb'])}
• 6GB  - Rp ${toRupiah(config.PANEL_PRICES['6gb'])}
• 7GB  - Rp ${toRupiah(config.PANEL_PRICES['7gb'])}
• 8GB  - Rp ${toRupiah(config.PANEL_PRICES['8gb'])}
• 9GB  - Rp ${toRupiah(config.PANEL_PRICES['9gb'])}
• 10GB - Rp ${toRupiah(config.PANEL_PRICES['10gb'])}
• UNLI - Rp ${toRupiah(config.PANEL_PRICES['unli'])}

💡 *Garansi 15 hari*
    \`\`\``.trim();

    const keyboard = [
        [
            { text: "5GB", callback_data: "buy_5gb" },
            { text: "6GB", callback_data: "buy_6gb" },
            { text: "7GB", callback_data: "buy_7gb" }
        ],
        [
            { text: "8GB", callback_data: "buy_8gb" },
            { text: "9GB", callback_data: "buy_9gb" },
            { text: "10GB", callback_data: "buy_10gb" }
        ],
        [
            { text: "UNLI", callback_data: "buy_unli" }
        ],
        [
            { text: "🔙 KEMBALI", callback_data: "main_menu" }
        ]
    ];

    const menuOptions = {
        reply_markup: { inline_keyboard: keyboard },
        parse_mode: "Markdown"
    };

    if (messageId) {
        bot.editMessageText(menuText, {
            chat_id: chatId,
            message_id: messageId,
            ...menuOptions
        });
    } else {
        bot.sendMessage(chatId, menuText, menuOptions);
    }
}

async function showResellerMenu(chatId, userId, messageId = null) {
    const isResellerUser = isReseller(userId);
    const resellerInfo = getResellerInfo(userId);
    
    let menuText = '';
    
    if (isResellerUser) {
        menuText = `\`\`\`Javascript 
💼 *RESELLER PANEL*
━━━━━━━━━━━━━━━━━━━━━━━━━━
*Status:* ✅ AKTIF
*Paket:* ${resellerInfo.package.toUpperCase()}
*Limit Harian:* ${resellerInfo.daily_limit} panel
*Max RAM:* ${resellerInfo.max_ram} MB

💡 *Fitur:*
• Bisa jual panel 5GB - UNLI
• Harga jual sesuai keinginan
• Buat panel untuk customer
        \`\`\``.trim();
    } else {
        menuText = `
\`\`\`Javascript 💼 *RESELLER PANEL*
━━━━━━━━━━━━━━━━━━━━━━━━━━
*Jadi reseller dan dapatkan keuntungan!*

📦 *Paket Reseller:*
• RESELLER - Rp ${toRupiah(config.RESELLER_PRICES.reseller)}
  └ Limit: ${config.RESELLER.reseller.daily_limit} panel/hari
  └ Max RAM: ${config.RESELLER.reseller.max_ram} MB

💡 *Keuntungan:*
• Bisa jual panel 5GB - UNLI
• Harga jual bebas (sesuai keinginan)
• Buat panel untuk customer
• Dashboard reseller
        \`\`\``.trim();
    }

    const keyboard = [];
    
    if (isResellerUser) {
        keyboard.push(
            [{ text: "🛒 JUAL PANEL", callback_data: "sell_panel" }],
            [{ text: "📊 DASHBOARD RESELLER", callback_data: "reseller_dashboard" }]
        );
    } else {
        keyboard.push(
            [{ text: "💼 BELI PAKET RESELLER", callback_data: "buy_reseller" }]
        );
    }
    
    keyboard.push([{ text: "🔙 KEMBALI", callback_data: "main_menu" }]);

    const menuOptions = {
        reply_markup: { inline_keyboard: keyboard },
        parse_mode: "Markdown"
    };

    if (messageId) {
        bot.editMessageText(menuText, {
            chat_id: chatId,
            message_id: messageId,
            ...menuOptions
        });
    } else {
        bot.sendMessage(chatId, menuText, menuOptions);
    }
}

async function showSpecialPanelMenu(chatId, userId, messageId = null) {
    const isOwnerUser = isOwner(userId);
    
    const menuText = `
\`\`\`Javascript 👑 *SPECIAL PANEL*
━━━━━━━━━━━━━━━━━━━━━━━━━━
*Panel khusus dengan fitur khusus!*

🎯 *Pilihan Panel:*
• ADMIN PANEL - Rp ${toRupiah(config.SPECIAL_PANEL_PRICES.admin_panel)}
  └ Bisa open reseller & jual panel 5GB - UNLI

• RESELLER PANEL - Rp ${toRupiah(config.SPECIAL_PANEL_PRICES.reseller_panel)}
  └ Bisa jual 5GB - UNLI

• OWNER PANEL - Rp ${toRupiah(config.SPECIAL_PANEL_PRICES.owner_panel)}
  └ Bisa jual PT Panel - Admin Panel - Reseller Panel & 5GB - UNLI

• PT PANEL - Rp ${toRupiah(config.SPECIAL_PANEL_PRICES.pt_panel)}
  └ Bisa jual - Reseller Panel & 5GB - UNLI

• TK PANEL - Rp ${toRupiah(config.SPECIAL_PANEL_PRICES.tk_panel)}
  └ Bisa jual Owner Panel - PT Panel - Admin Panel - Reseller Panel & 5GB - UNLI

${isOwnerUser ? '\n👑 *Owner bisa buat panel gratis!*' : ''}
    \`\`\``.trim();

    const keyboard = [
        [
            { text: "ADMIN", callback_data: "special_admin" },
            { text: "RESELLER", callback_data: "special_reseller" }
        ],
        [
            { text: "OWNER", callback_data: "special_owner" },
            { text: "PT", callback_data: "special_pt" }
        ],
        [
            { text: "TK", callback_data: "special_tk" }
        ],
        [
            { text: "🔙 KEMBALI", callback_data: "main_menu" }
        ]
    ];

    const menuOptions = {
        reply_markup: { inline_keyboard: keyboard },
        parse_mode: "Markdown"
    };

    if (messageId) {
        bot.editMessageText(menuText, {
            chat_id: chatId,
            message_id: messageId,
            ...menuOptions
        });
    } else {
        bot.sendMessage(chatId, menuText, menuOptions);
    }
}

async function showAppsMenu(chatId, messageId = null) {
    const apps = getAllApps();
    
    let menuText = `\`\`\`Javascript  
📱 *APPS PREMIUM*
━━━━━━━━━━━━━━━━━━━━━━━━━━
*Aplikasi premium siap pakai!*

`;
    
    if (apps.length === 0) {
        menuText += `❌ *Belum ada apps tersedia*\n\nHubungi admin untuk menambahkan apps.`;
    } else {
        apps.forEach((app, index) => {
            menuText += `• ${app.name} - Rp ${toRupiah(app.price)}\n`;
            menuText += `  └ ${app.description}\n\n`;
        });
    }

    menuText += `💡 *Semua apps garansi 100%*\`\`\``;

    const keyboard = [];
    
    if (apps.length > 0) {
        apps.forEach((app, index) => {
            if (index % 2 === 0) {
                const row = [];
                row.push({ 
                    text: `${app.name}`, 
                    callback_data: `buy_app_${app.id}` 
                });
                
                if (apps[index + 1]) {
                    row.push({ 
                        text: `${apps[index + 1].name}`, 
                        callback_data: `buy_app_${apps[index + 1].id}` 
                    });
                }
                
                keyboard.push(row);
            }
        });
    }
    
    keyboard.push([{ text: "🔙 KEMBALI", callback_data: "main_menu" }]);

    const menuOptions = {
        reply_markup: { inline_keyboard: keyboard },
        parse_mode: "Markdown"
    };

    if (messageId) {
        bot.editMessageText(menuText, {
            chat_id: chatId,
            message_id: messageId,
            ...menuOptions
        });
    } else {
        bot.sendMessage(chatId, menuText, menuOptions);
    }
}

async function showDocumentsMenu(chatId, messageId = null) {
    const documents = getAllDocuments();
    
    let menuText = `\`\`\`Javascript  
💻 *SCRIPT & TEMPLATE PREMIUM*
━━━━━━━━━━━━━━━━━━━━━━━━━━
*Source code & template berkualitas!*

`;
    
    if (documents.length === 0) {
        menuText += `❌ *Belum ada document tersedia*\n\nHubungi admin untuk menambahkan document.`;
    } else {
        documents.forEach((doc, index) => {
            menuText += `• ${doc.name} - Rp ${toRupiah(doc.price)}\n`;
            menuText += `  └ ${doc.description}\n\n`;
        });
    }

    menuText += `💡 *Semua document garansi 100%*\`\`\``;

    const keyboard = [];
    
    if (documents.length > 0) {
        documents.forEach((doc, index) => {
            if (index % 2 === 0) {
                const row = [];
                row.push({ 
                    text: `${doc.name}`, 
                    callback_data: `buy_doc_${doc.id}` 
                });
                
                if (documents[index + 1]) {
                    row.push({ 
                        text: `${documents[index + 1].name}`, 
                        callback_data: `buy_doc_${documents[index + 1].id}` 
                    });
                }
                
                keyboard.push(row);
            }
        });
    }
    
    keyboard.push([{ text: "🔙 KEMBALI", callback_data: "main_menu" }]);

    const menuOptions = {
        reply_markup: { inline_keyboard: keyboard },
        parse_mode: "Markdown"
    };

    if (messageId) {
        bot.editMessageText(menuText, {
            chat_id: chatId,
            message_id: messageId,
            ...menuOptions
        });
    } else {
        bot.sendMessage(chatId, menuText, menuOptions);
    }
}

async function showDepositMenu(chatId, userId, messageId = null) {
    const saldo = getUserSaldo(userId);
    
    const menuText = `
\`\`\`Javascript 💰 *DEPOSIT SALDO*
━━━━━━━━━━━━━━━━━━━━━━━━━━
💎 *Saldo Anda:* Rp ${toRupiah(saldo)}

💳 *Metode Deposit:*
• QRIS (Semua E-Wallet & Bank)

📝 *Cara Deposit:*
1. Pilih nominal deposit
2. Scan QR Code yang diberikan
3. Bayar via aplikasi e-wallet/m-banking
4. Saldo otomatis bertambah

💡 *Minimal Deposit:* Rp 5,000
    \`\`\``.trim();

    const keyboard = [
        [
            { text: "💰 5.000", callback_data: "deposit_5000" },
            { text: "💰 10.000", callback_data: "deposit_10000" },
            { text: "💰 20.000", callback_data: "deposit_20000" }
        ],
        [
            { text: "💰 50.000", callback_data: "deposit_50000" },
            { text: "💰 100.000", callback_data: "deposit_100000" },
            { text: "💰 200.000", callback_data: "deposit_200000" }
        ],
        [
            { text: "💰 LAINNYA", callback_data: "deposit_custom" }
        ],
        [
            { text: "🔙 KEMBALI", callback_data: "main_menu" }
        ]
    ];

    const menuOptions = {
        reply_markup: { inline_keyboard: keyboard },
        parse_mode: "Markdown"
    };

    if (messageId) {
        bot.editMessageText(menuText, {
            chat_id: chatId,
            message_id: messageId,
            ...menuOptions
        });
    } else {
        bot.sendMessage(chatId, menuText, menuOptions);
    }
}

// ==================== OWNER MENU FUNCTIONS ====================
async function showOwnerMenu(chatId, messageId = null) {
    const totalUsers = getTotalUsers();
    const totalTransactions = getTotalTransactions();
    const totalPanels = getTotalPanels();
    
    const menuText = `
\`\`\`Javascript 👑 *OWNER MENU*
━━━━━━━━━━━━━━━━━━━━━━━━━━
*Fitur khusus untuk Owner*

📊 *Statistik:*
• Total User: ${totalUsers}
• Total Transaksi: ${totalTransactions}
• Total Panel: ${totalPanels}
• Runtime: ${getRuntime()}

🛠️ *Tools:*
• Tambah Saldo User
• Broadcast Message
• Kelola User
• Kelola Transaksi
• Kelola Garansi
• Kelola Apps
• Kelola Documents
    \`\`\``.trim();

    const keyboard = [
    [
        { text: "💰 TAMBAH SALDO", callback_data: "owner_addsaldo" },
        { text: "📢 BROADCAST", callback_data: "owner_broadcast" },
    ],
    [
        { text: "👥 KELOLA USER", callback_data: "owner_manage_users" },
        { text: "📦 KELOLA TRANSAKSI", callback_data: "owner_manage_orders" }
    ],
    [
        { text: "🛡️ KELOLA GARANSI", callback_data: "owner_manage_warranty" },
        { text: "📱 KELOLA APPS", callback_data: "owner_manage_apps" }
    ],
    [
        { text: "💻 KELOLA DOCUMENTS", callback_data: "owner_manage_documents" },
        { text: "⚙️ KELOLA CONFIG", callback_data: "config_menu" }
    ],
    [
        { text: "🔙 KEMBALI", callback_data: "main_menu" }
    ]
];

    const menuOptions = {
        reply_markup: { inline_keyboard: keyboard },
        parse_mode: "Markdown"
    };

    if (messageId) {
        bot.editMessageText(menuText, {
            chat_id: chatId,
            message_id: messageId,
            ...menuOptions
        });
    } else {
        bot.sendMessage(chatId, menuText, menuOptions);
    }
}

async function showOwnerManageUsers(chatId, messageId = null) {
    const users = getAllUsers();
    
    let menuText = `
\`\`\`Javascript 👥 *KELOLA USER*
━━━━━━━━━━━━━━━━━━━━━━━━━━
*Total User:* ${users.length}

`;
    
    users.slice(0, 10).forEach((user, index) => {
        const saldo = getUserSaldo(user.userId);
        menuText += `${index + 1}. User ID: ${user.userId}\n`;
        menuText += `   Saldo: Rp ${toRupiah(saldo)}\n\n`;
    });
    
    if (users.length > 10) {
        menuText += `... dan ${users.length - 10} user lainnya\n\n`;
    }

    menuText += `🔄 *Klik REFRESH untuk update data*\`\`\``;

    const keyboard = [
        [
            { text: "💰 TAMBAH SALDO", callback_data: "owner_addsaldo" },
            { text: "📊 STATS USER", callback_data: "owner_user_stats" }
        ],
        [
            { text: "🔄 REFRESH", callback_data: "owner_manage_users" },
            { text: "🔙 KEMBALI", callback_data: "owner_menu" }
        ]
    ];

    const menuOptions = {
        reply_markup: { inline_keyboard: keyboard },
        parse_mode: "Markdown"
    };

    if (messageId) {
        bot.editMessageText(menuText, {
            chat_id: chatId,
            message_id: messageId,
            ...menuOptions
        });
    } else {
        bot.sendMessage(chatId, menuText, menuOptions);
    }
}

async function showOwnerManageOrders(chatId, messageId = null) {
    const transactions = JSON.parse(fs.readFileSync(transaksiPath));
    const panelPurchases = JSON.parse(fs.readFileSync(panelPurchasesPath));
    const specialPanels = JSON.parse(fs.readFileSync(specialPanelsPath));
    
    const allOrders = [...transactions, ...panelPurchases, ...specialPanels];
    allOrders.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    let menuText = `
📦 *KELOLA TRANSAKSI*
━━━━━━━━━━━━━━━━━━━━━━━━━━
*Total Transaksi:* ${allOrders.length}

`;
    
    allOrders.slice(0, 10).forEach((order, index) => {
        menuText += `${index + 1}. ${order.id}\n`;
        menuText += `   User: ${order.userId}\n`;
        menuText += `   Produk: ${order.productType || order.panelType || 'Panel'}\n`;
        menuText += `   Harga: Rp ${toRupiah(order.price || 0)}\n`;
        menuText += `   Waktu: ${new Date(order.createdAt).toLocaleDateString('id-ID')}\n\n`;
    });
    
    if (allOrders.length > 10) {
        menuText += `... dan ${allOrders.length - 10} transaksi lainnya\n\n`;
    }

    const keyboard = [
        [
            { text: "📊 STATS TRANSAKSI", callback_data: "owner_order_stats" }
        ],
        [
            { text: "🔄 REFRESH", callback_data: "owner_manage_orders" },
            { text: "🔙 KEMBALI", callback_data: "owner_menu" }
        ]
    ];

    const menuOptions = {
        reply_markup: { inline_keyboard: keyboard },
        parse_mode: "Markdown"
    };

    if (messageId) {
        bot.editMessageText(menuText, {
            chat_id: chatId,
            message_id: messageId,
            ...menuOptions
        });
    } else {
        bot.sendMessage(chatId, menuText, menuOptions);
    }
}

async function showOwnerManageWarranty(chatId, messageId = null) {
    const claims = getAllWarrantyClaims();
    
    let menuText = `
🛡️ *KELOLA GARANSI*
━━━━━━━━━━━━━━━━━━━━━━━━━━
*Total Klaim:* ${claims.length}

`;
    
    claims.slice(0, 10).forEach((claim, index) => {
        menuText += `${index + 1}. ${claim.id}\n`;
        menuText += `   User: ${claim.userId}\n`;
        menuText += `   Panel: ${claim.panelId}\n`;
        menuText += `   Status: ${claim.status}\n`;
        menuText += `   Waktu: ${new Date(claim.createdAt).toLocaleDateString('id-ID')}\n\n`;
    });
    
    if (claims.length > 10) {
        menuText += `... dan ${claims.length - 10} klaim lainnya\n\n`;
    }

    const keyboard = [
        [
            { text: "✅ APPROVE", callback_data: "owner_approve_warranty" },
            { text: "❌ REJECT", callback_data: "owner_reject_warranty" }
        ],
        [
            { text: "🔄 REFRESH", callback_data: "owner_manage_warranty" },
            { text: "🔙 KEMBALI", callback_data: "owner_menu" }
        ]
    ];

    const menuOptions = {
        reply_markup: { inline_keyboard: keyboard },
        parse_mode: "Markdown"
    };

    if (messageId) {
        bot.editMessageText(menuText, {
            chat_id: chatId,
            message_id: messageId,
            ...menuOptions
        });
    } else {
        bot.sendMessage(chatId, menuText, menuOptions);
    }
}

async function showOwnerManageApps(chatId, messageId = null) {
    const apps = getAllApps();
    
    let menuText = `
📱 *KELOLA APPS*
━━━━━━━━━━━━━━━━━━━━━━━━━━
*Total Apps:* ${apps.length}

`;
    
    apps.forEach((app, index) => {
        menuText += `${index + 1}. ${app.name}\n`;
        menuText += `   Harga: Rp ${toRupiah(app.price)}\n`;
        menuText += `   Deskripsi: ${app.description}\n`;
        menuText += `   ID: ${app.id}\n\n`;
    });
    
    if (apps.length === 0) {
        menuText += `❌ *Belum ada apps*`;
    }

    const keyboard = [
        [
            { text: "➕ TAMBAH APP", callback_data: "owner_add_app" },
            { text: "🗑️ HAPUS APP", callback_data: "owner_delete_app" }
        ],
        [
            { text: "🔄 REFRESH", callback_data: "owner_manage_apps" },
            { text: "🔙 KEMBALI", callback_data: "owner_menu" }
        ]
    ];

    const menuOptions = {
        reply_markup: { inline_keyboard: keyboard },
        parse_mode: "Markdown"
    };

    if (messageId) {
        bot.editMessageText(menuText, {
            chat_id: chatId,
            message_id: messageId,
            ...menuOptions
        });
    } else {
        bot.sendMessage(chatId, menuText, menuOptions);
    }
}

async function showOwnerManageDocuments(chatId, messageId = null) {
    const documents = getAllDocuments();
    
    let menuText = `
💻 *KELOLA DOCUMENTS*
━━━━━━━━━━━━━━━━━━━━━━━━━━
*Total Documents:* ${documents.length}

`;
    
    documents.forEach((doc, index) => {
        menuText += `${index + 1}. ${doc.name}\n`;
        menuText += `   Harga: Rp ${toRupiah(doc.price)}\n`;
        menuText += `   Deskripsi: ${doc.description}\n`;
        menuText += `   ID: ${doc.id}\n\n`;
    });
    
    if (documents.length === 0) {
        menuText += `❌ *Belum ada documents*`;
    }

    const keyboard = [
        [
            { text: "➕ TAMBAH DOC", callback_data: "owner_add_document" },
            { text: "🗑️ HAPUS DOC", callback_data: "owner_delete_document" }
        ],
        [
            { text: "🔄 REFRESH", callback_data: "owner_manage_documents" },
            { text: "🔙 KEMBALI", callback_data: "owner_menu" }
        ]
    ];

    const menuOptions = {
        reply_markup: { inline_keyboard: keyboard },
        parse_mode: "Markdown"
    };

    if (messageId) {
        bot.editMessageText(menuText, {
            chat_id: chatId,
            message_id: messageId,
            ...menuOptions
        });
    } else {
        bot.sendMessage(chatId, menuText, menuOptions);
    }
}

// ==================== MY PANELS FUNCTION ====================
async function showMyPanels(chatId, userId, messageId = null) {
    const regularPanels = getUserPurchases(userId);
    const specialPanels = getUserSpecialPanels(userId);
    const allPanels = [...regularPanels, ...specialPanels];
    
    if (allPanels.length === 0) {
        const menuText = `\`\`\`Text  
📦 *PANEL SAYA*
━━━━━━━━━━━━━━━━━━━━━━━━━━
Anda belum memiliki panel.

🛒 *Beli panel sekarang!*
        \`\`\``.trim();

        const keyboard = [
            [{ text: "🛒 BELI PANEL", callback_data: "buy_panel" }],
            [{ text: "🔙 KEMBALI", callback_data: "main_menu" }]
        ];

        const menuOptions = {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: "Markdown"
        };

        if (messageId) {
            bot.editMessageText(menuText, {
                chat_id: chatId,
                message_id: messageId,
                ...menuOptions
            });
        } else {
            bot.sendMessage(chatId, menuText, menuOptions);
        }
    } else {
        let panelList = "\`\`\`Text  📦 *PANEL SAYA*\n━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n";
        
        allPanels.slice(0, 10).forEach((panel, index) => {
            const type = panel.panelType === 'regular' ? panel.ramSize.toUpperCase() : panel.panelType.toUpperCase().replace('_', ' ');
            const expiry = new Date(panel.warrantyExpiry).toLocaleDateString('id-ID');
            
            panelList += `${index + 1}. *${panel.username}*\n`;
            panelList += `   ▸ Tipe: ${type}\n`;
            panelList += `   ▸ Garansi: ${expiry}\n`;
            panelList += `   ▸ ID: ${panel.id}\n\n`;
        });
        
        if (allPanels.length > 10) {
            panelList += `... dan ${allPanels.length - 10} panel lainnya\n\n`;
        }
        
        panelList += "💡 *Klik panel untuk detail lebih lanjut*\`\`\`";

        const keyboard = [
            [{ text: "🔙 KEMBALI", callback_data: "main_menu" }]
        ];

        const menuOptions = {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: "Markdown"
        };

        if (messageId) {
            bot.editMessageText(panelList, {
                chat_id: chatId,
                message_id: messageId,
                ...menuOptions
            });
        } else {
            bot.sendMessage(chatId, panelList, menuOptions);
        }
    }
}

// ==================== HELP MENU ====================
async function showHelpMenu(chatId, messageId = null) {
    const menuText = `
\`\`\`Text  ℹ️ *BANTUAN & PANDUAN*
━━━━━━━━━━━━━━━━━━━━━━━━━━
📖 *Cara Beli Panel:*
1. Deposit saldo terlebih dahulu
2. Pilih menu 'Beli Panel'
3. Pilih RAM yang diinginkan
4. Masukkan username untuk panel
5. Panel otomatis dibuat

💼 *Jadi Reseller:*
• Beli paket reseller
• Bisa jual panel ke orang lain
• Harga jual bebas
• Limit harian sesuai paket

👑 *Special Panel:*
• Panel dengan fitur khusus
• Bisa buka reseller
• Akses lebih luas

📱 *Apps Premium:*
• Aplikasi premium siap pakai
• Auto delivery setelah pembayaran
• Garansi 100%

💻 *Script & Template:*
• Source code berkualitas
• Template premium
• Auto delivery setelah pembayaran

🛡️ *Garansi:*
• Garansi 15 hari untuk panel regular
• Klaim garansi via menu bantuan

📞 *Support:*
Hubungi admin jika ada masalah
    \`\`\``.trim();

    const keyboard = [
        [{ text: "🔙 KEMBALI", callback_data: "main_menu" }]
    ];

    const menuOptions = {
        reply_markup: { inline_keyboard: keyboard },
        parse_mode: "Markdown"
    };

    if (messageId) {
        bot.editMessageText(menuText, {
            chat_id: chatId,
            message_id: messageId,
            ...menuOptions
        });
    } else {
        bot.sendMessage(chatId, menuText, menuOptions);
    }
}

// ==================== UPDATE RESELLER DASHBOARD ====================
async function showResellerDashboard(chatId, userId, messageId = null) {
    const resellerInfo = getResellerInfo(userId);
    if (!resellerInfo) {
        return bot.sendMessage(chatId, "❌ Anda bukan reseller!");
    }

    const statsPath = resellerStatsPath;
    let stats = {};
    
    try {
        stats = JSON.parse(fs.readFileSync(statsPath));
    } catch (e) {
        stats = {};
    }

    const userStats = stats[userId] || {
        total_sales: 0,
        total_income: 0,
        daily_sales: {}
    };

    const today = moment().format('YYYY-MM-DD');
    const todaySales = userStats.daily_sales[today] || 0;
    const remainingLimit = resellerInfo.daily_limit - todaySales;

    const menuText = `
\`\`\`Javascript  📊 *DASHBOARD RESELLER*
━━━━━━━━━━━━━━━━━━━━━━━━━━
💼 *Paket:* ${resellerInfo.package.toUpperCase()}
📈 *Total Penjualan:* ${userStats.total_sales} panel
💰 *Total Modal Keluar:* Rp ${toRupiah(userStats.total_income)}

📅 *Hari Ini:*
🛒 *Terjual:* ${todaySales} panel
📊 *Sisa Limit:* ${remainingLimit} panel
⏰ *Reset:* Besok 00:00

💡 *Tips:* Atur harga jual yang kompetitif!
    \`\`\``.trim();

    const keyboard = [
        [
            { text: "🛒 JUAL PANEL", callback_data: "sell_panel" },
            { text: "🔄 REFRESH", callback_data: "reseller_dashboard" }
        ],
        [
            { text: "🔙 KEMBALI", callback_data: "reseller_menu" }
        ]
    ];

    const menuOptions = {
        reply_markup: { inline_keyboard: keyboard },
        parse_mode: "Markdown"
    };

    if (messageId) {
        bot.editMessageText(menuText, {
            chat_id: chatId,
            message_id: messageId,
            ...menuOptions
        });
    } else {
        bot.sendMessage(chatId, menuText, menuOptions);
    }
}

// ==================== BOT COMMANDS ====================
bot.onText(/\/start/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const username = msg.from.username;
    
    // Show loading animation
    await showLoadingAnimation(chatId, userId);
    
    // Check if user is new and send notification
    if (!hasUserStarted(userId)) {
        markUserStarted(userId);
        await sendNewUserNotification(userId, username);
    }
    
    // Show main menu
    await showMainMenu(chatId, userId);
});

bot.onText(/\/menu/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    await showMainMenu(chatId, userId);
});

// ==================== CALLBACK QUERY HANDLER ====================
bot.on('callback_query', async (callbackQuery) => {
    const msg = callbackQuery.message;
    const chatId = msg.chat.id;
    const userId = callbackQuery.from.id;
    const data = callbackQuery.data;
    const messageId = msg.message_id;

    try {
        // Handle deposit cancellation
        if (data === 'bataldeposit') {
            if (activeDeposit[userId]) {
                clearTimeout(activeDeposit[userId].timeout);
                delete activeDeposit[userId];
                await bot.deleteMessage(chatId, messageId);
                await bot.sendMessage(chatId, "❌ Deposit dibatalkan.");
            } else {
                await bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Tidak ada deposit aktif!" });
            }
            return;
        }

        // Handle QRIS cancellation
        if (data.startsWith('cancel_qris_')) {
            const reff = data.replace('cancel_qris_', '');
            if (activeDirectQRIS[reff]) {
                clearTimeout(activeDirectQRIS[reff].timeout);
                delete activeDirectQRIS[reff];
                await bot.deleteMessage(chatId, messageId);
                await bot.sendMessage(chatId, "❌ Pembayaran dibatalkan.");
            } else {
                await bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Tidak ada pembayaran aktif!" });
            }
            return;
        }

        // Main menu navigation
        switch (data) {
            case 'main_menu':
                await showMainMenu(chatId, userId, messageId);
                break;
            case 'buy_panel':
                await showPanelMenu(chatId, messageId);
                break;
            case 'reseller_menu':
                await showResellerMenu(chatId, userId, messageId);
                break;
            case 'special_panel_menu':
                await showSpecialPanelMenu(chatId, userId, messageId);
                break;
            case 'apps_menu':
                await showAppsMenu(chatId, messageId);
                break;
            case 'documents_menu':
                await showDocumentsMenu(chatId, messageId);
                break;
            case 'deposit_menu':
                await showDepositMenu(chatId, userId, messageId);
                break;
            case 'owner_menu':
                if (!isOwner(userId)) {
                    return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Akses ditolak!" });
                }
                await showOwnerMenu(chatId, messageId);
                break;
            case 'my_panels':
                await showMyPanels(chatId, userId, messageId);
                break;
            case 'help_menu':
                await showHelpMenu(chatId, messageId);
                break;
            case 'sell_panel':
                await showSellPanelMenu(chatId, userId, messageId);
                break;
            case 'reseller_dashboard':
                await showResellerDashboard(chatId, userId, messageId);
                break;

            // Owner management menus
            case 'owner_delete_app':
            if (!isOwner(userId)) {
                return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Akses ditolak!" });
            }
            await showDeleteAppMenu(chatId, messageId);
            break;

        case 'owner_delete_document':
            if (!isOwner(userId)) {
                return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Akses ditolak!" });
            }
            await showDeleteDocumentMenu(chatId, messageId);
            break;
            case 'owner_manage_users':
                if (!isOwner(userId)) {
                    return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Akses ditolak!" });
                }
                await showOwnerManageUsers(chatId, messageId);
                break;
            case 'owner_manage_orders':
                if (!isOwner(userId)) {
                    return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Akses ditolak!" });
                }
                await showOwnerManageOrders(chatId, messageId);
                break;
            case 'owner_manage_warranty':
                if (!isOwner(userId)) {
                    return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Akses ditolak!" });
                }
                await showOwnerManageWarranty(chatId, messageId);
                break;
            case 'owner_manage_apps':
                if (!isOwner(userId)) {
                    return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Akses ditolak!" });
                }
                await showOwnerManageApps(chatId, messageId);
                break;
            case 'owner_manage_documents':
                if (!isOwner(userId)) {
                    return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Akses ditolak!" });
                }
                await showOwnerManageDocuments(chatId, messageId);
                break;

            // Panel purchase
            case 'buy_5gb':
            case 'buy_6gb':
            case 'buy_7gb':
            case 'buy_8gb':
            case 'buy_9gb':
            case 'buy_10gb':
            case 'buy_unli':
                await handlePanelPurchase(chatId, userId, data.replace('buy_', ''), messageId);
                break;

            // Reseller purchase
            case 'buy_reseller':
                await handleResellerPurchaseMenu(chatId, userId, messageId);
                break;
case 'special_admin':
case 'special_reseller':
case 'special_owner':
case 'special_pt':
case 'special_tk':
    try {
        await handleSpecialPanelPurchase(chatId, userId, data.replace('special_', ''), messageId);
    } catch (error) {
        console.error("❌ Special panel purchase error:", error);
        await bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Terjadi kesalahan, coba lagi!" });
    }
    break;
    // Refresh handlers untuk berbagai menu
        case 'owner_user_stats':
            if (!isOwner(userId)) {
                return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Akses ditolak!" });
            }
            await showOwnerManageUsers(chatId, messageId);
            break;

        case 'owner_order_stats':
            if (!isOwner(userId)) {
                return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Akses ditolak!" });
            }
            await showOwnerManageOrders(chatId, messageId);
            break;

        case 'owner_approve_warranty':
            if (!isOwner(userId)) {
                return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Akses ditolak!" });
            }
            await showOwnerManageWarranty(chatId, messageId);
            adminChatSessions[userId] = 'waiting_approve_warranty';
            await bot.sendMessage(chatId, "🛡️ Masukkan ID klaim garansi yang ingin di-approve:");
            break;
            case 'config_menu':
    if (!isOwner(userId)) {
        return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Akses ditolak!" });
    }
    await showConfigMenu(chatId, messageId);
    break;

case 'config_reload':
    if (!isOwner(userId)) {
        return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Akses ditolak!" });
    }
    await reloadConfig(chatId, messageId);
    break;

case 'config_bot_token':
case 'config_domain':
case 'config_plta':
case 'config_pltc':
case 'config_nomor_dana':
case 'config_nama_ewallet':
case 'config_api_atlantic':
case 'config_bot_name':
case 'config_owner_ids':
case 'config_channel':
    if (!isOwner(userId)) {
        return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Akses ditolak!" });
    }
    await handleConfigChange(chatId, data, messageId);
    break;

        case 'owner_reject_warranty':
            if (!isOwner(userId)) {
                return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Akses ditolak!" });
            }
            await showOwnerManageWarranty(chatId, messageId);
            adminChatSessions[userId] = 'waiting_reject_warranty';
            await bot.sendMessage(chatId, "🛡️ Masukkan ID klaim garansi yang ingin di-reject:");
            break;
            // Apps purchase
            case data.match(/^buy_app_/)?.input:
                const appId = data.replace('buy_app_', '');
                await handleAppPurchase(chatId, userId, appId, messageId);
                break;

            // Documents purchase
            case data.match(/^buy_doc_/)?.input:
                const docId = data.replace('buy_doc_', '');
                await handleDocumentPurchase(chatId, userId, docId, messageId);
                break;
            // Tambahkan di bagian callback query handler
            case data.match(/^copy_/)?.input:
                const passwordToCopy = data.replace('copy_', '');
                await bot.answerCallbackQuery(callbackQuery.id, { 
                text: `Password disalin: ${passwordToCopy}`,
                show_alert: true 
                });
                break;
            case data.match(/^confirm_delete_app_/)?.input:
            if (!isOwner(userId)) {
                return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Akses ditolak!" });
            }
            const appIdToConfirm = data.replace('confirm_delete_app_', '');
            await confirmDeleteApp(chatId, appIdToConfirm, messageId);
            break;

        case data.match(/^confirm_delete_doc_/)?.input:
            if (!isOwner(userId)) {
                return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Akses ditolak!" });
            }
            const docIdToConfirm = data.replace('confirm_delete_doc_', '');
            await confirmDeleteDocument(chatId, docIdToConfirm, messageId);
            break;

        case data.match(/^execute_delete_app_/)?.input:
            if (!isOwner(userId)) {
                return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Akses ditolak!" });
            }
            const appIdToDelete = data.replace('execute_delete_app_', '');
            await executeDeleteApp(chatId, appIdToDelete, messageId);
            break;

        case data.match(/^execute_delete_doc_/)?.input:
            if (!isOwner(userId)) {
                return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Akses ditolak!" });
            }
            const docIdToDelete = data.replace('execute_delete_doc_', '');
            await executeDeleteDocument(chatId, docIdToDelete, messageId);
            break;

            // Sell panel (reseller)
            case 'sell_5gb':
            case 'sell_6gb':
            case 'sell_7gb':
            case 'sell_8gb':
            case 'sell_9gb':
            case 'sell_10gb':
            case 'sell_unli':
                await handleSellPanel(chatId, userId, data.replace('sell_', ''), messageId);
                break;

            // Deposit amounts
            case 'deposit_5000':
            case 'deposit_10000':
            case 'deposit_20000':
            case 'deposit_50000':
            case 'deposit_100000':
            case 'deposit_200000':
                const amount = parseInt(data.replace('deposit_', ''));
                await processDeposit(chatId, userId, amount);
                break;

            case 'deposit_custom':
                userChatSessions[userId] = 'waiting_deposit_amount';
                await bot.editMessageText(
                    "💰 *DEPOSIT SALDO*\n\nMasukkan nominal deposit (minimal Rp 5,000):",
                    {
                        chat_id: chatId,
                        message_id: messageId,
                        parse_mode: "Markdown"
                    }
                );
                break;

            // QRIS Payment handlers
            case 'qris_5gb':
            case 'qris_6gb':
            case 'qris_7gb':
            case 'qris_8gb':
            case 'qris_9gb':
            case 'qris_10gb':
            case 'qris_unli':
                const ramSize = data.replace('qris_', '');
                const harga = config.PANEL_PRICES[ramSize];
                await processDirectQRIS(chatId, userId, 'panel', { ramSize }, harga);
                break;

            case 'qris_reseller_reseller':
                const resellerHarga = config.RESELLER_PRICES.reseller;
                await processDirectQRIS(chatId, userId, 'reseller', { packageType: 'reseller' }, resellerHarga);
                break;

            case 'qris_special_admin_panel':
            case 'qris_special_reseller_panel':
            case 'qris_special_owner_panel':
            case 'qris_special_pt_panel':
            case 'qris_special_tk_panel':
    const specialType = data.replace('qris_special_', '');
    const specialHarga = config.SPECIAL_PANEL_PRICES[specialType];
    try {
        await processDirectQRIS(chatId, userId, 'special_panel', { panelType: specialType }, specialHarga);
    } catch (error) {
        console.error("❌ QRIS special panel error:", error);
        await bot.sendMessage(chatId, "❌ Gagal memproses pembayaran. Silakan coba lagi.");
    }
    break;

            case data.match(/^qris_app_/)?.input:
                const qrisAppId = data.replace('qris_app_', '');
                const app = getAllApps().find(a => a.id === qrisAppId);
                if (app) {
                    await processDirectQRIS(chatId, userId, 'app', { appId: qrisAppId, appName: app.name }, app.price);
                }
                break;

            case data.match(/^qris_doc_/)?.input:
                const qrisDocId = data.replace('qris_doc_', '');
                const doc = getAllDocuments().find(d => d.id === qrisDocId);
                if (doc) {
                    await processDirectQRIS(chatId, userId, 'document', { docId: qrisDocId, docName: doc.name }, doc.price);
                }
                break;

            // Owner functions
            case 'owner_addsaldo':
                if (!isOwner(userId)) {
                    return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Akses ditolak!" });
                }
                adminChatSessions[userId] = 'waiting_addsaldo_user';
                await bot.editMessageText(
                    "💰 *TAMBAH SALDO USER*\n\nMasukkan User ID atau username (@username) user:",
                    {
                        chat_id: chatId,
                        message_id: messageId,
                        parse_mode: "Markdown"
                    }
                );
                break;

            case 'owner_broadcast':
                if (!isOwner(userId)) {
                    return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Akses ditolak!" });
                }
                adminChatSessions[userId] = 'waiting_broadcast_message';
                await bot.editMessageText(
                    "📢 *BROADCAST MESSAGE*\n\nMasukkan pesan yang ingin dikirim ke semua user:",
                    {
                        chat_id: chatId,
                        message_id: messageId,
                        parse_mode: "Markdown"
                    }
                );
                break;

            case 'owner_add_app':
                if (!isOwner(userId)) {
                    return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Akses ditolak!" });
                }
                adminChatSessions[userId] = 'waiting_add_app_name';
                await bot.editMessageText(
                    "📱 *TAMBAH APPS*\n\nMasukkan nama aplikasi:",
                    {
                        chat_id: chatId,
                        message_id: messageId,
                        parse_mode: "Markdown"
                    }
                );
                break;

            case 'owner_add_document':
                if (!isOwner(userId)) {
                    return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Akses ditolak!" });
                }
                adminChatSessions[userId] = 'waiting_add_doc_name';
                await bot.editMessageText(
                    "💻 *TAMBAH DOCUMENT*\n\nMasukkan nama document:",
                    {
                        chat_id: chatId,
                        message_id: messageId,
                        parse_mode: "Markdown"
                    }
                );
                break;

            default:
                await bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Perintah tidak dikenali!" });
        }

        await bot.answerCallbackQuery(callbackQuery.id);
        
     // Handle egg type selection - NEW VERSION
        if (data.startsWith('egg_')) {
            const [_, eggType, panelCategory] = data.split('_');
            const purchaseData = pendingPurchases[userId];
            
            if (!purchaseData) {
                await bot.answerCallbackQuery(callbackQuery.id, {
                    text: "❌ Data pembelian tidak ditemukan",
                    show_alert: true
                });
                return;
            }

            purchaseData.eggType = eggType;

            // Start panel creation process
            await bot.deleteMessage(chatId, messageId);
            
            const processingMsg = await bot.sendMessage(chatId, 
                `\`\`\`Javascript 🔄 *MEMPROSES PEMBUATAN PANEL...*\n\n` +
                `📦 *Detail Panel:*\n` +
                `• 👤 Username: ${purchaseData.username}\n` +
                `• 💾 ${purchaseData.panelType ? 'Tipe' : 'RAM'}: ${purchaseData.panelType ? purchaseData.panelType.toUpperCase().replace('_', ' ') : purchaseData.ramSize.toUpperCase()}\n` +
                `• 🥚 Egg: ${eggType.toUpperCase()}\n` +
                `• 💰 Harga: ${purchaseData.harga === 0 ? 'FREE (OWNER)' : 'Rp ' + toRupiah(purchaseData.harga)}\n` +
                `• 💳 Metode: ${purchaseData.paymentMethod.toUpperCase()}\n\n` +
                `⏳ Sedang membuat panel...\`\`\``,
                { parse_mode: "Markdown" }
            );

            // Start panel creation
            await processPanelCreationWithData(chatId, userId, processingMsg.message_id);
            
            await bot.answerCallbackQuery(callbackQuery.id, {
                text: `✅ ${eggType.toUpperCase()} dipilih, memproses pembuatan panel...`,
                show_alert: false
            });
            return;
        }
        
        if (data.startsWith('reseller_egg_')) {
            const eggType = data.replace('reseller_egg_', '');
            const sellData = resellerSellSessions[userId];
            
            if (!sellData) {
                await bot.answerCallbackQuery(callbackQuery.id, {
                    text: "❌ Data penjualan tidak ditemukan",
                    show_alert: true
                });
                return;
            }

            sellData.eggType = eggType;

            // Start panel creation process untuk customer
            await bot.deleteMessage(chatId, messageId);
            
            const processingMsg = await bot.sendMessage(chatId, 
                `\`\`\`Javascript 🔄 *MEMPROSES PEMBUATAN PANEL CUSTOMER...*\n\n` +
                `📦 *Detail Panel Customer:*\n` +
                `• 👤 Username: ${sellData.username}\n` +
                `• 💾 RAM: ${sellData.ramSize.toUpperCase()}\n` +
                `• 🥚 Egg: ${eggType.toUpperCase()}\n` +
                `• 💰 Modal: Rp ${toRupiah(sellData.modalPrice)}\n\n` +
                `⏳ Sedang membuat panel...\`\`\``,
                { parse_mode: "Markdown" }
            );

            // Start panel creation untuk customer
            await processResellerPanelCreation(chatId, userId, processingMsg.message_id);
            
            await bot.answerCallbackQuery(callbackQuery.id, {
                text: `✅ ${eggType.toUpperCase()} dipilih, memproses pembuatan panel...`,
                show_alert: false
            });
            return;
        }

    } catch (error) {
        console.error("❌ Callback query error:", error);
        await bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Terjadi kesalahan!" });
    }
});


// ==================== FIXED RESELLER PANEL CREATION ====================
async function processResellerPanelCreation(chatId, userId, processingMsgId = null) {
    const sellData = resellerSellSessions[userId];
    if (!sellData) {
        if (processingMsgId) {
            await bot.editMessageText("❌ Data penjualan tidak ditemukan.", {
                chat_id: chatId,
                message_id: processingMsgId
            });
        }
        return;
    }

    try {
        // Create panel untuk customer
        const result = await createPterodactylPanel(sellData.username, sellData.ramSize, sellData.eggType || 'nodejs');

        if (!result.success) {
            const errorMsg = `❌ Gagal membuat panel customer: ${result.error}`;
            if (processingMsgId) {
                await bot.editMessageText(errorMsg, {
                    chat_id: chatId,
                    message_id: processingMsgId
                });
            } else {
                await bot.sendMessage(chatId, errorMsg);
            }
            delete resellerSellSessions[userId];
            return;
        }

        const panelData = result.data;
        
        // Update reseller stats
        const statsPath = resellerStatsPath;
        let stats = {};
        
        try {
            stats = JSON.parse(fs.readFileSync(statsPath));
        } catch (e) {
            stats = {};
        }

        if (!stats[userId]) {
            stats[userId] = {
                total_sales: 0,
                total_income: 0,
                daily_sales: {}
            };
        }

        const today = moment().format('YYYY-MM-DD');
        
        stats[userId].total_sales += 1;
        stats[userId].total_income += sellData.modalPrice;
        stats[userId].daily_sales[today] = (stats[userId].daily_sales[today] || 0) + 1;
        
        fs.writeFileSync(statsPath, JSON.stringify(stats, null, 2));

        // Deduct reseller balance (modal)
        const currentSaldo = getUserSaldo(userId);
        setUserSaldo(userId, currentSaldo - sellData.modalPrice);

        // Save purchase record (customer gets the panel)
        const purchaseRecord = {
            id: `PANEL-${Math.floor(100000 + Math.random() * 900000)}`,
            userId: userId, // Reseller ID sebagai pemilik transaksi
            customerUsername: sellData.username,
            username: sellData.username,
            password: panelData.password,
            email: panelData.email,
            ramSize: sellData.ramSize,
            eggType: sellData.eggType || 'nodejs',
            panelType: 'reseller_sold',
            price: 0, // Gratis untuk customer, reseller yang bayar modal
            paymentMethod: 'reseller',
            serverId: panelData.serverId,
            serverName: panelData.serverName,
            domain: panelData.domain,
            createdAt: new Date().toISOString(),
            warrantyExpiry: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString(),
            resellerId: userId,
            resellerPrice: sellData.modalPrice
        };

        savePanelPurchase(purchaseRecord);

        if (processingMsgId) {
            await bot.deleteMessage(chatId, processingMsgId);
        }

        // Send success message to reseller
        await bot.sendMessage(chatId,
            `\`\`\`Javascript  ✅ *PANEL BERHASIL DIBUAT UNTUK CUSTOMER!*\n\n` +
            `📦 *Detail Panel:*\n` +
            `• 👤 Username: ${sellData.username}\n` +
            `• 💾 RAM: ${sellData.ramSize.toUpperCase()}\n` +
            `• 🥚 Egg: ${(sellData.eggType || 'nodejs').toUpperCase()}\n` +
            `• 💰 Modal: Rp ${toRupiah(sellData.modalPrice)}\n` +
            `• 💎 Saldo Baru: Rp ${toRupiah(currentSaldo - sellData.modalPrice)}\n\n` +
            `📊 *Statistik Penjualan:*\n` +
            `• Total: ${stats[userId].total_sales} panel\n` +
            `• Hari Ini: ${stats[userId].daily_sales[today]} panel\n` +
            `• Total Income: Rp ${toRupiah(stats[userId].total_income)}\`\`\``,
            { parse_mode: "Markdown" }
        );

        // Send panel info to reseller (untuk diteruskan ke customer)
        const panelInfo = `\`\`\`Javascript  
🔐 *INFORMASI PANEL CUSTOMER*

▸ Username: ${sellData.username}
▸ Password: ${panelData.password}
▸ Email: ${panelData.email}
▸ Domain: ${panelData.domain}
▸ RAM: ${sellData.ramSize.toUpperCase()}
▸ Egg: ${(sellData.eggType || 'nodejs').toUpperCase()}

⚠️ *Forward informasi ini ke customer!*
⏰ *Garansi 15 hari*
        \`\`\``.trim();

        await bot.sendMessage(chatId, panelInfo, {
            parse_mode: "Markdown",
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: "🌐 Domain", url: panelData.domain },
                        { text: "🔑 Salin Password", callback_data: `copy_${panelData.password}` }
                    ],
                    [
                        { text: "🛒 JUAL LAGI", callback_data: "sell_panel" },
                        { text: "📊 DASHBOARD", callback_data: "reseller_dashboard" }
                    ]
                ]
            }
        });

        // Kirim notifikasi ke owner tentang penjualan reseller
        try {
            const resellerInfo = await bot.getChat(userId);
            const resellerName = resellerInfo.username ? `@${resellerInfo.username}` : `User ID: ${userId}`;
            
            await bot.sendMessage(config.OWNER_ID,
                `\`\`\`Javascript  💼 *RESELLER SALE!*\n\n` +
                `👤 *Reseller:* ${resellerName}\n` +
                `👥 *Customer:* ${sellData.username}\n` +
                `📦 *RAM:* ${sellData.ramSize.toUpperCase()}\n` +
                `🥚 *Egg:* ${(sellData.eggType || 'nodejs').toUpperCase()}\n` +
                `💰 *Modal:* Rp ${toRupiah(sellData.modalPrice)}\n` +
                `⏰ *Waktu:* ${new Date().toLocaleString('id-ID')}\`\`\``,
                { parse_mode: "Markdown" }
            );
        } catch (notifError) {
            console.error("❌ Gagal kirim notifikasi reseller sale:", notifError);
        }

        delete resellerSellSessions[userId];

    } catch (error) {
        console.error("❌ Reseller panel creation error:", error);
        const errorMsg = "❌ Gagal membuat panel customer. Silakan coba lagi.";
        
        if (processingMsgId) {
            try {
                await bot.editMessageText(errorMsg, {
                    chat_id: chatId,
                    message_id: processingMsgId
                });
            } catch (editError) {
                await bot.sendMessage(chatId, errorMsg);
            }
        } else {
            await bot.sendMessage(chatId, errorMsg);
        }
        delete resellerSellSessions[userId];
    }
}

// ==================== FIXED PANEL CREATION PROCESS ====================
async function processPanelCreationWithData(chatId, userId, processingMsgId = null) {
    const purchaseData = pendingPurchases[userId];
    if (!purchaseData) {
        if (processingMsgId) {
            await bot.editMessageText("❌ Data pembelian tidak ditemukan.", {
                chat_id: chatId,
                message_id: processingMsgId
            });
        }
        return;
    }

    try {
        let result;
        
        if (purchaseData.panelType) {
            // Special panel creation
            result = await createSpecialPanel(purchaseData.username, purchaseData.panelType);
        } else {
            // Regular panel creation dengan egg type
            result = await createPterodactylPanel(purchaseData.username, purchaseData.ramSize, purchaseData.eggType || 'nodejs');
        }

        if (!result.success) {
            const errorMsg = `❌ Gagal membuat panel: ${result.error}`;
            if (processingMsgId) {
                await bot.editMessageText(errorMsg, {
                    chat_id: chatId,
                    message_id: processingMsgId
                });
            } else {
                await bot.sendMessage(chatId, errorMsg);
            }
            delete pendingPurchases[userId];
            return;
        }

        const panelData = result.data;
        
        // Save purchase record
        const purchaseRecord = {
            id: `PANEL-${Math.floor(100000 + Math.random() * 900000)}`,
            userId: userId,
            username: purchaseData.username,
            password: panelData.password,
            email: panelData.email,
            ramSize: purchaseData.ramSize || 'special',
            panelType: purchaseData.panelType || 'regular',
            eggType: purchaseData.eggType || 'nodejs',
            price: purchaseData.harga || 0,
            paymentMethod: purchaseData.paymentMethod || 'saldo',
            serverId: panelData.serverId || panelData.id,
            serverName: panelData.serverName || purchaseData.username,
            domain: panelData.domain,
            createdAt: new Date().toISOString(),
            warrantyExpiry: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString()
        };

        if (purchaseData.panelType) {
            saveSpecialPanel(purchaseRecord);
        } else {
            savePanelPurchase(purchaseRecord);
        }

        // Send panel info to user
        let caption = '';
        if (purchaseData.panelType) {
            caption = `<b>🔐 SUKSES CREATED ${purchaseData.panelType.toUpperCase().replace('_', ' ')}!</b>

▸ <b>ID User:</b> <code>${panelData.id}</code>
▸ <b>Username:</b> <code>${purchaseData.username}</code>
▸ <b>Email:</b> <code>${panelData.email}</code>
▸ <b>Password:</b> <code>${panelData.password}</code>
▸ <b>Domain:</b> <code>${panelData.domain}</code>
▸ <b>Tipe:</b> <code>${purchaseData.panelType.toUpperCase()}</code>
${purchaseData.eggType ? `▸ <b>Egg:</b> <code>${purchaseData.eggType.toUpperCase()}</code>` : ''}

⚠️ <b>Rules Panel:</b>
▸ No Rusuh Panel!
▸ Simpan data akun
▸ No Share Free!`;
        } else {
            caption = `<b>🔐 SUKSES CREATED PANEL!</b>

▸ <b>Name:</b> <code>${purchaseData.username}</code>
▸ <b>Email:</b> <code>${panelData.email}</code>
▸ <b>ID:</b> <code>${panelData.id}</code>
▸ <b>RAM:</b> <code>${purchaseData.ramSize.toUpperCase()}</code>
▸ <b>Password:</b> <code>${panelData.password}</code>
▸ <b>Domain:</b> <code>${panelData.domain}</code>
▸ <b>Egg:</b> <code>${(purchaseData.eggType || 'nodejs').toUpperCase()}</code>

⚠️ <b>Rules Panel:</b>
▸ Sensor domain
▸ Simpan data akun
▸ Garansi 15 hari`;
        }

        if (processingMsgId) {
            await bot.deleteMessage(chatId, processingMsgId);
        }

        await bot.sendMessage(chatId, caption, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: "🌐 Domain", url: panelData.domain },
                        { text: "🔑 Salin Password", callback_data: `copy_${panelData.password}` }
                    ]
                ]
            }
        });

        // Send notification
        const userInfo = await bot.getChat(userId);
        const panelType = purchaseData.panelType ? purchaseData.panelType.toUpperCase() : purchaseData.ramSize.toUpperCase();
        await sendPanelNotification(userId, panelType, userInfo.username, purchaseData.harga || 0);

        delete pendingPurchases[userId];

    } catch (error) {
        console.error("❌ Panel creation error:", error);
        const errorMsg = "❌ Gagal membuat panel. Silakan coba lagi.";
        
        if (processingMsgId) {
            try {
                await bot.editMessageText(errorMsg, {
                    chat_id: chatId,
                    message_id: processingMsgId
                });
            } catch (editError) {
                await bot.sendMessage(chatId, errorMsg);
            }
        } else {
            await bot.sendMessage(chatId, errorMsg);
        }
        delete pendingPurchases[userId];
    }
}

// ==================== PURCHASE HANDLERS ====================
async function handlePanelPurchase(chatId, userId, ramSize, messageId) {
    const harga = config.PANEL_PRICES[ramSize];
    const saldo = getUserSaldo(userId);
    
    if (isOwner(userId)) {
        // Owner gets free panels
        pendingPurchases[userId] = { ramSize, harga: 0, paymentMethod: 'owner_free' };
        
        await bot.editMessageText(
            `\`\`\`Javascript  👑 *OWNER FREE PURCHASE*\n\n` +
            `📦 *Detail Panel:*\n` +
            `• 💾 RAM: ${ramSize.toUpperCase()}\n` +
            `• 💰 Harga: FREE\n\n\`\`\`` +
            `📝 *Silakan masukkan username untuk panel Anda:*`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: "Markdown"
            }
        );
        
        pendingUsername[userId] = true;
    } else if (saldo >= harga) {
        // Deduct balance and proceed
        setUserSaldo(userId, saldo - harga);
        pendingPurchases[userId] = { ramSize, harga, paymentMethod: 'saldo' };
        
        await bot.editMessageText(
            `\`\`\`Javascript  ✅ *PEMBAYARAN BERHASIL!*\n\n` +
            `💰 *Dibayar:* Rp ${toRupiah(harga)}\n` +
            `📦 *RAM:* ${ramSize.toUpperCase()}\n` +
            `💎 *Saldo Baru:* Rp ${toRupiah(saldo - harga)}\n\n\`\`\`` +
            `📝 *Silakan masukkan username untuk panel Anda:*`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: "Markdown"
            }
        );
        
        pendingUsername[userId] = true;
    } else {
        // Insufficient balance - show payment options
        await bot.editMessageText(
            `\`\`\`Javascript  🛒 *BELI PANEL ${ramSize.toUpperCase()}*\n\n` +
            `💰 *Harga:* Rp ${toRupiah(harga)}\n` +
            `💎 *Saldo Anda:* Rp ${toRupiah(saldo)}\n\n` +
            `❌ *Saldo tidak cukup!*\n\n\`\`\`` +
            `*Pilih metode pembayaran:*`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: "Markdown",
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: "💳 BAYAR VIA QRIS", callback_data: `qris_${ramSize}` },
                            { text: "💰 DEPOSIT DULU", callback_data: "deposit_menu" }
                        ],
                        [
                            { text: "🔙 KEMBALI", callback_data: "buy_panel" }
                        ]
                    ]
                }
            }
        );
    }
}

async function handleResellerPurchaseMenu(chatId, userId, messageId) {
    const packageType = 'reseller';
    const harga = config.RESELLER_PRICES[packageType];
    const saldo = getUserSaldo(userId);
    
    if (saldo >= harga) {
        setUserSaldo(userId, saldo - harga);
        await handleResellerPurchase(chatId, userId, packageType);
    } else {
        await bot.editMessageText(
            `\`\`\`Javascript  💼 *BELI PAKET RESELLER*\n\n` +
            `💰 *Harga:* Rp ${toRupiah(harga)}\n` +
            `💎 *Saldo Anda:* Rp ${toRupiah(saldo)}\n\n` +
            `❌ *Saldo tidak cukup!*\n\n\`\`\`` +
            `*Pilih metode pembayaran:*`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: "Markdown",
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: "💳 BAYAR VIA QRIS", callback_data: `qris_reseller_${packageType}` },
                            { text: "💰 DEPOSIT DULU", callback_data: "deposit_menu" }
                        ],
                        [
                            { text: "🔙 KEMBALI", callback_data: "reseller_menu" }
                        ]
                    ]
                }
            }
        );
    }
}

// ==================== SPECIAL PANEL PURCHASE HANDLER ====================
async function handleSpecialPanelPurchase(chatId, userId, panelType, messageId) {
    const fullPanelType = panelType + '_panel';
    const harga = config.SPECIAL_PANEL_PRICES[fullPanelType];
    const saldo = getUserSaldo(userId);
    
    if (isOwner(userId)) {
        // Owner gets free special panels
        pendingPurchases[userId] = { panelType: fullPanelType, harga: 0, paymentMethod: 'owner_free' };
        
        try {
            await bot.editMessageText(
                `\`\`\`Javascript  👑 *OWNER FREE PURCHASE*\n\n` +
                `📦 *Detail Panel:*\n` +
                `• 💾 Tipe: ${fullPanelType.toUpperCase().replace('_', ' ')}\n` +
                `• 💰 Harga: FREE\n\n\`\`\`` +
                `📝 Silakan masukkan username untuk panel Anda:`,
                {
                    chat_id: chatId,
                    message_id: messageId,
                    parse_mode: "Markdown"
                }
            );
            
            pendingUsername[userId] = true;
        } catch (error) {
            console.error("❌ Error edit message:", error);
            // Fallback: send new message
            await bot.sendMessage(chatId,
                `\`\`\`Javascript  👑 *OWNER FREE PURCHASE*\n\n` +
                `📦 *Detail Panel:*\n` +
                `• 💾 Tipe: ${fullPanelType.toUpperCase().replace('_', ' ')}\n` +
                `• 💰 Harga: FREE\n\n\`\`\`` +
                `📝 Silakan masukkan username untuk panel Anda:`,
                { parse_mode: "Markdown" }
            );
            pendingUsername[userId] = true;
        }
    } else if (saldo >= harga) {
        setUserSaldo(userId, saldo - harga);
        pendingPurchases[userId] = { panelType: fullPanelType, harga, paymentMethod: 'saldo' };
        
        try {
            await bot.editMessageText(
                `\`\`\`Javascript  ✅ *PEMBAYARAN BERHASIL\\!*\n\n` +
                `💰 *Dibayar:* Rp ${toRupiah(harga)}\n` +
                `🎯 *Tipe:* ${fullPanelType.toUpperCase().replace('_', ' ')}\n` +
                `💎 *Saldo Baru:* Rp ${toRupiah(saldo - harga)}\n\n\`\`\`` +
                `📝 Silakan masukkan username untuk panel Anda:`,
                {
                    chat_id: chatId,
                    message_id: messageId,
                    parse_mode: "Markdown"
                }
            );
            
            pendingUsername[userId] = true;
        } catch (error) {
            console.error("❌ Error edit message:", error);
            // Fallback: send new message
            await bot.sendMessage(chatId,
                `\`\`\`Javascript  ✅ *PEMBAYARAN BERHASIL!*\n\n` +
                `💰 *Dibayar:* Rp ${toRupiah(harga)}\n` +
                `🎯 *Tipe:* ${fullPanelType.toUpperCase().replace('_', ' ')}\n` +
                `💎 *Saldo Baru:* Rp ${toRupiah(saldo - harga)}\n\n\`\`\`` +
                `📝 Silakan masukkan username untuk panel Anda:`,
                { parse_mode: "Markdown" }
            );
            pendingUsername[userId] = true;
        }
    } else {
            await bot.editMessageText(
                `\`\`\`Javascript  👑 *BELI SPECIAL PANEL*\n\n` +
                `🎯 *Tipe:* ${fullPanelType.toUpperCase().replace('_', ' ')}\n` +
                `💰 *Harga:* Rp ${toRupiah(harga)}\n` +
                `💎 *Saldo Anda:* Rp ${toRupiah(saldo)}\n\n` +
                `❌ *Saldo tidak cukup\\!*\n\n` +
                `*Pilih metode pembayaran:*\`\`\``,
                {
                    chat_id: chatId,
                    message_id: messageId,
                    parse_mode: "Markdown",
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { text: "💳 BAYAR VIA QRIS", callback_data: `qris_special_${fullPanelType}` },
                                { text: "💰 DEPOSIT DULU", callback_data: "deposit_menu" }
                            ],
                            [
                                { text: "🔙 KEMBALI", callback_data: "special_panel_menu" }
                            ]
                        ]
                    }
                }
            );
        }
    }

async function handleAppPurchase(chatId, userId, appId, messageId) {
    const apps = getAllApps();
    const app = apps.find(a => a.id === appId);
    
    if (!app) {
        return bot.sendMessage(chatId, "❌ Aplikasi tidak ditemukan!");
    }

    const saldo = getUserSaldo(userId);
    
    if (isOwner(userId)) {
        // Owner gets free apps
        await sendAppFile(chatId, userId, appId);
    } else if (saldo >= app.price) {
        // Deduct balance and send file
        setUserSaldo(userId, saldo - app.price);
        await sendAppFile(chatId, userId, appId);
    } else {
        await bot.editMessageText(
            `\`\`\`Javascript  📱 *BELI APPS ${app.name.toUpperCase()}*\n\n` +
            `💰 *Harga:* Rp ${toRupiah(app.price)}\n` +
            `💎 *Saldo Anda:* Rp ${toRupiah(saldo)}\n\n` +
            `❌ *Saldo tidak cukup!*\n\n\`\`\`` +
            `*Pilih metode pembayaran:*`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: "Markdown",
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: "💳 BAYAR VIA QRIS", callback_data: `qris_app_${appId}` },
                            { text: "💰 DEPOSIT DULU", callback_data: "deposit_menu" }
                        ],
                        [
                            { text: "🔙 KEMBALI", callback_data: "apps_menu" }
                        ]
                    ]
                }
            }
        );
    }
}

async function handleDocumentPurchase(chatId, userId, docId, messageId) {
    const documents = getAllDocuments();
    const doc = documents.find(d => d.id === docId);
    
    if (!doc) {
        return bot.sendMessage(chatId, "❌ Document tidak ditemukan!");
    }

    const saldo = getUserSaldo(userId);
    
    if (isOwner(userId)) {
        // Owner gets free documents
        await sendDocumentFile(chatId, userId, docId);
    } else if (saldo >= doc.price) {
        // Deduct balance and send file
        setUserSaldo(userId, saldo - doc.price);
        await sendDocumentFile(chatId, userId, docId);
    } else {
        await bot.editMessageText(
            `\`\`\`Javascript  💻 *BELI DOCUMENT ${doc.name.toUpperCase()}*\n\n` +
            `💰 *Harga:* Rp ${toRupiah(doc.price)}\n` +
            `💎 *Saldo Anda:* Rp ${toRupiah(saldo)}\n\n` +
            `❌ *Saldo tidak cukup!*\n\n\`\`\`` +
            `*Pilih metode pembayaran:*`,
            {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: "Markdown",
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: "💳 BAYAR VIA QRIS", callback_data: `qris_doc_${docId}` },
                            { text: "💰 DEPOSIT DULU", callback_data: "deposit_menu" }
                        ],
                        [
                            { text: "🔙 KEMBALI", callback_data: "documents_menu" }
                        ]
                    ]
                }
            }
        );
    }
}

// ==================== MESSAGE HANDLER ====================
bot.on('message', async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const text = msg.text || '';
    
    if (adminChatSessions[userId]?.action === 'waiting_config_value') {
    const success = await updateConfigValue(chatId, text);
    if (success) {
        await showConfigMenu(chatId);
    }
    return;
}
    
    if (adminChatSessions[userId] === 'waiting_approve_warranty') {
        delete adminChatSessions[userId];
        
        const claimId = text.trim();
        const success = updateWarrantyClaim(claimId, { status: 'approved', approvedAt: new Date().toISOString() });
        
        if (success) {
            await bot.sendMessage(chatId, `✅ Klaim garansi ${claimId} berhasil di-approve!`);
            
            // Notify user
            try {
                const claims = getAllWarrantyClaims();
                const claim = claims.find(c => c.id === claimId);
                if (claim) {
                    await bot.sendMessage(claim.userId, 
                        `🎉 *KLaim Garansi Disetujui!*\n\n` +
                        `🆔 ID Klaim: ${claimId}\n` +
                        `📦 Panel: ${claim.panelId}\n` +
                        `✅ Status: DISETUJUI\n\n` +
                        `Panel Anda telah diperbaiki/diganti.`,
                        { parse_mode: "Markdown" }
                    );
                }
            } catch (e) {
                console.log("❌ Tidak bisa kirim notifikasi ke user");
            }
        } else {
            await bot.sendMessage(chatId, `❌ Gagal approve klaim garansi. Pastikan ID benar.`);
        }
        return;
    }

    // Handle warranty rejection
    if (adminChatSessions[userId] === 'waiting_reject_warranty') {
        delete adminChatSessions[userId];
        
        const claimId = text.trim();
        const success = updateWarrantyClaim(claimId, { status: 'rejected', rejectedAt: new Date().toISOString() });
        
        if (success) {
            await bot.sendMessage(chatId, `❌ Klaim garansi ${claimId} berhasil di-reject!`);
            
            // Notify user
            try {
                const claims = getAllWarrantyClaims();
                const claim = claims.find(c => c.id === claimId);
                if (claim) {
                    await bot.sendMessage(claim.userId, 
                        `❌ *Klaim Garansi Ditolak!*\n\n` +
                        `🆔 ID Klaim: ${claimId}\n` +
                        `📦 Panel: ${claim.panelId}\n` +
                        `❌ Status: DITOLAK\n\n` +
                        `Silakan hubungi admin untuk informasi lebih lanjut.`,
                        { parse_mode: "Markdown" }
                    );
                }
            } catch (e) {
                console.log("❌ Tidak bisa kirim notifikasi ke user");
            }
        } else {
            await bot.sendMessage(chatId, `❌ Gagal reject klaim garansi. Pastikan ID benar.`);
        }
        return;
    }
    
    // Handle username input for panel creation - MODIFIED VERSION
    if (pendingUsername[userId]) {
        delete pendingUsername[userId];
        
        const purchaseData = pendingPurchases[userId];
        if (!purchaseData) {
            return bot.sendMessage(chatId, "❌ Data pembelian tidak ditemukan. Silakan ulangi dari menu.");
        }

       const username = text.trim();
        
        // Validate username
        if (!/^[a-zA-Z0-9_]{3,20}$/.test(username)) {
            pendingUsername[userId] = true; // Tetap aktif untuk input ulang
            return bot.sendMessage(chatId, 
                "❌ Username tidak valid!\n" +
                "• Harus 3-20 karakter\n" +
                "• Hanya boleh huruf, angka, underscore\n" +
                "• Tidak boleh ada spasi\n\n" +
                "Silakan masukkan username lagi:"
            );
        }

        // Save username and ask for egg type
        purchaseData.username = username;
        purchaseData.password = generateSecurePassword(username);

        await bot.sendMessage(chatId,
            `\`\`\`Javascript ✅ *USERNAME BERHASIL DISIMPAN!*\n\n` +
            `👤 *Username:* ${username}\n` +
            `🔑 *Password:* ${purchaseData.password}\n\n` +
            `🥚 *Pilih tipe egg untuk panel Anda:*\`\`\``,
            {
                parse_mode: "Markdown",
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: "🥚 Node.js", callback_data: `egg_nodejs_${purchaseData.panelType ? 'special' : 'regular'}` },
                            { text: "🥚 Python", callback_data: `egg_python_${purchaseData.panelType ? 'special' : 'regular'}` }
                        ],
                        [
                            { text: "🥚 PM2", callback_data: `egg_pm2_${purchaseData.panelType ? 'special' : 'regular'}` }
                        ]
                    ]
                }
            }
        );
        return;
    }

    // Handle reseller username input
    if (resellerSellSessions[userId]?.step === 'waiting_username') {
        const sellData = resellerSellSessions[userId];
        const username = text.trim();
        
        // Validate username
        if (!/^[a-zA-Z0-9_]{3,20}$/.test(username)) {
            return bot.sendMessage(chatId, 
                "❌ Username tidak valid!\n" +
                "• Harus 3-20 karakter\n" +
                "• Hanya boleh huruf, angka, underscore\n" +
                "• Tidak boleh ada spasi\n\n" +
                "Silakan masukkan username lagi:"
            );
        }

        // Save username and ask for egg type
        sellData.username = username;
        sellData.password = generateSecurePassword(username);
        sellData.step = 'waiting_egg_type';

        await bot.sendMessage(chatId,
            `\`\`\`Javascript ✅ *USERNAME CUSTOMER BERHASIL DISIMPAN!*\n\n` +
            `👤 *Username Customer:* ${username}\n` +
            `🔑 *Password:* ${sellData.password}\n` +
            `📦 *RAM:* ${sellData.ramSize.toUpperCase()}\n` +
            `💰 *Modal:* Rp ${toRupiah(sellData.modalPrice)}\n\n` +
            `🥚 *Pilih tipe egg untuk panel customer:*\`\`\``,
            {
                parse_mode: "Markdown",
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: "🥚 Node.js", callback_data: `reseller_egg_nodejs` },
                            { text: "🥚 Python", callback_data: `reseller_egg_python` }
                        ],
                        [
                            { text: "🥚 PM2", callback_data: `reseller_egg_pm2` }
                        ]
                    ]
                }
            }
        );
        return;
    }

    // Handle custom deposit amount
    if (userChatSessions[userId] === 'waiting_deposit_amount') {
        delete userChatSessions[userId];
        
        const amount = parseInt(text.replace(/[^0-9]/g, ''));
        
        if (!amount || amount < 5000) {
            return bot.sendMessage(chatId, "❌ Minimal deposit Rp 5,000. Silakan masukkan nominal yang valid:");
        }

        if (amount > 1000000) {
            return bot.sendMessage(chatId, "❌ Maksimal deposit Rp 1,000,000. Silakan masukkan nominal yang lebih kecil:");
        }

        await processDeposit(chatId, userId, amount);
        return;
    }

    // Handle owner add saldo
    if (adminChatSessions[userId] === 'waiting_addsaldo_user') {
        delete adminChatSessions[userId];
        
        const targetUser = text.trim();
        adminChatSessions[userId] = {
            action: 'waiting_addsaldo_amount',
            targetUser: targetUser
        };
        
        return bot.sendMessage(chatId, "💰 Masukkan jumlah saldo yang ingin ditambahkan:");
    }

    if (adminChatSessions[userId]?.action === 'waiting_addsaldo_amount') {
        const targetUser = adminChatSessions[userId].targetUser;
        delete adminChatSessions[userId];
        
        const amount = parseInt(text.replace(/[^0-9]/g, ''));
        
        if (!amount || amount <= 0) {
            return bot.sendMessage(chatId, "❌ Jumlah saldo tidak valid.");
        }

        let targetUserId;
        
        if (targetUser.startsWith('@')) {
            // Find user by username
            try {
                // This would need actual user lookup implementation
                targetUserId = targetUser.substring(1);
            } catch (e) {
                return bot.sendMessage(chatId, "❌ User tidak ditemukan.");
            }
        } else {
            targetUserId = parseInt(targetUser);
        }

        const newSaldo = addUserSaldo(targetUserId, amount);
        
        if (newSaldo !== null) {
            await bot.sendMessage(chatId,
                `\`\`\`Javascript  ✅ *SALDO BERHASIL DITAMBAHKAN*\n\n` +
                `👤 *User:* ${targetUser}\n` +
                `💰 *Jumlah:* Rp ${toRupiah(amount)}\n` +
                `💎 *Saldo Baru:* Rp ${toRupiah(newSaldo)}\`\`\``,
                { parse_mode: "Markdown" }
            );

            // Notify target user
            try {
                await bot.sendMessage(targetUserId,
                    `\`\`\`Javascript  🎉 *SALDO ANDA DITAMBAHKAN!*\n\n` +
                    `💰 *Jumlah:* Rp ${toRupiah(amount)}\n` +
                    `💎 *Saldo Baru:* Rp ${toRupiah(newSaldo)}\n` +
                    `👤 *Oleh:* Owner\`\`\``,
                    { parse_mode: "Markdown" }
                );
            } catch (e) {
                console.log("❌ Tidak bisa kirim notifikasi ke user");
            }
        } else {
            await bot.sendMessage(chatId, "❌ Gagal menambah saldo.");
        }
        return;
    }

    // Handle owner broadcast
    if (adminChatSessions[userId] === 'waiting_broadcast_message') {
        delete adminChatSessions[userId];
        
        const broadcastText = text;
        const users = getAllUsers();
        
        let successCount = 0;
        let failCount = 0;
        
        const progressMsg = await bot.sendMessage(chatId, 
            `\`\`\`Javascript  📢 *MENGIRIM BROADCAST...*\n\n` +
            `📝 *Pesan:* ${broadcastText.substring(0, 100)}...\n` +
            `👥 *Target:* ${users.length} users\n` +
            `✅ *Berhasil:* 0\n` +
            `❌ *Gagal:* 0\`\`\``,
            { parse_mode: "Markdown" }
        );

        for (const user of users) {
            try {
                await bot.sendMessage(user.userId,
                    `📢 *BROADCAST MESSAGE*\n\n${broadcastText}`,
                    { parse_mode: "Markdown" }
                );
                successCount++;
            } catch (e) {
                failCount++;
            }

            // Update progress every 10 sends
            if ((successCount + failCount) % 10 === 0) {
                await bot.editMessageText(
                    `\`\`\`Javascript  📢 *MENGIRIM BROADCAST...*\n\n` +
                    `📝 *Pesan:* ${broadcastText.substring(0, 100)}...\n` +
                    `👥 *Target:* ${users.length} users\n` +
                    `✅ *Berhasil:* ${successCount}\n` +
                    `❌ *Gagal:* ${failCount}\`\`\``,
                    {
                        chat_id: chatId,
                        message_id: progressMsg.message_id,
                        parse_mode: "Markdown"
                    }
                );
            }

            // Delay to avoid rate limiting
            await new Promise(r => setTimeout(r, 100));
        }

        await bot.editMessageText(
            `\`\`\`Javascript  ✅ *BROADCAST SELESAI!*\n\n` +
            `📝 *Pesan:* ${broadcastText.substring(0, 100)}...\n` +
            `👥 *Total Target:* ${users.length} users\n` +
            `✅ *Berhasil:* ${successCount}\n` +
            `❌ *Gagal:* ${failCount}\`\`\``,
            {
                chat_id: chatId,
                message_id: progressMsg.message_id,
                parse_mode: "Markdown"
            }
        );
        return;
    }

    // Handle owner add app
    if (adminChatSessions[userId] === 'waiting_add_app_name') {
        delete adminChatSessions[userId];
        
        const appName = text.trim();
        adminChatSessions[userId] = {
            action: 'waiting_add_app_price',
            appName: appName
        };
        
        return bot.sendMessage(chatId, "💰 Masukkan harga aplikasi:");
    }

    if (adminChatSessions[userId]?.action === 'waiting_add_app_price') {
        const appName = adminChatSessions[userId].appName;
        delete adminChatSessions[userId];
        
        const price = parseInt(text.replace(/[^0-9]/g, ''));
        
        if (!price || price <= 0) {
            return bot.sendMessage(chatId, "❌ Harga tidak valid.");
        }

        adminChatSessions[userId] = {
            action: 'waiting_add_app_description',
            appName: appName,
            price: price
        };
        
        return bot.sendMessage(chatId, "📝 Masukkan deskripsi aplikasi:");
    }

    if (adminChatSessions[userId]?.action === 'waiting_add_app_description') {
        const appName = adminChatSessions[userId].appName;
        const price = adminChatSessions[userId].price;
        delete adminChatSessions[userId];
        
        const description = text.trim();
        
        adminChatSessions[userId] = {
            action: 'waiting_add_app_file',
            appName: appName,
            price: price,
            description: description
        };
        
        return bot.sendMessage(chatId, "📁 Kirim file aplikasi (document):");
    }

    // Handle owner add document
    if (adminChatSessions[userId] === 'waiting_add_doc_name') {
        delete adminChatSessions[userId];
        
        const docName = text.trim();
        adminChatSessions[userId] = {
            action: 'waiting_add_doc_price',
            docName: docName
        };
        
        return bot.sendMessage(chatId, "💰 Masukkan harga document:");
    }

    if (adminChatSessions[userId]?.action === 'waiting_add_doc_price') {
        const docName = adminChatSessions[userId].docName;
        delete adminChatSessions[userId];
        
        const price = parseInt(text.replace(/[^0-9]/g, ''));
        
        if (!price || price <= 0) {
            return bot.sendMessage(chatId, "❌ Harga tidak valid.");
        }

        adminChatSessions[userId] = {
            action: 'waiting_add_doc_description',
            docName: docName,
            price: price
        };
        
        return bot.sendMessage(chatId, "📝 Masukkan deskripsi document:");
    }

    if (adminChatSessions[userId]?.action === 'waiting_add_doc_description') {
        const docName = adminChatSessions[userId].docName;
        const price = adminChatSessions[userId].price;
        delete adminChatSessions[userId];
        
        const description = text.trim();
        
        adminChatSessions[userId] = {
            action: 'waiting_add_doc_file',
            docName: docName,
            price: price,
            description: description
        };
        
        return bot.sendMessage(chatId, "📁 Kirim file document:");
    }

    // Handle file upload for apps and documents
    if (msg.document) {
        const fileId = msg.document.file_id;
        
        if (adminChatSessions[userId]?.action === 'waiting_add_app_file') {
            const appData = adminChatSessions[userId];
            delete adminChatSessions[userId];
            
            const app = {
                id: `APP-${Math.floor(100000 + Math.random() * 900000)}`,
                name: appData.appName,
                price: appData.price,
                description: appData.description,
                fileId: fileId,
                createdAt: new Date().toISOString()
            };
            
            if (saveApp(app)) {
                await bot.sendMessage(chatId,
                    `\`\`\`Javascript  ✅ *APPS BERHASIL DITAMBAHKAN!*\n\n` +
                    `📱 *Nama:* ${app.name}\n` +
                    `💰 *Harga:* Rp ${toRupiah(app.price)}\n` +
                    `📝 *Deskripsi:* ${app.description}\n` +
                    `🆔 *ID:* ${app.id}\`\`\``,
                    { parse_mode: "Markdown" }
                );
            } else {
                await bot.sendMessage(chatId, "❌ Gagal menambahkan apps.");
            }
            return;
        }

        if (adminChatSessions[userId]?.action === 'waiting_add_doc_file') {
            const docData = adminChatSessions[userId];
            delete adminChatSessions[userId];
            
            const doc = {
                id: `DOC-${Math.floor(100000 + Math.random() * 900000)}`,
                name: docData.docName,
                price: docData.price,
                description: docData.description,
                fileId: fileId,
                createdAt: new Date().toISOString()
            };
            
            if (saveDocument(doc)) {
                await bot.sendMessage(chatId,
                    `\`\`\`Javascript  ✅ *DOCUMENT BERHASIL DITAMBAHKAN!*\n\n` +
                    `💻 *Nama:* ${doc.name}\n` +
                    `💰 *Harga:* Rp ${toRupiah(doc.price)}\n` +
                    `📝 *Deskripsi:* ${doc.description}\n` +
                    `🆔 *ID:* ${doc.id}\`\`\``,
                    { parse_mode: "Markdown" }
                );
            } else {
                await bot.sendMessage(chatId, "❌ Gagal menambahkan document.");
            }
            return;
        }
    }

    // Handle start command
   /* if (text === '/start' || text === '/menu') {
        return showMainMenu(chatId, userId);
    }*/
});

// ==================== ADD CONFIG COMMAND ====================
bot.onText(/^\/(config|setting|pengaturan)$/i, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    if (!isOwner(userId)) {
        return bot.sendMessage(chatId, "❌ Hanya owner yang bisa mengakses perintah ini!");
    }
    
    await showConfigMenu(chatId);
});

bot.onText(/^\/(withdraw|cairkan)$/i, async (msg) => {  
    const chatId = msg.chat.id;  
    const userId = msg.from.id.toString();  
    const replyMessage = msg.reply_to_message;  
    const targetMessageId = replyMessage ? replyMessage.message_id : msg.message_id;  

    if (userId !== config.OWNER_ID) {  
        return bot.sendMessage(chatId, "❌ Hanya owner yang bisa mengakses perintah ini.");  
    }  

    try {  
        // Debug: Cek API key
        console.log('API Key yang digunakan:', config.PAYMENT.apiAtlantic ? 'Ada' : 'Tidak ada');
        console.log('Panjang API Key:', config.PAYMENT.apiAtlantic?.length);
        
        if (!config.PAYMENT.apiAtlantic || config.PAYMENT.apiAtlantic.trim() === '') {
            throw new Error('API Key tidak ditemukan di konfigurasi');
        }

        function sensorString(input, visibleCount = 3, maskChar = 'X') {  
            if (input.length <= visibleCount) return input;  
            const visiblePart = input.slice(0, visibleCount);  
            const maskedPart = maskChar.repeat(input.length - visibleCount);  
            return visiblePart + maskedPart;  
        }  

        function sensorWithSpace(str, visibleCount = 3, maskChar = 'X') {  
            let result = '';  
            let count = 0;  
            for (let char of str) {  
                if (char === ' ') {  
                    result += char;  
                } else if (count < visibleCount) {  
                    result += char;  
                    count++;  
                } else {  
                    result += maskChar;  
                }  
            }  
            return result;  
        }  

        // ✅ Ambil saldo Atlantic  
        const statusUrl = 'https://atlantich2h.com/get_profile';  
        const statusData = qs.stringify({ 
            api_key: config.PAYMENT.apiAtlantic.trim() // pastikan tidak ada spasi
        });

        console.log('Mengambil data saldo...');
        
        const res = await axios.post(statusUrl, statusData, {  
            headers: { 
                'Content-Type': 'application/x-www-form-urlencoded',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            },
            timeout: 10000 // timeout 10 detik
        });  

        console.log('Response status:', res.status);
        console.log('Response data:', JSON.stringify(res.data, null, 2));

        // Validasi response
        if (!res.data) {
            throw new Error('Tidak ada response dari server Atlantic');
        }

        if (res.data.error) {
            throw new Error(res.data.message || `Error: ${res.data.error}`);
        }

        if (!res.data.data) {
            throw new Error('Struktur response tidak valid - data tidak ditemukan');
        }

        const saldoAwal = res.data.data.balance;
        if (saldoAwal === undefined || saldoAwal === null) {
            throw new Error('Saldo tidak ditemukan dalam response');
        }

        const totalsaldo = Math.max(0, saldoAwal - 2000); // potong 2000  

        // Validasi saldo cukup untuk penarikan
        if (totalsaldo <= 0) {
            return bot.sendMessage(chatId, "❌ Saldo tidak cukup untuk melakukan penarikan (minimal saldo setelah fee: Rp 1)", { 
                reply_to_message_id: targetMessageId 
            });
        }

        // ✅ Proses pencairan  
        const statusUrl2 = 'https://atlantich2h.com/transfer/create';  
        const statusData2 = qs.stringify({  
            api_key: config.PAYMENT.apiAtlantic.trim(),  
            ref_id: `WD${Date.now()}`,  
            kode_bank: config.type_ewallet,  
            nomor_akun: config.nomor_pencairan,  
            nama_pemilik: config.atas_nama_ewallet,  
            nominal: totalsaldo.toString()  
        });  

        console.log('Memproses pencairan...');
        
        const ress = await axios.post(statusUrl2, statusData2, {  
            headers: { 
                'Content-Type': 'application/x-www-form-urlencoded',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            },
            timeout: 10000
        });  

        console.log('Response pencairan:', JSON.stringify(ress.data, null, 2));

        // Validasi response pencairan
        if (!ress.data) {
            throw new Error('Tidak ada response dari proses pencairan');
        }

        if (ress.data.error) {
            throw new Error(ress.data.message || `Error pencairan: ${ress.data.error}`);
        }

        if (!ress.data.data) {
            throw new Error('Struktur response pencairan tidak valid');
        }

        const ids = ress.data.data.id;  
        const status = ress.data.data.status || "unknown";  

        // Format saldo
        const formatRupiah = (number) => {
            return new Intl.NumberFormat('id-ID').format(number);
        };

        const formattedSaldo = formatRupiah(saldoAwal);
        const formattedTotal = formatRupiah(totalsaldo);
        const formattedFee = formatRupiah(2000);

        // ✅ Kirim informasi awal  
        await bot.sendMessage(chatId, `\`\`\`JAVASCRIPT
💳 Informasi Pencairan Saldo:  

- Saldo Awal: Rp ${formattedSaldo}
- Nominal Penarikan: Rp ${formattedTotal}  
- Fee Pencairan: Rp ${formattedFee}  
- Tujuan: ${sensorString(config.nomor_pencairan)}  
- Type Ewallet: ${config.type_ewallet}  
- Nama Pemilik: ${sensorWithSpace(config.atas_nama_ewallet)}  
- Status: ${status}  

Memproses Pencairan Saldo...  
\`\`\``, { reply_to_message_id: targetMessageId, parse_mode: 'Markdown' });  

        // ✅ Kalau langsung sukses, hentikan di sini  
        if (status === "success") {  
            return bot.sendMessage(chatId, `\`\`\`JAVASCRIPT
✅ Pencairan Berhasil!  

- Saldo Awal: Rp ${formattedSaldo}
- Nominal Penarikan: Rp ${formattedTotal}  
- Fee Pencairan: Rp ${formattedFee}  
- Tujuan: ${sensorString(config.nomor_pencairan)}  
- Type Ewallet: ${config.type_ewallet}  
- Nama Pemilik: ${sensorWithSpace(config.atas_nama_ewallet)}  
- Status: ${status}  

Saldo Berhasil Dikirim Ke Ewallet Pribadi ✅  
\`\`\``, { reply_to_message_id: targetMessageId, parse_mode: 'Markdown' });  
        }  

        // ✅ Kalau pending → loop cek status  
        if (status === "pending") {  
            let attempts = 0;
            const maxAttempts = 12; // maksimal 1 menit (12 x 5 detik)
            
            while (attempts < maxAttempts) {  
                attempts++;
                
                console.log(`Cek status ke-${attempts} untuk ID: ${ids}`);
                
                const statusUrl3 = 'https://atlantich2h.com/transfer/status';  
                const statusData3 = qs.stringify({  
                    api_key: config.PAYMENT.apiAtlantic.trim(),  
                    id: ids  
                });  

                const checkRes = await axios.post(statusUrl3, statusData3, {  
                    headers: { 
                        'Content-Type': 'application/x-www-form-urlencoded',
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                    },
                    timeout: 10000
                });  

                const result = checkRes?.data?.data || {};  
                console.log(`Status check ${attempts}:`, result?.status);
                
                if (result?.status === "success") {  
                    return bot.sendMessage(chatId, `\`\`\`JAVASCRIPT
✅ Pencairan Berhasil!  

- Saldo Awal: Rp ${formattedSaldo}
- Nominal Penarikan: Rp ${formattedTotal}  
- Fee Pencairan: Rp ${formattedFee}  
- Tujuan: ${sensorString(config.nomor_pencairan)}  
- Type Ewallet: ${config.type_ewallet}  
- Nama Pemilik: ${sensorWithSpace(config.atas_nama_ewallet)}  
- Status: ${result.status}  

Saldo Berhasil Dikirim Ke Ewallet Pribadi ✅  
\`\`\``, { reply_to_message_id: targetMessageId, parse_mode: 'Markdown' });  
                } 
                else if (result?.status === "failed" || result?.status === "error") {
                    throw new Error(`Pencairan gagal dengan status: ${result.status}`);
                }

                // Jika masih pending, tunggu 5 detik
                await new Promise(resolve => setTimeout(resolve, 5000));  
            }
            
            // Jika timeout
            throw new Error('Timeout: Pencairan masih pending setelah 1 menit');
        }  

    } catch (err) {  
        console.error('Error detail:', err.response?.data || err.message);
        console.error('Error stack:', err.stack);
        
        let msgErr = err.response?.data?.message || err.message;  

        // ⚠️ Kalau error "Saldo tidak cukup", abaikan karena normal setelah saldo ditarik  
        if (msgErr.includes("Saldo tidak cukup")) {  
            console.warn("Saldo habis setelah pencairan, abaikan error ini.");  
            return;  
        }  

        let errorMessage = '❌ Gagal memproses pencairan saldo';
        
        if (msgErr.includes('Invalid Credential') || msgErr.includes('invalid') || msgErr.includes('unauthorized')) {
            errorMessage = '❌ API Key tidak valid atau telah kadaluarsa. Silakan periksa kembali API key Atlantic Anda.';
        } else if (msgErr.includes('timeout') || msgErr.includes('Timeout')) {
            errorMessage = '❌ Timeout: Server tidak merespons. Silakan coba lagi nanti.';
        } else if (msgErr.includes('network') || msgErr.includes('ECONNREFUSED')) {
            errorMessage = '❌ Gagal terhubung ke server. Periksa koneksi internet Anda.';
        } else if (msgErr) {
            errorMessage += `\n\nPesan Error: ${msgErr}`;
        }
        
        return bot.sendMessage(chatId, errorMessage, {  
            reply_to_message_id: targetMessageId  
        });  
    }  
});

// Tambahkan perintah untuk test API key
bot.onText(/^\/(testapi|cekapikey)$/i, async (msg) => {  
    const chatId = msg.chat.id;  
    const userId = msg.from.id.toString();  

    if (userId !== config.OWNER_ID) {  
        return bot.sendMessage(chatId, "❌ Hanya owner yang bisa mengakses perintah ini.");  
    }  

    try {
        // Debug dulu confignya
        console.log('Config object:', config);
        console.log('apiAtlantic in config:', config.PAYMENT.apiAtlantic);
        
        if (!config.PAYMENT.apiAtlantic) {
            return bot.sendMessage(chatId, `❌ API Key tidak ditemukan di config.\n\nPastikan config.js berisi:\n\napiAtlantic: "your_api_key_here"`);
        }

        const apiKey = config.PAYMENT.apiAtlantic.trim ? config.PAYMENT.apiAtlantic.trim() : String(config.PAYMENT.apiAtlantic).trim();
        
        console.log('API Key setelah trim:', apiKey);
        console.log('Panjang API Key:', apiKey.length);

        const testUrl = 'https://atlantich2h.com/get_profile';  
        const testData = qs.stringify({ 
            api_key: apiKey
        });

        await bot.sendMessage(chatId, "🔄 Testing API Key...");

        const response = await axios.post(testUrl, testData, {  
            headers: { 
                'Content-Type': 'application/x-www-form-urlencoded',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            },
            timeout: 10000
        });  

        console.log('Response test API:', JSON.stringify(response.data, null, 2));

        if (response.data && response.data.data) {
            await bot.sendMessage(chatId, `✅ API Key Valid!\n\nSaldo: Rp ${new Intl.NumberFormat('id-ID').format(response.data.data.balance)}\nUsername: ${response.data.data.username || 'Tidak tersedia'}`);
        } else {
            await bot.sendMessage(chatId, '❌ API Key tidak valid - Response tidak sesuai format');
        }
    } catch (error) {
        console.error('Error test API:', error.response?.data || error.message);
        
        const errorMsg = error.response?.data?.message || error.message;
        
        if (errorMsg.includes('Invalid Credential') || errorMsg.includes('invalid')) {
            await bot.sendMessage(chatId, `❌ API Key tidak valid atau kadaluarsa.\n\nSilakan periksa API key di dashboard Atlantic.`);
        } else if (error.response?.data) {
            await bot.sendMessage(chatId, `❌ Error: ${JSON.stringify(error.response.data)}`);
        } else {
            await bot.sendMessage(chatId, `❌ API Key Gagal: ${errorMsg}`);
        }
    }
});

// Command untuk cek saldo Atlantic
bot.onText(/^\/(ceksaldo|saldo|balance)$/i, async (msg) => {  
    const chatId = msg.chat.id;  
    const userId = msg.from.id.toString();  
    const replyMessage = msg.reply_to_message;  
    const targetMessageId = replyMessage ? replyMessage.message_id : msg.message_id;  

    if (userId !== config.OWNER_ID) {  
        return bot.sendMessage(chatId, "❌ Hanya owner yang bisa mengakses perintah ini.");  
    }  

    try {  
        // Validasi config
        if (!config.PAYMENT.apiAtlantic) {
            return bot.sendMessage(chatId, "❌ API Key tidak ditemukan di konfigurasi.", { 
                reply_to_message_id: targetMessageId 
            });
        }

        const apiKey = config.PAYMENT.apiAtlantic.trim ? config.PAYMENT.apiAtlantic.trim() : String(config.PAYMENT.apiAtlantic).trim();
        
        if (!apiKey) {
            return bot.sendMessage(chatId, "❌ API Key kosong. Periksa konfigurasi apiAtlantic.", { 
                reply_to_message_id: targetMessageId 
            });
        }

        // Kirim pesan sedang memproses
        const processingMsg = await bot.sendMessage(chatId, `\`\`\`JAVASCRIPT 🔄 Mengambil data saldo....\`\`\``, { 
            reply_to_message_id: targetMessageId,
            parse_mode: 'Markdown'
        });

        // ✅ Ambil data profil dan saldo Atlantic  
        const statusUrl = 'https://atlantich2h.com/get_profile';  
        const statusData = qs.stringify({ 
            api_key: apiKey
        });

        const res = await axios.post(statusUrl, statusData, {  
            headers: { 
                'Content-Type': 'application/x-www-form-urlencoded',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            },
            timeout: 10000
        });  

        // Validasi response
        if (!res.data) {
            throw new Error('Tidak ada response dari server Atlantic');
        }

        if (res.data.error) {
            throw new Error(res.data.message || `Error: ${res.data.error}`);
        }

        if (!res.data.data) {
            throw new Error('Struktur response tidak valid - data tidak ditemukan');
        }

        const data = res.data.data;
        const saldo = data.balance;
        const username = data.username || "Tidak tersedia";
        const nama = data.name || "Tidak tersedia";
        const email = data.email || "Tidak tersedia";

        if (saldo === undefined || saldo === null) {
            throw new Error('Saldo tidak ditemukan dalam response');
        }

        // Format saldo
        const formatRupiah = (number) => {
            return new Intl.NumberFormat('id-ID').format(number);
        };

        const formattedSaldo = formatRupiah(saldo);
        
        // Hapus pesan processing
        await bot.deleteMessage(chatId, processingMsg.message_id);

        // Kirim informasi saldo dengan format yang rapi
        await bot.sendMessage(chatId, `\`
💰 *INFORMASI SALDO ATLANTIC*

┌─────────────────
│ 👤 *Profile Info*
│ ├ Username: ${username}
│ ├ Nama: ${nama}
│ ├ Email: ${email}
│ 
│ 💰 *Saldo*
│ ├ Saldo Aktif: *Rp ${formattedSaldo}*
│ ├ Estimasi Penarikan: *Rp ${formatRupiah(Math.max(0, saldo - 2000))}*
│ └ (setelah potongan fee Rp 2.000)
│ 
│ ⚡ *Status*
│ └ ✅ Akun aktif dan terhubung

💡 *Tips:* Gunakan /withdraw untuk menarik saldo
        \``, { 
            reply_to_message_id: targetMessageId,
            parse_mode: 'Markdown'
        });

    } catch (err) {  
        console.error('Error cek saldo:', err.response?.data || err.message);
        
        const msgErr = err.response?.data?.message || err.message;  

        let errorMessage = '❌ Gagal mengambil data saldo';
        
        if (msgErr.includes('Invalid Credential') || msgErr.includes('invalid') || msgErr.includes('unauthorized')) {
            errorMessage = '❌ API Key tidak valid atau telah kadaluarsa.\nSilakan periksa kembali API key Atlantic Anda.';
        } else if (msgErr.includes('timeout') || msgErr.includes('Timeout')) {
            errorMessage = '❌ Timeout: Server Atlantic tidak merespons.\nSilakan coba lagi nanti.';
        } else if (msgErr.includes('network') || msgErr.includes('ECONNREFUSED')) {
            errorMessage = '❌ Gagal terhubung ke server.\nPeriksa koneksi internet Anda.';
        } else {
            errorMessage += `\n\nPesan Error: ${msgErr}`;
        }
        
        // Hapus pesan processing jika ada error
        try {
            if (processingMsg) {
                await bot.deleteMessage(chatId, processingMsg.message_id);
            }
        } catch (e) {
            // Ignore error delete message
        }
        
        return bot.sendMessage(chatId, errorMessage, {  
            reply_to_message_id: targetMessageId  
        });  
    }  
});

// ==================== RESTORE BACKUP COMMAND ====================
bot.onText(/^\/(restore|restoredata)$/i, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (!isOwner(userId)) {
        return bot.sendMessage(chatId, "❌ Hanya owner yang bisa mengakses perintah ini.");
    }

    const replyMessage = msg.reply_to_message;
    
    if (!replyMessage || !replyMessage.document) {
        return bot.sendMessage(chatId, 
            "📁 *Cara Restore Backup:*\n\n" +
            "1. Reply pesan ini dengan file backup\n" +
            "2. Pastikan file backup valid\n" +
            "3. Bot akan memulihkan data dari backup\n\n" +
            "⚠️ *Peringatan:* Tindakan ini akan menimpa data saat ini!",
            { parse_mode: "Markdown", reply_to_message_id: msg.message_id }
        );
    }

    try {
        const processingMsg = await bot.sendMessage(chatId, "🔄 Memproses restore backup...");

        // Download backup file
        const fileId = replyMessage.document.file_id;
        const file = await bot.getFile(fileId);
        const filePath = file.file_path;
        const downloadUrl = `https://api.telegram.org/file/bot${config.BOT_TOKEN}/${filePath}`;
        
        const response = await axios({
            method: 'GET',
            url: downloadUrl,
            responseType: 'stream'
        });

        const tempFilePath = `./temp_backup_${Date.now()}.json`;
        const writer = fs.createWriteStream(tempFilePath);
        
        response.data.pipe(writer);
        
        await new Promise((resolve, reject) => {
            writer.on('finish', resolve);
            writer.on('error', reject);
        });

        // Read and validate backup file
        const backupContent = fs.readFileSync(tempFilePath, 'utf8');
        const backupData = JSON.parse(backupContent);

        if (!backupData.data || typeof backupData.data !== 'object') {
            throw new Error('Format backup file tidak valid');
        }

        // Restore data
        let restoredFiles = 0;
        let totalFiles = 0;

        for (const [fileName, fileContent] of Object.entries(backupData.data)) {
            try {
                const filePath = path.join(databaseDir, fileName);
                
                // Validate JSON before writing
                JSON.parse(fileContent);
                
                fs.writeFileSync(filePath, fileContent);
                restoredFiles++;
                totalFiles++;
                
            } catch (fileError) {
                console.error(`❌ Gagal restore file ${fileName}:`, fileError.message);
                totalFiles++;
            }
        }

        // Clean up temp file
        fs.unlinkSync(tempFilePath);

        await bot.editMessageText(
            `\`\`\`Javascript ✅ *RESTORE BERHASIL!*\n\n` +
            `📁 *File Dipulihkan:* ${restoredFiles}/${totalFiles}\n` +
            `🕐 *Backup Date:* ${backupData.timestamp ? new Date(backupData.timestamp).toLocaleString('id-ID') : 'Unknown'}\n\n` +
            `♻️ *Bot akan restart otomatis...*\`\`\``,
            {
                chat_id: chatId,
                message_id: processingMsg.message_id,
                parse_mode: "Markdown"
            }
        );

        // Restart bot setelah restore
        setTimeout(() => {
            process.exit(0);
        }, 3000);

    } catch (error) {
        console.error('❌ Restore error:', error);
        await bot.sendMessage(chatId, `❌ Gagal restore backup: ${error.message}`);
        
        // Clean up temp file if exists
        try {
            if (fs.existsSync(tempFilePath)) {
                fs.unlinkSync(tempFilePath);
            }
        } catch (cleanupError) {
            // Ignore cleanup errors
        }
    }
});

// ==================== MANUAL BACKUP COMMAND ====================
bot.onText(/^\/(backup|backupdata)$/i, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    if (!isOwner(userId)) {
        return bot.sendMessage(chatId, "❌ Hanya owner yang bisa mengakses perintah ini.");
    }

    try {
        const processingMsg = await bot.sendMessage(chatId, "💾 Membuat backup data...");

        const backupFilePath = await createBackup();
        if (!backupFilePath) {
            throw new Error('Gagal membuat file backup');
        }

        const backupData = JSON.parse(fs.readFileSync(backupFilePath).toString());
        const timestamp = new Date(backupData.timestamp).toLocaleString('id-ID');

        const stats = {
            totalUsers: getTotalUsers(),
            totalTransactions: getTotalTransactions(),
            totalPanels: getTotalPanels()
        };

        const caption = `\`\`\`Javascript
💾 *BACKUP DATA MANUAL*
━━━━━━━━━━━━━━━━━━━━━━━━━━
🕐 Waktu: ${timestamp}
⏱️ Runtime: ${getRuntime()}

📊 *STATISTIK:*
• 👥 Total Users: ${stats.totalUsers}
• 📦 Total Transaksi: ${stats.totalTransactions}
• 🖥️ Total Panel: ${stats.totalPanels}

✅ Backup manual berhasil dibuat.
\`\`\``;

        await bot.deleteMessage(chatId, processingMsg.message_id);
        await bot.sendDocument(chatId, backupFilePath, {
            caption: caption,
            parse_mode: "Markdown"
        });

        // Clean up
        setTimeout(() => {
            try {
                fs.unlinkSync(backupFilePath);
            console.log('🧹 File backup manual dibersihkan');
            bot.sendMessage(chatId, "🧹 File backup lokal telah dibersihkan.");
            } catch (cleanupError) {
                console.error('❌ Gagal membersihkan file backup:', cleanupError.message);
            }
        }, 30000); // Beri waktu 30 detik sebelum cleanup

    } catch (error) {
        console.error('❌ Manual backup error:', error);
        await bot.sendMessage(chatId, `❌ Gagal membuat backup: ${error.message}`);
    }
});

// ==================== ERROR HANDLING ====================
bot.on('polling_error', (error) => {
    console.error('❌ Polling error:', error);
});

bot.on('webhook_error', (error) => {
    console.error('❌ Webhook error:', error);
});

process.on('uncaughtException', (error) => {
    console.error('❌ Uncaught Exception:', error);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('❌ Unhandled Rejection at:', promise, 'reason:', reason);
});

console.log('🤖 Bot Panel Premium berhasil dijalankan!');