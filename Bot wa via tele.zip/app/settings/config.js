module.exports = {
  OWNER_ID: ["7516661613"],
  START_IMAGE_URL: "https://f.top4top.io/p_3338tz6bm0.jpg" 
};