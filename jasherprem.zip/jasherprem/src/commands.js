const { Telegraf, Markup } = require('telegraf');
const fs = require('fs-extra');
const path = require('path');
const fetch = require('node-fetch');
const moment = require('moment-timezone');
const JsConfuser = require('js-confuser');
const { 
    updateProgress, log, isPremium, isOwner, 
    runtime, uploadToUguu, createProgressBar 
} = require('../lib/utils');
const {
    obfuscateTimeLocked,
    obfuscateQuantum,
    getSiuCalcrickObfuscationConfig,
    getCustomObfuscationConfig,
    getNebulaObfuscationConfig,
    getNovaObfuscationConfig,
    getStrongObfuscationConfig,
    getArabObfuscationConfig,
    getJapanxArabObfuscationConfig,
    getJapanObfuscationConfig
} = require('./obf');

// Helper function untuk mendapatkan nama pengguna
function getUsername(user) {
    return user.username ? `@${user.username}` : `${user.first_name}${user.last_name ? ` ${user.last_name}` : ''}`;
}

// Helper function untuk mendapatkan info grup
function getGroupInfo(ctx) {
    const chat = ctx.chat;
    return {
        id: chat.id,
        title: chat.title || 'Private Chat',
        type: chat.type,
        username: chat.username ? `@${chat.username}` : 'Tidak ada'
    };
}

// Main menu command
function setupCommands(bot) {
    // Start command
    bot.start(async (ctx) => {
        const sender = getUsername(ctx.from);
        const isCreator = isOwner(ctx.from.id);
        
        users.add(ctx.from.id);
        saveUsers(users);
        
        const menuText = `
╭─❒ 「 User Info 」 
├ Owner : ${isCreator ? 'True' : 'False'}
├ Name : ${ctx.from.first_name}${ctx.from.last_name ? ` ${ctx.from.last_name}` : ''}
├ Profile : ${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`;
        
        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('🤖 Jasher Menu', 'jasher_menu')],
            [Markup.button.callback('👑 Owner Menu', 'owner_menu'), Markup.button.callback('🔒 Obf Menu', 'obf_menu')],
            [Markup.button.callback('🔄 Kembali', 'main_menu')]
        ]);
        
        await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
            caption: menuText,
            parse_mode: 'Markdown',
            ...keyboard
        });
    });
    
    // Help command
    bot.help((ctx) => {
        ctx.replyWithMarkdown(`
🤖 *Bantuan Bot Jasher*

*Fitur Utama:*
- 🔒 Obfuscation JavaScript dengan berbagai metode
- 👥 Manajemen grup dengan fitur admin
- 📢 Broadcast pesan ke semua pengguna
- ⭐ Fitur premium untuk pengguna berbayar

*Cara Penggunaan:*
1. Tambahkan bot ke grup Anda
2. Gunakan command /menu untuk melihat menu utama
3. Untuk obfuscation, reply file JS dengan command yang sesuai

*Command yang tersedia:*
/menu - Menu utama bot
/help - Bantuan penggunaan
/about - Tentang bot ini

*Support:*
Jika mengalami kendala, hubungi @ginaaforyou
        `);
    });
    
    // About command
    bot.command('about', (ctx) => {
        ctx.replyWithMarkdown(`
🤖 *Tentang Bot Jasher*

Bot Jasher adalah bot multifungsi yang dirancang untuk membantu mengelola grup dan melakukan obfuscation JavaScript dengan berbagai metode enkripsi.

*Fitur:*
- 🔒 Multiple Obfuscation Methods
- 👥 Group Management
- 📢 Broadcast System
- ⭐ Premium Features

*Developer:* @ginaaforyou
*Website:* y2beta.web.id
*Version:* 2.0.0
*Update:* ${moment().format('DD MMMM YYYY')}
        `);
    });
    
    // Menu command
    bot.command('menu', async (ctx) => {
        const sender = getUsername(ctx.from);
        const isCreator = isOwner(ctx.from.id);
        
        const menuText = `
╭─❒ 「 User Info 」 
├ Owner : ${isCreator ? 'True' : 'False'}
├ Name : ${ctx.from.first_name}${ctx.from.last_name ? ` ${ctx.from.last_name}` : ''}
├ Profile : ${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`;
        
        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('🤖 Jasher Menu', 'jasher_menu')],
            [Markup.button.callback('👑 Owner Menu', 'owner_menu'), Markup.button.callback('🔒 Obf Menu', 'obf_menu')],
            [Markup.button.callback('🔄 Kembali', 'main_menu')]
        ]);
        
        await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
            caption: menuText,
            parse_mode: 'Markdown',
            ...keyboard
        });
    });
    
    // Obfuscation commands
    setupObfuscationCommands(bot);
    
    // Owner commands
    setupOwnerCommands(bot);
    
    // Group admin commands
    setupGroupAdminCommands(bot);
    
    // Callback queries handler
    setupCallbackQueries(bot);
}

// Setup obfuscation commands
function setupObfuscationCommands(bot) {
    // enc3 command - Mandarin obfuscation
    bot.command("enc3", async (ctx) => {
        users.add(ctx.from.id);
        saveUsers(users);

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown(`
╭━━━「 ❌ ERROR 」━━━⬣
│ Terjadi kesalahan saat
│ memproses file!
╰━━━━━━━━━━━━━━━━⬣`);
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown(`
╭━━━「 ❌ ERROR 」━━━⬣
│ File harus berekstensi .js!
╰━━━━━━━━━━━━━━━━⬣`);
        }

        const encryptedPath = path.join(__dirname, "../temp", `china-encrypted-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                ` ⚙️ Memulai (Hardened Mandarin) (1%)\n` +
                ` ${createProgressBar(1)}\n` +
                "```\n" +
                "PROSES ENCRYPT "
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk Mandarin obfuscation: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            log(`Memvalidasi kode: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode tidak valid: ${syntaxError.message}`);
            }

            log(`Mengenkripsi file dengan gaya Mandarin yang diperkuat`);
            await updateProgress(
                ctx,
                progressMessage,
                40,
                "Inisialisasi Hardened Mandarin Obfuscation"
            );
            const obfuscated = await JsConfuser.obfuscate(
                fileContent,
                getMandarinObfuscationConfig()
            );
            await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
            await fs.writeFile(encryptedPath, obfuscated.code);
            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

            log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
            try {
                new Function(obfuscated.code);
            } catch (postObfuscationError) {
                throw new Error(
                    `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
                );
            }

            log(`Mengirim file terenkripsi gaya Mandarin: ${file.file_name}`);
            await ctx.replyWithDocument(
                { source: encryptedPath, filename: `china-encrypted-${file.file_name}` },
                {
                    caption: "✅ *File terenkripsi (Hardened Mandarin) siap!*\nSUKSES ENCRYPT 🕊",
                    parse_mode: "Markdown",
                }
            );
            await updateProgress(
                ctx,
                progressMessage,
                100,
                "Hardened Mandarin Obfuscation Selesai"
            );

            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus: ${encryptedPath}`);
            }
        } catch (error) {
            log("Kesalahan saat Mandarin obfuscation", error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
            );
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus setelah error: ${encryptedPath}`);
            }
        }
    });

    // enc4 command - Arab obfuscation
    bot.command("enc4", async (ctx) => {
        users.add(ctx.from.id);
        saveUsers(users);

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc4`!");
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const encryptedPath = path.join(__dirname, "../temp", `arab-encrypted-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                ` ⚙️ Memulai (Hardened Arab) (1%)\n` +
                ` ${createProgressBar(1)}\n` +
                "```\n" +
                "PROSES ENCRYPT"
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk Arab obfuscation: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            log(`Memvalidasi kode: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode tidak valid: ${syntaxError.message}`);
            }

            log(`Mengenkripsi file dengan gaya Arab yang diperkuat`);
            await updateProgress(
                ctx,
                progressMessage,
                40,
                "Inisialisasi Hardened Arab Obfuscation"
            );
            const obfuscated = await JsConfuser.obfuscate(
                fileContent,
                getArabObfuscationConfig()
            );
            await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
            await fs.writeFile(encryptedPath, obfuscated.code);
            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

            log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
            try {
                new Function(obfuscated.code);
            } catch (postObfuscationError) {
                throw new Error(
                    `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
                );
            }

            log(`Mengirim file terenkripsi gaya Arab: ${file.file_name}`);
            await ctx.replyWithDocument(
                { source: encryptedPath, filename: `arab-encrypted-${file.file_name}` },
                {
                    caption: "✅ *File terenkripsi (Hardened Arab) siap!*\nSUKSES ENCRYPT 🕊",
                    parse_mode: "Markdown",
                }
            );
            await updateProgress(
                ctx,
                progressMessage,
                100,
                "Hardened Arab Obfuscation Selesai"
            );

            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus: ${encryptedPath}`);
            }
        } catch (error) {
            log("Kesalahan saat Arab obfuscation", error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
            );
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus setelah error: ${encryptedPath}`);
            }
        }
    });

    // japan command - Japan obfuscation
    bot.command("japan", async (ctx) => {
        users.add(ctx.from.id);
        saveUsers(users);

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/japan`!");
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const encryptedPath = path.join(__dirname, "../temp", `japan-encrypted-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                ` ⚙️ Memulai (Hardened Japan) (1%)\n` +
                ` ${createProgressBar(1)}\n` +
                "```\n" +
                "PROSES ENCRYPT "
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk Japan obfuscation: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            log(`Memvalidasi kode: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode tidak valid: ${syntaxError.message}`);
            }

            log(`Mengenkripsi file dengan gaya Japan yang diperkuat`);
            await updateProgress(
                ctx,
                progressMessage,
                40,
                "Inisialisasi Hardened Japan Obfuscation"
            );
            const obfuscated = await JsConfuser.obfuscate(
                fileContent,
                getJapanObfuscationConfig()
            );
            await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
            await fs.writeFile(encryptedPath, obfuscated.code);
            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

            log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
            try {
                new Function(obfuscated.code);
            } catch (postObfuscationError) {
                throw new Error(
                    `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
                );
            }

            log(`Mengirim file terenkripsi gaya Japan: ${file.file_name}`);
            await ctx.replyWithDocument(
                { source: encryptedPath, filename: `japan-encrypted-${file.file_name}` },
                {
                    caption: "✅ *File terenkripsi (Hardened Japan) siap!*\nSUKSES ENCRYPT 🕊",
                    parse_mode: "Markdown",
                }
            );
            await updateProgress(
                ctx,
                progressMessage,
                100,
                "Hardened Japan Obfuscation Selesai"
            );

            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus: ${encryptedPath}`);
            }
        } catch (error) {
            log("Kesalahan saat Japan obfuscation", error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
            );
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus setelah error: ${encryptedPath}`);
            }
        }
    });

    // deobfuscate command
    bot.command("deobfuscate", async (ctx) => {
        users.add(ctx.from.id);
        saveUsers(users);

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown(
                "❌ *Error:* Balas file .js yang diobfuscate dengan `/deobfuscate`!"
            );
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const deobfuscatedPath = path.join(__dirname, "../temp", `deobfuscated-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                ` ⚙️ Memulai Deobfuscation (1%)\n` +
                ` ${createProgressBar(1)}\n` +
                "```\n" +
                "PROSES ENCRYPT "
            );

            // Mengunduh file
            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk deobfuscation: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            // Validasi kode awal
            log(`Memvalidasi kode awal: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode Awal");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
            }

            // Proses deobfuscation dengan webcrack
            log(`Memulai deobfuscation dengan webcrack: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 40, "Memulai Deobfuscation");
            const result = await webcrack(fileContent); // Pastikan await digunakan
            let deobfuscatedCode = result.code;

            // Penanganan jika kode dibundel
            let bundleInfo = "";
            if (result.bundle) {
                bundleInfo = "// Detected as bundled code (e.g., Webpack/Browserify)\n";
                log(`Kode terdeteksi sebagai bundel: ${file.file_name}`);
            }

            // Jika tidak ada perubahan signifikan atau hasil bukan string
            if (
                !deobfuscatedCode ||
                typeof deobfuscatedCode !== "string" ||
                deobfuscatedCode.trim() === fileContent.trim()
            ) {
                log(
                    `Webcrack tidak dapat mendekode lebih lanjut atau hasil bukan string: ${file.file_name}`
                );
                deobfuscatedCode = `${bundleInfo}// Webcrack tidak dapat mendekode sepenuhnya atau hasil invalid\n${fileContent}`;
            }

            // Validasi kode hasil
            log(`Memvalidasi kode hasil deobfuscation: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 60, "Memvalidasi Kode Hasil");
            let isValid = true;
            try {
                new Function(deobfuscatedCode);
                log(`Kode hasil valid: ${deobfuscatedCode.substring(0, 50)}...`);
            } catch (syntaxError) {
                log(`Kode hasil tidak valid: ${syntaxError.message}`);
                deobfuscatedCode = `${bundleInfo}// Kesalahan validasi: ${syntaxError.message}\n${deobfuscatedCode}`;
                isValid = false;
            }

            // Simpan hasil
            await updateProgress(ctx, progressMessage, 80, "Menyimpan Hasil");
            await fs.writeFile(deobfuscatedPath, deobfuscatedCode);

            // Kirim hasil
            log(`Mengirim file hasil deobfuscation: ${file.file_name}`);
            await ctx.replyWithDocument(
                { source: deobfuscatedPath, filename: `deobfuscated-${file.file_name}` },
                {
                    caption: `✅ *File berhasil dideobfuscate!${isValid ? "" : " (Perhatikan pesan error dalam file)"}*\nSUKSES ENCRYPT 🕊`,
                    parse_mode: "Markdown",
                }
            );
            await updateProgress(ctx, progressMessage, 100, "Deobfuscation Selesai");

            // Hapus file sementara
            if (await fs.pathExists(deobfuscatedPath)) {
                await fs.unlink(deobfuscatedPath);
                log(`File sementara dihapus: ${deobfuscatedPath}`);
            }
        } catch (error) {
            log("Kesalahan saat deobfuscation", error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan file Javascript yang valid!_`
            );
            if (await fs.pathExists(deobfuscatedPath)) {
                await fs.unlink(deobfuscatedPath);
                log(`File sementara dihapus setelah error: ${deobfuscatedPath}`);
            }
        }
    });

    // zenc command - Invisible obfuscation
    bot.command("zenc", async (ctx) => {
        users.add(ctx.from.id);
        saveUsers(users);

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/zenc`!");
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const encryptedPath = path.join(__dirname, "../temp", `invisible-encrypted-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                ` ⚙️ Memulai (InvisiBle) (1%)\n` +
                ` ${createProgressBar(1)}\n` +
                "```\n" +
                "PROSES ENCRYPT "
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk Strong obfuscation: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            log(`Memvalidasi kode awal: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode tidak valid: ${syntaxError.message}`);
            }

            log(`Mengenkripsi file dengan gaya Strong`);
            await updateProgress(
                ctx,
                progressMessage,
                40,
                "Inisialisasi Hardened Invisible Obfuscation"
            );
            const obfuscated = await JsConfuser.obfuscate(
                fileContent,
                getStrongObfuscationConfig()
            );
            let obfuscatedCode = obfuscated.code || obfuscated; // Pastikan string
            if (typeof obfuscatedCode !== "string") {
                throw new Error("Hasil obfuscation bukan string");
            }
            log(
                `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(0, 50)}...`
            );
            await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");

            log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
            try {
                new Function(obfuscatedCode);
            } catch (postObfuscationError) {
                throw new Error(
                    `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
                );
            }

            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
            await fs.writeFile(encryptedPath, obfuscatedCode);

            log(`Mengirim file terenkripsi gaya Invisible: ${file.file_name}`);
            await ctx.replyWithDocument(
                {
                    source: encryptedPath,
                    filename: `Invisible-encrypted-${file.file_name}`,
                },
                {
                    caption: "✅ *File terenkripsi (Invisible) siap!*\nSUKSES ENCRYPT 🕊",
                    parse_mode: "Markdown",
                }
            );
            await updateProgress(
                ctx,
                progressMessage,
                100,
                "Hardened Invisible Obfuscation Selesai"
            );

            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus: ${encryptedPath}`);
            }
        } catch (error) {
            log("Kesalahan saat Invisible obfuscation", error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
            );
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus setelah error: ${encryptedPath}`);
            }
        }
    });

    // xx command - Custom name obfuscation
    bot.command("xx", async (ctx) => {
        users.add(ctx.from.id);
        saveUsers(users);

        // Ambil nama kustom dari perintah
        const args = ctx.message.text.split(" ");
        if (args.length < 2 || !args[1]) {
            return ctx.replyWithMarkdown(
                "❌ *Error:* Gunakan format `/enc <nama>` dengan nama kustom!"
            );
        }
        const customName = args[1].replace(/[^a-zA-Z0-9_]/g, ""); // Sanitasi input, hanya huruf, angka, dan underscore
        if (!customName) {
            return ctx.replyWithMarkdown(
                "❌ *Error:* Nama kustom harus berisi huruf, angka, atau underscore!"
            );
        }

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown(
                "❌ *Error:* Balas file .js dengan `/enc <nama>`!"
            );
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const encryptedPath = path.join(__dirname, "../temp", `custom-${customName}-encrypted-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                ` ⚙️ Memulai (Hardened Custom: ${customName}) (1%)\n` +
                ` ${createProgressBar(1)}\n` +
                "```\n" +
                "PROSES ENCRYPT "
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk Custom obfuscation: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            log(`Memvalidasi kode awal: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
            }

            log(`Mengenkripsi file dengan gaya Custom (${customName}) yang diperkuat`);
            await updateProgress(
                ctx,
                progressMessage,
                40,
                "Inisialisasi Hardened Custom Obfuscation"
            );
            const obfuscated = await JsConfuser.obfuscate(
                fileContent,
                getCustomObfuscationConfig(customName)
            );
            log(
                `Hasil obfuscation (50 char pertama): ${obfuscated.code.substring(0, 50)}...`
            );
            await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");

            log(`Memvalidasi kode hasil obfuscation: ${file.file_name}`);
            try {
                new Function(obfuscated.code);
            } catch (postObfuscationError) {
                log(`Kode hasil obfuscation tidak valid: ${postObfuscationError.message}`);
                throw new Error(
                    `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
                );
            }

            await fs.writeFile(encryptedPath, obfuscated.code);
            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

            log(`Mengirim file terenkripsi gaya Custom: ${file.file_name}`);
            await ctx.replyWithDocument(
                {
                    source: encryptedPath,
                    filename: `custom-${customName}-encrypted-${file.file_name}`,
                },
                {
                    caption: `✅ *File terenkripsi (Hardened Custom: ${customName}) siap!*\nSUKSES ENCRYPT 🕊`,
                    parse_mode: "Markdown",
                }
            );
            await updateProgress(
                ctx,
                progressMessage,
                100,
                `Hardened Custom (${customName}) Obfuscation Selesai`
            );

            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus: ${encryptedPath}`);
            }
        } catch (error) {
            log("Kesalahan saat Custom obfuscation", error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
            );
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus setelah error: ${encryptedPath}`);
            }
        }
    });

    // quantum command - Quantum obfuscation
    bot.command("quantum", async (ctx) => {
        users.add(ctx.from.id);
        saveUsers(users);

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/quantum`!");
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const encryptedPath = path.join(__dirname, "../temp", `quantum-encrypted-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                " ⚙️ Memulai (Quantum Vortex Encryption) (1%)\n" +
                " " + createProgressBar(1) + "\n" +
                "```\n" +
                "PROSES ENCRYPT "
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk Quantum Vortex Encryption: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            log(`Memvalidasi kode awal: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
            }

            log(`Mengenkripsi file dengan Quantum Vortex Encryption`);
            await updateProgress(
                ctx,
                progressMessage,
                40,
                "Inisialisasi Quantum Vortex Encryption"
            );
            const obfuscatedCode = await obfuscateQuantum(fileContent);
            log(`Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(0, 50)}...`);
            log(`Ukuran file setelah obfuscation: ${Buffer.byteLength(obfuscatedCode, "utf-8")} bytes`);

            log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
            try {
                new Function(obfuscatedCode);
            } catch (postObfuscationError) {
                log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
                throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
            }

            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
            await fs.writeFile(encryptedPath, obfuscatedCode);

            log(`Mengirim file terenkripsi quantum: ${file.file_name}`);
            await ctx.replyWithDocument(
                {
                    source: encryptedPath,
                    filename: `quantum-encrypted-${file.file_name}`,
                },
                {
                    caption: "✅ *File terenkripsi (Quantum Vortex Encryption) siap!*\nSUKSES ENCRYPT 🕊",
                    parse_mode: "Markdown",
                }
            );
            await updateProgress(ctx, progressMessage, 100, "Quantum Vortex Encryption Selesai");

            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus: ${encryptedPath}`);
            }
        } catch (error) {
            log("Kesalahan saat Quantum obfuscation", error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
            );
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus setelah error: ${encryptedPath}`);
            }
        }
    });

    // var command - Var obfuscation
    bot.command("var", async (ctx) => {
        users.add(ctx.from.id);
        saveUsers(users);

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/var`!");
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const encryptedPath = path.join(__dirname, "../temp", `var-encrypted-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                " ⚙️ Memulai (Var) (1%)\n" +
                " " + createProgressBar(1) + "\n" +
                "```\n" +
                "PROSES ENCRYPT "
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk Var obfuscation: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            log(`Memvalidasi kode awal: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
            }

            log(`Mengenkripsi file dengan gaya Var`);
            await updateProgress(ctx, progressMessage, 40, "Inisialisasi Var Dynamic Obfuscation");
            const obfuscated = await JsConfuser.obfuscate(fileContent, getNovaObfuscationConfig());
            let obfuscatedCode = obfuscated.code || obfuscated;
            if (typeof obfuscatedCode !== "string") {
                throw new Error("Hasil obfuscation bukan string");
            }
            log(`Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(0, 50)}...`);

            log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
            try {
                new Function(obfuscatedCode);
            } catch (postObfuscationError) {
                log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
                throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
            }

            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
            await fs.writeFile(encryptedPath, obfuscatedCode);

            log(`Mengirim file terenkripsi gaya Var: ${file.file_name}`);
            await ctx.replyWithDocument(
                { source: encryptedPath, filename: `Var-encrypted-${file.file_name}` },
                {
                    caption: "✅ *File terenkripsi (Var) siap!*\nSUKSES ENCRYPT 🕊",
                    parse_mode: "Markdown",
                }
            );
            await updateProgress(ctx, progressMessage, 100, "Var Obfuscation Selesai");

            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus: ${encryptedPath}`);
            }
        } catch (error) {
            log("Kesalahan saat Nova obfuscation", error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
            );
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus setelah error: ${encryptedPath}`);
            }
        }
    });

    // nebula command - Nebula obfuscation
    bot.command("nebula", async (ctx) => {
        users.add(ctx.from.id);
        saveUsers(users);

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/nebula`!");
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const encryptedPath = path.join(__dirname, "../temp", `nebula-encrypted-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                " ⚙️ Memulai (Nebula Polymorphic Storm) (1%)\n" +
                " " + createProgressBar(1) + "\n" +
                "```\n" +
                "PROSES ENCRYPT "
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk Nebula obfuscation: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            log(`Memvalidasi kode awal: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
            }

            log(`Mengenkripsi file dengan gaya Nebula`);
            await updateProgress(ctx, progressMessage, 40, "Inisialisasi Nebula Polymorphic Storm");
            const obfuscated = await JsConfuser.obfuscate(fileContent, getNebulaObfuscationConfig());
            let obfuscatedCode = obfuscated.code || obfuscated;
            if (typeof obfuscatedCode !== "string") {
                throw new Error("Hasil obfuscation bukan string");
            }
            log(`Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(0, 50)}...`);
            log(`Ukuran file setelah obfuscation: ${Buffer.byteLength(obfuscatedCode, "utf-8")} bytes`);

            log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
            try {
                new Function(obfuscatedCode);
            } catch (postObfuscationError) {
                log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
                throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
            }

            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
            await fs.writeFile(encryptedPath, obfuscatedCode);

            log(`Mengirim file terenkripsi gaya Nebula: ${file.file_name}`);
            await ctx.replyWithDocument(
                { source: encryptedPath, filename: `nebula-encrypted-${file.file_name}` },
                {
                    caption: "✅ *File terenkripsi (Nebula Polymorphic Storm) siap!*\nSUKSES ENCRYPT 🕊",
                    parse_mode: "Markdown",
                }
            );
            await updateProgress(ctx, progressMessage, 100, "Nebula Polymorphic Storm Selesai");

            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus: ${encryptedPath}`);
            }
        } catch (error) {
            log("Kesalahan saat Nebula obfuscation", error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
            );
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus setelah error: ${encryptedPath}`);
            }
        }
    });

    // enc5 command - Siu+Calcrick obfuscation
    bot.command("enc5", async (ctx) => {
        users.add(ctx.from.id);
        saveUsers(users);

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc5`!");
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const encryptedPath = path.join(__dirname, "../temp", `siucalcrick-encrypted-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                " ⚙️ Memulai (Calcrick Chaos Core) (1%)\n" +
                " " + createProgressBar(1) + "\n" +
                "```\n" +
                "PROSES ENCRYPT "
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk Siu+Calcrick obfuscation: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            log(`Memvalidasi kode awal: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
            }

            log(`Mengenkripsi file dengan gaya Siu+Calcrick`);
            await updateProgress(ctx, progressMessage, 40, "Inisialisasi Calcrick Chaos Core");
            const obfuscated = await JsConfuser.obfuscate(fileContent, getSiuCalcrickObfuscationConfig());
            let obfuscatedCode = obfuscated.code || obfuscated;
            if (typeof obfuscatedCode !== "string") {
                throw new Error("Hasil obfuscation bukan string");
            }
            log(`Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(0, 50)}...`);
            log(`Ukuran file setelah obfuscation: ${Buffer.byteLength(obfuscatedCode, "utf-8")} bytes`);

            log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
            try {
                new Function(obfuscatedCode);
            } catch (postObfuscationError) {
                log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
                throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
            }

            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
            await fs.writeFile(encryptedPath, obfuscatedCode);

            log(`Mengirim file terenkripsi gaya Siu+Calcrick: ${file.file_name}`);
            await ctx.replyWithDocument(
                {
                    source: encryptedPath,
                    filename: `siucalcrick-encrypted-${file.file_name}`,
                },
                {
                    caption: "✅ *File terenkripsi (Calcrick Chaos Core) siap!*\nSUKSES ENCRYPT 🕊",
                    parse_mode: "Markdown",
                }
            );
            await updateProgress(ctx, progressMessage, 100, "Calcrick Chaos Core Selesai");

            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus: ${encryptedPath}`);
            }
        } catch (error) {
            log("Kesalahan saat Siu+Calcrick obfuscation", error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
            );
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus setelah error: ${encryptedPath}`);
            }
        }
    });

    // enc2 command - Custom text obfuscation
    bot.command("enc2", async (ctx) => {
        users.add(ctx.from.id);
        saveUsers(users);

        const customString = ctx.message.text.split(" ")[1];

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc2 <text>`!");
        }

        if (!customString) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc2 <text>`!");
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const encryptedPath = path.join(__dirname, "../temp", `custom-encrypted-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                " ⚙️ Memulai (custom enc) (1%)\n" +
                " " + createProgressBar(1) + "\n" +
                "```\n" +
                "PROSES ENCRYPT "
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk custom obfuscation: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            log(`Memvalidasi kode awal: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
            }

            log(`Mengenkripsi file dengan gaya custom (${customString})`);
            await updateProgress(ctx, progressMessage, 40, `Inisialisasi custom (${customString})`);

            const obfuscated = await JsConfuser.obfuscate(fileContent, getCustomObfuscationConfig(customString));
            let obfuscatedCode = obfuscated.code || obfuscated;
            if (typeof obfuscatedCode !== "string") {
                throw new Error("Hasil obfuscation bukan string");
            }
            log(`Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(0, 50)}...`);
            log(`Ukuran file setelah obfuscation: ${Buffer.byteLength(obfuscatedCode, "utf-8")} bytes`);

            log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
            try {
                new Function(obfuscatedCode);
            } catch (postObfuscationError) {
                log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
                throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
            }

            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
            await fs.writeFile(encryptedPath, obfuscatedCode);

            log(`Mengirim file terenkripsi gaya custom (${customString}): ${file.file_name}`);
            await ctx.replyWithDocument(
                {
                    source: encryptedPath,
                    filename: `custom-encrypted-${file.file_name}`,
                },
                {
                    caption: `✅ *File terenkripsi custom (${customString}) siap!*\nSUKSES ENCRYPT 🕊`,
                    parse_mode: "Markdown",
                }
            );
            await updateProgress(ctx, progressMessage, 100, `custom (${customString}) Selesai`);

            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus: ${encryptedPath}`);
            }
        } catch (error) {
            log("Kesalahan saat custom enc obfuscation", error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
            );
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus setelah error: ${encryptedPath}`);
            }
        }
    });

    // enc command - Time-locked obfuscation
    bot.command("enc", async (ctx) => {
        users.add(ctx.from.id);
        saveUsers(users);

        const args = ctx.message.text.split(" ").slice(1);
        if (args.length !== 1 || !/^\d+$/.test(args[0]) || parseInt(args[0]) < 1 || parseInt(args[0]) > 365) {
            return ctx.replyWithMarkdown(
                "❌ *Error:* Gunakan format `/locked [1-365]` untuk jumlah hari (misal: `/enc 7`)!"
            );
        }

        const days = args[0];
        const expiryDate = new Date();
        expiryDate.setDate(expiryDate.getDate() + parseInt(days));
        const expiryFormatted = expiryDate.toLocaleDateString();

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc [1-365]`!");
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const encryptedPath = path.join(__dirname, "../temp", `locked-encrypted-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                " ⚙️ Memulai (Time-Locked Encryption) (1%)\n" +
                " " + createProgressBar(1) + "\n" +
                "```\n" +
                "PROSES ENCRYPT "
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk Time-Locked Encryption: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            log(`Memvalidasi kode awal: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
            }

            log(`Mengenkripsi file dengan Time-Locked Encryption`);
            await updateProgress(ctx, progressMessage, 40, "Inisialisasi Time-Locked Encryption");
            const obfuscatedCode = await obfuscateTimeLocked(fileContent, days);
            log(`Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(0, 50)}...`);
            log(`Ukuran file setelah obfuscation: ${Buffer.byteLength(obfuscatedCode, "utf-8")} bytes`);

            log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
            try {
                new Function(obfuscatedCode);
            } catch (postObfuscationError) {
                log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
                throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
            }

            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
            await fs.writeFile(encryptedPath, obfuscatedCode);

            log(`Mengirim file terenkripsi time-locked: ${file.file_name}`);
            await ctx.replyWithMarkdown(
                `✅ *File terenkripsi (Time-Locked Encryption) siap!*\n` +
                `⏰ Masa aktif: ${days} hari (Kedaluwarsa: ${expiryFormatted})\n` +
                `_Powered by Ginaa_`,
                { parse_mode: "Markdown" }
            );
            await ctx.replyWithDocument({
                source: encryptedPath,
                filename: `locked-encrypted-${file.file_name}`,
            });
            await updateProgress(ctx, progressMessage, 100, "Time-Locked Encryption Selesai");

            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus: ${encryptedPath}`);
            }
        } catch (error) {
            log("Kesalahan saat Time-Locked obfuscation", error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
            );
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus setelah error: ${encryptedPath}`);
            }
        }
    });
}

// Setup owner commands
function setupOwnerCommands(bot) {
    // addprem command - Add premium user
    bot.command('addprem', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
        }
        
        const args = ctx.message.text.split(' ');
        if (args.length < 3) {
            return ctx.reply('❌ Format: /addprem <user_id> <days>');
        }
        
        const userId = parseInt(args[1]);
        const days = parseInt(args[2]);
        
        if (isNaN(userId) || isNaN(days) || days <= 0) {
            return ctx.reply('❌ Format: /addprem <user_id> <days> (days harus angka positif)');
        }
        
        const expiryDate = new Date();
        expiryDate.setDate(expiryDate.getDate() + days);
        
        premiumUsers.set(userId, { expiry: expiryDate.toISOString() });
        savePremiumUsers(premiumUsers);
        
        ctx.reply(`✅ User ${userId} telah ditambahkan sebagai premium selama ${days} hari. Berlaku hingga: ${expiryDate.toLocaleDateString()}`);
        
        try {
            await ctx.telegram.sendMessage(userId, `🎉 Selamat! Anda sekarang pengguna premium Jasher Bot selama ${days} hari. Berlaku hingga: ${expiryDate.toLocaleDateString()}`);
        } catch (error) {
            console.log(`Tidak dapat mengirim pesan ke user ${userId}: ${error.message}`);
        }
    });
    
    // delprem command - Remove premium user
    bot.command('delprem', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
        }
        
        const args = ctx.message.text.split(' ');
        if (args.length < 2) {
            return ctx.reply('❌ Format: /delprem <user_id>');
        }
        
        const userId = parseInt(args[1]);
        
        if (isNaN(userId)) {
            return ctx.reply('❌ Format: /delprem <user_id> (user_id harus angka)');
        }
        
        if (premiumUsers.has(userId)) {
            premiumUsers.delete(userId);
            savePremiumUsers(premiumUsers);
            ctx.reply(`✅ User ${userId} telah dihapus dari daftar premium.`);
            
            try {
                await ctx.telegram.sendMessage(userId, '❌ Status premium Anda telah dihapus oleh owner.');
            } catch (error) {
                console.log(`Tidak dapat mengirim pesan ke user ${userId}: ${error.message}`);
            }
        } else {
            ctx.reply(`❌ User ${userId} tidak ditemukan dalam daftar premium.`);
        }
    });
    
    // listprem command - List premium users
    bot.command('listprem', (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
        }
        
        if (premiumUsers.size === 0) {
            return ctx.reply('❌ Tidak ada pengguna premium saat ini.');
        }
        
        let listText = '📋 Daftar Pengguna Premium:\n\n';
        const now = new Date();
        
        premiumUsers.forEach((data, userId) => {
            const expiry = new Date(data.expiry);
            const remainingDays = Math.ceil((expiry - now) / (1000 * 60 * 60 * 24));
            const status = remainingDays > 0 ? `✅ (${remainingDays} hari lagi)` : '❌ (Kadaluarsa)';
            
            listText += `👤 User ID: ${userId}\n⏰ Berlaku hingga: ${expiry.toLocaleDateString()}\n${status}\n\n`;
        });
        
        ctx.reply(listText);
    });
    
    // addbl command - Add group to blacklist
    bot.command('addbl', (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
        }
        
        const args = ctx.message.text.split(' ');
        if (args.length < 2) {
            return ctx.reply('❌ Format: /addbl <group_id>');
        }
        
        const groupId = args[1];
        
        if (blacklistGroups.has(groupId)) {
            ctx.reply(`❌ Group ${groupId} sudah ada dalam blacklist.`);
        } else {
            blacklistGroups.add(groupId);
            saveBlacklistGroups(blacklistGroups);
            ctx.reply(`✅ Group ${groupId} telah ditambahkan ke blacklist.`);
        }
    });
    
    // delbl command - Remove group from blacklist
    bot.command('delbl', (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
        }
        
        const args = ctx.message.text.split(' ');
        if (args.length < 2) {
            return ctx.reply('❌ Format: /delbl <group_id>');
        }
        
        const groupId = args[1];
        
        if (blacklistGroups.has(groupId)) {
            blacklistGroups.delete(groupId);
            saveBlacklistGroups(blacklistGroups);
            ctx.reply(`✅ Group ${groupId} telah dihapus dari blacklist.`);
        } else {
            ctx.reply(`❌ Group ${groupId} tidak ditemukan dalam blacklist.`);
        }
    });
    
    // listbl command - List blacklisted groups
    bot.command('listbl', (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
        }
        
        if (blacklistGroups.size === 0) {
            return ctx.reply('❌ Tidak ada group dalam blacklist saat ini.');
        }
        
        let listText = '📋 Daftar Group Blacklist:\n\n';
        
        blacklistGroups.forEach(groupId => {
            listText += `👥 Group ID: ${groupId}\n`;
        });
        
        ctx.reply(listText);
    });
    
    // bc command - Broadcast to all users
    bot.command('bc', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
        }
        
        const messageText = ctx.message.text.split(' ').slice(1).join(' ');
        
        if (!messageText) {
            return ctx.reply('❌ Format: /bc <pesan>');
        }
        
        const usersArray = Array.from(users);
        let successCount = 0;
        let failCount = 0;
        
        const progressMessage = await ctx.reply(`📢 Mengirim broadcast ke ${usersArray.length} pengguna...\n\n✅ Berhasil: ${successCount}\n❌ Gagal: ${failCount}`);
        
        for (const userId of usersArray) {
            try {
                await ctx.telegram.sendMessage(userId, `📢 *Broadcast dari Owner:*\n\n${messageText}`, { parse_mode: 'Markdown' });
                successCount++;
                
                // Update progress every 10 messages
                if (successCount % 10 === 0) {
                    await ctx.telegram.editMessageText(
                        progressMessage.chat.id,
                        progressMessage.message_id,
                        null,
                        `📢 Mengirim broadcast ke ${usersArray.length} pengguna...\n\n✅ Berhasil: ${successCount}\n❌ Gagal: ${failCount}`
                    );
                }
                
                // Delay to avoid rate limiting
                await new Promise(resolve => setTimeout(resolve, 100));
            } catch (error) {
                failCount++;
                console.log(`Gagal mengirim broadcast ke ${userId}: ${error.message}`);
            }
        }
        
        await ctx.telegram.editMessageText(
            progressMessage.chat.id,
            progressMessage.message_id,
            null,
            `✅ Broadcast selesai!\n\n📊 Statistik:\n✅ Berhasil: ${successCount}\n❌ Gagal: ${failCount}`
        );
    });
    
    // listgrup command - List all groups
    bot.command('listgrup', (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
        }
        
        if (groups.size === 0) {
            return ctx.reply('❌ Bot belum ditambahkan ke grup manapun.');
        }
        
        let listText = '📋 Daftar Grup Aktif:\n\n';
        
        groups.forEach(groupId => {
            listText += `👥 Group ID: ${groupId}\n`;
        });
        
        ctx.reply(listText);
    });
}

// Setup group admin commands
function setupGroupAdminCommands(bot) {
    // antispam command - Toggle anti-spam
    bot.command('antispam', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ Command ini hanya dapat digunakan di grup!');
        }
        
        // Check if user is admin
        try {
            const chatMember = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(chatMember.status)) {
                return ctx.reply('❌ Hanya admin yang dapat menggunakan command ini!');
            }
        } catch (error) {
            return ctx.reply('❌ Gagal memverifikasi status admin.');
        }
        
        const groupId = ctx.chat.id.toString();
        let settings = groupSettings.get(groupId) || {};
        
        settings.antispam = !settings.antispam;
        groupSettings.set(groupId, settings);
        saveGroupSettings(groupSettings);
        
        ctx.reply(`✅ Anti-spam ${settings.antispam ? 'diaktifkan' : 'dinonaktifkan'}!`);
    });
    
    // noevent command - Toggle no event
    bot.command('noevent', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ Command ini hanya dapat digunakan di grup!');
        }
        
        // Check if user is admin
        try {
            const chatMember = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(chatMember.status)) {
                return ctx.reply('❌ Hanya admin yang dapat menggunakan command ini!');
            }
        } catch (error) {
            return ctx.reply('❌ Gagal memverifikasi status admin.');
        }
        
        const groupId = ctx.chat.id.toString();
        let settings = groupSettings.get(groupId) || {};
        
        settings.noevent = !settings.noevent;
        groupSettings.set(groupId, settings);
        saveGroupSettings(groupSettings);
        
        ctx.reply(`✅ No event ${settings.noevent ? 'diaktifkan' : 'dinonaktifkan'}!`);
    });
    
    // nolinks command - Toggle no links
    bot.command('nolinks', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ Command ini hanya dapat digunakan di grup!');
        }
        
        // Check if user is admin
        try {
            const chatMember = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(chatMember.status)) {
                return ctx.reply('❌ Hanya admin yang dapat menggunakan command ini!');
            }
        } catch (error) {
            return ctx.reply('❌ Gagal memverifikasi status admin.');
        }
        
        const groupId = ctx.chat.id.toString();
        let settings = groupSettings.get(groupId) || {};
        
        settings.nolinks = !settings.nolinks;
        groupSettings.set(groupId, settings);
        saveGroupSettings(groupSettings);
        
        ctx.reply(`✅ No links ${settings.nolinks ? 'diaktifkan' : 'dinonaktifkan'}!`);
    });
    
    // noforwards command - Toggle no forwards
    bot.command('noforwards', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ Command ini hanya dapat digunakan di grup!');
        }
        
        // Check if user is admin
        try {
            const chatMember = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(chatMember.status)) {
                return ctx.reply('❌ Hanya admin yang dapat menggunakan command ini!');
            }
        } catch (error) {
            return ctx.reply('❌ Gagal memverifikasi status admin.');
        }
        
        const groupId = ctx.chat.id.toString();
        let settings = groupSettings.get(groupId) || {};
        
        settings.noforwards = !settings.noforwards;
        groupSettings.set(groupId, settings);
        saveGroupSettings(groupSettings);
        
        ctx.reply(`✅ No forwards ${settings.noforwards ? 'diaktifkan' : 'dinonaktifkan'}!`);
    });
    
    // nocontacts command - Toggle no contacts
    bot.command('nocontacts', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ Command ini hanya dapat digunakan di grup!');
        }
        
        // Check if user is admin
        try {
            const chatMember = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(chatMember.status)) {
                return ctx.reply('❌ Hanya admin yang dapat menggunakan command ini!');
            }
        } catch (error) {
            return ctx.reply('❌ Gagal memverifikasi status admin.');
        }
        
        const groupId = ctx.chat.id.toString();
        let settings = groupSettings.get(groupId) || {};
        
        settings.nocontacts = !settings.nocontacts;
        groupSettings.set(groupId, settings);
        saveGroupSettings(groupSettings);
        
        ctx.reply(`✅ No contacts ${settings.nocontacts ? 'diaktifkan' : 'dinonaktifkan'}!`);
    });
    
    // nohastags command - Toggle no hashtags
    bot.command('nohastags', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ Command ini hanya dapat digunakan di grup!');
        }
        
        // Check if user is admin
        try {
            const chatMember = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(chatMember.status)) {
                return ctx.reply('❌ Hanya admin yang dapat menggunakan command ini!');
            }
        } catch (error) {
            return ctx.reply('❌ Gagal memverifikasi status admin.');
        }
        
        const groupId = ctx.chat.id.toString();
        let settings = groupSettings.get(groupId) || {};
        
        settings.nohastags = !settings.nohastags;
        groupSettings.set(groupId, settings);
        saveGroupSettings(groupSettings);
        
        ctx.reply(`✅ No hashtags ${settings.nohastags ? 'diaktifkan' : 'dinonaktifkan'}!`);
    });
    
    // nocommands command - Toggle no commands
    bot.command('nocommands', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ Command ini hanya dapat digunakan di grup!');
        }
        
        // Check if user is admin
        try {
            const chatMember = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(chatMember.status)) {
                return ctx.reply('❌ Hanya admin yang dapat menggunakan command ini!');
            }
        } catch (error) {
            return ctx.reply('❌ Gagal memverifikasi status admin.');
        }
        
        const groupId = ctx.chat.id.toString();
        let settings = groupSettings.get(groupId) || {};
        
        settings.nocommands = !settings.nocommands;
        groupSettings.set(groupId, settings);
        saveGroupSettings(groupSettings);
        
        ctx.reply(`✅ No commands ${settings.nocommands ? 'diaktifkan' : 'dinonaktifkan'}!`);
    });
    
    // settings command - Show group settings
    bot.command('settings', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ Command ini hanya dapat digunakan di grup!');
        }
        
        // Check if user is admin
        try {
            const chatMember = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(chatMember.status)) {
                return ctx.reply('❌ Hanya admin yang dapat menggunakan command ini!');
            }
        } catch (error) {
            return ctx.reply('❌ Gagal memverifikasi status admin.');
        }
        
        const groupId = ctx.chat.id.toString();
        const settings = groupSettings.get(groupId) || {};
        
        const settingsText = `
⚙️ *Pengaturan Grup:*

🔒 Anti-spam: ${settings.antispam ? '✅' : '❌'}
🎉 No event: ${settings.noevent ? '✅' : '❌'}
🔗 No links: ${settings.nolinks ? '✅' : '❌'}
↪️ No forwards: ${settings.noforwards ? '✅' : '❌'}
👤 No contacts: ${settings.nocontacts ? '✅' : '❌'}
#️⃣ No hashtags: ${settings.nohastags ? '✅' : '❌'}
⌨️ No commands: ${settings.nocommands ? '✅' : '❌'}
        `;
        
        ctx.replyWithMarkdown(settingsText);
    });
}

// Setup callback queries
function setupCallbackQueries(bot) {
    bot.action('main_menu', async (ctx) => {
        const sender = getUsername(ctx.from);
        const isCreator = isOwner(ctx.from.id);
        
        const menuText = `
╭─❒ 「 User Info 」 
├ Owner : ${isCreator ? 'True' : 'False'}
├ Name : ${ctx.from.first_name}${ctx.from.last_name ? ` ${ctx.from.last_name}` : ''}
├ Profile : ${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`;
        
        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('🤖 Jasher Menu', 'jasher_menu')],
            [Markup.button.callback('👑 Owner Menu', 'owner_menu'), Markup.button.callback('🔒 Obf Menu', 'obf_menu')],
            [Markup.button.callback('🔄 Kembali', 'main_menu')]
        ]);
        
        await ctx.editMessageCaption(menuText, {
            parse_mode: 'Markdown',
            ...keyboard
        });
        await ctx.answerCbQuery();
    });
    
    bot.action('jasher_menu', async (ctx) => {
        const jasherText = `
🤖 *Jasher Menu*

Fitur-fitur yang tersedia:

🔒 *Obfuscation:*
/enc3 - Mandarin Obfuscation
/enc4 - Arab Obfuscation
/japan - Japan Obfuscation
/zenc - Invisible Obfuscation
/xx <nama> - Custom Name Obfuscation
/quantum - Quantum Obfuscation
/var - Var Obfuscation
/nebula - Nebula Obfuscation
/enc5 - Siu+Calcrick Obfuscation
/enc2 <text> - Custom Text Obfuscation
/enc <days> - Time-Locked Obfuscation
/deobfuscate - Deobfuscate File

📢 *Sharing:*
/sharefree - Share pesan gratis
/sharevip - Share pesan premium

ℹ️ Gunakan command di atas dengan membalas file JS untuk obfuscation.
        `;
        
        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('⬅️ Kembali', 'main_menu')]
        ]);
        
        await ctx.editMessageCaption(jasherText, {
            parse_mode: 'Markdown',
            ...keyboard
        });
        await ctx.answerCbQuery();
    });
    
    bot.action('owner_menu', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            await ctx.answerCbQuery('❌ Hanya owner yang dapat mengakses menu ini!', { show_alert: true });
            return;
        }
        
        const ownerText = `
👑 *Owner Menu*

Fitur-fitur owner:

👤 *Premium Management:*
/addprem <user_id> <days> - Tambah user premium
/delprem <user_id> - Hapus user premium
/listprem - List user premium

🚫 *Blacklist Management:*
/addbl <group_id> - Tambah group ke blacklist
/delbl <group_id> - Hapus group dari blacklist
/listbl - List group blacklist

📢 *Broadcast:*
/bc <pesan> - Broadcast ke semua user

👥 *Group Management:*
/listgrup - List semua grup aktif

ℹ️ Gunakan command di atas untuk mengelola bot.
        `;
        
        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('⬅️ Kembali', 'main_menu')]
        ]);
        
        await ctx.editMessageCaption(ownerText, {
            parse_mode: 'Markdown',
            ...keyboard
        });
        await ctx.answerCbQuery();
    });
    
    bot.action('obf_menu', async (ctx) => {
        const obfText = `
🔒 *Obf Menu*

Metode Obfuscation yang tersedia:

1. 🔒 /enc3 - Mandarin Obfuscation
   - Gaya Mandarin yang diperkuat
   - Tingkat keamanan tinggi

2. 🔒 /enc4 - Arab Obfuscation  
   - Gaya Arab yang diperkuat
   - Perlindungan ekstra

3. 🔒 /japan - Japan Obfuscation
   - Gaya Japan yang diperkuat
   - Transformasi kode advanced

4. 🔒 /zenc - Invisible Obfuscation
   - Obfuscation tidak terlihat
   - Perlindungan maksimal

5. 🔒 /xx <nama> - Custom Name
   - Obfuscation dengan nama kustom
   - Personalisasi hasil

6. 🔒 /quantum - Quantum Obfuscation
   - Quantum Vortex Encryption
   - Teknologi terbaru

7. 🔒 /var - Var Obfuscation
   - Var Dynamic Obfuscation
   - Perlindungan variabel

8. 🔒 /nebula - Nebula Obfuscation
   - Nebula Polymorphic Storm
   - Perubahan bentuk terus menerus

9. 🔒 /enc5 - Siu+Calcrick Obfuscation
   - Calcrick Chaos Core
   - Tingkat kekacauan tinggi

10. 🔒 /enc2 <text> - Custom Text
    - Obfuscation dengan teks kustom
    - Hasil yang unik

11. 🔒 /enc <days> - Time-Locked
    - Enkripsi terkunci waktu
    - Masa aktif tertentu

12. 🔒 /deobfuscate - Deobfuscate
    - Buka obfuscation file
    - Hati-hati penggunaan

ℹ️ Balas file JS dengan command di atas.
        `;
        
        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('⬅️ Kembali', 'main_menu')]
        ]);
        
        await ctx.editMessageCaption(obfText, {
            parse_mode: 'Markdown',
            ...keyboard
        });
        await ctx.answerCbQuery();
    });
}

module.exports = {
    setupCommands
};