const fetch = require("node-fetch");

const settings = require("../settings.js");
const OWNER_ID = settings.ownerId;

const userStates = {};
const vpsSpecs = {
  /*r1c1: { size: "s-1vcpu-1gb", name: "1GB C1", icon: "✅" },
  r2c2: { size: "s-2vcpu-2gb", name: "2GB C2", icon: "✅" },*/
  r4c2: { size: "s-2vcpu-4gb", name: "ʀᴀᴍ 4ɢʙ ᴄ2", icon: "✅" },
  r8c4: { size: "s-4vcpu-8gb", name: "ʀᴀᴍ 8ɢʙ ᴄ4", icon: "✅" },
  r16c4: { size: "s-4vcpu-16gb-amd", name: "ʀᴀᴍ 16ɢʙ ᴄ4", icon: "✅" },
  r16c8: { size: "s-8vcpu-16gb-amd", name: "ʀᴀᴍ 16ɢʙ ᴄ8", icon: "✅" },
  r32c8: { size: "s-8vcpu-32gb-amd", name: "ʀᴀᴍ 32ɢʙ ᴄ8", icon: "✅" }
};

const vpsImages = {
  ubuntu20: { image: "ubuntu-20-04-x64", name: "Ubuntu 20.04 LTS", icon: "✅" },
  ubuntu22: { image: "ubuntu-22-04-x64", name: "Ubuntu 22.04 LTS", icon: "✅" },
  ubuntu24: { image: "ubuntu-24-04-x64", name: "Ubuntu 24.04 LTS", icon: "✅" }
};

const vpsRegions = {
  sgp1: { name: "Singapore", flag: "🇸🇬", latency: "Tercepat untuk Asia" },
  nyc1: { name: "New York", flag: "🇺🇸", latency: "USA Pantai Timur" },
  sfo3: { name: "San Francisco", flag: "🇺🇸", latency: "USA Pantai Barat" },
  lon1: { name: "London", flag: "🇬🇧", latency: "Eropa Barat" },
  fra1: { name: "Frankfurt", flag: "🇩🇪", latency: "Eropa Tengah" },
  ams3: { name: "Amsterdam", flag: "🇳🇱", latency: "Eropa Barat" },
  tor1: { name: "Toronto", flag: "🇨🇦", latency: "Amerika Utara" },
  blr1: { name: "Bangalore", flag: "🇮🇳", latency: "Asia Selatan" }
};

module.exports = (bot) => {
async function createVPSDroplet(apiKey, hostname, spec, os, region, password) {
  const dropletData = {
    name: hostname.toLowerCase().trim(),
    region,
    size: vpsSpecs[spec].size,
    image: vpsImages[os].image,
    ssh_keys: null,
    backups: false,
    ipv6: true,
    user_data: `#cloud-config\npassword: ${password}\nchpasswd: { expire: False }\nssh_pwauth: True`,
    private_networking: null,
    volumes: null,
    tags: ["AnggaDev-VPS", "pay-tama.vercel.app", new Date().toISOString().split("T")[0]]
  };

  const response = await fetch("https://api.digitalocean.com/v2/droplets", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    },
    body: JSON.stringify(dropletData)
  });

  const data = await response.json();
  if (!response.ok) throw new Error(data.message || "Failed to create VPS");
  return data.droplet.id;
}

async function getDropletIP(apiKey, dropletId) {
  const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    }
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.message || "Failed to fetch droplet info");
  return data.droplet.networks.v4.find(net => net.type === "public").ip_address;
}

async function getDropletInfo(apiKey, dropletId) {
  const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    }
  });

  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.message || `Gagal ambil info VPS (HTTP ${response.status})`);
  }

  return data.droplet;
}
    
async function getDropletInfo(apiKey, dropletId) {
  const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    }
  });

  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.message || `Gagal ambil info VPS (HTTP ${response.status})`);
  }

  return data.droplet;
}

async function deleteVPS(apiKey, dropletId) {
  const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    }
  });

  if (!response.ok) {
    const data = await response.json().catch(() => ({}));
    throw new Error(data.message || `Gagal delete VPS (HTTP ${response.status})`);
  }

  return true;
}

async function getAllVPS(apiKey) {
  const response = await fetch("https://api.digitalocean.com/v2/droplets", {
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    }
  });
  const data = await response.json();
  return data.droplets || [];
}

async function getListVps(apiKey) {
  const response = await fetch("https://api.digitalocean.com/v2/droplets", {
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    }
  });

  if (!response.ok) {
    throw new Error(`Gagal ambil daftar VPS: ${response.status} ${response.statusText}`);
  }

  const data = await response.json();
  return data.droplets || [];
}

async function getVpsDetail(apiKey, dropletId) {
  const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    }
  });

  if (!response.ok) {
    throw new Error(`Gagal ambil detail VPS: ${response.status} ${response.statusText}`);
  }

  const data = await response.json();
  return data.droplet;
}

function formatVPSStatus(status) {
  if (status === "active") return "🟢 Active"
  if (status === "off") return "🔴 Off"
  return "⚪ " + status
}

function formatUptime(createdAt) {
  const created = new Date(createdAt)
  const now = new Date()
  const diffMs = now - created
  const diffHrs = Math.floor(diffMs / 3600000)
  const diffDays = Math.floor(diffHrs / 24)
  return diffDays > 0 ? `${diffDays}d ${diffHrs % 24}h` : `${diffHrs}h`
}

bot.onText(/^\/createvps$/, async msg => {
  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(msg.chat.id, `❌ Kamu bukan @${settings.dev}!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
  }

  const keyboard = [
    [{ text: "🌐 DO 1", callback_data: "createvps_1" }],
    [{ text: "🌐 DO 2", callback_data: "createvps_2" }],
    [{ text: "🌐 DO 3", callback_data: "createvps_3" }]
  ];

  bot.sendMessage(msg.chat.id, `📡 *ᴍᴇɴᴜ ᴄʀᴇᴀᴛᴇ ᴠᴘꜱ ᴏᴛᴏᴍᴀᴛɪꜱ*
ᴛʜᴀɴᴋꜱ ꜰʀᴏᴍ @${settings.dev}

Digital Ocean Account:`, {
    parse_mode: "Markdown",
    reply_markup: { inline_keyboard: keyboard }
  });
});

bot.on("callback_query", async cb => {
  const chatId = cb.message.chat.id;
  const data = cb.data;

  if (data.startsWith("createvps_") && data.split("_").length === 2) {
    const accId = data.split("_")[1];

    const keyboard = Object.entries(vpsSpecs).map(([id, spec]) => ([{
      text: `${spec.icon} ${spec.name}`,
      callback_data: `spec_${accId}_${id}`
    }]));

    bot.editMessageText(
      `📡 *ᴍᴇɴᴜ ᴄʀᴇᴀᴛᴇ ᴠᴘꜱ*\n\nDigital Ocean: 🌐 *${accId}*\nSekarang pilih spesifikasi:`,
      {
        chat_id: chatId,
        message_id: cb.message.message_id,
        parse_mode: "Markdown",
        reply_markup: { inline_keyboard: keyboard }
      }
    );
  }

  if (data.startsWith("spec_")) {
    const [_, accId, specId] = data.split("_");
    const spec = vpsSpecs[specId];

    const keyboard = Object.entries(vpsImages).map(([id, img]) => ([{
      text: `${img.icon} ${img.name}`,
      callback_data: `image_${accId}_${specId}_${id}`
    }]));

    bot.editMessageText(
      `📦 Spesifikasi VPS\n*${spec.name}*\n\nSekarang pilih OS image:`,
      {
        chat_id: chatId,
        message_id: cb.message.message_id,
        parse_mode: "Markdown",
        reply_markup: { inline_keyboard: keyboard }
      }
    );
  }

  if (data.startsWith("image_")) {
    const [_, accId, specId, imageId] = data.split("_");
    const spec = vpsSpecs[specId];
    const img = vpsImages[imageId];

    const keyboard = Object.entries(vpsRegions).map(([id, reg]) => ([{
      text: `${reg.flag} ${reg.name}`,
      callback_data: `region_${accId}_${specId}_${imageId}_${id}`
    }]));

    bot.editMessageText(
      `📦 Spesifikasi VPS\n*${spec.name}*\n💿 Image: *${img.name}*\n\nSekarang pilih region:`,
      {
        chat_id: chatId,
        message_id: cb.message.message_id,
        parse_mode: "Markdown",
        reply_markup: { inline_keyboard: keyboard }
      }
    );
  }

  if (data.startsWith("region_")) {
    const [_, accId, specId, imageId, regionId] = data.split("_");
    const spec = vpsSpecs[specId];
    const img = vpsImages[imageId];
    const reg = vpsRegions[regionId];

    let apiKey;
    if (accId === "1") apiKey = settings.apiDigitalOcean;
    if (accId === "2") apiKey = settings.apiDigitalOcean2;
    if (accId === "3") apiKey = settings.apiDigitalOcean3;

    bot.editMessageText(
      `📡 Memulai proses create VPS...\n\n📦 *${spec.name}*\n💿 *${img.name}*\n🌍 ${reg.flag} *${reg.name}*\n\n⏳ Tunggu proses...`,
      {
        chat_id: chatId,
        message_id: cb.message.message_id,
        parse_mode: "Markdown"
      }
    );

    try {
      const hostname = `buyernael`;
      const password = Math.random().toString(36).slice(-10);

      const dropletId = await createVPSDroplet(apiKey, hostname, specId, imageId, regionId, password);

      bot.sendMessage(chatId,
        `✅ *Sukses create VPS*\nBerikut detail VPS Anda:\n\n🖥️ Hostname: \`${hostname}\`\n🆔 ID Droplet: \`${dropletId}\`\n📦 Spec: ${spec.name}\n💿 OS: ${img.name}\n🌍 Region: ${reg.flag} ${reg.name}\n\n📡 Detail login VPS:\n🔐 Password: \`${password}\`\n\nUntuk cek IP, ketik \`/cekip ${dropletId}\``,
        { parse_mode: "Markdown" }
      );
    } catch (err) {
      bot.sendMessage(chatId, `❌ Gagal membuat VPS\n\nError: ${err.message}`);
    }
  }

  bot.answerCallbackQuery(cb.id);
});

bot.onText(/^\/listvps$/, async msg => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, `❌ Kamu bukan @${settings.dev}!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
  }

  const keyboard = [
    [{ text: "🌐 DO 1", callback_data: "listdo_1" }],
    [{ text: "🌐 DO 2", callback_data: "listdo_2" }],
    [{ text: "🌐 DO 3", callback_data: "listdo_3" }]
  ];

  await bot.sendMessage(chatId, `*📋 ᴍᴇɴᴜ ʟɪꜱᴛ ᴠᴘꜱ*
ᴛʜᴀɴᴋꜱ ꜰʀᴏᴍ @${settings.dev}

Digital Ocean Account:`, {
    parse_mode: "Markdown",
    reply_markup: { inline_keyboard: keyboard }
  });
});

bot.on("callback_query", async query => {
  const chatId = query.message.chat.id;
  const data = query.data;

  if (data.startsWith("listdo_")) {
    const accId = data.split("_")[1];
    let apiKey;
    if (accId === "1") apiKey = settings.apiDigitalOcean;
    if (accId === "2") apiKey = settings.apiDigitalOcean2;
    if (accId === "3") apiKey = settings.apiDigitalOcean3;

    try {
      await bot.editMessageText("🔍 Mengambil daftar VPS...", {
        chat_id: chatId,
        message_id: query.message.message_id
      });

      const droplets = await getListVps(apiKey);

      if (droplets.length === 0) {
        return bot.editMessageText("📭 Tidak ada VPS yang ditemukan.\n\nGunakan /createvps untuk membuat VPS baru.", {
          chat_id: chatId,
          message_id: query.message.message_id
        });
      }

      const keyboard = droplets.map(vps => {
        const ip = vps.networks?.v4?.find(net => net.type === "public")?.ip_address || "No IP";
        const region = vpsRegions[vps.region.slug] || { flag: "🏳️", name: "Unknown" };
        const status = formatVPSStatus(vps.status);
        const uptime = formatUptime(vps.created_at);

        return [{
          text: `🖥️ ${vps.name} | ${status} | ${region.flag} ${region.name} | ${ip} | ${uptime}`,
          callback_data: `vpsinfo_${accId}_${vps.id}`
        }];
      });

      await bot.editMessageText(
        `🛰️ *Monitoring Vps*\n📊 Total VPS: *${droplets.length}*\n\nSilahkan klik untuk detail:`,
        {
          chat_id: chatId,
          message_id: query.message.message_id,
          parse_mode: "Markdown",
          reply_markup: { inline_keyboard: keyboard }
        }
      );
    } catch (err) {
      console.error("[LIST VPS ERROR]", err);
      bot.sendMessage(chatId, `❌ Gagal ambil daftar VPS\n\n🧾 Error: ${err.message}`);
    }
  }

  if (data.startsWith("vpsinfo_")) {
    const [_, accId, dropletId] = data.split("_");
    let apiKey;
    if (accId === "1") apiKey = settings.apiDigitalOcean;
    if (accId === "2") apiKey = settings.apiDigitalOcean2;
    if (accId === "3") apiKey = settings.apiDigitalOcean3;

    try {
      const droplet = await getVpsDetail(apiKey, dropletId);

      const ip = droplet?.networks?.v4?.find(net => net.type === "public")?.ip_address || "Belum tersedia";
      const region = vpsRegions[droplet?.region?.slug] || { flag: "🏳️", name: "Unknown" };
      const status = formatVPSStatus(droplet?.status);
      const uptime = droplet?.created_at ? formatUptime(droplet.created_at) : "Belum tersedia";

      const info = [
        `🖥️ *${droplet?.name || "Unknown"}*`,
        ``,
        `🆔 ID: \`${droplet?.id || "???"}\``,
        `🌐 IP: \`${ip}\``,
        `📦 Spec: ${droplet?.size_slug || "???"}`,
        `🖥️ OS: ${droplet?.image?.distribution || "???"} ${droplet?.image?.name || ""}`,
        `🌍 Region: ${region.flag} ${region.name}`,
        `📡 Status: ${status}`,
        `⏱️ Uptime: ${uptime}`
      ].join("\n");

      await bot.sendMessage(chatId, info, { parse_mode: "Markdown" });
    } catch (err) {
      console.error("[VPS DETAIL ERROR]", err);
      bot.sendMessage(chatId, `❌ Gagal ambil detail VPS\n\n🧾 Error: ${err.message}`);
    }
  }

  bot.answerCallbackQuery(query.id);
});

bot.onText(/^\/delvps (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const dropletId = match[1].trim();
    
  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, `❌ Kamu bukan @${settings.dev}!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
  }

  if (!dropletId) {
    return bot.sendMessage(chatId, "❌ ID VPS tidak valid");
  }

  bot.sendMessage(chatId, `*♻️ ᴍᴇɴᴜ ᴅᴇʟᴇᴛᴇ ᴠᴘꜱ*
ᴛʜᴀɴᴋꜱ ꜰʀᴏᴍ @${settings.dev}

Digital Ocean Account:`, {
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
          [{ text: "🌐 DO 1", callback_data: `delvpsacc_1_${dropletId}` }],
          [{ text: "🌐 DO 2", callback_data: `delvpsacc_2_${dropletId}` }],
          [{ text: "🌐 DO 3", callback_data: `delvpsacc_3_${dropletId}` }]
      ]
    }
  });
});

bot.on("callback_query", async (cbq) => {
  const chatId = cbq.message.chat.id;
  const data = cbq.data;

  if (data.startsWith("delvpsacc_")) {
    const parts = data.split("_");
    const accIndex = parts[1];
    const dropletId = parts[2];

    let apiKey;
    if (accIndex === "1") apiKey = settings.apiDigitalOcean;
    if (accIndex === "2") apiKey = settings.apiDigitalOcean2;
    if (accIndex === "3") apiKey = settings.apiDigitalOcean3;

    try {
      const vps = await getDropletInfo(apiKey, dropletId);

      const confirmMsg = [
        `⚠️ *KONFIRMASI DELETE VPS*`,
        ``,
        `🖥️ Name: *${vps.name}*`,
        `🆔 ID: \`${dropletId}\``,
        `🌐 IP: \`${vps.networks?.v4?.[0]?.ip_address || "No IP"}\``,
        ``,
        `❗ *PERINGATAN:*`,
        `• Semua data akan hilang permanen`,
        `• VPS tidak dapat dikembalikan`,
        `• Proses delete tidak bisa dibatalkan`,
        ``,
        `Yakin ingin menghapus VPS ini?`
      ].join("\n");

      bot.sendMessage(chatId, confirmMsg, {
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "✅ Ya, Hapus", callback_data: `confirmdel_${accIndex}_${dropletId}` },
              { text: "❌ Batal", callback_data: "canceldelete" }
            ]
          ]
        }
      });
    } catch (err) {
      bot.sendMessage(chatId, `❌ Gagal ambil info VPS\n\n🧾 Error: ${err.message}`);
    }
  }

  if (data.startsWith("confirmdel_")) {
    const parts = data.split("_");
    const accIndex = parts[1];
    const dropletId = parts[2];

    let apiKey;
    if (accIndex === "1") apiKey = settings.apiDigitalOcean;
    if (accIndex === "2") apiKey = settings.apiDigitalOcean2;
    if (accIndex === "3") apiKey = settings.apiDigitalOcean3;

    try {
      await deleteVPS(apiKey, dropletId);
      bot.sendMessage(chatId, `✅ VPS \`${dropletId}\` berhasil dihapus`, { parse_mode: "Markdown" });
    } catch (err) {
      bot.sendMessage(chatId, `❌ Gagal delete VPS\n\n🧾 Error: ${err.message}`);
    }
  }

  if (data === "canceldelete") {
    bot.sendMessage(chatId, "❌ Delete VPS dibatalkan.");
  }

  bot.answerCallbackQuery(cbq.id).catch(() => {});
});

bot.onText(/^\/cekip (\d+)$/, async (msg, match) => {
  const chatId = msg.chat.id
  const dropletId = match[1]?.trim()

  if (!dropletId) {
    return bot.sendMessage(chatId, "⚠️ Usage: /cekip <droplet_id>")
  }

  const keyboard = [
    [{ text: "🌐 DO 1", callback_data: `cekip_${dropletId}_1` }],
    [{ text: "🌐 DO 2", callback_data: `cekip_${dropletId}_2` }],
    [{ text: "🌐 DO 3", callback_data: `cekip_${dropletId}_3` }]
  ]

  bot.sendMessage(chatId, `*🔍 ᴍᴇɴᴜ ᴄᴇᴋ ɪᴘ ᴠᴘꜱ*
ᴛʜᴀɴᴋꜱ ꜰʀᴏᴍ @${settings.dev}

Digital Ocean Account:`, {
    parse_mode: "Markdown",
    reply_markup: { inline_keyboard: keyboard }
  })
})

bot.on("callback_query", async query => {
  const chatId = query.message.chat.id
  const data = query.data

  if (data.startsWith("cekip_")) {
    const [ , dropletId, acc ] = data.split("_")
    let apiKey

    if (acc === "1") apiKey = settings.apiDigitalOcean
    else if (acc === "2") apiKey = settings.apiDigitalOcean2
    else if (acc === "3") apiKey = settings.apiDigitalOcean3
    else return bot.answerCallbackQuery(query.id, { text: "❌ Akun tidak valid" })

    try {
      const droplet = await getDropletInfo(apiKey, dropletId)

      const ipAddress = droplet?.networks?.v4?.find(n => n.type === "public")?.ip_address || "⚠️ Dalam Proses"
      const region = vpsRegions[droplet?.region?.slug] || { name: droplet?.region?.slug || "Unknown", flag: "❓" }
      const spec = Object.values(vpsSpecs).find(s => s.size === droplet?.size_slug)
      const osName = (droplet?.image?.distribution || "") + " " + (droplet?.image?.name || "")

      const msgText = 
`📡 *ʙᴇʀɪᴋᴜᴛ ᴅᴇᴛᴀɪʟ ᴠᴘꜱ:*

🖥️ Hostname: \`${droplet?.name || "???"}\`
🌐 IP: \`${ipAddress}\`
📦 Spec: ${spec ? spec.name : droplet?.size_slug || "???"}
💿 OS: ${osName || "???"}
🌍 Region: ${region.flag} ${region.name}
⚡ Status: *${droplet?.status || "???"}*
🆔 Droplet ID: \`${droplet?.id || dropletId}\`

🔒 *ʟᴏɢɪɴ ᴊᴜɪᴄᴇꜱꜱʜ:*
\`root@${ipAddress}:22\``

      await bot.editMessageText(msgText, {
        chat_id: chatId,
        message_id: query.message.message_id,
        parse_mode: "Markdown"
      })
    } catch (err) {
      bot.editMessageText(`❌ Gagal cek VPS\n\n🧾 Error: ${err.message}`, {
        chat_id: chatId,
        message_id: query.message.message_id
      })
    }
  }

  bot.answerCallbackQuery(query.id)
})

}