const { Markup } = require('telegraf');
const database = require('../../lib/database');
const { isOwner, isPremium, loadJSON } = require('../../lib/utils');
const moment = require('moment-timezone');
const config = require('../../config');

module.exports = (bot) => {
    // Main menu callback handlers
    bot.action('jasher_menu', async (ctx) => {
        await ctx.answerCbQuery();
        await showJasherMenu(ctx);
    });

    bot.action('owner_menu', async (ctx) => {
        await ctx.answerCbQuery();
        if (isOwner(ctx.from.id)) {
            await showOwnerMenu(ctx);
        } else {
            await ctx.reply('❌ Hanya owner yang bisa mengakses menu ini!');
        }
    });

    bot.action('obf_menu', async (ctx) => {
        await ctx.answerCbQuery();
        await showObfMenu(ctx);
    });

    bot.action('status', async (ctx) => {
        await ctx.answerCbQuery();
        await showStatus(ctx);
    });

    bot.action('info', async (ctx) => {
        await ctx.answerCbQuery();
        await showInfo(ctx);
    });

    bot.action('back_to_main', async (ctx) => {
        await ctx.answerCbQuery();
        await showMainMenu(ctx);
    });

    // Jasher Menu sub-handlers
    bot.action('share_menu', async (ctx) => {
        await ctx.answerCbQuery();
        await showShareMenu(ctx);
    });

    bot.action('premium_info', async (ctx) => {
        await ctx.answerCbQuery();
        await showPremiumInfo(ctx);
    });

    bot.action('buy_premium', async (ctx) => {
        await ctx.answerCbQuery();
        await showBuyPremium(ctx);
    });

    // Owner Menu sub-handlers
    bot.action('detailed_stats', async (ctx) => {
        await ctx.answerCbQuery();
        if (isOwner(ctx.from.id)) {
            await showDetailedStats(ctx);
        } else {
            await ctx.answerCbQuery('❌ Akses ditolak!', true);
        }
    });

    bot.action('manage_users', async (ctx) => {
        await ctx.answerCbQuery();
        if (isOwner(ctx.from.id)) {
            await showManageUsers(ctx);
        } else {
            await ctx.answerCbQuery('❌ Akses ditolak!', true);
        }
    });

    bot.action('bot_settings', async (ctx) => {
        await ctx.answerCbQuery();
        if (isOwner(ctx.from.id)) {
            await showBotSettings(ctx);
        } else {
            await ctx.answerCbQuery('❌ Akses ditolak!', true);
        }
    });

    // Obf Menu sub-handlers
    bot.action('obf_time_locked', async (ctx) => {
        await ctx.answerCbQuery();
        await showObfHelp(ctx, 'enc', 'Time-Locked Encryption', 'Balas file .js dengan /enc <1-365>');
    });

    bot.action('obf_custom', async (ctx) => {
        await ctx.answerCbQuery();
        await showObfHelp(ctx, 'enc2', 'Custom Encryption', 'Balas file .js dengan /enc2 <nama>');
    });

    bot.action('obf_mandarin', async (ctx) => {
        await ctx.answerCbQuery();
        await showObfHelp(ctx, 'enc3', 'Hardened Mandarin', 'Balas file .js dengan /enc3');
    });

    bot.action('obf_arab', async (ctx) => {
        await ctx.answerCbQuery();
        await showObfHelp(ctx, 'enc4', 'Hardened Arab', 'Balas file .js dengan /enc4');
    });

    bot.action('obf_japan', async (ctx) => {
        await ctx.answerCbQuery();
        await showObfHelp(ctx, 'japan', 'Hardened Japan', 'Balas file .js dengan /japan');
    });

    bot.action('obf_nebula', async (ctx) => {
        await ctx.answerCbQuery();
        await showObfHelp(ctx, 'nebula', 'Nebula Polymorphic Storm', 'Balas file .js dengan /nebula');
    });

    bot.action('obf_quantum', async (ctx) => {
        await ctx.answerCbQuery();
        await showObfHelp(ctx, 'quantum', 'Quantum Vortex Encryption', 'Balas file .js dengan /quantum');
    });

    bot.action('obf_var', async (ctx) => {
        await ctx.answerCbQuery();
        await showObfHelp(ctx, 'var', 'Var Dynamic Obfuscation', 'Balas file .js dengan /var');
    });

    bot.action('obf_invisible', async (ctx) => {
        await ctx.answerCbQuery();
        await showObfHelp(ctx, 'zenc', 'Invisible Encryption', 'Balas file .js dengan /zenc');
    });

    bot.action('obf_deobf', async (ctx) => {
        await ctx.answerCbQuery();
        await showObfHelp(ctx, 'deobfuscate', 'Deobfuscation', 'Balas file .js yang diobfuscate dengan /deobfuscate');
    });

    // Payment handlers
    bot.action('confirm_payment', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.editMessageText(`
✅ *Konfirmasi Pembayaran*

Silakan kirim bukti transfer Anda ke @ginaaforyou dengan format:

*Format Pesan:*
Konfirmasi Premium - ID: ${ctx.from.id}
[Lampirkan screenshot bukti transfer]

*Pastikan bukti transfer jelas terlihat:*
• Nama pengirim
• Jumlah transfer
• Tanggal/waktu
• Bank tujuan

Premium akan diaktifkan maksimal 1x24 jam setelah konfirmasi.`,
            { parse_mode: 'Markdown' }
        );
    });

    bot.action('script_demo', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.editMessageText(`
📦 *Demo Script Jasher Bot*

*Fitur yang termasuk:*
• 🔒 Full obfuscation system
• 👥 User management database
• 💎 Premium system
• 📊 Analytics dashboard
• ⚡ Fast processing
• 🛡️ Security features

*Teknologi:*
• Node.js + Telegraf
• JSON database
• Modular architecture
• Easy to customize

*Support:* Include dokumentasi lengkap dan support instalasi.

Untuk pesan script, hubungi @ginaaforyou`,
            { parse_mode: 'Markdown' }
        );
    });

    // Tutorial handler
    bot.action('tutorial', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.editMessageText(`
📚 *Tutorial Penggunaan Jasher Bot*

*1. Obfuscation File:*
- Balas file .js dengan command obfuscation
- Contoh: /enc 7 (untuk 7 hari time-lock)
- Tunggu proses selesai, file akan dikirim otomatis

*2. Share Message:*
- Reply pesan dengan /sharefree atau /sharevip
- Pesan akan disebar ke semua group
- Share VIP lebih cepat untuk premium user

*3. Premium Features:*
- Add bot ke 3 group untuk trial 3 hari
- Upgrade premium untuk akses penuh
- Gunakan /buypremium untuk info pembayaran

*4. Group Management:*
- Add bot ke group sebagai admin
- Gunakan commands seperti /antispam on
- Bot akan otomatis moderasi group

*Support:* @ginaaforyou untuk bantuan lebih lanjut!`,
            { parse_mode: 'Markdown',
              ...Markup.inlineKeyboard([
                  [Markup.button.callback('🔙 Kembali', 'info')]
              ])
            }
        );
    });

    // Fungsi-fungsi menu display
    async function showMainMenu(ctx) {
        const userId = ctx.from.id;
        const isCreator = isOwner(userId);
        const sender = ctx.from.username || ctx.from.first_name;
        
        const menuText = `
╭─❒ 「 User Info 」 
├ Owner : ${isCreator ? 'True' : 'False'}
├ Name : ${ctx.from.first_name || ''}
├ Profile : @${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${require('../../lib/utils').runtime(process.uptime())}
├ Tanggal Server : ${moment().tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment().tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`;

        try {
            await ctx.editMessageCaption(menuText, {
                parse_mode: 'Markdown',
                ...Markup.inlineKeyboard([
                    [Markup.button.callback('🎯 Jasher Menu', 'jasher_menu')],
                    [Markup.button.callback('👑 Owner Menu', 'owner_menu'), Markup.button.callback('🔒 Obf Menu', 'obf_menu')],
                    [Markup.button.callback('📊 Status', 'status'), Markup.button.callback('ℹ️ Info', 'info')]
                ])
            });
        } catch (error) {
            await ctx.editMessageText(menuText, {
                parse_mode: 'Markdown',
                ...Markup.inlineKeyboard([
                    [Markup.button.callback('🎯 Jasher Menu', 'jasher_menu')],
                    [Markup.button.callback('👑 Owner Menu', 'owner_menu'), Markup.button.callback('🔒 Obf Menu', 'obf_menu')],
                    [Markup.button.callback('📊 Status', 'status'), Markup.button.callback('ℹ️ Info', 'info')]
                ])
            });
        }
    }

    async function showJasherMenu(ctx) {
        const menuText = `
🎯 *Jasher Menu*

*Fitur Utama:*
• 🔒 Obfuscation berbagai jenis
• 📤 Share otomatis
• 👥 Multi-group support
• ⚡ Fast processing

*Premium Features:*
• 🚀 Share VIP (cepat)
• 🔑 Akses penuh semua fitur
• 📊 Prioritas processing

Pilih opsi di bawah:`;

        await ctx.editMessageCaption(menuText, {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
                [Markup.button.callback('🔒 Obfuscation', 'obf_menu'), Markup.button.callback('📤 Share', 'share_menu')],
                [Markup.button.callback('💎 Premium Info', 'premium_info'), Markup.button.callback('🛒 Beli Premium', 'buy_premium')],
                [Markup.button.callback('🔙 Kembali', 'back_to_main')]
            ])
        });
    }

    async function showShareMenu(ctx) {
        const userId = ctx.from.id;
        const user = database.getUser(userId);
        const isPrem = isPremium(userId);
        
        const shareText = `
📤 *Share Menu*

*Status Anda:*
• Groups: ${user?.groups?.length || 0}/${config.REQUIRED_GROUPS}
• Premium: ${isPrem ? '✅ AKTIF' : '❌ NON-AKTIF'}
• Share Today: ${user?.share_count || 0}

*Available Commands:*
• /sharefree - Share gratis (lambat)
• /sharevip - Share VIP (cepat) ${isPrem ? '✅' : '🔒'}

*Cara penggunaan:*
1. Reply pesan dengan command share
2. Pesan akan disebar ke semua group
3. Tunggu proses selesai`;

        await ctx.editMessageCaption(shareText, {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
                [Markup.button.callback('🆓 Share Free', 'share_free_info'), Markup.button.callback('💎 Share VIP', 'share_vip_info')],
                [Markup.button.callback('📊 Status Share', 'share_status')],
                [Markup.button.callback('🔙 Kembali', 'jasher_menu')]
            ])
        });
    }

    async function showPremiumInfo(ctx) {
        const userId = ctx.from.id;
        const isPrem = isPremium(userId);
        const user = database.getUser(userId);
        
        let premiumStatus = '';
        if (isPrem && user.premium_expiry) {
            premiumStatus = `*Status Anda:* ✅ PREMIUM\\n*Expiry:* ${moment(user.premium_expiry).format('DD/MM/YYYY HH:mm')}\\n*Sisa:* ${moment(user.premium_expiry).fromNow(true)}\\n\\n`;
        }

        const premiumText = `
💎 *Premium Information*

${premiumStatus}
*Harga:* Rp ${config.PREMIUM_PRICE.toLocaleString()}
*Durasi:* ${config.PREMIUM_DAYS} hari

*Fitur Premium:*
• 🚀 Share VIP (prioritas tinggi)
• 🔒 Semua metode obfuscation
• ⚡ Processing cepat
• 📊 Unlimited usage
• 👑 Priority support

*Cara Upgrade:*
1. Transfer pembayaran
2. Kirim bukti ke owner
3. Premium diaktifkan dalam 1x24 jam`;

        await ctx.editMessageCaption(premiumText, {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
                [Markup.button.callback('🛒 Beli Sekarang', 'buy_premium')],
                [Markup.button.callback('📋 Syarat & Ketentuan', 'premium_tos')],
                [Markup.button.callback('🔙 Kembali', 'jasher_menu')]
            ])
        });
    }

    async function showBuyPremium(ctx) {
        const buyText = `
🛒 *Beli Premium*

*Paket Premium:*
💎 1 Bulan - Rp ${config.PREMIUM_PRICE.toLocaleString()}
✨ 3 Bulan - Rp ${(config.PREMIUM_PRICE * 3 * 0.9).toLocaleString()} (Diskon 10%)
🌟 1 Tahun - Rp ${(config.PREMIUM_PRICE * 12 * 0.8).toLocaleString()} (Diskon 20%)

*Metode Pembayaran:*
• Bank BCA: 1234567890 (A/N JASHER PREMIUM)
• Dana: 081234567890 (A/N JASHER PREMIUM)
• OVO: 081234567890 (A/N JASHER PREMIUM)

*Cara Order:*
1. Pilih paket dan transfer
2. Kirim bukti ke @ginaaforyou
3. Sertakan ID Anda: ${ctx.from.id}
4. Premium aktif dalam 1x24 jam`;

        await ctx.editMessageCaption(buyText, {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
                [Markup.button.url('💬 Hubungi Owner', 'https://t.me/ginaaforyou')],
                [Markup.button.callback('✅ Konfirmasi Pembayaran', 'confirm_payment')],
                [Markup.button.callback('🔙 Kembali', 'premium_info')]
            ])
        });
    }

    async function showOwnerMenu(ctx) {
        const stats = database.getStats();
        const menuText = `
👑 *Owner Menu*

*Statistics:*
• 👥 Total Users: ${stats.total_users}
• 💎 Premium Users: ${stats.premium_users}
• 👥 Active Groups: ${stats.active_groups}
• 📊 Total Groups: ${stats.total_groups}

*Owner Commands:*
• /bc - Broadcast message
• /addprem - Tambah premium
• /delprem - Hapus premium
• /addbl - Blacklist user
• /listgroup - List grup aktif`;

        await ctx.editMessageCaption(menuText, {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
                [Markup.button.callback('📊 Stats Detail', 'detailed_stats')],
                [Markup.button.callback('👥 Manage Users', 'manage_users')],
                [Markup.button.callback('🔧 Settings', 'bot_settings')],
                [Markup.button.callback('🔙 Kembali', 'back_to_main')]
            ])
        });
    }

    async function showDetailedStats(ctx) {
        const stats = database.getStats();
        const usersData = loadJSON('users.json');
        const premiumData = loadJSON('premium.json');
        
        // Hitung statistik detail
        const today = moment().format('YYYY-MM-DD');
        const weekAgo = moment().subtract(7, 'days').format('YYYY-MM-DD');
        
        const todayUsers = usersData.users.filter(u => 
            moment(u.join_date).format('YYYY-MM-DD') === today
        ).length;
        
        const weekUsers = usersData.users.filter(u => 
            moment(u.join_date).isAfter(weekAgo)
        ).length;
        
        const activePremium = premiumData.users.filter(p => 
            moment().isBefore(moment(p.expiry))
        ).length;

        const statsText = `
📈 *Detailed Statistics*

*User Analytics:*
• 👥 Total Users: ${stats.total_users}
• 📊 New Today: ${todayUsers}
• 📈 New This Week: ${weekUsers}
• 💎 Premium Active: ${activePremium}
• 📅 Premium Total: ${stats.premium_users}

*Group Analytics:*
• 👥 Active Groups: ${stats.active_groups}
• 📊 Total Groups: ${stats.total_groups}
• 📈 Active Rate: ${stats.total_groups > 0 ? ((stats.active_groups / stats.total_groups) * 100).toFixed(1) : 0}%

*Performance:*
• ⏰ Uptime: ${require('../../lib/utils').runtime(process.uptime())}
• 🗓️ Server Date: ${moment().format('DD/MM/YYYY')}
• ⏱️ Server Time: ${moment().format('HH:mm:ss')}
• 💾 Memory Usage: ${(process.memoryUsage().rss / 1024 / 1024).toFixed(2)} MB`;

        await ctx.editMessageCaption(statsText, {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
                [Markup.button.callback('🔄 Refresh', 'detailed_stats')],
                [Markup.button.callback('🔙 Kembali', 'owner_menu')]
            ])
        });
    }

    async function showManageUsers(ctx) {
        const manageText = `
👥 *User Management*

*Available Commands:*
• /addprem <id> <days> - Tambah premium user
• /delprem <id> - Hapus premium user
• /listprem - List semua premium user
• /addbl <id> [reason] - Blacklist user
• /delbl <id> - Hapus blacklist
• /listbl - List blacklisted users

*Quick Actions:*
Pilih aksi cepat di bawah:`;

        await ctx.editMessageCaption(manageText, {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
                [Markup.button.callback('📋 List Premium', 'quick_listprem'), Markup.button.callback('🚫 List Blacklist', 'quick_listbl')],
                [Markup.button.callback('📊 User Stats', 'quick_userstats')],
                [Markup.button.callback('🔙 Kembali', 'owner_menu')]
            ])
        });
    }

    async function showBotSettings(ctx) {
        const settingsText = `
🔧 *Bot Settings*

*Current Configuration:*
• Token: ${config.BOT_TOKEN ? '✅ Set' : '❌ Not set'}
• Owner: ${config.OWNER_ID ? '✅ Set' : '❌ Not set'}
• Premium Price: Rp ${config.PREMIUM_PRICE.toLocaleString()}
• Script Price: Rp ${config.SCRIPT_PRICE.toLocaleString()}
• Required Groups: ${config.REQUIRED_GROUPS}

*System Status:*
• Database: ✅ Connected
• Obfuscation: ✅ Ready
• Upload API: ✅ Available

*Maintenance:*
Bot dalam kondisi optimal dan siap melayani.`;

        await ctx.editMessageCaption(settingsText, {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
                [Markup.button.callback('🔄 Restart Bot', 'restart_bot'), Markup.button.callback('📝 Edit Config', 'edit_config')],
                [Markup.button.callback('🔧 Maintenance', 'maintenance_mode')],
                [Markup.button.callback('🔙 Kembali', 'owner_menu')]
            ])
        });
    }

    async function showObfMenu(ctx) {
        const menuText = `
🔒 *Obfuscation Menu*

*Available Methods:*
1. ⏰ Time-Locked (/enc [days])
2. 🎯 Custom (/enc2 [text])
3. 🇨🇳 Mandarin (/enc3)
4. 🇸🇦 Arab (/enc4)
5. 🎎 Japanese (/japan)
6. 🌌 Nebula (/nebula)
7. ⚛️ Quantum (/quantum)
8. 🔤 Var (/var)
9. 👻 Invisible (/zenc)
10. 🔄 Deobfuscate (/deobfuscate)

*Usage:* Balas file .js dengan command di atas`;

        await ctx.editMessageCaption(menuText, {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
                [Markup.button.callback('⏰ Time-Locked', 'obf_time_locked'), Markup.button.callback('🎯 Custom', 'obf_custom')],
                [Markup.button.callback('🇨🇳 Mandarin', 'obf_mandarin'), Markup.button.callback('🇸🇦 Arab', 'obf_arab')],
                [Markup.button.callback('🎎 Japan', 'obf_japan'), Markup.button.callback('🌌 Nebula', 'obf_nebula')],
                [Markup.button.callback('⚛️ Quantum', 'obf_quantum'), Markup.button.callback('🔤 Var', 'obf_var')],
                [Markup.button.callback('👻 Invisible', 'obf_invisible'), Markup.button.callback('🔄 Deobf', 'obf_deobf')],
                [Markup.button.callback('🔙 Kembali', 'back_to_main')]
            ])
        });
    }

    async function showObfHelp(ctx, command, name, usage) {
        const helpText = `
🔧 *${name}*

*Command:* /${command}
*Usage:* ${usage}

*Description:*
Method obfuscation ${name} memberikan perlindungan tingkat tinggi untuk kode JavaScript Anda.

*Features:*
• 🔒 Advanced code protection
• ⚡ Fast processing
• 📊 Optimized output

*Cara penggunaan:*
1. Balas file .js dengan /${command}
2. Tunggu proses selesai
3. File hasil akan dikirim otomatis

*Note:* Pastikan file berformat JavaScript (.js)`;

        await ctx.editMessageCaption(helpText, {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
                [Markup.button.callback('🔄 Kembali ke Obf Menu', 'obf_menu')],
                [Markup.button.callback('🔙 Main Menu', 'back_to_main')]
            ])
        });
    }

    async function showStatus(ctx) {
        const userId = ctx.from.id;
        const user = database.getUser(userId);
        const isPrem = isPremium(userId);
        const stats = database.getStats();
        
        const statusText = `
📊 *Status Bot*

*User Info:*
• 🆔 ID: ${userId}
• 💎 Premium: ${isPrem ? '✅ Aktif' : '❌ Non-aktif'}
• 📅 Member sejak: ${user ? moment(user.join_date).format('DD/MM/YY') : 'Baru'}
• 👥 Groups: ${user?.groups?.length || 0}

*Bot Status:*
• 🟢 Online
• ⏰ Uptime: ${require('../../lib/utils').runtime(process.uptime())}
• 📊 Total users: ${stats.total_users}
• 💎 Premium users: ${stats.premium_users}

*System:*
• 🗓️ Date: ${moment().format('DD/MM/YYYY')}
• ⏱️ Time: ${moment().format('HH:mm:ss')}
• 💾 Memory: ${(process.memoryUsage().rss / 1024 / 1024).toFixed(2)} MB`;

        await ctx.editMessageCaption(statusText, {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
                [Markup.button.callback('🔄 Refresh', 'status')],
                [Markup.button.callback('🔙 Kembali', 'back_to_main')]
            ])
        });
    }

    async function showInfo(ctx) {
        const infoText = `
ℹ️ *Jasher Bot Info*

*Version:* 2.0.0
*Developer:* @ginaaforyou
*Platform:* Node.js Telegraf
*Update:* ${moment().format('DD MMM YYYY')}

*Features:*
• 🔒 Advanced Obfuscation
• 👥 Group Management
• 💎 Premium System
• 📊 Analytics
• ⚡ Fast Processing

*Support Channels:*
• @ginaaforyou - Developer
• @jasherupdates - Updates

*Thanks for using Jasher Bot!* 🎉`;

        await ctx.editMessageCaption(infoText, {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
                [Markup.button.callback('📚 Tutorial', 'tutorial')],
                [Markup.button.callback('🆘 Support', 'support_help')],
                [Markup.button.callback('🔙 Kembali', 'back_to_main')]
            ])
        });
    }

    // Quick action handlers
    bot.action('quick_listprem', async (ctx) => {
        await ctx.answerCbQuery();
        if (!isOwner(ctx.from.id)) {
            return ctx.answerCbQuery('❌ Akses ditolak!', true);
        }

        const premiumData = loadJSON('premium.json');
        if (premiumData.users.length === 0) {
            return ctx.answerCbQuery('Tidak ada user premium!', true);
        }

        let listText = '💎 *Premium Users Quick List*\\n\\n';
        premiumData.users.slice(0, 10).forEach((user, index) => {
            const isActive = moment().isBefore(moment(user.expiry));
            listText += `${index + 1}. ID: ${user.id} - ${isActive ? '✅' : '❌'}\\n`;
        });

        if (premiumData.users.length > 10) {
            listText += `\\n... dan ${premiumData.users.length - 10} user lainnya.`;
        }

        await ctx.replyWithMarkdown(listText);
    });

    bot.action('support_help', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.editMessageCaption(`
🆘 *Support & Help*

*Jika mengalami masalah:*
1. Cek /tutorial untuk panduan dasar
2. Pastikan menggunakan command dengan benar
3. Cek status bot dengan /status

*Untuk bantuan lebih lanjut:*
• 💬 @ginaaforyou - Direct support
• 📢 @jasherupdates - Updates channel
• 🔧 Group support - Tersedia untuk premium

*Common Issues:*
• File tidak terbaca - Pastikan format .js
• Command tidak work - Cek di private chat
• Share gagal - Tambah bot ke lebih banyak group`,
            { parse_mode: 'Markdown',
              ...Markup.inlineKeyboard([
                  [Markup.button.url('💬 Contact Support', 'https://t.me/ginaaforyou')],
                  [Markup.button.callback('🔙 Kembali', 'info')]
              ])
            }
        );
    });

    // Error handler untuk callback queries
    bot.on('callback_query', async (ctx) => {
        // Default handler untuk callback yang tidak terdaftar
        if (!ctx.callbackQuery.data.startsWith('quick_')) {
            try {
                await ctx.answerCbQuery('⚠️ Perintah sedang diproses...');
            } catch (error) {
                console.log('Callback query error:', error);
            }
        }
    });
};