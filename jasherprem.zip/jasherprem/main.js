const { Telegraf, Markup } = require('telegraf');
const moment = require('moment-timezone');
const fs = require('fs-extra');
const path = require('path');
const fetch = require('node-fetch');
const JsConfuser = require('js-confuser');
const webcrack = require('webcrack');

// Load config
require('./config');
const { initDatabase, saveAllData } = require('./lib/database');
const { 
  saveUsers, 
  runtime, 
  log, 
  uploadToUguu, 
  isPremium, 
  getPremiumRemaining 
} = require('./lib/utils');
const { 
  handleNewGroup, 
  handleGroupLeft, 
  handleGroupMessage,
  setGroupSetting 
} = require('./src/groupManager');
const { 
  addPremium, 
  removePremium, 
  getPremiumList, 
  handlePremiumCommand, 
  handleBuyPremium 
} = require('./src/premiumManager');
const obfFunctions = require('./src/obf');

// Inisialisasi database
initDatabase();

// Buat folder temp jika belum ada
const tempDir = path.join(__dirname, 'temp');
if (!fs.existsSync(tempDir)) {
  fs.mkdirSync(tempDir);
}

// Inisialisasi bot
const bot = new Telegraf(global.BOT_TOKEN);

// Middleware untuk menangani pesan grup
bot.use(handleGroupMessage);

// Event ketika bot ditambahkan ke grup
bot.on('message', async (ctx, next) => {
  if (ctx.message.new_chat_members) {
    const botId = ctx.botInfo.id;
    const isBotAdded = ctx.message.new_chat_members.some(member => member.id === botId);
    
    if (isBotAdded) {
      await handleNewGroup(ctx);
    }
  }
  next();
});

// Command untuk fitur obfuscation
bot.command("enc3", async (ctx) => {
    users.add(ctx.from.id);
    saveUsers(users);
  
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
        return ctx.replyWithMarkdown(`
╭━━━「 ❌ ERROR 」━━━⬣
│ Terjadi kesalahan saat
│ memproses file!
╰━━━━━━━━━━━━━━━━⬣`);
    }
  
    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
        return ctx.replyWithMarkdown(`
╭━━━「 ❌ ERROR 」━━━⬣
│ File harus berekstensi .js!
╰━━━━━━━━━━━━━━━━⬣`);
    }
  
    const encryptedPath = path.join(
        __dirname,
        `china-encrypted-${file.file_name}`
    );
  
    try {
        const progressMessage = await ctx.replyWithMarkdown(
            "```css\n" +
            "🔒 EncryptBot\n" +
            ` ⚙️ Memulai (Hardened Mandarin) (1%)\n` +
            ` ${createProgressBar(1)}\n` +
            "```\n" +
            "PROSES ENCRYPT "
        );
  
        const fileLink = await ctx.telegram.getFileLink(file.file_id);
        log(`Mengunduh file untuk Mandarin obfuscation: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 10, "Mengunduh");
        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");
  
        log(`Memvalidasi kode: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode tidak valid: ${syntaxError.message}`);
        }
  
        log(`Mengenkripsi file dengan gaya Mandarin yang diperkuat`);
        await updateProgress(
            ctx,
            progressMessage,
            40,
            "Inisialisasi Hardened Mandarin Obfuscation"
        );
        const obfuscated = await JsConfuser.obfuscate(
            fileContent,
            getJapanxArabObfuscationConfig()
        );
        await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
        await fs.writeFile(encryptedPath, obfuscated.code);
        await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
  
        log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
        try {
            new Function(obfuscated.code);
        } catch (postObfuscationError) {
            throw new Error(
                `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
            );
        }
  
        log(`Mengirim file terenkripsi gaya Mandarin: ${file.file_name}`);
        await ctx.replyWithDocument(
            { source: encryptedPath, filename: `china-encrypted-${file.file_name}` },
            {
                caption:
                "✅ *File terenkripsi (Hardened Mandarin) siap!*\nSUKSES ENCRYPT 🕊",
                parse_mode: "Markdown",
            }
        );
        await updateProgress(
            ctx,
            progressMessage,
            100,
            "Hardened Mandarin Obfuscation Selesai"
        );
  
        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus: ${encryptedPath}`);
        }
    } catch (error) {
        log("Kesalahan saat Mandarin obfuscation", error);
        await ctx.replyWithMarkdown(
            `❌ *Kesalahan:* ${
                error.message || "Tidak diketahui"
            }\n_Coba lagi dengan kode Javascript yang valid!_`
        );
        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
    }
});

bot.command("enc4", async (ctx) => {
    users.add(ctx.from.id);
    saveUsers(users);
  
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
        return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc4`!");
    }
  
    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
        return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }
  
    const encryptedPath = path.join(
        __dirname,
        `arab-encrypted-${file.file_name}`
    );
  
    try {
        const progressMessage = await ctx.replyWithMarkdown(
            "```css\n" +
            "🔒 EncryptBot\n" +
            ` ⚙️ Memulai (Hardened Arab) (1%)\n` +
            ` ${createProgressBar(1)}\n` +
            "```\n" +
            "PROSES ENCRYPT"
        );
  
        const fileLink = await ctx.telegram.getFileLink(file.file_id);
        log(`Mengunduh file untuk Arab obfuscation: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 10, "Mengunduh");
        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");
  
        log(`Memvalidasi kode: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode tidak valid: ${syntaxError.message}`);
        }
  
        log(`Mengenkripsi file dengan gaya Arab yang diperkuat`);
        await updateProgress(
            ctx,
            progressMessage,
            40,
            "Inisialisasi Hardened Arab Obfuscation"
        );
        const obfuscated = await JsConfuser.obfuscate(
            fileContent,
            getArabObfuscationConfig()
        );
        await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
        await fs.writeFile(encryptedPath, obfuscated.code);
        await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
  
        log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
        try {
            new Function(obfuscated.code);
        } catch (postObfuscationError) {
            throw new Error(
                `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
            );
        }
  
        log(`Mengirim file terenkripsi gaya Arab: ${file.file_name}`);
        await ctx.replyWithDocument(
            { source: encryptedPath, filename: `arab-encrypted-${file.file_name}` },
            {
                caption:
                "✅ *File terenkripsi (Hardened Arab) siap!*\nSUKSES ENCRYPT 🕊",
                parse_mode: "Markdown",
            }
        );
        await updateProgress(
            ctx,
            progressMessage,
            100,
            "Hardened Arab Obfuscation Selesai"
        );
  
        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus: ${encryptedPath}`);
        }
    } catch (error) {
        log("Kesalahan saat Arab obfuscation", error);
        await ctx.replyWithMarkdown(
            `❌ *Kesalahan:* ${
                error.message || "Tidak diketahui"
            }\n_Coba lagi dengan kode Javascript yang valid!_`
        );
        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
    }
});

bot.command("japan", async (ctx) => {
    users.add(ctx.from.id);
    saveUsers(users);
  
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
        return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/japan`!");
    }
  
    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
        return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }
  
    const encryptedPath = path.join(
        __dirname,
        `japan-encrypted-${file.file_name}`
    );
  
    try {
        const progressMessage = await ctx.replyWithMarkdown(
            "```css\n" +
            "🔒 EncryptBot\n" +
            ` ⚙️ Memulai (Hardened Japan) (1%)\n` +
            ` ${createProgressBar(1)}\n` +
            "```\n" +
            "PROSES ENCRYPT "
        );
  
        const fileLink = await ctx.telegram.getFileLink(file.file_id);
        log(`Mengunduh file untuk Japan obfuscation: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 10, "Mengunduh");
        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");
  
        log(`Memvalidasi kode: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode tidak valid: ${syntaxError.message}`);
        }
  
        log(`Mengenkripsi file dengan gaya Japan yang diperkuat`);
        await updateProgress(
            ctx,
            progressMessage,
            40,
            "Inisialisasi Hardened Japan Obfuscation"
        );
        const obfuscated = await JsConfuser.obfuscate(
            fileContent,
            getJapanObfuscationConfig()
        );
        await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
        await fs.writeFile(encryptedPath, obfuscated.code);
        await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
  
        log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
        try {
            new Function(obfuscated.code);
        } catch (postObfuscationError) {
            throw new Error(
                `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
            );
        }
  
        log(`Mengirim file terenkripsi gaya Japan: ${file.file_name}`);
        await ctx.replyWithDocument(
            { source: encryptedPath, filename: `japan-encrypted-${file.file_name}` },
            {
                caption:
                "✅ *File terenkripsi (Hardened Japan) siap!*\nSUKSES ENCRYPT 🕊",
                parse_mode: "Markdown",
            }
        );
        await updateProgress(
            ctx,
            progressMessage,
            100,
            "Hardened Japan Obfuscation Selesai"
        );
  
        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus: ${encryptedPath}`);
        }
    } catch (error) {
        log("Kesalahan saat Japan obfuscation", error);
        await ctx.replyWithMarkdown(
            `❌ *Kesalahan:* ${
                error.message || "Tidak diketahui"
            }\n_Coba lagi dengan kode Javascript yang valid!_`
        );
        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
    }
});

bot.command("deobfuscate", async (ctx) => {
    users.add(ctx.from.id);
    saveUsers(users);
  
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
        return ctx.replyWithMarkdown(
            "❌ *Error:* Balas file .js yang diobfuscate dengan `/deobfuscate`!"
        );
    }
  
    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
        return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }
  
    const deobfuscatedPath = path.join(
        __dirname,
        `deobfuscated-${file.file_name}`
    );
  
    try {
        const progressMessage = await ctx.replyWithMarkdown(
            "```css\n" +
            "🔒 EncryptBot\n" +
            ` ⚙️ Memulai Deobfuscation (1%)\n` +
            ` ${createProgressBar(1)}\n` +
            "```\n" +
            "PROSES ENCRYPT "
        );
  
        // Mengunduh file
        const fileLink = await ctx.telegram.getFileLink(file.file_id);
        log(`Mengunduh file untuk deobfuscation: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 10, "Mengunduh");
        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");
  
        // Validasi kode awal
        log(`Memvalidasi kode awal: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode Awal");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
        }
  
        // Proses deobfuscation dengan webcrack
        log(`Memulai deobfuscation dengan webcrack: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 40, "Memulai Deobfuscation");
        const result = await webcrack(fileContent); // Pastikan await digunakan
        let deobfuscatedCode = result.code;
  
        // Penanganan jika kode dibundel
        let bundleInfo = "";
        if (result.bundle) {
            bundleInfo = "// Detected as bundled code (e.g., Webpack/Browserify)\n";
            log(`Kode terdeteksi sebagai bundel: ${file.file_name}`);
        }
  
        // Jika tidak ada perubahan signifikan atau hasil bukan string
        if (
            !deobfuscatedCode ||
            typeof deobfuscatedCode !== "string" ||
            deobfuscatedCode.trim() === fileContent.trim()
        ) {
            log(
                `Webcrack tidak dapat mendekode lebih lanjut atau hasil bukan string: ${file.file_name}`
            );
            deobfuscatedCode = `${bundleInfo}// Webcrack tidak dapat mendekode sepenuhnya atau hasil invalid\n${fileContent}`;
        }
  
        // Validasi kode hasil
        log(`Memvalidasi kode hasil deobfuscation: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 60, "Memvalidasi Kode Hasil");
        let isValid = true;
        try {
            new Function(deobfuscatedCode);
            log(`Kode hasil valid: ${deobfuscatedCode.substring(0, 50)}...`);
        } catch (syntaxError) {
            log(`Kode hasil tidak valid: ${syntaxError.message}`);
            deobfuscatedCode = `${bundleInfo}// Kesalahan validasi: ${syntaxError.message}\n${deobfuscatedCode}`;
            isValid = false;
        }
  
        // Simpan hasil
        await updateProgress(ctx, progressMessage, 80, "Menyimpan Hasil");
        await fs.writeFile(deobfuscatedPath, deobfuscatedCode);
  
        // Kirim hasil
        log(`Mengirim file hasil deobfuscation: ${file.file_name}`);
        await ctx.replyWithDocument(
            { source: deobfuscatedPath, filename: `deobfuscated-${file.file_name}` },
            {
                caption: `✅ *File berhasil dideobfuscate!${
                    isValid ? "" : " (Perhatikan pesan error dalam file)"
                }*\nSUKSES ENCRYPT 🕊`,
                parse_mode: "Markdown",
            }
        );
        await updateProgress(ctx, progressMessage, 100, "Deobfuscation Selesai");
  
        // Hapus file sementara
        if (await fs.pathExists(deobfuscatedPath)) {
            await fs.unlink(deobfuscatedPath);
            log(`File sementara dihapus: ${deobfuscatedPath}`);
        }
    } catch (error) {
        log("Kesalahan saat deobfuscation", error);
        await ctx.replyWithMarkdown(
            `❌ *Kesalahan:* ${
                error.message || "Tidak diketahui"
            }\n_Coba lagi dengan file Javascript yang valid!_`
        );
        if (await fs.pathExists(deobfuscatedPath)) {
            await fs.unlink(deobfuscatedPath);
            log(`File sementara dihapus setelah error: ${deobfuscatedPath}`);
        }
    }
});

bot.command("zenc", async (ctx) => {
    users.add(ctx.from.id);
    saveUsers(users);
  
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
        return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/zenc`!");
    }
  
    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
        return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }
  
    const encryptedPath = path.join(
        __dirname,
        `invisible-encrypted-${file.file_name}`
    );
  
    try {
        const progressMessage = await ctx.replyWithMarkdown(
            "```css\n" +
            "🔒 EncryptBot\n" +
            ` ⚙️ Memulai (InvisiBle) (1%)\n` +
            ` ${createProgressBar(1)}\n` +
            "```\n" +
            "PROSES ENCRYPT "
        );
  
        const fileLink = await ctx.telegram.getFileLink(file.file_id);
        log(`Mengunduh file untuk Strong obfuscation: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 10, "Mengunduh");
        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");
  
        log(`Memvalidasi kode awal: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode tidak valid: ${syntaxError.message}`);
        }
  
        log(`Mengenkripsi file dengan gaya Strong`);
        await updateProgress(
            ctx,
            progressMessage,
            40,
            "Inisialisasi Hardened Invisible Obfuscation"
        );
        const obfuscated = await JsConfuser.obfuscate(
            fileContent,
            getStrongObfuscationConfig()
        );
        let obfuscatedCode = obfuscated.code || obfuscated; // Pastikan string
        if (typeof obfuscatedCode !== "string") {
            throw new Error("Hasil obfuscation bukan string");
        }
        log(
            `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
                0,
                50
            )}...`
        );
        await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
  
        log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
        try {
            new Function(obfuscatedCode);
        } catch (postObfuscationError) {
            throw new Error(
                `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
            );
        }
  
        await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
        await fs.writeFile(encryptedPath, obfuscatedCode);
  
        log(`Mengirim file terenkripsi gaya Invisible: ${file.file_name}`);
        await ctx.replyWithDocument(
            {
                source: encryptedPath,
                filename: `Invisible-encrypted-${file.file_name}`,
            },
            {
                caption: "✅ *File terenkripsi (Invisible) siap!*\nSUKSES ENCRYPT 🕊",
                parse_mode: "Markdown",
            }
        );
        await updateProgress(
            ctx,
            progressMessage,
            100,
            "Hardened Invisible Obfuscation Selesai"
        );
  
        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus: ${encryptedPath}`);
        }
    } catch (error) {
        log("Kesalahan saat Invisible obfuscation", error);
        await ctx.replyWithMarkdown(
            `❌ *Kesalahan:* ${
                error.message || "Tidak diketahui"
            }\n_Coba lagi dengan kode Javascript yang valid!_`
        );
        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
    }
});

bot.command("xx", async (ctx) => {
    users.add(ctx.from.id);
    saveUsers(users);
  
    // Ambil nama kustom dari perintah
    const args = ctx.message.text.split(" ");
    if (args.length < 2 || !args[1]) {
        return ctx.replyWithMarkdown(
            "❌ *Error:* Gunakan format `/enc <nama>` dengan nama kustom!"
        );
    }
    const customName = args[1].replace(/[^a-zA-Z0-9_]/g, ""); // Sanitasi input, hanya huruf, angka, dan underscore
    if (!customName) {
        return ctx.replyWithMarkdown(
            "❌ *Error:* Nama kustom harus berisi huruf, angka, atau underscore!"
        );
    }
  
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
        return ctx.replyWithMarkdown(
            "❌ *Error:* Balas file .js dengan `/enc <nama>`!"
        );
    }
  
    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
        return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }
  
    const encryptedPath = path.join(
        __dirname,
        `custom-${customName}-encrypted-${file.file_name}`
    );
  
    try {
        const progressMessage = await ctx.replyWithMarkdown(
            "```css\n" +
            "🔒 EncryptBot\n" +
            ` ⚙️ Memulai (Hardened Custom: ${customName}) (1%)\n` +
            ` ${createProgressBar(1)}\n` +
            "```\n" +
            "PROSES ENCRYPT "
        );
  
        const fileLink = await ctx.telegram.getFileLink(file.file_id);
        log(`Mengunduh file untuk Custom obfuscation: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 10, "Mengunduh");
        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");
  
        log(`Memvalidasi kode awal: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
        }
  
        log(`Mengenkripsi file dengan gaya Custom (${customName}) yang diperkuat`);
        await updateProgress(
            ctx,
            progressMessage,
            40,
            "Inisialisasi Hardened Custom Obfuscation"
        );
        const obfuscated = await JsConfuser.obfuscate(
            fileContent,
            getCustomObfuscationConfig(customName)
        );
        log(
            `Hasil obfuscation (50 char pertama): ${obfuscated.code.substring(
                0,
                50
            )}...`
        );
        await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
  
        log(`Memvalidasi kode hasil obfuscation: ${file.file_name}`);
        try {
            new Function(obfuscated.code);
        } catch (postObfuscationError) {
            log(
                `Kode hasil obfuscation tidak valid: ${postObfuscationError.message}`
            );
            throw new Error(
                `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
            );
        }
  
        await fs.writeFile(encryptedPath, obfuscated.code);
        await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
  
        log(`Mengirim file terenkripsi gaya Custom: ${file.file_name}`);
        await ctx.replyWithDocument(
            {
                source: encryptedPath,
                filename: `custom-${customName}-encrypted-${file.file_name}`,
            },
            {
                caption: `✅ *File terenkripsi (Hardened Custom: ${customName}) siap!*\nSUKSES ENCRYPT 🕊`,
                parse_mode: "Markdown",
            }
        );
        await updateProgress(
            ctx,
            progressMessage,
            100,
            `Hardened Custom (${customName}) Obfuscation Selesai`
        );
  
        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus: ${encryptedPath}`);
        }
    } catch (error) {
        log("Kesalahan saat Custom obfuscation", error);
        await ctx.replyWithMarkdown(
            `❌ *Kesalahan:* ${
                error.message || "Tidak diketahui"
            }\n_Coba lagi dengan kode Javascript yang valid!_`
        );
        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
    }
});

bot.command("quantum", async (ctx) => {
    users.add(ctx.from.id);
    saveUsers(users);
  
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
        return ctx.replyWithMarkdown(
            "❌ *Error:* Balas file .js dengan `/quantum`!"
        );
    }
  
    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
        return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }
  
    const encryptedPath = path.join(
        __dirname,
        `quantum-encrypted-${file.file_name}`
    );
  
    try {
        const progressMessage = await ctx.replyWithMarkdown(
            "```css\n" +
            "🔒 EncryptBot\n" +
            " ⚙️ Memulai (Quantum Vortex Encryption) (1%)\n" +
            " " +
            createProgressBar(1) +
            "\n" +
            "```\n" +
            "PROSES ENCRYPT "
        );
  
        const fileLink = await ctx.telegram.getFileLink(file.file_id);
        log(`Mengunduh file untuk Quantum Vortex Encryption: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 10, "Mengunduh");
        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");
  
        log(`Memvalidasi kode awal: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
        }
  
        log(`Mengenkripsi file dengan Quantum Vortex Encryption`);
        await updateProgress(
            ctx,
            progressMessage,
            40,
            "Inisialisasi Quantum Vortex Encryption"
        );
        const obfuscatedCode = await obfuscateQuantum(fileContent);
        log(
            `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
                0,
                50
            )}...`
        );
        log(
            `Ukuran file setelah obfuscation: ${Buffer.byteLength(
                obfuscatedCode,
                "utf-8"
            )} bytes`
        );
  
        log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
        try {
            new Function(obfuscatedCode);
        } catch (postObfuscationError) {
            log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
            throw new Error(
                `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
            );
        }
  
        await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
        await fs.writeFile(encryptedPath, obfuscatedCode);
  
        log(`Mengirim file terenkripsi quantum: ${file.file_name}`);
        await ctx.replyWithDocument(
            {
                source: encryptedPath,
                filename: `quantum-encrypted-${file.file_name}`,
            },
            {
                caption:
                "✅ *File terenkripsi (Quantum Vortex Encryption) siap!*\nSUKSES ENCRYPT 🕊",
                parse_mode: "Markdown",
            }
        );
        await updateProgress(
            ctx,
            progressMessage,
            100,
            "Quantum Vortex Encryption Selesai"
        );
  
        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus: ${encryptedPath}`);
        }
    } catch (error) {
        log("Kesalahan saat Quantum obfuscation", error);
        await ctx.replyWithMarkdown(
            `❌ *Kesalahan:* ${
                error.message || "Tidak diketahui"
            }\n_Coba lagi dengan kode Javascript yang valid!_`
        );
        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
    }
});

bot.command("var", async (ctx) => {
    users.add(ctx.from.id);
    saveUsers(users);
  
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
        return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/var`!");
    }
  
    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
        return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }
  
    const encryptedPath = path.join(__dirname, `var-encrypted-${file.file_name}`);
  
    try {
        const progressMessage = await ctx.replyWithMarkdown(
            "```css\n" +
            "🔒 EncryptBot\n" +
            " ⚙️ Memulai (Var) (1%)\n" +
            " " +
            createProgressBar(1) +
            "\n" +
            "```\n" +
            "PROSES ENCRYPT "
        );
  
        const fileLink = await ctx.telegram.getFileLink(file.file_id);
        log(`Mengunduh file untuk Var obfuscation: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 10, "Mengunduh");
        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");
  
        log(`Memvalidasi kode awal: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
        }
  
        log(`Mengenkripsi file dengan gaya Var`);
        await updateProgress(
            ctx,
            progressMessage,
            40,
            "Inisialisasi Var Dynamic Obfuscation"
        );
        const obfuscated = await JsConfuser.obfuscate(
            fileContent,
            getNovaObfuscationConfig()
        );
        let obfuscatedCode = obfuscated.code || obfuscated;
        if (typeof obfuscatedCode !== "string") {
            throw new Error("Hasil obfuscation bukan string");
        }
        log(
            `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
                0,
                50
            )}...`
        );
  
        log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
        try {
            new Function(obfuscatedCode);
        } catch (postObfuscationError) {
            log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
            throw new Error(
                `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
            );
        }
  
        await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
        await fs.writeFile(encryptedPath, obfuscatedCode);
  
        log(`Mengirim file terenkripsi gaya Var: ${file.file_name}`);
        await ctx.replyWithDocument(
            { source: encryptedPath, filename: `Var-encrypted-${file.file_name}` },
            {
                caption: "✅ *File terenkripsi (Var) siap!*\nSUKSES ENCRYPT 🕊",
                parse_mode: "Markdown",
            }
        );
        await updateProgress(ctx, progressMessage, 100, "Var Obfuscation Selesai");
  
        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus: ${encryptedPath}`);
        }
    } catch (error) {
        log("Kesalahan saat Nova obfuscation", error);
        await ctx.replyWithMarkdown(
            `❌ *Kesalahan:* ${
                error.message || "Tidak diketahui"
            }\n_Coba lagi dengan kode Javascript yang valid!_`
        );
        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
    }
});

bot.command("nebula", async (ctx) => {
    users.add(ctx.from.id);
    saveUsers(users);
  
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
        return ctx.replyWithMarkdown(
            "❌ *Error:* Balas file .js dengan `/nebula`!"
        );
    }
  
    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
        return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }
  
    const encryptedPath = path.join(
        __dirname,
        `nebula-encrypted-${file.file_name}`
    );
  
    try {
        const progressMessage = await ctx.replyWithMarkdown(
            "```css\n" +
            "🔒 EncryptBot\n" +
            " ⚙️ Memulai (Nebula Polymorphic Storm) (1%)\n" +
            " " +
            createProgressBar(1) +
            "\n" +
            "```\n" +
            "PROSES ENCRYPT "
        );
  
        const fileLink = await ctx.telegram.getFileLink(file.file_id);
        log(`Mengunduh file untuk Nebula obfuscation: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 10, "Mengunduh");
        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");
  
        log(`Memvalidasi kode awal: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
        }
  
        log(`Mengenkripsi file dengan gaya Nebula`);
        await updateProgress(
            ctx,
            progressMessage,
            40,
            "Inisialisasi Nebula Polymorphic Storm"
        );
        const obfuscated = await JsConfuser.obfuscate(
            fileContent,
            getNebulaObfuscationConfig()
        );
        let obfuscatedCode = obfuscated.code || obfuscated;
        if (typeof obfuscatedCode !== "string") {
            throw new Error("Hasil obfuscation bukan string");
        }
        log(
            `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
                0,
                50
            )}...`
        );
        log(
            `Ukuran file setelah obfuscation: ${Buffer.byteLength(
                obfuscatedCode,
                "utf-8"
            )} bytes`
        );
  
        log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
        try {
            new Function(obfuscatedCode);
        } catch (postObfuscationError) {
            log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
            throw new Error(
                `Hasol obfuscation tidak valid: ${postObfuscationError.message}`
            );
        }
  
        await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
        await fs.writeFile(encryptedPath, obfuscatedCode);
  
        log(`Mengirim file terenkripsi gaya Nebula: ${file.file_name}`);
        await ctx.replyWithDocument(
            { source: encryptedPath, filename: `nebula-encrypted-${file.file_name}` },
            {
                caption:
                "✅ *File terenkripsi (Nebula Polymorphic Storm) siap!*\nSUKSES ENCRYPT 🕊",
                parse_mode: "Markdown",
            }
        );
        await updateProgress(
            ctx,
            progressMessage,
            100,
            "Nebula Polymorphic Storm Selesai"
        );
  
        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus: ${encryptedPath}`);
        }
    } catch (error) {
        log("Kesalahan saat Nebula obfuscation", error);
        await ctx.replyWithMarkdown(
            `❌ *Kesalahan:* ${
                error.message || "Tidak diketahui"
            }\n_Coba lagi dengan kode Javascript yang valid!_`
        );
        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
    }
});

bot.command("enc5", async (ctx) => {
    users.add(ctx.from.id);
    saveUsers(users);
  
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
        return ctx.replyWithMarkdown(
            "❌ *Error:* Balas file .js dengan `/enc5`!"
        );
    }
  
    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
        return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }
  
    const encryptedPath = path.join(
        __dirname,
        `siucalcrick-encrypted-${file.file_name}`
    );
  
    try {
        const progressMessage = await ctx.replyWithMarkdown(
            "```css\n" +
            "🔒 EncryptBot\n" +
            " ⚙️ Memulai (Calcrick Chaos Core) (1%)\n" +
            " " +
            createProgressBar(1) +
            "\n" +
            "```\n" +
            "PROSES ENCRYPT "
        );
  
        const fileLink = await ctx.telegram.getFileLink(file.file_id);
        log(`Mengunduh file untuk Siu+Calcrick obfuscation: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 10, "Mengunduh");
        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");
  
        log(`Memvalidasi kode awal: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
        }
  
        log(`Mengenkripsi file dengan gaya Siu+Calcrick`);
        await updateProgress(
            ctx,
            progressMessage,
            40,
            "Inisialisasi Calcrick Chaos Core"
        );
        const obfuscated = await JsConfuser.obfuscate(
            fileContent,
            getSiuCalcrickObfuscationConfig()
        );
        let obfuscatedCode = obfuscated.code || obfuscated;
        if (typeof obfuscatedCode !== "string") {
            throw new Error("Hasil obfuscation bukan string");
        }
        log(
            `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
                0,
                50
            )}...`
        );
        log(
            `Ukuran file setelah obfuscation: ${Buffer.byteLength(
                obfuscatedCode,
                "utf-8"
            )} bytes`
        );
  
        log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
        try {
            new Function(obfuscatedCode);
        } catch (postObfuscationError) {
            log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
            throw new Error(
                `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
            );
        }
  
        await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
        await fs.writeFile(encryptedPath, obfuscatedCode);
  
        log(`Mengirim file terenkripsi gaya Siu+Calcrick: ${file.file_name}`);
        await ctx.replyWithDocument(
            {
                source: encryptedPath,
                filename: `siucalcrick-encrypted-${file.file_name}`,
            },
            {
                caption:
                "✅ *File terenkripsi (Calcrick Chaos Core) siap!*\nSUKSES ENCRYPT 🕊",
                parse_mode: "Markdown",
            }
            );
        await updateProgress(
            ctx,
            progressMessage,
            100,
            "Calcrick Chaos Core Selesai"
        );
  
        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus: ${encryptedPath}`);
        }
    } catch (error) {
        log("Kesalahan saat Siu+Calcrick obfuscation", error);
        await ctx.replyWithMarkdown(
            `❌ *Kesalahan:* ${
                error.message || "Tidak diketahui"
            }\n_Coba lagi dengan kode Javascript yang valid!_`
        );
        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
    }
});

bot.command("enc2", async (ctx) => {
    users.add(ctx.from.id);
    saveUsers(users);
  
    const customString = ctx.message.text.split(" ")[1];
  
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
        return ctx.replyWithMarkdown(
            "❌ *Error:* Balas file .js dengan `/enc2 <text>`!"
        );
    }
  
    if (!customString) {
        return ctx.replyWithMarkdown(
            "❌ *Error:* Balas file .js dengan `/enc2 <text>`!"
        );
    }
  
    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
        return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }
  
    const encryptedPath = path.join(
        __dirname,
        `custom-encrypted-${file.file_name}`
    );
  
    try {
        const progressMessage = await ctx.replyWithMarkdown(
            "```css\n" +
            "🔒 EncryptBot\n" +
            " ⚙️ Memulai (custom enc) (1%)\n" +
            " " +
            createProgressBar(1) +
            "\n" +
            "```\n" +
            "PROSES ENCRYPT "
        );
  
        const fileLink = await ctx.telegram.getFileLink(file.file_id);
        log(`Mengunduh file untuk custom obfuscation: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 10, "Mengunduh");
        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");
  
        log(`Memvalidasi kode awal: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
        }
  
        log(`Mengenkripsi file dengan gaya custom (${customString})`);
        await updateProgress(ctx, progressMessage, 40, `Inisialisasi custom (${customString})`);
  
        const obfuscated = await JsConfuser.obfuscate(
            fileContent,
            getCustomObfuscationConfig(customString)
        );
  
        let obfuscatedCode = obfuscated.code || obfuscated;
        if (typeof obfuscatedCode !== "string") {
            throw new Error("Hasil obfuscation bukan string");
        }
        log(
            `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
                0,
                50
            )}...`
        );
        log(
            `Ukuran file setelah obfuscation: ${Buffer.byteLength(
                obfuscatedCode,
                "utf-8"
            )} bytes`
        );
  
        log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
        try {
            new Function(obfuscatedCode);
        } catch (postObfuscationError) {
            log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
            throw new Error(
                `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
            );
        }
  
        await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
        await fs.writeFile(encryptedPath, obfuscatedCode);
  
        log(`Mengirim file terenkripsi gaya custom (${customString}): ${file.file_name}`);
        await ctx.replyWithDocument(
            {
                source: encryptedPath,
                filename: `custom-encrypted-${file.file_name}`,
            },
            {
                caption: `✅ *File terenkripsi custom (${customString}) siap!*\nSUKSES ENCRYPT 🕊`,
                parse_mode: "Markdown",
            }
        );
        await updateProgress(ctx, progressMessage, 100, `custom (${customString}) Selesai`);
  
        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus: ${encryptedPath}`);
        }
    } catch (error) {
        log("Kesalahan saat custom enc obfuscation", error);
        await ctx.replyWithMarkdown(
            `❌ *Kesalahan:* ${
                error.message || "Tidak diketahui"
            }\n_Coba lagi dengan kode Javascript yang valid!_`
        );
        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
    }
});

bot.command("enc", async (ctx) => {
    users.add(ctx.from.id);
    saveUsers(users);
  
    const args = ctx.message.text.split(" ").slice(1);
    if (
        args.length !== 1 ||
        !/^\d+$/.test(args[0]) ||
        parseInt(args[0]) < 1 ||
        parseInt(args[0]) > 365
    ) {
        return ctx.replyWithMarkdown(
            "❌ *Error:* Gunakan format `/locked [1-365]` untuk jumlah hari (misal: `/enc 7`)!"
        );
    }
  
    const days = args[0];
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + parseInt(days));
    const expiryFormatted = expiryDate.toLocaleDateString();
  
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
        return ctx.replyWithMarkdown(
            "❌ *Error:* Balas file .js dengan `/enc [1-365]`!"
        );
    }
  
    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
        return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }
  
    const encryptedPath = path.join(
        __dirname,
        `locked-encrypted-${file.file_name}`
    );
  
    try {
        const progressMessage = await ctx.replyWithMarkdown(
            "```css\n" +
            "🔒 EncryptBot\n" +
            " ⚙️ Memulai (Time-Locked Encryption) (1%)\n" +
            " " +
            createProgressBar(1) +
            "\n" +
            "```\n" +
            "PROSES ENCRYPT "
        );
  
        const fileLink = await ctx.telegram.getFileLink(file.file_id);
        log(`Mengunduh file untuk Time-Locked Encryption: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 10, "Mengunduh");
        const response = await fetch(fileLink);
        let fileContent = await response.text();
        await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");
  
        log(`Memvalidasi kode awal: ${file.file_name}`);
        await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
        try {
            new Function(fileContent);
        } catch (syntaxError) {
            throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
        }
  
        log(`Mengenkripsi file dengan Time-Locked Encryption`);
        await updateProgress(
            ctx,
            progressMessage,
            40,
            "Inisialisasi Time-Locked Encryption"
        );
        const obfuscatedCode = await obfuscateTimeLocked(fileContent, days);
        log(
            `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
                0,
                50
            )}...`
        );
        log(
            `Ukuran file setelah obfuscation: ${Buffer.byteLength(
                obfuscatedCode,
                "utf-8"
            )} bytes`
        );
  
        log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
        try {
            new Function(obfuscatedCode);
        } catch (postObfuscationError) {
            log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
            throw new Error(
                `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
            );
        }
  
        await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
        await fs.writeFile(encryptedPath, obfuscatedCode);
  
        log(`Mengirim file terenkripsi time-locked: ${file.file_name}`);
        await ctx.replyWithMarkdown(
            `✅ *File terenkripsi (Time-Locked Encryption) siap!*\n` +
            `⏰ Masa aktif: ${days} hari (Kedaluwarsa: ${expiryFormatted})\n` +
            `_Powered by XHINN_`,
            { parse_mode: "Markdown" }
        );
        await ctx.replyWithDocument({
            source: encryptedPath,
            filename: `locked-encrypted-${file.file_name}`,
        });
        await updateProgress(
            ctx,
            progressMessage,
            100,
            "Time-Locked Encryption Selesai"
        );
  
        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus: ${encryptedPath}`);
        }
    } catch (error) {
        log("Kesalahan saat Time-Locked obfuscation", error);
        await ctx.replyWithMarkdown(
            `❌ *Kesalahan:* ${
                error.message || "Tidak diketahui"
            }\n_Coba lagi dengan kode Javascript yang valid!_`
        );
        if (await fs.pathExists(encryptedPath)) {
            await fs.unlink(encryptedPath);
            log(`File sementara dihapus setelah error: ${encryptedPath}`);
        }
    }
});

// Event ketika bot dikick dari grup
bot.on('left_chat_member', async (ctx) => {
  const botId = ctx.botInfo.id;
  if (ctx.message.left_chat_member.id === botId) {
    await handleGroupLeft(ctx);
  }
});

// Command start
bot.command('start', async (ctx) => {
  const userId = ctx.from.id;
  const isCreator = userId.toString() === global.OWNER_ID;
  const sender = ctx.from.username || ctx.from.first_name;
  
  // Tambahkan user ke database
  global.users.add(userId);
  saveUsers(global.users);
  
  // Jika user baru, berikan trial premium 3 hari
  if (!global.premiumUsers.has(userId)) {
    const trialExpiry = new Date();
    trialExpiry.setDate(trialExpiry.getDate() + global.FREE_TRIAL_DAYS);
    
    global.premiumUsers.set(userId, {
      expiry: trialExpiry.toISOString(),
      addedBy: 'system',
      addedAt: new Date().toISOString()
    });
    savePremiumUsers(global.premiumUsers);
    
    await ctx.reply(`🎉 Selamat! Anda mendapatkan trial premium ${global.FREE_TRIAL_DAYS} hari gratis!`);
  }
  
  const message = `╭─❒ 「 User Info 」 
├ Owner : ${isCreator ? 'True' : 'False'}
├ Name : ${ctx.from.first_name}${ctx.from.last_name ? ' ' + ctx.from.last_name : ''}
├ Profile : @${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`;
  
  await ctx.replyWithPhoto(
    'https://f.top4top.io/p_3530xky9e4.jpg',
    {
      caption: message,
      parse_mode: "Markdown",
      ...Markup.inlineKeyboard([
        [Markup.button.callback('🧰 Jasher Menu', 'jasher_menu')],
        [Markup.button.callback('👑 Owner Menu', 'owner_menu')],
        [Markup.button.callback('🔒 Obf Menu', 'obf_menu')]
      ])
    }
  );
});

// Command menu
bot.command('menu', async (ctx) => {
  const userId = ctx.from.id;
  const isCreator = userId.toString() === global.OWNER_ID;
  
  await ctx.replyWithPhoto(
    'https://f.top4top.io/p_3530xky9e4.jpg',
    {
      caption: '╭─❒ 「 Main Menu 」 \n├ Silahkan pilih menu dibawah\n╰❒',
      parse_mode: "Markdown",
      ...Markup.inlineKeyboard([
        [Markup.button.callback('🧰 Jasher Menu', 'jasher_menu')],
        [Markup.button.callback('👑 Owner Menu', 'owner_menu')],
        [Markup.button.callback('🔒 Obf Menu', 'obf_menu')],
        [Markup.button.callback('🔙 Kembali', 'start')]
      ])
    }
  );
});

// Command help
bot.command('help', async (ctx) => {
  await ctx.replyWithPhoto(
    'https://f.top4top.io/p_3530xky9e4.jpg',
    {
      caption: `╭─❒ 「 Bantuan 」 
├ /start - Memulai bot
├ /menu - Menu utama
├ /premium - Info premium
├ /buypremium - Beli premium
├ /help - Bantuan
├
├ Untuk obfuscation, balas file .js
├ dengan command yang tersedia
╰❒`,
      parse_mode: "Markdown",
      ...Markup.inlineKeyboard([
        [Markup.button.callback('🔙 Kembali', 'menu')]
      ])
    }
  );
});

// Command premium
bot.command('premium', handlePremiumCommand);

// Command buypremium
bot.command('buypremium', handleBuyPremium);

// Command untuk sharefree (hanya di private chat)
bot.command('sharefree', async (ctx) => {
  if (ctx.chat.type !== 'private') {
    return ctx.reply('❌ Command ini hanya bisa digunakan di private chat!');
  }
  
  if (!ctx.message.reply_to_message) {
    return ctx.reply('❌ Balas pesan yang ingin di-share!');
  }
  
  try {
    const message = ctx.message.reply_to_message;
    let text = '';
    
    if (message.text) {
      text = message.text;
    } else if (message.caption) {
      text = message.caption;
    } else {
      return ctx.reply('❌ Hanya bisa share pesan teks atau media dengan caption!');
    }
    
    // Share ke semua grup
    let successCount = 0;
    let failCount = 0;
    
    for (const groupId of global.groups) {
      try {
        if (global.blacklistGroups.has(groupId)) continue;
        
        if (message.photo) {
          await ctx.telegram.sendPhoto(groupId, message.photo[message.photo.length - 1].file_id, {
            caption: text
          });
        } else if (message.video) {
          await ctx.telegram.sendVideo(groupId, message.video.file_id, {
            caption: text
          });
        } else if (message.document) {
          await ctx.telegram.sendDocument(groupId, message.document.file_id, {
            caption: text
          });
        } else {
          await ctx.telegram.sendMessage(groupId, text);
        }
        
        successCount++;
      } catch (error) {
        failCount++;
        log(`Error sharing to group ${groupId}`, error);
      }
    }
    
    await ctx.reply(`✅ Berhasil share ke ${successCount} grup, gagal: ${failCount}`);
  } catch (error) {
    log('Error in sharefree', error);
    await ctx.reply('❌ Gagal melakukan share!');
  }
});

// Command untuk sharevip (hanya premium user, hanya di private chat)
bot.command('sharevip', async (ctx) => {
  if (ctx.chat.type !== 'private') {
    return ctx.reply('❌ Command ini hanya bisa digunakan di private chat!');
  }
  
  if (!isPremium(ctx.from.id)) {
    return ctx.reply('❌ Hanya user premium yang bisa menggunakan fitur ini!');
  }
  
  if (!ctx.message.reply_to_message) {
    return ctx.reply('❌ Balas pesan yang ingin di-share!');
  }
  
  try {
    const message = ctx.message.reply_to_message;
    let text = '';
    
    if (message.text) {
      text = message.text;
    } else if (message.caption) {
      text = message.caption;
    } else {
      return ctx.reply('❌ Hanya bisa share pesan teks atau media dengan caption!');
    }
    
    // Share ke semua grup dengan prioritas tinggi
    let successCount = 0;
    let failCount = 0;
    
    for (const groupId of global.groups) {
      try {
        if (global.blacklistGroups.has(groupId)) continue;
        
        if (message.photo) {
          await ctx.telegram.sendPhoto(groupId, message.photo[message.photo.length - 1].file_id, {
            caption: text,
            disable_notification: false // Prioritas tinggi
          });
        } else if (message.video) {
          await ctx.telegram.sendVideo(groupId, message.video.file_id, {
            caption: text,
            disable_notification: false
          });
        } else if (message.document) {
          await ctx.telegram.sendDocument(groupId, message.document.file_id, {
            caption: text,
            disable_notification: false
          });
        } else {
          await ctx.telegram.sendMessage(groupId, text, {
            disable_notification: false
          });
        }
        
        successCount++;
      } catch (error) {
        failCount++;
        log(`Error sharing to group ${groupId}`, error);
      }
    }
    
    await ctx.reply(`✅ Berhasil share VIP ke ${successCount} grup, gagal: ${failCount}`);
  } catch (error) {
    log('Error in sharevip', error);
    await ctx.reply('❌ Gagal melakukan share VIP!');
  }
});

// Command untuk broadcast (hanya owner)
bot.command('bc', async (ctx) => {
  if (ctx.from.id.toString() !== global.OWNER_ID) {
    return ctx.reply('❌ Hanya owner yang bisa menggunakan command ini!');
  }
  
  if (!ctx.message.reply_to_message) {
    return ctx.reply('❌ Balas pesan yang ingin di-broadcast!');
  }
  
  try {
    const message = ctx.message.reply_to_message;
    let successCount = 0;
    let failCount = 0;
    
    for (const userId of global.users) {
      try {
        if (message.photo) {
          await ctx.telegram.sendPhoto(userId, message.photo[message.photo.length - 1].file_id, {
            caption: message.caption || ''
          });
        } else if (message.video) {
          await ctx.telegram.sendVideo(userId, message.video.file_id, {
            caption: message.caption || ''
          });
        } else if (message.document) {
          await ctx.telegram.sendDocument(userId, message.document.file_id, {
            caption: message.caption || ''
          });
        } else if (message.text) {
          await ctx.telegram.sendMessage(userId, message.text);
        } else {
          continue;
        }
        
        successCount++;
      } catch (error) {
        failCount++;
        log(`Error broadcasting to user ${userId}`, error);
      }
    }
    
    await ctx.reply(`✅ Berhasil broadcast ke ${successCount} user, gagal: ${failCount}`);
  } catch (error) {
    log('Error in broadcast', error);
    await ctx.reply('❌ Gagal melakukan broadcast!');
  }
});

// Command untuk menambah premium user (hanya owner)
bot.command('addprem', async (ctx) => {
  if (ctx.from.id.toString() !== global.OWNER_ID) {
    return ctx.reply('❌ Hanya owner yang bisa menggunakan command ini!');
  }
  
  const args = ctx.message.text.split(' ');
  if (args.length < 3) {
    return ctx.reply('❌ Format: /addprem <user_id> <days>');
  }
  
  const userId = args[1];
  const days = parseInt(args[2]);
  
  if (isNaN(days) || days <= 0) {
    return ctx.reply('❌ Jumlah hari harus angka positif!');
  }
  
  if (addPremium(userId, days, ctx.from.id.toString())) {
    await ctx.reply(`✅ Berhasil menambahkan premium untuk user ${userId} selama ${days} hari`);
  } else {
    await ctx.reply('❌ Gagal menambahkan premium!');
  }
});

// Command untuk menghapus premium user (hanya owner)
bot.command('delprem', async (ctx) => {
  if (ctx.from.id.toString() !== global.OWNER_ID) {
    return ctx.reply('❌ Hanya owner yang bisa menggunakan command ini!');
  }
  
  const args = ctx.message.text.split(' ');
  if (args.length < 2) {
    return ctx.reply('❌ Format: /delprem <user_id>');
  }
  
  const userId = args[1];
  
  if (removePremium(userId)) {
    await ctx.reply(`✅ Berhasil menghapus premium untuk user ${userId}`);
  } else {
    await ctx.reply('❌ User tidak ditemukan atau bukan premium!');
  }
});

// Command untuk melihat list premium user (hanya owner)
bot.command('listprem', async (ctx) => {
  if (ctx.from.id.toString() !== global.OWNER_ID) {
    return ctx.reply('❌ Hanya owner yang bisa menggunakan command ini!');
  }
  
  const premiumList = getPremiumList();
  
  if (premiumList.length === 0) {
    return ctx.reply('❌ Tidak ada user premium!');
  }
  
  let message = '╭─❒ 「 List Premium Users 」 \n';
  
  premiumList.forEach((user, index) => {
    message += `├ ${index + 1}. User: ${user.userId}\n`;
    message += `├   Expiry: ${new Date(user.expiry).toLocaleDateString()}\n`;
    message += `├   Added by: ${user.addedBy}\n`;
    message += `├   Remaining: ${user.remaining}\n`;
    message += '├\n';
  });
  
  message += '╰❒';
  
  await ctx.reply(message);
});

// Command untuk menambah blacklist grup (hanya owner)
bot.command('addbl', async (ctx) => {
  if (ctx.from.id.toString() !== global.OWNER_ID) {
    return ctx.reply('❌ Hanya owner yang bisa menggunakan command ini!');
  }
  
  const args = ctx.message.text.split(' ');
  if (args.length < 2) {
    return ctx.reply('❌ Format: /addbl <group_id>');
  }
  
  const groupId = args[1];
  global.blacklistGroups.add(groupId);
  saveBlacklistGroups(global.blacklistGroups);
  
  await ctx.reply(`✅ Berhasil menambahkan grup ${groupId} ke blacklist`);
});

// Command untuk menghapus blacklist grup (hanya owner)
bot.command('delbl', async (ctx) => {
  if (ctx.from.id.toString() !== global.OWNER_ID) {
    return ctx.reply('❌ Hanya owner yang bisa menggunakan command ini!');
  }
  
  const args = ctx.message.text.split(' ');
  if (args.length < 2) {
    return ctx.reply('❌ Format: /delbl <group_id>');
  }
  
  const groupId = args[1];
  
  if (global.blacklistGroups.delete(groupId)) {
    saveBlacklistGroups(global.blacklistGroups);
    await ctx.reply(`✅ Berhasil menghapus grup ${groupId} dari blacklist`);
  } else {
    await ctx.reply('❌ Grup tidak ditemukan di blacklist!');
  }
});

// Command untuk melihat list blacklist grup (hanya owner)
bot.command('listbl', async (ctx) => {
  if (ctx.from.id.toString() !== global.OWNER_ID) {
    return ctx.reply('❌ Hanya owner yang bisa menggunakan command ini!');
  }
  
  if (global.blacklistGroups.size === 0) {
    return ctx.reply('❌ Tidak ada grup di blacklist!');
  }
  
  let message = '╭─❒ 「 List Blacklist Groups 」 \n';
  
  let index = 1;
  for (const groupId of global.blacklistGroups) {
    message += `├ ${index}. Group ID: ${groupId}\n`;
    index++;
  }
  
  message += '╰❒';
  
  await ctx.reply(message);
});

// Command untuk melihat list grup aktif (hanya owner)
bot.command('listgrup', async (ctx) => {
  if (ctx.from.id.toString() !== global.OWNER_ID) {
    return ctx.reply('❌ Hanya owner yang bisa menggunakan command ini!');
  }
  
  if (global.groups.size === 0) {
    return ctx.reply('❌ Bot belum ditambahkan ke grup manapun!');
  }
  
  let message = '╭─❒ 「 List Active Groups 」 \n';
  
  let index = 1;
  for (const groupId of global.groups) {
    try {
      const chat = await ctx.telegram.getChat(groupId);
      message += `├ ${index}. ${chat.title} (ID: ${groupId})\n`;
    } catch (error) {
      message += `├ ${index}. Unknown Group (ID: ${groupId}) - Mungkin bot sudah dikick\n`;
    }
    index++;
  }
  
  message += '╰❒';
  
  await ctx.reply(message);
});

// Command untuk upload file ke uguu.se
bot.command('tourl', async (ctx) => {
  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.reply('❌ Balas file yang ingin diupload!');
  }
  
  try {
    const file = ctx.message.reply_to_message.document;
    const fileLink = await ctx.telegram.getFileLink(file.file_id);
    
    const response = await fetch(fileLink);
    const fileBuffer = await response.buffer();
    
    const progressMsg = await ctx.reply('⏳ Mengupload file...');
    
    const url = await uploadToUguu(fileBuffer, file.file_name);
    
    if (url) {
      await ctx.reply(`✅ Berhasil upload!\n🔗 URL: ${url}`);
    } else {
      await ctx.reply('❌ Gagal mengupload file!');
    }
    
    await ctx.telegram.deleteMessage(progressMsg.chat.id, progressMsg.message_id);
  } catch (error) {
    log('Error in tourl', error);
    await ctx.reply('❌ Gagal mengupload file!');
  }
});

// Command untuk mengatur pengaturan grup (hanya admin grup)
// Antispam
bot.command('antispam', async (ctx) => {
  await setGroupSetting(ctx, 'antispam', true);
});

bot.command('noantispam', async (ctx) => {
  await setGroupSetting(ctx, 'antispam', false);
});

// Noevent
bot.command('noevent', async (ctx) => {
  await setGroupSetting(ctx, 'noevent', true);
});

bot.command('event', async (ctx) => {
  await setGroupSetting(ctx, 'noevent', false);
});

// Nolinks
bot.command('nolinks', async (ctx) => {
  await setGroupSetting(ctx, 'nolinks', true);
});

bot.command('links', async (ctx) => {
  await setGroupSetting(ctx, 'nolinks', false);
});

// Noforwards
bot.command('noforwards', async (ctx) => {
  await setGroupSetting(ctx, 'noforwards', true);
});

bot.command('forwards', async (ctx) => {
  await setGroupSetting(ctx, 'noforwards', false);
});

// Nocontacts
bot.command('nocontacts', async (ctx) => {
  await setGroupSetting(ctx, 'nocontacts', true);
});

bot.command('contacts', async (ctx) => {
  await setGroupSetting(ctx, 'nocontacts', false);
});

// Nohashtags
bot.command('nohashtags', async (ctx) => {
  await setGroupSetting(ctx, 'nohashtags', true);
});

bot.command('hashtags', async (ctx) => {
  await setGroupSetting(ctx, 'nohashtags', false);
});

// Nocommands
bot.command('nocommands', async (ctx) => {
  await setGroupSetting(ctx, 'nocommands', true);
});

bot.command('commands', async (ctx) => {
  await setGroupSetting(ctx, 'nocommands', false);
});

// Command untuk melihat pengaturan grup
bot.command('settings', async (ctx) => {
  if (ctx.chat.type === 'private') {
    return ctx.reply('❌ Command ini hanya bisa digunakan di grup!');
  }
  
  const groupId = ctx.chat.id;
  const settings = global.groupSettings.get(groupId) || {};
  
  let message = '╭─❒ 「 Group Settings 」 \n';
  message += `├ Antispam: ${settings.antispam ? '✅' : '❌'}\n`;
  message += `├ No Event: ${settings.noevent ? '✅' : '❌'}\n`;
  message += `├ No Links: ${settings.nolinks ? '✅' : '❌'}\n`;
  message += `├ No Forwards: ${settings.noforwards ? '✅' : '❌'}\n`;
  message += `├ No Contacts: ${settings.nocontacts ? '✅' : '❌'}\n`;
  message += `├ No Hashtags: ${settings.nohashtags ? '✅' : '❌'}\n`;
  message += `├ No Commands: ${settings.nocommands ? '✅' : '❌'}\n`;
  message += '╰❒';
  
  await ctx.reply(message);
});

// Handler untuk callback queries
bot.action('menu', async (ctx) => {
  await ctx.deleteMessage();
  await ctx.replyWithPhoto(
    'https://f.top4top.io/p_3530xky9e4.jpg',
    {
      caption: '╭─❒ 「 Main Menu 」 \n├ Silahkan pilih menu dibawah\n╰❒',
      parse_mode: "Markdown",
      ...Markup.inlineKeyboard([
        [Markup.button.callback('🧰 Jasher Menu', 'jasher_menu')],
        [Markup.button.callback('👑 Owner Menu', 'owner_menu')],
        [Markup.button.callback('🔒 Obf Menu', 'obf_menu')],
        [Markup.button.callback('🔙 Kembali', 'start')]
      ])
    }
  );
});

bot.action('start', async (ctx) => {
  await ctx.deleteMessage();
  const userId = ctx.from.id;
  const isCreator = userId.toString() === global.OWNER_ID;
  const sender = ctx.from.username || ctx.from.first_name;
  
  const message = `╭─❒ 「 User Info 」 
├ Owner : ${isCreator ? 'True' : 'False'}
├ Name : ${ctx.from.first_name}${ctx.from.last_name ? ' ' + ctx.from.last_name : ''}
├ Profile : @${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`;
  
  await ctx.replyWithPhoto(
    'https://f.top4top.io/p_3530xky9e4.jpg',
    {
      caption: message,
      parse_mode: "Markdown",
      ...Markup.inlineKeyboard([
        [Markup.button.callback('🧰 Jasher Menu', 'jasher_menu')],
        [Markup.button.callback('👑 Owner Menu', 'owner_menu')],
        [Markup.button.callback('🔒 Obf Menu', 'obf_menu')]
      ])
    }
  );
});

bot.action('jasher_menu', async (ctx) => {
  await ctx.deleteMessage();
  await ctx.replyWithPhoto(
    'https://f.top4top.io/p_3530xky9e4.jpg',
    {
      caption: `╭─❒ 「 Jasher Menu 」 
├ /start - Memulai bot
├ /menu - Menu utama
├ /premium - Info premium
├ /buypremium - Beli premium
├ /help - Bantuan
├ /sharefree - Share pesan (free)
├ /sharevip - Share pesan (vip)
╰❒`,
      parse_mode: "Markdown",
      ...Markup.inlineKeyboard([
        [Markup.button.callback('🔙 Kembali', 'menu')]
      ])
    }
  );
});

bot.action('owner_menu', async (ctx) => {
  await ctx.deleteMessage();
  const isCreator = ctx.from.id.toString() === global.OWNER_ID;
  
  if (!isCreator) {
    return ctx.reply('❌ Hanya owner yang bisa mengakses menu ini!');
  }
  
  await ctx.replyWithPhoto(
    'https://f.top4top.io/p_3530xky9e4.jpg',
    {
      caption: `╭─❒ 「 Owner Menu 」 
├ /bc - Broadcast ke semua user
├ /addprem - Tambah premium user
├ /delprem - Hapus premium user
├ /listprem - List premium user
├ /addbl - Tambah blacklist grup
├ /delbl - Hapus blacklist grup
├ /listbl - List blacklist grup
├ /listgrup - List grup aktif
╰❒`,
      parse_mode: "Markdown",
      ...Markup.inlineKeyboard([
        [Markup.button.callback('🔙 Kembali', 'menu')]
      ])
    }
  );
});

bot.action('obf_menu', async (ctx) => {
  await ctx.deleteMessage();
  await ctx.replyWithPhoto(
    'https://f.top4top.io/p_3530xky9e4.jpg',
    {
      caption: `╭─❒ 「 Obfuscation Menu 」 
├ /enc - Time-Locked Encryption
├ /enc2 - Custom Encryption
├ /enc3 - Mandarin Encryption
├ /enc4 - Arab Encryption
├ /enc5 - Calcrick Chaos Core
├ /japan - Japan Encryption
├ /deobfuscate - Deobfuscate
├ /zenc - Invisible Encryption
├ /xx - Custom Name Encryption
├ /quantum - Quantum Encryption
├ /var - Var Encryption
├ /nebula - Nebula Encryption
╰❒`,
      parse_mode: "Markdown",
      ...Markup.inlineKeyboard([
        [Markup.button.callback('🔙 Kembali', 'menu')]
      ])
    }
  );
});

bot.action('premium', handlePremiumCommand);
bot.action('buypremium', handleBuyPremium);
bot.action('listpremium', async (ctx) => {
  if (ctx.from.id.toString() !== global.OWNER_ID) {
    return ctx.reply('❌ Hanya owner yang bisa menggunakan command ini!');
  }
  
  const premiumList = getPremiumList();
  
  if (premiumList.length === 0) {
    return ctx.reply('❌ Tidak ada user premium!');
  }
  
  let message = '╭─❒ 「 List Premium Users 」 \n';
  
  premiumList.forEach((user, index) => {
    message += `├ ${index + 1}. User: ${user.userId}\n`;
    message += `├   Expiry: ${new Date(user.expiry).toLocaleDateString()}\n`;
    message += `├   Added by: ${user.addedBy}\n`;
    message += `├   Remaining: ${user.remaining}\n`;
    message += '├\n';
  });
  
  message += '╰❒';
  
  await ctx.reply(message);
});

case 'enc3':
      encryptedPath = path.join(__dirname, '..', 'temp', `china-encrypted-${file.file_name}`);
      configFunction = getCustomObfuscationConfig('china');
      commandName = 'Hardened Mandarin';
      break;
    case 'enc4':
      encryptedPath = path.join(__dirname, '..', 'temp', `arab-encrypted-${file.file_name}`);
      configFunction = getArabObfuscationConfig;
      commandName = 'Hardened Arab';
      break;
    case 'japan':
      encryptedPath = path.join(__dirname, '..', 'temp', `japan-encrypted-${file.file_name}`);
      configFunction = getJapanObfuscationConfig;
      commandName = 'Hardened Japan';
      break;
    case 'zenc':
      encryptedPath = path.join(__dirname, '..', 'temp', `invisible-encrypted-${file.file_name}`);
      configFunction = getStrongObfuscationConfig;
      commandName = 'Invisible';
      break;
    case 'nebula':
      encryptedPath = path.join(__dirname, '..', 'temp', `nebula-encrypted-${file.file_name}`);
      configFunction = getNebulaObfuscationConfig;
      commandName = 'Nebula Polymorphic Storm';
      break;
    case 'enc5':
      encryptedPath = path.join(__dirname, '..', 'temp', `siucalcrick-encrypted-${file.file_name}`);
      configFunction = getSiuCalcrickObfuscationConfig;
      commandName = 'Calcrick Chaos Core';
      break;
    case 'var':
      encryptedPath = path.join(__dirname, '..', 'temp', `var-encrypted-${file.file_name}`);
      configFunction = getNovaObfuscationConfig;
      commandName = 'Var';
      break;
    case 'quantum':
      encryptedPath = path.join(__dirname, '..', 'temp', `quantum-encrypted-${file.file_name}`);
      commandName = 'Quantum Vortex Encryption';
      break;
    case 'enc':
      const args = ctx.message.text.split(' ').slice(1);
      if (args.length !== 1 || !/^\d+$/.test(args[0]) || parseInt(args[0]) < 1 || parseInt(args[0]) > 365) {
        return ctx.replyWithMarkdown('❌ *Error:* Gunakan format `/enc [1-365]` untuk jumlah hari!');
      }
      encryptedPath = path.join(__dirname, '..', 'temp', `locked-encrypted-${file.file_name}`);
      commandName = 'Time-Locked Encryption';
      break;
    default:
      return ctx.replyWithMarkdown('❌ *Error:* Command tidak dikenali!');
  }

  try {
    const progressMessage = await ctx.replyWithMarkdown(
      "```css\n" +
      "🔒 JasherBot\n" +
      ` ⚙️ Memulai (${commandName}) (1%)\n` +
      ` ${createProgressBar(1)}\n` +
      "```\n" +
      "PROSES ENCRYPT "
    );

    const fileLink = await ctx.telegram.getFileLink(file.file_id);
    log(`Mengunduh file untuk ${commandName}: ${file.file_name}`);
    await updateProgress(ctx, progressMessage, 10, "Mengunduh");
    const response = await fetch(fileLink);
    let fileContent = await response.text();
    await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

    log(`Memvalidasi kode: ${file.file_name}`);
    await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
    try {
      new Function(fileContent);
    } catch (syntaxError) {
      throw new Error(`Kode tidak valid: ${syntaxError.message}`);
    }

    log(`Mengenkripsi file dengan ${commandName}`);
    await updateProgress(ctx, progressMessage, 40, `Inisialisasi ${commandName}`);
    
    let obfuscatedCode;
    if (command === 'quantum') {
      obfuscatedCode = await obfuscateQuantum(fileContent);
    } else if (command === 'enc') {
      const days = ctx.message.text.split(' ')[1];
      obfuscatedCode = await obfuscateTimeLocked(fileContent, days);
    } else {
      const obfuscated = await JsConfuser.obfuscate(fileContent, configFunction());
      obfuscatedCode = obfuscated.code || obfuscated;
    }
    
    await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
    await fs.ensureDir(path.dirname(encryptedPath));
    await fs.writeFile(encryptedPath, obfuscatedCode);
    await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

    log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
    try {
      new Function(obfuscatedCode);
    } catch (postObfuscationError) {
      throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
    }

    log(`Mengirim file terenkripsi: ${file.file_name}`);
    await ctx.replyWithDocument(
      { source: encryptedPath, filename: `${command.toLowerCase()}-encrypted-${file.file_name}` },
      {
        caption: `✅ *File terenkripsi (${commandName}) siap!*\nSUKSES ENCRYPT 🕊`,
        parse_mode: "Markdown",
      }
    );
    await updateProgress(ctx, progressMessage, 100, `${commandName} Selesai`);

    if (await fs.pathExists(encryptedPath)) {
      await fs.unlink(encryptedPath);
      log(`File sementara dihapus: ${encryptedPath}`);
    }
  } catch (error) {
    log(`Kesalahan saat ${commandName} obfuscation`, error);
    await ctx.replyWithMarkdown(
      `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
    );
    if (encryptedPath && await fs.pathExists(encryptedPath)) {
      await fs.unlink(encryptedPath);
      log(`File sementara dihapus setelah error: ${encryptedPath}`);
    }
  }
}

// Error handling
bot.catch((err, ctx) => {
  log(`Error for ${ctx.updateType}`, err);
});

// Start bot
bot.launch().then(() => {
  log('Bot started successfully');
});

// Enable graceful stop
process.once('SIGINT', () => {
  saveAllData();
  bot.stop('SIGINT');
});

process.once('SIGTERM', () => {
  saveAllData();
  bot.stop('SIGTERM');
});