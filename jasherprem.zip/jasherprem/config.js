global.BOT_TOKEN = "8198305874:AAH1Sfr54fyWkPSdfuLQTK_5hSyW69V2C7o";
global.MONGO_URL = "mongodb://jasher_coastfifth:c40755e5b21652b679c0d5b4688915155185303d@opqkay.h.filess.io:61004/jasher_coastfifth";
global.OWNER_ID = "8135269613";
global.PAYMENT_API_KEY = "tarjUb8mYusE5pdbHN8unB6snWA7CdSu";
global.PAYMENT_SECRET_KEY = "zElY27dFNFOPKbd2jO0o8xglJ5PfMVQqnI55VPrXghPKCyitciWP";
global.PAYMENT_URL = "https://yab-group.com/api/live/create";