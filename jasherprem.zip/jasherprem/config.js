global.BOT_TOKEN = process.env.BOT_TOKEN || '8404410811:AAEZIftEDvh7qfQ-zRxfCLbLuwMK3d9Vzc0';
global.MONGO_URL = process.env.MONGO_URL || 'mongodb://mybot_todaytime:94a632154d44683eb18a23ee50f3a31a69e621f8@2kred.h.filess.io:61004/mybot_todaytime';

module.exports = {
    BOT_TOKEN: global.BOT_TOKEN,
    MONGO_URL: global.MONGO_URL,
    CREATOR_ID: process.env.CREATOR_ID || '8373026763',
    GROUP_REQUIREMENT: 3, // Jumlah group yang harus diadd untuk mendapatkan kredit
    SHARE_COST: 2, // Biaya share dalam kredit
    PREMIUM_SHARE_COST: 1, // Biaya share premium dalam kredit
    INITIAL_CREDITS: 10 // Kredit awal setelah memenuhi syarat group
};