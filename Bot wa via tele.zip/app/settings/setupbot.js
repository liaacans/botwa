module.exports = {
  BOT_TOKEN: "7864459273:AAEJXXzljGCPa9Oo4Sea7ddBPdh_oyzjg2M", 
};