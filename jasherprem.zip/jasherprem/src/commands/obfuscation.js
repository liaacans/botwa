const fs = require('fs-extra');
const path = require('path');
const JsConfuser = require('js-confuser');
const { updateProgress, isPremium } = require('../../lib/utils');
const obfuscators = require('../../lib/obfuscators');

module.exports = (bot) => {
    // Helper function untuk handle obfuscation
    async function handleObfuscation(ctx, configName, displayName, customArgs = null) {
        const userId = ctx.from.id;
        
        // Cek premium untuk beberapa metode advanced
        const premiumMethods = ['quantum', 'nebula', 'zenc', 'var'];
        if (premiumMethods.includes(configName) && !isPremium(userId)) {
            return ctx.replyWithMarkdown(`
❌ *Fitur Premium Required!*

Method *${displayName}* hanya untuk user premium.

💎 Upgrade premium untuk akses:
• 🚀 Advanced obfuscation
• 🔒 Maximum protection
• ⚡ Priority processing

Ketik /buypremium untuk upgrade!`);
        }

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown(`❌ *Error:* Balas file .js dengan /${configName}!`);
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith('.js')) {
            return ctx.replyWithMarkdown('❌ *Error:* Hanya file .js yang didukung!');
        }

        const encryptedPath = path.join(__dirname, '..', '..', 'temp', `${configName}-encrypted-${file.file_name}`);
        
        try {
            await fs.ensureDir(path.dirname(encryptedPath));

            const progressMessage = await ctx.replyWithMarkdown(
                `\`\`\`css\n🔒 Jasher Bot\n ⚙️ Memulai (${displayName}) (1%)\n ${createProgressBar(1)}\n\`\`\`\nPROSES ENKRIPSI BERLANGSUNG...`
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            await updateProgress(ctx, progressMessage, 10, 'Mengunduh file');
            
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, 'Validasi kode');

            // Validasi syntax
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode tidak valid: ${syntaxError.message}`);
            }

            await updateProgress(ctx, progressMessage, 30, `Inisialisasi ${displayName}`);
            
            let obfuscatedCode;
            if (customArgs) {
                obfuscatedCode = await obfuscators[configName](fileContent, customArgs);
            } else {
                obfuscatedCode = await obfuscators[configName](fileContent);
            }

            await updateProgress(ctx, progressMessage, 60, 'Transformasi kode');

            // Validasi hasil obfuscation
            try {
                new Function(obfuscatedCode);
            } catch (postObfuscationError) {
                throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
            }

            await fs.writeFile(encryptedPath, obfuscatedCode);
            await updateProgress(ctx, progressMessage, 80, 'Finalisasi');

            await ctx.replyWithDocument(
                { source: encryptedPath, filename: `${configName}-encrypted-${file.file_name}` },
                {
                    caption: `✅ *File terenkripsi (${displayName}) siap!*\\nSUKSES ENCRYPT 🕊`,
                    parse_mode: 'Markdown'
                }
            );

            await updateProgress(ctx, progressMessage, 100, `${displayName} Selesai`);

            // Cleanup
            await fs.remove(encryptedPath);

        } catch (error) {
            console.log(`Error dalam ${configName}:`, error);
            await ctx.replyWithMarkdown(`❌ *Kesalahan:* ${error.message}\\n_Coba lagi dengan kode Javascript yang valid!_`);
            
            if (await fs.pathExists(encryptedPath)) {
                await fs.remove(encryptedPath);
            }
        }
    }

    function createProgressBar(percentage, length = 20) {
        const filled = Math.round((percentage / 100) * length);
        const empty = length - filled;
        return '█'.repeat(filled) + '░'.repeat(empty);
    }

    // Time-locked encryption
    bot.command('enc', async (ctx) => {
        const args = ctx.message.text.split(' ').slice(1);
        if (args.length !== 1 || !/^\d+$/.test(args[0]) || parseInt(args[0]) < 1 || parseInt(args[0]) > 365) {
            return ctx.replyWithMarkdown('❌ *Format:* /enc <1-365>\\nContoh: /enc 7 untuk 7 hari');
        }

        await handleObfuscation(ctx, 'timelocked', `Time-Locked (${args[0]} hari)`, args[0]);
    });

    // Custom encryption
    bot.command('enc2', async (ctx) => {
        const args = ctx.message.text.split(' ').slice(1);
        if (args.length < 1) {
            return ctx.replyWithMarkdown('❌ *Format:* /enc2 <custom_name>\\nContoh: /enc2 myscript');
        }

        await handleObfuscation(ctx, 'custom', `Custom (${args[0]})`, args[0]);
    });

    // Mandarin encryption
    bot.command('enc3', async (ctx) => {
        await handleObfuscation(ctx, 'mandarin', 'Hardened Mandarin');
    });

    // Arab encryption
    bot.command('enc4', async (ctx) => {
        await handleObfuscation(ctx, 'arab', 'Hardened Arab');
    });

    // Siu+Calcrick encryption
    bot.command('enc5', async (ctx) => {
        await handleObfuscation(ctx, 'siucalcrick', 'Calcrick Chaos Core');
    });

    // Japan encryption
    bot.command('japan', async (ctx) => {
        await handleObfuscation(ctx, 'japan', 'Hardened Japan');
    });

    // Nebula encryption
    bot.command('nebula', async (ctx) => {
        await handleObfuscation(ctx, 'nebula', 'Nebula Polymorphic Storm');
    });

    // Quantum encryption
    bot.command('quantum', async (ctx) => {
        await handleObfuscation(ctx, 'quantum', 'Quantum Vortex Encryption');
    });

    // Var encryption
    bot.command('var', async (ctx) => {
        await handleObfuscation(ctx, 'var', 'Var Dynamic Obfuscation');
    });

    // Invisible encryption
    bot.command('zenc', async (ctx) => {
        await handleObfuscation(ctx, 'invisible', 'Invisible Encryption');
    });

    // Deobfuscate
    bot.command('deobfuscate', async (ctx) => {
        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown('❌ *Error:* Balas file .js yang diobfuscate!');
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith('.js')) {
            return ctx.replyWithMarkdown('❌ *Error:* Hanya file .js yang didukung!');
        }

        await handleObfuscation(ctx, 'deobfuscate', 'Deobfuscation');
    });

    // XX command (alias untuk custom)
    bot.command('xx', async (ctx) => {
        const args = ctx.message.text.split(' ').slice(1);
        if (args.length < 1) {
            return ctx.replyWithMarkdown('❌ *Format:* /xx <custom_name>\\nContoh: /xx myscript');
        }

        await handleObfuscation(ctx, 'custom', `Custom (${args[0]})`, args[0]);
    });
};