const { Telegraf } = require('telegraf');
const { BOT_TOKEN } = require('./config');
const { connectDB } = require('./lib/database');
const { userMiddleware, groupMiddleware, premiumMiddleware, blacklistMiddleware } = require('./lib/middleware');

// Buat instance bot
const bot = new Telegraf(BOT_TOKEN);

// Connect to database
connectDB();

// Gunakan middleware
bot.use(userMiddleware);
bot.use(groupMiddleware);
bot.use(premiumMiddleware);
bot.use(blacklistMiddleware);

// Import dan setup commands
require('./src/commands')(bot);

// Import dan setup handlers
require('./src/handlers')(bot);

// Handle errors
bot.catch((err, ctx) => {
  console.error(`Error for ${ctx.updateType}:`, err);
  if (ctx.message) {
    ctx.reply('❌ Terjadi kesalahan saat memproses permintaan Anda.');
  }
});

// Start bot
bot.launch().then(() => {
  console.log('Bot Jasher Premium started!');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));