/*
Base Ori Rahman x Ifaa karisma

Sosmed media :
Ig : @4xglrs_
Tele : @idstore74_pw
Wa : Privet
Yt : A. Aulia Rahman Official (@auliarhmanproduction)

Thanks too::
Allah swt
Nabi Muhammad
Aulia Rahman
Ifaa karisma
Icha Maulidah Putriii
Zeeone Ofc
WanOfc
Naze
And Pengguna Copy/Paste:v

Note : don't remove copyright of this script!
*/

const config = require("./app/settings/config.js");
const setup = require("./app/settings/setupbot.js");
const TelegramBot = require("node-telegram-bot-api");
const {
  default: makeWASocket,
  DisconnectReason,
  useMultiFileAuthState,
  makeInMemoryStore,
  getAggregateVotesInPollMessage,
  proto,
  makeCacheableSignalKeyStore,
  fetchLatestBaileysVersion,
  Browsers, 
} = require("@whiskeysockets/baileys");
const fs = require("fs");
const P = require("pino");
const crypto = require("crypto");
const path = require("path");
const readline = require('readline');
const { Boom } = require('@hapi/boom');
const NodeCache = require('node-cache');
const { exec, spawn, execSync } = require('child_process');
const moment = require("moment-timezone");
const axios = require("axios");

const token = setup.BOT_TOKEN;
const bot = new TelegramBot(token, { polling: true });
const store = makeInMemoryStore({ logger: P().child({ level: 'silent', stream: 'store' }) })

global.api = (name, path = '/', query = {}, apikeyqueryname) => (name in global.APIs ? global.APIs[name] : name) + path + (query || apikeyqueryname ? '?' + decodeURIComponent(new URLSearchParams(Object.entries({ ...query, ...(apikeyqueryname ? { [apikeyqueryname]: global.APIKeys[name in global.APIs ? global.APIs[name] : name] } : {}) }))) : '')

const DataBase = require('./src/database');
const database = new DataBase(global.tempatDB);
const msgRetryCounterCache = new NodeCache();

(async () => {
	const loadData = await database.read()
	if (loadData && Object.keys(loadData).length === 0) {
		global.db = {
			set: {},
			users: {},
			game: {},
			groups: {},
			database: {},
			...(loadData || {}),
		}
		await database.write(global.db)
	} else {
		global.db = loadData
	}
	
	setInterval(async () => {
		if (global.db) await database.write(global.db)
	}, 30000)
})();

const { GroupUpdate, GroupParticipantsUpdate, MessagesUpsert, Solving } = require('./src/message');
const { isUrl, generateMessageTag, getBuffer, getSizeMedia, fetchJson, sleep } = require('./lib/function');


function isOwner(userId) {
  return config.OWNER_ID.includes(userId.toString());
}

// Fungsi untuk mengecek apakah user adalah admin
function isAdmin(userId) {
  return adminDB[userId] === true;
}

// Fungsi untuk mengecek apakah user adalah moderator
function isModerator(userId) {
  return modDB.moderators && modDB.moderators.includes(userId);
}

{}



// Direktori sesi dan database
const sessions = new Map();
const SESSIONS_DIR = "./sessions";
const SESSIONS_FILE = "./sessions/active_sessions.json";
const PREM_DB_FILE = "./database/premium.json";
const ADMIN_DB_FILE = "./database/admin.json";

// URL gambar untuk tampilan awal
const START_IMAGE_URL = "https://f.top4top.io/p_3338tz6bm0.jpg";

// Fungsi untuk membaca dan menulis database
function readDatabase(filePath) {
  try {
    if (fs.existsSync(filePath)) {
      return JSON.parse(fs.readFileSync(filePath));
    }
    return {};
  } catch (error) {
    console.error(`[ERROR] Failed to read database from ${filePath}:`, error);
    return {};
  }
}

function writeDatabase(filePath, data) {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
  } catch (error) {
    console.error(`[ERROR] Failed to write database to ${filePath}:`, error);
  }
}

// Database lokal
let premiumDB = readDatabase(PREM_DB_FILE);
let adminDB = readDatabase(ADMIN_DB_FILE);
let modDB = {};

// Membuat direktori sesi jika belum ada
function createSessionDir(botNumber) {
  const dir = `${SESSIONS_DIR}/${botNumber}`;
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  return dir;
}

// Fungsi untuk menyimpan sesi aktif
function saveActiveSessions(botNumber) {
  const activeSessions = Array.from(sessions.keys());
  fs.writeFileSync(SESSIONS_FILE, JSON.stringify(activeSessions, null, 2));
}

// Inisialisasi koneksi WhatsApp
async function initializeWhatsAppConnections() {
  try {
    if (fs.existsSync(SESSIONS_FILE)) {
      const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      console.log(`
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃ FOUND ACTIVE WHATSAPP SESSION
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃⌬ TOTAL : ${activeNumbers.length}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━`);

      for (const botNumber of activeNumbers) {
        console.log(`
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃ CURRENTLY CONNECTING WHATSAPP
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃⌬ NUMBER : ${botNumber}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
        const sessionDir = createSessionDir(botNumber);
        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

        const sock = makeWASocket({
          auth: state,
          printQRInTerminal: true,
          logger: P({ level: "silent" }),
          defaultQueryTimeoutMs: undefined,
        });

        await new Promise((resolve, reject) => {
          sock.ev.on("connection.update", async (update) => {
            const { connection, lastDisconnect } = update;
            if (connection === "open") {
              console.log(`
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃ SUCCESSFUL NUMBER CONNECTION
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃⌬ NUMBER : ${botNumber}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
              sessions.set(botNumber, sock);
              resolve();
            } else if (connection === "close") {
              const shouldReconnect =
                lastDisconnect?.error?.output?.statusCode !==
                DisconnectReason.loggedOut;
              if (shouldReconnect) {
                console.error(`[ERROR] Connection lost for ${botNumber}. Attempting to reconnect.`);
                await initializeWhatsAppConnections();
              } else {
                console.error(`[ERROR] Connection closed for ${botNumber}.`);
                reject(new Error("CONNECTION CLOSED"));
              }
            }
          });

          sock.ev.on("creds.update", saveCreds);
        });
      }
    }
  } catch (error) {
    console.error("[ERROR] Failed to initialize WhatsApp connections:", error);
  }
}

// Fungsi untuk menghubungkan bot ke WhatsApp
async function connectToWhatsApp(botNumber, chatId) {
  let statusMessage = await bot
    .sendMessage(chatId, `
┏━━━━━━━━━━━━━━━━━━━━━━
┃     INFORMATION
┣━━━━━━━━━━━━━━━━━━━━━━
┃⌬ NUMBER : ${botNumber}
┃⌬ STATUS : INITIALIZATIONℹ️
┗━━━━━━━━━━━━━━━━━━━━━━`, { parse_mode: "Markdown" })
    .then((msg) => msg.message_id);

  const sessionDir = createSessionDir(botNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode && statusCode >= 500 && statusCode < 600) {
        await bot.editMessageText(`
┏━━━━━━━━━━━━━━━━━━━━
┃       INFORMATION
┣━━━━━━━━━━━━━━━━━━━━
┃⌬ NUMBER : ${botNumber}
┃⌬ STATUS : RECONNECTING🔄
┗━━━━━━━━━━━━━━━━━━━━`, {
          chat_id: chatId,
          message_id: statusMessage,
          parse_mode: "Markdown",
        });
        await connectToWhatsApp(botNumber, chatId);
      } else {
        await bot.editMessageText(`
┏━━━━━━━━━━━━━━━━━━━━
┃       INFORMATION
┣━━━━━━━━━━━━━━━━━━━━
┃⌬ NUMBER : ${botNumber}
┃⌬ STATUS : FAILED 🔴
┗━━━━━━━━━━━━━━━━━━━━`, {
          chat_id: chatId,
          message_id: statusMessage,
          parse_mode: "Markdown",
        });
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        } catch (error) {
          console.error("Error deleting session:", error);
        }
      }
    } else if (connection === "open") {
      sessions.set(botNumber, sock);
      saveActiveSessions(botNumber);
      await bot.editMessageText(`
┏━━━━━━━━━━━━━━━━━━━━
┃       INFORMATION
┣━━━━━━━━━━━━━━━━━━━━
┃⌬ NUMBER : ${botNumber}
┃⌬ STATUS : CONNECTED 🟢
┗━━━━━━━━━━━━━━━━━━━━`, {
        chat_id: chatId,
        message_id: statusMessage,
        parse_mode: "Markdown",
      });
    } else if (connection === "connecting") {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
          const code = await sock.requestPairingCode(botNumber);
          const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;
          await bot.editMessageText(`
┏━━━━━━━━━━━━━━━━━━━━━
┃      PAIRING SESSION
┣━━━━━━━━━━━━━━━━━━━━━
┃⌬ NUMBER : ${botNumber}
┃⌬ CODE : ${formattedCode}
┗━━━━━━━━━━━━━━━━━━━━━`, {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          });
        }
      } catch (error) {
        console.error("Error requesting pairing code:", error);
        await bot.editMessageText(`
┏━━━━━━━━━━━━━━━━━━━━━
┃      PAIRING SESSION
┣━━━━━━━━━━━━━━━━━━━━━
┃⌬ NUMBER : ${botNumber}
┃⌬ STATUS : ${error.message}
┗━━━━━━━━━━━━━━━━━━━━━`, {
          chat_id: chatId,
          message_id: statusMessage,
          parse_mode: "Markdown",
        });
      }
    }
  });
  
  store.bind(sock.ev)
	
  await Solving(sock, store)

  sock.ev.on("creds.update", saveCreds);


sock.ev.on('contacts.update', (update) => {
		for (let contact of update) {
			let id = sock.decodeJid(contact.id)
			if (store && store.contacts) store.contacts[id] = { id, name: contact.notify }
		}
	});
	
	sock.ev.on('groups.update', async (update) => {
		await GroupUpdate(sock, update, store);
	});
	
	sock.ev.on('group-participants.update', async (update) => {
		await GroupParticipantsUpdate(sock, update, store);
	});
	
	sock.ev.on('messages.upsert', async (message) => {
		await MessagesUpsert(sock, message, store);
	});
	
	sock.ev.on('call', async (call) => {
		let botNumber = await sock.decodeJid(sock.user.id);
		if (db.set[botNumber].anticall) {
			for (let id of call) {
				if (id.status === 'offer') {
					let msg = await sock.sendMessage(id.from, { text: `Saat Ini, Kami Tidak Dapat Menerima Panggilan ${id.isVideo ? 'Video' : 'Suara'}.\nJika @${id.from.split('@')[0]} Memerlukan Bantuan, Silakan Hubungi Owner :)`, mentions: [id.from]});
					await sock.sendContact(id.from, global.owner, msg);
					await sock.rejectCall(id.id, id.from)
				}
			}
		}
	});
	
  return sock;
}

// Inisialisasi bot
async function initializeBot() {
  console.log(`
┏━━━━━━━━━━━━━━━━━━━━━━━━━━
┃ TERIMA KASIH TELAH MENEMUKAN SC INI
┣━━━━━━━━━━━━━━━━━━━━━━━━━━
┃ THANKS TO :
┃ • ALLAH SWT
┃ • NABI MUHAMMAD
┃ • ORTU
┃ • AULIA RAHMAN
┃ • Ifaa karisma
┃ • Ichaa M.P
┃ • Dan pengguna bot lainnya
┗━━━━━━━━━━━━━━━━━━━━━━━━━━`);

  await initializeWhatsAppConnections();
}

initializeBot();


//--------------- PESAN START DENGAN GAMBAR DAN MENU ---------------
bot.onText(/\/start/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const totalBot = sessions.size;

  const ownerStatus = isOwner(userId) ? "✅" : "❌";
  const modStatus = isModerator(userId) ? "✅" : "❌";
  try {
    const imageUrl = START_IMAGE_URL;
    const response = await axios.get(imageUrl, { responseType: "arraybuffer" });
    const imageBuffer = Buffer.from(response.data, "binary");

    const menu = `
╭━━━━[ UBOT WA FREE ]
┃ ⚅ *Developer* : *@auliacell_webid*
┃ ⚅ *Version* : Limitless
┃ ⚅ *Total bot* : ${totalBot}
┃ ⚅ *Moderator* : ${modStatus}
┃ ⚅ *Owner* : ${ownerStatus}
┃
┃ *OWNER PRINCE*
┃  /addbot - *connect bot*
┃  /listbot - *list of bot*
┃  /addadmin - *admin user*
┃  /deladmin - *remove admin*
┃  /addmod - *add moderator*
┃  /delmod - *remove moderator*
┃
┃ *ADMIN PRINCE*
┃  /addprem - *add to prem db*
┃  /delprem - *remove prem*
┃  /cekprem - *remove prem*
┃
┃ *MODERATOR PRINCE*
┃  /addtoken - *acces script*
┃  /deltoken - *remove acces*
┃  /listtoken - *list acces*
╰━━━━━━━━━━━━━━━━━━━━━━━━━❍`;
    await bot.sendPhoto(chatId, imageBuffer, {
      caption: menu,
      parse_mode: "Markdown",
    });
  } catch (error) {
    console.error("Error sending start message with image and menu:", error);
    bot.sendMessage(
      chatId,
      `👋 Halo, ${msg.from.username}! Selamat datang bot ini. (Gagal memuat gambar dan menu)`
    );
  }
});

bot.on('message', async (msg) => {
        require("./message/bbila")(msg, bot)
});

bot.onText(/\/addbot (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
      { parse_mode: "Markdown" }
    );
  }
  const botNumber = match[1].replace(/[^0-9]/g, "");

  try {
    await connectToWhatsApp(botNumber, chatId);
  } catch (error) {
    console.error("Error in addbot:", error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat menghubungkan ke WhatsApp. Silakan coba lagi."
    );
  }
});
//-------------- FITUR ADMIN --------------

// Fungsi untuk menambahkan admin
bot.onText(/\/addadmin (\d+)/, (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
      { parse_mode: "Markdown" }
    );
  }

  const userId = match[1];
  adminDB[userId] = true;
  writeDatabase(ADMIN_DB_FILE, adminDB);
  bot.sendMessage(chatId, `✅ Berhasil menambahkan ${userId} sebagai admin.`);
});

// Fungsi untuk menghapus admin
bot.onText(/\/deladmin (\d+)/, (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
      { parse_mode: "Markdown" }
    );
  }

  const userId = match[1];
  if (adminDB[userId]) {
    delete adminDB[userId];
    writeDatabase(ADMIN_DB_FILE, adminDB);
    bot.sendMessage(
      chatId,
      `✅ Berhasil menghapus ${userId} dari daftar admin.`
    );
  } else {
    bot.sendMessage(chatId, `❌ ${userId} tidak terdaftar sebagai admin.`);
  }
});

//-------------- FITUR PREMIUM --------------

// Fungsi untuk menambahkan user premium
bot.onText(/\/addprem (\d+) (\d+)/, (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id) && !isAdmin(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
      { parse_mode: "Markdown" }
    );
  }

  const userId = match[1];
  const days = parseInt(match[2]);
  const expirationDate = moment().add(days, "days").tz("Asia/Jakarta"); // Menambahkan waktu kadaluarsa

  premiumDB[userId] = {
    expired: expirationDate.format(),
  };
  writeDatabase(PREM_DB_FILE, premiumDB);

  bot.sendMessage(
    chatId,
    `✅ Berhasil menambahkan ${userId} sebagai user premium hingga ${expirationDate.format(
      "DD-MM-YYYY HH:mm:ss"
    )}`
  );
});

// Fungsi untuk menghapus user premium
bot.onText(/\/delprem (\d+)/, (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id) && !isAdmin(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
      { parse_mode: "Markdown" }
    );
  }

  const userId = match[1];
  if (premiumDB[userId]) {
    delete premiumDB[userId];
    writeDatabase(PREM_DB_FILE, premiumDB);
    bot.sendMessage(
      chatId,
      `✅ Berhasil menghapus ${userId} dari daftar user premium.`
    );
  } else {
    bot.sendMessage(
      chatId,
      `❌ ${userId} tidak terdaftar sebagai user premium.`
    );
  }
});

// Fungsi untuk mengecek status premium
bot.onText(/\/cekprem/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();

  if (premiumDB[userId]) {
    const expirationDate = moment(premiumDB[userId].expired);
    if (expirationDate.isAfter(moment())) {
      bot.sendMessage(
        chatId,
        `✅ Anda adalah user premium hingga ${expirationDate.format(
          "DD-MM-YYYY HH:mm:ss"
        )}`
      );
    } else {
      delete premiumDB[userId];
      writeDatabase(PREM_DB_FILE, premiumDB);
      bot.sendMessage(chatId, `❌ Status premium Anda telah kadaluarsa.`);
    }
  } else {
    bot.sendMessage(chatId, `❌ Anda bukan user premium.`);
  }
});

//--------------- FITUR TOKEN ---------------

// Fungsi untuk menambahkan token
bot.onText(/\/addtoken (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id) && !isModerator(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
      { parse_mode: "Markdown" }
    );
  }

  const newToken = match[1];
  try {
    let tokens = await readTokensFromGitHub();
    if (!tokens.botTokens) {
      tokens.botTokens = [];
    }
    if (!tokens.botTokens.includes(newToken)) {
      tokens.botTokens.push(newToken);
      await writeTokensToGitHub(tokens);
      bot.sendMessage(chatId, "✅ Token berhasil ditambahkan.");
    } else {
      bot.sendMessage(chatId, "❌ Token sudah ada.");
    }
  } catch (error) {
    console.error("Error adding token:", error);
    bot.sendMessage(chatId, "❌ Gagal menambahkan token. Periksa error log.");
  }
});

// Fungsi untuk menghapus token
bot.onText(/\/deltoken (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id) && !isModerator(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
      { parse_mode: "Markdown" }
    );
  }

  const tokenToDelete = match[1];
  try {
    let tokens = await readTokensFromGitHub();
    if (tokens.botTokens && tokens.botTokens.includes(tokenToDelete)) {
      tokens.botTokens = tokens.botTokens.filter(
        (token) => token !== tokenToDelete
      );
      await writeTokensToGitHub(tokens);
      bot.sendMessage(chatId, "✅ Token berhasil dihapus.");
    } else {
      bot.sendMessage(chatId, "❌ Token tidak ditemukan.");
    }
  } catch (error) {
    console.error("Error deleting token:", error);
    bot.sendMessage(chatId, "❌ Gagal menghapus token. Periksa error log.");
  }
});

// Fungsi untuk menampilkan daftar token
bot.onText(/\/listtoken/, async (msg) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id) && !isModerator(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
      { parse_mode: "Markdown" }
    );
  }

  try {
    const tokens = await readTokensFromGitHub();
    if (tokens.botTokens && tokens.botTokens.length > 0) {
      const tokenList = tokens.botTokens
        .map((token, index) => `${index + 1}. ${token}`)
        .join("\n");
      bot.sendMessage(chatId, `Daftar Token:\n${tokenList}`);
    } else {
      bot.sendMessage(chatId, "❌ Tidak ada token yang tersimpan.");
    }
  } catch (error) {
    console.error("Error listing tokens:", error);
    bot.sendMessage(
      chatId,
      "❌ Gagal menampilkan daftar token. Periksa error log."
    );
  }
});

//--------------- FITUR MODERATOR ---------------

// Fungsi untuk menambahkan moderator
bot.onText(/\/addmod (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
      { parse_mode: "Markdown" }
    );
  }

  const userId = match[1];
  try {
    let moderators = await readModeratorsFromGitHub();
    if (!moderators.moderators) {
      moderators.moderators = [];
    }
    if (!moderators.moderators.includes(userId)) {
      moderators.moderators.push(userId);
      await writeModeratorsToGitHub(moderators);
      bot.sendMessage(
        chatId,
        `✅ Berhasil menambahkan ${userId} sebagai moderator.`
      );
    } else {
      bot.sendMessage(
        chatId,
        `❌ ${userId} sudah terdaftar sebagai moderator.`
      );
    }
  } catch (error) {
    console.error("Error adding moderator:", error);
    bot.sendMessage(
      chatId,
      "❌ Gagal menambahkan moderator. Periksa error log."
    );
  }
});

// Fungsi untuk menghapus moderator
bot.onText(/\/delmod (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
      { parse_mode: "Markdown" }
    );
  }

  const userId = match[1];
  try {
    let moderators = await readModeratorsFromGitHub();
    if (moderators.moderators && moderators.moderators.includes(userId)) {
      moderators.moderators = moderators.moderators.filter(
        (id) => id !== userId
      );
      await writeModeratorsToGitHub(moderators);
      bot.sendMessage(
        chatId,
        `✅ Berhasil menghapus ${userId} dari daftar moderator.`
      );
    } else {
      bot.sendMessage(
        chatId,
        `❌ ${userId} tidak terdaftar sebagai moderator.`
      );
    }
  } catch (error) {
    console.error("Error deleting moderator:", error);
    bot.sendMessage(chatId, "❌ Gagal menghapus moderator. Periksa error log.");
  }
});

//--------------- LISTBOT ---------------
bot.onText(/\/listbot/, async (msg) => {
  const chatId = msg.chat.id;

  // Cek apakah user adalah owner, admin, atau moderator
  if (
    !isOwner(msg.from.id) &&
    !isAdmin(msg.from.id) &&
    !isModerator(msg.from.id)
  ) {
    return bot.sendMessage(
      chatId,
      "⚠️ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
      { parse_mode: "Markdown" }
    );
  }

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "❌ Tidak ada bot WhatsApp yang terhubung."
      );
    }

    let botList = "";
    let index = 1;
    for (const botNumber of sessions.keys()) {
      botList += `${index}. ${botNumber}\n`;
      index++;
    }

    bot.sendMessage(
      chatId,
      `*Daftar Bot WhatsApp yang Terhubung:*\n${botList}`,
      { parse_mode: "Markdown" }
    );
  } catch (error) {
    console.error("Error in listbot:", error);
    bot.sendMessage(
      chatId,
      "❌ Terjadi kesalahan saat menampilkan daftar bot. Silakan coba lagi."
    );
  }
});

console.log("Bot telah dimulai...");


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});

/*
Base Ori Rahman x Ifaa karisma

Sosmed media :
Ig : @4xglrs_
Tele : @idstore74_pw
Wa : Privet
Yt : A. Aulia Rahman Official (@auliarhmanproduction)

Thanks too::
Allah swt
Nabi Muhammad
Aulia Rahman
Ifaa karisma
Icha Maulidah Putriii
Zeeone Ofc
WanOfc
And Pengguna Copy/Paste:v

Note : don't remove copyright of this script!
*/