const db = require('../lib/database');

module.exports = (bot) => {
  // Handler ketika bot ditambahkan ke group
  bot.on('message', (ctx) => {
    if (ctx.message.new_chat_members) {
      const newMembers = ctx.message.new_chat_members;
      
      newMembers.forEach(member => {
        if (member.is_bot && member.username === bot.context.botInfo.username) {
          // Bot ditambahkan ke group
          const group = ctx.chat;
          
          db.addGroup(group, (err) => {
            if (err) {
              console.error('Error adding group:', err);
              return;
            }
            
            // Beri kredit kepada yang menambahkan bot
            const addedBy = ctx.from;
            db.getUser(addedBy.id, (err, user) => {
              if (err) {
                console.error('Error getting user:', err);
                return;
              }
              
              if (user) {
                db.updateUserCredit(addedBy.id, 10, (err) => {
                  if (err) {
                    console.error('Error updating credit:', err);
                  } else {
                    ctx.reply(
                      `Terima kasih ${addedBy.first_name} telah menambahkan bot ke group ini!\n` +
                      `Anda mendapatkan 10 kredit! Gunakan /credit untuk melihat kredit Anda.`
                    );
                  }
                });
              } else {
                // Buat user baru jika belum ada
                db.createUser(addedBy, (err) => {
                  if (err) {
                    console.error('Error creating user:', err);
                    return;
                  }
                  
                  db.updateUserCredit(addedBy.id, 10, (err) => {
                    if (err) {
                      console.error('Error updating credit:', err);
                    } else {
                      ctx.reply(
                        `Terima kasih ${addedBy.first_name} telah menambahkan bot ke group ini!\n` +
                        `Anda mendapatkan 10 kredit! Gunakan /credit untuk melihat kredit Anda.`
                      );
                    }
                  });
                });
              }
            });
          });
        }
      });
    }
  });
};