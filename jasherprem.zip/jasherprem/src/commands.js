const { User, Group } = require('../lib/database');
const { formatUserInfo } = require('../lib/utils');
const keyboards = require('./keyboards');

async function handleStart(ctx) {
    try {
        const userId = ctx.from.id;
        const username = ctx.from.username || '';
        const firstName = ctx.from.first_name || '';
        const lastName = ctx.from.last_name || '';
        
        // Cek apakah user sudah ada di database
        let user = await User.findOne({ userId });
        
        if (!user) {
            // Buat user baru jika belum ada
            user = new User({
                userId,
                username,
                firstName,
                lastName,
                credit: 0
            });
            await user.save();
        }
        
        const userInfo = formatUserInfo(ctx, user);
        
        // Kiram pesan dengan gambar dan menu
        await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
            caption: userInfo,
            parse_mode: 'HTML',
            reply_markup: keyboards.mainMenu().reply_markup
        });
    } catch (error) {
        console.error('Error in start command:', error);
        ctx.reply('Terjadi kesalahan. Silakan coba lagi.');
    }
}

async function handleHelp(ctx) {
    const helpText = `🤖 *Jasher Bot Help*

*Perintah yang tersedia:*
/start - Memulai bot
/help - Menampilkan bantuan
/credit - Menampilkan kredit Anda
/share - Membagikan pesan ke grup

*Cara menggunakan:*
1. Tambahkan bot ke grup Anda
2. Gunakan perintah /share di chat private untuk membagikan pesan
3. Tambahkan 3 grup untuk mendapatkan 10 kredit

*Biaya:*
- Share reguler: 2 kredit
- Share VIP: 5 kredit (lebih cepat)`;

    await ctx.reply(helpText, {
        parse_mode: 'Markdown',
        reply_markup: keyboards.backToMain().reply_markup
    });
}

async function handleCredit(ctx) {
    try {
        const userId = ctx.from.id;
        const user = await User.findOne({ userId });
        
        if (!user) {
            return ctx.reply('Anda belum terdaftar. Gunakan /start untuk mendaftar.');
        }
        
        await ctx.reply(`💎 *Kredit Anda: ${user.credit}*

Untuk menambah kredit, tambahkan bot ke 3 grup berbeda. Setiap grup yang ditambahkan memberikan 3 kredit.`, {
            parse_mode: 'Markdown',
            reply_markup: keyboards.backToMain().reply_markup
        });
    } catch (error) {
        console.error('Error in credit command:', error);
        ctx.reply('Terjadi kesalahan. Silakan coba lagi.');
    }
}

async function handleShare(ctx) {
    try {
        if (ctx.chat.type !== 'private') {
            return ctx.reply('Perintah ini hanya dapat digunakan di chat private.');
        }
        
        const userId = ctx.from.id;
        const user = await User.findOne({ userId });
        
        if (!user) {
            return ctx.reply('Anda belum terdaftar. Gunakan /start untuk mendaftar.');
        }
        
        // Cek apakah ada pesan yang di-reply
        const repliedMessage = ctx.message.reply_to_message;
        
        if (!repliedMessage) {
            return ctx.reply('Anda harus mereply pesan yang ingin dibagikan.', {
                reply_markup: keyboards.shareMenu().reply_markup
            });
        }
        
        await ctx.reply('Pilih jenis share yang ingin dilakukan:', {
            reply_markup: keyboards.shareMenu().reply_markup
        });
    } catch (error) {
        console.error('Error in share command:', error);
        ctx.reply('Terjadi kesalahan. Silakan coba lagi.');
    }
}

module.exports = {
    handleStart,
    handleHelp,
    handleCredit,
    handleShare
};