const { Markup } = require('telegraf');
const moment = require('moment-timezone');
const { isPremium, getPremiumDaysLeft, runtime, formatDate, escapeMarkdown } = require('../lib/utils');
const { obfuscateTimeLocked, obfuscateQuantum } = require('./obf');

// Start command
async function start(ctx) {
  const userId = ctx.from.id;
  const username = ctx.from.username || 'No Username';
  const firstName = ctx.from.first_name || '';
  const lastName = ctx.from.last_name || '';
  const isCreator = userId.toString() === global.DEVELOPER_ID;
  
  // Add user to database
  await global.db.addUser({
    id: userId,
    username,
    first_name: firstName,
    last_name: lastName,
    is_creator: isCreator
  });
  
  const caption = `╭─❒ 「 User Info 」 
├ Creator : ${global.DEVELOPER_USERNAME}
├ Name : @${username}
├ Profile : [${firstName}${lastName ? ' ' + lastName : ''}](tg://user?id=${userId})
├ ID Telegram Anda: ${userId}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreator ? 'True' : 'False'}

Silahkan pilih button dibawah ini!`;

  try {
    await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
      caption,
      parse_mode: 'Markdown',
      reply_markup: Markup.inlineKeyboard([
        [Markup.button.callback('Jasher Menu', 'jasher_menu')],
        [Markup.button.callback('Owner Menu', 'owner_menu')],
        [Markup.button.callback('Obf Menu', 'obf_menu')]
      ])
    });
  } catch (error) {
    await ctx.reply(caption, {
      parse_mode: 'Markdown',
      reply_markup: Markup.inlineKeyboard([
        [Markup.button.callback('Jasher Menu', 'jasher_menu')],
        [Markup.button.callback('Owner Menu', 'owner_menu')],
        [Markup.button.callback('Obf Menu', 'obf_menu')]
      ])
    });
  }
}

// Help command
async function help(ctx) {
  const helpText = `*Bot Jasher Premium Help*

*Available Commands:*
/menu - Show main menu
/owner - Show owner menu (for owners only)
/obf - Obfuscation menu

*Premium Features:*
- Add 3 groups to get 3 days premium
- Share in groups to extend premium
- VIP sharing for faster broadcasting

*Owner Commands:*
/addprem [user_id] [days] - Add premium to user
/delprem [user_id] - Remove premium from user
/listprem - List all premium users
/addbl [group_id] [reason] - Add group to blacklist
/delbl [group_id] - Remove group from blacklist
/listbl - List blacklisted groups
/autojasher - Start auto sharing
/stopautojasher - Stop auto sharing
/listgroup - List all active groups
/tourl - Convert photo to URL
/sharevip - VIP sharing to groups`;

  await ctx.reply(helpText, { parse_mode: 'Markdown' });
}

// Menu command
async function menu(ctx) {
  const userId = ctx.from.id;
  const username = ctx.from.username || 'No Username';
  const isCreator = userId.toString() === global.DEVELOPER_ID;
  const premiumStatus = isPremium(userId) ? `Aktif (${getPremiumDaysLeft(userId)} hari tersisa)` : 'Tidak Aktif';
  
  const caption = `╭─❒ 「 User Info 」 
├ Creator : ${global.DEVELOPER_USERNAME}
├ Name : @${username}
├ Profile : [${ctx.from.first_name}${ctx.from.last_name ? ' ' + ctx.from.last_name : ''}](tg://user?id=${userId})
├ ID Telegram Anda: ${userId}
├ Status Premium : ${premiumStatus}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreator ? 'True' : 'False'}

Silahkan pilih button dibawah ini!`;

  try {
    await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
      caption,
      parse_mode: 'Markdown',
      reply_markup: Markup.inlineKeyboard([
        [Markup.button.callback('Jasher Menu', 'jasher_menu')],
        [Markup.button.callback('Owner Menu', 'owner_menu')],
        [Markup.button.callback('Obf Menu', 'obf_menu')]
      ])
    });
  } catch (error) {
    await ctx.reply(caption, {
      parse_mode: 'Markdown',
      reply_markup: Markup.inlineKeyboard([
        [Markup.button.callback('Jasher Menu', 'jasher_menu')],
        [Markup.button.callback('Owner Menu', 'owner_menu')],
        [Markup.button.callback('Obf Menu', 'obf_menu')]
      ])
    });
  }
}

// Owner command
async function owner(ctx) {
  const userId = ctx.from.id;
  if (userId.toString() !== global.DEVELOPER_ID) {
    return ctx.reply('❌ Anda bukan owner bot!');
  }
  
  const ownerText = `*Owner Menu*

*Available Commands:*
/addprem [user_id] [days] - Add premium to user
/delprem [user_id] - Remove premium from user
/listprem - List all premium users
/addbl [group_id] [reason] - Add group to blacklist
/delbl [group_id] - Remove group from blacklist
/listbl - List blacklisted groups
/autojasher - Start auto sharing
/stopautojasher - Stop auto sharing
/listgroup - List all active groups
/tourl - Convert photo to URL
/sharevip - VIP sharing to groups`;

  await ctx.reply(ownerText, { parse_mode: 'Markdown' });
}

// Add premium command
async function addPremium(ctx) {
  const userId = ctx.from.id;
  if (userId.toString() !== global.DEVELOPER_ID) {
    return ctx.reply('❌ Anda bukan owner bot!');
  }
  
  const args = ctx.message.text.split(' ').slice(1);
  if (args.length < 2) {
    return ctx.reply('❌ Format salah. Gunakan: /addprem [user_id] [days]');
  }
  
  const targetUserId = parseInt(args[0]);
  const days = parseInt(args[1]);
  
  if (isNaN(targetUserId) || isNaN(days)) {
    return ctx.reply('❌ User ID dan hari harus angka!');
  }
  
  try {
    await global.db.setPremium(targetUserId, days);
    ctx.reply(`✅ Berhasil menambahkan ${days} hari premium untuk user ${targetUserId}`);
  } catch (error) {
    console.error(error);
    ctx.reply('❌ Gagal menambahkan premium');
  }
}

// Delete premium command
async function delPremium(ctx) {
  const userId = ctx.from.id;
  if (userId.toString() !== global.DEVELOPER_ID) {
    return ctx.reply('❌ Anda bukan owner bot!');
  }
  
  const args = ctx.message.text.split(' ').slice(1);
  if (args.length < 1) {
    return ctx.reply('❌ Format salah. Gunakan: /delprem [user_id]');
  }
  
  const targetUserId = parseInt(args[0]);
  
  if (isNaN(targetUserId)) {
    return ctx.reply('❌ User ID harus angka!');
  }
  
  try {
    await global.db.removePremium(targetUserId);
    ctx.reply(`✅ Berhasil menghapus premium untuk user ${targetUserId}`);
  } catch (error) {
    console.error(error);
    ctx.reply('❌ Gagal menghapus premium');
  }
}

// List premium command
async function listPremium(ctx) {
  const userId = ctx.from.id;
  if (userId.toString() !== global.DEVELOPER_ID) {
    return ctx.reply('❌ Anda bukan owner bot!');
  }
  
  try {
    const premiumUsers = await global.db.getAllPremiumUsers();
    if (premiumUsers.length === 0) {
      return ctx.reply('❌ Tidak ada user premium');
    }
    
    let listText = '*Daftar User Premium:*\n\n';
    premiumUsers.forEach(user => {
      const expiry = user.premium_expiry ? formatDate(user.premium_expiry) : 'Tidak ada';
      listText += `👤 ${user.first_name}${user.last_name ? ' ' + user.last_name : ''} (@${user.username || 'no_username'})\n`;
      listText += `🆔 ID: ${user.id}\n`;
      listText += `⏰ Expiry: ${expiry}\n`;
      listText += `📊 Groups: ${user.groups_added || 0}\n\n`;
    });
    
    ctx.reply(listText, { parse_mode: 'Markdown' });
  } catch (error) {
    console.error(error);
    ctx.reply('❌ Gagal mengambil daftar premium');
  }
}

// Add blacklist command
async function addBlacklist(ctx) {
  const userId = ctx.from.id;
  if (userId.toString() !== global.DEVELOPER_ID) {
    return ctx.reply('❌ Anda bukan owner bot!');
  }
  
  const args = ctx.message.text.split(' ').slice(1);
  if (args.length < 1) {
    return ctx.reply('❌ Format salah. Gunakan: /addbl [group_id] [reason]');
  }
  
  const groupId = parseInt(args[0]);
  const reason = args.slice(1).join(' ') || 'No reason provided';
  
  if (isNaN(groupId)) {
    return ctx.reply('❌ Group ID harus angka!');
  }
  
  try {
    await global.db.addToBlacklist(groupId, reason);
    ctx.reply(`✅ Berhasil menambahkan group ${groupId} ke blacklist`);
  } catch (error) {
    console.error(error);
    ctx.reply('❌ Gagal menambahkan ke blacklist');
  }
}

// Delete blacklist command
async function delBlacklist(ctx) {
  const userId = ctx.from.id;
  if (userId.toString() !== global.DEVELOPER_ID) {
    return ctx.reply('❌ Anda bukan owner bot!');
  }
  
  const args = ctx.message.text.split(' ').slice(1);
  if (args.length < 1) {
    return ctx.reply('❌ Format salah. Gunakan: /delbl [group_id]');
  }
  
  const groupId = parseInt(args[0]);
  
  if (isNaN(groupId)) {
    return ctx.reply('❌ Group ID harus angka!');
  }
  
  try {
    await global.db.removeFromBlacklist(groupId);
    ctx.reply(`✅ Berhasil menghapus group ${groupId} dari blacklist`);
  } catch (error) {
    console.error(error);
    ctx.reply('❌ Gagal menghapus dari blacklist');
  }
}

// List blacklist command
async function listBlacklist(ctx) {
  const userId = ctx.from.id;
  if (userId.toString() !== global.DEVELOPER_ID) {
    return ctx.reply('❌ Anda bukan owner bot!');
  }
  
  try {
    const blacklist = await global.db.getBlacklist();
    if (blacklist.length === 0) {
      return ctx.reply('✅ Tidak ada group di blacklist');
    }
    
    let listText = '*Daftar Blacklist Group:*\n\n';
    blacklist.forEach((group, index) => {
      listText += `${index + 1}. ${group.name}\n`;
      listText += `🆔 ID: ${group.id}\n`;
      listText += `📝 Reason: ${group.reason || 'No reason'}\n`;
      listText += `⏰ Added: ${formatDate(group.added_at)}\n\n`;
    });
    
    ctx.reply(listText, { parse_mode: 'Markdown' });
  } catch (error) {
    console.error(error);
    ctx.reply('❌ Gagal mengambil daftar blacklist');
  }
}

// AutoJasher command
async function autoJasher(ctx) {
  const userId = ctx.from.id;
  if (userId.toString() !== global.DEVELOPER_ID) {
    return ctx.reply('❌ Anda bukan owner bot!');
  }
  
  const args = ctx.message.text.split(' ').slice(1);
  const interval = args.length > 0 ? parseInt(args[0]) : 10;
  
  if (isNaN(interval) || interval < 5) {
    return ctx.reply('❌ Interval harus angka dan minimal 5 menit!');
  }
  
  try {
    await global.db.setAutoJasher(true, interval);
    ctx.reply(`✅ AutoJasher diaktifkan dengan interval ${interval} menit`);
  } catch (error) {
    console.error(error);
    ctx.reply('❌ Gagal mengaktifkan AutoJasher');
  }
}

// Stop AutoJasher command
async function stopAutoJasher(ctx) {
  const userId = ctx.from.id;
  if (userId.toString() !== global.DEVELOPER_ID) {
    return ctx.reply('❌ Anda bukan owner bot!');
  }
  
  try {
    await global.db.setAutoJasher(false);
    ctx.reply('✅ AutoJasher dimatikan');
  } catch (error) {
    console.error(error);
    ctx.reply('❌ Gagal mematikan AutoJasher');
  }
}

// List group command
async function listGroup(ctx) {
  const userId = ctx.from.id;
  if (userId.toString() !== global.DEVELOPER_ID) {
    return ctx.reply('❌ Anda bukan owner bot!');
  }
  
  try {
    const groups = await global.db.getAllGroups();
    if (groups.length === 0) {
      return ctx.reply('❌ Tidak ada group aktif');
    }
    
    let listText = '*Daftar Group Aktif:*\n\n';
    groups.forEach((group, index) => {
      listText += `${index + 1}. ${group.name}\n`;
      listText += `🆔 ID: ${group.id}\n`;
      listText += `👤 Added by: ${group.added_by}\n`;
      listText += `⏰ Added: ${formatDate(group.added_at)}\n\n`;
    });
    
    ctx.reply(listText, { parse_mode: 'Markdown' });
  } catch (error) {
    console.error(error);
    ctx.reply('❌ Gagal mengambil daftar group');
  }
}

// To URL command
async function toUrl(ctx) {
  const userId = ctx.from.id;
  if (userId.toString() !== global.DEVELOPER_ID) {
    return ctx.reply('❌ Anda bukan owner bot!');
  }
  
  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.photo) {
    return ctx.reply('❌ Balas pesan dengan foto!');
  }
  
  const photo = ctx.message.reply_to_message.photo;
  const fileId = photo[photo.length - 1].file_id;
  const fileLink = await ctx.telegram.getFileLink(fileId);
  
  ctx.reply(`✅ URL Foto: ${fileLink}`, {
    reply_to_message_id: ctx.message.reply_to_message.message_id
  });
}

// Share VIP command
async function shareVip(ctx) {
  const userId = ctx.from.id;
  if (userId.toString() !== global.DEVELOPER_ID) {
    return ctx.reply('❌ Anda bukan owner bot!');
  }
  
  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.text) {
    return ctx.reply('❌ Balas pesan dengan teks yang ingin di-share!');
  }
  
  const text = ctx.message.reply_to_message.text;
  const groups = await global.db.getAllGroups();
  
  if (groups.length === 0) {
    return ctx.reply('❌ Tidak ada group untuk di-share');
  }
  
  ctx.reply(`🚀 Memulai VIP sharing ke ${groups.length} group...`);
  
  let success = 0;
  let failed = 0;
  
  for (const group of groups) {
    try {
      const isBlacklisted = await global.db.isBlacklisted(group.id);
      if (isBlacklisted) {
        failed++;
        continue;
      }
      
      await ctx.telegram.sendMessage(group.id, text, { parse_mode: 'Markdown' });
      success++;
      
      // Delay to avoid rate limiting
      await new Promise(resolve => setTimeout(resolve, 1000));
    } catch (error) {
      console.error(`Error sending to group ${group.id}:`, error);
      failed++;
      
      // If group is inaccessible, deactivate it
      if (error.description && (error.description.includes('chat not found') || 
          error.description.includes('bot was kicked') || 
          error.description.includes('bot is not a member'))) {
        await global.db.deactivateGroup(group.id);
      }
    }
  }
  
  ctx.reply(`✅ VIP Sharing selesai!\nBerhasil: ${success}\nGagal: ${failed}`);
}

// Obf menu command
async function obfMenu(ctx) {
  const obfText = `*Obfuscation Menu*

Pilih jenis obfuscation yang diinginkan:

1. *Time-Locked Encryption* - Obfuscation dengan masa aktif tertentu
2. *Quantum Vortex Encryption* - Obfuscation tingkat tinggi dengan fitur self-evolving

Balas pesan ini dengan kode JavaScript yang ingin di-obfuscate, lalu pilih jenis obfuscation.`;

  await ctx.reply(obfText, { 
    parse_mode: 'Markdown',
    reply_markup: Markup.inlineKeyboard([
      [Markup.button.callback('Time-Locked Encryption', 'obf_time_locked')],
      [Markup.button.callback('Quantum Vortex Encryption', 'obf_quantum')],
      [Markup.button.callback('Kembali', 'main_menu')]
    ])
  });
}

module.exports = {
  start,
  help,
  menu,
  owner,
  addPremium,
  delPremium,
  listPremium,
  addBlacklist,
  delBlacklist,
  listBlacklist,
  autoJasher,
  stopAutoJasher,
  listGroup,
  toUrl,
  shareVip,
  obfMenu
};