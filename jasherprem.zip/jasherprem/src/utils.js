const moment = require('moment-timezone');

function runtime(seconds) {
  const days = Math.floor(seconds / (3600 * 24));
  seconds %= 3600 * 24;
  const hours = Math.floor(seconds / 3600);
  seconds %= 3600;
  const minutes = Math.floor(seconds / 60);
  seconds %= 60;
  
  return `${days}d ${hours}h ${minutes}m ${Math.floor(seconds)}s`;
}

function formatUserInfo(ctx, userData) {
  const sender = ctx.from.username ? `@${ctx.from.username}` : ctx.from.first_name;
  const userTelelu = ctx.from.username ? `@${ctx.from.username}` : 'Tidak ada username';
  const isCreator = ctx.from.id.toString() === process.env.OWNER_ID;
  
  return `Hi kak ${sender}
╭─❒ 「 User Info 」 
├ Creator : ${userTelelu}
├ Name : ${ctx.from.first_name}${ctx.from.last_name ? ' ' + ctx.from.last_name : ''}
├ Profile : ${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : Linux
├ Platform : Bot Telegram
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreator ? 'True' : 'False'}
Silahkan pilih button dibawah ini!`;
}

module.exports = { runtime, formatUserInfo };