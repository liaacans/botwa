const { Telegraf, session } = require('telegraf');
const { connectDB } = require('./lib/database');
const { userMiddleware, groupMiddleware, checkBlacklist } = require('./lib/middleware');
const { setupMainMenu, setupObfCommands, setupAdminCommands, setupOwnerCommands } = require('./src/commands');
const { setupPaymentCommands } = require('./src/payments');
const { handleNewChatMembers, handleLeftChatMember, handleGroupMessage, handleShare, handleTourl } = require('./src/handlers');
const { log } = require('./lib/utils');
const cron = require('node-cron');
const path = require('path');
const fs = require('fs-extra');

// Load config
require('./config');

// Buat instance bot
const bot = new Telegraf(global.BOT_TOKEN);

// Setup session
bot.use(session());

// Buat folder temp jika belum ada
const tempDir = path.join(__dirname, 'temp');
if (!fs.existsSync(tempDir)) {
  fs.mkdirSync(tempDir);
}

// Middleware
bot.use(userMiddleware);
bot.use(groupMiddleware);
bot.use(checkBlacklist);

// Setup commands
setupMainMenu(bot);
setupObfCommands(bot);
setupAdminCommands(bot);
setupOwnerCommands(bot);
setupPaymentCommands(bot);

// Handlers
bot.on('new_chat_members', handleNewChatMembers);
bot.on('left_chat_member', handleLeftChatMember);
bot.on('text', handleGroupMessage);
bot.on('text', handleShare);

// Command tourl
bot.command('tourl', handleTourl);

// Command help
bot.command('help', (ctx) => {
  ctx.reply(`
🤖 **Jasher Bot Help**

**Umum:**
/start - Memulai bot
/menu - Menampilkan menu
/help - Bantuan
/status - Status bot
/info - Info bot
/tourl - Upload foto ke URL

**Premium:**
/buyprem - Beli akses premium
/mysc - Script saya

**Share:**
/share - Bagikan teks ke group (reply pesan atau ketik teks)

**Obfuscation:**
/enc <hari> - Time-Locked Encryption
/enc2 <nama> - Custom Encryption
/enc3 - Mandarin Encryption
/enc4 - Arab Encryption
/enc5 - Siu+Calcrick Encryption
/japan - Japan Encryption
/nebula - Nebula Encryption
/var - Var Encryption
/zenc - Invisible Encryption
/quantum - Quantum Encryption
/deobfuscate - Deobfuscate script
/xx <nama> - Custom Encryption dengan nama

**Admin Group:**
/antispam - Aktifkan/nonaktifkan antispam
/noevent - Aktifkan/nonaktifkan noevent
/nolinks - Aktifkan/nonaktifkan nolinks
/noforwards - Aktifkan/nonaktifkan noforwards
/nocontacts - Aktifkan/nonaktifkan nocontacts
/nohastags - Aktifkan/nonaktifkan nohastags
/nocommands - Aktifkan/nonaktifkan nocommands

**Owner Only:**
/addbl - Tambah blacklist
/delbl - Hapus blacklist
/listbl - List blacklist
/addprem - Tambah premium
/delprem - Hapus premium
/listprem - List premium
/bc - Broadcast
/stats - Statistik
/groups - List group
/cleanup - Hapus group tidak aktif
  `.trim(), { parse_mode: 'Markdown' });
});

// Command menu
bot.command('menu', (ctx) => {
  ctx.reply('ℹ️ Gunakan /start untuk melihat menu utama');
});

// Command mysc
bot.command('mysc', async (ctx) => {
  const user = ctx.user;
  
  if (user.isPremium && user.premiumExpiry > new Date()) {
    ctx.reply('✅ Anda adalah user premium!');
  } else {
    ctx.reply(
      `❌ Anda bukan user premium.\n` +
      `Tambahkan bot ke 3 group atau beli premium dengan /buyprem`
    );
  }
});

// Error handling
bot.catch((err, ctx) => {
  log(`Error for ${ctx.updateType}: ${err.message}`);
  ctx.reply('❌ Terjadi kesalahan! Silakan coba lagi.');
});

// Job untuk membersihkan file temp setiap jam
cron.schedule('0 * * * *', async () => {
  try {
    const files = await fs.readdir(tempDir);
    const now = Date.now();
    
    for (const file of files) {
      const filePath = path.join(tempDir, file);
      const stat = await fs.stat(filePath);
      
      // Hapus file yang berumur lebih dari 1 jam
      if (now - stat.mtimeMs > 60 * 60 * 1000) {
        await fs.unlink(filePath);
        log(`Cleaned up temp file: ${file}`);
      }
    }
  } catch (error) {
    log(`Error cleaning temp files: ${error.message}`);
  }
});

// Job untuk mengecek expired premium setiap hari
cron.schedule('0 0 * * *', async () => {
  try {
    const expiredUsers = await require('./lib/database').User.find({
      isPremium: true,
      premiumExpiry: { $lte: new Date() }
    });
    
    for (const user of expiredUsers) {
      user.isPremium = false;
      user.premiumExpiry = null;
      await user.save();
      
      log(`Premium expired for user: ${user.userId}`);
      
      // Kirim notifikasi ke user
      try {
        await bot.telegram.sendMessage(
          user.userId,
          '❌ Premium Anda telah kadaluarsa. Gunakan /buyprem untuk memperpanjang.'
        );
      } catch (error) {
        // User mungkin sudah memblokir bot
        log(`Failed to notify user ${user.userId}: ${error.message}`);
      }
    }
    
    log(`Checked premium expiry: ${expiredUsers.length} users expired`);
  } catch (error) {
    log(`Error checking premium expiry: ${error.message}`);
  }
});

// Start bot
async function startBot() {
  try {
    // Connect to database
    await connectDB();
    
    // Start bot
    await bot.launch();
    log('Bot started successfully');
    
    // Enable graceful stop
    process.once('SIGINT', () => bot.stop('SIGINT'));
    process.once('SIGTERM', () => bot.stop('SIGTERM'));
  } catch (error) {
    log(`Failed to start bot: ${error.message}`);
    process.exit(1);
  }
}

startBot();