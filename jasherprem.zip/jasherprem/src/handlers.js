const { User } = require('../lib/database');
const { 
    getMainMenuKeyboard, 
    getJasherMenuKeyboard, 
    getOwnerMenuKeyboard, 
    getPremiumMenuKeyboard 
} = require('./commands');

// Handle callback queries
async function handleCallbacks(ctx) {
    const callbackData = ctx.callbackQuery.data;
    const userId = ctx.from.id;
    const user = await User.findOne({ userId });
    
    switch (callbackData) {
        case 'main_menu':
            const isCreator = userId.toString() === process.env.ADMIN_ID;
            const message = formatUserInfo(ctx, user, isCreator);
            await ctx.editMessageCaption(message, {
                parse_mode: 'HTML',
                ...getMainMenuKeyboard(ctx, user)
            });
            break;
            
        case 'jasher_menu':
            await ctx.editMessageCaption('🎯 <b>Jasher Menu</b>\nPilih opsi di bawah:', {
                parse_mode: 'HTML',
                ...getJasherMenuKeyboard()
            });
            break;
            
        case 'owner_menu':
            if (userId.toString() === process.env.ADMIN_ID) {
                await ctx.editMessageCaption('👤 <b>Owner Menu</b>\nPilih opsi di bawah:', {
                    parse_mode: 'HTML',
                    ...getOwnerMenuKeyboard()
                });
            } else {
                await ctx.answerCbQuery('❌ Anda bukan owner!');
            }
            break;
            
        case 'premium_menu':
            if (user.isPremium) {
                await ctx.editMessageCaption('⭐ <b>Premium Menu</b>\nPilih opsi di bawah:', {
                    parse_mode: 'HTML',
                    ...getPremiumMenuKeyboard()
                });
            } else {
                await ctx.answerCbQuery('❌ Anda bukan pengguna premium!');
            }
            break;
            
        case 'credit_command':
            await ctx.answerCbQuery();
            await ctx.reply(`💎 Kredit Anda: ${user.credit}`);
            break;
            
        case 'share_command':
            await handleShare(ctx, user);
            break;
            
        case 'share_vip':
            await handleShareVip(ctx, user);
            break;
            
        case 'broadcast_command':
            await handleBroadcastCommand(ctx);
            break;
            
        case 'add_premium':
            await handleAddPremium(ctx);
            break;
            
        case 'remove_premium':
            await handleRemovePremium(ctx);
            break;
            
        case 'list_premium':
            await handleListPremium(ctx);
            break;
            
        case 'owner_info':
            await ctx.answerCbQuery();
            await ctx.reply('👨‍💻 Owner: @your_username\nHubungi owner untuk info lebih lanjut.');
            break;
            
        default:
            await ctx.answerCbQuery('❌ Perintah tidak dikenali');
    }
}

// Handle share command
async function handleShare(ctx, user) {
    if (ctx.chat.type !== 'private') {
        await ctx.reply('❌ Perintah ini hanya bisa digunakan di chat private!');
        return;
    }
    
    if (user.credit < 2) {
        await ctx.reply('❌ Kredit Anda tidak cukup! Tambahkan bot ke 3 grup untuk mendapatkan kredit.');
        return;
    }
    
    // Check if user has added at least 3 groups
    if (user.addedGroups.length < 3) {
        await ctx.reply(`❌ Anda harus menambahkan bot ke ${3 - user.addedGroups.length} grup lagi untuk menggunakan fitur share.`);
        return;
    }
    
    // Ask for message to share
    await ctx.reply('📤 Silakan kirim pesan yang ingin di-share atau balas pesan yang ingin di-share:');
    // Set state to wait for message
    // (In a real implementation, you would use session or state management)
}

// Handle VIP share
async function handleShareVip(ctx, user) {
    if (!user.isPremium) {
        await ctx.reply('❌ Fitur ini hanya untuk pengguna premium!');
        return;
    }
    
    if (ctx.chat.type !== 'private') {
        await ctx.reply('❌ Perintah ini hanya bisa digunakan di chat private!');
        return;
    }
    
    // Ask for message to share
    await ctx.reply('🚀 Silakan kirim pesan yang ingin di-share VIP:');
    // Set state to wait for message
}

// Handle broadcast command (admin only)
async function handleBroadcastCommand(ctx) {
    if (ctx.from.id.toString() !== process.env.ADMIN_ID) {
        await ctx.reply('❌ Anda tidak memiliki akses ke fitur ini!');
        return;
    }
    
    await ctx.reply('📢 Silakan kirim pesan yang ingin di-broadcast:');
    // Set state to wait for broadcast message
}

// Handle add premium (admin only)
async function handleAddPremium(ctx) {
    if (ctx.from.id.toString() !== process.env.ADMIN_ID) {
        await ctx.reply('❌ Anda tidak memiliki akses ke fitur ini!');
        return;
    }
    
    await ctx.reply('👤 Silakan kirim user ID yang ingin ditambahkan sebagai premium:');
    // Set state to wait for user ID
}

// Handle remove premium (admin only)
async function handleRemovePremium(ctx) {
    if (ctx.from.id.toString() !== process.env.ADMIN_ID) {
        await ctx.reply('❌ Anda tidak memiliki akses ke fitur ini!');
        return;
    }
    
    await ctx.reply('👤 Silakan kirim user ID yang ingin dihapus dari premium:');
    // Set state to wait for user ID
}

// Handle list premium (admin only)
async function handleListPremium(ctx) {
    if (ctx.from.id.toString() !== process.env.ADMIN_ID) {
        await ctx.reply('❌ Anda tidak memiliki akses ke fitur ini!');
        return;
    }
    
    const premiumUsers = await User.find({ isPremium: true });
    if (premiumUsers.length === 0) {
        await ctx.reply('❌ Tidak ada pengguna premium.');
        return;
    }
    
    let message = '⭐ <b>Daftar Pengguna Premium</b>\n\n';
    premiumUsers.forEach((user, index) => {
        message += `${index + 1}. ${user.firstName || 'Unknown'} (@${user.username || 'no_username'}) - ID: ${user.userId}\n`;
    });
    
    await ctx.reply(message, { parse_mode: 'HTML' });
}

module.exports = {
    handleCallbacks,
    handleShare,
    handleShareVip,
    handleBroadcastCommand,
    handleAddPremium,
    handleRemovePremium,
    handleListPremium
};