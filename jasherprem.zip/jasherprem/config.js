global.BOT_TOKEN = "YOUR_BOT_TOKEN_HERE";
global.MONGO_URL = "mongodb://localhost:27017/jasherbot";
global.OWNER_ID = "YOUR_TELEGRAM_ID_HERE";
global.PAYMENT_API_KEY = "tarjUb8mYusE5pdbHN8unB6snWA7CdSu";
global.PAYMENT_SECRET_KEY = "zElY27dFNFOPKbd2jO0o8xglJ5PfMVQqnI55VPrXghPKCyitciWP";
global.PAYMENT_URL = "https://yab-group.com/api/live/create";