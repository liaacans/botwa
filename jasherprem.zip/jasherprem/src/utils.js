const moment = require('moment-timezone');

// Format runtime
function runtime(seconds) {
  const days = Math.floor(seconds / (3600 * 24));
  seconds %= 3600 * 24;
  const hours = Math.floor(seconds / 3600);
  seconds %= 3600;
  const minutes = Math.floor(seconds / 60);
  seconds %= 60;
  
  return `${days}d ${hours}h ${minutes}m ${Math.floor(seconds)}s`;
}

// Parse mode untuk telegraf
function parseMode(text) {
  // Deteksi format teks (Markdown atau HTML)
  if (text.includes('<b>') || text.includes('<i>') || text.includes('<a')) {
    return 'HTML';
  } else if (text.includes('*') || text.includes('_') || text.includes('`')) {
    return 'Markdown';
  }
  return null;
}

module.exports = { runtime, parseMode, moment };