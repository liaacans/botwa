const { Markup } = require('telegraf');
const db = require('../lib/database');
const { createMainMenu } = require('./utils');

// Handler untuk callback query
function handleCallbackQuery(ctx) {
    const data = ctx.callbackQuery.data;
    const user = db.getUser(ctx.from.id);
    
    switch (data) {
        case 'jasher_menu':
            showJasherMenu(ctx, user);
            break;
        case 'owner_menu':
            showOwnerMenu(ctx, user);
            break;
        case 'add_group':
            showAddGroupInfo(ctx, user);
            break;
        case 'info':
            showInfo(ctx, user);
            break;
        case 'back_to_main':
            const { message, keyboard } = createMainMenu(ctx, user);
            ctx.editMessageText(message, keyboard);
            break;
        default:
            ctx.answerCbQuery('Menu tidak dikenali');
    }
}

// Handler untuk message
function handleMessage(ctx) {
    // Jika bot ditambahkan ke group
    if (ctx.message.new_chat_members) {
        const botId = ctx.botInfo.id;
        const newMembers = ctx.message.new_chat_members;
        
        if (newMembers.some(member => member.id === botId)) {
            // Bot ditambahkan ke group
            const groupData = {
                id: ctx.chat.id,
                title: ctx.chat.title,
                type: ctx.chat.type,
                addedAt: new Date().toISOString()
            };
            
            // Cari siapa yang menambahkan bot
            const addedBy = ctx.message.from;
            if (addedBy) {
                db.addUserGroup(addedBy.id, groupData);
                ctx.reply(`Terima kasih telah menambahkan bot ke group ini!`);
            }
        }
    }
}

// Menampilkan menu Jasher
function showJasherMenu(ctx, user) {
    const message = `🎯 *JASHER MENU*
    
Fitur yang tersedia:
• Share pesan ke semua group
• ShareVIP (premium only)
• Cek kredit
• Info group yang telah ditambahkan

Gunakan perintah:
/credit - Cek kredit
/share - Share pesan (2 kredit)
/sharevip - Share pesan premium`;

    const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('🔙 Kembali', 'back_to_main')]
    ]);

    ctx.editMessageText(message, { parse_mode: 'Markdown', ...keyboard });
}

// Menampilkan menu Owner
function showOwnerMenu(ctx, user) {
    const isOwner = ctx.from.id === global.OWNER_ID;
    
    let message = `👑 *OWNER MENU*`;
    
    if (isOwner) {
        message += `
        
Fitur owner:
• Broadcast ke semua user
• Kelola user premium
• Lihat statistik bot

Gunakan perintah:
/broadcast - Broadcast pesan
/addprem - Tambah user premium
/delprem - Hapus user premium
/listprem - List user premium`;
    } else {
        message += `\n\nAnda bukan owner bot!`;
    }

    const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('🔙 Kembali', 'back_to_main')]
    ]);

    ctx.editMessageText(message, { parse_mode: 'Markdown', ...keyboard });
}

// Menampilkan info add group
function showAddGroupInfo(ctx, user) {
    const groups = user.joinedGroups || [];
    const groupsNeeded = Math.max(0, 3 - groups.length);
    
    let message = `➕ *ADD GROUP INFO*
    
Group yang telah ditambahkan: ${groups.length}/3`;

    if (groups.length > 0) {
        message += `\n\nGroup Anda:`;
        groups.forEach((group, index) => {
            message += `\n${index + 1}. ${group.title} (${group.type})`;
        });
    }
    
    if (groupsNeeded > 0) {
        message += `\n\nAnda perlu menambahkan ${groupsNeeded} group lagi untuk mendapatkan 10 kredit tambahan.`;
    } else {
        message += `\n\nAnda sudah memenuhi syarat untuk mendapatkan 10 kredit!`;
    }

    const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('🔙 Kembali', 'back_to_main')]
    ]);

    ctx.editMessageText(message, { parse_mode: 'Markdown', ...keyboard });
}

// Menampilkan info
function showInfo(ctx, user) {
    const message = `ℹ️ *INFO BOT JASHER*
    
Bot Jasher adalah bot untuk sharing pesan ke multiple group.

Cara penggunaan:
1. Tambahkan bot ke 3 group untuk mendapatkan 10 kredit
2. Gunakan perintah /share di private chat dengan mereply pesan yang ingin di-share
3. Setiap share akan mengurangi 2 kredit

Fitur premium:
- ShareVIP untuk broadcast lebih cepat
- Prioritas pengiriman pesan

Hubungi owner untuk menjadi user premium.`;

    const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('🔙 Kembali', 'back_to_main')]
    ]);

    ctx.editMessageText(message, { parse_mode: 'Markdown', ...keyboard });
}

module.exports = {
    handleCallbackQuery,
    handleMessage
};