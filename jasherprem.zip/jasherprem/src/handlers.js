const { Markup } = require('telegraf');
const moment = require('moment-timezone');
const { addUser, addGroup, removeGroup, addPremium, isPremium } = require('../lib/database');
const { runtime, log } = require('../lib/utils');

// Handler untuk callback query (button)
function setupHandlers(bot) {
  // Handler untuk callback query
  bot.on('callback_query', async (ctx) => {
    const data = ctx.callbackQuery.data;
    const userId = ctx.from.id;
    const username = ctx.from.username || 'Tidak ada';
    const isCreator = userId.toString() === global.DEVELOPER_ID;
    
    switch (data) {
      case 'jasher_menu':
        const jasherMenu = `
╭─❒ 「 Jasher Menu 」 
├ /sharefree - Share pesan gratis ke semua grup
├ /sharevip - Share pesan VIP ke semua grup (Premium only)
├ /tourl - Ubah foto menjadi URL
╰❒ /menu - Kembali ke menu utama`;

        const jasherKeyboard = Markup.inlineKeyboard([
          [Markup.button.callback('Kembali', 'main_menu')],
          [Markup.button.callback('Obf Menu', 'obf_menu')],
          [Markup.button.callback('Owner Menu', 'owner_menu')]
        ]);

        await ctx.editMessageCaption(jasherMenu, {
          parse_mode: 'Markdown',
          ...jasherKeyboard
        });
        break;

      case 'obf_menu':
        const obfMenu = `
╭─❒ 「 Obf Menu 」 
├ /enc3 - Mandarin Obfuscation (Premium)
├ /enc4 - Arab Obfuscation (Premium)
├ /japan - Japan Obfuscation (Premium)
├ /zenc - Invisible Obfuscation (Premium)
├ /xx <nama> - Custom Obfuscation (Premium)
├ /quantum - Quantum Obfuscation (Premium)
├ /var - Var Obfuscation (Premium)
├ /nebula - Nebula Obfuscation (Premium)
├ /enc5 - Siu+Calcrick Obfuscation (Premium)
├ /enc2 <text> - Custom Text Obfuscation (Premium)
╰❒ /enc <hari> - Time-Locked Obfuscation (Premium)`;

        const obfKeyboard = Markup.inlineKeyboard([
          [Markup.button.callback('Kembali', 'main_menu')],
          [Markup.button.callback('Jasher Menu', 'jasher_menu')],
          [Markup.button.callback('Owner Menu', 'owner_menu')]
        ]);

        await ctx.editMessageCaption(obfMenu, {
          parse_mode: 'Markdown',
          ...obfKeyboard
        });
        break;

      case 'owner_menu':
        if (userId.toString() !== global.DEVELOPER_ID) {
          await ctx.answerCbQuery('❌ Hanya owner yang dapat mengakses menu ini!');
          return;
        }
        
        const ownerMenu = `
╭─❒ 「 Owner Menu 」 
├ /addprem <user_id> <hari> - Tambah premium user
├ /delprem <user_id> - Hapus premium user
├ /listprem - List user premium
├ /addbl <user_id> - Tambah user ke blacklist
├ /delbl <user_id> - Hapus user dari blacklist
├ /listbl - List user blacklist
├ /listgrup - List grup aktif
├ /bc <pesan> - Broadcast ke semua user
╰❒ /menu - Kembali ke menu utama`;

        const ownerKeyboard = Markup.inlineKeyboard([
          [Markup.button.callback('Kembali', 'main_menu')],
          [Markup.button.callback('Jasher Menu', 'jasher_menu')],
          [Markup.button.callback('Obf Menu', 'obf_menu')]
        ]);

        await ctx.editMessageCaption(ownerMenu, {
          parse_mode: 'Markdown',
          ...ownerKeyboard
        });
        break;

      case 'main_menu':
        const mainMenu = `
╭─❒ 「 User Info 」 
├ Creator : ${global.DEVELOPER_USERNAME}
├ Name : @${username}
├ Profile : @${ctx.from.first_name}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreator ? 'True' : 'False'}
Silahkan pilih button dibawah ini!`;

        const mainKeyboard = Markup.inlineKeyboard([
          [Markup.button.callback('Jasher Menu', 'jasher_menu')],
          [Markup.button.callback('Obf Menu', 'obf_menu')],
          [Markup.button.callback('Owner', 'owner_menu')]
        ]);

        await ctx.editMessageCaption(mainMenu, {
          parse_mode: 'Markdown',
          ...mainKeyboard
        });
        break;

      default:
        await ctx.answerCbQuery('❌ Command tidak dikenali!');
    }
    
    await ctx.answerCbQuery();
  });

  // Handler ketika bot ditambahkan ke grup
  bot.on('message', async (ctx) => {
    if (ctx.message.new_chat_members) {
      for (const member of ctx.message.new_chat_members) {
        if (member.is_bot && member.username === ctx.botInfo.username) {
          // Bot ditambahkan ke grup
          const groupId = ctx.chat.id;
          const groupName = ctx.chat.title;
          
          addGroup(groupId, groupName);
          ctx.reply('✅ Terima kasih telah menambahkan saya ke grup ini!\n\nGunakan /menu untuk melihat fitur yang tersedia.');
        }
      }
    }
    
    // Cek jika bot dikick dari grup
    if (ctx.message.left_chat_member) {
      if (ctx.message.left_chat_member.username === ctx.botInfo.username) {
        // Bot dikick dari grup
        const groupId = ctx.chat.id;
        removeGroup(groupId);
      }
    }
  });

  // Handler untuk pesan baru
  bot.on('text', async (ctx) => {
    const userId = ctx.from.id;
    addUser(userId);
    
    // Jika di grup, tambahkan grup ke database
    if (ctx.chat.type !== 'private') {
      const groupId = ctx.chat.id;
      const groupName = ctx.chat.title;
      addGroup(groupId, groupName);
    }
  });
}

module.exports = {
  setupHandlers
};