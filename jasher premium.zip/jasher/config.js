global.BOT_TOKEN = process.env.BOT_TOKEN || '8404410811:AAEZIftEDvh7qfQ-zRxfCLbLuwMK3d9Vzc0';
global.OWNER_ID = process.env.OWNER_ID || '8373026763';

module.exports = {
    BOT_TOKEN: global.BOT_TOKEN,
    OWNER_ID: global.OWNER_ID,
    CREDITS: {
        ADD_GROUP_REWARD: 10,
        SHARE_COST: 2
    }
};