const { User, Group } = require('../lib/database');

async function handleCallbackQuery(ctx) {
  const data = ctx.update.callback_query.data;
  const userId = ctx.from.id;
  
  try {
    switch (data) {
      case 'jasher_menu':
        await showJasherMenu(ctx);
        break;
        
      case 'owner_menu':
        await showOwnerMenu(ctx);
        break;
        
      case 'add_group':
        await ctx.answerCbQuery('Tambahkan bot ke group Anda, lalu kirim /start di group tersebut.');
        break;
        
      case 'back_to_main':
        await showMainMenu(ctx);
        break;
        
      default:
        await ctx.answerCbQuery('Menu tidak dikenali.');
    }
  } catch (error) {
    console.error('Error handling callback query:', error);
    await ctx.answerCbQuery('Terjadi kesalahan.');
  }
}

async function showMainMenu(ctx) {
  const { formatUserInfo } = require('./utils');
  const message = formatUserInfo(ctx, {});
  
  const buttons = [
    [{ text: 'Jasher Menu', callback_data: 'jasher_menu' }],
    [{ text: 'Owner Menu', callback_data: 'owner_menu' }],
    [{ text: 'AddGroup', callback_data: 'add_group' }],
    [{ text: 'Owner', url: 't.me/your_username' }]
  ];
  
  await ctx.editMessageText(message, {
    reply_markup: {
      inline_keyboard: buttons
    },
    parse_mode: 'HTML'
  });
}

async function showJasherMenu(ctx) {
  const user = await User.findOne({ userId: ctx.from.id });
  const credit = user ? user.credit : 0;
  const isPremium = user ? user.isPremium : false;
  
  const message = `🤖 *Jasher Menu*

💳 Kredit: ${credit}
⭐ Status: ${isPremium ? 'Premium' : 'Regular'}

Pilih opsi di bawah ini:`;
  
  const buttons = [
    [{ text: 'Share (2 kredit)', callback_data: 'share_info' }],
    [{ text: 'Share VIP', callback_data: 'share_vip_info' }],
    [{ text: 'Cek Kredit', callback_data: 'credit_info' }],
    [{ text: 'Kembali', callback_data: 'back_to_main' }]
  ];
  
  await ctx.editMessageText(message, {
    reply_markup: {
      inline_keyboard: buttons
    },
    parse_mode: 'Markdown'
  });
}

async function showOwnerMenu(ctx) {
  // Check if user is owner
  if (ctx.from.id.toString() !== process.env.OWNER_ID) {
    await ctx.answerCbQuery('Anda tidak memiliki akses ke menu ini.');
    return;
  }
  
  const message = `🛠 *Owner Menu*

Fitur khusus untuk owner bot.`;
  
  const buttons = [
    [{ text: 'Add Premium', callback_data: 'add_premium_info' }],
    [{ text: 'Remove Premium', callback_data: 'remove_premium_info' }],
    [{ text: 'List Premium', callback_data: 'list_premium_info' }],
    [{ text: 'Broadcast', callback_data: 'broadcast_info' }],
    [{ text: 'Kembali', callback_data: 'back_to_main' }]
  ];
  
  await ctx.editMessageText(message, {
    reply_markup: {
      inline_keyboard: buttons
    },
    parse_mode: 'Markdown'
  });
}

async function handleNewChatMembers(ctx) {
  try {
    // Check if the new member is the bot itself
    const newMembers = ctx.update.message.new_chat_members;
    const botId = ctx.botInfo.id;
    
    for (const member of newMembers) {
      if (member.id === botId) {
        // Bot was added to a group
        const groupId = ctx.chat.id.toString();
        const groupTitle = ctx.chat.title;
        const groupUsername = ctx.chat.username || '';
        
        // Save group to database
        let group = await Group.findOne({ groupId });
        if (!group) {
          group = new Group({
            groupId,
            title: groupTitle,
            username: groupUsername,
            addedBy: ctx.from.id
          });
          await group.save();
        }
        
        // Add credit to user who added the bot
        const user = await User.findOne({ userId: ctx.from.id });
        if (user) {
          user.credit += 10;
          // Add group to user's joined groups if not already added
          if (!user.joinedGroups.includes(groupId)) {
            user.joinedGroups.push(groupId);
          }
          await user.save();
        }
        
        await ctx.reply(`Terima kasih telah menambahkan saya ke group ini!`);
        break;
      }
    }
  } catch (error) {
    console.error('Error handling new chat members:', error);
  }
}

async function handleLeftChatMember(ctx) {
  try {
    const leftMember = ctx.update.message.left_chat_member;
    const botId = ctx.botInfo.id;
    
    if (leftMember.id === botId) {
      // Bot was removed from a group
      const groupId = ctx.chat.id.toString();
      
      // Remove group from database
      await Group.deleteOne({ groupId });
      
      // Remove group from all users' joinedGroups
      await User.updateMany(
        { joinedGroups: groupId },
        { $pull: { joinedGroups: groupId } }
      );
    }
  } catch (error) {
    console.error('Error handling left chat member:', error);
  }
}

module.exports = {
  handleCallbackQuery,
  handleNewChatMembers,
  handleLeftChatMember
};