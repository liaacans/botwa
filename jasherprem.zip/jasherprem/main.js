const { Telegraf, session } = require('telegraf');
const { connectDB } = require('./lib/database');
const { BOT_TOKEN } = require('./config');
const commandHandlers = require('./src/commands');
const { handleCallbackQuery } = require('./src/handlers');

// Connect to database
connectDB();

// Initialize bot
const bot = new Telegraf(BOT_TOKEN);

// Session middleware (optional)
bot.use(session());

// Command handlers
bot.command('start', commandHandlers.handleStart);
bot.command('help', commandHandlers.handleHelp);
bot.command('credit', commandHandlers.handleCredit);
bot.command('share', commandHandlers.handleShare);
bot.command('addprem', commandHandlers.handleAddPrem);
bot.command('delprem', commandHandlers.handleDelPrem);
bot.command('listprem', commandHandlers.handleListPrem);
bot.command('broadcast', commandHandlers.handleBroadcast);

// Callback query handler
bot.on('callback_query', handleCallbackQuery);

// Error handling
bot.catch((err, ctx) => {
    console.error(`Error for ${ctx.updateType}:`, err);
    ctx.reply('❌ Terjadi kesalahan dalam bot!');
});

// Start bot
bot.launch().then(() => {
    console.log('Bot Jasher started successfully!');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));