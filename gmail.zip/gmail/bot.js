const { Telegraf } = require('telegraf');
const imap = require('imap-simple');
const simpleParser = require('mailparser').simpleParser;
const nodemailer = require('nodemailer');
const { simple } = require('imap-simple');

// Konfigurasi
const BOT_TOKEN = '7569137877:AAHnvva5p9SFclkDpDio8QcJsSfbzlrK6IY'; // Ganti dengan token bot Anda
const ALLOWED_GROUP_ID = '-1002793801544'; // Grup yang diizinkan
const IMAP_CONFIG = {
  imap: {
    user: 'nokosmerah@buatkamu.web.id',
    password: 'Grki6Vv1gdlA',
    host: 'newpinwheel.indowebsite.net',
    port: 993,
    tls: true,
    tlsOptions: { rejectUnauthorized: false },
    authTimeout: 10000
  }
};
const SMTP_CONFIG = {
  host: 'newpinwheel.indowebsite.net',
  port: 587,
  secure: false,
  auth: {
    user: 'nokosmerah@buatkamu.web.id',
    pass: 'Grki6Vv1gdlA'
  }
};

// Inisialisasi bot
const bot = new Telegraf(BOT_TOKEN);

// Inisialisasi transporter SMTP
const transporter = nodemailer.createTransporter(SMTP_CONFIG);

// Variabel untuk melacak email yang sudah diproses
let processedEmails = new Set();

// Fungsi untuk memeriksa dan memproses email baru
async function checkNewEmails() {
  console.log('Memeriksa email baru...');
  
  try {
    const connection = await imap.connect(IMAP_CONFIG);
    console.log('Terhubung ke server IMAP');

    await connection.openBox('INBOX');
    console.log('Kotak masuk terbuka');

    // Cari email yang belum dibaca
    const searchCriteria = ['UNSEEN'];
    const fetchOptions = {
      bodies: [''],
      markSeen: true, // Tandai sebagai dibaca
      struct: true
    };

    const messages = await connection.search(searchCriteria, fetchOptions);
    console.log(`Ditemukan ${messages.length} email baru`);

    for (const message of messages) {
      const all = message.parts.find(part => part.which === '');
      const id = message.attributes.uid;
      const idHeader = "Message-ID: " + (message.attributes['x-gm-msgid'] || id);

      if (processedEmails.has(idHeader)) {
        console.log(`Email ${idHeader} sudah diproses, dilewati`);
        continue;
      }

      const parsedEmail = await simpleParser(all.body);
      console.log('Memproses email dari:', parsedEmail.from.text);

      // Kirim notifikasi ke grup Telegram
      const emailText = `📧 Email Baru\n\nDari: ${parsedEmail.from.text}\nKepada: ${parsedEmail.to.text}\nSubjek: ${parsedEmail.subject}\n\n${parsedEmail.text || 'Tidak ada konten teks'}`;
      
      // Potong teks jika terlalu panjang untuk Telegram
      const truncatedText = emailText.length > 4096 ? emailText.substring(0, 4093) + '...' : emailText;
      
      await bot.telegram.sendMessage(ALLOWED_GROUP_ID, truncatedText);
      console.log('Notifikasi email terkirim ke grup Telegram');

      // Tandai email sebagai diproses
      processedEmails.add(idHeader);
      console.log(`Email ${idHeader} ditandai sebagai diproses`);
    }

    connection.end();
  } catch (error) {
    console.error('Error memeriksa email:', error);
  }
}

// Command /sendmail untuk mengirim email
bot.command('sendmail', async (ctx) => {
  // Periksa apakah perintah berasal dari grup yang diizinkan
  if (ctx.chat.id.toString() !== ALLOWED_GROUP_ID) {
    console.log(`Perintah dari grup tidak diizinkan: ${ctx.chat.id}`);
    return ctx.reply('Bot hanya dapat digunakan di grup yang ditentukan.');
  }

  try {
    const args = ctx.message.text.split(' ').slice(1);
    if (args.length < 3) {
      return ctx.reply('Format: /sendmail <email_tujuan> <subjek> <pesan>');
    }

    const toEmail = args[0];
    const subject = args.slice(1, -1).join(' ');
    const message = args[args.length - 1];

    const mailOptions = {
      from: 'nokosmerah@buatkamu.web.id',
      to: toEmail,
      subject: subject,
      text: message
    };

    await transporter.sendMail(mailOptions);
    console.log(`Email terkirim ke: ${toEmail}, subjek: ${subject}`);
    ctx.reply(`Email berhasil dikirim ke ${toEmail}`);
  } catch (error) {
    console.error('Error mengirim email:', error);
    ctx.reply('Gagal mengirim email. Silakan coba lagi.');
  }
});

// Middleware untuk memeriksa grup
bot.use((ctx, next) => {
  // Izinkan pesan dari grup yang diizinkan dan percakapan pribadi dengan bot
  if (ctx.chat && (ctx.chat.id.toString() === ALLOWED_GROUP_ID || ctx.chat.type === 'private')) {
    return next();
  }
  
  // Jika bot ditambahkan ke grup lain, keluar
  if (ctx.chat && ctx.chat.type !== 'private' && ctx.chat.id.toString() !== ALLOWED_GROUP_ID) {
    console.log(`Bot ditambahkan ke grup tidak diizinkan: ${ctx.chat.id}, meninggalkan grup`);
    ctx.leaveChat();
  }
  
  return Promise.resolve();
});

// Event ketika bot ditambahkan ke grup
bot.on('new_chat_members', (ctx) => {
  if (ctx.message.new_chat_member.id === ctx.botInfo.id) {
    if (ctx.chat.id.toString() !== ALLOWED_GROUP_ID) {
      console.log(`Bot ditambahkan ke grup tidak diizinkan: ${ctx.chat.id}, meninggalkan grup`);
      ctx.leaveChat();
    } else {
      console.log(`Bot ditambahkan ke grup yang diizinkan: ${ctx.chat.id}`);
      ctx.reply('Halo! Saya siap membantu mengelola email.');
    }
  }
});

// Start command
bot.command('start', (ctx) => {
  console.log(`Bot dimulai oleh: ${ctx.from.id}`);
  ctx.reply('Halo! Saya adalah bot pengelola email. Gunakan /sendmail untuk mengirim email.');
});

// Jalankan bot
bot.launch().then(() => {
  console.log('Bot Telegram berjalan');
});

// Jadwalkan pengecekan email setiap 1 menit
setInterval(checkNewEmails, 60000);

// Jalankan pengecekan email sekali saat mulai
checkNewEmails();

// Enable graceful stop
process.once('SIGINT', () => {
  bot.stop('SIGINT');
  console.log('Bot dihentikan');
});
process.once('SIGTERM', () => {
  bot.stop('SIGTERM');
  console.log('Bot dihentikan');
});