global.BOT_TOKEN = process.env.BOT_TOKEN || 'YOUR_BOT_TOKEN_HERE';
global.PREFIX = '/';
global.ADMINS = [123456789]; // Ganti dengan ID admin Anda
global.CREATOR_ID = 123456789; // Ganti dengan ID creator Anda

// Ekspor konfigurasi lainnya
module.exports = {
    CREDITS: {
        ADD_GROUP_REWARD: 10,
        SHARE_COST: 2,
        MIN_GROUPS_FOR_SHARE: 3
    }
};