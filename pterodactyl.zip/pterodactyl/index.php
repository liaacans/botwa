<?php
include 'includes/config.php';
include 'includes/functions.php';

// Cek jika user sudah login
if (isset($_SESSION['user_id'])) {
    redirect('panel.php');
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Pterodactyl - Hosting Terbaik</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">Panel Pterodactyl</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#features">Fitur</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#pricing">Harga</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#about">Tentang</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="auth/login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-primary text-white" href="auth/register.php">Daftar</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero bg-primary text-white py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h1 class="display-4 fw-bold">Mengapa Memilih Panel Pterodactyl Kami?</h1>
                    <p class="lead">Kami menyediakan layanan hosting terbaik dengan panel Pterodactyl yang mudah digunakan, aman, dan andal.</p>
                    <ul class="list-unstyled">
                        <li class="mb-2"><i class="bi bi-check-circle-fill"></i> Performa tinggi dengan SSD NVMe</li>
                        <li class="mb-2"><i class="bi bi-check-circle-fill"></i> Dukungan 24/7 dari tim profesional</li>
                        <li class="mb-2"><i class="bi bi-check-circle-fill"></i> Skalabilitas mudah sesuai kebutuhan</li>
                        <li class="mb-2"><i class="bi bi-check-circle-fill"></i> Keamanan tingkat enterprise</li>
                    </ul>
                    <a href="#pricing" class="btn btn-light btn-lg mt-3">Pilih Paket</a>
                </div>
                <div class="col-lg-6">
                    <img src="https://via.placeholder.com/600x400" alt="Server Illustration" class="img-fluid rounded">
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section id="features" class="py-5">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold">Fitur Unggulan</h2>
                <p class="text-muted">Nikmati berbagai fitur terbaik untuk kebutuhan hosting Anda</p>
            </div>
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center">
                            <i class="bi bi-speedometer2 display-4 text-primary mb-3"></i>
                            <h5 class="card-title">Performa Tinggi</h5>
                            <p class="card-text">Server kami didukung oleh hardware terbaru untuk memastikan performa optimal.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center">
                            <i class="bi bi-shield-check display-4 text-primary mb-3"></i>
                            <h5 class="card-title">Keamanan Terjamin</h5>
                            <p class="card-text">Sistem keamanan multi-layer melindungi data dan aplikasi Anda dari ancaman.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center">
                            <i class="bi bi-arrows-fullscreen display-4 text-primary mb-3"></i>
                            <h5 class="card-title">Skalabilitas Mudah</h5>
                            <p class="card-text">Tingkatkan kapasitas server kapan saja sesuai dengan kebutuhan bisnis Anda.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Pricing Section -->
    <section id="pricing" class="py-5 bg-light">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold">Pilihan Paket</h2>
                <p class="text-muted">Pilih paket yang sesuai dengan kebutuhan Anda</p>
            </div>
            <div class="row">
                <!-- Paket 1GB (Gratis) -->
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-header text-center bg-success text-white py-3">
                            <h5 class="card-title mb-0">Paket Gratis</h5>
                        </div>
                        <div class="card-body text-center">
                            <h3 class="card-title pricing-card-title">1GB RAM</h3>
                            <p class="text-muted">Coba layanan kami secara gratis</p>
                            <ul class="list-unstyled mt-3 mb-4">
                                <li>1GB RAM</li>
                                <li>10GB SSD Storage</li>
                                <li>1 Core CPU</li>
                                <li>Unlimited Bandwidth</li>
                                <li>Support 24/7</li>
                            </ul>
                        </div>
                        <div class="card-footer bg-transparent text-center">
                            <a href="auth/register.php?package=free" class="btn btn-outline-success w-100">Daftar Gratis</a>
                        </div>
                    </div>
                </div>

                <!-- Paket 2GB -->
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-header text-center bg-primary text-white py-3">
                            <h5 class="card-title mb-0">Paket Standard</h5>
                        </div>
                        <div class="card-body text-center">
                            <h3 class="card-title pricing-card-title">2GB RAM</h3>
                            <p class="text-muted">Rp 25.000/bulan</p>
                            <ul class="list-unstyled mt-3 mb-4">
                                <li>2GB RAM</li>
                                <li>20GB SSD Storage</li>
                                <li>1 Core CPU</li>
                                <li>Unlimited Bandwidth</li>
                                <li>Support 24/7</li>
                            </ul>
                        </div>
                        <div class="card-footer bg-transparent text-center">
                            <a href="order.php?package=2gb" class="btn btn-primary w-100">Pilih Paket</a>
                        </div>
                    </div>
                </div>

                <!-- Paket 4GB -->
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-header text-center bg-warning text-dark py-3">
                            <h5 class="card-title mb-0">Paket Professional</h5>
                        </div>
                        <div class="card-body text-center">
                            <h3 class="card-title pricing-card-title">4GB RAM</h3>
                            <p class="text-muted">Rp 50.000/bulan</p>
                            <ul class="list-unstyled mt-3 mb-4">
                                <li>4GB RAM</li>
                                <li>40GB SSD Storage</li>
                                <li>2 Core CPU</li>
                                <li>Unlimited Bandwidth</li>
                                <li>Support 24/7</li>
                            </ul>
                        </div>
                        <div class="card-footer bg-transparent text-center">
                            <a href="order.php?package=4gb" class="btn btn-warning w-100">Pilih Paket</a>
                        </div>
                    </div>
                </div>

                <!-- Paket lainnya bisa ditambahkan di sini -->
            </div>

            <div class="row mt-4">
                <!-- Paket 8GB -->
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-header text-center bg-info text-white py-3">
                            <h5 class="card-title mb-0">Paket Business</h5>
                        </div>
                        <div class="card-body text-center">
                            <h3 class="card-title pricing-card-title">8GB RAM</h3>
                            <p class="text-muted">Rp 100.000/bulan</p>
                            <ul class="list-unstyled mt-3 mb-4">
                                <li>8GB RAM</li>
                                <li>80GB SSD Storage</li>
                                <li>4 Core CPU</li>
                                <li>Unlimited Bandwidth</li>
                                <li>Support 24/7</li>
                            </ul>
                        </div>
                        <div class="card-footer bg-transparent text-center">
                            <a href="order.php?package=8gb" class="btn btn-info w-100">Pilih Paket</a>
                        </div>
                    </div>
                </div>

                <!-- Paket 10GB -->
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-header text-center bg-danger text-white py-3">
                            <h5 class="card-title mb-0">Paket Enterprise</h5>
                        </div>
                        <div class="card-body text-center">
                            <h3 class="card-title pricing-card-title">10GB RAM</h3>
                            <p class="text-muted">Rp 125.000/bulan</p>
                            <ul class="list-unstyled mt-3 mb-4">
                                <li>10GB RAM</li>
                                <li>100GB SSD Storage</li>
                                <li>6 Core CPU</li>
                                <li>Unlimited Bandwidth</li>
                                <li>Support 24/7</li>
                            </ul>
                        </div>
                        <div class="card-footer bg-transparent text-center">
                            <a href="order.php?package=10gb" class="btn btn-danger w-100">Pilih Paket</a>
                        </div>
                    </div>
                </div>

                <!-- Paket Unlimited -->
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-header text-center bg-dark text-white py-3">
                            <h5 class="card-title mb-0">Paket Unlimited</h5>
                        </div>
                        <div class="card-body text-center">
                            <h3 class="card-title pricing-card-title">Unlimited</h3>
                            <p class="text-muted">Custom Price</p>
                            <ul class="list-unstyled mt-3 mb-4">
                                <li>Unlimited RAM</li>
                                <li>Unlimited Storage</li>
                                <li>Unlimited CPU</li>
                                <li>Unlimited Bandwidth</li>
                                <li>Dedicated Support</li>
                            </ul>
                        </div>
                        <div class="card-footer bg-transparent text-center">
                            <a href="order.php?package=unlimited" class="btn btn-dark w-100">Hubungi Kami</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <h2 class="fw-bold">Tentang Kami</h2>
                    <p>Kami adalah penyedia layanan hosting terpercaya dengan pengalaman lebih dari 5 tahun. Dengan dukungan teknologi terkini dan tim profesional, kami siap membantu kesuksesan online Anda.</p>
                    <p>Panel Pterodactyl kami memberikan pengalaman terbaik dalam mengelola server dengan antarmuka yang intuitif dan fitur lengkap.</p>
                </div>
                <div class="col-lg-6">
                    <img src="https://via.placeholder.com/600x400" alt="About Us" class="img-fluid rounded">
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5>Panel Pterodactyl</h5>
                    <p>Layanan hosting terbaik dengan panel Pterodactyl.</p>
                </div>
                <div class="col-md-3">
                    <h5>Link Cepat</h5>
                    <ul class="list-unstyled">
                        <li><a href="#features" class="text-white">Fitur</a></li>
                        <li><a href="#pricing" class="text-white">Harga</a></li>
                        <li><a href="#about" class="text-white">Tentang</a></li>
                    </ul>
                </div>
                <div class="col-md-3">
                    <h5>Kontak</h5>
                    <ul class="list-unstyled">
                        <li>Email: support@y2beta.web.id</li>
                        <li>Telegram: @y2beta</li>
                    </ul>
                </div>
            </div>
            <hr>
            <div class="text-center">
                <p class="mb-0">&copy; 2023 Panel Pterodactyl. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/script.js"></script>
</body>
</html>