const { Telegraf, Markup } = require('telegraf');
const moment = require('moment-timezone');
const { isPremium, isOwner, runtime, log } = require('../../lib/functions');
const db = require('../../lib/database');

module.exports = (bot, users, groups, premium, blacklist) => {
    
    // Start command dengan menu utama
    bot.command('start', async (ctx) => {
        const userId = ctx.from.id.toString(); // Convert to string untuk Set
        users.add(userId); // Sekarang users adalah Set, jadi add() valid
        await db.saveUsers(users);
        
        const isCreator = isOwner(ctx.from.id);
        const sender = ctx.from.username || ctx.from.first_name;
        
        const menuText = `
╭─❒ 「 User Info 」 
├ Owner : ${isCreator ? 'True' : 'False'}
├ Name : ${ctx.from.first_name}()
├ Profile : @${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`;

        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('🎯 Jasher Menu', 'jasher_menu')],
            [Markup.button.callback('👑 Owner Menu', 'owner_menu')],
            [Markup.button.callback('🔒 Obf Menu', 'obf_menu')],
            [Markup.button.callback('🔄 Kembali', 'main_menu')]
        ]);

        try {
            await ctx.replyWithPhoto(
                'https://f.top4top.io/p_3530xky9e4.jpg',
                {
                    caption: menuText,
                    parse_mode: 'Markdown',
                    ...keyboard
                }
            );
        } catch (error) {
            await ctx.reply(menuText, keyboard);
        }
    });

    // Menu callback handlers
    bot.action('main_menu', async (ctx) => {
        const userId = ctx.from.id.toString();
        const isCreator = isOwner(userId);
        const sender = ctx.from.username || ctx.from.first_name;
        
        const menuText = `
╭─❒ 「 User Info 」 
├ Owner : ${isCreator ? 'True' : 'False'}
├ Name : ${ctx.from.first_name}()
├ Profile : @${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`;

        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('🎯 Jasher Menu', 'jasher_menu')],
            [Markup.button.callback('👑 Owner Menu', 'owner_menu')],
            [Markup.button.callback('🔒 Obf Menu', 'obf_menu')],
            [Markup.button.callback('🔄 Kembali', 'main_menu')]
        ]);

        try {
            await ctx.editMessageCaption(menuText, {
                parse_mode: 'Markdown',
                ...keyboard
            });
        } catch (error) {
            await ctx.reply(menuText, keyboard);
        }
    });

    // Jasher Menu
    bot.action('jasher_menu', async (ctx) => {
        const isPrem = isPremium(ctx.from.id, premium);
        
        const jasherText = `
╭─❒ 「 Jasher Menu 」 
├ Status : ${isPrem ? '✅ Premium' : '❌ Free'}
├ Fitur Free : Share Free
├ Fitur Premium : Share VIP
├ Upgrade Premium : /buypremium
╰❒
Pilih fitur yang ingin digunakan:`;

        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('📤 Share Free', 'share_free')],
            [Markup.button.callback('🚀 Share VIP', 'share_vip')],
            [Markup.button.callback('💳 Upgrade Premium', 'buy_premium')],
            [Markup.button.callback('📋 List Premium', 'list_premium')],
            [Markup.button.callback('🔙 Kembali', 'main_menu')]
        ]);

        await ctx.editMessageCaption(jasherText, {
            parse_mode: 'Markdown',
            ...keyboard
        });
    });

    // Share Free
    bot.action('share_free', async (ctx) => {
        const userGroups = Array.from(groups.values()).filter(g => g.members && g.members.includes(ctx.from.id.toString()));
        
        if (userGroups.length < 3) {
            return ctx.replyWithMarkdown(`
╭━━━「 ❌ ERROR 」━━━⬣
│ Anda harus menambahkan bot ke 3 group
│ terlebih dahulu untuk menggunakan Share Free!
│ 
│ Group saat ini: ${userGroups.length}/3
╰━━━━━━━━━━━━━━━━⬣

Gunakan perintah /addgroup untuk menambahkan bot ke group.`);
        }

        await ctx.replyWithMarkdown(`
╭━━━「 📤 SHARE FREE 」━━━⬣
│ Silahkan kirim pesan yang ingin di-share
│ atau reply pesan yang ingin di-share!
│ 
│ Fitur: Broadcast ke semua group
│ Kecepatan: Normal
╰━━━━━━━━━━━━━━━━⬣`);
    });

    // Share VIP
    bot.action('share_vip', async (ctx) => {
        if (!isPremium(ctx.from.id, premium)) {
            return ctx.replyWithMarkdown(`
╭━━━「 ❌ ERROR 」━━━⬣
│ Fitur Share VIP hanya untuk user premium!
│ 
│ Upgrade premium dengan /buypremium
╰━━━━━━━━━━━━━━━━⬣`);
        }

        await ctx.replyWithMarkdown(`
╭━━━「 🚀 SHARE VIP 」━━━⬣
│ Silahkan kirim pesan yang ingin di-share
│ atau reply pesan yang ingin di-share!
│ 
│ Fitur: Broadcast ke semua user private
│ Kecepatan: High Speed
╰━━━━━━━━━━━━━━━━⬣`);
    });

    // Buy Premium
    bot.action('buy_premium', async (ctx) => {
        const premiumText = `
╭─❒ 「 💳 UPGRADE PREMIUM 」 
├ 1 Hari : Rp 5.000
├ 7 Hari : Rp 25.000
├ 30 Hari : Rp 80.000
├ Permanent : Rp 300.000
╰❒
Cara Pembayaran:
1. Transfer ke rekening BCA 1234567890
2. Kirim bukti transfer ke @owner
3. Premium akan diaktifkan dalam 1x24 jam

Atau gunakan /buypremium untuk info lebih lanjut.`;

        await ctx.editMessageCaption(premiumText, {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
                [Markup.button.callback('💳 Bayar Sekarang', 'pay_now')],
                [Markup.button.callback('🔙 Kembali', 'jasher_menu')]
            ])
        });
    });

    // List Premium
    bot.action('list_premium', async (ctx) => {
        const userPremium = premium.get(ctx.from.id.toString());
        
        if (!userPremium) {
            return ctx.replyWithMarkdown(`
╭━━━「 📋 LIST PREMIUM 」━━━⬣
│ Anda belum memiliki premium!
│ 
│ Gunakan /buypremium untuk upgrade
╰━━━━━━━━━━━━━━━━⬣`);
        }

        const expiryDate = moment(userPremium.expiry).tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss');
        const remaining = moment.duration(userPremium.expiry - Date.now()).humanize();
        
        await ctx.replyWithMarkdown(`
╭━━━「 📋 LIST PREMIUM 」━━━⬣
│ Status : ✅ Aktif
│ Expiry : ${expiryDate}
│ Sisa : ${remaining}
│ Durasi : ${userPremium.days} hari
╰━━━━━━━━━━━━━━━━⬣`);
    });

    // Command untuk share free
    bot.command('sharefree', async (ctx) => {
        if (ctx.chat.type !== 'private') {
            return ctx.replyWithMarkdown('❌ *Error:* Command ini hanya bisa digunakan di private chat!');
        }

        const userGroups = Array.from(groups.values()).filter(g => g.members && g.members.includes(ctx.from.id.toString()));
        
        if (userGroups.length < 3) {
            return ctx.replyWithMarkdown(`
╭━━━「 ❌ ERROR 」━━━⬣
│ Anda harus menambahkan bot ke 3 group
│ terlebih dahulu untuk menggunakan Share Free!
│ 
│ Group saat ini: ${userGroups.length}/3
╰━━━━━━━━━━━━━━━━⬣`);
        }

        if (!ctx.message.reply_to_message) {
            return ctx.replyWithMarkdown(`
╭━━━「 📤 SHARE FREE 」━━━⬣
│ Silahkan reply pesan yang ingin di-share!
│ 
│ Contoh: reply pesan ini dengan /sharefree
╰━━━━━━━━━━━━━━━━⬣`);
        }

        // Broadcast ke semua group user
        let success = 0;
        let failed = 0;
        
        for (const group of userGroups) {
            try {
                await ctx.telegram.copyMessage(group.id, ctx.chat.id, ctx.message.reply_to_message.message_id);
                success++;
            } catch (error) {
                failed++;
                log(`Error broadcasting to group ${group.id}`, error);
            }
        }

        await ctx.replyWithMarkdown(`
╭━━━「 ✅ BROADCAST SELESAI 」━━━⬣
│ Berhasil : ${success} group
│ Gagal : ${failed} group
│ Total : ${userGroups.length} group
╰━━━━━━━━━━━━━━━━⬣`);
    });

    // Command untuk share VIP
    bot.command('sharevip', async (ctx) => {
        if (ctx.chat.type !== 'private') {
            return ctx.replyWithMarkdown('❌ *Error:* Command ini hanya bisa digunakan di private chat!');
        }

        if (!isPremium(ctx.from.id, premium)) {
            return ctx.replyWithMarkdown(`
╭━━━「 ❌ ERROR 」━━━⬣
│ Fitur Share VIP hanya untuk user premium!
│ 
│ Upgrade premium dengan /buypremium
╰━━━━━━━━━━━━━━━━⬣`);
        }

        if (!ctx.message.reply_to_message) {
            return ctx.replyWithMarkdown(`
╭━━━「 🚀 SHARE VIP 」━━━⬣
│ Silahkan reply pesan yang ingin di-share!
│ 
│ Contoh: reply pesan ini dengan /sharevip
╰━━━━━━━━━━━━━━━━⬣`);
        }

        // Broadcast ke semua user
        const allUsers = Array.from(users);
        let success = 0;
        let failed = 0;
        
        for (const userId of allUsers) {
            try {
                await ctx.telegram.copyMessage(userId, ctx.chat.id, ctx.message.reply_to_message.message_id);
                success++;
            } catch (error) {
                failed++;
                users.delete(userId); // Remove invalid users
            }
        }

        await db.saveUsers(users);
        
        await ctx.replyWithMarkdown(`
╭━━━「 ✅ BROADCAST VIP SELESAI 」━━━⬣
│ Berhasil : ${success} user
│ Gagal : ${failed} user
│ Total : ${allUsers.length} user
│ Kecepatan : High Speed
╰━━━━━━━━━━━━━━━━⬣`);
    });

    // Command untuk mengecek premium
    bot.command('premium', async (ctx) => {
        const userPremium = premium.get(ctx.from.id.toString());
        
        if (!userPremium) {
            return ctx.replyWithMarkdown(`
╭━━━「 📋 STATUS PREMIUM 」━━━⬣
│ Status : ❌ Free User
│ 
│ Upgrade dengan /buypremium
╰━━━━━━━━━━━━━━━━⬣`);
        }

        const expiryDate = moment(userPremium.expiry).tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss');
        const remaining = moment.duration(userPremium.expiry - Date.now()).humanize();
        
        await ctx.replyWithMarkdown(`
╭━━━「 📋 STATUS PREMIUM 」━━━⬣
│ Status : ✅ Premium User
│ Expiry : ${expiryDate}
│ Sisa : ${remaining}
│ Durasi : ${userPremium.days} hari
╰━━━━━━━━━━━━━━━━⬣`);
    });

    // Command untuk membeli premium
    bot.command('buypremium', async (ctx) => {
        const premiumText = `
╭─❒ 「 💳 BELI PREMIUM 」 
├ 1 Hari : Rp 5.000
├ 7 Hari : Rp 25.000
├ 30 Hari : Rp 80.000
├ Permanent : Rp 300.000
╰❒
Cara Pembayaran:
1. Transfer ke rekening BCA 1234567890
2. Kirim bukti transfer ke @owner
3. Premium akan diaktifkan dalam 1x24 jam

Setelah transfer, kirim bukti dengan command:
/bukti [jumlah_hari] [nama_bank]

Contoh: /bukti 30 BCA`;

        await ctx.replyWithMarkdown(premiumText);
    });

    // Command untuk mengirim bukti pembayaran
    bot.command('bukti', async (ctx) => {
        const args = ctx.message.text.split(' ');
        if (args.length < 3) {
            return ctx.replyWithMarkdown('❌ *Format:* /bukti [jumlah_hari] [nama_bank]\nContoh: /bukti 30 BCA');
        }

        const days = parseInt(args[1]);
        const bank = args[2];

        if (isNaN(days) || days < 1) {
            return ctx.replyWithMarkdown('❌ *Error:* Jumlah hari harus angka positif!');
        }

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.photo) {
            return ctx.replyWithMarkdown('❌ *Error:* Reply foto bukti transfer dengan command ini!');
        }

        // Kirim bukti ke owner
        const photo = ctx.message.reply_to_message.photo[0];
        const caption = `📋 BUKTI PEMBAYARAN PREMIUM
👤 User: ${ctx.from.first_name} (@${ctx.from.username || 'N/A'})
🆔 ID: ${ctx.from.id}
💰 Hari: ${days} hari
🏦 Bank: ${bank}
⏰ Waktu: ${moment().tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss')}`;

        try {
            await ctx.telegram.sendPhoto(global.OWNER_ID, photo.file_id, {
                caption: caption,
                parse_mode: 'Markdown'
            });

            await ctx.replyWithMarkdown(`
╭━━━「 ✅ BUKTI TERKIRIM 」━━━⬣
│ Bukti pembayaran telah dikirim ke owner!
│ 
│ Premium akan diaktifkan dalam 1x24 jam
│ setelah konfirmasi pembayaran.
╰━━━━━━━━━━━━━━━━⬣`);
        } catch (error) {
            await ctx.replyWithMarkdown('❌ *Error:* Gagal mengirim bukti ke owner!');
        }
    });

    // Command untuk menambahkan user (testing)
    bot.command('addme', async (ctx) => {
        const userId = ctx.from.id.toString();
        users.add(userId);
        await db.saveUsers(users);
        
        await ctx.replyWithMarkdown(`✅ *User ditambahkan!*\nID: ${userId}\nTotal users: ${users.size}`);
    });
};