const { Telegraf, session } = require('telegraf');
const config = require('./config');
const { connectDB } = require('./lib/database');
const { setupCommands } = require('./src/commands');
const {
    handleStart,
    handleJasherMenu,
    handleOwnerMenu,
    handleAddGroup,
    handleShareBroadcast,
    handleShareVip,
    handleBroadcastMessage,
    handleCheckCredit,
    handleBroadcastToAll,
    handleOwnerBroadcast,
    handleAddPremium,
    handleAddPremiumUser,
    handleRemovePremium,
    handleRemovePremiumUser,
    handleListPremium
} = require('./src/handlers');

// Connect to database
connectDB();

// Initialize bot
const bot = new Telegraf(config.BOT_TOKEN);

// Session middleware
bot.use(session());

// Setup commands
setupCommands(bot);

// Action handlers
bot.action('back_menu', handleStart);
bot.action('jasher_menu', handleJasherMenu);
bot.action('owner_menu', handleOwnerMenu);
bot.action('add_group', handleAddGroup);
bot.action('share_broadcast', handleShareBroadcast);
bot.action('share_vip', handleShareVip);
bot.action('check_credit', handleCheckCredit);
bot.action('broadcast_all', handleBroadcastToAll);
bot.action('add_premium', handleAddPremium);
bot.action('remove_premium', handleRemovePremium);
bot.action('list_premium', handleListPremium);

// Message handlers
bot.on('message', async (ctx) => {
    if (ctx.session.waitingForBroadcast) {
        await handleBroadcastMessage(ctx);
    } else if (ctx.session.waitingForOwnerBroadcast) {
        await handleOwnerBroadcast(ctx);
    } else if (ctx.session.waitingForPremiumAdd) {
        await handleAddPremiumUser(ctx);
    } else if (ctx.session.waitingForPremiumRemove) {
        await handleRemovePremiumUser(ctx);
    } else if (ctx.message && ctx.message.text && ctx.message.text.startsWith('/')) {
        // Ignore unknown commands
        await ctx.reply('Perintah tidak dikenali. Gunakan /help untuk melihat daftar perintah.');
    }
});

// Error handling
bot.catch((err, ctx) => {
    console.error(`Error for ${ctx.updateType}:`, err);
});

// Start bot
bot.launch().then(() => {
    console.log('Bot Jasher started');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));