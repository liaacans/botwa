const { Markup } = require('telegraf');

const mainKeyboard = Markup.keyboard([
    ['/share', '/addgroup']
]).resize();

const shareOptionsKeyboard = Markup.inlineKeyboard([
    [
        Markup.button.callback('Share Teks', 'share_text'),
        Markup.button.callback('Share Reply', 'share_reply')
    ]
]);

const joinGroupKeyboard = Markup.inlineKeyboard([
    [Markup.button.url('Tambahkan ke Group', 'http://t.me/your_bot_username?startgroup=true')],
    [Markup.button.callback('Saya sudah menambahkan', 'join_group')]
]);

module.exports = {
    mainKeyboard,
    shareOptionsKeyboard,
    joinGroupKeyboard
};