const { Telegraf, session } = require('telegraf');
const { BOT_TOKEN } = require('./config');
const { initializeDatabase, getUser, addUser, updateUserCredits } = require('./lib/database');
const { handleStart, handleShare, handleAddGroup, handleJoinGroup } = require('./src/handlers');
const { mainKeyboard, shareOptionsKeyboard } = require('./src/keyboards');

// Inisialisasi bot
const bot = new Telegraf(BOT_TOKEN);

// Middleware session
bot.use(session());

// Inisialisasi database
initializeDatabase();

// Command handlers
bot.command('start', handleStart);
bot.command('share', handleShare);
bot.command('addgroup', handleAddGroup);

// Action handlers
bot.action('join_group', handleJoinGroup);
bot.action('share_text', async (ctx) => {
    ctx.session.waitingForText = true;
    await ctx.editMessageText('Silakan kirim teks yang ingin Anda share.');
});

bot.action('share_reply', async (ctx) => {
    ctx.session.waitingForReply = true;
    await ctx.editMessageText('Silakan reply pesan yang ingin Anda share.');
});

// Handle text messages
bot.on('text', async (ctx) => {
    if (ctx.session.waitingForText) {
        ctx.session.shareText = ctx.message.text;
        ctx.session.waitingForText = false;
        
        const user = getUser(ctx.from.id);
        if (user && user.credits > 0) {
            // Broadcast message to all groups
            // Implementasi broadcast sesuai kebutuhan
            await updateUserCredits(ctx.from.id, -1);
            await ctx.reply(`Pesan berhasil di-share! Kredit berkurang 1. Sisa kredit: ${user.credits - 1}`);
        } else {
            await ctx.reply('Kredit tidak cukup untuk melakukan share.');
        }
    } else {
        await ctx.reply('Gunakan command /start untuk memulai bot.');
    }
});

// Handle replied messages
bot.on('message', async (ctx) => {
    if (ctx.session.waitingForReply && ctx.message.reply_to_message) {
        ctx.session.waitingForReply = false;
        
        const user = getUser(ctx.from.id);
        if (user && user.credits > 0) {
            // Broadcast replied message to all groups
            // Implementasi broadcast sesuai kebutuhan
            await updateUserCredits(ctx.from.id, -1);
            await ctx.reply(`Pesan berhasil di-share! Kredit berkurang 1. Sisa kredit: ${user.credits - 1}`);
        } else {
            await ctx.reply('Kredit tidak cukup untuk melakukan share.');
        }
    }
});

// Error handling
bot.catch((err, ctx) => {
    console.error(`Error for ${ctx.updateType}:`, err);
    ctx.reply('Terjadi kesalahan pada bot. Silakan coba lagi nanti.');
});

// Start bot
bot.launch().then(() => {
    console.log('Bot Jasher started successfully');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));