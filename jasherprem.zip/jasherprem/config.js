global.BOT_TOKEN = "YOUR_BOT_TOKEN_HERE";
global.DEVELOPER_ID = "YOUR_TELEGRAM_ID";
global.DEVELOPER_USERNAME = "@your_username";

// Database configuration
global.db = require('./lib/database');

// Other global variables
global.groupRequirements = 3;
global.premiumDaysPerGroup = 3;