const { Telegraf, Markup, session } = require('telegraf');
const { connectDB, User, Group } = require('./lib/database');
const { isPremium } = require('./lib/utils');
require('./config');
const commandHandler = require('./src/commands');
const obfuscator = require('./src/obf');

const bot = new Telegraf(BOT_TOKEN);

// Session middleware
bot.use(session());

// Database connection
connectDB();

// Middleware to track users and groups
bot.use(async (ctx, next) => {
    if (ctx.from) {
        let user = await User.findOne({ userId: ctx.from.id });
        if (!user) {
            user = new User({
                userId: ctx.from.id,
                username: ctx.from.username,
                firstName: ctx.from.first_name,
                lastName: ctx.from.last_name,
                isCreator: ctx.from.id === config.creatorId
            });
            await user.save();
        }
        ctx.user = user;
    }
    
    if (ctx.chat && ctx.chat.type !== 'private') {
        let group = await Group.findOne({ groupId: ctx.chat.id });
        if (!group) {
            group = new Group({
                groupId: ctx.chat.id,
                title: ctx.chat.title,
                memberCount: await ctx.getChatMembersCount()
            });
            await group.save();
        }
        
        // Add group to user's groups if this is a message from a user
        if (ctx.from && ctx.user) {
            const userGroup = ctx.user.groups.find(g => g.groupId === ctx.chat.id);
            if (!userGroup) {
                ctx.user.groups.push({
                    groupId: ctx.chat.id,
                    groupTitle: ctx.chat.title,
                    joinedAt: new Date()
                });
                await ctx.user.save();
            }
        }
    }
    
    await next();
});

// Start command
bot.start(async (ctx) => {
    const isCreator = ctx.from.id === global.creatorId;
    const username = ctx.from.username || ctx.from.first_name;
    const runtime = require('./lib/utils').runtime(process.uptime());
    const moment = require('moment-timezone');
    
    const menuText = `
╭─❒ 「 User Info 」 
├ Creator : @${developer}
├ Name : @${username}
├ Profile : @${ctx.from.username || ctx.from.first_name}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreator ? 'True' : 'False'}

Silahkan pilih button dibawah ini!`;

    const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('Jasher Menu', 'jasher_menu')],
        [Markup.button.callback('Obf Menu', 'obf_menu')],
        [Markup.button.callback('Owner', 'owner_menu')]
    ]);
    
    try {
        await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
            caption: menuText,
            parse_mode: 'HTML',
            ...keyboard
        });
    } catch (error) {
        await ctx.reply(menuText, { parse_mode: 'HTML', ...keyboard });
    }
});

// Handle callback queries
bot.action('jasher_menu', async (ctx) => {
    await commandHandler.handleJasherMenu(ctx);
});

bot.action('obf_menu', async (ctx) => {
    await commandHandler.handleObfMenu(ctx);
});

bot.action('owner_menu', async (ctx) => {
    await commandHandler.handleOwnerMenu(ctx);
});

bot.action('main_menu', async (ctx) => {
    await ctx.deleteMessage();
    await ctx.answerCbQuery();
    await bot.telegram.sendMessage(ctx.chat.id, 'Returning to main menu...');
    await bot.telegram.sendPhoto(ctx.chat.id, 'https://f.top4top.io/p_3530xky9e4.jpg', {
        caption: 'Main Menu',
        ...Markup.inlineKeyboard([
            [Markup.button.callback('Jasher Menu', 'jasher_menu')],
            [Markup.button.callback('Obf Menu', 'obf_menu')],
            [Markup.button.callback('Owner', 'owner_menu')]
        ])
    });
});

// Register commands
bot.command('addprem', async (ctx) => {
    await commandHandler.handleAddPrem(ctx);
});

bot.command('delprem', async (ctx) => {
    await commandHandler.handleDelPrem(ctx);
});

bot.command('listprem', async (ctx) => {
    await commandHandler.handleListPrem(ctx);
});

bot.command('addbl', async (ctx) => {
    await commandHandler.handleAddBlacklist(ctx);
});

bot.command('delbl', async (ctx) => {
    await commandHandler.handleDelBlacklist(ctx);
});

bot.command('listbl', async (ctx) => {
    await commandHandler.handleListBlacklist(ctx);
});

bot.command('autojasher', async (ctx) => {
    await commandHandler.handleAutoJasher(ctx);
});

bot.command('stopautojasher', async (ctx) => {
    await commandHandler.handleStopAutoJasher(ctx);
});

bot.command('listgrup', async (ctx) => {
    await commandHandler.handleListGroups(ctx);
});

bot.command('tourl', async (ctx) => {
    await commandHandler.handleToUrl(ctx);
});

bot.command('sharevip', async (ctx) => {
    await commandHandler.handleShareVip(ctx);
});

// Obfuscation commands
bot.command('enclocked', async (ctx) => {
    await obfuscator.handleEnclocked(ctx);
});

bot.command('quantum', async (ctx) => {
    await obfuscator.handleQuantum(ctx);
});

// Handle text messages for sharing
bot.on('text', async (ctx) => {
    if (ctx.chat.type === 'private') {
        if (ctx.message.reply_to_message) {
            const repliedMsg = ctx.message.reply_to_message;
            if (repliedMsg.text && repliedMsg.text.includes('Share this message to groups')) {
                await commandHandler.handleShare(ctx);
            }
        }
    }
});

// Error handling
bot.catch((err, ctx) => {
    console.error(`Error for ${ctx.updateType}:`, err);
    ctx.reply('An error occurred. Please try again later.');
});

// Start bot
bot.launch().then(() => {
    console.log('Bot Jasher Premium is running...');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));