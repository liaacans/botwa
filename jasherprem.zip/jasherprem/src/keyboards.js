const { Markup } = require('telegraf');

function mainMenuKeyboard() {
    return Markup.keyboard([
        ['Jasher Menu', 'Owner Menu'],
        ['Kembali', 'AddGroup'],
        ['Owner']
    ]).resize();
}

function jasherMenuKeyboard() {
    return Markup.keyboard([
        ['Credit', 'Share'],
        ['ShareVIP', 'Kembali']
    ]).resize();
}

function ownerMenuKeyboard() {
    return Markup.keyboard([
        ['Broadcast', 'ListPrem'],
        ['AddPrem', 'DelPrem', 'Kembali']
    ]).resize();
}

function backKeyboard() {
    return Markup.keyboard([
        ['Kembali']
    ]).resize();
}

module.exports = {
    mainMenuKeyboard,
    jasherMenuKeyboard,
    ownerMenuKeyboard,
    backKeyboard
};