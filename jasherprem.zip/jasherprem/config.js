global.BOT_TOKEN = "8198305874:AAGhlBEYItkhH2mxD265kLIMXVEcWMiwkMM";
global.DEVELOPER_ID = "8135269613";
global.DEVELOPER_USERNAME = "@ginaabaikhati";

// Konfigurasi lainnya
global.premiumUsers = new Map();
global.userGroups = new Map();
global.blacklistedGroups = new Set();
global.autoJasherInterval = null;

module.exports = {
    BOT_TOKEN: global.BOT_TOKEN,
    DEVELOPER_ID: global.DEVELOPER_ID,
    DEVELOPER_USERNAME: global.DEVELOPER_USERNAME
};