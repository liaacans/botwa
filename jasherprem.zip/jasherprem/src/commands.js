const { Markup } = require('telegraf');
const { User, Group } = require('../lib/database');
const { escapeMarkdown, runtime, moment } = require('./utils');
const axios = require('axios');

// Fungsi untuk mendapatkan menu utama
function getMainMenu(ctx, userData) {
    const sender = ctx.from.first_name;
    const userTelelu = ctx.from.username ? `@${ctx.from.username}` : 'Tidak ada';
    const isCreator = ctx.from.id.toString() === process.env.OWNER_ID;
    
    const caption = `Hi kak @${sender}
╭─❒ 「 User Info 」 
├ Creator : @${userTelelu}
├ Name : ${ctx.from.first_name}${ctx.from.last_name ? ' ' + ctx.from.last_name : ''}
├ Profile : ${userTelelu}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : Linux
├ Platform : Bot Telegram
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreator ? 'True' : 'False'}

Silahkan pilih button dibawah ini!`;

    const buttons = Markup.inlineKeyboard([
        [Markup.button.callback('🎯 Jasher Menu', 'jasher_menu')],
        [Markup.button.callback('👤 Owner Menu', 'owner_menu'), Markup.button.callback('➕ Add Group', 'add_group')],
        [Markup.button.url('👨‍💻 Owner', 'https://t.me/your_username')]
    ]);

    return { caption, buttons };
}

// Handler untuk command start
async function handleStart(ctx) {
    try {
        // Cek atau buat user di database
        let user = await User.findOne({ userId: ctx.from.id });
        if (!user) {
            user = new User({
                userId: ctx.from.id,
                username: ctx.from.username,
                firstName: ctx.from.first_name,
                lastName: ctx.from.last_name
            });
            await user.save();
        }

        // Kiram gambar dengan menu
        const { caption, buttons } = getMainMenu(ctx, user);
        
        // Download gambar dari URL
        const imageUrl = 'https://f.top4top.io/p_3530xky9e4.jpg';
        const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const imageBuffer = Buffer.from(response.data, 'binary');
        
        await ctx.replyWithPhoto(
            { source: imageBuffer },
            {
                caption: caption,
                parse_mode: 'Markdown',
                reply_markup: buttons.reply_markup
            }
        );
    } catch (error) {
        console.error('Error in start command:', error);
        await ctx.reply('Terjadi kesalahan. Silakan coba lagi.');
    }
}

// Handler untuk command help
async function handleHelp(ctx) {
    const helpText = `*Jasher Bot Help*

*Perintah Umum:*
/start - Memulai bot
/help - Menampilkan bantuan
/credit - Menampilkan kredit Anda
/share - Membagikan pesan (hanya di chat private)

*Perintah Premium:*
/sharevip - Membagikan pesan dengan prioritas tinggi

*Perintah Owner:*
/addprem - Menambahkan user premium
/delprem - Menghapus user premium
/listprem - Menampilkan daftar user premium
/broadcast - Mengirim pesan ke semua user

Tambahkan bot ke 3 grup untuk mendapatkan 10 kredit!`;
    
    await ctx.reply(helpText, { parse_mode: 'Markdown' });
}

// Handler untuk command credit
async function handleCredit(ctx) {
    try {
        const user = await User.findOne({ userId: ctx.from.id });
        if (!user) {
            return await ctx.reply('Anda belum terdaftar. Ketik /start untuk mendaftar.');
        }
        
        await ctx.reply(`Kredit Anda: ${user.credit}`);
    } catch (error) {
        console.error('Error in credit command:', error);
        await ctx.reply('Terjadi kesalahan. Silakan coba lagi.');
    }
}

// Handler untuk command share
async function handleShare(ctx) {
    try {
        // Hanya diizinkan di private chat
        if (ctx.chat.type !== 'private') {
            return await ctx.reply('Perintah /share hanya dapat digunakan di chat private.');
        }
        
        const user = await User.findOne({ userId: ctx.from.id });
        if (!user) {
            return await ctx.reply('Anda belum terdaftar. Ketik /start untuk mendaftar.');
        }
        
        // Cek apakah user memiliki cukup kredit
        if (user.credit < 2) {
            return await ctx.reply('Kredit Anda tidak cukup. Tambahkan bot ke 3 grup untuk mendapatkan 10 kredit.');
        }
        
        // Cek apakah ada pesan yang dibalas
        if (!ctx.message.reply_to_message) {
            return await ctx.reply('Anda harus membalas pesan yang ingin dibagikan dengan perintah /share.');
        }
        
        // Kurangi kredit
        user.credit -= 2;
        await user.save();
        
        // Kirim pesan ke semua grup yang telah ditambahkan
        const groups = await Group.find();
        let successCount = 0;
        
        for (const group of groups) {
            try {
                await ctx.telegram.copyMessage(
                    group.groupId,
                    ctx.chat.id,
                    ctx.message.reply_to_message.message_id
                );
                successCount++;
            } catch (error) {
                console.error(`Error sending to group ${group.groupId}:`, error);
            }
        }
        
        await ctx.reply(`Pesan berhasil dibagikan ke ${successCount} grup. Kredit berkurang 2. Sisa kredit: ${user.credit}`);
    } catch (error) {
        console.error('Error in share command:', error);
        await ctx.reply('Terjadi kesalahan. Silakan coba lagi.');
    }
}

// Handler untuk command sharevip
async function handleShareVip(ctx) {
    try {
        // Hanya diizinkan di private chat
        if (ctx.chat.type !== 'private') {
            return await ctx.reply('Perintah /sharevip hanya dapat digunakan di chat private.');
        }
        
        const user = await User.findOne({ userId: ctx.from.id });
        if (!user) {
            return await ctx.reply('Anda belum terdaftar. Ketik /start untuk mendaftar.');
        }
        
        // Cek apakah user premium
        if (!user.isPremium) {
            return await ctx.reply('Fitur ini hanya untuk user premium. Hubungi owner untuk menjadi premium.');
        }
        
        // Cek apakah ada pesan yang dibalas
        if (!ctx.message.reply_to_message) {
            return await ctx.reply('Anda harus membalas pesan yang ingin dibagikan dengan perintah /sharevip.');
        }
        
        // Kirim pesan ke semua grup yang telah ditambahkan (lebih cepat)
        const groups = await Group.find();
        let successCount = 0;
        
        // Menggunakan Promise.all untuk mengirim secara paralel (lebih cepat)
        const sendPromises = groups.map(async (group) => {
            try {
                await ctx.telegram.copyMessage(
                    group.groupId,
                    ctx.chat.id,
                    ctx.message.reply_to_message.message_id
                );
                successCount++;
                return true;
            } catch (error) {
                console.error(`Error sending to group ${group.groupId}:`, error);
                return false;
            }
        });
        
        await Promise.all(sendPromises);
        
        await ctx.reply(`Pesan VIP berhasil dibagikan ke ${successCount} grup dengan cepat!`);
    } catch (error) {
        console.error('Error in sharevip command:', error);
        await ctx.reply('Terjadi kesalahan. Silakan coba lagi.');
    }
}

// Handler untuk command addprem (owner only)
async function handleAddPrem(ctx) {
    try {
        // Cek apakah user adalah owner
        if (ctx.from.id.toString() !== process.env.OWNER_ID) {
            return await ctx.reply('Perintah ini hanya untuk owner.');
        }
        
        // Cek apakah ada username atau ID yang disebutkan
        const mentionedUser = ctx.message.text.split(' ')[1];
        if (!mentionedUser) {
            return await ctx.reply('Gunakan: /addprem <username atau ID>');
        }
        
        // Cari user berdasarkan username atau ID
        let user;
        if (isNaN(mentionedUser)) {
            // Jika berupa username (hilangkan @ jika ada)
            const username = mentionedUser.replace('@', '');
            user = await User.findOne({ username: username });
        } else {
            // Jika berupa ID
            user = await User.findOne({ userId: parseInt(mentionedUser) });
        }
        
        if (!user) {
            return await ctx.reply('User tidak ditemukan.');
        }
        
        // Jadikan premium
        user.isPremium = true;
        await user.save();
        
        await ctx.reply(`User ${user.username || user.userId} sekarang premium.`);
    } catch (error) {
        console.error('Error in addprem command:', error);
        await ctx.reply('Terjadi kesalahan. Silakan coba lagi.');
    }
}

// Handler untuk command delprem (owner only)
async function handleDelPrem(ctx) {
    try {
        // Cek apakah user adalah owner
        if (ctx.from.id.toString() !== process.env.OWNER_ID) {
            return await ctx.reply('Perintah ini hanya untuk owner.');
        }
        
        // Cek apakah ada username atau ID yang disebutkan
        const mentionedUser = ctx.message.text.split(' ')[1];
        if (!mentionedUser) {
            return await ctx.reply('Gunakan: /delprem <username atau ID>');
        }
        
        // Cari user berdasarkan username atau ID
        let user;
        if (isNaN(mentionedUser)) {
            // Jika berupa username (hilangkan @ jika ada)
            const username = mentionedUser.replace('@', '');
            user = await User.findOne({ username: username });
        } else {
            // Jika berupa ID
            user = await User.findOne({ userId: parseInt(mentionedUser) });
        }
        
        if (!user) {
            return await ctx.reply('User tidak ditemukan.');
        }
        
        // Hapus status premium
        user.isPremium = false;
        await user.save();
        
        await ctx.reply(`User ${user.username || user.userId} tidak lagi premium.`);
    } catch (error) {
        console.error('Error in delprem command:', error);
        await ctx.reply('Terjadi kesalahan. Silakan coba lagi.');
    }
}

// Handler untuk command listprem (owner only)
async function handleListPrem(ctx) {
    try {
        // Cek apakah user adalah owner
        if (ctx.from.id.toString() !== process.env.OWNER_ID) {
            return await ctx.reply('Perintah ini hanya untuk owner.');
        }
        
        // Dapatkan semua user premium
        const premiumUsers = await User.find({ isPremium: true });
        
        if (premiumUsers.length === 0) {
            return await ctx.reply('Tidak ada user premium.');
        }
        
        let listText = 'Daftar User Premium:\n\n';
        premiumUsers.forEach((user, index) => {
            listText += `${index + 1}. ${user.username ? '@' + user.username : 'No username'} (ID: ${user.userId})\n`;
        });
        
        await ctx.reply(listText);
    } catch (error) {
        console.error('Error in listprem command:', error);
        await ctx.reply('Terjadi kesalahan. Silakan coba lagi.');
    }
}

// Handler untuk command broadcast (owner only)
async function handleBroadcast(ctx) {
    try {
        // Cek apakah user adalah owner
        if (ctx.from.id.toString() !== process.env.OWNER_ID) {
            return await ctx.reply('Perintah ini hanya untuk owner.');
        }
        
        // Cek apakah ada pesan yang dibalas
        if (!ctx.message.reply_to_message) {
            return await ctx.reply('Anda harus membalas pesan yang ingin di-broadcast.');
        }
        
        // Dapatkan semua user
        const allUsers = await User.find();
        let successCount = 0;
        
        // Kirim ke semua user
        for (const user of allUsers) {
            try {
                await ctx.telegram.copyMessage(
                    user.userId,
                    ctx.chat.id,
                    ctx.message.reply_to_message.message_id
                );
                successCount++;
            } catch (error) {
                console.error(`Error sending to user ${user.userId}:`, error);
            }
        }
        
        await ctx.reply(`Broadcast berhasil dikirim ke ${successCount} user.`);
    } catch (error) {
        console.error('Error in broadcast command:', error);
        await ctx.reply('Terjadi kesalahan. Silakan coba lagi.');
    }
}

module.exports = {
    handleStart,
    handleHelp,
    handleCredit,
    handleShare,
    handleShareVip,
    handleAddPrem,
    handleDelPrem,
    handleListPrem,
    handleBroadcast
};