const { User, Group } = require('../lib/database');
const { formatUserInfo } = require('../lib/utils');
const { mainMenuKeyboard, jasherMenuKeyboard, ownerMenuKeyboard, backKeyboard } = require('./keyboards');

async function handleStart(ctx) {
    try {
        // Simpan atau update user data
        const userData = {
            userId: ctx.from.id,
            username: ctx.from.username,
            firstName: ctx.from.first_name,
            lastName: ctx.from.last_name
        };
        
        let user = await User.findOne({ userId: ctx.from.id });
        if (!user) {
            user = new User(userData);
            await user.save();
        } else {
            await User.updateOne({ userId: ctx.from.id }, userData);
        }
        
        const message = formatUserInfo(ctx, user);
        await ctx.replyWithHTML(message, mainMenuKeyboard());
    } catch (error) {
        console.error('Error in start command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleHelp(ctx) {
    const helpMessage = `<b>Bantuan Jasher Bot</b>
    
<b>Fitur Umum:</b>
- <code>/credit</code> : Cek credit Anda
- <code>/share</code> : Share pesan (kurang 2 credit)
- <code>/sharevip</code> : Share pesan VIP (lebih cepat)

<b>Fitur Premium:</b>
- <code>/addprem</code> : Tambah user premium (Owner only)
- <code>/delprem</code> : Hapus user premium (Owner only)
- <code>/listprem</code> : List user premium (Owner only)
- <code>/broadcast</code> : Broadcast ke semua user (Owner only)

Gunakan button untuk navigasi yang lebih mudah!`;
    
    await ctx.replyWithHTML(helpMessage, mainMenuKeyboard());
}

async function handleCredit(ctx) {
    try {
        const user = await User.findOne({ userId: ctx.from.id });
        if (!user) {
            return await ctx.reply('Anda belum terdaftar. Ketik /start untuk mendaftar.');
        }
        
        await ctx.replyWithHTML(`Credit Anda: <b>${user.credit}</b>\n\nUntuk menambah credit, tambahkan bot ke 3 group. Setiap group yang ditambahkan akan menambah 10 credit.`, backKeyboard());
    } catch (error) {
        console.error('Error in credit command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleShare(ctx) {
    try {
        // Cek apakah di private chat
        if (ctx.chat.type !== 'private') {
            return await ctx.reply('Perintah ini hanya bisa digunakan di private chat!');
        }
        
        const user = await User.findOne({ userId: ctx.from.id });
        if (!user) {
            return await ctx.reply('Anda belum terdaftar. Ketik /start untuk mendaftar.');
        }
        
        // Cek credit
        if (user.credit < 2) {
            return await ctx.reply('Credit Anda tidak cukup. Minimal 2 credit untuk share. Tambahkan bot ke group untuk menambah credit.');
        }
        
        // Cek apakah ada pesan yang di-reply
        if (!ctx.message.reply_to_message) {
            return await ctx.reply('Anda harus mereply pesan yang ingin di-share!', backKeyboard());
        }
        
        // Kurangi credit
        user.credit -= 2;
        await user.save();
        
        // Broadcast pesan ke semua group
        const groups = await Group.find({});
        let successCount = 0;
        
        for (const group of groups) {
            try {
                await ctx.telegram.copyMessage(group.groupId, ctx.chat.id, ctx.message.reply_to_message.message_id);
                successCount++;
            } catch (error) {
                console.error(`Error sending to group ${group.groupId}:`, error);
            }
        }
        
        await ctx.replyWithHTML(`Pesan berhasil di-share ke <b>${successCount}</b> group. Credit berkurang 2. Sisa credit: <b>${user.credit}</b>`, mainMenuKeyboard());
    } catch (error) {
        console.error('Error in share command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleShareVip(ctx) {
    try {
        // Cek apakah di private chat
        if (ctx.chat.type !== 'private') {
            return await ctx.reply('Perintah ini hanya bisa digunakan di private chat!');
        }
        
        const user = await User.findOne({ userId: ctx.from.id });
        if (!user) {
            return await ctx.reply('Anda belum terdaftar. Ketik /start untuk mendaftar.');
        }
        
        if (!user.isPremium) {
            return await ctx.reply('Fitur ini hanya untuk user premium!');
        }
        
        // Cek apakah ada pesan yang di-reply
        if (!ctx.message.reply_to_message) {
            return await ctx.reply('Anda harus mereply pesan yang ingin di-share!', backKeyboard());
        }
        
        // Broadcast pesan ke semua group (lebih cepat)
        const groups = await Group.find({});
        const promises = groups.map(group => {
            return ctx.telegram.copyMessage(group.groupId, ctx.chat.id, ctx.message.reply_to_message.message_id)
                .catch(error => console.error(`Error sending to group ${group.groupId}:`, error));
        });
        
        await Promise.all(promises);
        
        await ctx.replyWithHTML(`Pesan berhasil di-share VIP ke <b>${groups.length}</b> group.`, mainMenuKeyboard());
    } catch (error) {
        console.error('Error in sharevip command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleAddPrem(ctx) {
    try {
        // Cek apakah owner
        if (ctx.from.id.toString() !== process.env.OWNER_ID) {
            return await ctx.reply('Anda bukan owner bot!');
        }
        
        // Cek apakah ada reply atau username yang disebutkan
        let targetUserId;
        if (ctx.message.reply_to_message) {
            targetUserId = ctx.message.reply_to_message.from.id;
        } else if (ctx.message.text.split(' ').length > 1) {
            const username = ctx.message.text.split(' ')[1].replace('@', '');
            // Di sini perlu logika untuk mendapatkan user ID dari username
            // Untuk sederhananya, kita asumsikan input adalah user ID
            targetUserId = parseInt(username);
        } else {
            return await ctx.reply('Gunakan command dengan format: /addprem [user_id] atau reply pesan user');
        }
        
        // Update user menjadi premium
        await User.updateOne({ userId: targetUserId }, { isPremium: true });
        
        await ctx.reply(`User ${targetUserId} berhasil ditambahkan sebagai premium.`, backKeyboard());
    } catch (error) {
        console.error('Error in addprem command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleDelPrem(ctx) {
    try {
        // Cek apakah owner
        if (ctx.from.id.toString() !== process.env.OWNER_ID) {
            return await ctx.reply('Anda bukan owner bot!');
        }
        
        // Cek apakah ada reply atau username yang disebutkan
        let targetUserId;
        if (ctx.message.reply_to_message) {
            targetUserId = ctx.message.reply_to_message.from.id;
        } else if (ctx.message.text.split(' ').length > 1) {
            const username = ctx.message.text.split(' ')[1].replace('@', '');
            targetUserId = parseInt(username);
        } else {
            return await ctx.reply('Gunakan command dengan format: /delprem [user_id] atau reply pesan user');
        }
        
        // Update user menjadi non-premium
        await User.updateOne({ userId: targetUserId }, { isPremium: false });
        
        await ctx.reply(`User ${targetUserId} berhasil dihapus dari premium.`, backKeyboard());
    } catch (error) {
        console.error('Error in delprem command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleListPrem(ctx) {
    try {
        // Cek apakah owner
        if (ctx.from.id.toString() !== process.env.OWNER_ID) {
            return await ctx.reply('Anda bukan owner bot!');
        }
        
        const premiumUsers = await User.find({ isPremium: true });
        
        if (premiumUsers.length === 0) {
            return await ctx.reply('Tidak ada user premium.', backKeyboard());
        }
        
        let message = '<b>Daftar User Premium:</b>\n\n';
        premiumUsers.forEach((user, index) => {
            message += `${index + 1}. ID: ${user.userId} | Username: @${user.username || 'N/A'}\n`;
        });
        
        await ctx.replyWithHTML(message, backKeyboard());
    } catch (error) {
        console.error('Error in listprem command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleBroadcast(ctx) {
    try {
        // Cek apakah owner
        if (ctx.from.id.toString() !== process.env.OWNER_ID) {
            return await ctx.reply('Anda bukan owner bot!');
        }
        
        // Cek apakah ada pesan yang di-reply
        if (!ctx.message.reply_to_message) {
            return await ctx.reply('Anda harus mereply pesan yang ingin di-broadcast!', backKeyboard());
        }
        
        const allUsers = await User.find({});
        let successCount = 0;
        
        for (const user of allUsers) {
            try {
                await ctx.telegram.copyMessage(user.userId, ctx.chat.id, ctx.message.reply_to_message.message_id);
                successCount++;
            } catch (error) {
                console.error(`Error sending to user ${user.userId}:`, error);
            }
        }
        
        await ctx.replyWithHTML(`Broadcast berhasil dikirim ke <b>${successCount}</b> user.`, backKeyboard());
    } catch (error) {
        console.error('Error in broadcast command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

module.exports = {
    handleStart,
    handleHelp,
    handleCredit,
    handleShare,
    handleShareVip,
    handleAddPrem,
    handleDelPrem,
    handleListPrem,
    handleBroadcast
};