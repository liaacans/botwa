const { Telegraf } = require('telegraf');
const imap = require('imap-simple');
const simpleParser = require('mailparser').simpleParser;
const nodemailer = require('nodemailer');
const fs = require('fs');
const path = require('path');

// Konfigurasi
const BOT_TOKEN = '7569137877:AAHnvva5p9SFclkDpDio8QcJsSfbzlrK6IY';
const IMAP_CONFIG = {
  imap: {
    user: 'nokosmerah@buatkamu.web.id',
    password: 'Grki6Vv1gdlA',
    host: 'newpinwheel.indowebsite.net',
    port: 993,
    tls: true,
    tlsOptions: { rejectUnauthorized: false },
    authTimeout: 10000
  }
};
const SMTP_CONFIG = {
  host: 'newpinwheel.indowebsite.net',
  port: 587,
  secure: false,
  auth: {
    user: 'nokosmerah@buatkamu.web.id',
    pass: 'Grki6Vv1gdlA'
  }
};

// Inisialisasi bot
const bot = new Telegraf(BOT_TOKEN);

// Inisialisasi transporter SMTP
const transporter = nodemailer.createTransport(SMTP_CONFIG);

// Variabel untuk melacak email yang sudah diproses
let processedEmails = new Set();

// File untuk menyimpan data admin dan notifikasi
const DATA_FILE = 'bot_data.json';

// Load data dari file
let botData = {
  adminUsers: new Set(),
  notificationUsers: new Set(),
  allowedGroups: new Set()
};

function loadData() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const data = fs.readFileSync(DATA_FILE, 'utf8');
      const parsed = JSON.parse(data);
      botData.adminUsers = new Set(parsed.adminUsers || []);
      botData.notificationUsers = new Set(parsed.notificationUsers || []);
      botData.allowedGroups = new Set(parsed.allowedGroups || []);
    }
  } catch (error) {
    console.error('Error loading data:', error);
  }
}

function saveData() {
  try {
    const data = {
      adminUsers: Array.from(botData.adminUsers),
      notificationUsers: Array.from(botData.notificationUsers),
      allowedGroups: Array.from(botData.allowedGroups)
    };
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
  } catch (error) {
    console.error('Error saving data:', error);
  }
}

// Load data saat start
loadData();

// Fungsi untuk memeriksa dan memproses email baru
async function checkNewEmails() {
  console.log('Memeriksa email baru...');
  
  try {
    const connection = await imap.connect(IMAP_CONFIG);
    console.log('Terhubung ke server IMAP');

    await connection.openBox('INBOX');
    console.log('Kotak masuk terbuka');

    // Cari email yang belum dibaca
    const searchCriteria = ['UNSEEN'];
    const fetchOptions = {
      bodies: [''],
      markSeen: true,
      struct: true
    };

    const messages = await connection.search(searchCriteria, fetchOptions);
    console.log(`Ditemukan ${messages.length} email baru`);

    for (const message of messages) {
      const all = message.parts.find(part => part.which === '');
      const id = message.attributes.uid;
      const idHeader = "Message-ID: " + (message.attributes['x-gm-msgid'] || id);

      if (processedEmails.has(idHeader)) {
        console.log(`Email ${idHeader} sudah diproses, dilewati`);
        continue;
      }

      const parsedEmail = await simpleParser(all.body);
      console.log('Memproses email dari:', parsedEmail.from.text);

      // Kirim notifikasi ke admin dan user yang berlangganan
      const emailText = `📧 EMAIL BARU\n\nDari: ${parsedEmail.from.text}\nKepada: ${parsedEmail.to.text}\nSubjek: ${parsedEmail.subject}\n\n${parsedEmail.text ? parsedEmail.text.substring(0, 1000) + (parsedEmail.text.length > 1000 ? '...' : '') : 'Tidak ada konten teks'}`;

      // Kirim ke semua admin
      for (const userId of botData.adminUsers) {
        try {
          await bot.telegram.sendMessage(userId, emailText);
          console.log(`Notifikasi terkirim ke admin: ${userId}`);
        } catch (error) {
          console.error(`Gagal mengirim ke admin ${userId}:`, error);
        }
      }

      // Kirim ke user yang berlangganan notifikasi
      for (const userId of botData.notificationUsers) {
        try {
          await bot.telegram.sendMessage(userId, emailText);
          console.log(`Notifikasi terkirim ke user: ${userId}`);
        } catch (error) {
          console.error(`Gagal mengirim ke user ${userId}:`, error);
        }
      }

      processedEmails.add(idHeader);
      console.log(`Email ${idHeader} diproses`);
    }

    connection.end();
  } catch (error) {
    console.error('Error memeriksa email:', error);
  }
}

// Command /sendmail untuk mengirim email
bot.command('sendmail', async (ctx) => {
  if (ctx.chat.type === 'channel') {
    return ctx.reply('❌ Perintah ini tidak dapat digunakan di channel.');
  }

  // Cek apakah user adalah admin
  if (!botData.adminUsers.has(ctx.from.id.toString())) {
    return ctx.reply('❌ Anda bukan admin. Hanya admin yang dapat mengirim email.');
  }

  try {
    const args = ctx.message.text.split(' ').slice(1);
    if (args.length < 3) {
      return ctx.reply('📝 Format: /sendmail <email_tujuan> <subjek> <pesan>\n\nContoh: /sendmail contoh@email.com "Test Subject" "Pesan tes"');
    }

    const toEmail = args[0];
    const subject = args.slice(1, -1).join(' ');
    const message = args[args.length - 1];

    const mailOptions = {
      from: 'nokosmerah@buatkamu.web.id',
      to: toEmail,
      subject: subject,
      text: message,
      html: `<p>${message.replace(/\n/g, '<br>')}</p>`
    };

    await transporter.sendMail(mailOptions);
    console.log(`Email terkirim ke: ${toEmail}, subjek: ${subject}`);
    ctx.reply(`✅ Email berhasil dikirim ke ${toEmail}`);
  } catch (error) {
    console.error('Error mengirim email:', error);
    ctx.reply('❌ Gagal mengirim email. Silakan coba lagi.');
  }
});

// Command untuk berlangganan notifikasi email
bot.command('subemail', async (ctx) => {
  if (ctx.chat.type !== 'private') {
    return ctx.reply('❌ Berlangganan notifikasi hanya bisa di chat pribadi.');
  }

  botData.notificationUsers.add(ctx.from.id.toString());
  saveData();
  ctx.reply('✅ Anda berhasil berlangganan notifikasi email baru!');
});

// Command untuk berhenti langganan notifikasi
bot.command('unsubemail', async (ctx) => {
  if (ctx.chat.type !== 'private') {
    return ctx.reply('❌ Berhenti langganan hanya bisa di chat pribadi.');
  }

  botData.notificationUsers.delete(ctx.from.id.toString());
  saveData();
  ctx.reply('✅ Anda berhenti berlangganan notifikasi email.');
});

// Command untuk info status
bot.command('status', async (ctx) => {
  const isAdmin = botData.adminUsers.has(ctx.from.id.toString());
  const isSubscribed = botData.notificationUsers.has(ctx.from.id.toString());
  const isGroupAllowed = botData.allowedGroups.has(ctx.chat.id.toString());

  let statusMessage = `🤖 Status Bot Email\n\n`;
  statusMessage += `👤 User ID: ${ctx.from.id}\n`;
  statusMessage += `💬 Chat Type: ${ctx.chat.type}\n`;
  statusMessage += `🛡️ Admin: ${isAdmin ? '✅' : '❌'}\n`;
  statusMessage += `🔔 Notifikasi: ${isSubscribed ? '✅' : '❌'}\n`;
  
  if (ctx.chat.type !== 'private') {
    statusMessage += `👥 Grup Diizinkan: ${isGroupAllowed ? '✅' : '❌'}\n`;
  }

  statusMessage += `\n📊 Statistik:\n`;
  statusMessage += `• Admin: ${botData.adminUsers.size} user\n`;
  statusMessage += `• Notifikasi: ${botData.notificationUsers.size} user\n`;
  statusMessage += `• Grup Diizinkan: ${botData.allowedGroups.size} grup\n`;
  statusMessage += `• Email Diproses: ${processedEmails.size} email`;

  ctx.reply(statusMessage);
});

// Command untuk bantuan
bot.command('help', (ctx) => {
  const helpText = `🤖 Bot Email Help\n
Perintah untuk semua user:
/start - Mulai bot
/help - Tampilkan bantuan
/status - Status bot
/subemail - Langganan notifikasi email (hanya private)
/unsubemail - Berhenti langganan notifikasi (hanya private)

Perintah untuk admin:
/sendmail - Kirim email

Format /sendmail:
/sendmail email@tujuan.com "Subjek email" "Pesan email"

Contoh:
/sendmail contoh@gmail.com "Test Subject" "Ini adalah pesan test"`;

  ctx.reply(helpText);
});

// Start command - Otomatis simpan user yang memulai bot
bot.command('start', (ctx) => {
  console.log(`Bot dimulai oleh: ${ctx.from.id} di ${ctx.chat.type}`);
  
  // Otomatis simpan user sebagai admin jika chat private
  if (ctx.chat.type === 'private') {
    if (!botData.adminUsers.has(ctx.from.id.toString())) {
      botData.adminUsers.add(ctx.from.id.toString());
      saveData();
      console.log(`User ${ctx.from.id} ditambahkan sebagai admin`);
    }
  }
  
  // Otomatis simpan grup yang diizinkan jika di grup
  if (ctx.chat.type === 'group' || ctx.chat.type === 'supergroup') {
    if (!botData.allowedGroups.has(ctx.chat.id.toString())) {
      botData.allowedGroups.add(ctx.chat.id.toString());
      saveData();
      console.log(`Grup ${ctx.chat.id} ditambahkan ke daftar yang diizinkan`);
    }
  }

  const welcomeText = `🤖 Selamat datang di Bot Email!\n
Saya membantu mengelola email Anda. Fitur yang tersedia:
• Menerima notifikasi email baru
• Mengirim email melalui Telegram
• Manajemen multi-user

Gunakan /help untuk melihat semua perintah yang tersedia.`;

  ctx.reply(welcomeText);
});

// Middleware untuk otomatis menyimpan data grup dan user
bot.use((ctx, next) => {
  // Otomatis simpan user private sebagai admin
  if (ctx.chat && ctx.chat.type === 'private' && ctx.from) {
    if (!botData.adminUsers.has(ctx.from.id.toString())) {
      botData.adminUsers.add(ctx.from.id.toString());
      saveData();
      console.log(`User ${ctx.from.id} otomatis ditambahkan sebagai admin`);
    }
  }
  
  // Otomatis simpan grup yang mengirim pesan
  if (ctx.chat && (ctx.chat.type === 'group' || ctx.chat.type === 'supergroup')) {
    if (!botData.allowedGroups.has(ctx.chat.id.toString())) {
      botData.allowedGroups.add(ctx.chat.id.toString());
      saveData();
      console.log(`Grup ${ctx.chat.id} otomatis ditambahkan ke daftar yang diizinkan`);
    }
  }
  
  return next();
});

// Event ketika bot ditambahkan ke grup
bot.on('new_chat_members', (ctx) => {
  if (ctx.message.new_chat_member.id === ctx.botInfo.id) {
    // Otomatis simpan grup ke daftar yang diizinkan
    if (!botData.allowedGroups.has(ctx.chat.id.toString())) {
      botData.allowedGroups.add(ctx.chat.id.toString());
      saveData();
      console.log(`Grup ${ctx.chat.id} ditambahkan ke daftar yang diizinkan`);
    }
    ctx.reply('🤖 Terima kasih telah menambahkan saya! Bot sekarang dapat digunakan di grup ini.');
  }
});

// Handle error
bot.catch((err, ctx) => {
  console.error(`Error untuk update ${ctx.updateType}:`, err);
});

// Jalankan bot
bot.launch().then(() => {
  console.log('✅ Bot Telegram berjalan');
  console.log('🤖 Bot info:', bot.botInfo);
});

// Jadwalkan pengecekan email setiap 1 menit
setInterval(checkNewEmails, 60000);

// Jalankan pengecekan email sekali saat mulai
setTimeout(checkNewEmails, 3000);

// Enable graceful stop
process.once('SIGINT', () => {
  console.log('🛑 Menghentikan bot...');
  bot.stop('SIGINT');
  saveData();
  process.exit(0);
});

process.once('SIGTERM', () => {
  console.log('🛑 Menghentikan bot...');
  bot.stop('SIGTERM');
  saveData();
  process.exit(0);
});

// Simpan data secara periodik
setInterval(saveData, 60000); // Setiap 1 menit