const { Telegraf } = require('telegraf');
const imap = require('imap-simple');
const simpleParser = require('mailparser').simpleParser;
const nodemailer = require('nodemailer');
const { simple } = require('imap-simple');

// Konfigurasi Bot Telegram
const BOT_TOKEN = '7569137877:AAHnvva5p9SFclkDpDio8QcJsSfbzlrK6IY';
const ALLOWED_GROUP_ID = '-1002793801544';

// Konfigurasi Email
const emailConfig = {
  imap: {
    user: 'nokosmerah@buatkamu.web.id',
    password: 'Grki6Vv1gdlA',
    host: 'newpinwheel.indowebsite.net',
    port: 993,
    tls: true,
    tlsOptions: { rejectUnauthorized: false },
    authTimeout: 3000
  },
  smtp: {
    host: 'newpinwheel.indowebsite.net',
    port: 465,
    secure: true,
    auth: {
      user: 'nokosmerah@buatkamu.web.id',
      pass: 'Grki6Vv1gdlA'
    }
  }
};

// Inisialisasi Bot
const bot = new Telegraf(BOT_TOKEN);

// Inisialisasi Transporter SMTP
const transporter = nodemailer.createTransporter(emailConfig.smtp);

// Fungsi untuk memeriksa email baru
async function checkEmails() {
  try {
    const connection = await imap.connect({ imap: emailConfig.imap });
    
    await connection.openBox('INBOX');
    const searchCriteria = ['UNSEEN'];
    const fetchOptions = { 
      bodies: ['HEADER', 'TEXT', ''],
      markSeen: true // Otomatis tandai sebagai terbaca
    };
    
    const results = await connection.search(searchCriteria, fetchOptions);
    
    for (const result of results) {
      const all = result.parts.find(part => part.which === '');
      const id = result.attributes.uid;
      const idHeader = "Message-ID: " + id;
      
      const parsed = await simpleParser(all.body);
      
      // Format pesan email untuk dikirim ke grup
      const emailMessage = `
📧 <b>Email Baru</b>
────────────────
<b>Dari:</b> ${parsed.from.text}
<b>Kepada:</b> ${parsed.to.text}
<b>Subjek:</b> ${parsed.subject}
<b>Tanggal:</b> ${parsed.date}

${parsed.text?.substring(0, 1000)}${parsed.text && parsed.text.length > 1000 ? '...' : ''}
────────────────
<b>Balas email ini dengan:</b> <code>/balas ${id} [pesan_anda]</code>
      `;
      
      // Kirim ke grup yang diizinkan
      await bot.telegram.sendMessage(ALLOWED_GROUP_ID, emailMessage, { 
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: "📨 Balas Email",
                callback_data: `reply_${id}`
              }
            ]
          ]
        }
      });
    }
    
    connection.end();
  } catch (error) {
    console.error('Error checking emails:', error);
  }
}

// Periksa email baru setiap 1 menit
setInterval(checkEmails, 60000);

// Command untuk membalas email
bot.command('balas', async (ctx) => {
  // Hanya izinkan di grup yang ditentukan
  if (ctx.chat.id.toString() !== ALLOWED_GROUP_ID) {
    await ctx.reply('Bot hanya dapat digunakan di grup tertentu.');
    return;
  }
  
  const args = ctx.message.text.split(' ');
  if (args.length < 3) {
    await ctx.reply('Format: /balas [message_id] [pesan_anda]');
    return;
  }
  
  const messageId = args[1];
  const replyMessage = args.slice(2).join(' ');
  
  try {
    // Kirim balasan email
    await transporter.sendMail({
      from: emailConfig.imap.user,
      to: 'recipient@example.com', // Ganti dengan alamat penerima yang sesuai
      subject: `Re: ${messageId}`,
      text: replyMessage
    });
    
    await ctx.reply('✅ Balasan email telah dikirim!');
  } catch (error) {
    console.error('Error sending email:', error);
    await ctx.reply('❌ Gagal mengirim balasan email.');
  }
});

// Handler untuk tombol balas inline
bot.action(/reply_(.+)/, async (ctx) => {
  const messageId = ctx.match[1];
  await ctx.answerCbQuery();
  await ctx.reply(`Ketik balasan Anda dengan format:\n/balas ${messageId} [pesan_anda]`);
});

// Handler ketika bot ditambahkan ke grup
bot.on('chat_member', async (ctx) => {
  const chatMember = ctx.chatMember;
  const chatId = ctx.chat.id.toString();
  
  // Jika bot ditambahkan ke grup yang tidak diizinkan
  if (chatMember.new_chat_member.status === 'member' && 
      chatMember.new_chat_member.user.id === ctx.botInfo.id && 
      chatId !== ALLOWED_GROUP_ID) {
    
    await ctx.leaveChat();
  }
});

// Middleware untuk memeriksa grup
bot.use(async (ctx, next) => {
  // Izinkan pesan dari private chat dan grup yang diizinkan
  if (ctx.chat.type === 'private' || ctx.chat.id.toString() === ALLOWED_GROUP_ID) {
    return next();
  } else {
    // Keluar dari grup yang tidak diizinkan
    if (ctx.chat.type !== 'private') {
      await ctx.leaveChat();
    }
    return;
  }
});

// Jalankan bot
bot.launch().then(() => {
  console.log('Bot berhasil dijalankan!');
  // Periksa email sekali saat bot mulai
  checkEmails();
});

// Tangani proses shutdown dengan graceful
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));