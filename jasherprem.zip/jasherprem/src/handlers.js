const { Markup } = require('telegraf');
const { checkPremium, addGroup, getUserGroups, addPremium, removePremium, listPremium, addBlacklist, removeBlacklist, listBlacklist, broadcastMessage, getStats, uploadToUrl, autoJasher, stopAutoJasher, getActiveGroups, removeGroup } = require('../lib/utils');
const { handleObfCommands, obfuscateTimeLocked, obfuscateQuantum } = require('./obf');

// Handle pesan teks
async function handleMessage(ctx, bot) {
  const text = ctx.message.text;
  const userId = ctx.from.id;
  const chatType = ctx.chat.type;
  const isPrivate = chatType === 'private';
  const isCreator = global.ownerId.includes(userId);
  
  // Pastikan session terdefinisi
  if (!ctx.session) {
    ctx.session = {
      waitingForBroadcast: false,
      waitingForAddPremium: false,
      waitingForRemovePremium: false,
      waitingForAddBlacklist: false,
      waitingForRemoveBlacklist: false,
      waitingForDays: false,
      obfuscationType: null,
      fileContent: null
    };
  }
  
  // Handle session states
  if (ctx.session.waitingForBroadcast) {
    if (isCreator) {
      const result = await broadcastMessage(bot, text);
      await ctx.reply(result);
      delete ctx.session.waitingForBroadcast;
    }
    return;
  }
  
  if (ctx.session.waitingForAddPremium) {
    if (isCreator) {
      const [targetUserId, days] = text.split(':');
      if (targetUserId && days) {
        await addPremium(parseInt(targetUserId), parseInt(days));
        await ctx.reply(`Premium berhasil ditambahkan untuk user ${targetUserId} selama ${days} hari.`);
      } else {
        await ctx.reply('Format salah! Gunakan: userID:hari');
      }
      delete ctx.session.waitingForAddPremium;
    }
    return;
  }
  
  if (ctx.session.waitingForRemovePremium) {
    if (isCreator) {
      await removePremium(parseInt(text));
      await ctx.reply(`Premium berhasil dihapus untuk user ${text}.`);
      delete ctx.session.waitingForRemovePremium;
    }
    return;
  }
  
  if (ctx.session.waitingForAddBlacklist) {
    if (isCreator) {
      const type = isNaN(text) ? 'username' : 'id';
      await addBlacklist(text, type);
      await ctx.reply(`${text} berhasil ditambahkan ke blacklist.`);
      delete ctx.session.waitingForAddBlacklist;
    }
    return;
  }
  
  if (ctx.session.waitingForRemoveBlacklist) {
    if (isCreator) {
      await removeBlacklist(text);
      await ctx.reply(`${text} berhasil dihapus dari blacklist.`);
      delete ctx.session.waitingForRemoveBlacklist;
    }
    return;
  }
  
  if (ctx.session.waitingForDays && ctx.session.fileContent) {
    const days = parseInt(text);
    if (!isNaN(days)) {
      try {
        const obfuscatedCode = await obfuscateTimeLocked(ctx.session.fileContent, days);
        await ctx.reply('Obfuscation berhasil!');
        await ctx.reply(obfuscatedCode, { parse_mode: 'HTML' });
      } catch (error) {
        await ctx.reply('Gagal melakukan obfuscation: ' + error.message);
      }
    } else {
      await ctx.reply('Masukkan jumlah hari yang valid.');
    }
    delete ctx.session.waitingForDays;
    delete ctx.session.fileContent;
    return;
  }
  
  // Handle commands
  if (text.startsWith('/')) {
    const command = text.split(' ')[0].toLowerCase();
    
    switch (command) {
      case '/sharefree':
        if (!isPrivate) {
          await ctx.reply('Command ini hanya bisa digunakan di private chat!');
          return;
        }
        
        if (!ctx.message.reply_to_message) {
          await ctx.reply('Silakan reply pesan yang ingin dishare!');
          return;
        }
        
        const userGroups = await getUserGroups(userId);
        if (userGroups.length < 3) {
          await ctx.reply('Anda harus menambahkan bot ke minimal 3 grup terlebih dahulu!');
          return;
        }
        
        const messageToShare = ctx.message.reply_to_message.text || ctx.message.reply_to_message.caption;
        if (!messageToShare) {
          await ctx.reply('Pesan yang ingin dishare harus mengandung teks!');
          return;
        }
        
        let sharedCount = 0;
        for (const group of userGroups) {
          try {
            await bot.telegram.sendMessage(group.id, messageToShare);
            sharedCount++;
          } catch (error) {
            console.error(`Gagal mengirim pesan ke grup ${group.id}:`, error.message);
          }
        }
        
        if (sharedCount > 0) {
          await ctx.reply(`Pesan berhasil dishare ke ${sharedCount} grup!`);
          
          // Tambahkan premium 3 hari jika berhasil share ke 3 grup
          if (sharedCount >= 3) {
            await addPremium(userId, 3);
            await ctx.reply('Anda mendapatkan premium 3 hari!');
          }
        } else {
          await ctx.reply('Gagal membagikan pesan ke grup manapun.');
        }
        break;
        
      case '/sharevip':
        if (!isPrivate) {
          await ctx.reply('Command ini hanya bisa digunakan di private chat!');
          return;
        }
        
        const isUserPremium = await checkPremium(userId);
        if (!isUserPremium) {
          await ctx.reply('Anda harus premium untuk menggunakan fitur Share VIP!');
          return;
        }
        
        if (!ctx.message.reply_to_message) {
          await ctx.reply('Silakan reply pesan yang ingin dishare!');
          return;
        }
        
        const vipMessageToShare = ctx.message.reply_to_message.text || ctx.message.reply_to_message.caption;
        if (!vipMessageToShare) {
          await ctx.reply('Pesan yang ingin dishare harus mengandung teks!');
          return;
        }
        
        const allGroups = await getActiveGroups();
        let vipSharedCount = 0;
        
        for (const group of allGroups) {
          try {
            await bot.telegram.sendMessage(group.id, `[VIP] ${vipMessageToShare}`);
            vipSharedCount++;
          } catch (error) {
            console.error(`Gagal mengirim pesan VIP ke grup ${group.id}:`, error.message);
          }
        }
        
        await ctx.reply(`Pesan VIP berhasil dishare ke ${vipSharedCount} grup!`);
        break;
        
      case '/addprem':
        if (!isCreator) {
          await ctx.reply('Akses ditolak! Hanya owner yang bisa menggunakan command ini.');
          return;
        }
        
        const parts = text.split(' ');
        if (parts.length < 3) {
          await ctx.reply('Format: /addprem userID hari');
          return;
        }
        
        const targetUser = parseInt(parts[1]);
        const daysToAdd = parseInt(parts[2]);
        
        if (isNaN(targetUser) || isNaN(daysToAdd)) {
          await ctx.reply('UserID dan hari harus berupa angka!');
          return;
        }
        
        await addPremium(targetUser, daysToAdd);
        await ctx.reply(`Premium berhasil ditambahkan untuk user ${targetUser} selama ${daysToAdd} hari.`);
        break;
        
      case '/delprem':
        if (!isCreator) {
          await ctx.reply('Akses ditolak! Hanya owner yang bisa menggunakan command ini.');
          return;
        }
        
        const userIdToRemove = parseInt(text.split(' ')[1]);
        if (isNaN(userIdToRemove)) {
          await ctx.reply('Format: /delprem userID');
          return;
        }
        
        await removePremium(userIdToRemove);
        await ctx.reply(`Premium berhasil dihapus untuk user ${userIdToRemove}.`);
        break;
        
      case '/listprem':
        if (!isCreator) {
          await ctx.reply('Akses ditolak! Hanya owner yang bisa menggunakan command ini.');
          return;
        }
        
        const premiumList = await listPremium();
        await ctx.reply(`Daftar pengguna premium:\n${premiumList}`);
        break;
        
      case '/addbl':
        if (!isCreator) {
          await ctx.reply('Akses ditolak! Hanya owner yang bisa menggunakan command ini.');
          return;
        }
        
        const idToBlacklist = text.split(' ')[1];
        if (!idToBlacklist) {
          await ctx.reply('Format: /addbl userID atau username');
          return;
        }
        
        const blType = isNaN(idToBlacklist) ? 'username' : 'id';
        await addBlacklist(idToBlacklist, blType);
        await ctx.reply(`${idToBlacklist} berhasil ditambahkan ke blacklist.`);
        break;
        
      case '/delbl':
        if (!isCreator) {
          await ctx.reply('Akses ditolak! Hanya owner yang bisa menggunakan command ini.');
          return;
        }
        
        const idToRemove = text.split(' ')[1];
        if (!idToRemove) {
          await ctx.reply('Format: /delbl userID atau username');
          return;
        }
        
        await removeBlacklist(idToRemove);
        await ctx.reply(`${idToRemove} berhasil dihapus dari blacklist.`);
        break;
        
      case '/listbl':
        if (!isCreator) {
          await ctx.reply('Akses ditolak! Hanya owner yang bisa menggunakan command ini.');
          return;
        }
        
        const blacklist = await listBlacklist();
        await ctx.reply(`Daftar blacklist:\n${blacklist}`);
        break;
        
      case '/autojasher':
        if (!isCreator) {
          await ctx.reply('Akses ditolak! Hanya owner yang bisa menggunakan command ini.');
          return;
        }
        
        const autoResult = await autoJasher(bot);
        await ctx.reply(autoResult);
        break;
        
      case '/stopautojasher':
        if (!isCreator) {
          await ctx.reply('Akses ditolak! Hanya owner yang bisa menggunakan command ini.');
          return;
        }
        
        const stopResult = stopAutoJasher();
        await ctx.reply(stopResult);
        break;
        
      case '/listgroups':
        if (!isCreator) {
          await ctx.reply('Akses ditolak! Hanya owner yang bisa menggunakan command ini.');
          return;
        }
        
        const groups = await getActiveGroups();
        const groupList = groups.map(g => `${g.name} (${g.id})`).join('\n');
        await ctx.reply(`Daftar grup aktif:\n${groupList}`);
        break;
        
      case '/tourl':
        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.photo) {
          await ctx.reply('Silakan reply pesan dengan foto untuk mengubahnya menjadi URL!');
          return;
        }
        
        try {
          const photo = ctx.message.reply_to_message.photo[0];
          const fileId = photo.file_id;
          const file = await ctx.telegram.getFile(fileId);
          const fileUrl = `https://api.telegram.org/file/bot${global.BOT_TOKEN}/${file.file_path}`;
          
          await ctx.reply(`URL foto: ${fileUrl}`);
        } catch (error) {
          await ctx.reply('Gagal mendapatkan URL foto: ' + error.message);
        }
        break;
        
      case '/stats':
        if (!isCreator) {
          await ctx.reply('Akses ditolak! Hanya owner yang bisa menggunakan command ini.');
          return;
        }
        
        const stats = await getStats();
        await ctx.reply(`Statistik Bot:\nTotal Users: ${stats.totalUsers}\nPremium Users: ${stats.premiumUsers}\nTotal Groups: ${stats.totalGroups}`);
        break;
        
      default:
        // Handle obfuscation commands
        if (text.startsWith('/obf')) {
          await handleObfCommands(ctx, text);
        } else {
          await ctx.reply('Command tidak dikenali. Gunakan /start untuk melihat menu.');
        }
    }
  }
}

module.exports = {
  handleMessage
};