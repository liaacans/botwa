/*
*Dibuat oleh aulia rahman
*Ditambahkan fitur fiturnya oleh ginaa septiana ramadhani
Base Ori Rahman x Gina septiana ramadhani

Sosmed media :
Ig : @4xglrs_
Tele : @ginaabaikhati
Wa : Privet
Yt : A. Aulia Rahman Official (@auliarhmanproduction)

Thanks too::
Allah swt
Nabi Muhammad
Ortu
Aulia Rahman
Ginaa septiana ramadhani
And Pengguna Copy/Paste:v

Note : don't remove copyright of this script!



Eh jangan lupa ini diganti yaawww🌹 dibagian src/commands
// Ganti ini:
const obfuscated = await JsConfuser.obfuscate(fileContent, getJapanObfuscationConfig());

// Menjadi ini:
const obfuscatedCode = await safeObfuscate(fileContent, getJapanObfuscationConfig(), 'Mandarin');
biar tidak error kalau mau enc / dec disitu ada decode sih:v
*/


global.BOT_TOKEN = "8198305874:AAGhlBEYItkhH2mxD265kLIMXVEcWMiwkMM";
global.DEVELOPER_ID = "8135269613";
global.DEVELOPER_USERNAME = "ginaabaikhati";

// Ekspor untuk penggunaan di file lain
module.exports = {
  BOT_TOKEN: global.BOT_TOKEN,
  DEVELOPER_ID: global.DEVELOPER_ID,
  DEVELOPER_USERNAME: global.DEVELOPER_USERNAME
};