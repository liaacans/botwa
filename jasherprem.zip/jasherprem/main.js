const { Telegraf, session } = require('telegraf');
const { connectDB } = require('./lib/database');
const { 
    handleStart, 
    handleHelp, 
    handleCredit, 
    handleShare, 
    handleShareVip,
    handleAddPrem,
    handleDelPrem,
    handleListPrem,
    handleBroadcast
} = require('./src/commands');
const { 
    handleCallbacks, 
    handleNewChatMembers, 
    handleLeftChatMember 
} = require('./src/handlers');
const { BOT_TOKEN } = require('./config');

// Inisialisasi bot
const bot = new Telegraf(BOT_TOKEN);

// Middleware session
bot.use(session());

// Event ketika bot mulai
bot.start(async (ctx) => {
    await handleStart(ctx);
});

// Command help
bot.help(async (ctx) => {
    await handleHelp(ctx);
});

// Command credit
bot.command('credit', async (ctx) => {
    await handleCredit(ctx);
});

// Command share
bot.command('share', async (ctx) => {
    await handleShare(ctx);
});

// Command sharevip
bot.command('sharevip', async (ctx) => {
    await handleShareVip(ctx);
});

// Command addprem (hanya owner)
bot.command('addprem', async (ctx) => {
    await handleAddPrem(ctx);
});

// Command delprem (hanya owner)
bot.command('delprem', async (ctx) => {
    await handleDelPrem(ctx);
});

// Command listprem (hanya owner)
bot.command('listprem', async (ctx) => {
    await handleListPrem(ctx);
});

// Command broadcast (hanya owner)
bot.command('broadcast', async (ctx) => {
    await handleBroadcast(ctx);
});

// Handle callback queries
bot.on('callback_query', async (ctx) => {
    await handleCallbacks(ctx);
});

// Handle ketika bot ditambahkan ke group
bot.on('new_chat_members', async (ctx) => {
    await handleNewChatMembers(ctx);
});

// Handle ketika bot dikeluarkan dari group
bot.on('left_chat_member', async (ctx) => {
    await handleLeftChatMember(ctx);
});

// Handle errors
bot.catch((err, ctx) => {
    console.error(`Error for ${ctx.updateType}:`, err);
    ctx.reply('Terjadi kesalahan, silakan coba lagi.');
});

// Jalankan bot
async function startBot() {
    try {
        // Koneksi ke database
        await connectDB();
        console.log('Database connected');
        
        // Jalankan bot
        await bot.launch();
        console.log('Bot started successfully');
        
        // Enable graceful stop
        process.once('SIGINT', () => bot.stop('SIGINT'));
        process.once('SIGTERM', () => bot.stop('SIGTERM'));
    } catch (error) {
        console.error('Failed to start bot:', error);
        process.exit(1);
    }
}

startBot();