// Obfuscation configurations for different encryption types

function getTimeLockedObfuscationConfig(days) {
  const unlockDate = new Date();
  unlockDate.setDate(unlockDate.getDate() + days);
  
  return {
    target: 'node',
    lock: {
      lockType: 'date',
      date: unlockDate.getTime()
    },
    preset: 'high'
  };
}

function getQuantumObfuscationConfig() {
  return {
    target: 'node',
    stringEncoding: 'base64',
    stringArray: true,
    stringArrayThreshold: 1,
    stringArrayEncoding: ['rc4'],
    stringArrayWrappersCount: 5,
    stringArrayWrappersChainedCalls: true,
    stringArrayWrappersParametersMaxCount: 5,
    stringArrayWrappersType: 'function',
    stringArrayIndexesType: 'hexadecimal-number',
    stringArrayIndexesShift: true,
    transformObjectKeys: true,
    numbersToExpressions: true,
    simplify: true,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 1,
    deadCodeInjection: true,
    deadCodeInjectionThreshold: 1,
    debugProtection: true,
    debugProtectionInterval: 4000,
    disableConsoleOutput: true,
    domainLock: ['localhost'],
    reservedNames: ['^_$'],
    reservedStrings: ['\\w+'],
    selfDefending: true,
    splitStrings: true,
    splitStringsChunkLength: 10
  };
}

function getSiuCalcrickObfuscationConfig() {
  return {
    target: 'node',
    stringEncoding: 'base64',
    stringArray: true,
    stringArrayThreshold: 1,
    stringArrayEncoding: ['rc4'],
    stringArrayWrappersCount: 3,
    stringArrayWrappersChainedCalls: true,
    stringArrayWrappersParametersMaxCount: 3,
    stringArrayWrappersType: 'function',
    stringArrayIndexesType: 'hexadecimal-number',
    stringArrayIndexesShift: true,
    transformObjectKeys: true,
    numbersToExpressions: true,
    simplify: true,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 0.75,
    deadCodeInjection: true,
    deadCodeInjectionThreshold: 0.4,
    debugProtection: false,
    disableConsoleOutput: true,
    domainLock: ['localhost'],
    reservedNames: ['^_$'],
    reservedStrings: ['\\w+'],
    selfDefending: true,
    splitStrings: true,
    splitStringsChunkLength: 5
  };
}

function getCustomObfuscationConfig(customString) {
  return {
    target: 'node',
    stringEncoding: 'base64',
    stringArray: true,
    stringArrayThreshold: 1,
    stringArrayEncoding: ['rc4'],
    stringArrayWrappersCount: 2,
    stringArrayWrappersChainedCalls: true,
    stringArrayWrappersParametersMaxCount: 2,
    stringArrayWrappersType: 'function',
    stringArrayIndexesType: 'hexadecimal-number',
    stringArrayIndexesShift: true,
    transformObjectKeys: true,
    numbersToExpressions: true,
    simplify: true,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 0.5,
    deadCodeInjection: true,
    deadCodeInjectionThreshold: 0.3,
    debugProtection: false,
    disableConsoleOutput: true,
    domainLock: ['localhost'],
    identifierNamesGenerator: 'mangled',
    identifiersPrefix: customString,
    reservedNames: ['^_$'],
    reservedStrings: ['\\w+'],
    selfDefending: true,
    splitStrings: true,
    splitStringsChunkLength: 3
  };
}

function getNebulaObfuscationConfig() {
  return {
    target: 'node',
    stringEncoding: 'base64',
    stringArray: true,
    stringArrayThreshold: 1,
    stringArrayEncoding: ['rc4'],
    stringArrayWrappersCount: 4,
    stringArrayWrappersChainedCalls: true,
    stringArrayWrappersParametersMaxCount: 4,
    stringArrayWrappersType: 'function',
    stringArrayIndexesType: 'hexadecimal-number',
    stringArrayIndexesShift: true,
    transformObjectKeys: true,
    numbersToExpressions: true,
    simplify: true,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 0.8,
    deadCodeInjection: true,
    deadCodeInjectionThreshold: 0.5,
    debugProtection: true,
    debugProtectionInterval: 3000,
    disableConsoleOutput: true,
    domainLock: ['localhost'],
    reservedNames: ['^_$'],
    reservedStrings: ['\\w+'],
    selfDefending: true,
    splitStrings: true,
    splitStringsChunkLength: 8
  };
}

function getNovaObfuscationConfig() {
  return {
    target: 'node',
    stringEncoding: 'base64',
    stringArray: true,
    stringArrayThreshold: 1,
    stringArrayEncoding: ['rc4'],
    stringArrayWrappersCount: 3,
    stringArrayWrappersChainedCalls: true,
    stringArrayWrappersParametersMaxCount: 3,
    stringArrayWrappersType: 'function',
    stringArrayIndexesType: 'hexadecimal-number',
    stringArrayIndexesShift: true,
    transformObjectKeys: true,
    numbersToExpressions: true,
    simplify: true,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 0.7,
    deadCodeInjection: true,
    deadCodeInjectionThreshold: 0.4,
    debugProtection: false,
    disableConsoleOutput: true,
    domainLock: ['localhost'],
    reservedNames: ['^_$'],
    reservedStrings: ['\\w+'],
    selfDefending: true,
    splitStrings: true,
    splitStringsChunkLength: 6
  };
}

function getStrongObfuscationConfig() {
  return {
    target: 'node',
    stringEncoding: 'base64',
    stringArray: true,
    stringArrayThreshold: 1,
    stringArrayEncoding: ['rc4'],
    stringArrayWrappersCount: 5,
    stringArrayWrappersChainedCalls: true,
    stringArrayWrappersParametersMaxCount: 5,
    stringArrayWrappersType: 'function',
    stringArrayIndexesType: 'hexadecimal-number',
    stringArrayIndexesShift: true,
    transformObjectKeys: true,
    numbersToExpressions: true,
    simplify: true,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 1,
    deadCodeInjection: true,
    deadCodeInjectionThreshold: 0.6,
    debugProtection: true,
    debugProtectionInterval: 5000,
    disableConsoleOutput: true,
    domainLock: ['localhost'],
    reservedNames: ['^_$'],
    reservedStrings: ['\\w+'],
    selfDefending: true,
    splitStrings: true,
    splitStringsChunkLength: 12
  };
}

function getArabObfuscationConfig() {
  return {
    target: 'node',
    stringEncoding: 'base64',
    stringArray: true,
    stringArrayThreshold: 1,
    stringArrayEncoding: ['rc4'],
    stringArrayWrappersCount: 2,
    stringArrayWrappersChainedCalls: true,
    stringArrayWrappersParametersMaxCount: 2,
    stringArrayWrappersType: 'function',
    stringArrayIndexesType: 'hexadecimal-number',
    stringArrayIndexesShift: true,
    transformObjectKeys: true,
    numbersToExpressions: true,
    simplify: true,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 0.6,
    deadCodeInjection: true,
    deadCodeInjectionThreshold: 0.3,
    debugProtection: false,
    disableConsoleOutput: true,
    domainLock: ['localhost'],
    identifierNamesGenerator: 'mangled',
    identifiersPrefix: 'arab_',
    reservedNames: ['^_$'],
    reservedStrings: ['\\w+'],
    selfDefending: true,
    splitStrings: true,
    splitStringsChunkLength: 4
  };
}

function getJapanxArabObfuscationConfig() {
  return {
    target: 'node',
    stringEncoding: 'base64',
    stringArray: true,
    stringArrayThreshold: 1,
    stringArrayEncoding: ['rc4'],
    stringArrayWrappersCount: 3,
    stringArrayWrappersChainedCalls: true,
    stringArrayWrappersParametersMaxCount: 3,
    stringArrayWrappersType: 'function',
    stringArrayIndexesType: 'hexadecimal-number',
    stringArrayIndexesShift: true,
    transformObjectKeys: true,
    numbersToExpressions: true,
    simplify: true,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 0.7,
    deadCodeInjection: true,
    deadCodeInjectionThreshold: 0.4,
    debugProtection: false,
    disableConsoleOutput: true,
    domainLock: ['localhost'],
    identifierNamesGenerator: 'mangled',
    identifiersPrefix: 'japan_arab_',
    reservedNames: ['^_$'],
    reservedStrings: ['\\w+'],
    selfDefending: true,
    splitStrings: true,
    splitStringsChunkLength: 5
  };
}

function getJapanObfuscationConfig() {
  return {
    target: 'node',
    stringEncoding: 'base64',
    stringArray: true,
    stringArrayThreshold: 1,
    stringArrayEncoding: ['rc4'],
    stringArrayWrappersCount: 2,
    stringArrayWrappersChainedCalls: true,
    stringArrayWrappersParametersMaxCount: 2,
    stringArrayWrappersType: 'function',
    stringArrayIndexesType: 'hexadecimal-number',
    stringArrayIndexesShift: true,
    transformObjectKeys: true,
    numbersToExpressions: true,
    simplify: true,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 0.5,
    deadCodeInjection: true,
    deadCodeInjectionThreshold: 0.2,
    debugProtection: false,
    disableConsoleOutput: true,
    domainLock: ['localhost'],
    identifierNamesGenerator: 'mangled',
    identifiersPrefix: 'japan_',
    reservedNames: ['^_$'],
    reservedStrings: ['\\w+'],
    selfDefending: true,
    splitStrings: true,
    splitStringsChunkLength: 3
  };
}

// Obfuscate with time-locked encryption
async function obfuscateTimeLocked(code, days) {
  const config = getTimeLockedObfuscationConfig(days);
  return await global.JsConfuser.obfuscate(code, config);
}

// Obfuscate with quantum vortex encryption
async function obfuscateQuantum(code) {
  const config = getQuantumObfuscationConfig();
  return await global.JsConfuser.obfuscate(code, config);
}

module.exports = {
  getTimeLockedObfuscationConfig,
  getQuantumObfuscationConfig,
  getSiuCalcrickObfuscationConfig,
  getCustomObfuscationConfig,
  getNebulaObfuscationConfig,
  getNovaObfuscationConfig,
  getStrongObfuscationConfig,
  getArabObfuscationConfig,
  getJapanxArabObfuscationConfig,
  getJapanObfuscationConfig,
  obfuscateTimeLocked,
  obfuscateQuantum
};