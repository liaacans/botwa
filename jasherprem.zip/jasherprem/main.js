const { Telegraf, session } = require('telegraf');
const { connectDB } = require('./lib/database');
const commands = require('./src/commands');
const handlers = require('./src/handlers');

// Connect to database
connectDB();

// Initialize bot
const bot = new Telegraf(global.BOT_TOKEN);

// Middleware
bot.use(session());

// Command handlers
bot.command('start', commands.handleStart);
bot.command('help', commands.handleHelp);
bot.command('credit', commands.handleCredit);
bot.command('share', commands.handleShare);
bot.command('addprem', commands.handleAddPrem);
bot.command('delprem', commands.handleDelPrem);
bot.command('listprem', commands.handleListPrem);
bot.command('bc', commands.handleBroadcast);

// Event handlers
bot.on('callback_query', handlers.handleCallbackQuery);
bot.on('new_chat_members', handlers.handleNewChatMembers);

// Error handling
bot.catch((err, ctx) => {
  console.error(`Error for ${ctx.updateType}:`, err);
  ctx.reply('Terjadi kesalahan, silakan coba lagi.');
});

// Start bot
bot.launch().then(() => {
  console.log('Bot Jasher started successfully');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));