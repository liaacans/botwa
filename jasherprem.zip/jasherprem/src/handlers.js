const { Markup } = require('telegraf');
const { User, Group } = require('../lib/database');
const { escapeHtml, runtime, moment } = require('./utils');
const config = require('../config');

async function handleStart(ctx) {
    const sender = ctx.from;
    const userTele = sender.username ? `@${sender.username}` : `${sender.first_name}${sender.last_name ? ` ${sender.last_name}` : ''}`;
    
    try {
        let user = await User.findOne({ userId: sender.id });
        const isCreator = sender.id.toString() === config.CREATOR_ID;
        
        if (!user) {
            user = new User({
                userId: sender.id,
                username: sender.username,
                firstName: sender.first_name,
                lastName: sender.last_name,
                isCreator: isCreator,
                credits: isCreator ? 9999 : 0
            });
            await user.save();
        }
        
        const groups = await Group.find({ addedBy: sender.id });
        const groupCount = groups.length;
        
        // Jika user belum memenuhi syarat group tapi sudah ada di database
        if (!user.isPremium && groupCount >= config.GROUP_REQUIREMENT) {
            user.isPremium = true;
            user.credits += config.INITIAL_CREDITS;
            await user.save();
        }
        
        const message = `
Hi kak <b>${escapeHtml(userTele)}</b>
╭─❒ 「 User Info 」 
├ Creator : <b>${escapeHtml(userTele)}</b>
├ Name : <b>${escapeHtml(userTele)}</b>
├ Profile : <b>${escapeHtml(userTele)}</b>
├ ID Telegram Anda: <b>${sender.id}</b>
├ Hostname : Linux
├ Platform : Bot Telegram
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : <b>${isCreator ? 'True' : 'False'}</b>
╭─❒ 「 Status 」 
├ Premium : <b>${user.isPremium ? 'Yes' : 'No'}</b>
├ Groups Added : <b>${groupCount}/${config.GROUP_REQUIREMENT}</b>
├ Credits : <b>${user.credits}</b>
╰❒

Silahkan pilih menu dibawah ini!`;

        const keyboard = Markup.inlineKeyboard([
            [
                Markup.button.callback('Jasher Menu', 'jasher_menu'),
                Markup.button.callback('Owner Menu', 'owner_menu')
            ],
            [
                Markup.button.callback('Add Group', 'add_group'),
                Markup.button.callback('Kembali', 'back_menu')
            ]
        ]);

        if (ctx.updateType === 'callback_query') {
            await ctx.editMessageText(message, { 
                parse_mode: 'HTML',
                ...keyboard 
            });
        } else {
            await ctx.replyWithHTML(message, keyboard);
        }
    } catch (error) {
        console.error('Error in start handler:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleJasherMenu(ctx) {
    const sender = ctx.from;
    const user = await User.findOne({ userId: sender.id });
    
    if (!user || !user.isPremium) {
        return await ctx.reply('Anda harus menjadi premium user untuk mengakses menu ini. Tambahkan bot ke 3 group terlebih dahulu.');
    }
    
    const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('Share Broadcast', 'share_broadcast')],
        [Markup.button.callback('Share VIP', 'share_vip')],
        [Markup.button.callback('Cek Credit', 'check_credit')],
        [Markup.button.callback('Kembali', 'back_menu')]
    ]);
    
    await ctx.editMessageText(
        `╭─❒ 「 Jasher Menu 」 
├ Fitur Share Broadcast
├ Fitur Share VIP
├ Cek Credit
╰❒

Pilih opsi di bawah:`,
        { parse_mode: 'HTML', ...keyboard }
    );
}

async function handleOwnerMenu(ctx) {
    const sender = ctx.from;
    const isCreator = sender.id.toString() === config.CREATOR_ID;
    
    if (!isCreator) {
        return await ctx.reply('Anda bukan owner bot!');
    }
    
    const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('Broadcast to All', 'broadcast_all')],
        [Markup.button.callback('Add Premium', 'add_premium')],
        [Markup.button.callback('Remove Premium', 'remove_premium')],
        [Markup.button.callback('List Premium', 'list_premium')],
        [Markup.button.callback('Kembali', 'back_menu')]
    ]);
    
    await ctx.editMessageText(
        `╭─❒ 「 Owner Menu 」 
├ Broadcast ke semua user
├ Kelola user premium
╰❒

Pilih opsi di bawah:`,
        { parse_mode: 'HTML', ...keyboard }
    );
}

async function handleAddGroup(ctx) {
    try {
        const chat = ctx.chat;
        
        // Hanya bisa dijalankan di group
        if (chat.type === 'private') {
            return await ctx.reply('Perintah ini hanya bisa digunakan di dalam group!');
        }
        
        const sender = ctx.from;
        const user = await User.findOne({ userId: sender.id });
        
        // Cek apakah group sudah terdaftar
        const existingGroup = await Group.findOne({ groupId: chat.id });
        if (existingGroup) {
            return await ctx.reply('Group ini sudah terdaftar sebelumnya.');
        }
        
        // Tambahkan group ke database
        const newGroup = new Group({
            groupId: chat.id,
            title: chat.title,
            addedBy: sender.id
        });
        await newGroup.save();
        
        // Tambahkan group ke user's groups
        user.groups.push({
            groupId: chat.id,
            groupTitle: chat.title
        });
        
        // Cek apakah user sudah memenuhi syarat group untuk menjadi premium
        const userGroups = await Group.find({ addedBy: sender.id });
        if (userGroups.length >= config.GROUP_REQUIREMENT && !user.isPremium) {
            user.isPremium = true;
            user.credits += config.INITIAL_CREDITS;
            await ctx.reply(`Selamat! Anda telah menambahkan ${config.GROUP_REQUIREMENT} group dan mendapatkan ${config.INITIAL_CREDITS} kredit.`);
        }
        
        await user.save();
        
        await ctx.reply(`Group "${chat.title}" berhasil ditambahkan!`);
    } catch (error) {
        console.error('Error adding group:', error);
        await ctx.reply('Terjadi kesalahan saat menambahkan group.');
    }
}

async function handleShareBroadcast(ctx) {
    const sender = ctx.from;
    const user = await User.findOne({ userId: sender.id });
    
    if (!user || !user.isPremium) {
        return await ctx.reply('Anda harus menjadi premium user untuk menggunakan fitur ini.');
    }
    
    if (ctx.chat.type !== 'private') {
        return await ctx.reply('Fitur share hanya bisa digunakan di private chat!');
    }
    
    if (user.credits < config.SHARE_COST) {
        return await ctx.reply(`Kredit Anda tidak cukup. Diperlukan ${config.SHARE_COST} kredit untuk share broadcast.`);
    }
    
    // Meminta pesan untuk dibroadcast
    await ctx.reply('Silakan kirim pesan yang ingin Anda broadcast ke group:');
    ctx.session = { waitingForBroadcast: true, type: 'regular' };
}

async function handleShareVip(ctx) {
    const sender = ctx.from;
    const user = await User.findOne({ userId: sender.id });
    
    if (!user || !user.isPremium) {
        return await ctx.reply('Anda harus menjadi premium user untuk menggunakan fitur ini.');
    }
    
    if (ctx.chat.type !== 'private') {
        return await ctx.reply('Fitur share hanya bisa digunakan di private chat!');
    }
    
    if (user.credits < config.PREMIUM_SHARE_COST) {
        return await ctx.reply(`Kredit Anda tidak cukup. Diperlukan ${config.PREMIUM_SHARE_COST} kredit untuk share VIP.`);
    }
    
    // Meminta pesan untuk dibroadcast VIP
    await ctx.reply('Silakan kirim pesan yang ingin Anda broadcast VIP ke group:');
    ctx.session = { waitingForBroadcast: true, type: 'vip' };
}

async function handleBroadcastMessage(ctx) {
    if (!ctx.session.waitingForBroadcast) return;
    
    const sender = ctx.from;
    const user = await User.findOne({ userId: sender.id });
    const message = ctx.message.text || ctx.message.caption;
    const hasMedia = ctx.message.photo || ctx.message.video || ctx.message.document;
    
    if (!message && !hasMedia) {
        return await ctx.reply('Pesan tidak valid. Silakan coba lagi.');
    }
    
    const groups = await Group.find({ addedBy: sender.id });
    if (groups.length === 0) {
        return await ctx.reply('Anda belum menambahkan bot ke group manapun.');
    }
    
    const cost = ctx.session.type === 'vip' ? config.PREMIUM_SHARE_COST : config.SHARE_COST;
    
    // Kurangi kredit user
    user.credits -= cost;
    await user.save();
    
    // Broadcast ke semua group user
    let successCount = 0;
    for (const group of groups) {
        try {
            if (hasMedia) {
                if (ctx.message.photo) {
                    await ctx.telegram.sendPhoto(group.groupId, ctx.message.photo[ctx.message.photo.length - 1].file_id, {
                        caption: message,
                        parse_mode: 'HTML'
                    });
                } else if (ctx.message.video) {
                    await ctx.telegram.sendVideo(group.groupId, ctx.message.video.file_id, {
                        caption: message,
                        parse_mode: 'HTML'
                    });
                } else if (ctx.message.document) {
                    await ctx.telegram.sendDocument(group.groupId, ctx.message.document.file_id, {
                        caption: message,
                        parse_mode: 'HTML'
                    });
                }
            } else {
                await ctx.telegram.sendMessage(group.groupId, message, {
                    parse_mode: 'HTML'
                });
            }
            successCount++;
        } catch (error) {
            console.error(`Error broadcasting to group ${group.groupId}:`, error);
        }
    }
    
    // Reset session
    ctx.session = {};
    
    await ctx.reply(`Broadcast berhasil dikirim ke ${successCount} group. Kredit berkurang ${cost}. Sisa kredit: ${user.credits}`);
}

async function handleCheckCredit(ctx) {
    const sender = ctx.from;
    const user = await User.findOne({ userId: sender.id });
    
    if (!user) {
        return await ctx.reply('User tidak ditemukan.');
    }
    
    await ctx.reply(`Sisa kredit Anda: ${user.credits}`);
}

// Owner functions
async function handleBroadcastToAll(ctx) {
    const sender = ctx.from;
    const isCreator = sender.id.toString() === config.CREATOR_ID;
    
    if (!isCreator) {
        return await ctx.reply('Anda bukan owner bot!');
    }
    
    await ctx.reply('Silakan kirim pesan yang ingin Anda broadcast ke semua user:');
    ctx.session = { waitingForOwnerBroadcast: true };
}

async function handleOwnerBroadcast(ctx) {
    if (!ctx.session.waitingForOwnerBroadcast) return;
    
    const sender = ctx.from;
    const message = ctx.message.text || ctx.message.caption;
    const hasMedia = ctx.message.photo || ctx.message.video || ctx.message.document;
    
    if (!message && !hasMedia) {
        return await ctx.reply('Pesan tidak valid. Silakan coba lagi.');
    }
    
    const users = await User.find({});
    let successCount = 0;
    
    for (const user of users) {
        try {
            if (hasMedia) {
                if (ctx.message.photo) {
                    await ctx.telegram.sendPhoto(user.userId, ctx.message.photo[ctx.message.photo.length - 1].file_id, {
                        caption: message,
                        parse_mode: 'HTML'
                    });
                } else if (ctx.message.video) {
                    await ctx.telegram.sendVideo(user.userId, ctx.message.video.file_id, {
                        caption: message,
                        parse_mode: 'HTML'
                    });
                } else if (ctx.message.document) {
                    await ctx.telegram.sendDocument(user.userId, ctx.message.document.file_id, {
                        caption: message,
                        parse_mode: 'HTML'
                    });
                }
            } else {
                await ctx.telegram.sendMessage(user.userId, message, {
                    parse_mode: 'HTML'
                });
            }
            successCount++;
        } catch (error) {
            console.error(`Error broadcasting to user ${user.userId}:`, error);
        }
    }
    
    // Reset session
    ctx.session = {};
    
    await ctx.reply(`Broadcast berhasil dikirim ke ${successCount} user.`);
}

async function handleAddPremium(ctx) {
    const sender = ctx.from;
    const isCreator = sender.id.toString() === config.CREATOR_ID;
    
    if (!isCreator) {
        return await ctx.reply('Anda bukan owner bot!');
    }
    
    await ctx.reply('Silakan reply pesan ini dengan username/user ID yang ingin ditambahkan sebagai premium:');
    ctx.session = { waitingForPremiumAdd: true };
}

async function handleAddPremiumUser(ctx) {
    if (!ctx.session.waitingForPremiumAdd) return;
    
    const target = ctx.message.text;
    let user;
    
    if (target.startsWith('@')) {
        user = await User.findOne({ username: target.substring(1) });
    } else if (!isNaN(target)) {
        user = await User.findOne({ userId: parseInt(target) });
    }
    
    if (!user) {
        ctx.session = {};
        return await ctx.reply('User tidak ditemukan.');
    }
    
    user.isPremium = true;
    user.credits += config.INITIAL_CREDITS;
    await user.save();
    
    ctx.session = {};
    await ctx.reply(`User ${user.username ? '@' + user.username : user.userId} berhasil ditambahkan sebagai premium dan mendapatkan ${config.INITIAL_CREDITS} kredit.`);
}

async function handleRemovePremium(ctx) {
    const sender = ctx.from;
    const isCreator = sender.id.toString() === config.CREATOR_ID;
    
    if (!isCreator) {
        return await ctx.reply('Anda bukan owner bot!');
    }
    
    await ctx.reply('Silakan reply pesan ini dengan username/user ID yang ingin dihapus dari premium:');
    ctx.session = { waitingForPremiumRemove: true };
}

async function handleRemovePremiumUser(ctx) {
    if (!ctx.session.waitingForPremiumRemove) return;
    
    const target = ctx.message.text;
    let user;
    
    if (target.startsWith('@')) {
        user = await User.findOne({ username: target.substring(1) });
    } else if (!isNaN(target)) {
        user = await User.findOne({ userId: parseInt(target) });
    }
    
    if (!user) {
        ctx.session = {};
        return await ctx.reply('User tidak ditemukan.');
    }
    
    user.isPremium = false;
    await user.save();
    
    ctx.session = {};
    await ctx.reply(`User ${user.username ? '@' + user.username : user.userId} berhasil dihapus dari premium.`);
}

async function handleListPremium(ctx) {
    const sender = ctx.from;
    const isCreator = sender.id.toString() === config.CREATOR_ID;
    
    if (!isCreator) {
        return await ctx.reply('Anda bukan owner bot!');
    }
    
    const premiumUsers = await User.find({ isPremium: true });
    
    if (premiumUsers.length === 0) {
        return await ctx.reply('Tidak ada user premium.');
    }
    
    let message = 'Daftar User Premium:\n\n';
    premiumUsers.forEach((user, index) => {
        message += `${index + 1}. ${user.username ? '@' + user.username : user.userId} (${user.userId}) - Kredit: ${user.credits}\n`;
    });
    
    await ctx.reply(message);
}

module.exports = {
    handleStart,
    handleJasherMenu,
    handleOwnerMenu,
    handleAddGroup,
    handleShareBroadcast,
    handleShareVip,
    handleBroadcastMessage,
    handleCheckCredit,
    handleBroadcastToAll,
    handleOwnerBroadcast,
    handleAddPremium,
    handleAddPremiumUser,
    handleRemovePremium,
    handleRemovePremiumUser,
    handleListPremium
};