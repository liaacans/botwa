const { Telegraf, Markup } = require('telegraf');
const fs = require('fs-extra');
const path = require('path');
const fetch = require('node-fetch');
const moment = require('moment-timezone');
const JsConfuser = require('js-confuser');
const { 
    updateProgress, log, isPremium, isOwner, 
    runtime, createProgressBar, saveUsers, savePremiumUsers,
    saveGroups, saveBlacklistGroups, saveGroupSettings
} = require('../lib/utils');
const {
    obfuscateTimeLocked,
    obfuscateQuantum,
    getSiuCalcrickObfuscationConfig,
    getCustomObfuscationConfig,
    getNebulaObfuscationConfig,
    getNovaObfuscationConfig,
    getStrongObfuscationConfig,
    getArabObfuscationConfig,
    getJapanxArabObfuscationConfig,
    getJapanObfuscationConfig
} = require('./obf');

// Helper function untuk mendapatkan nama pengguna
function getUsername(user) {
    return user.username ? `@${user.username}` : `${user.first_name}${user.last_name ? ` ${user.last_name}` : ''}`;
}

// Konfigurasi Mandarin (tambahkan ini karena tidak ada di file obf.js)
function getMandarinObfuscationConfig() {
    const generateMandarinName = () => {
        const mandarinChars = ["的", "一", "是", "在", "不", "了", "有", "和", "人", "这", "中", "大", "为", "上", "个", "国", "我", "以", "要", "他", "时", "来", "用", "们", "生", "到", "作", "地", "于", "出", "就", "分", "对", "成", "会", "可", "主", "发", "年", "动", "同", "工", "也", "能", "下", "过", "子", "说", "产", "种", "面", "而", "方", "后", "多", "定", "行", "学", "法", "所", "民", "得", "经", "十", "三", "之", "进", "着", "等", "部", "度", "家", "电", "力", "里", "如", "水", "化", "高", "自", "二", "理", "起", "小", "物", "现", "实", "加", "量", "都", "两", "体", "制", "机", "当", "使", "点", "从", "业", "本", "去", "把", "性", "好", "应", "开", "它", "合", "还", "因", "由", "其", "些", "然", "前", "外", "天", "政", "四", "日", "那", "社", "义", "事", "平", "形", "相", "全", "表", "间", "样", "与", "关", "各", "重", "新", "线", "内", "数", "正", "心", "反", "你", "明", "看", "原", "又", "么", "利", "比", "或", "但", "质", "气", "第", "向", "道", "命", "此", "变", "条", "只", "没", "结", "解", "问", "意", "建", "月", "公", "无", "系", "军", "很", "情", "者", "最", "立", "代", "想", "已", "通", "并", "提", "直", "题", "党", "程", "展", "五", "果", "料", "象", "员", "革", "位", "入", "常", "文", "总", "次", "品", "式", "活", "设", "及", "管", "特", "件", "长", "求", "老", "头", "基", "资", "边", "流", "路", "级", "少", "图", "山", "统", "接", "知", "较", "将", "组", "见", "计", "别", "她", "手", "角", "期", "根", "论", "运", "农", "指", "几", "九", "区", "强", "放", "决", "西", "被", "干", "做", "必", "战", "先", "回", "则", "任", "取", "据", "处", "队", "南", "给", "色", "光", "门", "即", "保", "治", "北", "造", "百", "规", "热", "领", "七", "海", "口", "东", "导", "器", "压", "志", "世", "金", "增", "争", "济", "阶", "油", "思", "术", "极", "交", "受", "联", "什", "认", "六", "共", "权", "收", "证", "改", "清", "美", "再", "采", "转", "更", "单", "风", "切", "打", "白", "教", "速", "花", "带", "安", "场", "身", "车", "例", "真", "务", "具", "万", "每", "目", "至", "达", "走", "积", "示", "议", "声", "报", "斗", "完", "类", "八", "离", "华", "名", "确", "才", "科", "张", "信", "马", "节", "话", "米", "整", "空", "元", "况", "今", "集", "温", "传", "土", "许", "步", "群", "广", "石", "记", "需", "段", "研", "界", "拉", "林", "律", "叫", "且", "究", "观", "越", "织", "装", "影", "算", "低", "持", "音", "众", "书", "布", "复", "容", "儿", "须", "际", "商", "非", "验", "连", "断", "深", "难", "近", "矿", "千", "周", "委", "素", "技", "备", "半", "办", "青", "省", "列", "习", "响", "约", "支", "般", "史", "感", "劳", "便", "团", "往", "酸", "历", "市", "克", "何", "除", "消", "构", "府", "称", "太", "准", "精", "值", "号", "率", "族", "维", "划", "选", "标", "写", "存", "候", "毛", "亲", "快", "效", "斯", "院", "查", "江", "型", "眼", "王", "按", "格", "养", "易", "置", "派", "层", "片", "始", "却", "专", "状", "育", "厂", "京", "识", "适", "属", "圆", "包", "火", "住", "调", "满", "县", "局", "照", "参", "红", "细", "引", "听", "该", "铁", "价", "严", "首", "底", "液", "官", "德", "随", "病", "苏", "失", "尔", "死", "讲", "配", "女", "黄", "推", "显", "谈", "罪", "神", "艺", "呢", "席", "含", "企", "望", "密", "批", "营", "项", "防", "举", "球", "英", "氧", "势", "告", "李", "台", "落", "木", "帮", "轮", "破", "亚", "师", "围", "注", "远", "字", "材", "排", "供", "河", "态", "封", "另", "施", "减", "树", "溶", "怎", "止", "案", "言", "士", "均", "武", "固", "叶", "鱼", "波", "视", "仅", "费", "紧", "爱", "左", "章", "早", "朝", "害", "续", "轻", "服", "试", "食", "充", "兵", "源", "判", "护", "司", "足", "某", "练", "差", "致", "板", "田", "降", "黑", "犯", "负", "击", "范", "继", "兴", "似", "余", "坚", "曲", "输", "修", "故", "城", "夫", "够", "送", "笔", "船", "占", "右", "财", "吃", "富", "春", "职", "觉", "汉", "画", "功", "巴", "跟", "虽", "杂", "飞", "检", "吸", "助", "升", "阳", "互", "初", "创", "抗", "考", "投", "坏", "策", "古", "径", "换", "未", "跑", "留", "钢", "曾", "端", "责", "站", "简", "述", "钱", "副", "尽", "帝", "射", "草", "冲", "承", "独", "令", "限", "阿", "宣", "环", "双", "请", "超", "微", "让", "控", "州", "良", "轴", "找", "否", "纪", "益", "依", "优", "顶", "础", "载", "倒", "房", "突", "坐", "粉", "敌", "略", "客", "袁", "冷", "胜", "绝", "析", "块", "剂", "测", "丝", "协", "诉", "念", "陈", "仍", "罗", "盐", "友", "洋", "错", "苦", "夜", "刑", "移", "频", "逐", "靠", "混", "母", "短", "皮", "终", "聚", "汽", "村", "云", "哪", "既", "距", "卫", "停", "烈", "央", "察", "烧", "迅", "境", "若", "印", "洲", "刻", "括", "激", "孔", "搞", "甚", "室", "待", "核", "校", "散", "侵", "吧", "甲", "游", "久", "菜", "味", "旧", "模", "湖", "货", "损", "预", "阻", "毫", "普", "稳", "乙", "妈", "植", "息", "扩", "银", "语", "挥", "酒", "守", "拿", "序", "纸", "医", "缺", "雨", "吗", "针", "刘", "啊", "急", "唱", "误", "训", "愿", "审", "附", "获", "茶", "鲜", "粮", "斤", "孩", "脱", "硫", "肥", "善", "龙", "演", "父", "渐", "血", "欢", "械", "掌", "歌", "沙", "刚", "攻", "谓", "盾", "讨", "晚", "粒", "乱", "燃", "矛", "乎", "杀", "药", "宁", "鲁", "贵", "钟", "煤", "读", "班", "伯", "香", "介", "迫", "句", "丰", "培", "握", "兰", "担", "弦", "蛋", "沉", "假", "穿", "执", "答", "乐", "谁", "顺", "烟", "缩", "征", "脸", "喜", "松", "脚", "困", "异", "免", "背", "星", "福", "买", "染", "井", "概", "慢", "怕", "磁", "倍", "祖", "皇", "促", "静", "补", "评", "翻", "肉", "践", "尼", "衣", "宽", "扬", "棉", "希", "伤", "操", "垂", "秋", "宜", "氢", "套", "督", "振", "架", "亮", "末", "宪", "庆", "编", "牛", "触", "映", "雷", "销", "诗", "座", "居", "抓", "裂", "胞", "呼", "娘", "景", "威", "绿", "晶", "厚", "盟", "衡", "鸡", "孙", "延", "危", "胶", "屋", "乡", "临", "陆", "顾", "掉", "呀", "灯", "岁", "措", "束", "耐", "剧", "玉", "赵", "跳", "哥", "季", "课", "凯", "胡", "额", "款", "绍", "卷", "齐", "伟", "蒸", "殖", "永", "宗", "苗", "川", "炉", "岩", "弱", "零", "杨", "奏", "沿", "露", "杆", "探", "滑", "镇", "饭", "浓", "航", "怀", "赶", "库", "夺", "伊", "灵", "税", "途", "灭", "赛", "归", "召", "鼓", "播", "盘", "裁", "险", "康", "唯", "录", "菌", "纯", "借", "糖", "盖", "横", "符", "私", "努", "堂", "域", "枪", "润", "幅", "哈", "竟", "熟", "虫", "泽", "脑", "壤", "碳", "欧", "遍", "侧", "寨", "敢", "彻", "虑", "斜", "薄", "庭", "纳", "弹", "饲", "伸", "折", "麦", "湿", "暗", "荷", "瓦", "塞", "床", "筑", "恶", "户", "访", "塔", "奇", "透", "梁", "刀", "旋", "迹", "卡", "氯", "遇", "份", "毒", "泥", "退", "洗", "摆", "灰", "彩", "卖", "耗", "夏", "择", "忙", "铜", "献", "硬", "予", "繁", "圈", "雪", "函", "亦", "抽", "篇", "阵", "阴", "丁", "尺", "追", "堆", "雄", "迎", "泛", "爸", "楼", "避", "谋", "吨", "野", "猪", "旗", "累", "偏", "典", "馆", "索", "秦", "脂", "潮", "爷", "豆", "忽", "托", "惊", "塑", "遗", "愈", "朱", "替", "纤", "粗", "倾", "尚", "痛", "楚", "谢", "奋", "购", "磨", "君", "池", "旁", "碎", "骨", "监", "捕", "弟", "暴", "割", "贯", "殊", "释", "词", "亡", "壁", "顿", "宝", "午", "尘", "闻", "揭", "炮", "残", "冬", "桥", "妇", "警", "综", "招", "吴", "付", "浮", "遭", "徐", "您", "摇", "谷", "赞", "箱", "隔", "订", "男", "吹", "园", "纷", "唐", "败", "宋", "玻", "巨", "耕", "坦", "荣", "闭", "湾", "键", "凡", "驻", "锅", "救", "恩", "剥", "凝", "碱", "齿", "截", "炼", "麻", "纺", "禁", "废", "盛", "版", "缓", "净", "睛", "昌", "婚", "涉", "筒", "嘴", "插", "岸", "朗", "庄", "街", "藏", "姑", "贸", "腐", "奴", "啦", "惯", "乘", "伙", "恢", "匀", "纱", "扎", "辩", "耳", "彪", "臣", "亿", "璃", "抵", "脉", "秀", "萨", "俄", "网", "舞", "店", "喷", "纵", "寸", "汗", "挂", "洪", "贺", "闪", "柬", "爆", "烯", "津", "稻", "墙", "软", "勇", "像", "滚", "厘", "蒙", "芳", "肯", "坡", "柱", "荡", "腿", "仪", "旅", "尾", "轧", "冰", "贡", "登", "黎", "削", "钻", "勒", "逃", "障", "氨", "郭", "峰", "币", "港", "伏", "轨", "亩", "毕", "擦", "莫", "刺", "浪", "秘", "援", "株", "健", "售", "股", "岛", "甘", "泡", "睡", "童", "铸", "汤", "阀", "休", "汇", "舍", "牧", "绕", "炸", "哲", "磷", "绩", "朋", "淡", "尖", "启", "陷", "柴", "呈", "徒", "颜", "泪", "稍", "忘", "泵", "蓝", "拖", "洞", "授", "镜", "辛", "壮", "锋", "贫", "虚", "弯", "摩", "泰", "幼", "廷", "尊", "窗", "纲", "弄", "隶", "疑", "氏", "宫", "姐", "震", "瑞", "怪", "尤", "琴", "循", "描", "膜", "违", "夹", "腰", "缘", "珠", "穷", "森", "枝", "竹", "沟", "催", "绳", "忆", "邦", "剩", "幸", "浆", "栏", "拥", "牙", "贮", "礼", "滤", "钠", "纹", "罢", "拍", "咱", "喊", "袖", "埃", "勤", "罚", "焦", "潜", "伍", "墨", "欲", "缝", "姓", "刊", "饱", "仿", "奖", "铝", "鬼", "丽", "跨", "默", "挖", "链", "扫", "喝", "袋", "炭", "污", "幕", "诸", "弧", "励", "梅", "奶", "洁", "灾", "舟", "鉴", "苯", "讼", "抱", "毁", "懂", "寒", "智", "埔", "寄", "届", "跃", "渡", "挑", "丹", "艰", "贝", "碰", "拔", "爹", "戴", "码", "梦", "芽", "熔", "赤", "渔", "哭", "敬", "颗", "奔", "铅", "仲", "虎", "稀", "妹", "乏", "珍", "申", "桌", "遵", "允", "隆", "螺", "仓", "魏", "锐", "晓", "氮", "兼", "隐", "碍", "赫", "拨", "忠", "肃", "缸", "牵", "抢", "博", "巧", "壳", "兄", "杜", "讯", "诚", "碧", "祥", "柯", "页", "巡", "矩", "悲", "灌", "龄", "伦", "票", "寻", "桂", "铺", "圣", "恐", "恰", "郑", "趣", "抬", "荒", "腾", "贴", "柔", "滴", "猛", "阔", "辆", "妻", "填", "撤", "储", "签", "闹", "扰", "紫", "砂", "递", "戏", "吊", "陶", "伐", "喂", "疗", "瓶", "婆", "抚", "臂", "摸", "忍", "虾", "蜡", "邻", "胸", "巩", "挤", "偶", "弃", "槽", "劲", "乳", "邓", "吉", "仁", "烂", "砖", "租", "乌", "舰", "伴", "瓜", "浅", "丙", "暂", "燥", "橡", "柳", "迷", "暖", "牌", "秧", "胆", "详", "簧", "踏", "瓷", "谱", "呆", "宾", "糊", "洛", "辉", "愤", "竞", "隙", "怒", "粘", "乃", "绪", "肩", "籍", "敏", "涂", "熙", "皆", "侦", "悬", "掘", "享", "纠", "醒", "狂", "锁", "淀", "恨", "牲", "霸", "爬", "赏", "逆", "玩", "陵", "祝", "秒", "浙", "貌", "役", "彼", "悉", "鸭", "趋", "凤", "晨", "畜", "辈", "秩", "卵", "署", "梯", "炎", "滩", "棋", "驱", "筛", "峡", "冒", "啥", "寿", "译", "浸", "泉", "帽", "迟", "硅", "疆", "贷", "漏", "稿", "冠", "嫩", "胁", "芯", "牢", "叛", "蚀", "奥", "鸣", "岭", "羊", "凭", "串", "塘", "绘", "酵", "融", "盆", "锡", "庙", "筹", "冻", "辅", "摄", "袭", "筋", "拒", "僚", "旱", "钾", "鸟", "漆", "沈", "眉", "疏", "添", "棒", "穗", "硝", "韩", "逼", "扭", "侨", "凉", "挺", "碗", "栽", "炒", "杯", "患", "馏", "劝", "豪", "辽", "勃", "鸿", "旦", "吏", "拜", "狗", "埋", "辊", "掩", "饮", "搬", "骂", "辞", "勾", "扣", "估", "蒋", "绒", "雾", "丈", "朵", "姆", "拟", "宇", "辑", "陕", "雕", "偿", "蓄", "崇", "剪", "倡", "厅", "咬", "驶", "薯", "刷", "斥", "番", "赋", "奉", "佛", "浇", "漫", "曼", "扇", "钙", "桃", "扶", "仔", "返", "俗", "亏", "腔", "鞋", "棱", "覆", "框", "悄", "叔", "撞", "骗", "勘", "旺", "沸", "孤", "吐", "孟", "渠", "屈", "疾", "妙", "惜", "仰", "狠", "胀", "谐", "抛", "霉", "桑", "岗", "嘛", "衰", "盗", "渗", "脏", "赖", "涌", "甜", "曹", "阅", "肌", "哩", "厉", "烃", "纬", "毅", "昨", "伪", "症", "煮", "叹", "钉", "搭", "茎", "笼", "酷", "偷", "弓", "锥", "恒", "杰", "坑", "鼻", "翼", "纶", "叙", "狱", "逮", "罐", "络", "棚", "抑", "膨", "蔬", "寺", "骤", "穆", "冶", "枯", "册", "尸", "凸", "绅", "坯", "牺", "焰", "轰", "欣", "晋", "瘦", "御", "锭", "锦", "丧", "旬", "锻", "垄", "搜", "扑", "邀", "亭", "酯", "迈", "舒", "脆", "酶", "闲", "忧", "酚", "顽", "羽", "涨", "卸", "仗", "陪", "辟", "惩", "杭", "姚", "肚", "捉", "飘", "漂", "昆", "欺", "吾", "郎", "烷", "汁", "呵", "饰", "萧", "雅", "邮", "迁", "燕", "撒", "姻", "赴", "宴", "烦", "债", "帐", "斑", "铃", "旨", "醇", "董", "饼", "雏", "姿", "拌", "傅", "腹", "妥", "揉", "贤", "拆", "歪", "葡", "胺", "丢", "浩", "徽", "昂", "垫", "挡", "览", "贪", "慰", "缴", "汪", "慌", "冯", "诺", "姜", "谊", "凶", "劣", "诬", "耀", "昏", "躺", "盈", "骑", "乔", "溪", "丛", "卢", "抹", "易", "闷", "咨", "刮", "驾", "缆", "悟", "摘", "铒", "掷", "颇", "幻", "柄", "惠", "惨", "佳", "仇", "腊", "窝", "涤", "剑", "瞧", "堡", "泼", "葱", "罩", "霍", "捞", "胎", "苍", "滨", "俩", "捅", "湘", "砍", "霞", "邵", "萄", "疯", "淮", "遂", "熊", "粪", "烘", "宿", "档", "戈", "驳", "嫂", "裕", "徙", "箭", "捐", "肠", "撑", "晒", "辨", "殿", "莲", "摊", "搅", "酱", "屏", "疫", "哀", "蔡", "堵", "沫", "皱", "畅", "叠", "阁", "莱", "敲", "辖", "钩", "痕", "坝", "巷", "饿", "祸", "丘", "玄", "溜", "曰", "逻", "彭", "尝", "卿", "妨", "艇", "吞", "韦", "怨", "矮", "歇"];
        const length = Math.floor(Math.random() * 3) + 2;
        let name = "";
        for (let i = 0; i < length; i++) {
            name += mandarinChars[Math.floor(Math.random() * mandarinChars.length)];
        }
        return name;
    };

    return {
        target: "node",
        compact: true,
        renameVariables: true,
        renameGlobals: true,
        identifierGenerator: generateMandarinName,
        stringCompression: true,
        stringEncoding: true,
        stringSplitting: true,
        controlFlowFlattening: 0.9,
        shuffle: true,
        duplicateLiteralsRemoval: true,
        deadCode: true,
        calculator: true,
        opaquePredicates: true,
        lock: {
            selfDefending: true,
            antiDebug: true,
            integrity: true,
            tamperProtection: true,
        },
    };
}

// Main menu command
function setupCommands(bot) {
    // Start command
    bot.start(async (ctx) => {
        const sender = getUsername(ctx.from);
        const isCreator = isOwner(ctx.from.id);
        
        global.users.add(ctx.from.id);
        saveUsers(global.users);
        
        const menuText = `
╭─❒ 「 User Info 」 
├ Owner : ${isCreator ? 'True' : 'False'}
├ Name : ${ctx.from.first_name}${ctx.from.last_name ? ` ${ctx.from.last_name}` : ''}
├ Profile : ${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`;
        
        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('🤖 Jasher Menu', 'jasher_menu')],
            [Markup.button.callback('👑 Owner Menu', 'owner_menu'), Markup.button.callback('🔒 Obf Menu', 'obf_menu')],
            [Markup.button.callback('🔄 Kembali', 'main_menu')]
        ]);
        
        await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
            caption: menuText,
            parse_mode: 'Markdown',
            ...keyboard
        });
    });
    
    // Help command
    bot.help((ctx) => {
        ctx.replyWithMarkdown(`
🤖 *Bantuan Bot Jasher*

*Fitur Utama:*
- 🔒 Obfuscation JavaScript dengan berbagai metode
- 👥 Manajemen grup dengan fitur admin
- 📢 Broadcast pesan ke semua pengguna
- ⭐ Fitur premium untuk pengguna berbayar

*Cara Penggunaan:*
1. Tambahkan bot ke grup Anda
2. Gunakan command /menu untuk melihat menu utama
3. Untuk obfuscation, reply file JS dengan command yang sesuai

*Command yang tersedia:*
/menu - Menu utama bot
/help - Bantuan penggunaan
/about - Tentang bot ini

*Support:*
Jika mengalami kendala, hubungi @ginaabaikhati
        `);
    });
    
    // About command
    bot.command('about', (ctx) => {
        ctx.replyWithMarkdown(`
🤖 *Tentang Bot Jasher*

Bot Jasher adalah bot multifungsi yang dirancang untuk membantu mengelola grup dan melakukan obfuscation JavaScript dengan berbagai metode enkripsi.

*Fitur:*
- 🔒 Multiple Obfuscation Methods
- 👥 Group Management
- 📢 Broadcast System
- ⭐ Premium Features

*Developer:* @ginaabaikhati
*Website:* https://y2beta.web.id
*Version:* 2.0.0
*Update:* ${moment().format('DD MMMM YYYY')}
        `);
    });
    
    // Menu command
    bot.command('menu', async (ctx) => {
        const sender = getUsername(ctx.from);
        const isCreator = isOwner(ctx.from.id);
        
        const menuText = `
╭─❒ 「 User Info 」 
├ Owner : ${isCreator ? 'True' : 'False'}
├ Name : ${ctx.from.first_name}${ctx.from.last_name ? ` ${ctx.from.last_name}` : ''}
├ Profile : ${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`;
        
        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('🤖 Jasher Menu', 'jasher_menu')],
            [Markup.button.callback('👑 Owner Menu', 'owner_menu'), Markup.button.callback('🔒 Obf Menu', 'obf_menu')],
            [Markup.button.callback('🔄 Kembali', 'main_menu')]
        ]);
        
        await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
            caption: menuText,
            parse_mode: 'Markdown',
            ...keyboard
        });
    });

    // enc3 command - Mandarin obfuscation
    bot.command("enc3", async (ctx) => {
        users.add(ctx.from.id);
        saveUsers(users);

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc3`!");
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown(`
╭━━━「 ❌ ERROR 」━━━⬣
│ File harus berekstensi .js!
╰━━━━━━━━━━━━━━━━⬣`);
        }

        const encryptedPath = path.join(__dirname, "../temp", `china-encrypted-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                ` ⚙️ Memulai (Hardened Mandarin) (1%)\n` +
                ` ${createProgressBar(1)}\n` +
                "```\n" +
                "PROSES ENCRYPT "
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk Mandarin obfuscation: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            log(`Memvalidasi kode: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode tidak valid: ${syntaxError.message}`);
            }

            log(`Mengenkripsi file dengan gaya Mandarin yang diperkuat`);
            await updateProgress(
                ctx,
                progressMessage,
                40,
                "Inisialisasi Hardened Mandarin Obfuscation"
            );
            const obfuscated = await JsConfuser.obfuscate(
                fileContent,
                getMandarinObfuscationConfig()
            );
            await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
            await fs.writeFile(encryptedPath, obfuscated.code);
            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

            log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
            try {
                new Function(obfuscated.code);
            } catch (postObfuscationError) {
                throw new Error(
                    `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
                );
            }

            log(`Mengirim file terenkripsi gaya Mandarin: ${file.file_name}`);
            await ctx.replyWithDocument(
                { source: encryptedPath, filename: `china-encrypted-${file.file_name}` },
                {
                    caption: "✅ *File terenkripsi (Hardened Mandarin) siap!*\nSUKSES ENCRYPT 🕊",
                    parse_mode: "Markdown",
                }
            );
            await updateProgress(
                ctx,
                progressMessage,
                100,
                "Hardened Mandarin Obfuscation Selesai"
            );

            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus: ${encryptedPath}`);
            }
        } catch (error) {
            log("Kesalahan saat Mandarin obfuscation", error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
            );
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus setelah error: ${encryptedPath}`);
            }
        }
    });

    // enc4 command - Arab obfuscation
    bot.command("enc4", async (ctx) => {
        users.add(ctx.from.id);
        saveUsers(users);

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc4`!");
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const encryptedPath = path.join(__dirname, "../temp", `arab-encrypted-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                ` ⚙️ Memulai (Hardened Arab) (1%)\n` +
                ` ${createProgressBar(1)}\n` +
                "```\n" +
                "PROSES ENCRYPT"
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk Arab obfuscation: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            log(`Memvalidasi kode: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode tidak valid: ${syntaxError.message}`);
            }

            log(`Mengenkripsi file dengan gaya Arab yang diperkuat`);
            await updateProgress(
                ctx,
                progressMessage,
                40,
                "Inisialisasi Hardened Arab Obfuscation"
            );
            const obfuscated = await JsConfuser.obfuscate(
                fileContent,
                getArabObfuscationConfig()
            );
            await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
            await fs.writeFile(encryptedPath, obfuscated.code);
            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

            log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
            try {
                new Function(obfuscated.code);
            } catch (postObfuscationError) {
                throw new Error(
                    `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
                );
            }

            log(`Mengirim file terenkripsi gaya Arab: ${file.file_name}`);
            await ctx.replyWithDocument(
                { source: encryptedPath, filename: `arab-encrypted-${file.file_name}` },
                {
                    caption: "✅ *File terenkripsi (Hardened Arab) siap!*\nSUKSES ENCRYPT 🕊",
                    parse_mode: "Markdown",
                }
            );
            await updateProgress(
                ctx,
                progressMessage,
                100,
                "Hardened Arab Obfuscation Selesai"
            );

            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus: ${encryptedPath}`);
            }
        } catch (error) {
            log("Kesalahan saat Arab obfuscation", error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
            );
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus setelah error: ${encryptedPath}`);
            }
        }
    });

    // japan command - Japan obfuscation
    bot.command("japan", async (ctx) => {
        users.add(ctx.from.id);
        saveUsers(users);

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/japan`!");
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const encryptedPath = path.join(__dirname, "../temp", `japan-encrypted-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                ` ⚙️ Memulai (Hardened Japan) (1%)\n` +
                ` ${createProgressBar(1)}\n` +
                "```\n" +
                "PROSES ENCRYPT "
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk Japan obfuscation: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            log(`Memvalidasi kode: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode tidak valid: ${syntaxError.message}`);
            }

            log(`Mengenkripsi file dengan gaya Japan yang diperkuat`);
            await updateProgress(
                ctx,
                progressMessage,
                40,
                "Inisialisasi Hardened Japan Obfuscation"
            );
            const obfuscated = await JsConfuser.obfuscate(
                fileContent,
                getJapanObfuscationConfig()
            );
            await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
            await fs.writeFile(encryptedPath, obfuscated.code);
            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

            log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
            try {
                new Function(obfuscated.code);
            } catch (postObfuscationError) {
                throw new Error(
                    `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
                );
            }

            log(`Mengirim file terenkripsi gaya Japan: ${file.file_name}`);
            await ctx.replyWithDocument(
                { source: encryptedPath, filename: `japan-encrypted-${file.file_name}` },
                {
                    caption: "✅ *File terenkripsi (Hardened Japan) siap!*\nSUKSES ENCRYPT 🕊",
                    parse_mode: "Markdown",
                }
            );
            await updateProgress(
                ctx,
                progressMessage,
                100,
                "Hardened Japan Obfuscation Selesai"
            );

            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus: ${encryptedPath}`);
            }
        } catch (error) {
            log("Kesalahan saat Japan obfuscation", error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
            );
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus setelah error: ${encryptedPath}`);
            }
        }
    });

    // deobfuscate command
    bot.command("deobfuscate", async (ctx) => {
        users.add(ctx.from.id);
        saveUsers(users);

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown(
                "❌ *Error:* Balas file .js yang diobfuscate dengan `/deobfuscate`!"
            );
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const deobfuscatedPath = path.join(__dirname, "../temp", `deobfuscated-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                ` ⚙️ Memulai Deobfuscation (1%)\n` +
                ` ${createProgressBar(1)}\n` +
                "```\n" +
                "PROSES ENCRYPT "
            );

            // Mengunduh file
            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk deobfuscation: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            // Validasi kode awal
            log(`Memvalidasi kode awal: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode Awal");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
            }

            // Proses deobfuscation dengan webcrack
            log(`Memulai deobfuscation dengan webcrack: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 40, "Memulai Deobfuscation");
            const result = await webcrack(fileContent); // Pastikan await digunakan
            let deobfuscatedCode = result.code;

            // Penanganan jika kode dibundel
            let bundleInfo = "";
            if (result.bundle) {
                bundleInfo = "// Detected as bundled code (e.g., Webpack/Browserify)\n";
                log(`Kode terdeteksi sebagai bundel: ${file.file_name}`);
            }

            // Jika tidak ada perubahan signifikan atau hasil bukan string
            if (
                !deobfuscatedCode ||
                typeof deobfuscatedCode !== "string" ||
                deobfuscatedCode.trim() === fileContent.trim()
            ) {
                log(
                    `Webcrack tidak dapat mendekode lebih lanjut atau hasil bukan string: ${file.file_name}`
                );
                deobfuscatedCode = `${bundleInfo}// Webcrack tidak dapat mendekode sepenuhnya atau hasil invalid\n${fileContent}`;
            }

            // Validasi kode hasil
            log(`Memvalidasi kode hasil deobfuscation: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 60, "Memvalidasi Kode Hasil");
            let isValid = true;
            try {
                new Function(deobfuscatedCode);
                log(`Kode hasil valid: ${deobfuscatedCode.substring(0, 50)}...`);
            } catch (syntaxError) {
                log(`Kode hasil tidak valid: ${syntaxError.message}`);
                deobfuscatedCode = `${bundleInfo}// Kesalahan validasi: ${syntaxError.message}\n${deobfuscatedCode}`;
                isValid = false;
            }

            // Simpan hasil
            await updateProgress(ctx, progressMessage, 80, "Menyimpan Hasil");
            await fs.writeFile(deobfuscatedPath, deobfuscatedCode);

            // Kirim hasil
            log(`Mengirim file hasil deobfuscation: ${file.file_name}`);
            await ctx.replyWithDocument(
                { source: deobfuscatedPath, filename: `deobfuscated-${file.file_name}` },
                {
                    caption: `✅ *File berhasil dideobfuscate!${isValid ? "" : " (Perhatikan pesan error dalam file)"}*\nSUKSES ENCRYPT 🕊`,
                    parse_mode: "Markdown",
                }
            );
            await updateProgress(ctx, progressMessage, 100, "Deobfuscation Selesai");

            // Hapus file sementara
            if (await fs.pathExists(deobfuscatedPath)) {
                await fs.unlink(deobfuscatedPath);
                log(`File sementara dihapus: ${deobfuscatedPath}`);
            }
        } catch (error) {
            log("Kesalahan saat deobfuscation", error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan file Javascript yang valid!_`
            );
            if (await fs.pathExists(deobfuscatedPath)) {
                await fs.unlink(deobfuscatedPath);
                log(`File sementara dihapus setelah error: ${deobfuscatedPath}`);
            }
        }
    });

    // zenc command - Invisible obfuscation
    bot.command("zenc", async (ctx) => {
        users.add(ctx.from.id);
        saveUsers(users);

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/zenc`!");
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const encryptedPath = path.join(__dirname, "../temp", `invisible-encrypted-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                ` ⚙️ Memulai (InvisiBle) (1%)\n` +
                ` ${createProgressBar(1)}\n` +
                "```\n" +
                "PROSES ENCRYPT "
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk Strong obfuscation: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            log(`Memvalidasi kode awal: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode tidak valid: ${syntaxError.message}`);
            }

            log(`Mengenkripsi file dengan gaya Strong`);
            await updateProgress(
                ctx,
                progressMessage,
                40,
                "Inisialisasi Hardened Invisible Obfuscation"
            );
            const obfuscated = await JsConfuser.obfuscate(
                fileContent,
                getStrongObfuscationConfig()
            );
            let obfuscatedCode = obfuscated.code || obfuscated; // Pastikan string
            if (typeof obfuscatedCode !== "string") {
                throw new Error("Hasil obfuscation bukan string");
            }
            log(
                `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(0, 50)}...`
            );
            await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");

            log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
            try {
                new Function(obfuscatedCode);
            } catch (postObfuscationError) {
                throw new Error(
                    `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
                );
            }

            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
            await fs.writeFile(encryptedPath, obfuscatedCode);

            log(`Mengirim file terenkripsi gaya Invisible: ${file.file_name}`);
            await ctx.replyWithDocument(
                {
                    source: encryptedPath,
                    filename: `Invisible-encrypted-${file.file_name}`,
                },
                {
                    caption: "✅ *File terenkripsi (Invisible) siap!*\nSUKSES ENCRYPT 🕊",
                    parse_mode: "Markdown",
                }
            );
            await updateProgress(
                ctx,
                progressMessage,
                100,
                "Hardened Invisible Obfuscation Selesai"
            );

            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus: ${encryptedPath}`);
            }
        } catch (error) {
            log("Kesalahan saat Invisible obfuscation", error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
            );
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus setelah error: ${encryptedPath}`);
            }
        }
    });

    // xx command - Custom name obfuscation
    bot.command("xx", async (ctx) => {
        users.add(ctx.from.id);
        saveUsers(users);

        // Ambil nama kustom dari perintah
        const args = ctx.message.text.split(" ");
        if (args.length < 2 || !args[1]) {
            return ctx.replyWithMarkdown(
                "❌ *Error:* Gunakan format `/enc <nama>` dengan nama kustom!"
            );
        }
        const customName = args[1].replace(/[^a-zA-Z0-9_]/g, ""); // Sanitasi input, hanya huruf, angka, dan underscore
        if (!customName) {
            return ctx.replyWithMarkdown(
                "❌ *Error:* Nama kustom harus berisi huruf, angka, atau underscore!"
            );
        }

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown(
                "❌ *Error:* Balas file .js dengan `/enc <nama>`!"
            );
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const encryptedPath = path.join(__dirname, "../temp", `custom-${customName}-encrypted-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                ` ⚙️ Memulai (Hardened Custom: ${customName}) (1%)\n` +
                ` ${createProgressBar(1)}\n` +
                "```\n" +
                "PROSES ENCRYPT "
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk Custom obfuscation: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            log(`Memvalidasi kode awal: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
            }

            log(`Mengenkripsi file dengan gaya Custom (${customName}) yang diperkuat`);
            await updateProgress(
                ctx,
                progressMessage,
                40,
                "Inisialisasi Hardened Custom Obfuscation"
            );
            const obfuscated = await JsConfuser.obfuscate(
                fileContent,
                getCustomObfuscationConfig(customName)
            );
            log(
                `Hasil obfuscation (50 char pertama): ${obfuscated.code.substring(0, 50)}...`
            );
            await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");

            log(`Memvalidasi kode hasil obfuscation: ${file.file_name}`);
            try {
                new Function(obfuscated.code);
            } catch (postObfuscationError) {
                log(`Kode hasil obfuscation tidak valid: ${postObfuscationError.message}`);
                throw new Error(
                    `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
                );
            }

            await fs.writeFile(encryptedPath, obfuscated.code);
            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

            log(`Mengirim file terenkripsi gaya Custom: ${file.file_name}`);
            await ctx.replyWithDocument(
                {
                    source: encryptedPath,
                    filename: `custom-${customName}-encrypted-${file.file_name}`,
                },
                {
                    caption: `✅ *File terenkripsi (Hardened Custom: ${customName}) siap!*\nSUKSES ENCRYPT 🕊`,
                    parse_mode: "Markdown",
                }
            );
            await updateProgress(
                ctx,
                progressMessage,
                100,
                `Hardened Custom (${customName}) Obfuscation Selesai`
            );

            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus: ${encryptedPath}`);
            }
        } catch (error) {
            log("Kesalahan saat Custom obfuscation", error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
            );
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus setelah error: ${encryptedPath}`);
            }
        }
    });

    // quantum command - Quantum obfuscation
    bot.command("quantum", async (ctx) => {
        users.add(ctx.from.id);
        saveUsers(users);

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/quantum`!");
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const encryptedPath = path.join(__dirname, "../temp", `quantum-encrypted-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                " ⚙️ Memulai (Quantum Vortex Encryption) (1%)\n" +
                " " + createProgressBar(1) + "\n" +
                "```\n" +
                "PROSES ENCRYPT "
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk Quantum Vortex Encryption: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            log(`Memvalidasi kode awal: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
            }

            log(`Mengenkripsi file dengan Quantum Vortex Encryption`);
            await updateProgress(
                ctx,
                progressMessage,
                40,
                "Inisialisasi Quantum Vortex Encryption"
            );
            const obfuscatedCode = await obfuscateQuantum(fileContent);
            log(`Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(0, 50)}...`);
            log(`Ukuran file setelah obfuscation: ${Buffer.byteLength(obfuscatedCode, "utf-8")} bytes`);

            log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
            try {
                new Function(obfuscatedCode);
            } catch (postObfuscationError) {
                log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
                throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
            }

            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
            await fs.writeFile(encryptedPath, obfuscatedCode);

            log(`Mengirim file terenkripsi quantum: ${file.file_name}`);
            await ctx.replyWithDocument(
                {
                    source: encryptedPath,
                    filename: `quantum-encrypted-${file.file_name}`,
                },
                {
                    caption: "✅ *File terenkripsi (Quantum Vortex Encryption) siap!*\nSUKSES ENCRYPT 🕊",
                    parse_mode: "Markdown",
                }
            );
            await updateProgress(ctx, progressMessage, 100, "Quantum Vortex Encryption Selesai");

            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus: ${encryptedPath}`);
            }
        } catch (error) {
            log("Kesalahan saat Quantum obfuscation", error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
            );
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus setelah error: ${encryptedPath}`);
            }
        }
    });

    // var command - Var obfuscation
    bot.command("var", async (ctx) => {
        users.add(ctx.from.id);
        saveUsers(users);

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/var`!");
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const encryptedPath = path.join(__dirname, "../temp", `var-encrypted-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                " ⚙️ Memulai (Var) (1%)\n" +
                " " + createProgressBar(1) + "\n" +
                "```\n" +
                "PROSES ENCRYPT "
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk Var obfuscation: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            log(`Memvalidasi kode awal: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
            }

            log(`Mengenkripsi file dengan gaya Var`);
            await updateProgress(ctx, progressMessage, 40, "Inisialisasi Var Dynamic Obfuscation");
            const obfuscated = await JsConfuser.obfuscate(fileContent, getNovaObfuscationConfig());
            let obfuscatedCode = obfuscated.code || obfuscated;
            if (typeof obfuscatedCode !== "string") {
                throw new Error("Hasil obfuscation bukan string");
            }
            log(`Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(0, 50)}...`);

            log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
            try {
                new Function(obfuscatedCode);
            } catch (postObfuscationError) {
                log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
                throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
            }

            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
            await fs.writeFile(encryptedPath, obfuscatedCode);

            log(`Mengirim file terenkripsi gaya Var: ${file.file_name}`);
            await ctx.replyWithDocument(
                { source: encryptedPath, filename: `Var-encrypted-${file.file_name}` },
                {
                    caption: "✅ *File terenkripsi (Var) siap!*\nSUKSES ENCRYPT 🕊",
                    parse_mode: "Markdown",
                }
            );
            await updateProgress(ctx, progressMessage, 100, "Var Obfuscation Selesai");

            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus: ${encryptedPath}`);
            }
        } catch (error) {
            log("Kesalahan saat Nova obfuscation", error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
            );
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus setelah error: ${encryptedPath}`);
            }
        }
    });

    // nebula command - Nebula obfuscation
    bot.command("nebula", async (ctx) => {
        users.add(ctx.from.id);
        saveUsers(users);

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/nebula`!");
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const encryptedPath = path.join(__dirname, "../temp", `nebula-encrypted-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                " ⚙️ Memulai (Nebula Polymorphic Storm) (1%)\n" +
                " " + createProgressBar(1) + "\n" +
                "```\n" +
                "PROSES ENCRYPT "
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk Nebula obfuscation: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            log(`Memvalidasi kode awal: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
            }

            log(`Mengenkripsi file dengan gaya Nebula`);
            await updateProgress(ctx, progressMessage, 40, "Inisialisasi Nebula Polymorphic Storm");
            const obfuscated = await JsConfuser.obfuscate(fileContent, getNebulaObfuscationConfig());
            let obfuscatedCode = obfuscated.code || obfuscated;
            if (typeof obfuscatedCode !== "string") {
                throw new Error("Hasil obfuscation bukan string");
            }
            log(`Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(0, 50)}...`);
            log(`Ukuran file setelah obfuscation: ${Buffer.byteLength(obfuscatedCode, "utf-8")} bytes`);

            log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
            try {
                new Function(obfuscatedCode);
            } catch (postObfuscationError) {
                log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
                throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
            }

            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
            await fs.writeFile(encryptedPath, obfuscatedCode);

            log(`Mengirim file terenkripsi gaya Nebula: ${file.file_name}`);
            await ctx.replyWithDocument(
                { source: encryptedPath, filename: `nebula-encrypted-${file.file_name}` },
                {
                    caption: "✅ *File terenkripsi (Nebula Polymorphic Storm) siap!*\nSUKSES ENCRYPT 🕊",
                    parse_mode: "Markdown",
                }
            );
            await updateProgress(ctx, progressMessage, 100, "Nebula Polymorphic Storm Selesai");

            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus: ${encryptedPath}`);
            }
        } catch (error) {
            log("Kesalahan saat Nebula obfuscation", error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
            );
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus setelah error: ${encryptedPath}`);
            }
        }
    });

    // enc5 command - Siu+Calcrick obfuscation
    bot.command("enc5", async (ctx) => {
        users.add(ctx.from.id);
        saveUsers(users);

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc5`!");
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const encryptedPath = path.join(__dirname, "../temp", `siucalcrick-encrypted-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                " ⚙️ Memulai (Calcrick Chaos Core) (1%)\n" +
                " " + createProgressBar(1) + "\n" +
                "```\n" +
                "PROSES ENCRYPT "
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk Siu+Calcrick obfuscation: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            log(`Memvalidasi kode awal: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
            }

            log(`Mengenkripsi file dengan gaya Siu+Calcrick`);
            await updateProgress(ctx, progressMessage, 40, "Inisialisasi Calcrick Chaos Core");
            const obfuscated = await JsConfuser.obfuscate(fileContent, getSiuCalcrickObfuscationConfig());
            let obfuscatedCode = obfuscated.code || obfuscated;
            if (typeof obfuscatedCode !== "string") {
                throw new Error("Hasil obfuscation bukan string");
            }
            log(`Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(0, 50)}...`);
            log(`Ukuran file setelah obfuscation: ${Buffer.byteLength(obfuscatedCode, "utf-8")} bytes`);

            log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
            try {
                new Function(obfuscatedCode);
            } catch (postObfuscationError) {
                log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
                throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
            }

            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
            await fs.writeFile(encryptedPath, obfuscatedCode);

            log(`Mengirim file terenkripsi gaya Siu+Calcrick: ${file.file_name}`);
            await ctx.replyWithDocument(
                {
                    source: encryptedPath,
                    filename: `siucalcrick-encrypted-${file.file_name}`,
                },
                {
                    caption: "✅ *File terenkripsi (Calcrick Chaos Core) siap!*\nSUKSES ENCRYPT 🕊",
                    parse_mode: "Markdown",
                }
            );
            await updateProgress(ctx, progressMessage, 100, "Calcrick Chaos Core Selesai");

            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus: ${encryptedPath}`);
            }
        } catch (error) {
            log("Kesalahan saat Siu+Calcrick obfuscation", error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
            );
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus setelah error: ${encryptedPath}`);
            }
        }
    });

    // enc2 command - Custom text obfuscation
    bot.command("enc2", async (ctx) => {
        users.add(ctx.from.id);
        saveUsers(users);

        const customString = ctx.message.text.split(" ")[1];

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc2 <text>`!");
        }

        if (!customString) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc2 <text>`!");
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const encryptedPath = path.join(__dirname, "../temp", `custom-encrypted-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                " ⚙️ Memulai (custom enc) (1%)\n" +
                " " + createProgressBar(1) + "\n" +
                "```\n" +
                "PROSES ENCRYPT "
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk custom obfuscation: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            log(`Memvalidasi kode awal: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
            }

            log(`Mengenkripsi file dengan gaya custom (${customString})`);
            await updateProgress(ctx, progressMessage, 40, `Inisialisasi custom (${customString})`);

            const obfuscated = await JsConfuser.obfuscate(fileContent, getCustomObfuscationConfig(customString));
            let obfuscatedCode = obfuscated.code || obfuscated;
            if (typeof obfuscatedCode !== "string") {
                throw new Error("Hasil obfuscation bukan string");
            }
            log(`Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(0, 50)}...`);
            log(`Ukuran file setelah obfuscation: ${Buffer.byteLength(obfuscatedCode, "utf-8")} bytes`);

            log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
            try {
                new Function(obfuscatedCode);
            } catch (postObfuscationError) {
                log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
                throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
            }

            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
            await fs.writeFile(encryptedPath, obfuscatedCode);

            log(`Mengirim file terenkripsi gaya custom (${customString}): ${file.file_name}`);
            await ctx.replyWithDocument(
                {
                    source: encryptedPath,
                    filename: `custom-encrypted-${file.file_name}`,
                },
                {
                    caption: `✅ *File terenkripsi custom (${customString}) siap!*\nSUKSES ENCRYPT 🕊`,
                    parse_mode: "Markdown",
                }
            );
            await updateProgress(ctx, progressMessage, 100, `custom (${customString}) Selesai`);

            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus: ${encryptedPath}`);
            }
        } catch (error) {
            log("Kesalahan saat custom enc obfuscation", error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
            );
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus setelah error: ${encryptedPath}`);
            }
        }
    });

    // enc command - Time-locked obfuscation
    bot.command("enc", async (ctx) => {
        users.add(ctx.from.id);
        saveUsers(users);

        const args = ctx.message.text.split(" ").slice(1);
        if (args.length !== 1 || !/^\d+$/.test(args[0]) || parseInt(args[0]) < 1 || parseInt(args[0]) > 365) {
            return ctx.replyWithMarkdown(
                "❌ *Error:* Gunakan format `/locked [1-365]` untuk jumlah hari (misal: `/enc 7`)!"
            );
        }

        const days = args[0];
        const expiryDate = new Date();
        expiryDate.setDate(expiryDate.getDate() + parseInt(days));
        const expiryFormatted = expiryDate.toLocaleDateString();

        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc [1-365]`!");
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".js")) {
            return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
        }

        const encryptedPath = path.join(__dirname, "../temp", `locked-encrypted-${file.file_name}`);

        try {
            const progressMessage = await ctx.replyWithMarkdown(
                "```css\n" +
                "🔒 EncryptBot\n" +
                " ⚙️ Memulai (Time-Locked Encryption) (1%)\n" +
                " " + createProgressBar(1) + "\n" +
                "```\n" +
                "PROSES ENCRYPT "
            );

            const fileLink = await ctx.telegram.getFileLink(file.file_id);
            log(`Mengunduh file untuk Time-Locked Encryption: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 10, "Mengunduh");
            const response = await fetch(fileLink);
            let fileContent = await response.text();
            await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

            log(`Memvalidasi kode awal: ${file.file_name}`);
            await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
            try {
                new Function(fileContent);
            } catch (syntaxError) {
                throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
            }

            log(`Mengenkripsi file dengan Time-Locked Encryption`);
            await updateProgress(ctx, progressMessage, 40, "Inisialisasi Time-Locked Encryption");
            const obfuscatedCode = await obfuscateTimeLocked(fileContent, days);
            log(`Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(0, 50)}...`);
            log(`Ukuran file setelah obfuscation: ${Buffer.byteLength(obfuscatedCode, "utf-8")} bytes`);

            log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
            try {
                new Function(obfuscatedCode);
            } catch (postObfuscationError) {
                log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
                throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
            }

            await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
            await fs.writeFile(encryptedPath, obfuscatedCode);

            log(`Mengirim file terenkripsi time-locked: ${file.file_name}`);
            await ctx.replyWithMarkdown(
                `✅ *File terenkripsi (Time-Locked Encryption) siap!*\n` +
                `⏰ Masa aktif: ${days} hari (Kedaluwarsa: ${expiryFormatted})\n` +
                `_Powered by Ginaa_`,
                { parse_mode: "Markdown" }
            );
            await ctx.replyWithDocument({
                source: encryptedPath,
                filename: `locked-encrypted-${file.file_name}`,
            });
            await updateProgress(ctx, progressMessage, 100, "Time-Locked Encryption Selesai");

            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus: ${encryptedPath}`);
            }
        } catch (error) {
            log("Kesalahan saat Time-Locked obfuscation", error);
            await ctx.replyWithMarkdown(
                `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
            );
            if (await fs.pathExists(encryptedPath)) {
                await fs.unlink(encryptedPath);
                log(`File sementara dihapus setelah error: ${encryptedPath}`);
            }
        }
    });
    // addprem command - Add premium user
    bot.command('addprem', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
        }
        
        const args = ctx.message.text.split(' ');
        if (args.length < 3) {
            return ctx.reply('❌ Format: /addprem <user_id> <days>');
        }
        
        const userId = parseInt(args[1]);
        const days = parseInt(args[2]);
        
        if (isNaN(userId) || isNaN(days) || days <= 0) {
            return ctx.reply('❌ Format: /addprem <user_id> <days> (days harus angka positif)');
        }
        
        const expiryDate = new Date();
        expiryDate.setDate(expiryDate.getDate() + days);
        
        global.premiumUsers.set(userId, { expiry: expiryDate.toISOString() });
        savePremiumUsers(global.premiumUsers);
        
        ctx.reply(`✅ User ${userId} telah ditambahkan sebagai premium selama ${days} hari. Berlaku hingga: ${expiryDate.toLocaleDateString()}`);
        
        try {
            await ctx.telegram.sendMessage(userId, `🎉 Selamat! Anda sekarang pengguna premium Jasher Bot selama ${days} hari. Berlaku hingga: ${expiryDate.toLocaleDateString()}`);
        } catch (error) {
            console.log(`Tidak dapat mengirim pesan ke user ${userId}: ${error.message}`);
        }
    });
    
    // addbl command - Add group to blacklist
    bot.command('addbl', (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
        }
        
        const args = ctx.message.text.split(' ');
        if (args.length < 2) {
            return ctx.reply('❌ Format: /addbl <group_id>');
        }
        
        const groupId = args[1];
        
        if (blacklistGroups.has(groupId)) {
            ctx.reply(`❌ Group ${groupId} sudah ada dalam blacklist.`);
        } else {
            blacklistGroups.add(groupId);
            saveBlacklistGroups(blacklistGroups);
            ctx.reply(`✅ Group ${groupId} telah ditambahkan ke blacklist.`);
        }
    });
    
    // delbl command - Remove group from blacklist
    bot.command('delbl', (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
        }
        
        const args = ctx.message.text.split(' ');
        if (args.length < 2) {
            return ctx.reply('❌ Format: /delbl <group_id>');
        }
        
        const groupId = args[1];
        
        if (blacklistGroups.has(groupId)) {
            blacklistGroups.delete(groupId);
            saveBlacklistGroups(blacklistGroups);
            ctx.reply(`✅ Group ${groupId} telah dihapus dari blacklist.`);
        } else {
            ctx.reply(`❌ Group ${groupId} tidak ditemukan dalam blacklist.`);
        }
    });
    
    // listbl command - List blacklisted groups
    bot.command('listbl', (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
        }
        
        if (blacklistGroups.size === 0) {
            return ctx.reply('❌ Tidak ada group dalam blacklist saat ini.');
        }
        
        let listText = '📋 Daftar Group Blacklist:\n\n';
        
        blacklistGroups.forEach(groupId => {
            listText += `👥 Group ID: ${groupId}\n`;
        });
        
        ctx.reply(listText);
    });
    
    // bc command - Broadcast to all users
    bot.command('bc', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
        }
        
        const messageText = ctx.message.text.split(' ').slice(1).join(' ');
        
        if (!messageText) {
            return ctx.reply('❌ Format: /bc <pesan>');
        }
        
        const usersArray = Array.from(users);
        let successCount = 0;
        let failCount = 0;
        
        const progressMessage = await ctx.reply(`📢 Mengirim broadcast ke ${usersArray.length} pengguna...\n\n✅ Berhasil: ${successCount}\n❌ Gagal: ${failCount}`);
        
        for (const userId of usersArray) {
            try {
                await ctx.telegram.sendMessage(userId, `📢 *Broadcast dari Owner:*\n\n${messageText}`, { parse_mode: 'Markdown' });
                successCount++;
                
                // Update progress every 10 messages
                if (successCount % 10 === 0) {
                    await ctx.telegram.editMessageText(
                        progressMessage.chat.id,
                        progressMessage.message_id,
                        null,
                        `📢 Mengirim broadcast ke ${usersArray.length} pengguna...\n\n✅ Berhasil: ${successCount}\n❌ Gagal: ${failCount}`
                    );
                }
                
                // Delay to avoid rate limiting
                await new Promise(resolve => setTimeout(resolve, 100));
            } catch (error) {
                failCount++;
                console.log(`Gagal mengirim broadcast ke ${userId}: ${error.message}`);
            }
        }
        
        await ctx.telegram.editMessageText(
            progressMessage.chat.id,
            progressMessage.message_id,
            null,
            `✅ Broadcast selesai!\n\n📊 Statistik:\n✅ Berhasil: ${successCount}\n❌ Gagal: ${failCount}`
        );
    });
    
    // listgrup command - List all groups
    bot.command('listgrup', (ctx) => {
        if (!isOwner(ctx.from.id)) {
            return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
        }
        
        if (groups.size === 0) {
            return ctx.reply('❌ Bot belum ditambahkan ke grup manapun.');
        }
        
        let listText = '📋 Daftar Grup Aktif:\n\n';
        
        groups.forEach(groupId => {
            listText += `👥 Group ID: ${groupId}\n`;
        });
        
        ctx.reply(listText);
    });
    // antispam command - Toggle anti-spam
    bot.command('antispam', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ Command ini hanya dapat digunakan di grup!');
        }
        
        // Check if user is admin
        try {
            const chatMember = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(chatMember.status)) {
                return ctx.reply('❌ Hanya admin yang dapat menggunakan command ini!');
            }
        } catch (error) {
            return ctx.reply('❌ Gagal memverifikasi status admin.');
        }
        
        const groupId = ctx.chat.id.toString();
        let settings = global.groupSettings.get(groupId) || {};
        
        settings.antispam = !settings.antispam;
        global.groupSettings.set(groupId, settings);
        saveGroupSettings(global.groupSettings);
        
        ctx.reply(`✅ Anti-spam ${settings.antispam ? 'diaktifkan' : 'dinonaktifkan'}!`);
    });
    
    // noevent command - Toggle no event
    bot.command('noevent', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ Command ini hanya dapat digunakan di grup!');
        }
        
        // Check if user is admin
        try {
            const chatMember = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(chatMember.status)) {
                return ctx.reply('❌ Hanya admin yang dapat menggunakan command ini!');
            }
        } catch (error) {
            return ctx.reply('❌ Gagal memverifikasi status admin.');
        }
        
        const groupId = ctx.chat.id.toString();
        let settings = groupSettings.get(groupId) || {};
        
        settings.noevent = !settings.noevent;
        groupSettings.set(groupId, settings);
        saveGroupSettings(groupSettings);
        
        ctx.reply(`✅ No event ${settings.noevent ? 'diaktifkan' : 'dinonaktifkan'}!`);
    });
    
    // nolinks command - Toggle no links
    bot.command('nolinks', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ Command ini hanya dapat digunakan di grup!');
        }
        
        // Check if user is admin
        try {
            const chatMember = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(chatMember.status)) {
                return ctx.reply('❌ Hanya admin yang dapat menggunakan command ini!');
            }
        } catch (error) {
            return ctx.reply('❌ Gagal memverifikasi status admin.');
        }
        
        const groupId = ctx.chat.id.toString();
        let settings = groupSettings.get(groupId) || {};
        
        settings.nolinks = !settings.nolinks;
        groupSettings.set(groupId, settings);
        saveGroupSettings(groupSettings);
        
        ctx.reply(`✅ No links ${settings.nolinks ? 'diaktifkan' : 'dinonaktifkan'}!`);
    });
    
    // noforwards command - Toggle no forwards
    bot.command('noforwards', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ Command ini hanya dapat digunakan di grup!');
        }
        
        // Check if user is admin
        try {
            const chatMember = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(chatMember.status)) {
                return ctx.reply('❌ Hanya admin yang dapat menggunakan command ini!');
            }
        } catch (error) {
            return ctx.reply('❌ Gagal memverifikasi status admin.');
        }
        
        const groupId = ctx.chat.id.toString();
        let settings = groupSettings.get(groupId) || {};
        
        settings.noforwards = !settings.noforwards;
        groupSettings.set(groupId, settings);
        saveGroupSettings(groupSettings);
        
        ctx.reply(`✅ No forwards ${settings.noforwards ? 'diaktifkan' : 'dinonaktifkan'}!`);
    });
    
    // nocontacts command - Toggle no contacts
    bot.command('nocontacts', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ Command ini hanya dapat digunakan di grup!');
        }
        
        // Check if user is admin
        try {
            const chatMember = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(chatMember.status)) {
                return ctx.reply('❌ Hanya admin yang dapat menggunakan command ini!');
            }
        } catch (error) {
            return ctx.reply('❌ Gagal memverifikasi status admin.');
        }
        
        const groupId = ctx.chat.id.toString();
        let settings = groupSettings.get(groupId) || {};
        
        settings.nocontacts = !settings.nocontacts;
        groupSettings.set(groupId, settings);
        saveGroupSettings(groupSettings);
        
        ctx.reply(`✅ No contacts ${settings.nocontacts ? 'diaktifkan' : 'dinonaktifkan'}!`);
    });
    
    // nohastags command - Toggle no hashtags
    bot.command('nohastags', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ Command ini hanya dapat digunakan di grup!');
        }
        
        // Check if user is admin
        try {
            const chatMember = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(chatMember.status)) {
                return ctx.reply('❌ Hanya admin yang dapat menggunakan command ini!');
            }
        } catch (error) {
            return ctx.reply('❌ Gagal memverifikasi status admin.');
        }
        
        const groupId = ctx.chat.id.toString();
        let settings = groupSettings.get(groupId) || {};
        
        settings.nohastags = !settings.nohastags;
        groupSettings.set(groupId, settings);
        saveGroupSettings(groupSettings);
        
        ctx.reply(`✅ No hashtags ${settings.nohastags ? 'diaktifkan' : 'dinonaktifkan'}!`);
    });
    
    // nocommands command - Toggle no commands
    bot.command('nocommands', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ Command ini hanya dapat digunakan di grup!');
        }
        
        // Check if user is admin
        try {
            const chatMember = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(chatMember.status)) {
                return ctx.reply('❌ Hanya admin yang dapat menggunakan command ini!');
            }
        } catch (error) {
            return ctx.reply('❌ Gagal memverifikasi status admin.');
        }
        
        const groupId = ctx.chat.id.toString();
        let settings = groupSettings.get(groupId) || {};
        
        settings.nocommands = !settings.nocommands;
        groupSettings.set(groupId, settings);
        saveGroupSettings(groupSettings);
        
        ctx.reply(`✅ No commands ${settings.nocommands ? 'diaktifkan' : 'dinonaktifkan'}!`);
    });
    
    // settings command - Show group settings
    bot.command('settings', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ Command ini hanya dapat digunakan di grup!');
        }
        
        // Check if user is admin
        try {
            const chatMember = await ctx.getChatMember(ctx.from.id);
            if (!['administrator', 'creator'].includes(chatMember.status)) {
                return ctx.reply('❌ Hanya admin yang dapat menggunakan command ini!');
            }
        } catch (error) {
            return ctx.reply('❌ Gagal memverifikasi status admin.');
        }
        
        const groupId = ctx.chat.id.toString();
        const settings = groupSettings.get(groupId) || {};
        
        const settingsText = `
⚙️ *Pengaturan Grup:*

🔒 Anti-spam: ${settings.antispam ? '✅' : '❌'}
🎉 No event: ${settings.noevent ? '✅' : '❌'}
🔗 No links: ${settings.nolinks ? '✅' : '❌'}
↪️ No forwards: ${settings.noforwards ? '✅' : '❌'}
👤 No contacts: ${settings.nocontacts ? '✅' : '❌'}
#️⃣ No hashtags: ${settings.nohastags ? '✅' : '❌'}
⌨️ No commands: ${settings.nocommands ? '✅' : '❌'}
        `;
        
        ctx.replyWithMarkdown(settingsText);
    });

    bot.action('main_menu', async (ctx) => {
        const sender = getUsername(ctx.from);
        const isCreator = isOwner(ctx.from.id);
        
        const menuText = `
╭─❒ 「 User Info 」 
├ Owner : ${isCreator ? 'True' : 'False'}
├ Name : ${ctx.from.first_name}${ctx.from.last_name ? ` ${ctx.from.last_name}` : ''}
├ Profile : ${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`;
        
        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('🤖 Jasher Menu', 'jasher_menu')],
            [Markup.button.callback('👑 Owner Menu', 'owner_menu'), Markup.button.callback('🔒 Obf Menu', 'obf_menu')],
            [Markup.button.callback('🔄 Kembali', 'main_menu')]
        ]);
        
        try {
            await ctx.editMessageCaption(menuText, {
                parse_mode: 'Markdown',
                ...keyboard
            });
        } catch (error) {
            await ctx.deleteMessage();
            await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
                caption: menuText,
                parse_mode: 'Markdown',
                ...keyboard
            });
        }
        await ctx.answerCbQuery();
    });
    
    bot.action('jasher_menu', async (ctx) => {
        const jasherText = `
🤖 *Jasher Menu*

Fitur-fitur yang tersedia:

🔒 *Obfuscation:*
/enc3 - Mandarin Obfuscation
/enc4 - Arab Obfuscation
/japan - Japan Obfuscation
/zenc - Invisible Obfuscation
/xx <nama> - Custom Name Obfuscation
/quantum - Quantum Obfuscation
/var - Var Obfuscation
/nebula - Nebula Obfuscation
/enc5 - Siu+Calcrick Obfuscation
/enc2 <text> - Custom Text Obfuscation
/enc <days> - Time-Locked Obfuscation
/deobfuscate - Deobfuscate File

📢 *Sharing:*
/sharefree - Share pesan gratis
/sharevip - Share pesan premium

ℹ️ Gunakan command di atas dengan membalas file JS untuk obfuscation.
        `;
        
        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('⬅️ Kembali', 'main_menu')]
        ]);
        
        try {
            await ctx.editMessageCaption(jasherText, {
                parse_mode: 'Markdown',
                ...keyboard
            });
        } catch (error) {
            await ctx.deleteMessage();
            await ctx.replyWithMarkdown(jasherText, keyboard);
        }
        await ctx.answerCbQuery();
    });
    
    bot.action('owner_menu', async (ctx) => {
        if (!isOwner(ctx.from.id)) {
            await ctx.answerCbQuery('❌ Hanya owner yang dapat mengakses menu ini!', { show_alert: true });
            return;
        }
        
        const ownerText = `
👑 *Owner Menu*

Fitur-fitur owner:

👤 *Premium Management:*
/addprem <user_id> <days> - Tambah user premium
/delprem <user_id> - Hapus user premium
/listprem - List user premium

🚫 *Blacklist Management:*
/addbl <group_id> - Tambah group ke blacklist
/delbl <group_id> - Hapus group dari blacklist
/listbl - List group blacklist

📢 *Broadcast:*
/bc <pesan> - Broadcast ke semua user

👥 *Group Management:*
/listgrup - List semua grup aktif

ℹ️ Gunakan command di atas untuk mengelola bot.
        `;
        
        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('⬅️ Kembali', 'main_menu')]
        ]);
        
        try {
            await ctx.editMessageCaption(ownerText, {
                parse_mode: 'Markdown',
                ...keyboard
            });
        } catch (error) {
            await ctx.deleteMessage();
            await ctx.replyWithMarkdown(ownerText, keyboard);
        }
        await ctx.answerCbQuery();
    });
    
    bot.action('obf_menu', async (ctx) => {
        const obfText = `
🔒 *Obf Menu*

Metode Obfuscation yang tersedia:

1. 🔒 /enc3 - Mandarin Obfuscation
2. 🔒 /enc4 - Arab Obfuscation  
3. 🔒 /japan - Japan Obfuscation
4. 🔒 /zenc - Invisible Obfuscation
5. 🔒 /xx <nama> - Custom Name
6. 🔒 /quantum - Quantum Obfuscation
7. 🔒 /var - Var Obfuscation
8. 🔒 /nebula - Nebula Obfuscation
9. 🔒 /enc5 - Siu+Calcrick Obfuscation
10. 🔒 /enc2 <text> - Custom Text
11. 🔒 /enc <days> - Time-Locked
12. 🔒 /deobfuscate - Deobfuscate

ℹ️ Balas file JS dengan command di atas.
Gunakan /help untuk info detail setiap metode.
        `;
        
        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('⬅️ Kembali', 'main_menu')]
        ]);
        
        try {
            await ctx.editMessageCaption(obfText, {
                parse_mode: 'Markdown',
                ...keyboard
            });
        } catch (error) {
            await ctx.deleteMessage();
            await ctx.replyWithMarkdown(obfText, keyboard);
        }
        await ctx.answerCbQuery();
    });

// fixed by aulia rahman
    // sharefree command - Free sharing
    bot.command('sharefree', async (ctx) => {
        if (ctx.chat.type !== 'private') {
            await ctx.reply('❌ Command ini hanya dapat digunakan di private chat!');
            return;
        }
        
        if (!ctx.message.reply_to_message) {
            await ctx.reply('❌ Balas pesan yang ingin di-share dengan command ini!');
            return;
        }
        
        // Add user to database
        users.add(ctx.from.id);
        saveUsers(users);
        
        // Check if user is premium or has free trial
        const isUserPremium = isPremium(ctx.from.id);
        const hasFreeTrial = users.has(ctx.from.id); // Simple check, can be enhanced
        
        if (!isUserPremium && !hasFreeTrial) {
            // Give free trial
            const expiryDate = new Date();
            expiryDate.setDate(expiryDate.getDate() + FREE_TRIAL_DAYS);
            
            premiumUsers.set(ctx.from.id, { expiry: expiryDate.toISOString() });
            savePremiumUsers(premiumUsers);
            
            await ctx.reply(`🎉 Anda mendapatkan trial premium ${FREE_TRIAL_DAYS} hari! Berlaku hingga: ${expiryDate.toLocaleDateString()}`);
        }
        
        // Share the message to groups
        const groupsArray = Array.from(groups);
        let successCount = 0;
        let failCount = 0;
        
        const progressMessage = await ctx.reply(`📢 Mengirim pesan ke ${groupsArray.length} grup...\n\n✅ Berhasil: ${successCount}\n❌ Gagal: ${failCount}`);
        
        for (const groupId of groupsArray) {
            if (blacklistGroups.has(groupId)) {
                failCount++;
                continue;
            }
            
            try {
                // Forward the message or send a copy
                if (ctx.message.reply_to_message.text) {
                    await ctx.telegram.sendMessage(groupId, `📢 *Share from ${ctx.from.first_name}:*\n\n${ctx.message.reply_to_message.text}`, { parse_mode: 'Markdown' });
                } else if (ctx.message.reply_to_message.photo) {
                    await ctx.telegram.sendPhoto(groupId, ctx.message.reply_to_message.photo[0].file_id, {
                        caption: ctx.message.reply_to_message.caption ? `📢 Share from ${ctx.from.first_name}:\n\n${ctx.message.reply_to_message.caption}` : `📢 Share from ${ctx.from.first_name}`
                    });
                } else if (ctx.message.reply_to_message.document) {
                    await ctx.telegram.sendDocument(groupId, ctx.message.reply_to_message.document.file_id, {
                        caption: ctx.message.reply_to_message.caption ? `📢 Share from ${ctx.from.first_name}:\n\n${ctx.message.reply_to_message.caption}` : `📢 Share from ${ctx.from.first_name}`
                    });
                } else {
                    // Unsupported message type
                    failCount++;
                    continue;
                }
                
                successCount++;
                
                // Update progress every 5 messages
                if (successCount % 5 === 0) {
                    await ctx.telegram.editMessageText(
                        progressMessage.chat.id,
                        progressMessage.message_id,
                        null,
                        `📢 Mengirim pesan ke ${groupsArray.length} grup...\n\n✅ Berhasil: ${successCount}\n❌ Gagal: ${failCount}`
                    );
                }
                
                // Delay to avoid rate limiting
                await new Promise(resolve => setTimeout(resolve, 500));
            } catch (error) {
                failCount++;
                console.log(`Gagal mengirim pesan ke grup ${groupId}: ${error.message}`);
            }
        }
        
        await ctx.telegram.editMessageText(
            progressMessage.chat.id,
            progressMessage.message_id,
            null,
            `✅ Share selesai!\n\n📊 Statistik:\n✅ Berhasil: ${successCount}\n❌ Gagal: ${failCount}`
        );
    });
    
    // sharevip command - VIP sharing (faster)
    bot.command('sharevip', async (ctx) => {
        if (ctx.chat.type !== 'private') {
            await ctx.reply('❌ Command ini hanya dapat digunakan di private chat!');
            return;
        }
        
        if (!isPremium(ctx.from.id)) {
            await ctx.reply('❌ Hanya pengguna premium yang dapat menggunakan command ini!');
            return;
        }
        
        if (!ctx.message.reply_to_message) {
            await ctx.reply('❌ Balas pesan yang ingin di-share dengan command ini!');
            return;
        }
        
        // Share the message to groups (faster for VIP)
        const groupsArray = Array.from(groups);
        let successCount = 0;
        let failCount = 0;
        
        const progressMessage = await ctx.reply(`🚀 Mengirim pesan VIP ke ${groupsArray.length} grup...\n\n✅ Berhasil: ${successCount}\n❌ Gagal: ${failCount}`);
        
        // Use Promise.all for faster sending
        const sendPromises = groupsArray.map(async (groupId) => {
            if (blacklistGroups.has(groupId)) {
                failCount++;
                return;
            }
            
            try {
                // Forward the message or send a copy
                if (ctx.message.reply_to_message.text) {
                    await ctx.telegram.sendMessage(groupId, `🚀 *VIP Share from ${ctx.from.first_name}:*\n\n${ctx.message.reply_to_message.text}`, { parse_mode: 'Markdown' });
                } else if (ctx.message.reply_to_message.photo) {
                    await ctx.telegram.sendPhoto(groupId, ctx.message.reply_to_message.photo[0].file_id, {
                        caption: ctx.message.reply_to_message.caption ? `🚀 VIP Share from ${ctx.from.first_name}:\n\n${ctx.message.reply_to_message.caption}` : `🚀 VIP Share from ${ctx.from.first_name}`
                    });
                } else if (ctx.message.reply_to_message.document) {
                    await ctx.telegram.sendDocument(groupId, ctx.message.reply_to_message.document.file_id, {
                        caption: ctx.message.reply_to_message.caption ? `🚀 VIP Share from ${ctx.from.first_name}:\n\n${ctx.message.reply_to_message.caption}` : `🚀 VIP Share from ${ctx.from.first_name}`
                    });
                } else {
                    // Unsupported message type
                    failCount++;
                    return;
                }
                
                successCount++;
                
                // Update progress every 10 messages
                if (successCount % 10 === 0) {
                    await ctx.telegram.editMessageText(
                        progressMessage.chat.id,
                        progressMessage.message_id,
                        null,
                        `🚀 Mengirim pesan VIP ke ${groupsArray.length} grup...\n\n✅ Berhasil: ${successCount}\n❌ Gagal: ${failCount}`
                    );
                }
            } catch (error) {
                failCount++;
                console.log(`Gagal mengirim pesan VIP ke grup ${groupId}: ${error.message}`);
            }
        });
        
        // Wait for all promises to complete
        await Promise.all(sendPromises);
        
        await ctx.telegram.editMessageText(
            progressMessage.chat.id,
            progressMessage.message_id,
            null,
            `✅ VIP Share selesai!\n\n📊 Statistik:\n✅ Berhasil: ${successCount}\n❌ Gagal: ${failCount}`
        );
    });

    bot.command('tourl', async (ctx) => {
        if (!ctx.message.reply_to_message) {
            return ctx.reply('❌ Balas foto atau document dengan command ini!');
        }
        
        let fileBuffer;
        let filename;
        
        if (ctx.message.reply_to_message.photo) {
            // Get the highest quality photo
            const photo = ctx.message.reply_to_message.photo[ctx.message.reply_to_message.photo.length - 1];
            const fileLink = await ctx.telegram.getFileLink(photo.file_id);
            const response = await fetch(fileLink);
            fileBuffer = await response.buffer();
            filename = `photo_${Date.now()}.jpg`;
        } else if (ctx.message.reply_to_message.document) {
            const document = ctx.message.reply_to_message.document;
            const fileLink = await ctx.telegram.getFileLink(document.file_id);
            const response = await fetch(fileLink);
            fileBuffer = await response.buffer();
            filename = document.file_name || `file_${Date.now()}`;
        } else {
            return ctx.reply('❌ Hanya foto atau document yang didukung!');
        }
        
        try {
            const progressMessage = await ctx.reply('📤 Mengupload file ke uguu.se...');
            
            const url = await uploadToUguu(fileBuffer, filename);
            
            await ctx.telegram.editMessageText(
                progressMessage.chat.id,
                progressMessage.message_id,
                null,
                `✅ File berhasil diupload!\n\n🔗 URL: ${url}`
            );
        } catch (error) {
            log('Error uploading to uguu.se', error);
            ctx.reply('❌ Gagal mengupload file. Silakan coba lagi.');
        }
    });
}

module.exports = {
    setupCommands
};