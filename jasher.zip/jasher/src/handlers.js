const { getUser, updateUser, addUserToGroup, getGroup, getAllGroups } = require('../lib/database');
const { mainKeyboard } = require('./keyboards');

async function handleStart(ctx) {
    const userId = ctx.from.id;
    const user = getUser(userId);
    
    const welcomeMessage = `👋 Halo ${ctx.from.first_name}! Selamat datang di Bot Jasher.

✨ Fitur:
- Dapatkan 10 kredit dengan menambahkan bot ke grup dan menggunakan /addgroup
- Gunakan /share untuk membagikan pesan ke semua grup (1 kredit/share)
- Gunakan /stats untuk melihat kredit Anda

Silakan pilih opsi di bawah:`;
    
    await ctx.reply(welcomeMessage, mainKeyboard);
}

async function handleShare(ctx) {
    const userId = ctx.from.id;
    const user = getUser(userId);
    
    if (user.credits < 1) {
        return ctx.reply('Kredit Anda tidak cukup. Silakan join grup terlebih dahulu untuk mendapatkan kredit.');
    }
    
    await ctx.reply('Silakan ketik pesan yang ingin Anda share ke semua grup:');
    ctx.session.waitingForShare = true;
}

async function handleAddGroup(ctx) {
    if (ctx.chat.type === 'private') {
        return ctx.reply('Perintah ini hanya dapat digunakan di dalam grup.');
    }
    
    const userId = ctx.from.id;
    const groupId = ctx.chat.id;
    
    try {
        // Check if user is admin in the group
        const member = await ctx.telegram.getChatMember(groupId, userId);
        if (member.status !== 'administrator' && member.status !== 'creator') {
            return ctx.reply('Hanya admin grup yang dapat menggunakan perintah ini.');
        }
        
        // Add user to group
        const success = addUserToGroup(userId, groupId);
        
        if (success) {
            const user = getUser(userId);
            await ctx.reply(`Berhasil! Anda telah tergabung di grup ini dan mendapatkan 10 kredit. Total kredit: ${user.credits}`);
        } else {
            await ctx.reply('Anda sudah tergabung di grup ini sebelumnya.');
        }
    } catch (error) {
        console.error('Error in handleAddGroup:', error);
        await ctx.reply('Terjadi kesalahan. Pastikan bot adalah admin di grup ini.');
    }
}

async function handleJoinGroup(ctx) {
    if (ctx.chat.type !== 'private') {
        return ctx.reply('Perintah ini hanya dapat digunakan di chat private dengan bot.');
    }
    
    const userId = ctx.from.id;
    const allGroups = getAllGroups();
    
    if (allGroups.length === 0) {
        return ctx.reply('Belum ada grup yang terdaftar. Silakan tambahkan bot ke grup terlebih dahulu.');
    }
    
    let message = '📋 Daftar Grup Tersedia:\n\n';
    allGroups.forEach((group, index) => {
        message += `${index + 1}. ${group.title}\n`;
    });
    
    message += '\nSilakan tambahkan bot ke salah satu grup di atas, kemudian gunakan perintah /addgroup di grup tersebut.';
    
    await ctx.reply(message);
}

async function handleStats(ctx) {
    const userId = ctx.from.id;
    const user = getUser(userId);
    
    await ctx.reply(`📊 Stats Anda:
- Kredit: ${user.credits}
- Grup yang diikuti: ${user.groups.length}
- Bergabung sejak: ${user.joinedAt.toLocaleDateString('id-ID')}`);
}

module.exports = {
    handleStart,
    handleShare,
    handleAddGroup,
    handleJoinGroup,
    handleStats
};