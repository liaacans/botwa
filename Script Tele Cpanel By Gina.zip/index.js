const settings = require("./settings");

const TelegramBot = require("node-telegram-bot-api");
const axios = require("axios");
const archiver = require("archiver");
const { createCanvas, loadImage } = require('canvas');
const crypto = require("crypto");
const chalk = require("chalk");
const fs = require("fs");
const os = require("os");
const { exec } = require("child_process");
const path = require("path");
const readline = require("readline");
const https = require('https'); // ✅ TAMBAHKAN INI
const { startBot } = require("./connectbot/start");
// ===== Monitoring: deteksi panel/admin manual =====
const knownServersPath = path.join(__dirname, './library/database/knownServers.json');

// Pastikan file knownServers ada
if (!fs.existsSync(knownServersPath)) {
  const dir = path.dirname(knownServersPath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(knownServersPath, JSON.stringify({ servers: [], users: [], lastChecked: 0 }, null, 2));
}

function loadKnownServers() {
  try {
    return JSON.parse(fs.readFileSync(knownServersPath, 'utf8'));
  } catch (e) {
    const init = { servers: [], users: [], lastChecked: 0 };
    fs.writeFileSync(knownServersPath, JSON.stringify(init, null, 2));
    return init;
  }
}

function saveKnownServers(obj) {
  try {
    fs.writeFileSync(knownServersPath, JSON.stringify(obj, null, 2));
  } catch (e) {
    console.error('Gagal simpan knownServers:', e.message);
  }
}

/*const { saveActiveSessions, connectToWhatsApp, initializeWhatsAppConnections, sessions } = require("./connect");

// koneksi WA
initializeWhatsAppConnections();*/

async function fetchBot() {
  try {
    const response = await axios.get(`${settings.RAW}`);
    return response.data.tokens;
  } catch (error) {
    return [];
  }
}

async function startingBot() {
  console.clear();
  const validTokens = await fetchBot();
  if (!validTokens.includes(settings.token)) {
    console.clear();
    console.log(chalk.red.bold("🚫 Akses ditolak! Token tidak ada."));
    process.exit(1);
  }
  startBot(bot);
  console.clear();
}

const bot = new TelegramBot(settings.token, { polling: true });

// PASTIKAN FUNGSI INI SUDAH DITAMBAHKAN SEBELUM validateBot
function cachePassword(password) {
    try {
        const PASSWORD_FILE = "./db/password_cache.txt";
        fs.writeFileSync(PASSWORD_FILE, password);
        console.log('✅ Password cached for auto-restart');
    } catch (error) {
        console.log('❌ Failed to cache password');
    }
}

function saveAuthSession() {
    try {
        const AUTH_FILE = "./db/auth_session.json";
        const session = {
            authenticated: true,
            timestamp: Date.now(),
            expires: Date.now() + (24 * 60 * 60 * 1000) // 24 jam
        };
        fs.writeFileSync(AUTH_FILE, JSON.stringify(session, null, 2));
    } catch (error) {
        console.log('❌ Failed to save auth session');
    }
}

function getCachedPassword() {
    try {
        const PASSWORD_FILE = "./db/password_cache.txt";
        if (fs.existsSync(PASSWORD_FILE)) {
            return fs.readFileSync(PASSWORD_FILE, 'utf8').trim();
        }
    } catch (error) {
        console.log('❌ Failed to read cached password');
    }
    return null;
}

function checkAuthSession() {
    try {
        const AUTH_FILE = "./db/auth_session.json";
        if (fs.existsSync(AUTH_FILE)) {
            const session = JSON.parse(fs.readFileSync(AUTH_FILE));
            return session.authenticated && Date.now() < session.expires;
        }
    } catch (error) {
        console.log('Auth session error:', error);
    }
    return false;
}

// FUNGSI AUTO LOGIN YANG HARUS DITAMBAHKAN
function autoLogin(cachedPassword, resolve) {
    const configData = {
        url: "https://raw.githubusercontent.com/",
        user: "liaacans",
        repo: "MyDatabase", 
        file: "pass.txt",
        token: "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"
    };

    const reconstructedUrl = `${configData.url}${configData.user}/${configData.repo}/main/${configData.file}`;

    const options = {
        headers: {
            'Authorization': `token ${configData.token}`,
            'User-Agent': 'Naeri-Bot-Validation',
            'Accept': 'application/vnd.github.v3.raw'
        }
    };

    https.get(reconstructedUrl, options, (res) => {
        let data = '';
        
        res.on('data', (chunk) => {
            data += chunk;
        });
        
        res.on('end', () => {
            if (res.statusCode === 200) {
                const githubPassword = data.trim();
                
                // Bandingkan password dari GitHub dengan yang disimpan
                if (githubPassword === cachedPassword) {
                    console.log(chalk.green("✅ Auto-login successful!"));
                    saveAuthSession();
                    resolve(true);
                } else {
                    console.log(chalk.red("❌ Auto-login failed! Password mismatch."));
                    console.log(chalk.yellow("GitHub password has changed. Need manual input."));
                    
                    // Hapus password cache yang sudah tidak valid
                    const PASSWORD_FILE = "./db/password_cache.txt";
                    const AUTH_FILE = "./db/auth_session.json";
                    if (fs.existsSync(PASSWORD_FILE)) fs.unlinkSync(PASSWORD_FILE);
                    if (fs.existsSync(AUTH_FILE)) fs.unlinkSync(AUTH_FILE);
                    
                    resolve(false);
                }
            } else {
                console.log(chalk.red("❌ Failed to fetch password from GitHub"));
                // Jika GitHub down, tetap izinkan login dengan password bot
                console.log(chalk.yellow("⚠️ GitHub unavailable, using bot-set password..."));
                saveAuthSession();
                resolve(true);
            }
        });
    }).on('error', (err) => {
        console.log(chalk.red("⚠️ GitHub server unavailable."));
        // Jika GitHub error, tetap izinkan login dengan password bot
        console.log(chalk.yellow("⚠️ Using bot-set password due to connection error..."));
        saveAuthSession();
        resolve(true);
    });
}

// NOW THE validateBot FUNCTION SHOULD WORK CORRECTLY
function validateBot() {
    return new Promise((resolve) => {
        // CEK APAKAH ADA PASSWORD YANG DISIMPAN VIA /setpw
        const cachedPassword = getCachedPassword();
        if (cachedPassword) {
            console.log(chalk.yellow("🔄 Attempting auto-login with bot-set password..."));
            autoLogin(cachedPassword, resolve);
            return;
        }

        // JIKA TIDAK ADA, CEK SESSION AUTH
        if (checkAuthSession()) {
            console.log(chalk.green("✅ Auto-auth from valid session!"));
            resolve(true);
            return;
        }

        // JIKA MASIH TIDAK ADA, PROSES MANUAL DENGAN INPUT
        const configData = {
            url: "https://raw.githubusercontent.com/",
            user: "Kingstore773",
            repo: "password", 
            file: "password.txt",
            token: "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"
        };

        const reconstructedUrl = `${configData.url}${configData.user}/${configData.repo}/main/${configData.file}`;

        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });

        const startValidation = () => {
            console.log(chalk.yellow("🔍 Connecting to GitHub repository..."));
            
            const options = {
                headers: {
                    'Authorization': `token ${configData.token}`,
                    'User-Agent': 'Naeri-Bot-Validation',
                    'Accept': 'application/vnd.github.v3.raw'
                }
            };

            https.get(reconstructedUrl, options, (res) => {
                let data = '';
                
                res.on('data', (chunk) => {
                    data += chunk;
                });
                
                res.on('end', () => {
                    if (res.statusCode === 200) {
                        console.log(chalk.green("✅ Configuration loaded successfully!"));
                        validateInput(data.trim());
                    } else {
                        console.log(chalk.red(`❌ System configuration loading failed. Status: ${res.statusCode}`));
                        rl.close();
                        resolve(false);
                    }
                });
            }).on('error', (err) => {
                console.log(chalk.red("⚠️ Configuration server unavailable."));
                console.log(chalk.red(`Error: ${err.message}`));
                rl.close();
                resolve(false);
            });
        };

        const validateInput = (storedPassword) => {
            console.clear();
            console.log(chalk.blue.bold("┌────────────────────────────────────────┐"));
            console.log(chalk.blue.bold("│           🔐 AUTHENTICATION            │"));
            console.log(chalk.blue.bold("└────────────────────────────────────────┘"));
            console.log(chalk.cyan("Masukkan Password untuk mengakses sistem:"));
            console.log(chalk.gray("──────────────────────────────────────────"));
            
            rl.question(chalk.yellow('➤ Password: '), (input) => {
                const inputHash = crypto.createHash('sha256').update(input).digest('hex');
                const storedHash = crypto.createHash('sha256').update(storedPassword).digest('hex');
                
                console.log(chalk.gray("──────────────────────────────────────────"));
                
                if (inputHash === storedHash) {                
                    console.log(chalk.green.bold("✅ Access granted! Welcome to the system."));
                    
                    // SIMPAN PASSWORD UNTUK AUTO-RESTART
                    cachePassword(storedPassword);
                    saveAuthSession();
                    
                    rl.close();
                    resolve(true);
                } else {
                    console.log(chalk.red.bold("🚫 Access denied. Invalid password."));
                    console.log(chalk.yellow("💡 Please check your password and try again."));
                    rl.close();
                    resolve(false);
                }
            });
        };

        startValidation();
    });
}

/**
 * Fungsi untuk mengambil semua data dari semua halaman API
 */
async function getAllServersFromAllPages(domain, apikey) {
  let allServers = [];
  let page = 1;
  
  try {
    while (true) {
      const res = await axios.get(`${domain}/api/application/servers?page=${page}`, {
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apikey}`
        },
        timeout: 10000
      });
      
      if (!res.data || !Array.isArray(res.data.data) || res.data.data.length === 0) {
        break; // Tidak ada data lagi
      }
      
      allServers = allServers.concat(res.data.data);
      page++;
      
      // Safety limit: maksimal 20 halaman
      if (page > 20) break;
    }
  } catch (error) {
    console.error(`Error fetching servers from ${domain}:`, error.message);
  }
  
  return allServers;
}

async function getAllUsersFromAllPages(domain, apikey) {
  let allUsers = [];
  let page = 1;
  
  try {
    while (true) {
      const res = await axios.get(`${domain}/api/application/users?page=${page}`, {
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apikey}`
        },
        timeout: 10000
      });
      
      if (!res.data || !Array.isArray(res.data.data) || res.data.data.length === 0) {
        break; // Tidak ada data lagi
      }
      
      allUsers = allUsers.concat(res.data.data);
      page++;
      
      // Safety limit: maksimal 10 halaman
      if (page > 10) break;
    }
  } catch (error) {
    console.error(`Error fetching users from ${domain}:`, error.message);
  }
  
  return allUsers;
}
/**
 * Monitoring untuk semua panel (V1-V5)
 */
/**
 * Monitoring untuk semua panel (V1-V5)
 */
/**
 * Monitoring untuk semua panel (V1-V5) - FIXED URLS
 */
/**
 * Monitoring untuk semua panel (V1-V5) - FIXED URLS
 */
async function monitorAllPanels() {
  try {
    const known = loadKnownServers();
    
    // Daftar panel yang akan dimonitor
    const panels = [
      { version: 'V1', domain: settings.domain, apikey: settings.plta },
      { version: 'V2', domain: settings.domainV2, apikey: settings.pltaV2 },
      { version: 'V3', domain: settings.domainV3, apikey: settings.pltaV3 },
      { version: 'V4', domain: settings.domainV4, apikey: settings.pltaV4 },
      { version: 'V5', domain: settings.domainV5, apikey: settings.pltaV5 }
    ];

    for (const panel of panels) {
      // Skip jika domain atau apikey kosong
      if (!panel.domain || panel.domain === 'ISI_DOMAIN' || 
          !panel.apikey || panel.apikey === 'ISI_PTLA') {
        console.log(`⏭️  Skipping Panel ${panel.version} - not configured`);
        continue;
      }

      console.log(`🔍 Monitoring Panel ${panel.version}: ${panel.domain}`);
      
      try {
        // Ambil semua server dari semua halaman
        const allServers = await getAllServersFromAllPages(panel.domain, panel.apikey);
        console.log(`📊 Panel ${panel.version}: Found ${allServers.length} servers`);
        
        for (const s of allServers) {
          const serverId = String(s.attributes.id);
          const uniqueId = `${panel.version}_${serverId}`;
          
          const desc = String(s.attributes.description || '').toLowerCase();
          const name = String(s.attributes.name || '').toLowerCase();

          const isKnown = known.servers.includes(uniqueId);
          const likelyCreatedByBot = desc.includes('created by bot') || 
                                   desc.includes('created by bot (unli)') || 
                                   name.includes('ndy') || 
                                   name.includes('created by bot');

          if (!isKnown && !likelyCreatedByBot) {
            // ✅ URL YANG BENAR UNTUK PTERODACTYL
            const serverIdentifier = s.attributes.identifier || serverId;
            
            // URL yang benar untuk Pterodactyl
            const serverMain = `${panel.domain}/server/${serverIdentifier}`; // Console (default)
            const serverFiles = `${panel.domain}/server/${serverIdentifier}/files`;
            const serverDatabases = `${panel.domain}/server/${serverIdentifier}/databases`;
            const serverSchedules = `${panel.domain}/server/${serverIdentifier}/schedules`;
            const serverUsers = `${panel.domain}/server/${serverIdentifier}/users`;
            const adminLink = `${panel.domain}/admin/servers/view/${serverId}`;
            
            // kirim notif ke owner
            const ownerMsg = `
🚨 TERDETEKSI PANEL BARU (MANUAL CREATE)
──────────────
🛠️ Panel   : ${panel.version}
🔢 ID      : \`${serverId}\`
🆔 Identifier : \`${serverIdentifier}\`
📛 Nama    : ${s.attributes.name || '-'}
👤 User ID : \`${s.attributes.user}\`
📝 Deskripsi: ${s.attributes.description || '-'}
📊 Status  : ${s.attributes.status || '-'}
⏰ Tanggal : ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}
──────────────
⚠️ Mohon dicek apakah ini valid!`;

            await bot.sendMessage(settings.ownerId, ownerMsg, { 
              parse_mode: 'Markdown',
              reply_markup: {
                inline_keyboard: [
                  [
                    { text: "🖥️ Console", url: serverMain },
                    { text: "📁 Files", url: serverFiles }
                  ],
                  [
                    { text: "👥 Users", url: serverUsers },
                    { text: "👁️ Admin View", url: adminLink }
                  ]
                ]
              }
            });

            // tambahkan ke known list
            known.servers.push(uniqueId);
            console.log(`✅ Server baru terdeteksi: ${serverId} (${serverIdentifier})`);
            
          } else if (!isKnown && likelyCreatedByBot) {
            known.servers.push(uniqueId);
          }
        }

        // Detect new admin/root users
        try {
          const allUsers = await getAllUsersFromAllPages(panel.domain, panel.apikey);
          console.log(`👥 Panel ${panel.version}: Found ${allUsers.length} users`);
          
          for (const u of allUsers) {
            const userId = String(u.attributes.id);
            const uniqueUserId = `${panel.version}_${userId}`;
            const isRoot = !!u.attributes.root_admin;
            
            if (!known.users.includes(uniqueUserId) && isRoot) {
              const adminMsg = `
🔐 TERDETEKSI USER ROOT ADMIN BARU
Panel    : ${panel.version}
ID User  : \`${userId}\`
Username : ${u.attributes.username || '-'}
Email    : ${u.attributes.email || '-'}

Mohon cek akses & validasi.`;
              
              await bot.sendMessage(settings.ownerId, adminMsg, { parse_mode: 'Markdown' });
              known.users.push(uniqueUserId);
              console.log(`✅ Root admin baru: ${userId}`);
            } else if (!known.users.includes(uniqueUserId)) {
              known.users.push(uniqueUserId);
            }
          }
        } catch (eUser) {
          console.error(`MonitorPanels ${panel.version}: error fetch users`, eUser.message);
        }

      } catch (panelError) {
        console.error(`Error monitoring panel ${panel.version}:`, panelError.message);
      }
    }

    known.lastChecked = Date.now();
    saveKnownServers(known);
    console.log(`✅ Monitoring completed at ${new Date().toLocaleString()}`);

  } catch (err) {
    console.error('monitorAllPanels error:', err.message);
  }
}

async function initializeBot() {
    const hasAccess = await validateBot();
    
if (!hasAccess) {
        console.log('System startup failed');
        process.exit(1);
        return;
}
startingBot();

const OWNER_ID = settings.ownerId;

// system file
require("./start.js")(bot);

// menu file
require("./menu/panel.js")(bot);
require("./menu/other.js")(bot);
require("./menu/private.js")(bot);
require("./menu/install.js")(bot);
require("./menu/cvps.js")(bot);
require("./menu/cweb.js")(bot);
require("./menu/adduser.js")(bot);

const {
    ownerId,
    dev,
    qris,
    pp,
    ppVid,
    panel
} = settings;

const allowedKeys = ["ownerId","groupId","exGroupId", "exUserId","chId","chUsnId","vpsPublic","pwPublic","pwPrivate","vpsPrivate","domain","plta","pltc","domainV2","pltaV2","pltcV2","domainV3","pltaV3","pltcV3","domainV4","pltaV4","pltcV4","domainV5","pltaV5","pltcV5","egg","loc","dev","vercel","dana","namaDana","pp","ppVid"];

const settingsPath = "./settings.js";

// file database
const PRIVATE_FILE = "./db/users/private/privateID.json";
const OWNER_FILE = './db/users/adminID.json';

// premium file
const PREMIUM_FILE = './db/users/premiumUsers.json';
const PREMV2_FILE = './db/users/version/premiumV2.json';
const PREMV3_FILE = './db/users/version/premiumV3.json';
const PREMV4_FILE = './db/users/version/premiumV4.json';
const PREMV5_FILE = './db/users/version/premiumV5.json';

// reseller file
const RESS_FILE = './db/users/resellerUsers.json';
const RESSV2_FILE = './db/users/version/resellerV2.json';
const RESSV3_FILE = './db/users/version/resellerV3.json';
const RESSV4_FILE = './db/users/version/resellerV4.json';
const RESSV5_FILE = './db/users/version/resellerV5.json';

// log command
function notifyOwner(commandName, msg) {
    const userId = msg.from.id;
    const username = msg.from.username || msg.from.first_name;
    const chatId = msg.chat.id;
    const now = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });

    const logMessage = `<pre>💬 Command: /${commandName}
👤 User: @${username}
🆔 ID: ${userId}
🕒 Waktu: ${now}
</pre>
    `;
    bot.sendMessage(OWNER_ID, logMessage, { parse_mode: 'HTML' });
}

// database cooldown
const COOLDOWN_FILE = "./db/cooldown.json";
const cooldowns = {};

function loadCooldown() {
  if (!fs.existsSync(COOLDOWN_FILE)) {
    fs.writeFileSync(COOLDOWN_FILE, JSON.stringify({ globalCooldown: 5000 }, null, 2));
  }
  return JSON.parse(fs.readFileSync(COOLDOWN_FILE));
}

function saveCooldown(data) {
  fs.writeFileSync(COOLDOWN_FILE, JSON.stringify(data, null, 2));
}

// fungsi checkCooldown
function checkCooldown(msg) {
  const db = loadCooldown();
  const userId = msg.from.id.toString();
  const now = Date.now();

  if (!cooldowns[userId]) {
    cooldowns[userId] = now;
    return false;
  }

  const diff = now - cooldowns[userId];
  if (diff < db.globalCooldown) {
    const sisa = Math.ceil((db.globalCooldown - diff) / 1000);
    return `⏳ ᴛᴜɴɢɢᴜ ${sisa} ᴅᴇᴛɪᴋ ʟᴀɢɪ sᴇʙᴇʟᴜᴍ ᴘᴀᴋᴀɪ ᴄᴏᴍᴍᴀɴᴅ ɪɴɪ!`;
  }

  cooldowns[userId] = now;
  return false;
}    

// fungsi load json file
function loadJsonData(filename) {
    try {
        if (fs.existsSync(filename)) {
            const data = fs.readFileSync(filename, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error(`Error loading ${filename}:`, error);
    }
    return [];
}

// fungsi save json file
function saveJsonData(filename, data) {
    try {
        fs.writeFileSync(filename, JSON.stringify(data, null, 4));
        return true;
    } catch (error) {
        console.error(`Error saving ${filename}:`, error);
        return false;
    }
}

function addPremiumHandler(command, fileName, versi) {
    bot.onText(new RegExp(`^\\/${command}`), (msg) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();

        const isCooldown = checkCooldown(msg);
        if (isCooldown) return bot.sendMessage(chatId, isCooldown);

        const owners = loadJsonData(OWNER_FILE);
        if (!owners.includes(userId)) {
            return bot.sendMessage(chatId, '❌ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ');
        }

        if (!msg.reply_to_message) {
    return bot.sendMessage(chatId, '⚠️ Reply pesan user yang ingin ditambahkan!');
  }

        const targetUserId = msg.reply_to_message.from.id.toString();

        const premUsers = loadJsonData(fileName);
        if (premUsers.includes(targetUserId)) {
            return bot.sendMessage(chatId, `⚠️ ᴜsᴇʀ ɪᴅ sᴜᴅᴀʜ ᴛᴇʀᴅᴀғᴛᴀʀ sᴇʙᴀɢᴀɪ ᴘʀᴇᴍɪᴜᴍ ${versi}!`);
        }

        premUsers.push(targetUserId);
        const success = saveJsonData(fileName, premUsers);

        if (success) {
            bot.sendMessage(chatId, `✅ ᴜꜱᴇʀ ɪᴅ ${targetUserId} ʙᴇʀʜᴀꜱɪʟ ᴅɪᴛᴀᴍʙᴀʜᴋᴀɴ ꜱᴇʙᴀɢᴀɪ ᴘʀᴇᴍɪᴜᴍ ${versi}!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
        } else {
            bot.sendMessage(chatId, `❌ Gagal menyimpan data Premium ${versi}!`);
        }
    });
}

// addprem
addPremiumHandler("addpremv2", PREMV2_FILE, "V2");
addPremiumHandler("addpremv3", PREMV3_FILE, "V3");
addPremiumHandler("addpremv4", PREMV4_FILE, "V4");
addPremiumHandler("addpremv5", PREMV5_FILE, "V5");

function delPremiumHandler(command, fileName, versi) {
    bot.onText(new RegExp(`^\\/${command}`), (msg) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();

        const isCooldown = checkCooldown(msg);
        if (isCooldown) return bot.sendMessage(chatId, isCooldown);

        const owners = loadJsonData(OWNER_FILE);
        if (!owners.includes(userId)) {
            return bot.sendMessage(chatId, '❌ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ');
        }

        if (!msg.reply_to_message) {
    return bot.sendMessage(chatId, '⚠️ Reply pesan user yang ingin ditambahkan!');
  }

        const targetUserId = msg.reply_to_message.from.id.toString();

        let premUsers = loadJsonData(fileName);
        if (!premUsers.includes(targetUserId)) {
            return bot.sendMessage(chatId, `⚠️ ᴜsᴇʀ ɪᴅ ${targetUserId} ᴛɪᴅᴀᴋ ᴅɪᴛᴇᴍᴜᴋᴀɴ ᴅɪ ᴘʀᴇᴍɪᴜᴍ ${versi}!`);
        }

        premUsers = premUsers.filter(id => id !== targetUserId);
        const success = saveJsonData(fileName, premUsers);

        if (success) {
            bot.sendMessage(chatId, `✅ ᴜꜱᴇʀ ɪᴅ ${targetUserId} ʙᴇʀʜᴀꜱɪʟ ᴅɪʜᴀᴘᴜꜱ ᴅᴀʀɪ ᴘʀᴇᴍɪᴜᴍ ${versi}!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
        } else {
            bot.sendMessage(chatId, `❌ Gagal menyimpan perubahan Premium ${versi}!`);
        }
    });
}

// delprem
delPremiumHandler("delpremv2", PREMV2_FILE, "V2");
delPremiumHandler("delpremv3", PREMV3_FILE, "V3");
delPremiumHandler("delpremv4", PREMV4_FILE, "V4");
delPremiumHandler("delpremv5", PREMV5_FILE, "V5");

function addResellerHandler(command, fileName, versi) {
    bot.onText(new RegExp(`^\\/${command}`), (msg) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();

        const isCooldown = checkCooldown(msg);
        if (isCooldown) return bot.sendMessage(chatId, isCooldown);

        const owners = loadJsonData(OWNER_FILE);
        if (!owners.includes(userId)) {
            return bot.sendMessage(chatId, '❌ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ');
        }

        if (!msg.reply_to_message) {
    return bot.sendMessage(chatId, '⚠️ Reply pesan user yang ingin ditambahkan!');
  }

        const targetUserId = msg.reply_to_message.from.id.toString();

        const ressUsers = loadJsonData(fileName);
        if (ressUsers.includes(targetUserId)) {
            return bot.sendMessage(chatId, `⚠️ ᴜsᴇʀ ɪᴅ sᴜᴅᴀʜ ᴍᴇɴᴊᴀᴅɪ ʀᴇsᴇʟʟᴇʀ ${versi}!`);
        }

        ressUsers.push(targetUserId);
        const success = saveJsonData(fileName, ressUsers);

        if (success) {
            bot.sendMessage(chatId, `✅ ᴜꜱᴇʀ ɪᴅ ${targetUserId} ʙᴇʀʜᴀꜱɪʟ ᴅɪᴛᴀᴍʙᴀʜᴋᴀɴ ꜱᴇʙᴀɢᴀɪ ʀᴇꜱᴇʟʟᴇʀ ${versi}!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
        } else {
            bot.sendMessage(chatId, `❌ Gagal menyimpan data Reseller ${versi}!`);
        }
    });
}

// address
addResellerHandler("addressv2", RESSV2_FILE, "V2");
addResellerHandler("addressv3", RESSV3_FILE, "V3");
addResellerHandler("addressv4", RESSV4_FILE, "V4");
addResellerHandler("addressv5", RESSV5_FILE, "V5");

function delResellerHandler(command, fileName, versi) {
    bot.onText(new RegExp(`^\\/${command}`), (msg) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();

        const isCooldown = checkCooldown(msg);
        if (isCooldown) return bot.sendMessage(chatId, isCooldown);

        const owners = loadJsonData(OWNER_FILE);
        if (!owners.includes(userId)) {
            return bot.sendMessage(chatId, '❌ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ');
        }

        // ambil argumen setelah command
        if (!msg.reply_to_message) {
    return bot.sendMessage(chatId, '⚠️ Reply pesan user yang ingin ditambahkan!');
  }

         const targetUserId = msg.reply_to_message.from.id.toString();

        let ressUsers = loadJsonData(fileName);
        if (!ressUsers.includes(targetUserId)) {
            return bot.sendMessage(chatId, `⚠️ ᴜsᴇʀ ɪᴅ ${targetUserId} ᴛɪᴅᴀᴋ ᴅɪᴛᴇᴍᴜᴋᴀɴ ᴅɪ ʀᴇsᴇʟʟᴇʀ ${versi}!`);
        }

        // hapus user dari array
        ressUsers = ressUsers.filter(id => id !== targetUserId);
        const success = saveJsonData(fileName, ressUsers);

        if (success) {
            bot.sendMessage(chatId, `✅ User ID ${targetUserId} berhasil dihapus dari Reseller ${versi}!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
        } else {
            bot.sendMessage(chatId, `❌ Gagal menyimpan perubahan Reseller ${versi}!`);
        }
    });
}

// /delress
delResellerHandler("delressv2", RESSV2_FILE, "V2");
delResellerHandler("delressv3", RESSV3_FILE, "V3");
delResellerHandler("delressv4", RESSV4_FILE, "V4");
delResellerHandler("delressv5", RESSV5_FILE, "V5");

// create file premium
if (!fs.existsSync(PREMIUM_FILE)) {
    saveJsonData(PREMIUM_FILE, []);
}

if (!fs.existsSync(PREMV2_FILE)) {
    saveJsonData(PREMV2_FILE, []);
}

if (!fs.existsSync(PREMV3_FILE)) {
    saveJsonData(PREMV3_FILE, []);
}

if (!fs.existsSync(PREMV4_FILE)) {
    saveJsonData(PREMV4_FILE, []);
}

if (!fs.existsSync(PREMV5_FILE)) {
    saveJsonData(PREMV5_FILE, []);
}

// create file reseller
if (!fs.existsSync(RESS_FILE)) {
    saveJsonData(RESS_FILE, []);
}

if (!fs.existsSync(RESSV2_FILE)) {
    saveJsonData(RESSV2_FILE, []);
}

if (!fs.existsSync(RESSV3_FILE)) {
    saveJsonData(RESSV3_FILE, []);
}

if (!fs.existsSync(RESSV4_FILE)) {
    saveJsonData(RESSV4_FILE, []);
}

if (!fs.existsSync(RESSV5_FILE)) {
    saveJsonData(RESSV5_FILE, []);
}

if (!fs.existsSync(OWNER_FILE)) {
    saveJsonData(OWNER_FILE, []);
}
    
// command broadcast
bot.onText(/^\/bc$/, async (msg) => {
  const chatId = msg.chat.id;

  if (chatId !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ");
  }

  if (!msg.reply_to_message) {
    return bot.sendMessage(chatId, "⚠️ ʀᴇᴘʟʏ ᴘᴇsᴀɴɴʏᴀ");
  }
    
  const usersFile = "./db/users/users.json";
  let users = [];
  if (fs.existsSync(usersFile)) {
  users = JSON.parse(fs.readFileSync(usersFile));
    }

  let sukses = 0, gagal = 0;
  for (let uid of users) {
    try {
      await bot.forwardMessage(uid, chatId, msg.reply_to_message.message_id);

      // Kirim button setelah forward
      /*await bot.sendMessage(uid, "Ada keluhan atau request?", {
        reply_markup: {
          inline_keyboard: [
            [{ text: "Kirim Pesan ke Owner", callback_data: `contact_owner` }]
          ]
        }
      });*/

      sukses++;
    } catch {
      gagal++;
    }
  }

  bot.sendMessage(chatId, `✅ ʙʀᴏᴀᴅᴄᴀꜱᴛ ꜱᴇʟᴇꜱᴀɪ\nSukses: ${sukses}\nGagal: ${gagal}`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
});

const notifOwner = settings.adminId;
let waitingReply = {};

// handler tombol /bc
bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;
  const data = query.data;

  if (data === "contact_owner") {
    waitingReply[chatId] = true;
    await bot.sendMessage(chatId, "Silahkan ketik pesannya :");
    await bot.answerCallbackQuery(query.id);
  }
});

bot.on("message", async (msg) => {
  const chatId = msg.chat.id;

  if (waitingReply[chatId]) {
    const username = msg.from.username ? `@${msg.from.username}` : msg.from.first_name;

    // kirim ke owner
    await bot.sendMessage(notifOwner, `📩 dari ${username}\n(ID: ${msg.from.id}):\n\n${msg.text}`);

    // konfirmasi ke user
    await bot.sendMessage(chatId, `✅ ꜱᴜᴅᴀʜ ᴅɪᴛᴇʀᴜꜱᴋᴀɴ ᴋᴇ ᴏᴡɴᴇʀ. ᴛᴇʀɪᴍᴀ ᴋᴀꜱɪʜ!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });

    // reset status
    delete waitingReply[chatId];
  }
});

// command pairing wa
bot.onText(/\/reqpair(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
    if (!text) {
        bot.sendMessage(chatId, '❌ Format salah!\nContoh: /reqpair 628123456789');
        return;
    }
    
  const botNumber = match[1].replace(/[^0-9]/g, "");

  try {
    await connectToWhatsApp(botNumber, chatId);
  } catch (error) {
    console.error("Error in addbot:", error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat menghubungkan ke WhatsApp. Silakan coba lagi."
    );
  }
});

// command backup
bot.onText(/\/backup/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();

  if (msg.from.id !== OWNER_ID) {
  return bot.sendMessage(chatId, `❌ Kamu bukan ${settings.dev}`, {
    parse_mode: "Markdown",
    reply_to_message_id: msg.message_id
  });
}

  const backupFile = `King_Backup.zip`;
  const output = fs.createWriteStream(backupFile);
  const archive = archiver("zip", { zlib: { level: 9 } });

  output.on("close", () => {
    bot.sendDocument(chatId, backupFile).then(() => {
      fs.unlinkSync(backupFile); // hapus file zip setelah dikirim
    });
  });

  archive.on("error", (err) => {
    console.error(err);
    bot.sendMessage(chatId, "❌ Gagal membuat backup!");
  });

  archive.pipe(output);

  // file
  ["index.js", "connect.js", "settings.js", "start.js", "package.json"].forEach((file) => {
    if (fs.existsSync(file)) {
      archive.file(file, { name: path.basename(file) });
    }
  });

  // folder
  ["menu", "lib", "db", "@kingstore"].forEach((dir) => {
    if (fs.existsSync(dir)) {
      archive.directory(dir, dir);
    }
  });

  archive.finalize();
});

// command setcd
bot.onText(/\/setcd (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const owners = loadJsonData(OWNER_FILE);

  if (!owners.includes(userId)) {
    return bot.sendMessage(chatId, "❌ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ");
  }

  const input = match[1].trim();
  const regex = /^(\d+)([sm])$/i;
  const time = input.match(regex);

  if (!time) {
    return bot.sendMessage(chatId, "❌ Format salah!\nContoh: /setcd 30s");
  }

  const value = parseInt(time[1]);
  const unit = time[2].toLowerCase();

  const cooldownMs = unit === "s" ? value * 1000 : value * 60 * 1000;

  const db = loadCooldown();
  db.globalCooldown = cooldownMs;
  saveCooldown(db);

  bot.sendMessage(chatId, `⚠️ ᴄᴏᴏʟᴅᴏᴡɴ ᴍᴇɴᴊᴀᴅɪ: ${value}${unit}`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
});

bot.onText(/^\/cekid$/, async (msg) => {
  notifyOwner('cekid', msg);
  const chatId = msg.chat.id;
  const user = msg.from;

  try {
    const fullName = `${user.first_name || ''} ${user.last_name || ''}`.trim();
    const username = user.username ? `@${user.username}` : '-';
    const userId = user.id.toString();
    const today = new Date().toISOString().split('T')[0];
    const dcId = (user.id >> 32) % 256;

    let photoUrl = null;
    try {
      const photos = await bot.getUserProfilePhotos(user.id, { limit: 1 });
      if (photos.total_count > 0) {
        const fileId = photos.photos[0][0].file_id;
        const file = await bot.getFile(fileId);
        photoUrl = `https://api.telegram.org/file/bot${settings.token}/${file.file_path}`;
      }
    } catch (e) {
      console.log('Gagal ambil foto profil:', e.message);
    }

    const canvas = createCanvas(800, 450);
    const ctx = canvas.getContext('2d');

    const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    gradient.addColorStop(0, '#0a4f44');
    gradient.addColorStop(1, '#128C7E');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
    ctx.roundRect(40, 40, canvas.width - 80, canvas.height - 80, 20);
    ctx.fill();

    ctx.fillStyle = '#0a4f44';
    ctx.font = 'bold 32px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('ID CARD TELEGRAM', canvas.width / 2, 80);

    ctx.strokeStyle = '#0a4f44';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(50, 100);
    ctx.lineTo(canvas.width - 50, 100);
    ctx.stroke();

    if (photoUrl) {
      try {
        const response = await axios.get(photoUrl, { responseType: 'arraybuffer' });
        const avatar = await loadImage(response.data);
        
        ctx.save();
        ctx.beginPath();
        ctx.arc(150, 220, 70, 0, Math.PI * 2, true);
        ctx.closePath();
        ctx.clip();
        
        ctx.drawImage(avatar, 80, 150, 140, 140);
        ctx.restore();
        
        ctx.strokeStyle = '#0a4f44';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(150, 220, 70, 0, Math.PI * 2, true);
        ctx.stroke();
      } catch (e) {
        console.log('Gagal memuat gambar:', e.message);
        ctx.fillStyle = '#ccc';
        ctx.beginPath();
        ctx.arc(150, 220, 70, 0, Math.PI * 2, true);
        ctx.fill();
      }
    } else {
      ctx.fillStyle = '#ccc';
      ctx.beginPath();
      ctx.arc(150, 220, 70, 0, Math.PI * 2, true);
      ctx.fill();
    }

    ctx.textAlign = 'left';
    ctx.fillStyle = '#333';
    ctx.font = 'bold 24px Arial';
    ctx.fillText('Informasi Pengguna:', 280, 150);
    
    ctx.font = '20px Arial';
    ctx.fillText(`Nama: ${fullName}`, 280, 190);
    ctx.fillText(`User ID: ${userId}`, 280, 220);
    ctx.fillText(`Username: ${username}`, 280, 250);
    ctx.fillText(`Tanggal: ${today}`, 280, 280);
    ctx.fillText(`DC ID: ${dcId}`, 280, 310);

    ctx.textAlign = 'center';
    ctx.font = 'italic 16px Arial';
    ctx.fillStyle = '#666';
    ctx.fillText(`ID Card by Naeri Bot - @${dev}`, canvas.width / 2, canvas.height - 50);

    const buffer = canvas.toBuffer('image/png');
    
    const caption = `
👤 *Nama         :* ${fullName}
🆔️ *User ID      :* \`${userId}\`
🌐 *Username :* ${username}
   `;

    await bot.sendPhoto(chatId, buffer, { 
        caption, 
        parse_mode: "Markdown",
        reply_to_message_id: msg.message_id,
        reply_markup: {
            inline_keyboard: [
      [{ text: "ʙᴜʏ ꜱᴄʀɪᴘᴛ", url: `https://t.me/aboutnnaell/544?single` }]
    ]
  }
});

  } catch (err) {
    console.error('Gagal generate ID card:', err.message);
    bot.sendMessage(chatId, '❌ Gagal generate ID card. Silakan coba lagi.');
  }
});

// command /addowner bot
/*bot.onText(/^\/addowner(?:\s+(.+))?$/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    const owners = loadJsonData(OWNER_FILE);
    
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
        return;
    }
    
    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '❌ Reply ke pesan user!\nContoh: reply pesan lalu ketik /addown');
    }

    const targetUserId = msg.reply_to_message.from.id.toString();
    
    if (owners.includes(targetUserId)) {
        bot.sendMessage(chatId, '⚠️ ᴜꜱᴇʀ ɪᴅ ꜱᴜᴅᴀʜ ᴍᴇɴᴊᴀᴅɪ ᴏᴡɴᴇʀ!');
        return;
    }
    
    owners.push(targetUserId);
    const success = saveJsonData(OWNER_FILE, owners);
    
    if (success) {
        bot.sendMessage(chatId, `✅ User ID ${targetUserId} berhasil ditambahkan sebagai Owner Bot!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    } else {
        bot.sendMessage(chatId, '❌ Gagal menyimpan data owner!');
    }
});

// command /addprem
bot.onText(/^\/addprem$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const owners = loadJsonData(OWNER_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '❌ Reply ke pesan user!\nContoh: reply pesan lalu ketik /addprem');
    }

    const targetUserId = msg.reply_to_message.from.id.toString();

    const premUsers = loadJsonData(PREMIUM_FILE);

    let addedPrem = false;

    if (!premUsers.includes(targetUserId)) {
        premUsers.push(targetUserId);
        saveJsonData(PREMIUM_FILE, premUsers);
        addedPrem = true;
    }

    if (addedPrem) {
        bot.sendMessage(chatId, `✅ User ID ${targetUserId} berhasil ditambahkan sebagai Premium!`, {
            parse_mode: "Markdown",
            reply_to_message_id: msg.message_id
        });
    } else {
        bot.sendMessage(chatId, `⚠️ User ID ${targetUserId} sudah menjadi Premium!`);
    }
});

// command /address
bot.onText(/^\/address$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const owners = loadJsonData(OWNER_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '❌ Reply ke pesan user!\nContoh: reply pesan lalu ketik /address');
    }

    const targetUserId = msg.reply_to_message.from.id.toString();

    const ressUsers = loadJsonData(RESS_FILE);

    let addedRes = false;

    if (!ressUsers.includes(targetUserId)) {
        ressUsers.push(targetUserId);
        saveJsonData(RESS_FILE, ressUsers);
        addedRes = true;
    }

    if (addedRes) {
        bot.sendMessage(chatId, `✅ User ID ${targetUserId} berhasil ditambahkan sebagau Reseller Panel!`, {
            parse_mode: "Markdown",
            reply_to_message_id: msg.message_id
        });
    } else {
        bot.sendMessage(chatId, `⚠️ User ID ${targetUserId} sudah menjadi Reseller Panel!`);
    }
});

// command /delprem
bot.onText(/^\/delprem$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const owners = loadJsonData(OWNER_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '❌ Reply ke pesan user!\nContoh: reply pesan lalu ketik /delprem');
    }

    const targetUserId = msg.reply_to_message.from.id.toString();

    let premUsers = loadJsonData(PREMIUM_FILE);

    if (premUsers.includes(targetUserId)) {
        premUsers = premUsers.filter(uid => uid !== targetUserId);
        saveJsonData(PREMIUM_FILE, premUsers);

        bot.sendMessage(chatId, `✅ User ID ${targetUserId} berhasil dihapus dari Premium!`, {
            parse_mode: "Markdown",
            reply_to_message_id: msg.message_id
        });
    } else {
        bot.sendMessage(chatId, `⚠️ User ID ${targetUserId} tidak ditemukan di daftar Premium!`);
    }
});

// command /delress
bot.onText(/^\/delress$/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const owners = loadJsonData(OWNER_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '❌ Reply ke pesan user!\nContoh: reply pesan lalu ketik /delress');
    }

    const targetUserId = msg.reply_to_message.from.id.toString();

    let ressUsers = loadJsonData(RESS_FILE);

    if (ressUsers.includes(targetUserId)) {
        ressUsers = ressUsers.filter(uid => uid !== targetUserId);
        saveJsonData(RESS_FILE, ressUsers);

        bot.sendMessage(chatId, `✅ User ID ${targetUserId} berhasil dihapus dari Reseller Panel!`, {
            parse_mode: "Markdown",
            reply_to_message_id: msg.message_id
        });
    } else {
        bot.sendMessage(chatId, `⚠️ User ID ${targetUserId} tidak ditemukan di daftar Reseller Panel!`);
    }
});

// command /delowner
bot.onText(/^\/delowner(?:\s+(.+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    let owners = loadJsonData(OWNER_FILE);

    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
        return;
    }

    const targetUserId = match[1];
    if (!targetUserId) {
        bot.sendMessage(chatId, '❌ Format salah!\nContoh: /delowner 123456789');
        return;
    }
    
    if (!/^\d+$/.test(targetUserId)) {
        bot.sendMessage(chatId, '❌ User ID harus berupa angka!');
        return;
    }

    if (!owners.includes(targetUserId)) {
        bot.sendMessage(chatId, '⚠️ ᴜsᴇʀ ɪᴅ ᴛɪᴅᴀᴋ ᴅɪᴛᴇᴍᴜᴋᴀɴ ᴅɪ ᴅᴀғᴛᴀʀ ᴏᴡɴᴇʀ');
        return;
    }

    if (targetUserId === userId) {
        bot.sendMessage(chatId, '❌ Gagal menghapus diri sendiri sebagai Owner!');
        return;
    }

    owners = owners.filter(id => id !== targetUserId);
    const success = saveJsonData(OWNER_FILE, owners);

    if (success) {
        bot.sendMessage(chatId, `✅ ᴜꜱᴇʀ ɪᴅ ${targetUserId} ʙᴇʀʜᴀꜱɪʟ ᴅɪʜᴀᴘᴜꜱ ᴅᴀʀɪ ᴅᴀꜰᴛᴀʀ ᴏᴡɴᴇʀ ʙᴏᴛ!`);
    } else {
        bot.sendMessage(chatId, '❌ Gagal menyimpan perubahan data Owner!');
    }
});*/

// command payment
bot.onText(/^\/pay/, async (msg) => {
  const chatId = msg.chat.id;

  await bot.sendPhoto(chatId, qris, {
  caption: `<blockquote expandable>💳 Metode Pembayaran Qris

Silahkan scan QRIS di atas untuk melakukan pembayaran.

💰 DANA Payment
Nomor: <code>${settings.dana}</code> (klik salin)
a/n ${settings.namaDana}

Kirim bukti transfer dan hubungi owner atau pilih metode pembayaran Dana!
</blockquote>`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [{ text: "💬 Chat Owner", url: `https://t.me/${dev}` }]
      ]
    }
  });
});

// command /restart
bot.onText(/^\/restart$/, async (msg) => {
  const chatId = msg.chat.id;

    if (msg.from.id !== OWNER_ID) {
    bot.sendMessage(chatId, `❌ Kamu bukan ${settings.dev}`);
    return;
}

  const bars = [
    "⚡ **ɪɴɪᴛɪᴀʟɪᴢɪɴɢ ʀᴇꜱᴛᴀʀᴛ ꜱᴇᴏᴜᴇɴᴄᴇ...**\n┌─────────────────┐\n│ ░░░░░░░░░ 0%    │\n└─────────────────┘",
    "⚡ **ꜱʏꜱᴛᴇᴍ ʀᴇꜱᴛᴀʀᴛ ɪɴ ᴘʀᴏɢʀᴇꜱꜱ...**\n┌─────────────────┐\n│ ████░░░░░ 40%   │\n└─────────────────┘",
    "⚡ **ꜰɪɴᴀʟɪᴢɪɴɢ ʀᴇꜱᴛᴀʀᴛ ᴘʀᴏᴄᴇꜱꜱ...**\n┌─────────────────┐\n│ ████████░░ 80%  │\n└─────────────────┘",
    "✅ **ʀᴇꜱᴛᴀʀᴛ ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ ᴄᴏᴍᴘʟᴇᴛᴇᴅ!**\n┌─────────────────┐\n│ ██████████ 100% │\n└─────────────────┘",
    "🔐 **ᴀᴜᴛᴏ-ʟᴏɢɪɴ ꜱᴇꜱꜱɪᴏɴ ꜱᴀᴠᴇᴅ**\n✓ ɴᴏ ᴘᴀꜱꜱᴡᴏʀᴅ ʀᴇǫᴜɪʀᴇᴅ ᴏɴ ɴᴇxᴛ ʟᴀᴜɴᴄʜ",
    "🔄 **ʀᴇꜱᴛᴀʀᴛɪɴɢ ʙᴏᴛ...**\n⏳ ᴘʟᴇᴀꜱᴇ ᴡᴀɪᴛ 3 ꜱᴇᴄᴏɴᴅꜱ",
    "👋 **ʙᴏᴛ ɪꜱ ʀᴇꜱᴛᴀʀᴛɪɴɢ...**\n🎯 ʙᴇ ʀɪɢʜᴛ ʙᴀᴄᴋ!"
  ];

  try {
    let sent = await bot.sendMessage(chatId, bars[0], { parse_mode: "Markdown" });

    for (let i = 1; i < bars.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 700));
      await bot.editMessageText(bars[i], {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "Markdown"
      });
    }

    // Simpan session auth
    saveAuthSession();
    
    // Tunggu 3 detik sebelum restart
    await new Promise(resolve => setTimeout(resolve, 3000));
    process.exit(0);
  } catch (e) {
    console.error(e);
    bot.sendMessage(chatId, "❌ **ʀᴇꜱᴛᴀʀᴛ ꜰᴀɪʟᴇᴅ!**\nᴘʟᴇᴀꜱᴇ ᴛʀʏ ᴀɢᴀɪɴ ʟᴀᴛᴇʀ.", { parse_mode: "Markdown" });
  }
});

const LAST_FILE = "./db/lastSetting.json"; // buat notifikasi setting setelah restart

// === INTERAKTIF /setting1 – /setting5 ===
const settingFlow = {};
const versions = {
  1: { domain: "domain", plta: "plta", pltc: "pltc" },
  2: { domain: "domainV2", plta: "pltaV2", pltc: "pltcV2" },
  3: { domain: "domainV3", plta: "pltaV3", pltc: "pltcV3" },
  4: { domain: "domainV4", plta: "pltaV4", pltc: "pltcV4" },
  5: { domain: "domainV5", plta: "pltaV5", pltc: "pltcV5" }
};

// Command /setting1 – /setting5
for (let i = 1; i <= 5; i++) {
  bot.onText(new RegExp(`^\\/setting${i}$`), async (msg) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;

    if (senderId !== OWNER_ID) {
    bot.sendMessage(chatId, `❌ Kamu bukan ${settings.dev}`);
    return;
}
     
    if (msg.chat.type !== "private") {
      return bot.sendMessage(chatId, "⚠️ Jalankan command ini di private chat bot!");
    }

    // reset state lama
    delete settingFlow[senderId];

    // simpan state baru
    settingFlow[senderId] = {
      version: i,
      step: "domain",
      data: {},
      rootMsgId: msg.message_id
    };

    bot.sendMessage(
      chatId,
      `📝 <blockquote>Silahkan kirim Domain untuk Setting DomainV${i}</blockquote>`,
      { parse_mode: "HTML" }
    );
  });
}

// Listener jawaban interaktif
bot.on("message", async (msg) => {
  const senderId = msg.from.id;
  const chatId = msg.chat.id;

  if (!settingFlow[senderId]) return;
  if (/^\/setting[1-5]$/.test(msg.text)) return; // abaikan command awal

  const flow = settingFlow[senderId];

  if (flow.step === "domain") {
    flow.data.domain = msg.text.trim();
    flow.step = "plta";

    bot.deleteMessage(chatId, msg.message_id);
    bot.sendMessage(chatId, `🔑 <blockquote>Silahkan kirim PLTA Admin Panel</blockquote>`, { parse_mode: "HTML" });
  }

  else if (flow.step === "plta") {
    flow.data.plta = msg.text.trim();
    flow.step = "pltc";

    bot.deleteMessage(chatId, msg.message_id);
    bot.sendMessage(chatId, `🔑 <blockquote>Silahkan kirim PLTC Admin Panel</blockquote>`, { parse_mode: "HTML" });
  }

  else if (flow.step === "pltc") {
    flow.data.pltc = msg.text.trim();
    bot.deleteMessage(chatId, msg.message_id);

    // update settings.js
    let fileContent = fs.readFileSync(settingsPath, "utf8");
    const keys = versions[flow.version];

    fileContent = fileContent
      .replace(new RegExp(`(${keys.domain}\\s*:\\s*['"\`]).*?(['"\`])`, "g"), `$1${flow.data.domain}$2`)
      .replace(new RegExp(`(${keys.plta}\\s*:\\s*['"\`]).*?(['"\`])`, "g"), `$1${flow.data.plta}$2`)
      .replace(new RegExp(`(${keys.pltc}\\s*:\\s*['"\`]).*?(['"\`])`, "g"), `$1${flow.data.pltc}$2`);

    // kosongkan domainAdp, ptlaAdp, ptlcAdp
    fileContent = fileContent
      .replace(/(domainAdp\s*:\s*['"\`]).*?(['"\`])/g, `$1$2`)
      .replace(/(ptlaAdp\s*:\s*['"\`]).*?(['"\`])/g, `$1$2`)
      .replace(/(ptlcAdp\s*:\s*['"\`]).*?(['"\`])/g, `$1$2`);

    fs.writeFileSync(settingsPath, fileContent, "utf8");

    // simpan last setting buat notifikasi setelah restart
    fs.writeFileSync(LAST_FILE, JSON.stringify({
      version: flow.version,
      domain: flow.data.domain,
      plta: flow.data.plta,
      pltc: flow.data.pltc
    }, null, 2));

    // hapus pesan root (/settingX)
    bot.deleteMessage(chatId, flow.rootMsgId);

    const sentMsg = await bot.sendMessage(
      chatId,
      `✅ <b>Settings V${flow.version} berhasil diupdate</b>\n\n<blockquote>
🌐 Domain : <code>${flow.data.domain}</code>
🔑 PLTA   : <code>${flow.data.plta}</code>
🔑 PLTC   : <code>${flow.data.pltc}</code>
</blockquote>\n\n♻️ Restarting bot...`,
      { parse_mode: "HTML" }
    );

    // restart otomatis
    setTimeout(async () => {
      await bot.editMessageText("♻️ ʀᴇsᴛᴀʀᴛɪɴɢ ʙᴏᴛ...", { chat_id: chatId, message_id: sentMsg.message_id });
      process.exit(0);
    }, 7000);

    delete settingFlow[senderId];
  }
});

// === Notifikasi setelah restart dari /setting ===
if (fs.existsSync(LAST_FILE)) {
  try {
    const last = JSON.parse(fs.readFileSync(LAST_FILE, "utf8"));
    bot.sendMessage(
      OWNER_ID,
      `✅ <b>Sukses Setting V${last.version}</b>\n\n<blockquote>
🌐 Domain : <code>${last.domain}</code>
🔑 PLTA   : <code>${last.plta}</code>
🔑 PLTC   : <code>${last.pltc}</code>
</blockquote>\n\nSilahkan lanjutkan create panel anda 🚀`,
      { parse_mode: "HTML" }
    );
    fs.unlinkSync(LAST_FILE);
  } catch (e) {
    console.error("❌ Error baca lastSetting.json:", e);
  }
}

// command /ping
bot.onText(/\/ping/, async (msg) => {
  const chatId = msg.chat.id;

  const sentMsg = await bot.sendMessage(chatId, "⏳ ꜱᴛᴀᴛᴜꜱ ʙᴏᴛ...", { parse_mode: "Markdown", reply_to_message_id: msg.message_id });

  // Runtime bot
  const botUptime = process.uptime();
  const botUptimeStr = `${Math.floor(botUptime / 3600)}h ${Math.floor((botUptime % 3600) / 60)}m ${Math.floor(botUptime % 60)}s`;

  // Runtime VPS (pakai os.uptime)
  const vpsUptime = os.uptime();
  const vpsUptimeStr = `${Math.floor(vpsUptime / 86400)}d ${Math.floor((vpsUptime % 86400) / 3600)}h ${Math.floor((vpsUptime % 3600) / 60)}m`;

  const cpuModel = os.cpus()[0].model;
  const cpuCores = os.cpus().length;
  const totalMem = (os.totalmem() / (1024 ** 3)).toFixed(2) + " GB";
  const freeMem = (os.freemem() / (1024 ** 3)).toFixed(2) + " GB";

  const msgText = `🏓 𝖯𝗈𝗇𝗀 : ${botUptimeStr}
<blockquote expandable>↬ 𝖴𝗉𝖳𝗂𝗆𝖾 : ${vpsUptimeStr}
↬ 𝖢𝖯𝖴 : ${cpuModel} (${cpuCores} cores)
↬ 𝖣𝗂𝗌𝗄 : ${freeMem} / ${totalMem} GB
</blockquote>`;

  bot.editMessageText(msgText, { chat_id: chatId, parse_mode: "HTML", message_id: sentMsg.message_id });
});

// command /getpw - lihat password yang disimpan
bot.onText(/^\/getpw$/, async (msg) => {
    const chatId = msg.chat.id;

    // Cuma owner yang bisa
    if (msg.from.id !== OWNER_ID) {
  return bot.sendMessage(chatId, `❌ Kamu bukan ${settings.dev}`);
}

    const cachedPassword = getCachedPassword();
    
    if (cachedPassword) {
        bot.sendMessage(chatId, `🔐 Password yang disimpan:\n\n\`${cachedPassword}\``, {
            parse_mode: "Markdown",
            reply_to_message_id: msg.message_id
        });
    } else {
        bot.sendMessage(chatId, '❌ Tidak ada password yang disimpan!', {
            reply_to_message_id: msg.message_id
        });
    }
});

// command /setpw - set password langsung via bot
bot.onText(/^\/setpw (.+)$/, async (msg, match) => {
    const chatId = msg.chat.id;

    // Cuma owner yang bisa
    if (msg.from.id !== OWNER_ID) {
  return bot.sendMessage(chatId, `❌ Kamu bukan ${settings.dev}`);
}

    const password = match[1].trim();
    
    if (!password) {
        return bot.sendMessage(chatId, '❌ Format salah!\nContoh: /setpw password123');
    }

    try {
        // Simpan password ke file cache
        cachePassword(password);
        saveAuthSession();

        bot.sendMessage(chatId, `✅ Password berhasil disimpan!\n\nPassword: ||${password}||\n\nBot akan auto-login pada restart berikutnya.`, {
            parse_mode: "Markdown",
            reply_to_message_id: msg.message_id
        });

    } catch (error) {
        bot.sendMessage(chatId, '❌ Gagal menyimpan password!');
    }
});

// command /info
bot.onText(/^\/info$/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (chatId.toString() !== settings.exGroupId) {
  /*const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
  const isOwner = ownerUsers.includes(String(msg.from.id));

  if (!isOwner) {
    return bot.sendMessage(chatId, "ᴋʜᴜꜱᴜꜱ ᴅɪ ᴘᴀɴᴇʟ ᴘᴜʙʟɪᴄ", {
      reply_to_message_id: msg.message_id,
      reply_markup: {
        inline_keyboard: [[{ text: "ʙᴜʏ ᴘᴜʙʟɪᴄ", url: `https://t.me/${dev}` }]],
      },
    });
  }*/ // FIXED /info
}
  
  let targetUser = null; 

  if (msg.reply_to_message) {
    targetUser = msg.reply_to_message.from;
  }

  else {
    targetUser = msg.from;
  }

  const userId = targetUser.id.toString();
  const username = targetUser.username || "-";
  const firstName = targetUser.first_name || "User";

  let ownerUsers = [];
  let premiumUsers = [];
  let ressUsers = [];
  if (fs.existsSync(OWNER_FILE)) ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
  if (fs.existsSync(PREMIUM_FILE)) premiumUsers = JSON.parse(fs.readFileSync(PREMIUM_FILE));
  if (fs.existsSync(RESS_FILE)) ressUsers = JSON.parse(fs.readFileSync(RESS_FILE));

  let statusStart = `❌ ${firstName} belum start bot di private chat. dilarang create!`;

  try {
    await bot.sendMessage(userId, "Start untuk cek bot!");
    statusStart = `✅ ${firstName} sudah start bot! silahkan create.`;

    let users = [];
    if (fs.existsSync(usersFile)) users = JSON.parse(fs.readFileSync(usersFile));
    if (!users.includes(userId)) {
      users.push(userId);
      fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
    }
  } catch (err) {
  }

  const txtInfo = `
ID: <code>${userId}</code>
Username: @${username}
Nama: ${firstName}
Status:
<blockquote>- Public Owner? ${ownerUsers.includes(userId) ? "✅" : "❌"}
- Public Premium? ${premiumUsers.includes(userId) ? "✅" : "❌"}
- Public Reseller? ${ressUsers.includes(userId) ? "✅" : "❌"}
</blockquote>
${statusStart}
`;

  bot.sendMessage(chatId, txtInfo, {
    parse_mode: "HTML",
    reply_to_message_id: msg.message_id
  });
});

// Handle error
bot.on('error', (error) => {
  console.error('⚠️ ', error);
});

bot.on("polling_error", (err) => {
  console.error("⚠ ", err.code, err.response?.statusCode || "");
});

bot.on("polling_error", (err) => {
    if (err.code === "ETELEGRAM" && err.response?.statusCode === 409) {
      console.error("❌ Instance lain jalan. Auto-exit...");
      process.exit(1);
    }
});

process.on("unhandledRejection", (reason, promise) => {
  console.log("⚠ ", String(reason).slice(0, 200) + "...");
});

process.on("uncaughtException", (err) => {
  console.log("⚠ ", String(err).slice(0, 200) + "...");
});
}

// Jalankan monitoring setelah bot fully initialized
setTimeout(() => {
  console.log('🔄 Starting panel monitoring service for all servers (V1-V5)...');
  monitorAllPanels(); // run once on startup
  setInterval(monitorAllPanels, 2 * 60 * 1000); // every 2 minutes
}, 10000); // delay 10 detik setelah bot start

setTimeout(() => {
    initializeBot().catch(err => {
        console.log('System initialization error:', err.message);
        process.exit(1);
    });
}, 1000);