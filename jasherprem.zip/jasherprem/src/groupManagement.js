const { Group, User } = require('../lib/database');
const { log } = require('../lib/utils');

// Handler ketika bot ditambahkan ke grup
async function handleNewChatMembers(ctx) {
  if (ctx.message.new_chat_members) {
    for (const member of ctx.message.new_chat_members) {
      if (member.is_bot && member.username === ctx.botInfo.username) {
        // Bot ditambahkan ke grup
        try {
          const chat = await ctx.getChat();
          let group = await Group.findOne({ groupId: chat.id });
          
          if (!group) {
            group = new Group({
              groupId: chat.id,
              title: chat.title,
              username: chat.username
            });
            await group.save();
            log(`Bot ditambahkan ke grup: ${chat.title} (${chat.id})`);
          } else if (!group.isActive) {
            group.isActive = true;
            await group.save();
            log(`Bot kembali ditambahkan ke grup: ${chat.title} (${chat.id})`);
          }
          
          // Kirim pesan sambutan
          await ctx.reply(
            `Halo! Saya adalah Jasher Bot Premium.\n\n` +
            `Gunakan /help untuk melihat fitur yang tersedia.`
          );
        } catch (error) {
          log(`Error handling new group: ${error.message}`);
        }
      }
    }
  }
}

// Handler ketika bot dihapus dari grup
async function handleLeftChatMember(ctx) {
  if (ctx.message.left_chat_member) {
    const leftMember = ctx.message.left_chat_member;
    
    if (leftMember.is_bot && leftMember.username === ctx.botInfo.username) {
      // Bot dihapus dari grup
      try {
        const group = await Group.findOne({ groupId: ctx.chat.id });
        if (group) {
          group.isActive = false;
          await group.save();
          log(`Bot dihapus dari grup: ${group.title} (${group.groupId})`);
        }
      } catch (error) {
        log(`Error handling left group: ${error.message}`);
      }
    }
  }
}

// Middleware untuk menangani pesan grup
async function handleGroupMessage(ctx, next) {
  if (ctx.chat.type === 'private') {
    await next();
    return;
  }
  
  try {
    // Cek apakah grup aktif
    const group = await Group.findOne({ groupId: ctx.chat.id });
    if (!group || !group.isActive) {
      return;
    }
    
    // Terapkan pengaturan grup
    if (group.settings.antispam) {
      // Implementasi antispam
      // ...
    }
    
    if (group.settings.noevent) {
      // Blokir event messages
      if (ctx.message && (ctx.message.new_chat_members || ctx.message.left_chat_member)) {
        await ctx.deleteMessage();
        return;
      }
    }
    
    if (group.settings.nolinks) {
      // Blokir tautan
      if (ctx.message && ctx.message.text && /https?:\/\/[^\s]+/.test(ctx.message.text)) {
        await ctx.deleteMessage();
        await ctx.reply('❌ Tautan tidak diizinkan di grup ini!');
        return;
      }
    }
    
    if (group.settings.noforwards) {
      // Blokir pesan yang diteruskan
      if (ctx.message && ctx.message.forward_from) {
        await ctx.deleteMessage();
        await ctx.reply('❌ Meneruskan pesan tidak diizinkan di grup ini!');
        return;
      }
    }
    
    if (group.settings.nocontacts) {
      // Blokir kontak
      if (ctx.message && ctx.message.contact) {
        await ctx.deleteMessage();
        await ctx.reply('❌ Berbagi kontak tidak diizinkan di grup ini!');
        return;
      }
    }
    
    if (group.settings.nohashtags) {
      // Blokir hashtag
      if (ctx.message && ctx.message.text && /#\w+/.test(ctx.message.text)) {
        await ctx.deleteMessage();
        await ctx.reply('❌ Hashtag tidak diizinkan di grup ini!');
        return;
      }
    }
    
    if (group.settings.nocommands) {
      // Blokir commands dari non-admin
      if (ctx.message && ctx.message.text && ctx.message.text.startsWith('/')) {
        try {
          const member = await ctx.getChatMember(ctx.from.id);
          if (!['administrator', 'creator'].includes(member.status)) {
            await ctx.deleteMessage();
            await ctx.reply('❌ Hanya admin yang dapat menggunakan commands di grup ini!');
            return;
          }
        } catch (error) {
          // Jika gagal memeriksa status, biarkan pesan lolos
        }
      }
    }
    
    await next();
  } catch (error) {
    log(`Error handling group message: ${error.message}`);
    await next();
  }
}

module.exports = {
  handleNewChatMembers,
  handleLeftChatMember,
  handleGroupMessage
};