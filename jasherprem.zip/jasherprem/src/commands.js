const { Telegraf, Markup } = require('telegraf');
const moment = require('moment-timezone');
const { User, Premium, Group, Blacklist } = require('../lib/database');
const { 
  isPremium, 
  addPremium, 
  reducePremium, 
  isBlacklisted, 
  addBlacklist, 
  removeBlacklist,
  getGroups,
  addGroup,
  removeGroup,
  deactivateGroup,
  getAllUsers,
  log,
  runtime
} = require('../lib/utils');
const { 
  obfuscateTimeLocked,
  obfuscateQuantum,
  getSiuCalcrickObfuscationConfig,
  getCustomObfuscationConfig,
  getNebulaObfuscationConfig,
  getNovaObfuscationConfig,
  getStrongObfuscationConfig,
  getArabObfuscationConfig,
  getJapanxArabObfuscationConfig,
  getJapanObfuscationConfig
} = require('./obf');

const JsConfuser = require('js-confuser');
const fs = require('fs-extra');
const path = require('path');
const fetch = require('node-fetch');
const webcrack = require('webcrack');

// Inisialisasi database
const userDB = new User();
const premiumDB = new Premium();
const groupDB = new Group();
const blacklistDB = new Blacklist();

// Fungsi untuk membuat menu utama
function mainMenu(ctx) {
  const username = ctx.from.username || ctx.from.first_name;
  const isCreator = global.ADMINS.includes(ctx.from.id);
  
  return ctx.replyWithPhoto(
    'https://f.top4top.io/p_3530xky9e4.jpg',
    {
      caption: `
╭─❒ 「 User Info 」 
├ Creator : @${global.DEVELOPER}
├ Name : @${username}
├ Profile : @${ctx.from.username || ctx.from.first_name}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreator ? 'True' : 'False'}

Silahkan pilih button dibawah ini!`,
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [
          Markup.button.callback('Jasher Menu', 'jasher_menu'),
          Markup.button.callback('Owner Menu', 'owner_menu')
        ],
        [
          Markup.button.callback('Obf Menu', 'obf_menu'),
          Markup.button.callback('Main Menu', 'main_menu')
        ]
      ])
    }
  );
}

// Command start
function setupStartCommand(bot) {
  bot.start(async (ctx) => {
    userDB.add(ctx.from.id);
    return mainMenu(ctx);
  });
}

// Command help
function setupHelpCommand(bot) {
  bot.help((ctx) => {
    return ctx.replyWithMarkdown(`
🤖 *BOT JASHER PREMIUM*

*Fitur Utama:*
- Obfuscation JavaScript dengan berbagai metode
- Sistem premium berlangganan
- Broadcast ke semua pengguna
- Manajemen grup

*Cara Penggunaan:*
1. Kirim file JavaScript yang ingin diobfuscate
2. Balas file tersebut dengan command obfuscation yang diinginkan
3. Tunggu proses selesai
4. File hasil akan dikirimkan

*Daftar Command Obfuscation:*
/enc [hari] - Time-Locked Encryption
/enc2 [teks] - Custom Encryption
/enc3 - Hardened Mandarin
/enc4 - Hardened Arab
/enc5 - Calcrick Chaos Core
/japan - Hardened Japan
/nebula - Nebula Polymorphic Storm
/quantum - Quantum Vortex Encryption
/var - Var Dynamic Obfuscation
/zenc - Invisible Encryption
/deobfuscate - Deobfuscate JavaScript

*Premium Features:*
- Tambah 3 hari premium dengan menambahkan bot ke grup
- Share VIP untuk broadcast lebih cepat

Gunakan /menu untuk melihat menu utama.
    `);
  });
}

// Command menu
function setupMenuCommand(bot) {
  bot.command('menu', (ctx) => {
    return mainMenu(ctx);
  });
}

// Command untuk mengecek premium
function setupPremiumCommand(bot) {
  bot.command('premium', (ctx) => {
    const userId = ctx.from.id;
    const premiumData = premiumDB.get(userId);
    
    if (premiumData && premiumDB.isValid(userId)) {
      const expiryDate = new Date(premiumData.expiry);
      const remainingDays = Math.ceil((premiumData.expiry - Date.now()) / (1000 * 60 * 60 * 24));
      
      return ctx.replyWithMarkdown(`
╭─❒ 「 PREMIUM STATUS 」 
├ Status : ✅ AKTIF
├ Added : ${new Date(premiumData.added).toLocaleDateString('id-ID')}
├ Expiry : ${expiryDate.toLocaleDateString('id-ID')}
├ Sisa Hari : ${remainingDays} hari
╰❒ Package : ${premiumData.days} hari
      `);
    } else {
      return ctx.replyWithMarkdown(`
╭─❒ 「 PREMIUM STATUS 」 
├ Status : ❌ NON-AKTIF
├ Info : Anda tidak memiliki akses premium
├ Cara Dapatkan : Tambah bot ke grup untuk +3 hari
╰❒ Upgrade : Hubungi owner untuk premium berbayar
      `);
    }
  });
}

// Command untuk menambah premium (owner only)
function setupAddPremCommand(bot) {
  bot.command('addprem', (ctx) => {
    if (!global.ADMINS.includes(ctx.from.id)) {
      return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
    }
    
    const args = ctx.message.text.split(' ');
    if (args.length < 3) {
      return ctx.reply('❌ Format: /addprem [user_id] [days]');
    }
    
    const userId = args[1];
    const days = parseInt(args[2]);
    
    if (isNaN(days) || days <= 0) {
      return ctx.reply('❌ Jumlah hari harus angka positif!');
    }
    
    premiumDB.add(userId, days);
    return ctx.reply(`✅ Berhasil menambahkan ${days} hari premium untuk user ${userId}`);
  });
}

// Command untuk menghapus premium (owner only)
function setupDelPremCommand(bot) {
  bot.command('delprem', (ctx) => {
    if (!global.ADMINS.includes(ctx.from.id)) {
      return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
    }
    
    const args = ctx.message.text.split(' ');
    if (args.length < 2) {
      return ctx.reply('❌ Format: /delprem [user_id]');
    }
    
    const userId = args[1];
    premiumDB.remove(userId);
    return ctx.reply(`✅ Berhasil menghapus premium untuk user ${userId}`);
  });
}

// Command untuk melihat daftar premium (owner only)
function setupListPremCommand(bot) {
  bot.command('listprem', (ctx) => {
    if (!global.ADMINS.includes(ctx.from.id)) {
      return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
    }
    
    const premiumUsers = premiumDB.getAll();
    let message = '╭─❒ 「 PREMIUM USERS 」\n';
    
    if (Object.keys(premiumUsers).length === 0) {
      message += '├ Tidak ada user premium\n';
    } else {
      const now = Date.now();
      Object.entries(premiumUsers).forEach(([userId, data], index) => {
        const isValid = data.expiry > now;
        const remainingDays = Math.ceil((data.expiry - now) / (1000 * 60 * 60 * 24));
        message += `├ ${index + 1}. User: ${userId} | ${isValid ? `✅ (${remainingDays} hari)` : '❌'}\n`;
      });
    }
    
    message += '╰❒ Total: ' + Object.keys(premiumUsers).length;
    return ctx.reply(message);
  });
}

// Command untuk menambah blacklist (owner only)
function setupAddBlCommand(bot) {
  bot.command('addbl', (ctx) => {
    if (!global.ADMINS.includes(ctx.from.id)) {
      return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
    }
    
    const args = ctx.message.text.split(' ');
    if (args.length < 2) {
      return ctx.reply('❌ Format: /addbl [user_id] [reason?]');
    }
    
    const userId = args[1];
    const reason = args.slice(2).join(' ') || 'No reason provided';
    
    blacklistDB.add(userId, reason);
    return ctx.reply(`✅ Berhasil menambahkan user ${userId} ke blacklist`);
  });
}

// Command untuk menghapus blacklist (owner only)
function setupDelBlCommand(bot) {
  bot.command('delbl', (ctx) => {
    if (!global.ADMINS.includes(ctx.from.id)) {
      return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
    }
    
    const args = ctx.message.text.split(' ');
    if (args.length < 2) {
      return ctx.reply('❌ Format: /delbl [user_id]');
    }
    
    const userId = args[1];
    blacklistDB.remove(userId);
    return ctx.reply(`✅ Berhasil menghapus user ${userId} dari blacklist`);
  });
}

// Command untuk melihat daftar blacklist (owner only)
function setupListBlCommand(bot) {
  bot.command('listbl', (ctx) => {
    if (!global.ADMINS.includes(ctx.from.id)) {
      return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
    }
    
    const blacklist = blacklistDB.getAll();
    let message = '╭─❒ 「 BLACKLIST USERS 」\n';
    
    if (Object.keys(blacklist).length === 0) {
      message += '├ Tidak ada user di blacklist\n';
    } else {
      Object.entries(blacklist).forEach(([userId, data], index) => {
        const date = new Date(data.timestamp).toLocaleDateString('id-ID');
        message += `├ ${index + 1}. User: ${userId} | ${date} | ${data.reason}\n`;
      });
    }
    
    message += '╰❒ Total: ' + Object.keys(blacklist).length;
    return ctx.reply(message);
  });
}

// Command untuk melihat daftar grup (owner only)
function setupListGrupCommand(bot) {
  bot.command('listgrup', (ctx) => {
    if (!global.ADMINS.includes(ctx.from.id)) {
      return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
    }
    
    const groups = groupDB.getAll();
    let message = '╭─❒ 「 ACTIVE GROUPS 」\n';
    
    if (Object.keys(groups).length === 0) {
      message += '├ Tidak ada grup aktif\n';
    } else {
      Object.entries(groups).forEach(([groupId, data], index) => {
        const date = new Date(data.added).toLocaleDateString('id-ID');
        message += `├ ${index + 1}. ${data.name} | ${data.active ? '✅' : '❌'} | ${date}\n`;
      });
    }
    
    message += '╰❒ Total: ' + Object.keys(groups).length;
    return ctx.reply(message);
  });
}

// Command untuk menghapus grup tidak aktif (owner only)
function setupHapusGbCommand(bot) {
  bot.command('hapusgb', async (ctx) => {
    if (!global.ADMINS.includes(ctx.from.id)) {
      return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
    }
    
    try {
      const groups = groupDB.getAll();
      let removedCount = 0;
      
      for (const [groupId, data] of Object.entries(groups)) {
        if (!data.active) {
          groupDB.remove(groupId);
          removedCount++;
        }
      }
      
      return ctx.reply(`✅ Berhasil menghapus ${removedCount} grup tidak aktif`);
    } catch (error) {
      log('Error removing inactive groups', error);
      return ctx.reply('❌ Gagal menghapus grup tidak aktif');
    }
  });
}

// Command untuk broadcast (owner only)
function setupBcCommand(bot) {
  bot.command('bc', async (ctx) => {
    if (!global.ADMINS.includes(ctx.from.id)) {
      return ctx.reply('❌ Hanya owner yang dapat menggunakan command ini!');
    }
    
    const messageText = ctx.message.text.replace('/bc', '').trim();
    if (!messageText) {
      return ctx.reply('❌ Format: /bc [pesan]');
    }
    
    const users = userDB.getAll();
    const userIds = Object.keys(users);
    
    if (userIds.length === 0) {
      return ctx.reply('❌ Tidak ada pengguna untuk di-broadcast');
    }
    
    const progressMsg = await ctx.reply(`🚀 Memulai broadcast ke ${userIds.length} pengguna...`);
    
    let successCount = 0;
    let failCount = 0;
    
    for (const userId of userIds) {
      try {
        await ctx.telegram.sendMessage(userId, messageText);
        successCount++;
        
        // Update progress setiap 10 pengguna
        if (successCount % 10 === 0) {
          await ctx.telegram.editMessageText(
            progressMsg.chat.id,
            progressMsg.message_id,
            null,
            `🚀 Broadcast progress: ${successCount + failCount}/${userIds.length}\n✅ Success: ${successCount}\n❌ Failed: ${failCount}`
          );
        }
      } catch (error) {
        failCount++;
        log(`Failed to send broadcast to ${userId}`, error);
      }
      
      // Delay untuk menghindari rate limit
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    await ctx.telegram.editMessageText(
      progressMsg.chat.id,
      progressMsg.message_id,
      null,
      `✅ Broadcast selesai!\n📊 Total: ${userIds.length}\n✅ Success: ${successCount}\n❌ Failed: ${failCount}`
    );
  });
}

// Command untuk sharevip (premium only)
function setupShareVipCommand(bot) {
  bot.command('sharevip', async (ctx) => {
    if (ctx.chat.type !== 'private') {
      return ctx.reply('❌ Command ini hanya bisa digunakan di private chat!');
    }
    
    if (!premiumDB.isValid(ctx.from.id)) {
      return ctx.reply('❌ Hanya user premium yang dapat menggunakan fitur ini!');
    }
    
    const messageText = ctx.message.text.replace('/sharevip', '').trim();
    if (!messageText && !ctx.message.reply_to_message) {
      return ctx.reply('❌ Balas pesan atau ketik pesan untuk di-share!');
    }
    
    const textToShare = messageText || 
      (ctx.message.reply_to_message.text || ctx.message.reply_to_message.caption || '');
    
    if (!textToShare) {
      return ctx.reply('❌ Tidak ada teks yang dapat di-share!');
    }
    
    const groups = groupDB.getAll();
    const activeGroups = Object.entries(groups).filter(([_, data]) => data.active);
    
    if (activeGroups.length === 0) {
      return ctx.reply('❌ Tidak ada grup aktif untuk di-share!');
    }
    
    const progressMsg = await ctx.reply(`🚀 Memulai share VIP ke ${activeGroups.length} grup...`);
    
    let successCount = 0;
    let failCount = 0;
    
    for (const [groupId, data] of activeGroups) {
      try {
        await ctx.telegram.sendMessage(groupId, `⭐ SHARE VIP:\n\n${textToShare}`);
        successCount++;
        
        // Update progress setiap 3 grup
        if ((successCount + failCount) % 3 === 0) {
          await ctx.telegram.editMessageText(
            progressMsg.chat.id,
            progressMsg.message_id,
            null,
            `🚀 Share VIP progress: ${successCount + failCount}/${activeGroups.length}\n✅ Success: ${successCount}\n❌ Failed: ${failCount}`
          );
        }
      } catch (error) {
        failCount++;
        groupDB.deactivate(groupId);
        log(`Failed to share VIP to group ${groupId}`, error);
      }
      
      // Delay lebih pendek untuk VIP
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    
    await ctx.telegram.editMessageText(
      progressMsg.chat.id,
      progressMsg.message_id,
      null,
      `✅ Share VIP selesai!\n📊 Total: ${activeGroups.length}\n✅ Success: ${successCount}\n❌ Failed: ${failCount}`
    );
  });
}

// Command untuk sharefree (semua user)
function setupShareFreeCommand(bot) {
  bot.command('sharefree', async (ctx) => {
    if (ctx.chat.type !== 'private') {
      return ctx.reply('❌ Command ini hanya bisa digunakan di private chat!');
    }
    
    const messageText = ctx.message.text.replace('/sharefree', '').trim();
    if (!messageText && !ctx.message.reply_to_message) {
      return ctx.reply('❌ Balas pesan atau ketik pesan untuk di-share!');
    }
    
    const textToShare = messageText || 
      (ctx.message.reply_to_message.text || ctx.message.reply_to_message.caption || '');
    
    if (!textToShare) {
      return ctx.reply('❌ Tidak ada teks yang dapat di-share!');
    }
    
    const groups = groupDB.getAll();
    const activeGroups = Object.entries(groups).filter(([_, data]) => data.active);
    
    if (activeGroups.length === 0) {
      return ctx.reply('❌ Tidak ada grup aktif untuk di-share!');
    }
    
    const progressMsg = await ctx.reply(`🚀 Memulai share free ke ${activeGroups.length} grup...`);
    
    let successCount = 0;
    let failCount = 0;
    
    for (const [groupId, data] of activeGroups) {
      try {
        await ctx.telegram.sendMessage(groupId, `📢 SHARE FREE:\n\n${textToShare}`);
        successCount++;
        
        // Update progress setiap 5 grup
        if ((successCount + failCount) % 5 === 0) {
          await ctx.telegram.editMessageText(
            progressMsg.chat.id,
            progressMsg.message_id,
            null,
            `🚀 Share Free progress: ${successCount + failCount}/${activeGroups.length}\n✅ Success: ${successCount}\n❌ Failed: ${failCount}`
          );
        }
      } catch (error) {
        failCount++;
        groupDB.deactivate(groupId);
        log(`Failed to share free to group ${groupId}`, error);
      }
      
      // Delay lebih lama untuk free
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
    
    await ctx.telegram.editMessageText(
      progressMsg.chat.id,
      progressMsg.message_id,
      null,
      `✅ Share Free selesai!\n📊 Total: ${activeGroups.length}\n✅ Success: ${successCount}\n❌ Failed: ${failCount}`
    );
  });
}

// Command untuk tourl (convert foto ke URL)
function setupTourlCommand(bot) {
  bot.command('tourl', async (ctx) => {
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.photo) {
      return ctx.reply('❌ Balas foto dengan command /tourl');
    }
    
    try {
      const photo = ctx.message.reply_to_message.photo;
      const fileId = photo[photo.length - 1].file_id;
      const file = await ctx.telegram.getFile(fileId);
      const filePath = file.file_path;
      const fileUrl = `https://api.telegram.org/file/bot${global.BOT_TOKEN}/${filePath}`;
      
      return ctx.replyWithMarkdown(`✅ Berhasil mengkonversi foto ke URL:\n\`${fileUrl}\``);
    } catch (error) {
      log('Error converting photo to URL', error);
      return ctx.reply('❌ Gagal mengkonversi foto ke URL');
    }
  });
}

// Command untuk obfuscation
function setupObfCommands(bot) {
  // enc3 - Hardened Mandarin
  bot.command("enc3", async (ctx) => {
    userDB.add(ctx.from.id);
    
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown(`
╭━━━「 ❌ ERROR 」━━━⬣
│ Terjadi kesalahan saat
│ memproses file!
╰━━━━━━━━━━━━━━━━⬣`);
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown(`
╭━━━「 ❌ ERROR 」━━━⬣
│ File harus berekstensi .js!
╰━━━━━━━━━━━━━━━━⬣`);
    }

    const encryptedPath = path.join(
      __dirname,
      `china-encrypted-${file.file_name}`
    );

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          ` ⚙️ Memulai (Hardened Mandarin) (1%)\n` +
          ` ${createProgressBar(1)}\n` +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Mandarin obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Mandarin yang diperkuat`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Hardened Mandarin Obfuscation"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getJapanObfuscationConfig()
      );
      await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
      await fs.writeFile(encryptedPath, obfuscated.code);
      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscated.code);
      } catch (postObfuscationError) {
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      log(`Mengirim file terenkripsi gaya Mandarin: ${file.file_name}`);
      await ctx.replyWithDocument(
        { source: encryptedPath, filename: `china-encrypted-${file.file_name}` },
        {
          caption:
            "✅ *File terenkripsi (Hardened Mandarin) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Hardened Mandarin Obfuscation Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Mandarin obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // enc4 - Hardened Arab
  bot.command("enc4", async (ctx) => {
    userDB.add(ctx.from.id);

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc4`!");
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(
      __dirname,
      `arab-encrypted-${file.file_name}`
    );

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          ` ⚙️ Memulai (Hardened Arab) (1%)\n` +
          ` ${createProgressBar(1)}\n` +
          "```\n" +
          "PROSES ENCRYPT"
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Arab obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Arab yang diperkuat`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Hardened Arab Obfuscation"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getArabObfuscationConfig()
      );
      await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
      await fs.writeFile(encryptedPath, obfuscated.code);
      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscated.code);
      } catch (postObfuscationError) {
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      log(`Mengirim file terenkripsi gaya Arab: ${file.file_name}`);
      await ctx.replyWithDocument(
        { source: encryptedPath, filename: `arab-encrypted-${file.file_name}` },
        {
          caption:
            "✅ *File terenkripsi (Hardened Arab) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Hardened Arab Obfuscation Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Arab obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // japan - Hardened Japan
  bot.command("japan", async (ctx) => {
    userDB.add(ctx.from.id);

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/japan`!");
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(
      __dirname,
      `japan-encrypted-${file.file_name}`
    );

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          ` ⚙️ Memulai (Hardened Japan) (1%)\n` +
          ` ${createProgressBar(1)}\n` +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Japan obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Japan yang diperkuat`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Hardened Japan Obfuscation"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getJapanObfuscationConfig()
      );
      await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
      await fs.writeFile(encryptedPath, obfuscated.code);
      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscated.code);
      } catch (postObfuscationError) {
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      log(`Mengirim file terenkripsi gaya Japan: ${file.file_name}`);
      await ctx.replyWithDocument(
        { source: encryptedPath, filename: `japan-encrypted-${file.file_name}` },
        {
          caption:
            "✅ *File terenkripsi (Hardened Japan) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Hardened Japan Obfuscation Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Japan obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // deobfuscate - Deobfuscate JavaScript
  bot.command("deobfuscate", async (ctx) => {
    userDB.add(ctx.from.id);

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Balas file .js yang diobfuscate dengan `/deobfuscate`!"
      );
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const deobfuscatedPath = path.join(
      __dirname,
      `deobfuscated-${file.file_name}`
    );

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          ` ⚙️ Memulai Deobfuscation (1%)\n` +
          ` ${createProgressBar(1)}\n` +
          "```\n" +
          "PROSES ENCRYPT "
      );

      // Mengunduh file
      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk deobfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      // Validasi kode awal
      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode Awal");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      // Proses deobfuscation dengan webcrack
      log(`Memulai deobfuscation dengan webcrack: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 40, "Memulai Deobfuscation");
      const result = await webcrack(fileContent); // Pastikan await digunakan
      let deobfuscatedCode = result.code;

      // Penanganan jika kode dibundel
      let bundleInfo = "";
      if (result.bundle) {
        bundleInfo = "// Detected as bundled code (e.g., Webpack/Browserify)\n";
        log(`Kode terdeteksi sebagai bundel: ${file.file_name}`);
      }

      // Jika tidak ada perubahan signifikan atau hasil bukan string
      if (
        !deobfuscatedCode ||
        typeof deobfuscatedCode !== "string" ||
        deobfuscatedCode.trim() === fileContent.trim()
      ) {
        log(
          `Webcrack tidak dapat mendekode lebih lanjut atau hasil bukan string: ${file.file_name}`
        );
        deobfuscatedCode = `${bundleInfo}// Webcrack tidak dapat mendekode sepenuhnya atau hasil invalid\n${fileContent}`;
      }

      // Validasi kode hasil
      log(`Memvalidasi kode hasil deobfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 60, "Memvalidasi Kode Hasil");
      let isValid = true;
      try {
        new Function(deobfuscatedCode);
        log(`Kode hasil valid: ${deobfuscatedCode.substring(0, 50)}...`);
      } catch (syntaxError) {
        log(`Kode hasil tidak valid: ${syntaxError.message}`);
        deobfuscatedCode = `${bundleInfo}// Kesalahan validasi: ${syntaxError.message}\n${deobfuscatedCode}`;
        isValid = false;
      }

      // Simpan hasil
      await updateProgress(ctx, progressMessage, 80, "Menyimpan Hasil");
      await fs.writeFile(deobfuscatedPath, deobfuscatedCode);

      // Kirim hasil
      log(`Mengirim file hasil deobfuscation: ${file.file_name}`);
      await ctx.replyWithDocument(
        { source: deobfuscatedPath, filename: `deobfuscated-${file.file_name}` },
        {
          caption: `✅ *File berhasil dideobfuscate!${
            isValid ? "" : " (Perhatikan pesan error dalam file)"
          }*\nSUKSES ENCRYPT 🕊`,
          parse_mode: "Markdown",
        }
      );
      await updateProgress(ctx, progressMessage, 100, "Deobfuscation Selesai");

      // Hapus file sementara
      if (await fs.pathExists(deobfuscatedPath)) {
        await fs.unlink(deobfuscatedPath);
        log(`File sementara dihapus: ${deobfuscatedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat deobfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan file Javascript yang valid!_`
      );
      if (await fs.pathExists(deobfuscatedPath)) {
        await fs.unlink(deobfuscatedPath);
        log(`File sementara dihapus setelah error: ${deobfuscatedPath}`);
      }
    }
  });

  // zenc - Invisible Encryption
  bot.command("zenc", async (ctx) => {
    userDB.add(ctx.from.id);

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/zenc`!");
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(
      __dirname,
      `invisible-encrypted-${file.file_name}`
    );

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          ` ⚙️ Memulai (InvisiBle) (1%)\n` +
          ` ${createProgressBar(1)}\n` +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Strong obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Strong`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Hardened Invisible Obfuscation"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getStrongObfuscationConfig()
      );
      let obfuscatedCode = obfuscated.code || obfuscated; // Pastikan string
      if (typeof obfuscatedCode !== "string") {
        throw new Error("Hasil obfuscation bukan string");
      }
      log(
        `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
          0,
          50
        )}...`
      );
      await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscatedCode);
      } catch (postObfuscationError) {
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscatedCode);

      log(`Mengirim file terenkripsi gaya Invisible: ${file.file_name}`);
      await ctx.replyWithDocument(
        {
          source: encryptedPath,
          filename: `Invisible-encrypted-${file.file_name}`,
        },
        {
          caption: "✅ *File terenkripsi (Invisible) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Hardened Invisible Obfuscation Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Invisible obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // xx - Custom Encryption dengan nama
  bot.command("xx", async (ctx) => {
    userDB.add(ctx.from.id);

    // Ambil nama kustom dari perintah
    const args = ctx.message.text.split(" ");
    if (args.length < 2 || !args[1]) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Gunakan format `/enc <nama>` dengan nama kustom!"
      );
    }
    const customName = args[1].replace(/[^a-zA-Z0-9_]/g, ""); // Sanitasi input, hanya huruf, angka, dan underscore
    if (!customName) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Nama kustom harus berisi huruf, angka, atau underscore!"
      );
    }

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Balas file .js dengan `/enc <nama>`!"
      );
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(
      __dirname,
      `custom-${customName}-encrypted-${file.file_name}`
    );

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          ` ⚙️ Memulai (Hardened Custom: ${customName}) (1%)\n` +
          ` ${createProgressBar(1)}\n` +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Custom obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Custom (${customName}) yang diperkuat`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Hardened Custom Obfuscation"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getCustomObfuscationConfig(customName)
      );
      log(
        `Hasil obfuscation (50 char pertama): ${obfuscated.code.substring(
          0,
          50
        )}...`
      );
      await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");

      log(`Memvalidasi kode hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscated.code);
      } catch (postObfuscationError) {
        log(
          `Kode hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      await fs.writeFile(encryptedPath, obfuscated.code);
      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

      log(`Mengirim file terenkripsi gaya Custom: ${file.file_name}`);
      await ctx.replyWithDocument(
        {
          source: encryptedPath,
          filename: `custom-${customName}-encrypted-${file.file_name}`,
        },
        {
          caption: `✅ *File terenkripsi (Hardened Custom: ${customName}) siap!*\nSUKSES ENCRYPT 🕊`,
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        `Hardened Custom (${customName}) Obfuscation Selesai`
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Custom obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // quantum - Quantum Vortex Encryption
  bot.command("quantum", async (ctx) => {
    userDB.add(ctx.from.id);

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Balas file .js dengan `/quantum`!"
      );
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(
      __dirname,
      `quantum-encrypted-${file.file_name}`
    );

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          " ⚙️ Memulai (Quantum Vortex Encryption) (1%)\n" +
          " " +
          createProgressBar(1) +
          "\n" +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Quantum Vortex Encryption: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan Quantum Vortex Encryption`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Quantum Vortex Encryption"
      );
      const obfuscatedCode = await obfuscateQuantum(fileContent);
      log(
        `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
          0,
          50
        )}...`
      );
      log(
        `Ukuran file setelah obfuscation: ${Buffer.byteLength(
          obfuscatedCode,
          "utf-8"
        )} bytes`
      );

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscatedCode);
      } catch (postObfuscationError) {
        log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscatedCode);

      log(`Mengirim file terenkripsi quantum: ${file.file_name}`);
      await ctx.replyWithDocument(
        {
          source: encryptedPath,
          filename: `quantum-encrypted-${file.file_name}`,
        },
        {
          caption:
            "✅ *File terenkripsi (Quantum Vortex Encryption) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Quantum Vortex Encryption Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Quantum obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // var - Var Dynamic Obfuscation
  bot.command("var", async (ctx) => {
    userDB.add(ctx.from.id);

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/var`!");
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, `var-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          " ⚙️ Memulai (Var) (1%)\n" +
          " " +
          createProgressBar(1) +
          "\n" +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Var obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Var`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Var Dynamic Obfuscation"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getNovaObfuscationConfig()
      );
      let obfuscatedCode = obfuscated.code || obfuscated;
      if (typeof obfuscatedCode !== "string") {
        throw new Error("Hasil obfuscation bukan string");
      }
      log(
        `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
          0,
          50
        )}...`
      );

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscatedCode);
      } catch (postObfuscationError) {
        log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscatedCode);

      log(`Mengirim file terenkripsi gaya Var: ${file.file_name}`);
      await ctx.replyWithDocument(
        { source: encryptedPath, filename: `Var-encrypted-${file.file_name}` },
        {
          caption: "✅ *File terenkripsi (Var) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(ctx, progressMessage, 100, "Var Obfuscation Selesai");

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Nova obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // nebula - Nebula Polymorphic Storm
  bot.command("nebula", async (ctx) => {
    userDB.add(ctx.from.id);

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Balas file .js dengan `/nebula`!"
      );
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(
      __dirname,
      `nebula-encrypted-${file.file_name}`
    );

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          " ⚙️ Memulai (Nebula Polymorphic Storm) (1%)\n" +
          " " +
          createProgressBar(1) +
          "\n" +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Nebula obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Nebula`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Nebula Polymorphic Storm"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getNebulaObfuscationConfig()
      );
      let obfuscatedCode = obfuscated.code || obfuscated;
      if (typeof obfuscatedCode !== "string") {
        throw new Error("Hasil obfuscation bukan string");
      }
      log(
        `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
          0,
          50
        )}...`
      );
      log(
        `Ukuran file setelah obfuscation: ${Buffer.byteLength(
          obfuscatedCode,
          "utf-8"
        )} bytes`
      );

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscatedCode);
      } catch (postObfuscationError) {
        log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscatedCode);

      log(`Mengirim file terenkripsi gaya Nebula: ${file.file_name}`);
      await ctx.replyWithDocument(
        { source: encryptedPath, filename: `nebula-encrypted-${file.file_name}` },
        {
          caption:
            "✅ *File terenkripsi (Nebula Polymorphic Storm) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Nebula Polymorphic Storm Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Nebula obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // enc5 - Calcrick Chaos Core
  bot.command("enc5", async (ctx) => {
    userDB.add(ctx.from.id);

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Balas file .js dengan `/enc5`!"
      );
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(
      __dirname,
      `siucalcrick-encrypted-${file.file_name}`
    );

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          " ⚙️ Memulai (Calcrick Chaos Core) (1%)\n" +
          " " +
          createProgressBar(1) +
          "\n" +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Siu+Calcrick obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Siu+Calcrick`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Calcrick Chaos Core"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getSiuCalcrickObfuscationConfig()
      );
      let obfuscatedCode = obfuscated.code || obfuscated;
      if (typeof obfuscatedCode !== "string") {
        throw new Error("Hasil obfuscation bukan string");
      }
      log(
        `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
          0,
          50
        )}...`
      );
      log(
        `Ukuran file setelah obfuscation: ${Buffer.byteLength(
          obfuscatedCode,
          "utf-8"
        )} bytes`
      );

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscatedCode);
      } catch (postObfuscationError) {
        log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscatedCode);

      log(`Mengirim file terenkripsi gaya Siu+Calcrick: ${file.file_name}`);
      await ctx.replyWithDocument(
        {
          source: encryptedPath,
          filename: `siucalcrick-encrypted-${file.file_name}`,
        },
        {
          caption:
            "✅ *File terenkripsi (Calcrick Chaos Core) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Calcrick Chaos Core Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Siu+Calcrick obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // enc2 - Custom Encryption dengan teks
  bot.command("enc2", async (ctx) => {
    userDB.add(ctx.from.id);

    const customString = ctx.message.text.split(" ")[1];

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Balas file .js dengan `/enc2 <text>`!"
      );
    }

    if (!customString) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Balas file .js dengan `/enc2 <text>`!"
      );
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(
      __dirname,
      `custom-encrypted-${file.file_name}`
    );

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          " ⚙️ Memulai (custom enc) (1%)\n" +
          " " +
          createProgressBar(1) +
          "\n" +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk custom obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya custom (${customString})`);
      await updateProgress(ctx, progressMessage, 40, `Inisialisasi custom (${customString})`);

      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getCustomObfuscationConfig(customString)
      );

      let obfuscatedCode = obfuscated.code || obfuscated;
      if (typeof obfuscatedCode !== "string") {
        throw new Error("Hasil obfuscation bukan string");
      }
      log(
        `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
          0,
          50
        )}...`
      );
      log(
        `Ukuran file setelah obfuscation: ${Buffer.byteLength(
          obfuscatedCode,
          "utf-8"
        )} bytes`
      );

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscatedCode);
      } catch (postObfuscationError) {
        log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscatedCode);

      log(`Mengirim file terenkripsi gaya custom (${customString}): ${file.file_name}`);
      await ctx.replyWithDocument(
        {
          source: encryptedPath,
          filename: `custom-encrypted-${file.file_name}`,
        },
        {
          caption: `✅ *File terenkripsi custom (${customString}) siap!*\nSUKSES ENCRYPT 🕊`,
          parse_mode: "Markdown",
        }
      );
      await updateProgress(ctx, progressMessage, 100, `custom (${customString}) Selesai`);

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat custom enc obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // enc - Time-Locked Encryption
  bot.command("enc", async (ctx) => {
    userDB.add(ctx.from.id);

    const args = ctx.message.text.split(" ").slice(1);
    if (
      args.length !== 1 ||
      !/^\d+$/.test(args[0]) ||
      parseInt(args[0]) < 1 ||
      parseInt(args[0]) > 365
    ) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Gunakan format `/locked [1-365]` untuk jumlah hari (misal: `/enc 7`)!"
      );
    }

    const days = args[0];
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + parseInt(days));
    const expiryFormatted = expiryDate.toLocaleDateString();

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Balas file .js dengan `/enc [1-365]`!"
      );
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(
      __dirname,
      `locked-encrypted-${file.file_name}`
    );

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          " ⚙️ Memulai (Time-Locked Encryption) (1%)\n" +
          " " +
          createProgressBar(1) +
          "\n" +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Time-Locked Encryption: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan Time-Locked Encryption`);
      await updateProgress(
        ctx,
        progressMessage,
       40,
        "Inisialisasi Time-Locked Encryption"
      );
      const obfuscatedCode = await obfuscateTimeLocked(fileContent, days);
      log(
        `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
          0,
          50
        )}...`
      );
      log(
        `Ukuran file setelah obfuscation: ${Buffer.byteLength(
          obfuscatedCode,
          "utf-8"
        )} bytes`
      );

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscatedCode);
      } catch (postObfuscationError) {
        log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscatedCode);

      log(`Mengirim file terenkripsi time-locked: ${file.file_name}`);
      await ctx.replyWithMarkdown(
        `✅ *File terenkripsi (Time-Locked Encryption) siap!*\n` +
          `⏰ Masa aktif: ${days} hari (Kedaluwarsa: ${expiryFormatted})\n` +
          `_Powered by XHINN_`,
        { parse_mode: "Markdown" }
      );
      await ctx.replyWithDocument({
        source: encryptedPath,
        filename: `locked-encrypted-${file.file_name}`,
      });
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Time-Locked Encryption Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Time-Locked obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });
}

// Ekspor semua fungsi setup command
module.exports = {
  setupStartCommand,
  setupHelpCommand,
  setupMenuCommand,
  setupPremiumCommand,
  setupAddPremCommand,
  setupDelPremCommand,
  setupListPremCommand,
  setupAddBlCommand,
  setupDelBlCommand,
  setupListBlCommand,
  setupListGrupCommand,
  setupHapusGbCommand,
  setupBcCommand,
  setupShareVipCommand,
  setupShareFreeCommand,
  setupTourlCommand,
  setupObfCommands
};