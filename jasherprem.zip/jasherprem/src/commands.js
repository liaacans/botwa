const { Markup } = require('telegraf');
const { User, Group } = require('../lib/database');
const { formatUserInfo } = require('./utils');

async function handleStart(ctx) {
  try {
    let user = await User.findOne({ userId: ctx.from.id });
    
    if (!user) {
      user = new User({
        userId: ctx.from.id,
        username: ctx.from.username,
        firstName: ctx.from.first_name,
        lastName: ctx.from.last_name,
        isCreator: ctx.from.id.toString() === process.env.OWNER_ID
      });
      await user.save();
    }
    
    const menuText = formatUserInfo(ctx, user);
    const menuButtons = Markup.inlineKeyboard([
      [Markup.button.callback('🎯 Jasher Menu', 'jasher_menu')],
      [Markup.button.callback('👤 Owner Menu', 'owner_menu')],
      [Markup.button.url('➕ Add Group', 'https://t.me/your_bot_username?startgroup=true')],
      [Markup.button.callback('👨‍💻 Owner', 'contact_owner')]
    ]);
    
    await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
      caption: menuText,
      parse_mode: 'HTML',
      ...menuButtons
    });
  } catch (error) {
    console.error('Error in start command:', error);
    ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleHelp(ctx) {
  const helpText = `
🤖 *Jasher Bot Help*

*Perintah Umum:*
/start - Memulai bot
/help - Menampilkan bantuan
/credit - Melihat kredit Anda
/share - Berbagi pesan (kurang 2 kredit)

*Perintah Premium:*
/sharevip - Berbagi pesan premium (lebih cepat)

*Perintah Owner:*
/addprem - Menambah user premium
/delprem - Menghapus user premium
/listprem - Melihat daftar premium
/broadcast - Mengirim pesan ke semua user

Tambahkan bot ke 3 grup untuk mendapatkan 10 kredit!
  `;
  
  await ctx.reply(helpText, { parse_mode: 'Markdown' });
}

async function handleCredit(ctx) {
  try {
    const user = await User.findOne({ userId: ctx.from.id });
    if (!user) return ctx.reply('Anda belum terdaftar. Ketik /start untuk mendaftar.');
    
    await ctx.reply(`💰 Kredit Anda: ${user.credit}`);
  } catch (error) {
    console.error('Error in credit command:', error);
    ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleShare(ctx) {
  try {
    if (ctx.chat.type !== 'private') {
      return ctx.reply('Perintah ini hanya bisa digunakan di chat private!');
    }
    
    const user = await User.findOne({ userId: ctx.from.id });
    if (!user) return ctx.reply('Anda belum terdaftar. Ketik /start untuk mendaftar.');
    
    if (user.credit < 2) {
      return ctx.reply('Kredit Anda tidak cukup. Tambahkan bot ke 3 grup untuk mendapatkan kredit!');
    }
    
    const messageToShare = ctx.message.reply_to_message 
      ? ctx.message.reply_to_message 
      : ctx.message.text.split(' ').slice(1).join(' ');
    
    if (!messageToShare) {
      return ctx.reply('Balas pesan yang ingin dibagikan atau ketik pesan setelah perintah /share');
    }
    
    // Kurangi kredit
    user.credit -= 2;
    await user.save();
    
    // Broadcast ke semua grup yang telah ditambahkan
    const groups = await Group.find({});
    let successCount = 0;
    
    for (const group of groups) {
      try {
        await ctx.telegram.sendMessage(group.groupId, `📢 *Pesan Dibagikan:*\n\n${messageToShare.text || messageToShare}`, {
          parse_mode: 'Markdown'
        });
        successCount++;
      } catch (error) {
        console.error(`Error sending to group ${group.groupId}:`, error);
      }
    }
    
    await ctx.reply(`Pesan berhasil dibagikan ke ${successCount} grup. Kredit berkurang 2. Sisa kredit: ${user.credit}`);
  } catch (error) {
    console.error('Error in share command:', error);
    ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleShareVip(ctx) {
  try {
    if (ctx.chat.type !== 'private') {
      return ctx.reply('Perintah ini hanya bisa digunakan di chat private!');
    }
    
    const user = await User.findOne({ userId: ctx.from.id });
    if (!user) return ctx.reply('Anda belum terdaftar. Ketik /start untuk mendaftar.');
    
    if (!user.isPremium) {
      return ctx.reply('Fitur ini hanya untuk user premium!');
    }
    
    const messageToShare = ctx.message.reply_to_message 
      ? ctx.message.reply_to_message 
      : ctx.message.text.split(' ').slice(1).join(' ');
    
    if (!messageToShare) {
      return ctx.reply('Balas pesan yang ingin dibagikan atau ketik pesan setelah perintah /sharevip');
    }
    
    // Broadcast ke semua grup yang telah ditambahkan (lebih cepat)
    const groups = await Group.find({});
    let successCount = 0;
    
    // Menggunakan Promise.all untuk mengirim lebih cepat
    const sendPromises = groups.map(async (group) => {
      try {
        await ctx.telegram.sendMessage(group.groupId, `🌟 *Pesan Premium Dibagikan:*\n\n${messageToShare.text || messageToShare}`, {
          parse_mode: 'Markdown'
        });
        successCount++;
      } catch (error) {
        console.error(`Error sending to group ${group.groupId}:`, error);
      }
    });
    
    await Promise.all(sendPromises);
    
    await ctx.reply(`Pesan premium berhasil dibagikan ke ${successCount} grup dengan cepat!`);
  } catch (error) {
    console.error('Error in sharevip command:', error);
    ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

// Owner commands
async function handleAddPrem(ctx) {
  try {
    if (ctx.from.id.toString() !== process.env.OWNER_ID) {
      return ctx.reply('Anda bukan owner bot!');
    }
    
    const targetUsername = ctx.message.text.split(' ')[1];
    if (!targetUsername) {
      return ctx.reply('Gunakan: /addprem @username');
    }
    
    const user = await User.findOne({ 
      username: targetUsername.replace('@', '') 
    });
    
    if (!user) {
      return ctx.reply('User tidak ditemukan!');
    }
    
    user.isPremium = true;
    await user.save();
    
    await ctx.reply(`User ${targetUsername} sekarang premium!`);
  } catch (error) {
    console.error('Error in addprem command:', error);
    ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleDelPrem(ctx) {
  try {
    if (ctx.from.id.toString() !== process.env.OWNER_ID) {
      return ctx.reply('Anda bukan owner bot!');
    }
    
    const targetUsername = ctx.message.text.split(' ')[1];
    if (!targetUsername) {
      return ctx.reply('Gunakan: /delprem @username');
    }
    
    const user = await User.findOne({ 
      username: targetUsername.replace('@', '') 
    });
    
    if (!user) {
      return ctx.reply('User tidak ditemukan!');
    }
    
    user.isPremium = false;
    await user.save();
    
    await ctx.reply(`User ${targetUsername} dihapus dari premium!`);
  } catch (error) {
    console.error('Error in delprem command:', error);
    ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleListPrem(ctx) {
  try {
    if (ctx.from.id.toString() !== process.env.OWNER_ID) {
      return ctx.reply('Anda bukan owner bot!');
    }
    
    const premiumUsers = await User.find({ isPremium: true });
    
    if (premiumUsers.length === 0) {
      return ctx.reply('Tidak ada user premium!');
    }
    
    let listText = '🌟 Daftar User Premium:\n\n';
    premiumUsers.forEach((user, index) => {
      listText += `${index + 1}. @${user.username} (ID: ${user.userId})\n`;
    });
    
    await ctx.reply(listText);
  } catch (error) {
    console.error('Error in listprem command:', error);
    ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleBroadcast(ctx) {
  try {
    if (ctx.from.id.toString() !== process.env.OWNER_ID) {
      return ctx.reply('Anda bukan owner bot!');
    }
    
    const message = ctx.message.reply_to_message;
    if (!message) {
      return ctx.reply('Balas pesan yang ingin di-broadcast!');
    }
    
    const allUsers = await User.find({});
    let successCount = 0;
    
    for (const user of allUsers) {
      try {
        await ctx.telegram.copyMessage(user.userId, ctx.chat.id, message.message_id);
        successCount++;
      } catch (error) {
        console.error(`Error broadcasting to user ${user.userId}:`, error);
      }
    }
    
    await ctx.reply(`Broadcast berhasil dikirim ke ${successCount} user.`);
  } catch (error) {
    console.error('Error in broadcast command:', error);
    ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

module.exports = {
  handleStart,
  handleHelp,
  handleCredit,
  handleShare,
  handleShareVip,
  handleAddPrem,
  handleDelPrem,
  handleListPrem,
  handleBroadcast
};