const axios = require('axios');
const crypto = require('crypto');
const { Payment, User } = require('../lib/database');
const { log } = require('../lib/utils');
const { Markup } = require('telegraf');

// Fungsi untuk membuat signature
function generateSignature(refKode, apiKey, amount, secretKey) {
  return crypto
    .createHmac('sha256', secretKey)
    .update(refKode + apiKey + amount)
    .digest('hex');
}

// Fungsi untuk membuat pembayaran
async function createPayment(userId, amount, product, paymentMethod, userData) {
  try {
    const refKode = "JasherBot_" + Date.now() + "_" + Math.random().toString(36).substr(2, 9);
    
    const postData = {
      'api_key': global.PAYMENT_API_KEY,
      'secret_key': global.PAYMENT_SECRET_KEY,
      'channel_payment': paymentMethod.toUpperCase(),
      'ref_kode': refKode,
      'nominal': amount,
      'cus_nama': userData.name || `User_${userId}`,
      'cus_email': userData.email || `user${userId}@jasherbot.com`,
      'cus_phone': userData.phone || '081234567890',
      'produk': product,
      'url_redirect': "https://t.me/jasherbot",
      'url_callback': "https://yourdomain.com/callback", // Ganti dengan URL callback Anda
      'expired_time': Math.floor(Date.now() / 1000) + (24 * 60 * 60),
      'signature': generateSignature(refKode, global.PAYMENT_API_KEY, amount, global.PAYMENT_SECRET_KEY)
    };

    const response = await axios.post(global.PAYMENT_URL, postData, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      timeout: 30000
    });

    if (response.data && response.data.data && response.data.data.status === "success") {
      // Simpan data pembayaran
      const payment = new Payment({
        userId,
        amount,
        product,
        paymentMethod,
        reference: response.data.data.id_reference,
        checkoutUrl: response.data.data.checkout_url,
        status: 'pending',
        userData: userData
      });
      await payment.save();

      return {
        success: true,
        checkoutUrl: response.data.data.checkout_url,
        reference: response.data.data.id_reference,
        message: 'Pembayaran berhasil dibuat'
      };
    } else {
      const errorMsg = response.data?.message || response.data?.data?.message || 'Gagal membuat pembayaran';
      throw new Error(errorMsg);
    }
  } catch (error) {
    log(`Payment error: ${error.message}`);
    return {
      success: false,
      error: error.response?.data?.message || error.message
    };
  }
}

// Fungsi untuk memeriksa status pembayaran
async function checkPaymentStatus(reference) {
  try {
    // Implementasi pengecekan status pembayaran
    // Ini adalah contoh sederhana, Anda perlu menyesuaikan dengan API yab-group.com
    const response = await axios.get(`${global.PAYMENT_URL}/check`, {
      params: {
        api_key: global.PAYMENT_API_KEY,
        reference: reference
      },
      timeout: 15000
    });

    if (response.data && response.data.status === 'success') {
      return {
        success: true,
        status: response.data.data.status,
        message: response.data.message
      };
    } else {
      return {
        success: false,
        status: 'unknown',
        message: response.data?.message || 'Gagal memeriksa status'
      };
    }
  } catch (error) {
    log(`Payment status check error: ${error.message}`);
    return {
      success: false,
      status: 'error',
      message: error.message
    };
  }
}

// Command untuk membeli premium
function setupPaymentCommands(bot) {
  // State untuk menangani proses pembayaran
  const paymentState = new Map();

  bot.command('buyprem', async (ctx) => {
    const args = ctx.message.text.split(' ');
    if (args.length < 2) {
      return ctx.reply(
        '❌ Format: /buyprem <paket>\n' +
        'Paket yang tersedia:\n' +
        '• 7hari - Rp 10.000\n' +
        '• 30hari - Rp 30.000\n' +
        '• 90hari - Rp 75.000\n' +
        '• 365hari - Rp 250.000'
      );
    }

    const package = args[1].toLowerCase();
    let amount, days, product;

    switch (package) {
      case '7hari':
        amount = 10000;
        days = 7;
        product = 'Premium 7 Hari';
        break;
      case '30hari':
        amount = 30000;
        days = 30;
        product = 'Premium 30 Hari';
        break;
      case '90hari':
        amount = 75000;
        days = 90;
        product = 'Premium 90 Hari';
        break;
      case '365hari':
        amount = 250000;
        days = 365;
        product = 'Premium 365 Hari';
        break;
      default:
        return ctx.reply(
          '❌ Paket tidak valid!\n' +
          'Paket yang tersedia:\n' +
          '• 7hari - Rp 10.000\n' +
          '• 30hari - Rp 30.000\n' +
          '• 90hari - Rp 75.000\n' +
          '• 365hari - Rp 250.000'
        );
    }

    // Simpan state pembayaran
    paymentState.set(ctx.from.id, {
      package,
      amount,
      days,
      product,
      step: 'select_method'
    });

    // Tampilkan opsi pembayaran
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('💳 QRIS', `pay_qris_${package}`)],
      [Markup.button.callback('🏦 Transfer Bank', `pay_bank_${package}`)],
      [Markup.button.callback('🔙 Batal', 'cancel_payment')]
    ]);

    await ctx.reply(
      `💎 Paket: ${product}\n` +
      `💰 Harga: Rp ${amount.toLocaleString('id-ID')}\n` +
      `⏰ Durasi: ${days} hari\n\n` +
      `Pilih metode pembayaran:`,
      keyboard
    );
  });

  // Handler untuk pembayaran QRIS
  bot.action(/pay_qris_(.+)/, async (ctx) => {
    const package = ctx.match[1];
    const userId = ctx.from.id;
    const state = paymentState.get(userId);

    if (!state || state.package !== package) {
      return ctx.answerCbQuery('❌ Sesi pembayaran tidak valid!');
    }

    state.paymentMethod = 'QRIS';
    paymentState.set(userId, state);

    // Minta data user
    await ctx.editMessageText(
      `🔒 *Pembayaran via QRIS*\n\n` +
      `💎 Paket: ${state.product}\n` +
      `💰 Harga: Rp ${state.amount.toLocaleString('id-ID')}\n\n` +
      `Silakan isi data diri Anda:\n` +
      `Balas pesan ini dengan format:\n` +
      `Nama|Email|NoHP\n\n` +
      `Contoh: Ahmad|ahmad@email.com|08123456789`,
      { parse_mode: 'Markdown' }
    );

    state.step = 'input_data';
    paymentState.set(userId, state);
  });

  // Handler untuk pembayaran Bank Transfer
  bot.action(/pay_bank_(.+)/, async (ctx) => {
    const package = ctx.match[1];
    const userId = ctx.from.id;
    const state = paymentState.get(userId);

    if (!state || state.package !== package) {
      return ctx.answerCbQuery('❌ Sesi pembayaran tidak valid!');
    }

    state.paymentMethod = 'BANK';
    paymentState.set(userId, state);

    // Tampilkan instruksi transfer bank
    await ctx.editMessageText(
      `🏦 *Pembayaran via Transfer Bank*\n\n` +
      `💎 Paket: ${state.product}\n` +
      `💰 Harga: Rp ${state.amount.toLocaleString('id-ID')}\n\n` +
      `Silakan transfer ke:\n` +
      `Bank: BCA\n` +
      `No. Rekening: 1234567890\n` +
      `Atas Nama: Jasher Bot\n\n` +
      `Setelah transfer, balas pesan ini dengan bukti transfer dan format:\n` +
      `Nama|Email|NoHP|TanggalTransfer|BankAsal`,
      { parse_mode: 'Markdown' }
    );

    state.step = 'input_data';
    paymentState.set(userId, state);
  });

  // Handler untuk input data pembayaran
  bot.on('text', async (ctx) => {
    const userId = ctx.from.id;
    const state = paymentState.get(userId);

    if (state && state.step === 'input_data') {
      const message = ctx.message.text;
      
      // Parsing data user
      const userData = parseUserData(message);
      if (!userData) {
        return ctx.reply(
          '❌ Format data tidak valid!\n' +
          'Gunakan format: Nama|Email|NoHP\n' +
          'Contoh: Ahmad|ahmad@email.com|08123456789'
        );
      }

      try {
        // Buat pembayaran
        const paymentResult = await createPayment(
          userId, 
          state.amount, 
          state.product, 
          state.paymentMethod,
          userData
        );

        if (paymentResult.success) {
          if (state.paymentMethod === 'QRIS') {
            await ctx.reply(
              `✅ *Pembayaran berhasil dibuat!*\n\n` +
              `💎 Paket: ${state.product}\n` +
              `💰 Harga: Rp ${state.amount.toLocaleString('id-ID')}\n` +
              `⏰ Durasi: ${state.days} hari\n` +
              `💳 Metode: QRIS\n\n` +
              `🔗 Link Pembayaran: ${paymentResult.checkoutUrl}\n\n` +
              `Silakan selesaikan pembayaran Anda dalam 24 jam.`,
              Markup.inlineKeyboard([
                [Markup.button.url('💳 Bayar Sekarang', paymentResult.checkoutUrl)],
                [Markup.button.callback('🔄 Cek Status', `check_status_${paymentResult.reference}`)]
              ])
            );
          } else {
            await ctx.reply(
              `✅ *Pembayaran berhasil dicatat!*\n\n` +
              `💎 Paket: ${state.product}\n` +
              `💰 Harga: Rp ${state.amount.toLocaleString('id-ID')}\n` +
              `⏰ Durasi: ${state.days} hari\n` +
              `💳 Metode: Transfer Bank\n\n` +
              `Pembayaran akan diproses setelah kami menerima bukti transfer.`
            );
          }

          // Hapus state
          paymentState.delete(userId);
        } else {
          await ctx.reply(
            `❌ Gagal membuat pembayaran: ${paymentResult.error}\n\n` +
            `Silakan coba lagi atau hubungi admin.`
          );
        }
      } catch (error) {
        await ctx.reply(
          `❌ Error: ${error.message}\n\n` +
          `Silakan coba lagi atau hubungi admin.`
        );
      }
    }
  });

  // Handler untuk cek status pembayaran
  bot.action(/check_status_(.+)/, async (ctx) => {
    const reference = ctx.match[1];
    
    try {
      const payment = await Payment.findOne({ reference });
      if (!payment) {
        return ctx.answerCbQuery('❌ Pembayaran tidak ditemukan!');
      }

      if (payment.status === 'completed') {
        await ctx.answerCbQuery('✅ Pembayaran sudah berhasil!');
        
        // Berikan premium ke user
        const user = await User.findOne({ userId: payment.userId });
        if (user) {
          const expiryDate = new Date();
          expiryDate.setDate(expiryDate.getDate() + getDaysFromProduct(payment.product));
          
          user.isPremium = true;
          user.premiumExpiry = expiryDate;
          await user.save();

          // Kirim notifikasi ke user
          await ctx.telegram.sendMessage(
            user.userId,
            `🎉 *Selamat! Akun Anda sekarang Premium!*\n\n` +
            `💎 Paket: ${payment.product}\n` +
            `⏰ Berlaku hingga: ${expiryDate.toLocaleDateString('id-ID')}\n\n` +
            `Nikmati semua fitur premium tanpa batas!`,
            { parse_mode: 'Markdown' }
          );
        }
      } else {
        const statusResult = await checkPaymentStatus(reference);
        if (statusResult.success && statusResult.status === 'paid') {
          // Update status pembayaran
          payment.status = 'completed';
          await payment.save();
          
          await ctx.answerCbQuery('✅ Pembayaran sudah berhasil!');
        } else {
          await ctx.answerCbQuery('⏳ Pembayaran masih pending...');
        }
      }
    } catch (error) {
      await ctx.answerCbQuery('❌ Error memeriksa status!');
    }
  });

  // Handler untuk batalkan pembayaran
  bot.action('cancel_payment', async (ctx) => {
    const userId = ctx.from.id;
    paymentState.delete(userId);
    
    await ctx.deleteMessage();
    await ctx.answerCbQuery('❌ Pembayaran dibatalkan');
  });

  // Fungsi untuk parsing data user
  function parseUserData(message) {
    const parts = message.split('|');
    if (parts.length < 3) return null;

    const name = parts[0].trim();
    const email = parts[1].trim();
    const phone = parts[2].trim();

    // Validasi email sederhana
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) return null;

    // Validasi phone sederhana
    const phoneRegex = /^[0-9]{10,15}$/;
    if (!phoneRegex.test(phone.replace(/\D/g, ''))) return null;

    return { name, email, phone };
  }

  // Fungsi untuk mendapatkan hari dari produk
  function getDaysFromProduct(product) {
    if (product.includes('7')) return 7;
    if (product.includes('30')) return 30;
    if (product.includes('90')) return 90;
    if (product.includes('365')) return 365;
    return 7; // Default
  }
}

module.exports = {
  setupPaymentCommands,
  createPayment,
  checkPaymentStatus
};