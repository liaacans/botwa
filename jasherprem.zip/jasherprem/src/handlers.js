const { Markup } = require('telegraf');
const moment = require('moment-timezone');
const { User, Premium, Group } = require('../lib/database');
const { runtime, log } = require('../lib/utils');

// Inisialisasi database
const userDB = new User();
const premiumDB = new Premium();
const groupDB = new Group();

// Fungsi untuk menangani callback query
function setupCallbackQueryHandler(bot) {
  bot.on('callback_query', async (ctx) => {
    const data = ctx.callbackQuery.data;
    const userId = ctx.from.id;
    
    try {
      switch (data) {
        case 'jasher_menu':
          await ctx.editMessageCaption(
            `╭─❒ 「 JASHER MENU 」 
├ Fitur utama bot Jasher Premium
├ 
├ /enc [hari] - Time-Locked Encryption
├ /enc2 [teks] - Custom Encryption
├ /enc3 - Hardened Mandarin
├ /enc4 - Hardened Arab
├ /enc5 - Calcrick Chaos Core
├ /japan - Hardened Japan
├ /nebula - Nebula Polymorphic Storm
├ /quantum - Quantum Vortex Encryption
├ /var - Var Dynamic Obfuscation
├ /zenc - Invisible Encryption
├ /deobfuscate - Deobfuscate JavaScript
├ 
├ /premium - Cek status premium
├ /sharefree - Share pesan ke grup (free)
├ /sharevip - Share pesan ke grup (VIP)
╰❒ Gunakan command di atas untuk memulai`,
            {
              ...Markup.inlineKeyboard([
                [Markup.button.callback('Kembali', 'main_menu')]
              ])
            }
          );
          break;
          
        case 'owner_menu':
          if (!global.ADMINS.includes(userId)) {
            await ctx.answerCbQuery('❌ Hanya owner yang dapat mengakses menu ini!');
            return;
          }
          
          await ctx.editMessageCaption(
            `╭─❒ 「 OWNER MENU 」 
├ Menu khusus untuk owner bot
├ 
├ /addprem [user_id] [days] - Tambah premium
├ /delprem [user_id] - Hapus premium
├ /listprem - List user premium
├ 
├ /addbl [user_id] [reason] - Tambah blacklist
├ /delbl [user_id] - Hapus blacklist
├ /listbl - List blacklist
├ 
├ /listgrup - List grup aktif
├ /hapusgb - Hapus grup tidak aktif
├ 
├ /bc [pesan] - Broadcast ke semua user
├ /tourl - Convert foto ke URL
╰❒ Gunakan command di atas untuk mengelola bot`,
            {
              ...Markup.inlineKeyboard([
                [Markup.button.callback('Kembali', 'main_menu')]
              ])
            }
          );
          break;
          
        case 'obf_menu':
          await ctx.editMessageCaption(
            `╭─❒ 「 OBF MENU 」 
├ Menu obfuscation JavaScript
├ 
├ /enc [1-365] - Time-Locked Encryption
├ /enc2 [teks] - Custom Encryption
├ /enc3 - Hardened Mandarin
├ /enc4 - Hardened Arab
├ /enc5 - Calcrick Chaos Core
├ /japan - Hardened Japan
├ /nebula - Nebula Polymorphic Storm
├ /quantum - Quantum Vortex Encryption
├ /var - Var Dynamic Obfuscation
├ /zenc - Invisible Encryption
├ /deobfuscate - Deobfuscate JavaScript
├ 
├ Cara penggunaan:
├ 1. Kirim file JavaScript
├ 2. Balas file dengan command obf
├ 3. Tunggu proses selesai
╰❒ 4. File hasil akan dikirimkan`,
            {
              ...Markup.inlineKeyboard([
                [Markup.button.callback('Kembali', 'main_menu')]
              ])
            }
          );
          break;
          
        case 'main_menu':
          const username = ctx.from.username || ctx.from.first_name;
          const isCreator = global.ADMINS.includes(ctx.from.id);
          
          await ctx.editMessageCaption(
            `╭─❒ 「 User Info 」 
├ Creator : @${global.DEVELOPER}
├ Name : @${username}
├ Profile : @${ctx.from.username || ctx.from.first_name}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreator ? 'True' : 'False'}

Silahkan pilih button dibawah ini!`,
            {
              ...Markup.inlineKeyboard([
                [
                  Markup.button.callback('Jasher Menu', 'jasher_menu'),
                  Markup.button.callback('Owner Menu', 'owner_menu')
                ],
                [
                  Markup.button.callback('Obf Menu', 'obf_menu'),
                  Markup.button.callback('Main Menu', 'main_menu')
                ]
              ])
            }
          );
          break;
          
        default:
          await ctx.answerCbQuery('❌ Perintah tidak dikenali!');
      }
      
      await ctx.answerCbQuery();
    } catch (error) {
      log('Error handling callback query', error);
      await ctx.answerCbQuery('❌ Terjadi kesalahan!');
    }
  });
}

// Fungsi untuk menangani ketika bot ditambahkan ke grup
function setupNewChatMembersHandler(bot) {
  bot.on('new_chat_members', async (ctx) => {
    const newMembers = ctx.message.new_chat_members;
    const chatId = ctx.chat.id;
    const chatTitle = ctx.chat.title;
    
    // Cek jika bot yang ditambahkan
    const botMember = newMembers.find(member => member.is_bot && member.id === ctx.botInfo.id);
    if (botMember) {
      // Tambahkan grup ke database
      groupDB.add(chatId, chatTitle);
      
      // Beri premium kepada user yang menambahkan bot
      const addedBy = ctx.message.from.id;
      premiumDB.add(addedBy, 3);
      
      await ctx.replyWithMarkdown(`
╭─❒ 「 BOT JASHER DITAMBAHKAN 」 
├ Terima kasih telah menambahkan
├ Bot Jasher Premium ke grup ini!
├ 
├ Owner grup mendapatkan +3 hari premium
├ Gunakan /premium untuk cek status
├ 
├ Fitur yang didukung:
├ • Obfuscation JavaScript
├ • Share pesan ke grup
├ • Sistem premium
╰❒ • Dan banyak lagi!

Gunakan /menu di private chat untuk memulai.
      `);
      
      log(`Bot added to group: ${chatTitle} (${chatId}) by user: ${addedBy}`);
    }
  });
}

// Fungsi untuk menangani ketika bot dikick dari grup
function setupLeftChatMemberHandler(bot) {
  bot.on('left_chat_member', async (ctx) => {
    const leftMember = ctx.message.left_chat_member;
    const chatId = ctx.chat.id;
    
    // Cek jika bot yang dikick
    if (leftMember.is_bot && leftMember.id === ctx.botInfo.id) {
      // Tandai grup sebagai tidak aktif
      groupDB.deactivate(chatId);
      log(`Bot removed from group: ${ctx.chat.title} (${chatId})`);
    }
  });
}

// Fungsi untuk menangani pesan yang tidak dikenali
function setupMessageHandler(bot) {
  bot.on('message', async (ctx) => {
    // Jika pesan dari grup, simpan info grup
    if (ctx.chat.type !== 'private') {
      const chatId = ctx.chat.id;
      const chatTitle = ctx.chat.title;
      
      // Cek jika grup sudah ada di database
      const existingGroup = groupDB.get(chatId);
      if (!existingGroup) {
        groupDB.add(chatId, chatTitle);
      } else if (!existingGroup.active) {
        // Aktifkan kembali grup jika sebelumnya nonaktif
        groupDB.add(chatId, chatTitle);
      }
    }
    
    // Simpan user ke database
    userDB.add(ctx.from.id);
  });
}

module.exports = {
  setupCallbackQueryHandler,
  setupNewChatMembersHandler,
  setupLeftChatMemberHandler,
  setupMessageHandler
};