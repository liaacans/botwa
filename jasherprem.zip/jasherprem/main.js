require('./config');
const { Telegraf } = require('telegraf');
const { connectDB, getDB } = require('./lib/database');
const {
  handleStart,
  handleHelp,
  handleCredit,
  handleShare,
  handleShareVip,
  handleAddPrem,
  handleDelPrem,
  handleListPrem,
  handleCallbackQuery
} = require('./src/commands');
const {
  handleNewChatMembers,
  handleLeftChatMember,
  handleRegisterGroup
} = require('./src/handlers');

const bot = new Telegraf(global.BOT_TOKEN);

// Connect to MongoDB
connectDB().then(() => {
  console.log('Database connected, starting bot...');
});

// Command handlers
bot.command('start', handleStart);
bot.command('help', handleHelp);
bot.command('credit', handleCredit);
bot.command('share', handleShare);
bot.command('sharevip', handleShareVip);
bot.command('addprem', handleAddPrem);
bot.command('delprem', handleDelPrem);
bot.command('listprem', handleListPrem);
bot.command('register', handleRegisterGroup);

// Event handlers
bot.on('new_chat_members', handleNewChatMembers);
bot.on('left_chat_member', handleLeftChatMember);

// Callback query handler (for buttons)
bot.on('callback_query', handleCallbackQuery);

// Error handling
bot.catch((err, ctx) => {
  console.error(`Error for ${ctx.updateType}:`, err);
  ctx.reply('❌ Terjadi error! Silakan coba lagi nanti.');
});

// Start bot
bot.launch().then(() => {
  console.log('Bot started!');
});

// Enable graceful stop
process.once('SIGINT', () => {
  bot.stop('SIGINT');
  process.exit();
});

process.once('SIGTERM', () => {
  bot.stop('SIGTERM');
  process.exit();
});