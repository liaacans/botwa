const { Markup } = require('telegraf');
const { isPremium, addPremium, removePremium, updateProgress } = require('../lib/utils');
const axios = require('axios');

// Owner commands
function handleAddPrem(ctx) {
  // Check if user is owner
  const isCreator = ctx.from.id.toString() === process.env.CREATOR_ID;
  if (!isCreator) {
    return ctx.reply('Hanya owner yang bisa menggunakan perintah ini.');
  }
  
  const args = ctx.message.text.split(' ');
  if (args.length < 3) {
    return ctx.reply('Usage: /addprem [userid] [days]');
  }
  
  const userId = args[1];
  const days = parseInt(args[2]);
  
  if (isNaN(days) || days <= 0) {
    return ctx.reply('Hari harus berupa angka positif');
  }
  
  addPremium(userId, days);
  ctx.reply(`✅ Berhasil menambahkan ${days} hari premium untuk user ${userId}`);
}

function handleDelPrem(ctx) {
  // Check if user is owner
  const isCreator = ctx.from.id.toString() === process.env.CREATOR_ID;
  if (!isCreator) {
    return ctx.reply('Hanya owner yang bisa menggunakan perintah ini.');
  }
  
  const args = ctx.message.text.split(' ');
  if (args.length < 2) {
    return ctx.reply('Usage: /delprem [userid]');
  }
  
  const userId = args[1];
  removePremium(userId);
  ctx.reply(`✅ Berhasil menghapus premium untuk user ${userId}`);
}

function handleListPrem(ctx) {
  // Check if user is owner
  const isCreator = ctx.from.id.toString() === process.env.CREATOR_ID;
  if (!isCreator) {
    return ctx.reply('Hanya owner yang bisa menggunakan perintah ini.');
  }
  
  let listText = '👑 *DAFTAR USER PREMIUM* 👑\n\n';
  let count = 0;
  
  for (const [userId, data] of global.db.premium) {
    const expiryDate = new Date(data.expiry);
    const daysLeft = Math.ceil((data.expiry - Date.now()) / (1000 * 60 * 60 * 24));
    
    if (daysLeft > 0) {
      count++;
      listText += `${count}. User ID: ${userId}\n   Berakhir: ${expiryDate.toLocaleDateString('id-ID')} (${daysLeft} hari lagi)\n\n`;
    }
  }
  
  if (count === 0) {
    listText = 'Tidak ada user premium.';
  }
  
  ctx.reply(listText, { parse_mode: 'Markdown' });
}

function handleAddBl(ctx) {
  // Check if user is owner
  const isCreator = ctx.from.id.toString() === process.env.CREATOR_ID;
  if (!isCreator) {
    return ctx.reply('Hanya owner yang bisa menggunakan perintah ini.');
  }
  
  const args = ctx.message.text.split(' ');
  if (args.length < 2) {
    return ctx.reply('Usage: /addbl [userid/groupid]');
  }
  
  const id = args[1];
  global.db.blacklist.add(id);
  ctx.reply(`✅ Berhasil menambahkan ${id} ke blacklist`);
}

function handleDelBl(ctx) {
  // Check if user is owner
  const isCreator = ctx.from.id.toString() === process.env.CREATOR_ID;
  if (!isCreator) {
    return ctx.reply('Hanya owner yang bisa menggunakan perintah ini.');
  }
  
  const args = ctx.message.text.split(' ');
  if (args.length < 2) {
    return ctx.reply('Usage: /delbl [userid/groupid]');
  }
  
  const id = args[1];
  global.db.blacklist.delete(id);
  ctx.reply(`✅ Berhasil menghapus ${id} dari blacklist`);
}

function handleListBl(ctx) {
  // Check if user is owner
  const isCreator = ctx.from.id.toString() === process.env.CREATOR_ID;
  if (!isCreator) {
    return ctx.reply('Hanya owner yang bisa menggunakan perintah ini.');
  }
  
  let listText = '🚫 *DAFTAR BLACKLIST* 🚫\n\n';
  let count = 0;
  
  for (const id of global.db.blacklist) {
    count++;
    listText += `${count}. ID: ${id}\n`;
  }
  
  if (count === 0) {
    listText = 'Tidak ada yang di-blacklist.';
  }
  
  ctx.reply(listText, { parse_mode: 'Markdown' });
}

function handleAutoJasher(ctx) {
  // Check if user is owner
  const isCreator = ctx.from.id.toString() === process.env.CREATOR_ID;
  if (!isCreator) {
    return ctx.reply('Hanya owner yang bisa menggunakan perintah ini.');
  }
  
  if (global.db.autoShare.enabled) {
    return ctx.reply('Auto Jasher sudah aktif.');
  }
  
  // Start auto share every 10 minutes
  global.db.autoShare.enabled = true;
  global.db.autoShare.interval = setInterval(() => {
    // Implementation for auto sharing
    console.log('Auto sharing...');
  }, 10 * 60 * 1000); // 10 minutes
  
  ctx.reply('✅ Auto Jasher telah diaktifkan. Akan berjalan setiap 10 menit.');
}

function handleStopAutoJasher(ctx) {
  // Check if user is owner
  const isCreator = ctx.from.id.toString() === process.env.CREATOR_ID;
  if (!isCreator) {
    return ctx.reply('Hanya owner yang bisa menggunakan perintah ini.');
  }
  
  if (!global.db.autoShare.enabled) {
    return ctx.reply('Auto Jasher tidak aktif.');
  }
  
  // Stop auto share
  global.db.autoShare.enabled = false;
  clearInterval(global.db.autoShare.interval);
  global.db.autoShare.interval = null;
  
  ctx.reply('✅ Auto Jasher telah dihentikan.');
}

function handleListGroup(ctx) {
  // Check if user is owner
  const isCreator = ctx.from.id.toString() === process.env.CREATOR_ID;
  if (!isCreator) {
    return ctx.reply('Hanya owner yang bisa menggunakan perintah ini.');
  }
  
  let listText = '👥 *DAFTAR GRUP AKTIF* 👥\n\n';
  let count = 0;
  
  for (const [chatId, data] of global.db.groups) {
    if (data.active) {
      count++;
      const addedDate = new Date(data.addedAt).toLocaleDateString('id-ID');
      listText += `${count}. ${data.title} (${data.type})\n   ID: ${chatId}\n   Ditambahkan: ${addedDate}\n\n`;
    }
  }
  
  if (count === 0) {
    listText = 'Tidak ada grup aktif.';
  }
  
  ctx.reply(listText, { parse_mode: 'Markdown' });
}

function handleToUrl(ctx) {
  if (!ctx.message.reply_to_message) {
    return ctx.reply('Balas pesan yang berisi media (foto, video, dll).');
  }
  
  const replied = ctx.message.reply_to_message;
  let fileId = '';
  let fileType = '';
  
  if (replied.photo) {
    fileId = replied.photo[replied.photo.length - 1].file_id;
    fileType = 'photo';
  } else if (replied.video) {
    fileId = replied.video.file_id;
    fileType = 'video';
  } else if (replied.document) {
    fileId = replied.document.file_id;
    fileType = 'document';
  } else if (replied.audio) {
    fileId = replied.audio.file_id;
    fileType = 'audio';
  } else {
    return ctx.reply('Pesan yang dibalas tidak mengandung media yang didukung.');
  }
  
  // Get file URL (in a real implementation, you would use the Telegram Bot API)
  ctx.reply(`File ${fileType}: https://api.telegram.org/file/bot${global.BOT_TOKEN}/${fileId}`);
}

function handleBroadcast(ctx) {
  // Check if user is owner
  const isCreator = ctx.from.id.toString() === process.env.CREATOR_ID;
  if (!isCreator) {
    return ctx.reply('Hanya owner yang bisa menggunakan perintah ini.');
  }
  
  const args = ctx.message.text.split(' ');
  if (args.length < 2) {
    return ctx.reply('Usage: /bc [message]');
  }
  
  const message = args.slice(1).join(' ');
  let successCount = 0;
  let failCount = 0;
  
  // Broadcast to all users
  for (const [userId, userData] of global.db.users) {
    try {
      ctx.telegram.sendMessage(userId, `📢 *BROADCAST* 📢\n\n${message}`, { parse_mode: 'Markdown' });
      successCount++;
    } catch (error) {
      console.error(`Failed to send broadcast to ${userId}:`, error.message);
      failCount++;
    }
  }
  
  ctx.reply(`✅ Broadcast selesai.\nBerhasil: ${successCount}\nGagal: ${failCount}`);
}

// Handle text messages for sharing
function handleTextMessage(ctx) {
  // Check if message is in private chat and contains share text
  if (ctx.chat.type !== 'private') {
    return;
  }
  
  const text = ctx.message.text;
  const userId = ctx.from.id.toString();
  const userData = global.db.users.get(userId) || {
    userId: ctx.from.id,
    joinedGroups: new Set(),
    shareCount: 0,
    lastShare: 0
  };
  
  // Check if text contains bot mention or share message
  if (text.includes('@' + ctx.botInfo.username) || text.includes('t.me/' + ctx.botInfo.username)) {
    // Check cooldown (1 hour)
    const now = Date.now();
    if (now - userData.lastShare < 60 * 60 * 1000) {
      const remaining = Math.ceil((60 * 60 * 1000 - (now - userData.lastShare)) / (60 * 1000));
      return ctx.reply(`Anda harus menunggu ${remaining} menit sebelum bisa share lagi.`);
    }
    
    // Update share count
    userData.shareCount++;
    userData.lastShare = now;
    global.db.users.set(userId, userData);
    
    ctx.reply('✅ Terima kasih telah membagikan bot! Share count: ' + userData.shareCount);
  }
}

module.exports = {
  handleAddPrem,
  handleDelPrem,
  handleListPrem,
  handleAddBl,
  handleDelBl,
  handleListBl,
  handleAutoJasher,
  handleStopAutoJasher,
  handleListGroup,
  handleToUrl,
  handleBroadcast,
  handleTextMessage
};