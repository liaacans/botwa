const { Telegraf } = require('telegraf');
const { BOT_TOKEN } = require('./config');
const { User, Group } = require('./lib/database');
const commands = require('./src/commands');
const handlers = require('./src/handlers');

const bot = new Telegraf(BOT_TOKEN);

// Command handlers
bot.command('start', commands.handleStart);
bot.command('help', commands.handleHelp);
bot.command('credit', commands.handleCredit);
bot.command('share', commands.handleShare);

// Owner commands
bot.command('addprem', async (ctx) => {
    if (ctx.from.id.toString() !== process.env.OWNER_ID) {
        return ctx.reply('Akses ditolak. Hanya owner yang dapat menggunakan perintah ini.');
    }
    
    const args = ctx.message.text.split(' ');
    if (args.length < 2) {
        return ctx.reply('Format: /addprem [user_id]');
    }
    
    const userId = parseInt(args[1]);
    if (isNaN(userId)) {
        return ctx.reply('User ID harus berupa angka.');
    }
    
    try {
        const user = await User.findOneAndUpdate(
            { userId },
            { isPremium: true },
            { new: true, upsert: true }
        );
        
        ctx.reply(`User ${userId} berhasil ditambahkan sebagai premium.`);
    } catch (error) {
        console.error('Error adding premium:', error);
        ctx.reply('Terjadi kesalahan saat menambahkan premium.');
    }
});

bot.command('delprem', async (ctx) => {
    if (ctx.from.id.toString() !== process.env.OWNER_ID) {
        return ctx.reply('Akses ditolak. Hanya owner yang dapat menggunakan perintah ini.');
    }
    
    const args = ctx.message.text.split(' ');
    if (args.length < 2) {
        return ctx.reply('Format: /delprem [user_id]');
    }
    
    const userId = parseInt(args[1]);
    if (isNaN(userId)) {
        return ctx.reply('User ID harus berupa angka.');
    }
    
    try {
        const user = await User.findOneAndUpdate(
            { userId },
            { isPremium: false },
            { new: true }
        );
        
        if (user) {
            ctx.reply(`User ${userId} berhasil dihapus dari premium.`);
        } else {
            ctx.reply(`User ${userId} tidak ditemukan.`);
        }
    } catch (error) {
        console.error('Error removing premium:', error);
        ctx.reply('Terjadi kesalahan saat menghapus premium.');
    }
});

bot.command('broadcast', async (ctx) => {
    if (ctx.from.id.toString() !== process.env.OWNER_ID) {
        return ctx.reply('Akses ditolak. Hanya owner yang dapat menggunakan perintah ini.');
    }
    
    const repliedMessage = ctx.message.reply_to_message;
    if (!repliedMessage) {
        return ctx.reply('Anda harus mereply pesan yang ingin di-broadcast.');
    }
    
    try {
        const allUsers = await User.find({});
        let successCount = 0;
        let failCount = 0;
        
        for (const user of allUsers) {
            try {
                await ctx.telegram.copyMessage(user.userId, ctx.chat.id, repliedMessage.message_id);
                successCount++;
            } catch (error) {
                console.error(`Failed to send broadcast to user ${user.userId}:`, error);
                failCount++;
            }
            
            // Delay untuk menghindari limit Telegram
            await new Promise(resolve => setTimeout(resolve, 100));
        }
        
        ctx.reply(`Broadcast selesai. Berhasil: ${successCount}, Gagal: ${failCount}`);
    } catch (error) {
        console.error('Error in broadcast:', error);
        ctx.reply('Terjadi kesalahan saat melakukan broadcast.');
    }
});

// Callback query handler
bot.on('callback_query', handlers.handleCallbackQuery);

// Event ketika bot ditambahkan ke grup
bot.on('chat_member', async (ctx) => {
    if (ctx.chatMember.new_chat_member.status === 'member' && 
        ctx.chatMember.new_chat_member.user.id === ctx.botInfo.id) {
        // Bot ditambahkan ke grup
        const groupId = ctx.chat.id;
        const groupTitle = ctx.chat.title;
        const groupUsername = ctx.chat.username;
        const addedBy = ctx.chatMember.from.id;
        
        try {
            // Cek apakah grup sudah ada
            let group = await Group.findOne({ groupId });
            
            if (!group) {
                // Simpan grup baru
                group = new Group({
                    groupId,
                    title: groupTitle,
                    username: groupUsername,
                    addedBy
                });
                await group.save();
                
                // Tambahkan kredit ke user
                const user = await User.findOne({ userId: addedBy });
                if (user) {
                    user.addedGroups.push(groupId);
                    
                    // Beri 3 kredit untuk setiap grup yang ditambahkan
                    if (user.addedGroups.length <= 3) {
                        user.credit += 3;
                        await user.save();
                        
                        // Kirim pesan ke user
                        await ctx.telegram.sendMessage(
                            addedBy, 
                            `Terima kasih telah menambahkan bot ke grup "${groupTitle}". Anda mendapat 3 kredit! Total kredit: ${user.credit}`
                        );
                    } else {
                        await user.save();
                    }
                }
            }
        } catch (error) {
            console.error('Error handling new group:', error);
        }
    }
});

// Error handling
bot.catch((err, ctx) => {
    console.error(`Error for ${ctx.updateType}:`, err);
});

// Start bot
bot.launch().then(() => {
    console.log('Bot Jasher started successfully');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));