const { isPremium } = require('../../lib/utils');
const { getUser } = require('../../lib/database');

module.exports = (bot) => {
    // Handle text messages untuk share free/vip
    bot.on('text', async (ctx) => {
        if (ctx.chat.type !== 'private') return;

        const text = ctx.message.text.toLowerCase();
        const user = getUser(ctx.from.id);

        // Handle share free/vip di private chat
        if (text === 'sharefree' || text === 'sharevip') {
            if (text === 'sharefree') {
                if ((user?.groups_added || 0) < 3) {
                    await ctx.reply(
                        `❌ Anda harus menambahkan bot ke 3 group terlebih dahulu!\n` +
                        `📊 Status: ${user?.groups_added || 0}/3 group\n\n` +
                        `Tambahkan bot ke group dan gunakan /addgroup di group tersebut.`
                    );
                    return;
                }

                // Add 3 days premium
                const { addPremium } = require('../../lib/utils');
                const expiry = addPremium(ctx.from.id, 3);
                
                await ctx.reply(
                    `✅ *Share Free Berhasil!*\n\n` +
                    `⭐ Premium aktif selama 3 hari\n` +
                    `⏰ Berakhir: ${new Date(expiry).toLocaleDateString('id-ID')}\n\n` +
                    `Sekarang Anda bisa menggunakan fitur Share VIP!`,
                    { parse_mode: 'Markdown' }
                );
            } else {
                if (!isPremium(ctx.from.id)) {
                    await ctx.reply(
                        `❌ Anda harus premium untuk menggunakan Share VIP!\n\n` +
                        `Gunakan Share Free terlebih dahulu atau beli premium.`
                    );
                    return;
                }

                await ctx.reply(
                    `💎 *Share VIP Ready!*\n\n` +
                    `Balas pesan yang ingin di-share atau ketik pesan langsung.`
                );
            }
        }

        // Handle broadcast dari owner
        if (ctx.message.reply_to_message && ctx.message.reply_to_message.text.includes('Broadcast Message')) {
            const { isOwner } = require('../../lib/utils');
            if (isOwner(ctx.from.id)) {
                await handleOwnerBroadcast(ctx);
            }
        }
    });

    // Handle document messages untuk obfuscation
    bot.on('document', async (ctx) => {
        // Document handling sudah di-handle oleh commands obfuscation
    });

    async function handleOwnerBroadcast(ctx) {
        const message = ctx.message.text;
        const users = require('fs-extra').readJsonSync(global.USERS_DB);
        const userIds = Object.keys(users);
        
        let success = 0;
        let failed = 0;

        const progressMessage = await ctx.reply(`🚀 Memulai broadcast ke ${userIds.length} users...`);

        for (const userId of userIds) {
            try {
                await ctx.telegram.sendMessage(userId, `📢 *Broadcast dari Owner:*\n\n${message}`, { 
                    parse_mode: 'Markdown' 
                });
                success++;
                
                // Update progress setiap 10 pengiriman
                if (success % 10 === 0) {
                    await ctx.telegram.editMessageText(
                        progressMessage.chat.id,
                        progressMessage.message_id,
                        null,
                        `🚀 Broadcast progress: ${success}/${userIds.length} users...`
                    );
                }
                
                // Delay to avoid rate limiting
                await new Promise(resolve => setTimeout(resolve, 100));
            } catch (error) {
                failed++;
            }
        }

        await ctx.telegram.editMessageText(
            progressMessage.chat.id,
            progressMessage.message_id,
            null,
            `✅ *Broadcast Selesai!*\n\n` +
            `✅ Berhasil: ${success} users\n` +
            `❌ Gagal: ${failed} users`,
            { parse_mode: 'Markdown' }
        );
    }
};