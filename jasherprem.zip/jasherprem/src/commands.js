const { Markup } = require('telegraf');
const moment = require('moment-timezone');
const db = require('../lib/database');
const utils = require('../lib/utils');
const obf = require('./obf');
const fs = require('fs');
const path = require('path');
const axios = require('axios');

// Start command
async function start(ctx) {
  const userId = ctx.from.id;
  const username = ctx.from.username || '';
  const firstName = ctx.from.first_name || '';
  const lastName = ctx.from.last_name || '';
  
  // Add user to database if not exists
  await db.addUser(userId, username, firstName, lastName);
  
  const user = await db.getUser(userId);
  const isCreator = utils.isCreator(userId);
  
  const message = `╭─❒ 「 User Info 」 
├ Creator : @${global.developer}
├ Name : @${username}
├ Profile : @${ctx.from.username || 'No username'}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${utils.runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreator ? 'True' : 'False'}

Silahkan pilih button dibawah ini!`;
  
  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('Jasher Menu', 'jasher_menu')],
    [Markup.button.callback('Owner Menu', 'owner_menu')],
    [Markup.button.callback('Obf Menu', 'obf_menu')]
  ]);
  
  // Send photo with caption and buttons
  await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
    caption: message,
    parse_mode: 'HTML',
    ...keyboard
  });
}

// Menu command
async function menu(ctx) {
  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('Jasher Menu', 'jasher_menu')],
    [Markup.button.callback('Owner Menu', 'owner_menu')],
    [Markup.button.callback('Obf Menu', 'obf_menu')],
    [Markup.button.callback('Kembali', 'back_menu')],
    [Markup.button.callback('Main Menu', 'main_menu')]
  ]);
  
  await ctx.reply('Pilih menu yang tersedia:', keyboard);
}

// Owner command
async function owner(ctx) {
  const isCreator = utils.isCreator(ctx.from.id);
  
  if (!isCreator) {
    return ctx.reply('Anda bukan owner bot!');
  }
  
  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('Add Premium', 'add_premium')],
    [Markup.button.callback('Remove Premium', 'remove_premium')],
    [Markup.button.callback('List Premium', 'list_premium')],
    [Markup.button.callback('Broadcast', 'broadcast')],
    [Markup.button.callback('Blacklist Group', 'blacklist_group')],
    [Markup.button.callback('Auto Jasher', 'auto_jasher')],
    [Markup.button.callback('List Groups', 'list_groups')],
    [Markup.button.callback('Kembali', 'back_menu')]
  ]);
  
  await ctx.reply('Owner Menu:', keyboard);
}

// Add premium command
async function addPrem(ctx) {
  const isCreator = utils.isCreator(ctx.from.id);
  
  if (!isCreator) {
    return ctx.reply('Anda bukan owner bot!');
  }
  
  const args = ctx.message.text.split(' ');
  if (args.length < 3) {
    return ctx.reply('Format: /addprem <user_id> <days>');
  }
  
  const userId = parseInt(args[1]);
  const days = parseInt(args[2]);
  
  if (isNaN(userId) || isNaN(days)) {
    return ctx.reply('User ID dan days harus angka!');
  }
  
  const premiumUntil = moment().add(days, 'days').format('YYYY-MM-DD HH:mm:ss');
  
  try {
    await db.updateUserPremium(userId, true, premiumUntil);
    ctx.reply(`Berhasil menambahkan premium untuk user ${userId} selama ${days} hari.`);
  } catch (error) {
    ctx.reply('Gagal menambahkan premium: ' + error.message);
  }
}

// Remove premium command
async function delPrem(ctx) {
  const isCreator = utils.isCreator(ctx.from.id);
  
  if (!isCreator) {
    return ctx.reply('Anda bukan owner bot!');
  }
  
  const args = ctx.message.text.split(' ');
  if (args.length < 2) {
    return ctx.reply('Format: /delprem <user_id>');
  }
  
  const userId = parseInt(args[1]);
  
  if (isNaN(userId)) {
    return ctx.reply('User ID harus angka!');
  }
  
  try {
    await db.updateUserPremium(userId, false, null);
    ctx.reply(`Berhasil menghapus premium untuk user ${userId}.`);
  } catch (error) {
    ctx.reply('Gagal menghapus premium: ' + error.message);
  }
}

// List premium command
async function listPrem(ctx) {
  const isCreator = utils.isCreator(ctx.from.id);
  
  if (!isCreator) {
    return ctx.reply('Anda bukan owner bot!');
  }
  
  try {
    const premiumUsers = await db.getPremiumUsers();
    
    if (premiumUsers.length === 0) {
      return ctx.reply('Tidak ada user premium.');
    }
    
    let message = 'Daftar User Premium:\n\n';
    premiumUsers.forEach(user => {
      message += `ID: ${user.id}\nUsername: @${user.username || 'N/A'}\nPremium Until: ${user.premium_until || 'N/A'}\n\n`;
    });
    
    ctx.reply(message);
  } catch (error) {
    ctx.reply('Gagal mendapatkan daftar premium: ' + error.message);
  }
}

// Add blacklist command
async function addBl(ctx) {
  const isCreator = utils.isCreator(ctx.from.id);
  
  if (!isCreator) {
    return ctx.reply('Anda bukan owner bot!');
  }
  
  const args = ctx.message.text.split(' ');
  if (args.length < 2) {
    return ctx.reply('Format: /addbl <group_id> [reason]');
  }
  
  const groupId = parseInt(args[1]);
  const reason = args.slice(2).join(' ') || '';
  
  if (isNaN(groupId)) {
    return ctx.reply('Group ID harus angka!');
  }
  
  try {
    await db.addToBlacklist(groupId, reason);
    ctx.reply(`Berhasil menambahkan group ${groupId} ke blacklist.`);
  } catch (error) {
    ctx.reply('Gagal menambahkan blacklist: ' + error.message);
  }
}

// Remove blacklist command
async function delBl(ctx) {
  const isCreator = utils.isCreator(ctx.from.id);
  
  if (!isCreator) {
    return ctx.reply('Anda bukan owner bot!');
  }
  
  const args = ctx.message.text.split(' ');
  if (args.length < 2) {
    return ctx.reply('Format: /delbl <group_id>');
  }
  
  const groupId = parseInt(args[1]);
  
  if (isNaN(groupId)) {
    return ctx.reply('Group ID harus angka!');
  }
  
  try {
    await db.removeFromBlacklist(groupId);
    ctx.reply(`Berhasil menghapus group ${groupId} dari blacklist.`);
  } catch (error) {
    ctx.reply('Gagal menghapus blacklist: ' + error.message);
  }
}

// List blacklist command
async function listBl(ctx) {
  const isCreator = utils.isCreator(ctx.from.id);
  
  if (!isCreator) {
    return ctx.reply('Anda bukan owner bot!');
  }
  
  try {
    const blacklist = await db.getBlacklist();
    
    if (blacklist.length === 0) {
      return ctx.reply('Tidak ada group dalam blacklist.');
    }
    
    let message = 'Daftar Blacklist Group:\n\n';
    blacklist.forEach(item => {
      message += `Group ID: ${item.group_id}\nReason: ${item.reason || 'N/A'}\nAdded: ${item.added_at}\n\n`;
    });
    
    ctx.reply(message);
  } catch (error) {
    ctx.reply('Gagal mendapatkan daftar blacklist: ' + error.message);
  }
}

// Auto Jasher command
async function autoJasher(ctx) {
  const isCreator = utils.isCreator(ctx.from.id);
  
  if (!isCreator) {
    return ctx.reply('Anda bukan owner bot!');
  }
  
  const args = ctx.message.text.split(' ');
  const interval = args.length > 1 ? parseInt(args[1]) : 10;
  
  if (isNaN(interval) || interval < 1) {
    return ctx.reply('Interval harus angka dan minimal 1 menit!');
  }
  
  try {
    await db.updateAutoJasherSettings(true, interval);
    ctx.reply(`Auto Jasher diaktifkan dengan interval ${interval} menit.`);
  } catch (error) {
    ctx.reply('Gagal mengaktifkan Auto Jasher: ' + error.message);
  }
}

// Stop Auto Jasher command
async function stopAutoJasher(ctx) {
  const isCreator = utils.isCreator(ctx.from.id);
  
  if (!isCreator) {
    return ctx.reply('Anda bukan owner bot!');
  }
  
  try {
    await db.updateAutoJasherSettings(false, 10);
    ctx.reply('Auto Jasher dinonaktifkan.');
  } catch (error) {
    ctx.reply('Gagal menonaktifkan Auto Jasher: ' + error.message);
  }
}

// List groups command
async function listGrup(ctx) {
  const isCreator = utils.isCreator(ctx.from.id);
  
  if (!isCreator) {
    return ctx.reply('Anda bukan owner bot!');
  }
  
  try {
    const groups = await db.getAllGroups();
    
    if (groups.length === 0) {
      return ctx.reply('Tidak ada group yang terdaftar.');
    }
    
    let message = 'Daftar Group Aktif:\n\n';
    groups.forEach(group => {
      message += `ID: ${group.id}\nNama: ${group.name}\nAdded By: ${group.added_by}\nAdded: ${group.added_at}\n\n`;
    });
    
    ctx.reply(message);
  } catch (error) {
    ctx.reply('Gagal mendapatkan daftar group: ' + error.message);
  }
}

// To URL command (convert photo to URL)
async function toUrl(ctx) {
  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.photo) {
    return ctx.reply('Balas ke foto untuk mengonversi ke URL!');
  }
  
  try {
    const photo = ctx.message.reply_to_message.photo;
    const fileId = photo[photo.length - 1].file_id;
    const file = await ctx.telegram.getFile(fileId);
    const fileUrl = `https://api.telegram.org/file/bot${global.BOT_TOKEN}/${file.file_path}`;
    
    ctx.reply(`URL Foto: ${fileUrl}`);
  } catch (error) {
    ctx.reply('Gagal mendapatkan URL foto: ' + error.message);
  }
}

// Share VIP command
async function shareVip(ctx) {
  if (ctx.chat.type !== 'private') {
    return ctx.reply('Command ini hanya bisa digunakan di private chat!');
  }
  
  const user = await db.getUser(ctx.from.id);
  const isPremium = user && user.is_premium && moment().isBefore(user.premium_until);
  
  if (!isPremium) {
    return ctx.reply('Anda harus premium untuk menggunakan fitur Share VIP!');
  }
  
  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.text) {
    return ctx.reply('Balas ke pesan yang ingin di-share!');
  }
  
  const textToShare = ctx.message.reply_to_message.text;
  const groups = await db.getAllGroups();
  
  if (groups.length === 0) {
    return ctx.reply('Tidak ada group yang terdaftar untuk di-share.');
  }
  
  let successCount = 0;
  let failCount = 0;
  
  for (const group of groups) {
    try {
      await ctx.telegram.sendMessage(group.id, textToShare);
      successCount++;
    } catch (error) {
      console.error(`Gagal mengirim ke group ${group.id}:`, error.message);
      failCount++;
    }
  }
  
  ctx.reply(`Broadcast VIP selesai!\nBerhasil: ${successCount}\nGagal: ${failCount}`);
}

// Obfuscation commands
async function enclocked(ctx) {
  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.reply('Balas ke file JavaScript untuk di-obfuscate dengan Time-Locked Encryption!');
  }
  
  const args = ctx.message.text.split(' ');
  if (args.length < 2) {
    return ctx.reply('Format: /enclocked <days>');
  }
  
  const days = parseInt(args[1]);
  if (isNaN(days) || days < 1) {
    return ctx.reply('Days harus angka dan minimal 1!');
  }
  
  try {
    const document = ctx.message.reply_to_message.document;
    const fileId = document.file_id;
    const file = await ctx.telegram.getFile(fileId);
    const fileUrl = `https://api.telegram.org/file/bot${global.BOT_TOKEN}/${file.file_path}`;
    
    // Download the file
    const response = await axios.get(fileUrl, { responseType: 'arraybuffer' });
    const fileContent = response.data.toString('utf8');
    
    // Obfuscate with time-locked encryption
    const obfuscatedCode = await obf.obfuscateTimeLocked(fileContent, days);
    
    // Send the obfuscated file
    await ctx.replyWithDocument({
      source: Buffer.from(obfuscatedCode),
      filename: `obfuscated_time_locked_${days}days.js`
    });
    
    ctx.reply('Obfuscation Time-Locked Encryption berhasil!');
  } catch (error) {
    ctx.reply('Gagal melakukan obfuscation: ' + error.message);
  }
}

async function quantum(ctx) {
  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.reply('Balas ke file JavaScript untuk di-obfuscate dengan Quantum Vortex Encryption!');
  }
  
  try {
    const document = ctx.message.reply_to_message.document;
    const fileId = document.file_id;
    const file = await ctx.telegram.getFile(fileId);
    const fileUrl = `https://api.telegram.org/file/bot${global.BOT_TOKEN}/${file.file_path}`;
    
    // Download the file
    const response = await axios.get(fileUrl, { responseType: 'arraybuffer' });
    const fileContent = response.data.toString('utf8');
    
    // Obfuscate with quantum vortex encryption
    const obfuscatedCode = await obf.obfuscateQuantum(fileContent);
    
    // Send the obfuscated file
    await ctx.replyWithDocument({
      source: Buffer.from(obfuscatedCode),
      filename: 'obfuscated_quantum.js'
    });
    
    ctx.reply('Obfuscation Quantum Vortex Encryption berhasil!');
  } catch (error) {
    ctx.reply('Gagal melakukan obfuscation: ' + error.message);
  }
}

async function siuCalcrick(ctx) {
  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.reply('Balas ke file JavaScript untuk di-obfuscate dengan Siu Calcrick Encryption!');
  }
  
  try {
    const document = ctx.message.reply_to_message.document;
    const fileId = document.file_id;
    const file = await ctx.telegram.getFile(fileId);
    const fileUrl = `https://api.telegram.org/file/bot${global.BOT_TOKEN}/${file.file_path}`;
    
    // Download the file
    const response = await axios.get(fileUrl, { responseType: 'arraybuffer' });
    const fileContent = response.data.toString('utf8');
    
    // Obfuscate with Siu Calcrick encryption
    const config = obf.getSiuCalcrickObfuscationConfig();
    const obfuscated = await global.JsConfuser.obfuscate(fileContent, config);
    const obfuscatedCode = obfuscated.code || obfuscated;
    
    // Send the obfuscated file
    await ctx.replyWithDocument({
      source: Buffer.from(obfuscatedCode),
      filename: 'obfuscated_siu_calcrick.js'
    });
    
    ctx.reply('Obfuscation Siu Calcrick Encryption berhasil!');
  } catch (error) {
    ctx.reply('Gagal melakukan obfuscation: ' + error.message);
  }
}

async function custom(ctx) {
  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.reply('Balas ke file JavaScript untuk di-obfuscate dengan Custom Encryption!');
  }
  
  const args = ctx.message.text.split(' ');
  if (args.length < 2) {
    return ctx.reply('Format: /custom <custom_string>');
  }
  
  const customString = args.slice(1).join(' ');
  
  try {
    const document = ctx.message.reply_to_message.document;
    const fileId = document.file_id;
    const file = await ctx.telegram.getFile(fileId);
    const fileUrl = `https://api.telegram.org/file/bot${global.BOT_TOKEN}/${file.file_path}`;
    
    // Download the file
    const response = await axios.get(fileUrl, { responseType: 'arraybuffer' });
    const fileContent = response.data.toString('utf8');
    
    // Obfuscate with custom encryption
    const config = obf.getCustomObfuscationConfig(customString);
    const obfuscated = await global.JsConfuser.obfuscate(fileContent, config);
    const obfuscatedCode = obfuscated.code || obfuscated;
    
    // Send the obfuscated file
    await ctx.replyWithDocument({
      source: Buffer.from(obfuscatedCode),
      filename: 'obfuscated_custom.js'
    });
    
    ctx.reply('Obfuscation Custom Encryption berhasil!');
  } catch (error) {
    ctx.reply('Gagal melakukan obfuscation: ' + error.message);
  }
}

async function nebula(ctx) {
  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.reply('Balas ke file JavaScript untuk di-obfuscate dengan Nebula Encryption!');
  }
  
  try {
    const document = ctx.message.reply_to_message.document;
    const fileId = document.file_id;
    const file = await ctx.telegram.getFile(fileId);
    const fileUrl = `https://api.telegram.org/file/bot${global.BOT_TOKEN}/${file.file_path}`;
    
    // Download the file
    const response = await axios.get(fileUrl, { responseType: 'arraybuffer' });
    const fileContent = response.data.toString('utf8');
    
    // Obfuscate with Nebula encryption
    const config = obf.getNebulaObfuscationConfig();
    const obfuscated = await global.JsConfuser.obfuscate(fileContent, config);
    const obfuscatedCode = obfuscated.code || obfuscated;
    
    // Send the obfuscated file
    await ctx.replyWithDocument({
      source: Buffer.from(obfuscatedCode),
      filename: 'obfuscated_nebula.js'
    });
    
    ctx.reply('Obfuscation Nebula Encryption berhasil!');
  } catch (error) {
    ctx.reply('Gagal melakukan obfuscation: ' + error.message);
  }
}

async function nova(ctx) {
  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.reply('Balas ke file JavaScript untuk di-obfuscate dengan Nova Encryption!');
  }
  
  try {
    const document = ctx.message.reply_to_message.document;
    const fileId = document.file_id;
    const file = await ctx.telegram.getFile(fileId);
    const fileUrl = `https://api.telegram.org/file/bot${global.BOT_TOKEN}/${file.file_path}`;
    
    // Download the file
    const response = await axios.get(fileUrl, { responseType: 'arraybuffer' });
    const fileContent = response.data.toString('utf8');
    
    // Obfuscate with Nova encryption
    const config = obf.getNovaObfuscationConfig();
    const obfuscated = await global.JsConfuser.obfuscate(fileContent, config);
    const obfuscatedCode = obfuscated.code || obfuscated;
    
    // Send the obfuscated file
    await ctx.replyWithDocument({
      source: Buffer.from(obfuscatedCode),
      filename: 'obfuscated_nova.js'
    });
    
    ctx.reply('Obfuscation Nova Encryption berhasil!');
  } catch (error) {
    ctx.reply('Gagal melakukan obfuscation: ' + error.message);
  }
}

async function strong(ctx) {
  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.reply('Balas ke file JavaScript untuk di-obfuscate dengan Strong Encryption!');
  }
  
  try {
    const document = ctx.message.reply_to_message.document;
    const fileId = document.file_id;
    const file = await ctx.telegram.getFile(fileId);
    const fileUrl = `https://api.telegram.org/file/bot${global.BOT_TOKEN}/${file.file_path}`;
    
    // Download the file
    const response = await axios.get(fileUrl, { responseType: 'arraybuffer' });
    const fileContent = response.data.toString('utf8');
    
    // Obfuscate with Strong encryption
    const config = obf.getStrongObfuscationConfig();
    const obfuscated = await global.JsConfuser.obfuscate(fileContent, config);
    const obfuscatedCode = obfuscated.code || obfuscated;
    
    // Send the obfuscated file
    await ctx.replyWithDocument({
      source: Buffer.from(obfuscatedCode),
      filename: 'obfuscated_strong.js'
    });
    
    ctx.reply('Obfuscation Strong Encryption berhasil!');
  } catch (error) {
    ctx.reply('Gagal melakukan obfuscation: ' + error.message);
  }
}

async function arab(ctx) {
  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.reply('Balas ke file JavaScript untuk di-obfuscate dengan Arab Encryption!');
  }
  
  try {
    const document = ctx.message.reply_to_message.document;
    const fileId = document.file_id;
    const file = await ctx.telegram.getFile(fileId);
    const fileUrl = `https://api.telegram.org/file/bot${global.BOT_TOKEN}/${file.file_path}`;
    
    // Download the file
    const response = await axios.get(fileUrl, { responseType: 'arraybuffer' });
    const fileContent = response.data.toString('utf8');
    
    // Obfuscate with Arab encryption
    const config = obf.getArabObfuscationConfig();
    const obfuscated = await global.JsConfuser.obfuscate(fileContent, config);
    const obfuscatedCode = obfuscated.code || obfuscated;
    
    // Send the obfuscated file
    await ctx.replyWithDocument({
      source: Buffer.from(obfuscatedCode),
      filename: 'obfuscated_arab.js'
    });
    
    ctx.reply('Obfuscation Arab Encryption berhasil!');
  } catch (error) {
    ctx.reply('Gagal melakukan obfuscation: ' + error.message);
  }
}

async function japanxArab(ctx) {
  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.reply('Balas ke file JavaScript untuk di-obfuscate dengan Japan x Arab Encryption!');
  }
  
  try {
    const document = ctx.message.reply_to_message.document;
    const fileId = document.file_id;
    const file = await ctx.telegram.getFile(fileId);
    const fileUrl = `https://api.telegram.org/file/bot${global.BOT_TOKEN}/${file.file_path}`;
    
    // Download the file
    const response = await axios.get(fileUrl, { responseType: 'arraybuffer' });
    const fileContent = response.data.toString('utf8');
    
    // Obfuscate with Japan x Arab encryption
    const config = obf.getJapanxArabObfuscationConfig();
    const obfuscated = await global.JsConfuser.obfuscate(fileContent, config);
    const obfuscatedCode = obfuscated.code || obfuscated;
    
    // Send the obfuscated file
    await ctx.replyWithDocument({
      source: Buffer.from(obfuscatedCode),
      filename: 'obfuscated_japanxarab.js'
    });
    
    ctx.reply('Obfuscation Japan x Arab Encryption berhasil!');
  } catch (error) {
    ctx.reply('Gagal melakukan obfuscation: ' + error.message);
  }
}

async function japan(ctx) {
  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.reply('Balas ke file JavaScript untuk di-obfuscate dengan Japan Encryption!');
  }
  
  try {
    const document = ctx.message.reply_to_message.document;
    const fileId = document.file_id;
    const file = await ctx.telegram.getFile(fileId);
    const fileUrl = `https://api.telegram.org/file/bot${global.BOT_TOKEN}/${file.file_path}`;
    
    // Download the file
    const response = await axios.get(fileUrl, { responseType: 'arraybuffer' });
    const fileContent = response.data.toString('utf8');
    
    // Obfuscate with Japan encryption
    const config = obf.getJapanObfuscationConfig();
    const obfuscated = await global.JsConfuser.obfuscate(fileContent, config);
    const obfuscatedCode = obfuscated.code || obfuscated;
    
    // Send the obfuscated file
    await ctx.replyWithDocument({
      source: Buffer.from(obfuscatedCode),
      filename: 'obfuscated_japan.js'
    });
    
    ctx.reply('Obfuscation Japan Encryption berhasil!');
  } catch (error) {
    ctx.reply('Gagal melakukan obfuscation: ' + error.message);
  }
}

module.exports = {
  start,
  menu,
  owner,
  addPrem,
  delPrem,
  listPrem,
  addBl,
  delBl,
  listBl,
  autoJasher,
  stopAutoJasher,
  listGrup,
  toUrl,
  shareVip,
  enclocked,
  quantum,
  siuCalcrick,
  custom,
  nebula,
  nova,
  strong,
  arab,
  japanxArab,
  japan
};