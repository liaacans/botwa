global.BOT_TOKEN = "8198305874:AAH1Sfr54fyWkPSdfuLQTK_5hSyW69V2C7o";
global.OWNER_ID = "8135269613";
global.PREMIUM_PRICE = 5000; // Harga premium dalam Rupiah
global.SCRIPT_PRICE = 10000; // Harga script dalam Rupiah

// Database paths
global.USERS_DB = "./data/users.json";
global.GROUPS_DB = "./data/groups.json";
global.PREMIUM_DB = "./data/premium.json";
global.BLACKLIST_DB = "./data/blacklist.json";

// Upload service
global.UPLOAD_URL = "https://uguu.se/upload.php";

// Bot settings
global.BOT_NAME = "Jasher Bot";
global.BOT_USERNAME = "jasher_bot";