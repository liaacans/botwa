global.BOT_TOKEN = "8198305874:AAH1Sfr54fyWkPSdfuLQTK_5hSyW69V2C7o";
global.MONGO_URL = "mongodb://jasher_coastfifth:c40755e5b21652b679c0d5b4688915155185303d@opqkay.h.filess.io:61004/jasher_coastfifth";
global.OWNER_ID = "8135269613";
global.PREMIUM_PRICE = 5000; // Harga premium dalam Rupiah
global.QRIS_URL = "https://yab-group.com/api/live/create";

module.exports = {
  BOT_TOKEN: global.BOT_TOKEN,
  MONGO_URL: global.MONGO_URL,
  OWNER_ID: global.OWNER_ID,
  PREMIUM_PRICE: global.PREMIUM_PRICE,
  QRIS_URL: global.QRIS_URL
};