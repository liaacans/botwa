const { Markup } = require('telegraf');
const { User, Group } = require('../lib/database');
const { formatUserInfo } = require('./utils');

async function handleStart(ctx) {
  try {
    let user = await User.findOne({ userId: ctx.from.id });
    
    if (!user) {
      user = new User({
        userId: ctx.from.id,
        username: ctx.from.username,
        firstName: ctx.from.first_name,
        lastName: ctx.from.last_name,
        isCreator: ctx.from.id.toString() === global.OWNER_ID
      });
      await user.save();
    }
    
    const caption = formatUserInfo(ctx, user);
    const menuButtons = Markup.inlineKeyboard([
      [Markup.button.callback('🎯 Jasher Menu', 'jasher_menu')],
      [Markup.button.callback('👤 Owner Menu', 'owner_menu')],
      [Markup.button.url('➕ Add Group', 'https://t.me/jasherpremtia_Bot?startgroup=true')]
    ]);
    
    // Kirim gambar dengan menu
    await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
      caption: caption,
      parse_mode: 'HTML',
      ...menuButtons
    });
  } catch (error) {
    console.error('Error in start command:', error);
    ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleHelp(ctx) {
  const helpText = `🤖 <b>Jasher Bot Help</b>

<b>Perintah yang tersedia:</b>
/start - Memulai bot
/help - Menampilkan bantuan
/credit - Menampilkan kredit Anda
/share - Membagikan pesan (hanya di chat private)

<b>Cara mendapatkan kredit:</b>
1. Tambahkan bot ke ${global.GROUPS_REQUIRED} grup untuk mendapatkan ${global.PREMIUM_COST} kredit
2. Setiap grup yang ditambahkan akan diverifikasi oleh admin

<b>Fitur Share:</b>
- Share Free: ${global.FREE_COST} kredit (lambat)
- Share VIP: ${global.PREMIUM_COST} kredit (cepat)

<b>Perintah Owner:</b>
/addprem [user_id] - Menambah user premium
/delprem [user_id] - Menghapus user premium
/listprem - List semua user premium
/bc [pesan] - Broadcast ke semua user`;

  await ctx.reply(helpText, { parse_mode: 'HTML' });
}

async function handleCredit(ctx) {
  try {
    const user = await User.findOne({ userId: ctx.from.id });
    if (!user) return ctx.reply('Anda belum terdaftar. Ketik /start untuk mendaftar.');
    
    const groups = await Group.find({ addedBy: ctx.from.id });
    const groupsCount = groups.length;
    const creditNeeded = Math.max(0, global.GROUPS_REQUIRED - groupsCount);
    
    let creditInfo = `💳 <b>Info Kredit</b>\n\n`;
    creditInfo += `Kredit Anda: <b>${user.credit}</b>\n`;
    creditInfo += `Grup yang telah ditambahkan: <b>${groupsCount}/${global.GROUPS_REQUIRED}</b>\n\n`;
    
    if (groupsCount < global.GROUPS_REQUIRED) {
      creditInfo += `Anda perlu menambahkan <b>${creditNeeded}</b> grup lagi untuk mendapatkan ${global.PREMIUM_COST} kredit.\n`;
      creditInfo += `Gunakan tombol "➕ Add Group" di menu utama.`;
    } else {
      creditInfo += `Anda telah memenuhi syarat menambahkan grup.`;
    }
    
    await ctx.reply(creditInfo, { 
      parse_mode: 'HTML',
      reply_markup: Markup.inlineKeyboard([
        [Markup.button.callback('➕ Add Group', 'add_group')],
        [Markup.button.callback('🔙 Kembali', 'main_menu')]
      ])
    });
  } catch (error) {
    console.error('Error in credit command:', error);
    ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleShare(ctx) {
  // Hanya boleh dijalankan di private chat
  if (ctx.chat.type !== 'private') {
    return ctx.reply('Perintah /share hanya dapat digunakan di private chat.');
  }
  
  try {
    const user = await User.findOne({ userId: ctx.from.id });
    if (!user) return ctx.reply('Anda belum terdaftar. Ketik /start untuk mendaftar.');
    
    // Cek apakah ada pesan yang di-reply
    if (!ctx.message.reply_to_message) {
      return ctx.reply('Anda harus membalas pesan yang ingin dibagikan dengan perintah /share');
    }
    
    const shareOptions = Markup.inlineKeyboard([
      [Markup.button.callback(`🚀 Share VIP (${global.PREMIUM_COST} kredit)`, 'share_vip')],
      [Markup.button.callback(`🐢 Share Free (${global.FREE_COST} kredit)`, 'share_free')],
      [Markup.button.callback('🔙 Batal', 'cancel_share')]
    ]);
    
    await ctx.reply(
      `Pilih jenis share:\n\n` +
      `🚀 <b>Share VIP</b>: Broadcast cepat ke semua grup (${global.PREMIUM_COST} kredit)\n` +
      `🐢 <b>Share Free</b>: Broadcast reguler (${global.FREE_COST} kredit)`,
      { parse_mode: 'HTML', ...shareOptions }
    );
  } catch (error) {
    console.error('Error in share command:', error);
    ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

// Command untuk owner
async function handleAddPrem(ctx) {
  if (ctx.from.id.toString() !== global.OWNER_ID) {
    return ctx.reply('Anda bukan owner bot!');
  }
  
  const userId = ctx.message.text.split(' ')[1];
  if (!userId) return ctx.reply('Gunakan: /addprem [user_id]');
  
  try {
    const user = await User.findOneAndUpdate(
      { userId: parseInt(userId) },
      { isPremium: true },
      { new: true, upsert: true }
    );
    
    await ctx.reply(`User ${user.firstName} (${user.userId}) telah ditambahkan sebagai premium.`);
  } catch (error) {
    console.error('Error adding premium user:', error);
    ctx.reply('Terjadi kesalahan saat menambahkan user premium.');
  }
}

async function handleDelPrem(ctx) {
  if (ctx.from.id.toString() !== global.OWNER_ID) {
    return ctx.reply('Anda bukan owner bot!');
  }
  
  const userId = ctx.message.text.split(' ')[1];
  if (!userId) return ctx.reply('Gunakan: /delprem [user_id]');
  
  try {
    const user = await User.findOneAndUpdate(
      { userId: parseInt(userId) },
      { isPremium: false }
    );
    
    if (user) {
      await ctx.reply(`User ${user.firstName} (${user.userId}) telah dihapus dari premium.`);
    } else {
      await ctx.reply('User tidak ditemukan.');
    }
  } catch (error) {
    console.error('Error removing premium user:', error);
    ctx.reply('Terjadi kesalahan saat menghapus user premium.');
  }
}

async function handleListPrem(ctx) {
  if (ctx.from.id.toString() !== global.OWNER_ID) {
    return ctx.reply('Anda bukan owner bot!');
  }
  
  try {
    const premiumUsers = await User.find({ isPremium: true });
    
    if (premiumUsers.length === 0) {
      return ctx.reply('Tidak ada user premium.');
    }
    
    let listText = '📋 <b>Daftar User Premium</b>\n\n';
    premiumUsers.forEach((user, index) => {
      listText += `${index + 1}. ${user.firstName}${user.lastName ? ' ' + user.lastName : ''} `;
      listText += `(@${user.username || 'no_username'}) - ID: ${user.userId}\n`;
    });
    
    await ctx.reply(listText, { parse_mode: 'HTML' });
  } catch (error) {
    console.error('Error listing premium users:', error);
    ctx.reply('Terjadi kesalahan saat mengambil daftar user premium.');
  }
}

async function handleBroadcast(ctx) {
  if (ctx.from.id.toString() !== global.OWNER_ID) {
    return ctx.reply('Anda bukan owner bot!');
  }
  
  const message = ctx.message.text.split(' ').slice(1).join(' ');
  if (!message) return ctx.reply('Gunakan: /bc [pesan]');
  
  try {
    const users = await User.find({});
    let successCount = 0;
    let failCount = 0;
    
    for (const user of users) {
      try {
        await ctx.telegram.sendMessage(user.userId, `📢 <b>Broadcast dari Admin:</b>\n\n${message}`, {
          parse_mode: 'HTML'
        });
        successCount++;
      } catch (error) {
        console.error(`Failed to send broadcast to ${user.userId}:`, error);
        failCount++;
      }
      
      // Delay untuk menghindari limit Telegram
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    await ctx.reply(
      `📊 <b>Hasil Broadcast:</b>\n\n` +
      `✅ Berhasil: ${successCount}\n` +
      `❌ Gagal: ${failCount}`,
      { parse_mode: 'HTML' }
    );
  } catch (error) {
    console.error('Error in broadcast:', error);
    ctx.reply('Terjadi kesalahan saat broadcast.');
  }
}

module.exports = {
  handleStart,
  handleHelp,
  handleCredit,
  handleShare,
  handleAddPrem,
  handleDelPrem,
  handleListPrem,
  handleBroadcast
};