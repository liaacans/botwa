const { Telegraf, session } = require('telegraf');
const { connectDB, User } = require('./lib/database');
const { 
    handleStart, 
    handleHelp, 
    handleCredit, 
    handleShare, 
    handleShareVip,
    handleAddPrem,
    handleDelPrem,
    handleListPrem
} = require('./src/commands');
const { handleCallbackQuery } = require('./src/handlers');
const { BOT_TOKEN } = require('./config');

// Connect to database
connectDB();

const bot = new Telegraf(BOT_TOKEN);

// Session middleware (optional)
bot.use(session());

// Command handlers
bot.command('start', handleStart);
bot.command('help', handleHelp);
bot.command('credit', handleCredit);
bot.command('share', handleShare);
bot.command('sharevip', handleShareVip);
bot.command('addprem', handleAddPrem);
bot.command('delprem', handleDelPrem);
bot.command('listprem', handleListPrem);

// Callback query handler
bot.on('callback_query', handleCallbackQuery);

// Error handling
bot.catch((err, ctx) => {
    console.error(`Error for ${ctx.updateType}:`, err);
    ctx.reply('Terjadi kesalahan pada bot. Silakan coba lagi nanti.');
});

// Start bot
bot.launch().then(() => {
    console.log('Bot Jasher started successfully!');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));