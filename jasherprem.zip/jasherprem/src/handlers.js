const { User, Group } = require('../lib/database');
const { mainMenu } = require('./commands');

// Handle callback queries
async function handleCallbacks(ctx) {
    const data = ctx.callbackQuery.data;
    const user = await User.findOne({ userId: ctx.from.id });
    
    switch (data) {
        case 'main_menu':
            await mainMenu(ctx, user);
            break;
            
        case 'jasher_menu':
            await ctx.editMessageCaption(`🎯 <b>Jasher Menu</b>\n\nFitur yang tersedia:\n- Share pesan ke banyak grup\n- ShareVIP untuk user premium\n- Sistem kredit\n\nKredit Anda: ${user.credit}`, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🔙 Kembali', callback_data: 'main_menu' }]
                    ]
                }
            });
            break;
            
        case 'owner_menu':
            // Cek apakah owner
            if (ctx.from.id.toString() !== process.env.OWNER_ID) {
                await ctx.answerCbQuery('❌ Menu ini hanya untuk owner.');
                return;
            }
            
            await ctx.editMessageCaption(`👤 <b>Owner Menu</b>\n\nFitur yang tersedia:\n- Tambah/hapus user premium\n- List user premium\n- Broadcast ke semua user\n\nGunakan command:\n/addprem - Menambah user premium\n/delprem - Menghapus user premium\n/listprem - List user premium\n/broadcast - Broadcast pesan`, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🔙 Kembali', callback_data: 'main_menu' }]
                    ]
                }
            });
            break;
            
        case 'owner_info':
            await ctx.editMessageCaption(`👨‍💻 <b>Owner Info</b>\n\nHubungi owner untuk informasi lebih lanjut:\n@username_owner\n\nAtau melalui command /help`, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🔙 Kembali', callback_data: 'main_menu' }]
                    ]
                }
            });
            break;
            
        default:
            await ctx.answerCbQuery('❌ Opsi tidak dikenali');
            break;
    }
    
    await ctx.answerCbQuery();
}

// Handle new chat members (bot ditambahkan ke group)
async function handleNewChatMembers(ctx) {
    try {
        for (const member of ctx.message.new_chat_members) {
            if (member.is_bot && member.username === ctx.botInfo.username) {
                // Bot ditambahkan ke group
                const groupId = ctx.chat.id;
                const groupTitle = ctx.chat.title;
                const groupUsername = ctx.chat.username;
                const addedBy = ctx.from.id;
                
                // Cek apakah group sudah ada di database
                let group = await Group.findOne({ groupId });
                if (!group) {
                    group = new Group({
                        groupId,
                        title: groupTitle,
                        username: groupUsername,
                        addedBy
                    });
                    await group.save();
                    
                    // Beri kredit kepada user yang menambahkan bot
                    const user = await User.findOne({ userId: addedBy });
                    if (user) {
                        user.joinedGroups.push(groupId);
                        
                        // Beri 10 kredit jika sudah menambahkan ke 3 group
                        if (user.joinedGroups.length >= 3 && user.joinedGroups.length % 3 === 0) {
                            user.credit += 10;
                            await user.save();
                            
                            // Beritahu user
                            try {
                                await ctx.telegram.sendMessage(addedBy, `🎉 Selamat! Anda telah menambahkan bot ke 3 grup dan mendapatkan 10 kredit.\nTotal kredit: ${user.credit}`);
                            } catch (error) {
                                console.error('Cannot notify user:', error);
                            }
                        } else {
                            await user.save();
                        }
                    }
                    
                    await ctx.reply(`✅ Terima kasih telah menambahkan saya ke grup ini!\nGunakan /help untuk melihat fitur yang tersedia.`);
                }
            }
        }
    } catch (error) {
        console.error('Error in handleNewChatMembers:', error);
    }
}

// Handle left chat member (bot dikeluarkan dari group)
async function handleLeftChatMember(ctx) {
    try {
        if (ctx.message.left_chat_member && 
            ctx.message.left_chat_member.is_bot && 
            ctx.message.left_chat_member.username === ctx.botInfo.username) {
            
            // Bot dikeluarkan dari group
            const groupId = ctx.chat.id;
            
            // Hapus group dari database
            await Group.deleteOne({ groupId });
        }
    } catch (error) {
        console.error('Error in handleLeftChatMember:', error);
    }
}

module.exports = {
    handleCallbacks,
    handleNewChatMembers,
    handleLeftChatMember
};