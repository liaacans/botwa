const db = require('../lib/database');
const utils = require('../lib/utils');
const keyboards = require('./keyboards');
const commands = require('./commands');
const { CREDITS } = require('../config');

// Handler untuk callback queries (button clicks)
async function handleCallbackQuery(ctx) {
    const data = ctx.callbackQuery.data;
    const user = ctx.from;
    const isCreator = user.id === global.CREATOR_ID;
    
    let userData = await db.getUser(user.id);
    if (!userData) {
        await db.createUser(user);
        userData = await db.getUser(user.id);
    }
    
    switch (data) {
        case 'main_menu':
            await ctx.editMessageText(
                `Hi kak @${user.username || user.first_name}\n╭─❒ 「 User Info 」 \n├ Creator : @${user.username || user.first_name}\n├ Name : ${user.first_name}${user.last_name ? ' ' + user.last_name : ''}\n├ Profile : <a href="tg://user?id=${user.id}">Profile</a>\n├ ID Telegram Anda: ${user.id}\n├ Hostname : Linux\n├ Platform : Bot Telegram\n├ Runtime : ${utils.runtime(process.uptime())}\n├ Tanggal Server : ${utils.moment.tz('Asia/Jakarta').format('DD/MM/YY')}\n├ Waktu Server : ${utils.moment.tz('Asia/Jakarta').format('HH:mm:ss')}\n╰❒ Owner : ${isCreator ? 'True' : 'False'}\nSilahkan pilih button dibawah ini!`,
                { 
                    parse_mode: 'HTML',
                    ...keyboards.mainMenuKeyboard(isCreator)
                }
            );
            break;
            
        case 'jasher_menu':
            await ctx.editMessageText(
                '🎯 <b>Jasher Menu</b>\n\nPilih opsi di bawah:',
                { 
                    parse_mode: 'HTML',
                    ...keyboards.jasherMenuKeyboard()
                }
            );
            break;
            
        case 'owner_menu':
            await ctx.editMessageText(
                '👤 <b>Owner Menu</b>\n\nPilih opsi di bawah:',
                { 
                    parse_mode: 'HTML',
                    ...keyboards.ownerMenuKeyboard()
                }
            );
            break;
            
        case 'admin_menu':
            if (!global.ADMINS.includes(user.id)) {
                await ctx.answerCbQuery('❌ Menu ini hanya untuk admin!');
                return;
            }
            
            await ctx.editMessageText(
                '🛠 <b>Admin Menu</b>\n\nPilih opsi di bawah:',
                { 
                    parse_mode: 'HTML',
                    ...keyboards.adminMenuKeyboard()
                }
            );
            break;
            
        case 'credit_info':
            await ctx.editMessageText(
                `<b>💎 Credit Info</b>\n\nNama: ${user.first_name}${user.last_name ? ' ' + user.last_name : ''}\nCredit: ${utils.formatCredits(userData.credits)}\nGroup ditambahkan: ${userData.added_groups}\nStatus: ${userData.is_premium ? 'Premium 🎖' : 'Regular'}\n\nUntuk menambah credit, tambahkan bot ke group (minimal 3 group untuk bisa menggunakan fitur share)`,
                { 
                    parse_mode: 'HTML',
                    ...keyboards.backButton('jasher_menu')
                }
            );
            break;
            
        case 'share_menu':
            if (ctx.chat.type !== 'private') {
                await ctx.answerCbQuery('❌ Fitur share hanya bisa digunakan di chat private!');
                return;
            }
            
            if (userData.added_groups < CREDITS.MIN_GROUPS_FOR_SHARE) {
                await ctx.editMessageText(
                    `❌ Anda harus menambahkan bot ke minimal <b>${CREDITS.MIN_GROUPS_FOR_SHARE} group</b> sebelum bisa menggunakan fitur share.\n\nGroup ditambahkan: <b>${userData.added_groups}/${CREDITS.MIN_GROUPS_FOR_SHARE}</b>`,
                    { 
                        parse_mode: 'HTML',
                        ...keyboards.backButton('jasher_menu')
                    }
                );
                return;
            }
            
            await ctx.editMessageText(
                `📤 <b>Share Menu</b>\n\nBiaya share: <b>${CREDITS.SHARE_COST} credit</b>\nCredit Anda: <b>${utils.formatCredits(userData.credits)}</b>\n\nBalas pesan dengan perintah /share untuk membagikan pesan ke semua group.`,
                { 
                    parse_mode: 'HTML',
                    ...keyboards.backButton('jasher_menu')
                }
            );
            break;
            
        case 'share_vip':
            if (ctx.chat.type !== 'private') {
                await ctx.answerCbQuery('❌ Fitur sharevip hanya bisa digunakan di chat private!');
                return;
            }
            
            if (!userData.is_premium) {
                await ctx.editMessageText(
                    '❌ Fitur ini hanya untuk user premium!',
                    { 
                        parse_mode: 'HTML',
                        ...keyboards.backButton('jasher_menu')
                    }
                );
                return;
            }
            
            await ctx.editMessageText(
                '📤 <b>ShareVIP Menu</b>\n\nFitur shareVIP untuk user premium tanpa biaya credit.\n\nBalas pesan dengan perintah /sharevip untuk membagikan pesan ke semua group.',
                { 
                    parse_mode: 'HTML',
                    ...keyboards.backButton('jasher_menu')
                }
            );
            break;
            
        case 'bot_stats':
            if (!global.ADMINS.includes(user.id)) {
                await ctx.answerCbQuery('❌ Menu ini hanya untuk admin!');
                return;
            }
            
            const allUsers = await db.getAllUsers();
            const premiumUsers = await db.getPremiumUsers();
            const allGroups = await db.getAllGroups();
            
            await ctx.editMessageText(
                `<b>📊 Bot Statistics</b>\n\nTotal Users: <b>${allUsers.length}</b>\nPremium Users: <b>${premiumUsers.length}</b>\nTotal Groups: <b>${allGroups.length}</b>\n\nServer Uptime: <b>${utils.runtime(process.uptime())}</b>`,
                { 
                    parse_mode: 'HTML',
                    ...keyboards.backButton('owner_menu')
                }
            );
            break;
            
        case 'broadcast_menu':
            if (!global.ADMINS.includes(user.id)) {
                await ctx.answerCbQuery('❌ Menu ini hanya untuk admin!');
                return;
            }
            
            await ctx.editMessageText(
                '📢 <b>Broadcast Menu</b>\n\nBalas pesan dengan perintah /broadcast untuk mengirim pesan ke semua user.',
                { 
                    parse_mode: 'HTML',
                    ...keyboards.backButton('owner_menu')
                }
            );
            break;
            
        case 'add_premium':
            if (!global.ADMINS.includes(user.id)) {
                await ctx.answerCbQuery('❌ Menu ini hanya untuk admin!');
                return;
            }
            
            await ctx.editMessageText(
                '⭐ <b>Add Premium</b>\n\nBalas pesan user dengan perintah /addprem untuk menambahkan user sebagai premium.',
                { 
                    parse_mode: 'HTML',
                    ...keyboards.backButton('admin_menu')
                }
            );
            break;
            
        case 'remove_premium':
            if (!global.ADMINS.includes(user.id)) {
                await ctx.answerCbQuery('❌ Menu ini hanya untuk admin!');
                return;
            }
            
            await ctx.editMessageText(
                '🗑 <b>Remove Premium</b>\n\nBalas pesan user dengan perintah /delprem untuk menghapus user dari premium.',
                { 
                    parse_mode: 'HTML',
                    ...keyboards.backButton('admin_menu')
                }
            );
            break;
            
        case 'list_premium':
            if (!global.ADMINS.includes(user.id)) {
                await ctx.answerCbQuery('❌ Menu ini hanya untuk admin!');
                return;
            }
            
            const premiumUsersList = await db.getPremiumUsers();
            
            if (premiumUsersList.length === 0) {
                await ctx.editMessageText(
                    '❌ Tidak ada user premium!',
                    { 
                        parse_mode: 'HTML',
                        ...keyboards.backButton('admin_menu')
                    }
                );
                return;
            }
            
            let message = '<b>📋 Daftar User Premium</b>\n\n';
            
            for (const user of premiumUsersList) {
                message += `👤 ${user.first_name}${user.last_name ? ' ' + user.last_name : ''} (ID: ${user.user_id})\n`;
                if (user.username) message += `@${user.username}\n`;
                message += `Credit: ${utils.formatCredits(user.credits)}\n`;
                message += `Group: ${user.added_groups}\n`;
                message += `Joined: ${new Date(user.created_at).toLocaleDateString('id-ID')}\n`;
                message += '─\n';
            }
            
            await ctx.editMessageText(
                message,
                { 
                    parse_mode: 'HTML',
                    ...keyboards.backButton('admin_menu')
                }
            );
            break;
            
        case 'add_group':
            await ctx.editMessageText(
                '➕ <b>Add Group</b>\n\nTambahkan bot ke group Anda dan berikan admin rights untuk mengirim pesan. Setiap penambahan group akan memberikan 10 credit.\n\nSetelah menambahkan bot, ketik /addgroup di group tersebut untuk mendaftarkan group.',
                { 
                    parse_mode: 'HTML',
                    ...keyboards.backButton('main_menu')
                }
            );
            break;
            
        case 'contact_owner':
            await ctx.editMessageText(
                `👤 <b>Contact Owner</b>\n\nPemilik bot: <a href="tg://user?id=${global.CREATOR_ID}">Klik di sini</a>\n\nUntuk pertanyaan atau masalah, hubungi owner langsung.`,
                { 
                    parse_mode: 'HTML',
                    ...keyboards.backButton('main_menu')
                }
            );
            break;
    }
    
    await ctx.answerCbQuery();
}

// Handler untuk new chat members (bot ditambahkan ke group)
async function handleNewChatMembers(ctx) {
    if (ctx.message.new_chat_members.some(member => member.is_bot && member.id === ctx.botInfo.id)) {
        // Bot ditambahkan ke group
        const chat = ctx.chat;
        
        await ctx.replyWithHTML(
            `Terima kasih telah menambahkan saya ke group <b>${chat.title}</b>!\n\nUntuk mendaftarkan group, ketik /addgroup`
        );
    }
}

// Handler untuk left chat member (bot dikeluarkan dari group)
async function handleLeftChatMember(ctx) {
    if (ctx.message.left_chat_member && ctx.message.left_chat_member.id === ctx.botInfo.id) {
        // Bot dikeluarkan dari group
        const chatId = ctx.chat.id;
        
        try {
            await db.removeGroup(chatId);
        } catch (error) {
            console.error('Gagal menghapus group dari database:', error.message);
        }
    }
}

module.exports = {
    handleCallbackQuery,
    handleNewChatMembers,
    handleLeftChatMember
};