module.exports = {
    BOT_TOKEN: "8439733385:AAGJUPe0cjw_KOREpne1qjNMmAUMQsAUHDw",
    OWNER_IDS: ["8135269613"],
    OWNER_ID: "8135269613",
    CHANNEL_ID: "-1003011195058",
    CHANNEL_URL: "https://t.me/ginaimutp",
    BOT_NAME: "GINASTORE OFFICIAL",
    nomor_pencairan: "085654127071",
    type_ewallet: "dana",
    atas_nama_ewallet: "Akhmad Aulia Rahman",
    
    PAYMENT: {
        apiAtlantic: "tzxoo6P17Lm5BPU4vH3OWHP91kkIqBsoSa0pImIzONyyfJlK4jAV3MFre5WQWJfmhStLGdxi5k67nvKEwLYf9jeShCx1aQquiqXC",
        FeeTransaksi: 450
    },
    
    PTERODACTYL: {
        domain: "https://masvilxpribadiv5.store-panell.my.id",
        apiKey: "ptla_PdvKiGK51OGSBH2iSJfvauXXrqe6tBfEU8R8LUGCrnk",
        clientKey: "ptlc_6mf5XLM1hoIlAtbsWJg89UFjUtyKXRSkSgIjrA1elPJ",
        loc: "1",
        nest: "5",
        eggs: {
            nodejs: "15",
            python: "16", 
            pm2: "17"
        }
    },
    
    PANEL_PRICES: {
        '5gb': 5000,
        '6gb': 6000,
        '7gb': 7000,
        '8gb': 8000,
        '9gb': 9000,
        '10gb': 10000,
        'unli': 15000
    },
    
    RESELLER_PRICES: {
        reseller: 8000
    },
    
    RESELLER: {
        reseller: {
            daily_limit: 5,
            max_ram: 10240,
            sell_price: 5000
        }
    },
    
    SPECIAL_PANEL_PRICES: {
        admin_panel: 10000,
        reseller_panel: 8000,
        owner_panel: 20000,
        pt_panel: 10000,
        tk_panel: 15000
    }
};