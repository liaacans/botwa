const { Markup } = require('telegraf');
const fs = require('fs-extra');
const path = require('path');
const fetch = require('node-fetch');
const moment = require('moment-timezone');
const { User, Group, Blacklist, Payment } = require('../lib/database');
const { log, runtime, updateProgress, createProgressBar, uploadToUguu } = require('../lib/utils');
const { isOwner, isPremium } = require('../lib/middleware');
const { obfuscateTimeLocked,obfuscateQuantum, getSiuCalcrickObfuscationConfig, getCustomObfuscationConfig, getNebulaObfuscationConfig, getNovaObfuscationConfig, getStrongObfuscationConfig, getArabObfuscationConfig, getJapanxArabObfuscationConfig, getJapanObfuscationConfig
} = require('./obf');

// Inisialisasi JsConfuser
const JsConfuser = require('js-confuser');

// Command untuk menampilkan menu utama
function setupMainMenu(bot) {
  bot.command('start', async (ctx) => {
    const isCreator = ctx.from.id.toString() === global.OWNER_ID;
    const sender = ctx.from.username || ctx.from.first_name;
    
    const menuText = `
╭─❒ 「 User Info 」 
├ Owner : ${isCreator ? 'True' : 'False'}
├ Name : ${ctx.from.first_name}${ctx.from.last_name ? ' ' + ctx.from.last_name : ''}
├ Profile : @${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`;

    const keyboard = Markup.inlineKeyboard([
      [
        Markup.button.callback('🧰 Jasher Menu', 'jasher_menu'),
        Markup.button.callback('👤 Owner Menu', 'owner_menu')
      ],
      [
        Markup.button.callback('🔒 Obf Menu', 'obf_menu'),
        Markup.button.callback('🛒 Buy Premium', 'buy_premium')
      ],
      [
        Markup.button.callback('📊 Status', 'status'),
        Markup.button.callback('ℹ️ Info', 'info')
      ]
    ]);

    try {
      await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
        caption: menuText,
        parse_mode: 'Markdown',
        ...keyboard
      });
    } catch (error) {
      await ctx.reply(menuText, {
        parse_mode: 'Markdown',
        ...keyboard
      });
    }
  });

  // Handler untuk callback queries
bot.action('jasher_menu', async (ctx) => {
  const menuText = `
╭─❒ 「 Jasher Menu 」 
├ /status - Status bot
├ /info - Info bot
├ /buyprem - Beli premium
├ /mysc - Script saya
├ /sharefree - Share dengan delay
├ /sharevip - Share tanpa delay
├ /share - Share otomatis
├ /tourl - Upload foto ke URL
╰❒`;

  await ctx.editMessageCaption(menuText, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('🔙 Kembali', 'main_menu')]
    ])
  });
});

  bot.action('owner_menu', async (ctx) => {
    if (ctx.from.id.toString() !== global.OWNER_ID) {
      return ctx.answerCbQuery('❌ Hanya owner yang bisa mengakses menu ini!');
    }

    const menuText = `
╭─❒ 「 Owner Menu 」 
├ /addbl <grup_id> - Tambah group ke blacklist
├ /delbl <grup_id> - Hapus group dari blacklist
├ /listbl - List group blacklist
├ /addprem <user_id> <hari> - Tambah premium user
├ /delprem <user_id> - Hapus premium user
├ /listprem - List user premium
├ /bc <pesan> - Broadcast ke semua user
├ /stats - Statistik bot
├ /groups - List group aktif
├ /cleanup - Hapus group tidak aktif
╰❒`;

    await ctx.editMessageCaption(menuText, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('🔙 Kembali', 'main_menu')]
      ])
    });
  });

  bot.action('obf_menu', async (ctx) => {
    const menuText = `
╭─❒ 「 Obfuscation Menu 」 
├ /enc <hari> - Time-Locked Encryption (1-365 hari)
├ /enc2 <nama> - Custom Encryption
├ /enc3 - Mandarin Encryption
├ /enc4 - Arab Encryption
├ /enc5 - Siu+Calcrick Encryption
├ /japan - Japan Encryption
├ /nebula - Nebula Encryption
├ /var - Var Encryption
├ /zenc - Invisible Encryption
├ /quantum - Quantum Encryption
├ /deobfuscate - Deobfuscate script
╰❒
Balas file JS dengan command di atas!`;

    await ctx.editMessageCaption(menuText, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('🔙 Kembali', 'main_menu')]
      ])
    });
  });

  bot.action('buy_premium', async (ctx) => {
    const menuText = `
╭─❒ 「 Buy Premium 」 
├ Premium 7 Hari: Rp 10.000
├ Premium 30 Hari: Rp 30.000
├ Premium 90 Hari: Rp 75.000
├ Premium 365 Hari: Rp 250.000
╰❒
Untuk membeli premium, ketik /buyprem <paket>
Contoh: /buyprem 7hari`;

    await ctx.editMessageCaption(menuText, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('🔙 Kembali', 'main_menu')]
      ])
    });
  });

  bot.action('status', async (ctx) => {
    const userCount = await User.countDocuments();
    const groupCount = await Group.countDocuments({ isActive: true });
    const premiumCount = await User.countDocuments({ 
      isPremium: true, 
      premiumExpiry: { $gt: new Date() } 
    });

    const statusText = `
╭─❒ 「 Bot Status 」 
├ Users: ${userCount}
├ Groups: ${groupCount}
├ Premium: ${premiumCount}
├ Runtime: ${runtime(process.uptime())}
├ Memory: ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB
╰❒`;

    await ctx.editMessageCaption(statusText, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('🔙 Kembali', 'main_menu')]
      ])
    });
  });

  bot.action('info', async (ctx) => {
    const infoText = `
╭─❒ 「 Bot Info 」 
├ Creator: @ginaabaikhati
├ Version: 2.0.0
├ Platform: Node.js Telegraf
├ Database: MongoDB
├ Host: VPS 6GB
├ Support: https://y2beta.web.id
╰❒`;

    await ctx.editMessageCaption(infoText, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('🔙 Kembali', 'main_menu')]
      ])
    });
  });

  // Update main menu untuk menambahkan button share
bot.action('main_menu', async (ctx) => {
  const isCreator = ctx.from.id.toString() === global.OWNER_ID;
  const sender = ctx.from.username || ctx.from.first_name;
  
  const menuText = `
╭─❒ 「 User Info 」 
├ Owner : ${isCreator ? 'True' : 'False'}
├ Name : ${ctx.from.first_name}${ctx.from.last_name ? ' ' + ctx.from.last_name : ''}
├ Profile : @${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`;

  const keyboard = Markup.inlineKeyboard([
    [
      Markup.button.callback('🧰 Jasher Menu', 'jasher_menu'),
      Markup.button.callback('👤 Owner Menu', 'owner_menu')
    ],
    [
      Markup.button.callback('🔒 Obf Menu', 'obf_menu'),
      Markup.button.callback('📤 Share Menu', 'share_menu')
    ],
    [
      Markup.button.callback('🛒 Buy Premium', 'buy_premium'),
      Markup.button.callback('📊 Status', 'status')
    ],
    [
      Markup.button.callback('ℹ️ Info', 'info')
    ]
  ]);

  try {
    await ctx.editMessageMedia({
      type: 'photo',
      media: 'https://f.top4top.io/p_3530xky9e4.jpg',
      caption: menuText,
      parse_mode: 'Markdown'
    }, keyboard);
  } catch (error) {
    await ctx.editMessageCaption(menuText, {
      parse_mode: 'Markdown',
      ...keyboard
    });
  }
});

// Handler untuk callback queries
bot.action('share_menu', async (ctx) => {
  const user = ctx.user;
  const hasPremium = user.isPremium && user.premiumExpiry > new Date();
  
  const menuText = `
╭─❒ 「 Share Menu 」 
├ /sharefree - Share dengan delay (gratis)
├ /sharevip - Share tanpa delay (premium only)
├ /share - Share otomatis pilih mode
├
├ Status: ${hasPremium ? '✅ Premium' : '❌ Free'}
├ Groups: ${user.joinedGroups.length}/3
╰❒
${hasPremium ? 'Anda dapat menggunakan sharevip tanpa delay!' : 'Tambahkan bot ke 3 group untuk akses free share.'}`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('📤 Share Free', 'share_free_info')],
    [Markup.button.callback('⚡ Share VIP', 'share_vip_info')],
    [Markup.button.callback('🔙 Kembali', 'main_menu')]
  ]);

  await ctx.editMessageCaption(menuText, {
    parse_mode: 'Markdown',
    ...keyboard
  });
});

// Handler untuk info share free
bot.action('share_free_info', async (ctx) => {
  const user = ctx.user;
  
  const infoText = `
╭─❒ 「 Share Free Info 」 
├ 📤 Fitur: Share pesan ke semua group
├ ⏰ Kecepatan: Delay 2 detik per group
├ 🆓 Status: Gratis
├
├ Syarat: Tambahkan bot ke 3 group
├ Groups Anda: ${user.joinedGroups.length}/3
├
├ Cara penggunaan:
├ 1. Reply pesan dengan /sharefree
├ 2. Atau ketik /sharefree <teks>
╰❒`;

  await ctx.editMessageCaption(infoText, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('🔙 Kembali', 'share_menu')]
    ])
  });
});

// Handler untuk info share vip
bot.action('share_vip_info', async (ctx) => {
  const user = ctx.user;
  const hasPremium = user.isPremium && user.premiumExpiry > new Date();
  
  const infoText = `
╭─❒ 「 Share VIP Info 」 
├ 📤 Fitur: Share pesan ke semua group
├ ⚡ Kecepatan: Tanpa delay
├ 💎 Status: Premium only
├
├ Premium: ${hasPremium ? '✅ Aktif' : '❌ Non-aktif'}
├ Groups Anda: ${user.joinedGroups.length}/3
├
├ Cara penggunaan:
├ 1. Reply pesan dengan /sharevip
├ 2. Atau ketik /sharevip <teks>
╰❒
${hasPremium ? 'Anda dapat menggunakan fitur ini!' : 'Beli premium dengan /buyprem'}`;

  await ctx.editMessageCaption(infoText, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('🔙 Kembali', 'share_menu')]
    ])
  });
});

// Command help
bot.command('help', (ctx) => {
  ctx.reply(`
🤖 **Jasher Bot Help**

**Umum:**
/start - Memulai bot
/menu - Menampilkan menu
/help - Bantuan
/status - Status bot
/info - Info bot
/tourl - Upload foto ke URL

**Premium:**
/buyprem - Beli akses premium
/mysc - Script saya

**Share:**
/sharefree - Bagikan teks ke group (dengan delay, gratis)
/sharevip - Bagikan teks ke group (tanpa delay, premium only)
/share - Bagikan teks ke group (otomatis pilih mode berdasarkan status)

**Obfuscation:**
/enc <hari> - Time-Locked Encryption
/enc2 <nama> - Custom Encryption
/enc3 - Mandarin Encryption
/enc4 - Arab Encryption
/enc5 - Siu+Calcrick Encryption
/japan - Japan Encryption
/nebula - Nebula Encryption
/var - Var Encryption
/zenc - Invisible Encryption
/quantum - Quantum Encryption
/deobfuscate - Deobfuscate script
/xx <nama> - Custom Encryption dengan nama

**Admin Group:**
/antispam - Aktifkan/nonaktifkan antispam
/noevent - Aktifkan/nonaktifkan noevent
/nolinks - Aktifkan/nonaktifkan nolinks
/noforwards - Aktifkan/nonaktifkan noforwards
/nocontacts - Aktifkan/nonaktifkan nocontacts
/nohastags - Aktifkan/nonaktifkan nohastags
/nocommands - Aktifkan/nonaktifkan nocommands

**Owner Only:**
/addbl - Tambah blacklist
/delbl - Hapus blacklist
/listbl - List blacklist
/addprem - Tambah premium
/delprem - Hapus premium
/listprem - List premium
/bc - Broadcast
/stats - Statistik
/groups - List group
/cleanup - Hapus group tidak aktif
  `.trim(), { parse_mode: 'Markdown' });
});

// Command untuk sharefree (share dengan delay)
bot.command("sharefree", async (ctx) => {
  const user = ctx.user;
  const message = ctx.message.text || '';
  const repliedMessage = ctx.message.reply_to_message;

  // Hanya bisa dilakukan di private chat
  if (ctx.chat.type !== 'private') {
    return ctx.reply('❌ Fitur share hanya bisa digunakan di private chat!');
  }

  // Cek apakah user telah menambahkan bot ke minimal 3 group
  if (user.joinedGroups.length < 3) {
    return ctx.reply(
      `❌ Untuk menggunakan fitur share, Anda perlu menambahkan bot ke 3 group!\n` +
      `Anda telah menambahkan bot ke ${user.joinedGroups.length}/3 group.`
    );
  }

  let shareText = '';

  // Jika user reply ke pesan
  if (repliedMessage) {
    shareText = repliedMessage.text || repliedMessage.caption || '';
    
    if (!shareText) {
      return ctx.reply('❌ Tidak ada teks yang bisa dibagikan!');
    }
  } else {
    // Jika user mengirim teks langsung
    const textToShare = message.replace('/sharefree', '').trim();
    
    if (!textToShare) {
      return ctx.reply('❌ Format: /sharefree <teks> atau reply pesan dengan /sharefree');
    }
    
    shareText = textToShare;
  }

  try {
    // Kirim ke semua group yang user telah tambahkan bot
    let success = 0;
    let failed = 0;
    const groups = user.joinedGroups;

    if (groups.length === 0) {
      return ctx.reply('❌ Anda belum menambahkan bot ke group manapun!');
    }

    const progressMessage = await ctx.reply(
      `📤 Memulai share free ke ${groups.length} group...\n` +
      `⏰ Mode: Free (delay 2 detik per group)`
    );

    for (let i = 0; i < groups.length; i++) {
      const groupId = groups[i];
      
      try {
        // Cek apakah group masih aktif dan tidak diblacklist
        const group = await Group.findOne({ groupId, isActive: true });
        const blacklisted = await Blacklist.findOne({ groupId });
        
        if (!group || blacklisted) {
          failed++;
          continue;
        }

        // Share Free - dengan delay 2 detik
        await new Promise(resolve => setTimeout(resolve, 2000));
        await ctx.telegram.sendMessage(groupId, `📢 Share from @${user.username || user.firstName}:\n\n${shareText}`);
        success++;

        // Update progress
        if (i % 2 === 0 || i === groups.length - 1) {
          await ctx.telegram.editMessageText(
            progressMessage.chat.id,
            progressMessage.message_id,
            null,
            `📤 Sharing free ke ${groups.length} group...\n` +
            `✅ Berhasil: ${success} | ❌ Gagal: ${failed}\n` +
            `⏰ Mode: Free (delay 2 detik per group)`
          );
        }
      } catch (error) {
        failed++;
        log(`Failed to share to group ${groupId}: ${error.message}`);
      }
    }

    await ctx.telegram.editMessageText(
      progressMessage.chat.id,
      progressMessage.message_id,
      null,
      `✅ Share free selesai!\n` +
      `✔️ Berhasil: ${success} group\n` +
      `❌ Gagal: ${failed} group\n` +
      `🐢 Mode: Free (delay 2 detik)`
    );

    // Update share count
    user.shareCount += 1;
    await user.save();

  } catch (error) {
    ctx.reply('❌ Gagal melakukan share free!');
    log(`Error sharing free: ${error.message}`);
  }
});

// Command untuk sharevip (share tanpa delay - hanya untuk premium)
bot.command("sharevip", async (ctx) => {
  const user = ctx.user;
  const message = ctx.message.text || '';
  const repliedMessage = ctx.message.reply_to_message;

  // Hanya bisa dilakukan di private chat
  if (ctx.chat.type !== 'private') {
    return ctx.reply('❌ Fitur share hanya bisa digunakan di private chat!');
  }

  // Cek apakah user premium
  const hasPremium = user.isPremium && user.premiumExpiry > new Date();
  if (!hasPremium) {
    return ctx.reply(
      `❌ Fitur sharevip hanya untuk user premium!\n` +
      `Gunakan /buyprem untuk membeli akses premium.`
    );
  }

  let shareText = '';

  // Jika user reply ke pesan
  if (repliedMessage) {
    shareText = repliedMessage.text || repliedMessage.caption || '';
    
    if (!shareText) {
      return ctx.reply('❌ Tidak ada teks yang bisa dibagikan!');
    }
  } else {
    // Jika user mengirim teks langsung
    const textToShare = message.replace('/sharevip', '').trim();
    
    if (!textToShare) {
      return ctx.reply('❌ Format: /sharevip <teks> atau reply pesan dengan /sharevip');
    }
    
    shareText = textToShare;
  }

  try {
    // Kirim ke semua group yang user telah tambahkan bot
    let success = 0;
    let failed = 0;
    const groups = user.joinedGroups;

    if (groups.length === 0) {
      return ctx.reply('❌ Anda belum menambahkan bot ke group manapun!');
    }

    const progressMessage = await ctx.reply(
      `📤 Memulai share VIP ke ${groups.length} group...\n` +
      `⚡ Mode: VIP (tanpa delay)`
    );

    // Kirim semua pesan sekaligus tanpa delay
    const promises = groups.map(async (groupId, index) => {
      try {
        // Cek apakah group masih aktif dan tidak diblacklist
        const group = await Group.findOne({ groupId, isActive: true });
        const blacklisted = await Blacklist.findOne({ groupId });
        
        if (!group || blacklisted) {
          failed++;
          return null;
        }

        await ctx.telegram.sendMessage(groupId, `📢 Share VIP from @${user.username || user.firstName}:\n\n${shareText}`);
        success++;
        
        // Update progress setiap 5 group
        if (index % 5 === 0 || index === groups.length - 1) {
          await ctx.telegram.editMessageText(
            progressMessage.chat.id,
            progressMessage.message_id,
            null,
            `📤 Sharing VIP ke ${groups.length} group...\n` +
            `✅ Berhasil: ${success} | ❌ Gagal: ${failed}\n` +
            `⚡ Mode: VIP (tanpa delay)`
          );
        }
        
        return true;
      } catch (error) {
        failed++;
        log(`Failed to share VIP to group ${groupId}: ${error.message}`);
        return false;
      }
    });

    // Tunggu semua promise selesai
    await Promise.all(promises);

    await ctx.telegram.editMessageText(
      progressMessage.chat.id,
      progressMessage.message_id,
      null,
      `✅ Share VIP selesai!\n` +
      `✔️ Berhasil: ${success} group\n` +
      `❌ Gagal: ${failed} group\n` +
      `⚡ Mode: VIP (tanpa delay)`
    );

    // Update share count
    user.shareCount += 1;
    await user.save();

  } catch (error) {
    ctx.reply('❌ Gagal melakukan share VIP!');
    log(`Error sharing VIP: ${error.message}`);
  }
});

// Command untuk fitur obfuscation
function setupObfCommands(bot) {
  // Command enc3 (Mandarin Encryption)
  bot.command("enc3", async (ctx) => {
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown(`
╭━━━「 ❌ ERROR 」━━━⬣
│ Terjadi kesalahan saat
│ memproses file!
╰━━━━━━━━━━━━━━━━⬣`);
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown(`
╭━━━「 ❌ ERROR 」━━━⬣
│ File harus berekstensi .js!
╰━━━━━━━━━━━━━━━━⬣`);
    }

    const encryptedPath = path.join(__dirname, "..", "temp", `china-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          ` ⚙️ Memulai (Hardened Mandarin) (1%)\n` +
          ` ${createProgressBar(1)}\n` +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Mandarin obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Mandarin yang diperkuat`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Hardened Mandarin Obfuscation"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getJapanObfuscationConfig() // Using Japan config as Mandarin
      );
      await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
      await fs.writeFile(encryptedPath, obfuscated);
      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscated);
      } catch (postObfuscationError) {
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      log(`Mengirim file terenkripsi gaya Mandarin: ${file.file_name}`);
      await ctx.replyWithDocument(
        { source: encryptedPath, filename: `china-encrypted-${file.file_name}` },
        {
          caption:
            "✅ *File terenkripsi (Hardened Mandarin) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Hardened Mandarin Obfuscation Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Mandarin obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // Command enc4 (Arab Encryption)
  bot.command("enc4", async (ctx) => {
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc4`!");
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, "..", "temp", `arab-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          ` ⚙️ Memulai (Hardened Arab) (1%)\n` +
          ` ${createProgressBar(1)}\n` +
          "```\n" +
          "PROSES ENCRYPT"
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Arab obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Arab yang diperkuat`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Hardened Arab Obfuscation"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getArabObfuscationConfig()
      );
      await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
      await fs.writeFile(encryptedPath, obfuscated);
      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscated);
      } catch (postObfuscationError) {
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      log(`Mengirim file terenkripsi gaya Arab: ${file.file_name}`);
      await ctx.replyWithDocument(
        { source: encryptedPath, filename: `arab-encrypted-${file.file_name}` },
        {
          caption:
            "✅ *File terenkripsi (Hardened Arab) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Hardened Arab Obfuscation Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Arab obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // Command japan (Japan Encryption)
  bot.command("japan", async (ctx) => {
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/japan`!");
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, "..", "temp", `japan-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          ` ⚙️ Memulai (Hardened Japan) (1%)\n` +
          ` ${createProgressBar(1)}\n` +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Japan obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Japan yang diperkuat`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Hardened Japan Obfuscation"
      );
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getJapanObfuscationConfig()
      );
      await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
      await fs.writeFile(encryptedPath, obfuscated);
      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscated);
      } catch (postObfuscationError) {
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      log(`Mengirim file terenkripsi gaya Japan: ${file.file_name}`);
      await ctx.replyWithDocument(
        { source: encryptedPath, filename: `japan-encrypted-${file.file_name}` },
        {
          caption:
            "✅ *File terenkripsi (Hardened Japan) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Hardened Japan Obfuscation Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Japan obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // ... (kode sebelumnya tetap sama)

// Command untuk zenc (Invisible Encryption)
bot.command("zenc", async (ctx) => {
  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/zenc`!");
  }

  const file = ctx.message.reply_to_message.document;
  if (!file.file_name.endsWith(".js")) {
    return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
  }

  const encryptedPath = path.join(__dirname, "..", "temp", `invisible-encrypted-${file.file_name}`);

  try {
    const progressMessage = await ctx.replyWithMarkdown(
      "```css\n" +
        "🔒 EncryptBot\n" +
        ` ⚙️ Memulai (InvisiBle) (1%)\n` +
        ` ${createProgressBar(1)}\n` +
        "```\n" +
        "PROSES ENCRYPT "
    );

    const fileLink = await ctx.telegram.getFileLink(file.file_id);
    log(`Mengunduh file untuk Strong obfuscation: ${file.file_name}`);
    await updateProgress(ctx, progressMessage, 10, "Mengunduh");
    const response = await fetch(fileLink);
    let fileContent = await response.text();
    await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

    log(`Memvalidasi kode awal: ${file.file_name}`);
    await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
    try {
      new Function(fileContent);
    } catch (syntaxError) {
      throw new Error(`Kode tidak valid: ${syntaxError.message}`);
    }

    log(`Mengenkripsi file dengan gaya Strong`);
    await updateProgress(
      ctx,
      progressMessage,
      40,
      "Inisialisasi Hardened Invisible Obfuscation"
    );
    const obfuscated = await JsConfuser.obfuscate(
      fileContent,
      getStrongObfuscationConfig()
    );
    let obfuscatedCode = obfuscated.code || obfuscated; // Pastikan string
    if (typeof obfuscatedCode !== "string") {
      throw new Error("Hasil obfuscation bukan string");
    }
    log(
      `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
        0,
        50
      )}...`
    );
    await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");

    log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
    try {
      new Function(obfuscatedCode);
    } catch (postObfuscationError) {
      throw new Error(
        `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
      );
    }

    await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
    await fs.writeFile(encryptedPath, obfuscatedCode);

    log(`Mengirim file terenkripsi gaya Invisible: ${file.file_name}`);
    await ctx.replyWithDocument(
      {
        source: encryptedPath,
        filename: `Invisible-encrypted-${file.file_name}`,
      },
      {
        caption: "✅ *File terenkripsi (Invisible) siap!*\nSUKSES ENCRYPT 🕊",
        parse_mode: "Markdown",
      }
    );
    await updateProgress(
      ctx,
      progressMessage,
      100,
      "Hardened Invisible Obfuscation Selesai"
    );

    if (await fs.pathExists(encryptedPath)) {
      await fs.unlink(encryptedPath);
      log(`File sementara dihapus: ${encryptedPath}`);
    }
  } catch (error) {
    log("Kesalahan saat Invisible obfuscation", error);
    await ctx.replyWithMarkdown(
      `❌ *Kesalahan:* ${
        error.message || "Tidak diketahui"
      }\n_Coba lagi dengan kode Javascript yang valid!_`
    );
    if (await fs.pathExists(encryptedPath)) {
      await fs.unlink(encryptedPath);
      log(`File sementara dihapus setelah error: ${encryptedPath}`);
    }
  }
});

// Command untuk xx (Custom Encryption dengan nama)
bot.command("xx", async (ctx) => {
  // Ambil nama kustom dari perintah
  const args = ctx.message.text.split(" ");
  if (args.length < 2 || !args[1]) {
    return ctx.replyWithMarkdown(
      "❌ *Error:* Gunakan format `/xx <nama>` dengan nama kustom!"
    );
  }
  const customName = args[1].replace(/[^a-zA-Z0-9_]/g, ""); // Sanitasi input, hanya huruf, angka, dan underscore
  if (!customName) {
    return ctx.replyWithMarkdown(
      "❌ *Error:* Nama kustom harus berisi huruf, angka, atau underscore!"
    );
  }

  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.replyWithMarkdown(
      "❌ *Error:* Balas file .js dengan `/xx <nama>`!"
    );
  }

  const file = ctx.message.reply_to_message.document;
  if (!file.file_name.endsWith(".js")) {
    return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
  }

  const encryptedPath = path.join(
    __dirname, "..", "temp",
    `custom-${customName}-encrypted-${file.file_name}`
  );

  try {
    const progressMessage = await ctx.replyWithMarkdown(
      "```css\n" +
        "🔒 EncryptBot\n" +
        ` ⚙️ Memulai (Hardened Custom: ${customName}) (1%)\n` +
        ` ${createProgressBar(1)}\n` +
        "```\n" +
        "PROSES ENCRYPT "
    );

    const fileLink = await ctx.telegram.getFileLink(file.file_id);
    log(`Mengunduh file untuk Custom obfuscation: ${file.file_name}`);
    await updateProgress(ctx, progressMessage, 10, "Mengunduh");
    const response = await fetch(fileLink);
    let fileContent = await response.text();
    await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

    log(`Memvalidasi kode awal: ${file.file_name}`);
    await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
    try {
      new Function(fileContent);
    } catch (syntaxError) {
      throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
    }

    log(`Mengenkripsi file dengan gaya Custom (${customName}) yang diperkuat`);
    await updateProgress(
      ctx,
      progressMessage,
      40,
      "Inisialisasi Hardened Custom Obfuscation"
    );
    const obfuscated = await JsConfuser.obfuscate(
      fileContent,
      getCustomObfuscationConfig(customName)
    );
    log(
      `Hasil obfuscation (50 char pertama): ${obfuscated.code.substring(
        0,
        50
      )}...`
    );
    await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");

    log(`Memvalidasi kode hasil obfuscation: ${file.file_name}`);
    try {
      new Function(obfuscated.code);
    } catch (postObfuscationError) {
      log(
        `Kode hasil obfuscation tidak valid: ${postObfuscationError.message}`
      );
      throw new Error(
        `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
      );
    }

    await fs.writeFile(encryptedPath, obfuscated.code);
    await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

    log(`Mengirim file terenkripsi gaya Custom: ${file.file_name}`);
    await ctx.replyWithDocument(
      {
        source: encryptedPath,
        filename: `custom-${customName}-encrypted-${file.file_name}`,
      },
      {
        caption: `✅ *File terenkripsi (Hardened Custom: ${customName}) siap!*\nSUKSES ENCRYPT 🕊`,
        parse_mode: "Markdown",
      }
    );
    await updateProgress(
      ctx,
      progressMessage,
      100,
      `Hardened Custom (${customName}) Obfuscation Selesai`
    );

    if (await fs.pathExists(encryptedPath)) {
      await fs.unlink(encryptedPath);
      log(`File sementara dihapus: ${encryptedPath}`);
    }
  } catch (error) {
    log("Kesalahan saat Custom obfuscation", error);
    await ctx.replyWithMarkdown(
      `❌ *Kesalahan:* ${
        error.message || "Tidak diketahui"
      }\n_Coba lagi dengan kode Javascript yang valid!_`
    );
    if (await fs.pathExists(encryptedPath)) {
      await fs.unlink(encryptedPath);
      log(`File sementara dihapus setelah error: ${encryptedPath}`);
    }
  }
});

// Command untuk quantum (Quantum Encryption)
bot.command("quantum", async (ctx) => {
  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.replyWithMarkdown(
      "❌ *Error:* Balas file .js dengan `/quantum`!"
    );
  }

  const file = ctx.message.reply_to_message.document;
  if (!file.file_name.endsWith(".js")) {
    return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
  }

  const encryptedPath = path.join(__dirname, "..", "temp", `quantum-encrypted-${file.file_name}`);

  try {
    const progressMessage = await ctx.replyWithMarkdown(
      "```css\n" +
        "🔒 EncryptBot\n" +
        " ⚙️ Memulai (Quantum Vortex Encryption) (1%)\n" +
        " " +
        createProgressBar(1) +
        "\n" +
        "```\n" +
        "PROSES ENCRYPT "
    );

    const fileLink = await ctx.telegram.getFileLink(file.file_id);
    log(`Mengunduh file untuk Quantum Vortex Encryption: ${file.file_name}`);
    await updateProgress(ctx, progressMessage, 10, "Mengunduh");
    const response = await fetch(fileLink);
    let fileContent = await response.text();
    await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

    log(`Memvalidasi kode awal: ${file.file_name}`);
    await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
    try {
      new Function(fileContent);
    } catch (syntaxError) {
      throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
    }

    log(`Mengenkripsi file dengan Quantum Vortex Encryption`);
    await updateProgress(
      ctx,
      progressMessage,
      40,
      "Inisialisasi Quantum Vortex Encryption"
    );
    const obfuscatedCode = await obfuscateQuantum(fileContent);
    log(
      `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
        0,
        50
      )}...`
    );
    log(
      `Ukuran file setelah obfuscation: ${Buffer.byteLength(
        obfuscatedCode,
        "utf-8"
      )} bytes`
    );

    log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
    try {
      new Function(obfuscatedCode);
    } catch (postObfuscationError) {
      log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
      throw new Error(
        `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
      );
    }

    await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
    await fs.writeFile(encryptedPath, obfuscatedCode);

    log(`Mengirim file terenkripsi quantum: ${file.file_name}`);
    await ctx.replyWithDocument(
      {
        source: encryptedPath,
        filename: `quantum-encrypted-${file.file_name}`,
      },
      {
        caption:
          "✅ *File terenkripsi (Quantum Vortex Encryption) siap!*\nSUKSES ENCRYPT 🕊",
        parse_mode: "Markdown",
      }
    );
    await updateProgress(
      ctx,
      progressMessage,
      100,
      "Quantum Vortex Encryption Selesai"
    );

    if (await fs.pathExists(encryptedPath)) {
      await fs.unlink(encryptedPath);
      log(`File sementara dihapus: ${encryptedPath}`);
    }
  } catch (error) {
    log("Kesalahan saat Quantum obfuscation", error);
    await ctx.replyWithMarkdown(
      `❌ *Kesalahan:* ${
        error.message || "Tidak diketahui"
      }\n_Coba lagi dengan kode Javascript yang valid!_`
    );
    if (await fs.pathExists(encryptedPath)) {
      await fs.unlink(encryptedPath);
      log(`File sementara dihapus setelah error: ${encryptedPath}`);
    }
  }
});

// Command untuk var (Var Encryption)
bot.command("var", async (ctx) => {
  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/var`!");
  }

  const file = ctx.message.reply_to_message.document;
  if (!file.file_name.endsWith(".js")) {
    return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
  }

  const encryptedPath = path.join(__dirname, "..", "temp", `var-encrypted-${file.file_name}`);

  try {
    const progressMessage = await ctx.replyWithMarkdown(
      "```css\n" +
        "🔒 EncryptBot\n" +
        " ⚙️ Memulai (Var) (1%)\n" +
        " " +
        createProgressBar(1) +
        "\n" +
        "```\n" +
        "PROSES ENCRYPT "
    );

    const fileLink = await ctx.telegram.getFileLink(file.file_id);
    log(`Mengunduh file untuk Var obfuscation: ${file.file_name}`);
    await updateProgress(ctx, progressMessage, 10, "Mengunduh");
    const response = await fetch(fileLink);
    let fileContent = await response.text();
    await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

    log(`Memvalidasi kode awal: ${file.file_name}`);
    await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
    try {
      new Function(fileContent);
    } catch (syntaxError) {
      throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
    }

    log(`Mengenkripsi file dengan gaya Var`);
    await updateProgress(
      ctx,
      progressMessage,
      40,
      "Inisialisasi Var Dynamic Obfuscation"
    );
    const obfuscated = await JsConfuser.obfuscate(
      fileContent,
      getNovaObfuscationConfig()
    );
    let obfuscatedCode = obfuscated.code || obfuscated;
    if (typeof obfuscatedCode !== "string") {
      throw new Error("Hasil obfuscation bukan string");
    }
    log(
      `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
        0,
        50
      )}...`
    );

    log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
    try {
      new Function(obfuscatedCode);
    } catch (postObfuscationError) {
      log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
      throw new Error(
        `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
      );
    }

    await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
    await fs.writeFile(encryptedPath, obfuscatedCode);

    log(`Mengirim file terenkripsi gaya Var: ${file.file_name}`);
    await ctx.replyWithDocument(
      { source: encryptedPath, filename: `Var-encrypted-${file.file_name}` },
      {
        caption: "✅ *File terenkripsi (Var) siap!*\nSUKSES ENCRYPT 🕊",
        parse_mode: "Markdown",
      }
    );
    await updateProgress(ctx, progressMessage, 100, "Var Obfuscation Selesai");

    if (await fs.pathExists(encryptedPath)) {
      await fs.unlink(encryptedPath);
      log(`File sementara dihapus: ${encryptedPath}`);
    }
  } catch (error) {
    log("Kesalahan saat Nova obfuscation", error);
    await ctx.replyWithMarkdown(
      `❌ *Kesalahan:* ${
        error.message || "Tidak diketahui"
      }\n_Coba lagi dengan kode Javascript yang valid!_`
    );
    if (await fs.pathExists(encryptedPath)) {
      await fs.unlink(encryptedPath);
      log(`File sementara dihapus setelah error: ${encryptedPath}`);
    }
  }
});

// Command untuk nebula (Nebula Encryption)
bot.command("nebula", async (ctx) => {
  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.replyWithMarkdown(
      "❌ *Error:* Balas file .js dengan `/nebula`!"
    );
  }

  const file = ctx.message.reply_to_message.document;
  if (!file.file_name.endsWith(".js")) {
    return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
  }

  const encryptedPath = path.join(__dirname, "..", "temp", `nebula-encrypted-${file.file_name}`);

  try {
    const progressMessage = await ctx.replyWithMarkdown(
      "```css\n" +
        "🔒 EncryptBot\n" +
        " ⚙️ Memulai (Nebula Polymorphic Storm) (1%)\n" +
        " " +
        createProgressBar(1) +
        "\n" +
        "```\n" +
        "PROSES ENCRYPT "
    );

    const fileLink = await ctx.telegram.getFileLink(file.file_id);
    log(`Mengunduh file untuk Nebula obfuscation: ${file.file_name}`);
    await updateProgress(ctx, progressMessage, 10, "Mengunduh");
    const response = await fetch(fileLink);
    let fileContent = await response.text();
    await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

    log(`Memvalidasi kode awal: ${file.file_name}`);
    await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
    try {
      new Function(fileContent);
    } catch (syntaxError) {
      throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
    }

    log(`Mengenkripsi file dengan gaya Nebula`);
    await updateProgress(
      ctx,
      progressMessage,
      40,
      "Inisialisasi Nebula Polymorphic Storm"
    );
    const obfuscated = await JsConfuser.obfuscate(
      fileContent,
      getNebulaObfuscationConfig()
    );
    let obfuscatedCode = obfuscated.code || obfuscated;
    if (typeof obfuscatedCode !== "string") {
      throw new Error("Hasil obfuscation bukan string");
    }
    log(
      `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
        0,
        50
      )}...`
    );
    log(
      `Ukuran file setelah obfuscation: ${Buffer.byteLength(
        obfuscatedCode,
        "utf-8"
      )} bytes`
    );

    log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
    try {
      new Function(obfuscatedCode);
    } catch (postObfuscationError) {
      log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
      throw new Error(
        `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
      );
    }

    await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
    await fs.writeFile(encryptedPath, obfuscatedCode);

    log(`Mengirim file terenkripsi gaya Nebula: ${file.file_name}`);
    await ctx.replyWithDocument(
      { source: encryptedPath, filename: `nebula-encrypted-${file.file_name}` },
      {
        caption:
          "✅ *File terenkripsi (Nebula Polymorphic Storm) siap!*\nSUKSES ENCRYPT 🕊",
        parse_mode: "Markdown",
      }
    );
    await updateProgress(
      ctx,
      progressMessage,
      100,
      "Nebula Polymorphic Storm Selesai"
    );

    if (await fs.pathExists(encryptedPath)) {
      await fs.unlink(encryptedPath);
      log(`File sementara dihapus: ${encryptedPath}`);
    }
  } catch (error) {
    log("Kesalahan saat Nebula obfuscation", error);
    await ctx.replyWithMarkdown(
      `❌ *Kesalahan:* ${
        error.message || "Tidak diketahui"
      }\n_Coba lagi dengan kode Javascript yang valid!_`
    );
    if (await fs.pathExists(encryptedPath)) {
      await fs.unlink(encryptedPath);
      log(`File sementara dihapus setelah error: ${encryptedPath}`);
    }
  }
});

// Command untuk enc5 (Siu+Calcrick Encryption)
bot.command("enc5", async (ctx) => {
  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.replyWithMarkdown(
      "❌ *Error:* Balas file .js dengan `/enc5`!"
    );
  }

  const file = ctx.message.reply_to_message.document;
  if (!file.file_name.endsWith(".js")) {
    return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
  }

  const encryptedPath = path.join(__dirname, "..", "temp", `siucalcrick-encrypted-${file.file_name}`);

  try {
    const progressMessage = await ctx.replyWithMarkdown(
      "```css\n" +
        "🔒 EncryptBot\n" +
        " ⚙️ Memulai (Calcrick Chaos Core) (1%)\n" +
        " " +
        createProgressBar(1) +
        "\n" +
        "```\n" +
        "PROSES ENCRYPT "
    );

    const fileLink = await ctx.telegram.getFileLink(file.file_id);
    log(`Mengunduh file untuk Siu+Calcrick obfuscation: ${file.file_name}`);
    await updateProgress(ctx, progressMessage, 10, "Mengunduh");
    const response = await fetch(fileLink);
    let fileContent = await response.text();
    await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

    log(`Memvalidasi kode awal: ${file.file_name}`);
    await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
    try {
      new Function(fileContent);
    } catch (syntaxError) {
      throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
    }

    log(`Mengenkripsi file dengan gaya Siu+Calcrick`);
    await updateProgress(
      ctx,
      progressMessage,
      40,
      "Inisialisasi Calcrick Chaos Core"
    );
    const obfuscated = await JsConfuser.obfuscate(
      fileContent,
      getSiuCalcrickObfuscationConfig()
    );
    let obfuscatedCode = obfuscated.code || obfuscated;
    if (typeof obfuscatedCode !== "string") {
      throw new Error("Hasil obfuscation bukan string");
    }
    log(
      `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
        0,
        50
      )}...`
    );
    log(
      `Ukuran file setelah obfuscation: ${Buffer.byteLength(
        obfuscatedCode,
        "utf-8"
      )} bytes`
    );

    log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
    try {
      new Function(obfuscatedCode);
    } catch (postObfuscationError) {
      log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
      throw new Error(
        `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
      );
    }

    await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
    await fs.writeFile(encryptedPath, obfuscatedCode);

    log(`Mengirim file terenkripsi gaya Siu+Calcrick: ${file.file_name}`);
    await ctx.replyWithDocument(
      {
        source: encryptedPath,
        filename: `siucalcrick-encrypted-${file.file_name}`,
      },
      {
        caption:
          "✅ *File terenkripsi (Calcrick Chaos Core) siap!*\nSUKSES ENCRYPT 🕊",
        parse_mode: "Markdown",
      }
    );
    await updateProgress(
      ctx,
      progressMessage,
      100,
      "Calcrick Chaos Core Selesai"
    );

    if (await fs.pathExists(encryptedPath)) {
      await fs.unlink(encryptedPath);
      log(`File sementara dihapus: ${encryptedPath}`);
    }
  } catch (error) {
    log("Kesalahan saat Siu+Calcrick obfuscation", error);
    await ctx.replyWithMarkdown(
      `❌ *Kesalahan:* ${
        error.message || "Tidak diketahui"
      }\n_Coba lagi dengan kode Javascript yang valid!_`
    );
    if (await fs.pathExists(encryptedPath)) {
      await fs.unlink(encryptedPath);
      log(`File sementara dihapus setelah error: ${encryptedPath}`);
    }
  }
});

// Command untuk enc2 (Custom Encryption dengan teks)
bot.command("enc2", async (ctx) => {
  const customString = ctx.message.text.split(" ")[1];

  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.replyWithMarkdown(
      "❌ *Error:* Balas file .js dengan `/enc2 <text>`!"
    );
  }

  if (!customString) {
    return ctx.replyWithMarkdown(
      "❌ *Error:* Balas file .js dengan `/enc2 <text>`!"
    );
  }

  const file = ctx.message.reply_to_message.document;
  if (!file.file_name.endsWith(".js")) {
    return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
  }

  const encryptedPath = path.join(__dirname, "..", "temp", `custom-encrypted-${file.file_name}`);

  try {
    const progressMessage = await ctx.replyWithMarkdown(
      "```css\n" +
        "🔒 EncryptBot\n" +
        " ⚙️ Memulai (custom enc) (1%)\n" +
        " " +
        createProgressBar(1) +
        "\n" +
        "```\n" +
        "PROSES ENCRYPT "
    );

    const fileLink = await ctx.telegram.getFileLink(file.file_id);
    log(`Mengunduh file untuk custom obfuscation: ${file.file_name}`);
    await updateProgress(ctx, progressMessage, 10, "Mengunduh");
    const response = await fetch(fileLink);
    let fileContent = await response.text();
    await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

    log(`Memvalidasi kode awal: ${file.file_name}`);
    await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
    try {
      new Function(fileContent);
    } catch (syntaxError) {
      throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
    }

    log(`Mengenkripsi file dengan gaya custom (${customString})`);
    await updateProgress(ctx, progressMessage, 40, `Inisialisasi custom (${customString})`);

    const obfuscated = await JsConfuser.obfuscate(
      fileContent,
      getCustomObfuscationConfig(customString)
    );

    let obfuscatedCode = obfuscated.code || obfuscated;
    if (typeof obfuscatedCode !== "string") {
      throw new Error("Hasil obfuscation bukan string");
    }
    log(
      `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
        0,
        50
      )}...`
    );
    log(
      `Ukuran file setelah obfuscation: ${Buffer.byteLength(
        obfuscatedCode,
        "utf-8"
      )} bytes`
    );

    log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
    try {
      new Function(obfuscatedCode);
    } catch (postObfuscationError) {
      log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
      throw new Error(
        `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
      );
    }

    await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
    await fs.writeFile(encryptedPath, obfuscatedCode);

    log(`Mengirim file terenkripsi gaya custom (${customString}): ${file.file_name}`);
    await ctx.replyWithDocument(
      {
        source: encryptedPath,
        filename: `custom-encrypted-${file.file_name}`,
      },
      {
        caption: `✅ *File terenkripsi custom (${customString}) siap!*\nSUKSES ENCRYPT 🕊`,
        parse_mode: "Markdown",
      }
    );
    await updateProgress(ctx, progressMessage, 100, `custom (${customString}) Selesai`);

    if (await fs.pathExists(encryptedPath)) {
      await fs.unlink(encryptedPath);
      log(`File sementara dihapus: ${encryptedPath}`);
    }
  } catch (error) {
    log("Kesalahan saat custom enc obfuscation", error);
    await ctx.replyWithMarkdown(
      `❌ *Kesalahan:* ${
        error.message || "Tidak diketahui"
      }\n_Coba lagi dengan kode Javascript yang valid!_`
    );
    if (await fs.pathExists(encryptedPath)) {
      await fs.unlink(encryptedPath);
      log(`File sementara dihapus setelah error: ${encryptedPath}`);
    }
  }
});

// Command untuk deobfuscate
bot.command("deobfuscate", async (ctx) => {
  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.replyWithMarkdown(
      "❌ *Error:* Balas file .js yang diobfuscate dengan `/deobfuscate`!"
    );
  }

  const file = ctx.message.reply_to_message.document;
  if (!file.file_name.endsWith(".js")) {
    return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
  }

  const deobfuscatedPath = path.join(__dirname, "..", "temp", `deobfuscated-${file.file_name}`);

  try {
    const progressMessage = await ctx.replyWithMarkdown(
      "```css\n" +
        "🔒 EncryptBot\n" +
        ` ⚙️ Memulai Deobfuscation (1%)\n` +
        ` ${createProgressBar(1)}\n` +
        "```\n" +
        "PROSES ENCRYPT "
    );

    // Mengunduh file
    const fileLink = await ctx.telegram.getFileLink(file.file_id);
    log(`Mengunduh file untuk deobfuscation: ${file.file_name}`);
    await updateProgress(ctx, progressMessage, 10, "Mengunduh");
    const response = await fetch(fileLink);
    let fileContent = await response.text();
    await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

    // Validasi kode awal
    log(`Memvalidasi kode awal: ${file.file_name}`);
    await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode Awal");
    try {
      new Function(fileContent);
    } catch (syntaxError) {
      throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
    }

    // Proses deobfuscation sederhana (implementasi dasar)
    // Catatan: Deobfuscation yang lengkap memerlukan library khusus
    log(`Memulai deobfuscation: ${file.file_name}`);
    await updateProgress(ctx, progressMessage, 40, "Memulai Deobfuscation");
    
    // Implementasi deobfuscation sederhana
    let deobfuscatedCode = fileContent;
    
    // Hapus beberapa pola obfuscation umum
    // 1. Hapus eval dan fungsi self-executing
    deobfuscatedCode = deobfuscatedCode.replace(/eval\(\(function\(.*?\)\{.*?\}\)\(.*?\)\)/g, '');
    
    // 2. Ganti string escape sequences
    deobfuscatedCode = deobfuscatedCode.replace(/\\x([0-9A-Fa-f]{2})/g, (match, p1) => {
      return String.fromCharCode(parseInt(p1, 16));
    });
    
    // 3. Ganti unicode escape sequences
    deobfuscatedCode = deobfuscatedCode.replace(/\\u([0-9A-Fa-f]{4})/g, (match, p1) => {
      return String.fromCharCode(parseInt(p1, 16));
    });

    // Validasi kode hasil
    log(`Memvalidasi kode hasil deobfuscation: ${file.file_name}`);
    await updateProgress(ctx, progressMessage, 60, "Memvalidasi Kode Hasil");
    let isValid = true;
    try {
      new Function(deobfuscatedCode);
      log(`Kode hasil valid: ${deobfuscatedCode.substring(0, 50)}...`);
    } catch (syntaxError) {
      log(`Kode hasil tidak valid: ${syntaxError.message}`);
      deobfuscatedCode = `// Kesalahan validasi: ${syntaxError.message}\n${deobfuscatedCode}`;
      isValid = false;
    }

    // Simpan hasil
    await updateProgress(ctx, progressMessage, 80, "Menyimpan Hasil");
    await fs.writeFile(deobfuscatedPath, deobfuscatedCode);

    // Kirim hasil
    log(`Mengirim file hasil deobfuscation: ${file.file_name}`);
    await ctx.replyWithDocument(
      { source: deobfuscatedPath, filename: `deobfuscated-${file.file_name}` },
      {
        caption: `✅ *File berhasil dideobfuscate!${
          isValid ? "" : " (Perhatikan pesan error dalam file)"
        }*\nSUKSES ENCRYPT 🕊`,
        parse_mode: "Markdown",
      }
    );
    await updateProgress(ctx, progressMessage, 100, "Deobfuscation Selesai");

    // Hapus file sementara
    if (await fs.pathExists(deobfuscatedPath)) {
      await fs.unlink(deobfuscatedPath);
      log(`File sementara dihapus: ${deobfuscatedPath}`);
    }
  } catch (error) {
    log("Kesalahan saat deobfuscation", error);
    await ctx.replyWithMarkdown(
      `❌ *Kesalahan:* ${
        error.message || "Tidak diketahui"
      }\n_Coba lagi dengan file Javascript yang valid!_`
    );
    if (await fs.pathExists(deobfuscatedPath)) {
      await fs.unlink(deobfuscatedPath);
      log(`File sementara dihapus setelah error: ${deobfuscatedPath}`);
    }
  }
});

  // Command enc (Time-Locked Encryption)
  bot.command("enc", async (ctx) => {
    const args = ctx.message.text.split(" ").slice(1);
    if (
      args.length !== 1 ||
      !/^\d+$/.test(args[0]) ||
      parseInt(args[0]) < 1 ||
      parseInt(args[0]) > 365
    ) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Gunakan format `/enc [1-365]` untuk jumlah hari (misal: `/enc 7`)!"
      );
    }

    const days = args[0];
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + parseInt(days));
    const expiryFormatted = expiryDate.toLocaleDateString();

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown(
        "❌ *Error:* Balas file .js dengan `/enc [1-365]`!"
      );
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, "..", "temp", `locked-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
          "🔒 EncryptBot\n" +
          " ⚙️ Memulai (Time-Locked Encryption) (1%)\n" +
          " " +
          createProgressBar(1) +
          "\n" +
          "```\n" +
          "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Time-Locked Encryption: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan Time-Locked Encryption`);
      await updateProgress(
        ctx,
        progressMessage,
        40,
        "Inisialisasi Time-Locked Encryption"
      );
      const obfuscatedCode = await obfuscateTimeLocked(fileContent, days);
      log(
        `Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(
          0,
          50
        )}...`
      );
      log(
        `Ukuran file setelah obfuscation: ${Buffer.byteLength(
          obfuscatedCode,
          "utf-8"
        )} bytes`
      );

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscatedCode);
      } catch (postObfuscationError) {
        log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
        throw new Error(
          `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
        );
      }

      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscatedCode);

      log(`Mengirim file terenkripsi time-locked: ${file.file_name}`);
      await ctx.replyWithMarkdown(
        `✅ *File terenkripsi (Time-Locked Encryption) siap!*\n` +
          `⏰ Masa aktif: ${days} hari (Kedaluwarsa: ${expiryFormatted})\n` +
          `_Powered by Ginaa_`,
        { parse_mode: "Markdown" }
      );
      await ctx.replyWithDocument({
        source: encryptedPath,
        filename: `locked-encrypted-${file.file_name}`,
      });
      await updateProgress(
        ctx,
        progressMessage,
        100,
        "Time-Locked Encryption Selesai"
      );

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Time-Locked obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${
          error.message || "Tidak diketahui"
        }\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  });

  // Implementasi command lainnya dengan pola yang sama...
}

// Command untuk admin group
function setupAdminCommands(bot) {
  // Command untuk mengatur antispam
  bot.command('antispam', async (ctx) => {
    if (ctx.chat.type !== 'group' && ctx.chat.type !== 'supergroup') {
      return ctx.reply('❌ Command ini hanya bisa digunakan di grup!');
    }

    // Cek apakah pengguna adalah admin
    try {
      const chatMember = await ctx.getChatMember(ctx.from.id);
      if (!['administrator', 'creator'].includes(chatMember.status)) {
        return ctx.reply('❌ Hanya admin yang bisa menggunakan command ini!');
      }
    } catch (error) {
      return ctx.reply('❌ Gagal memverifikasi status admin!');
    }

    const group = await Group.findOne({ groupId: ctx.chat.id });
    if (!group) {
      return ctx.reply('❌ Grup tidak terdaftar!');
    }

    // Toggle antispam setting
    group.settings.antispam = !group.settings.antispam;
    await group.save();

    await ctx.reply(
      `✅ Pengaturan antispam telah ${group.settings.antispam ? 'diaktifkan' : 'dinonaktifkan'}!`
    );
  });

  // Command untuk mengatur noevent
  bot.command('noevent', async (ctx) => {
    if (ctx.chat.type !== 'group' && ctx.chat.type !== 'supergroup') {
      return ctx.reply('❌ Command ini hanya bisa digunakan di grup!');
    }

    try {
      const chatMember = await ctx.getChatMember(ctx.from.id);
      if (!['administrator', 'creator'].includes(chatMember.status)) {
        return ctx.reply('❌ Hanya admin yang bisa menggunakan command ini!');
      }
    } catch (error) {
      return ctx.reply('❌ Gagal memverifikasi status admin!');
    }

    const group = await Group.findOne({ groupId: ctx.chat.id });
    if (!group) {
      return ctx.reply('❌ Grup tidak terdaftar!');
    }

    group.settings.noevent = !group.settings.noevent;
    await group.save();

    await ctx.reply(
      `✅ Pengaturan noevent telah ${group.settings.noevent ? 'diaktifkan' : 'dinonaktifkan'}!`
    );
  });

  // Command untuk mengatur nolinks
  bot.command('nolinks', async (ctx) => {
    if (ctx.chat.type !== 'group' && ctx.chat.type !== 'supergroup') {
      return ctx.reply('❌ Command ini hanya bisa digunakan di grup!');
    }

    try {
      const chatMember = await ctx.getChatMember(ctx.from.id);
      if (!['administrator', 'creator'].includes(chatMember.status)) {
        return ctx.reply('❌ Hanya admin yang bisa menggunakan command ini!');
      }
    } catch (error) {
      return ctx.reply('❌ Gagal memverifikasi status admin!');
    }

    const group = await Group.findOne({ groupId: ctx.chat.id });
    if (!group) {
      return ctx.reply('❌ Grup tidak terdaftar!');
    }

    group.settings.nolinks = !group.settings.nolinks;
    await group.save();

    await ctx.reply(
      `✅ Pengaturan nolinks telah ${group.settings.nolinks ? 'diaktifkan' : 'dinonaktifkan'}!`
    );
  });

  // Command untuk mengatur noforwards
  bot.command('noforwards', async (ctx) => {
    if (ctx.chat.type !== 'group' && ctx.chat.type !== 'supergroup') {
      return ctx.reply('❌ Command ini hanya bisa digunakan di grup!');
    }

    try {
      const chatMember = await ctx.getChatMember(ctx.from.id);
      if (!['administrator', 'creator'].includes(chatMember.status)) {
        return ctx.reply('❌ Hanya admin yang bisa menggunakan command ini!');
      }
    } catch (error) {
      return ctx.reply('❌ Gagal memverifikasi status admin!');
    }

    const group = await Group.findOne({ groupId: ctx.chat.id });
    if (!group) {
      return ctx.reply('❌ Grup tidak terdaftar!');
    }

    group.settings.noforwards = !group.settings.noforwards;
    await group.save();

    await ctx.reply(
      `✅ Pengaturan noforwards telah ${group.settings.noforwards ? 'diaktifkan' : 'dinonaktifkan'}!`
    );
  });

  // Command untuk mengatur nocontacts
  bot.command('nocontacts', async (ctx) => {
    if (ctx.chat.type !== 'group' && ctx.chat.type !== 'supergroup') {
      return ctx.reply('❌ Command ini hanya bisa digunakan di grup!');
    }

    try {
      const chatMember = await ctx.getChatMember(ctx.from.id);
      if (!['administrator', 'creator'].includes(chatMember.status)) {
        return ctx.reply('❌ Hanya admin yang bisa menggunakan command ini!');
      }
    } catch (error) {
      return ctx.reply('❌ Gagal memverifikasi status admin!');
    }

    const group = await Group.findOne({ groupId: ctx.chat.id });
    if (!group) {
      return ctx.reply('❌ Grup tidak terdaftar!');
    }

    group.settings.nocontacts = !group.settings.nocontacts;
    await group.save();

    await ctx.reply(
      `✅ Pengaturan nocontacts telah ${group.settings.nocontacts ? 'diaktifkan' : 'dinonaktifkan'}!`
    );
  });

  // Command untuk mengatur nohastags
  bot.command('nohastags', async (ctx) => {
    if (ctx.chat.type !== 'group' && ctx.chat.type !== 'supergroup') {
      return ctx.reply('❌ Command ini hanya bisa digunakan di grup!');
    }

    try {
      const chatMember = await ctx.getChatMember(ctx.from.id);
      if (!['administrator', 'creator'].includes(chatMember.status)) {
        return ctx.reply('❌ Hanya admin yang bisa menggunakan command ini!');
      }
    } catch (error) {
      return ctx.reply('❌ Gagal memverifikasi status admin!');
    }

    const group = await Group.findOne({ groupId: ctx.chat.id });
    if (!group) {
      return ctx.reply('❌ Grup tidak terdaftar!');
    }

    group.settings.nohastags = !group.settings.nohastags;
    await group.save();

    await ctx.reply(
      `✅ Pengaturan nohastags telah ${group.settings.nohastags ? 'diaktifkan' : 'dinonaktifkan'}!`
    );
  });

  // Command untuk mengatur nocommands
  bot.command('nocommands', async (ctx) => {
    if (ctx.chat.type !== 'group' && ctx.chat.type !== 'supergroup') {
      return ctx.reply('❌ Command ini hanya bisa digunakan di grup!');
    }

    try {
      const chatMember = await ctx.getChatMember(ctx.from.id);
      if (!['administrator', 'creator'].includes(chatMember.status)) {
        return ctx.reply('❌ Hanya admin yang bisa menggunakan command ini!');
      }
    } catch (error) {
      return ctx.reply('❌ Gagal memverifikasi status admin!');
    }

    const group = await Group.findOne({ groupId: ctx.chat.id });
    if (!group) {
      return ctx.reply('❌ Grup tidak terdaftar!');
    }

    group.settings.nocommands = !group.settings.nocommands;
    await group.save();

    await ctx.reply(
      `✅ Pengaturan nocommands telah ${group.settings.nocommands ? 'diaktifkan' : 'dinonaktifkan'}!`
    );
  });
}

// Command untuk owner
function setupOwnerCommands(bot) {
  // Command untuk menambahkan blacklist
  bot.command('addbl', isOwner, async (ctx) => {
    const args = ctx.message.text.split(' ');
    if (args.length < 2) {
      return ctx.reply('❌ Format: /addbl <group_id> [alasan]');
    }

    const groupId = parseInt(args[1]);
    if (isNaN(groupId)) {
      return ctx.reply('❌ Group ID harus berupa angka!');
    }

    const reason = args.slice(2).join(' ') || 'Tidak ada alasan';

    try {
      // Cek apakah group sudah di blacklist
      const existing = await Blacklist.findOne({ groupId });
      if (existing) {
        return ctx.reply('❌ Group sudah ada di blacklist!');
      }

      // Tambahkan ke blacklist
      const blacklist = new Blacklist({
        groupId,
        reason
      });
      await blacklist.save();

      // Nonaktifkan group jika ada
      await Group.findOneAndUpdate(
        { groupId },
        { isActive: false }
      );

      ctx.reply('✅ Group berhasil ditambahkan ke blacklist!');
    } catch (error) {
      ctx.reply('❌ Gagal menambahkan ke blacklist!');
      log(`Error adding blacklist: ${error.message}`);
    }
  });

  // Command untuk menghapus blacklist
  bot.command('delbl', isOwner, async (ctx) => {
    const args = ctx.message.text.split(' ');
    if (args.length < 2) {
      return ctx.reply('❌ Format: /delbl <group_id>');
    }

    const groupId = parseInt(args[1]);
    if (isNaN(groupId)) {
      return ctx.reply('❌ Group ID harus berupa angka!');
    }

    try {
      const result = await Blacklist.findOneAndDelete({ groupId });
      if (!result) {
        return ctx.reply('❌ Group tidak ditemukan di blacklist!');
      }

      ctx.reply('✅ Group berhasil dihapus dari blacklist!');
    } catch (error) {
      ctx.reply('❌ Gagal menghapus dari blacklist!');
      log(`Error deleting blacklist: ${error.message}`);
    }
  });

  // Command untuk melihat list blacklist
  bot.command('listbl', isOwner, async (ctx) => {
    try {
      const blacklists = await Blacklist.find().sort({ blacklistedAt: -1 });
      if (blacklists.length === 0) {
        return ctx.reply('📝 Tidak ada group yang di-blacklist.');
      }

      let message = '📋 Daftar Group Blacklist:\n\n';
      blacklists.forEach((bl, index) => {
        message += `${index + 1}. Group ID: ${bl.groupId}\n`;
        message += `   Alasan: ${bl.reason}\n`;
        message += `   Tanggal: ${moment(bl.blacklistedAt).format('DD/MM/YYYY HH:mm')}\n\n`;
      });

      ctx.reply(message);
    } catch (error) {
      ctx.reply('❌ Gagal mengambil daftar blacklist!');
      log(`Error listing blacklist: ${error.message}`);
    }
  });

  // Command untuk menambahkan premium
  bot.command('addprem', isOwner, async (ctx) => {
    const args = ctx.message.text.split(' ');
    if (args.length < 3) {
      return ctx.reply('❌ Format: /addprem <user_id> <hari>');
    }

    const userId = parseInt(args[1]);
    if (isNaN(userId)) {
      return ctx.reply('❌ User ID harus berupa angka!');
    }

    const days = parseInt(args[2]);
    if (isNaN(days) || days < 1) {
      return ctx.reply('❌ Jumlah hari harus berupa angka positif!');
    }

    try {
      const user = await User.findOne({ userId });
      if (!user) {
        return ctx.reply('❌ User tidak ditemukan!');
      }

      const expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + days);

      user.isPremium = true;
      user.premiumExpiry = expiryDate;
      await user.save();

      ctx.reply(`✅ Premium berhasil ditambahkan untuk user ${userId} selama ${days} hari!`);
    } catch (error) {
      ctx.reply('❌ Gagal menambahkan premium!');
      log(`Error adding premium: ${error.message}`);
    }
  });

  // Command untuk menghapus premium
  bot.command('delprem', isOwner, async (ctx) => {
    const args = ctx.message.text.split(' ');
    if (args.length < 2) {
      return ctx.reply('❌ Format: /delprem <user_id>');
    }

    const userId = parseInt(args[1]);
    if (isNaN(userId)) {
      return ctx.reply('❌ User ID harus berupa angka!');
    }

    try {
      const user = await User.findOne({ userId });
      if (!user) {
        return ctx.reply('❌ User tidak ditemukan!');
      }

      user.isPremium = false;
      user.premiumExpiry = null;
      await user.save();

      ctx.reply(`✅ Premium berhasil dihapus untuk user ${userId}!`);
    } catch (error) {
      ctx.reply('❌ Gagal menghapus premium!');
      log(`Error deleting premium: ${error.message}`);
    }
  });

  // Command untuk melihat list premium
  bot.command('listprem', isOwner, async (ctx) => {
    try {
      const premiumUsers = await User.find({
        isPremium: true,
        premiumExpiry: { $gt: new Date() }
      }).sort({ premiumExpiry: 1 });

      if (premiumUsers.length === 0) {
        return ctx.reply('📝 Tidak ada user premium.');
      }

      let message = '📋 Daftar User Premium:\n\n';
      premiumUsers.forEach((user, index) => {
        const expiry = moment(user.premiumExpiry).format('DD/MM/YYYY HH:mm');
        message += `${index + 1}. User ID: ${user.userId}\n`;
        message += `   Username: @${user.username || 'N/A'}\n`;
        message += `   Expiry: ${expiry}\n\n`;
      });

      ctx.reply(message);
    } catch (error) {
      ctx.reply('❌ Gagal mengambil daftar premium!');
      log(`Error listing premium: ${error.message}`);
    }
  });

  // Command untuk broadcast
  bot.command('bc', isOwner, async (ctx) => {
    const message = ctx.message.text.split(' ').slice(1).join(' ');
    if (!message) {
      return ctx.reply('❌ Format: /bc <pesan>');
    }

    try {
      const users = await User.find();
      let success = 0;
      let failed = 0;

      ctx.reply(`📤 Memulai broadcast ke ${users.length} user...`);

      for (const user of users) {
        try {
          await ctx.telegram.sendMessage(user.userId, message);
          success++;
        } catch (error) {
          failed++;
          log(`Failed to send message to ${user.userId}: ${error.message}`);
        }

        // Delay untuk menghindari rate limit
        await new Promise(resolve => setTimeout(resolve, 100));
      }

      ctx.reply(
        `✅ Broadcast selesai!\n` +
        `✔️ Berhasil: ${success}\n` +
        `❌ Gagal: ${failed}`
      );
    } catch (error) {
      ctx.reply('❌ Gagal melakukan broadcast!');
      log(`Error broadcasting: ${error.message}`);
    }
  });

  // Command untuk stats
  bot.command('stats', isOwner, async (ctx) => {
    try {
      const userCount = await User.countDocuments();
      const groupCount = await Group.countDocuments({ isActive: true });
      const premiumCount = await User.countDocuments({
        isPremium: true,
        premiumExpiry: { $gt: new Date() }
      });
      const blacklistCount = await Blacklist.countDocuments();

      const statsText = `
📊 Statistik Bot:
👥 Total User: ${userCount}
👥 User Premium: ${premiumCount}
👥 Group Aktif: ${groupCount}
🚫 Group Blacklist: ${blacklistCount}
⏰ Runtime: ${runtime(process.uptime())}
💾 Memory: ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB
      `.trim();

      ctx.reply(statsText);
    } catch (error) {
      ctx.reply('❌ Gagal mengambil statistik!');
      log(`Error getting stats: ${error.message}`);
    }
  });

  // Command untuk melihat list group
  bot.command('groups', isOwner, async (ctx) => {
    try {
      const groups = await Group.find({ isActive: true }).sort({ addedAt: -1 });
      if (groups.length === 0) {
        return ctx.reply('📝 Tidak ada group aktif.');
      }

      let message = '📋 Daftar Group Aktif:\n\n';
      groups.forEach((group, index) => {
        const added = moment(group.addedAt).format('DD/MM/YYYY');
        message += `${index + 1}. ${group.title || 'N/A'}\n`;
        message += `   ID: ${group.groupId}\n`;
        message += `   Username: @${group.username || 'N/A'}\n`;
        message += `   Ditambahkan: ${added}\n\n`;
      });

      ctx.reply(message);
    } catch (error) {
      ctx.reply('❌ Gagal mengambil daftar group!');
      log(`Error listing groups: ${error.message}`);
    }
  });

  // Command untuk cleanup group tidak aktif
  bot.command('cleanup', isOwner, async (ctx) => {
    try {
      const groups = await Group.find({ isActive: true });
      let cleaned = 0;
      let total = groups.length;

      ctx.reply(`🧹 Memulai cleanup ${total} group...`);

      for (const group of groups) {
        try {
          // Cek apakah bot masih ada di group
          await ctx.telegram.getChatMember(group.groupId, ctx.botInfo.id);
        } catch (error) {
          // Jika error, artinya bot sudah tidak ada di group
          group.isActive = false;
          await group.save();
          cleaned++;
        }

        // Delay untuk menghindari rate limit
        await new Promise(resolve => setTimeout(resolve, 100));
      }

      ctx.reply(
        `✅ Cleanup selesai!\n` +
        `🧹 Dibersihkan: ${cleaned}/${total} group`
      );
    } catch (error) {
      ctx.reply('❌ Gagal melakukan cleanup!');
      log(`Error cleaning up groups: ${error.message}`);
    }
  });
}

module.exports = {
  setupMainMenu,
  setupObfCommands,
  setupAdminCommands,
  setupOwnerCommands
};