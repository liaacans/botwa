require("dotenv").config();

const { Octokit } = require("@octokit/rest");
const { neon } = require("@neondatabase/serverless");

const requiredVariables = [
  "DATABASE_URL",
  "LEGACY_GITHUB_TOKEN",
  "LEGACY_GITHUB_OWNER",
  "LEGACY_GITHUB_REPO"
];

const missingVariables = requiredVariables.filter(name => !process.env[name]);

if (missingVariables.length) {
  throw new Error(`Konfigurasi migrasi belum lengkap: ${missingVariables.join(", ")}`);
}

const sql = neon(process.env.DATABASE_URL);
const octokit = new Octokit({ auth: process.env.LEGACY_GITHUB_TOKEN });
const owner = process.env.LEGACY_GITHUB_OWNER;
const repo = process.env.LEGACY_GITHUB_REPO;
const branch = process.env.LEGACY_GITHUB_BRANCH || "main";

function isDatabaseFile(path) {
  return path === "users.json" || /^(transactions|withdrawals|activity)\/[^/]+\.json$/.test(path);
}

async function ensureSchema() {
  await sql`
    CREATE TABLE IF NOT EXISTS xdk_app_store (
      store_key TEXT PRIMARY KEY,
      data JSONB NOT NULL,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
    )
  `;
}

async function readGitHubJson(path, fileSha) {
  const response = await octokit.repos.getContent({
    owner,
    repo,
    path,
    ref: branch
  });

  let content = response.data.content;

  if (!content && fileSha) {
    const blob = await octokit.git.getBlob({ owner, repo, file_sha: fileSha });
    content = blob.data.content;
  }

  if (!content) {
    throw new Error(`Isi file ${path} tidak dapat dibaca dari GitHub.`);
  }

  return JSON.parse(Buffer.from(content, "base64").toString("utf8"));
}

async function migrate() {
  await ensureSchema();

  const reference = await octokit.git.getRef({
    owner,
    repo,
    ref: `heads/${branch}`
  });
  const commit = await octokit.git.getCommit({
    owner,
    repo,
    commit_sha: reference.data.object.sha
  });
  const tree = await octokit.git.getTree({
    owner,
    repo,
    tree_sha: commit.data.tree.sha,
    recursive: "true"
  });

  const files = tree.data.tree.filter(
    item => item.type === "blob" && isDatabaseFile(item.path)
  );

  let imported = 0;
  let skipped = 0;

  for (const file of files) {
    const data = await readGitHubJson(file.path, file.sha);
    const result = await sql`
      INSERT INTO xdk_app_store (store_key, data, updated_at)
      VALUES (${file.path}, ${JSON.stringify(data)}::jsonb, CURRENT_TIMESTAMP)
      ON CONFLICT (store_key) DO NOTHING
      RETURNING store_key
    `;

    if (result.length) imported += 1;
    else skipped += 1;
  }

  console.log(`Migrasi selesai. Diimpor: ${imported}; dilewati karena sudah ada: ${skipped}.`);
}

migrate().catch(error => {
  console.error("Migrasi GitHub ke Neon gagal:", error.message);
  process.exitCode = 1;
});
