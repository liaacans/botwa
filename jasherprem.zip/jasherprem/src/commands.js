const { Markup } = require('telegraf');
const { User, Group, Blacklist, Payment } = require('../lib/database');
const { log, runtime, moment, uploadToUguu } = require('../lib/utils');
const { privateChatOnly, ownerOnly, groupNotBlacklisted } = require('../lib/middleware');
const path = require('path');
const fs = require('fs-extra');
const fetch = require('node-fetch');

// Import konfigurasi obfuscation dari obf.js
const obfConfigs = require('../obf');

// Menyimpan pesan progress global
const progressMessages = new Map();

// Command start
function setupStartCommand(bot) {
  bot.start(async (ctx) => {
    const user = ctx.userData;
    const isCreator = ctx.from.id.toString() === global.OWNER_ID;
    const sender = ctx.from.username || `${ctx.from.first_name}${ctx.from.last_name ? ' ' + ctx.from.last_name : ''}`;
    
    const menuText = `
╭─❒ 「 User Info 」 
├ Owner : ${isCreator ? 'True' : 'False'}
├ Name : ${ctx.from.first_name}${ctx.from.last_name ? ' ' + ctx.from.last_name : ''}
├ Profile : @${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`;

    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('🔰 Jasher Menu', 'jasher_menu')],
      [Markup.button.callback('👤 Owner Menu', 'owner_menu'), Markup.button.callback('🔒 Obf Menu', 'obf_menu')],
      [Markup.button.callback('🛒 Buy Premium', 'buy_premium'), Markup.button.callback('📊 Status', 'status_info')]
    ]);
    
    try {
      await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
        caption: menuText,
        parse_mode: 'Markdown',
        ...keyboard
      });
    } catch (error) {
      await ctx.reply(menuText, {
        parse_mode: 'Markdown',
        ...keyboard
      });
    }
  });
}

// Command menu
function setupMenuCommand(bot) {
  bot.command('menu', async (ctx) => {
    const isCreator = ctx.from.id.toString() === global.OWNER_ID;
    const sender = ctx.from.username || `${ctx.from.first_name}${ctx.from.last_name ? ' ' + ctx.from.last_name : ''}`;
    
    const menuText = `
╭─❒ 「 User Info 」 
├ Owner : ${isCreator ? 'True' : 'False'}
├ Name : ${ctx.from.first_name}${ctx.from.last_name ? ' ' + ctx.from.last_name : ''}
├ Profile : @${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
Silahkan pilih button dibawah ini!`;

    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('🔰 Jasher Menu', 'jasher_menu')],
      [Markup.button.callback('👤 Owner Menu', 'owner_menu'), Markup.button.callback('🔒 Obf Menu', 'obf_menu')],
      [Markup.button.callback('🛒 Buy Premium', 'buy_premium'), Markup.button.callback('📊 Status', 'status_info')]
    ]);
    
    await ctx.reply(menuText, {
      parse_mode: 'Markdown',
      ...keyboard
    });
  });
}

// Command untuk menambah premium
function setupAddPremCommand(bot) {
  bot.command('addprem', ownerOnly, async (ctx) => {
    const args = ctx.message.text.split(' ');
    if (args.length < 3) {
      return ctx.reply('❌ Format: /addprem <user_id> <days>');
    }
    
    const userId = parseInt(args[1]);
    const days = parseInt(args[2]);
    
    if (isNaN(userId) || isNaN(days) || days < 1) {
      return ctx.reply('❌ Format: /addprem <user_id> <days> (days harus angka positif)');
    }
    
    try {
      const user = await User.findOne({ userId });
      if (!user) {
        return ctx.reply('❌ User tidak ditemukan');
      }
      
      const premiumUntil = new Date();
      premiumUntil.setDate(premiumUntil.getDate() + days);
      
      user.isPremium = true;
      user.premiumUntil = premiumUntil;
      await user.save();
      
      await ctx.reply(`✅ Premium berhasil ditambahkan untuk user ${userId} selama ${days} hari`);
      
      // Kirim notifikasi ke user
      try {
        await ctx.telegram.sendMessage(userId, `🎉 Anda mendapatkan premium selama ${days} hari!`);
      } catch (error) {
        log(`Tidak dapat mengirim notifikasi ke user ${userId}: ${error.message}`);
      }
    } catch (error) {
      log('Error adding premium: ' + error.message);
      await ctx.reply('❌ Gagal menambahkan premium');
    }
  });
}

// Command untuk menghapus premium
function setupDelPremCommand(bot) {
  bot.command('delprem', ownerOnly, async (ctx) => {
    const args = ctx.message.text.split(' ');
    if (args.length < 2) {
      return ctx.reply('❌ Format: /delprem <user_id>');
    }
    
    const userId = parseInt(args[1]);
    
    if (isNaN(userId)) {
      return ctx.reply('❌ Format: /delprem <user_id>');
    }
    
    try {
      const user = await User.findOne({ userId });
      if (!user) {
        return ctx.reply('❌ User tidak ditemukan');
      }
      
      user.isPremium = false;
      user.premiumUntil = null;
      await user.save();
      
      await ctx.reply(`✅ Premium berhasil dihapus untuk user ${userId}`);
    } catch (error) {
      log('Error removing premium: ' + error.message);
      await ctx.reply('❌ Gagal menghapus premium');
    }
  });
}

// Command untuk list premium users
function setupListPremCommand(bot) {
  bot.command('listprem', ownerOnly, async (ctx) => {
    try {
      const premiumUsers = await User.find({ 
        isPremium: true,
        premiumUntil: { $gt: new Date() }
      });
      
      if (premiumUsers.length === 0) {
        return ctx.reply('❌ Tidak ada user premium');
      }
      
      let message = '📋 Daftar User Premium:\n\n';
      for (const user of premiumUsers) {
        const remaining = Math.ceil((user.premiumUntil - new Date()) / (1000 * 60 * 60 * 24));
        message += `👤 ${user.firstName}${user.lastName ? ' ' + user.lastName : ''} (@${user.username || 'N/A'})\n`;
        message += `🆔 ID: ${user.userId}\n`;
        message += `⏰ Sisa: ${remaining} hari\n`;
        message += `📅 Hingga: ${moment(user.premiumUntil).format('DD/MM/YYYY HH:mm')}\n\n`;
      }
      
      await ctx.reply(message);
    } catch (error) {
      log('Error listing premium users: ' + error.message);
      await ctx.reply('❌ Gagal mengambil daftar premium users');
    }
  });
}

// Command untuk menambah blacklist grup
function setupAddBlCommand(bot) {
  bot.command('addbl', ownerOnly, async (ctx) => {
    const args = ctx.message.text.split(' ');
    if (args.length < 2) {
      return ctx.reply('❌ Format: /addbl <group_id> [reason]');
    }
    
    const groupId = parseInt(args[1]);
    const reason = args.slice(2).join(' ') || 'No reason provided';
    
    if (isNaN(groupId)) {
      return ctx.reply('❌ Format: /addbl <group_id> [reason]');
    }
    
    try {
      const existing = await Blacklist.findOne({ groupId });
      if (existing) {
        return ctx.reply('❌ Grup sudah ada di blacklist');
      }
      
      const blacklist = new Blacklist({
        groupId,
        reason
      });
      
      await blacklist.save();
      await ctx.reply(`✅ Grup ${groupId} berhasil ditambahkan ke blacklist\nAlasan: ${reason}`);
    } catch (error) {
      log('Error adding to blacklist: ' + error.message);
      await ctx.reply('❌ Gagal menambahkan ke blacklist');
    }
  });
}

// Command untuk menghapus blacklist grup
function setupDelBlCommand(bot) {
  bot.command('delbl', ownerOnly, async (ctx) => {
    const args = ctx.message.text.split(' ');
    if (args.length < 2) {
      return ctx.reply('❌ Format: /delbl <group_id>');
    }
    
    const groupId = parseInt(args[1]);
    
    if (isNaN(groupId)) {
      return ctx.reply('❌ Format: /delbl <group_id>');
    }
    
    try {
      const result = await Blacklist.deleteOne({ groupId });
      
      if (result.deletedCount === 0) {
        return ctx.reply('❌ Grup tidak ditemukan di blacklist');
      }
      
      await ctx.reply(`✅ Grup ${groupId} berhasil dihapus dari blacklist`);
    } catch (error) {
      log('Error removing from blacklist: ' + error.message);
      await ctx.reply('❌ Gagal menghapus dari blacklist');
    }
  });
}

// Command untuk list blacklist grup
function setupListBlCommand(bot) {
  bot.command('listbl', ownerOnly, async (ctx) => {
    try {
      const blacklistedGroups = await Blacklist.find();
      
      if (blacklistedGroups.length === 0) {
        return ctx.reply('✅ Tidak ada grup yang diblacklist');
      }
      
      let message = '📋 Daftar Grup Blacklist:\n\n';
      for (const group of blacklistedGroups) {
        message += `👥 Group ID: ${group.groupId}\n`;
        message += `📝 Alasan: ${group.reason}\n`;
        message += `⏰ Sejak: ${moment(group.blacklistedAt).format('DD/MM/YYYY HH:mm')}\n\n`;
      }
      
      await ctx.reply(message);
    } catch (error) {
      log('Error listing blacklisted groups: ' + error.message);
      await ctx.reply('❌ Gagal mengambil daftar blacklist');
    }
  });
}

// Command untuk list grup aktif
function setupListGroupsCommand(bot) {
  bot.command('listgroups', ownerOnly, async (ctx) => {
    try {
      const activeGroups = await Group.find({ isActive: true });
      
      if (activeGroups.length === 0) {
        return ctx.reply('❌ Tidak ada grup aktif');
      }
      
      let message = '📋 Daftar Grup Aktif:\n\n';
      for (const group of activeGroups) {
        message += `👥 ${group.title}${group.username ? ` (@${group.username})` : ''}\n`;
        message += `🆔 ID: ${group.groupId}\n`;
        message += `📅 Ditambahkan: ${moment(group.addedAt).format('DD/MM/YYYY HH:mm')}\n\n`;
      }
      
      await ctx.reply(message);
    } catch (error) {
      log('Error listing groups: ' + error.message);
      await ctx.reply('❌ Gagal mengambil daftar grup');
    }
  });
}

// Command untuk broadcast ke semua user
function setupBcCommand(bot) {
  bot.command('bc', ownerOnly, async (ctx) => {
    const message = ctx.message.text.split(' ').slice(1).join(' ');
    
    if (!message) {
      return ctx.reply('❌ Format: /bc <message>');
    }
    
    try {
      const users = await User.find();
      let successCount = 0;
      let failCount = 0;
      
      await ctx.reply(`📢 Memulai broadcast ke ${users.length} user...`);
      
      for (const user of users) {
        try {
          await ctx.telegram.sendMessage(user.userId, `📢 Broadcast dari Admin:\n\n${message}`);
          successCount++;
          
          // Delay untuk menghindari limit
          await new Promise(resolve => setTimeout(resolve, 100));
        } catch (error) {
          failCount++;
          log(`Gagal mengirim broadcast ke user ${user.userId}: ${error.message}`);
        }
      }
      
      await ctx.reply(`✅ Broadcast selesai!\nBerhasil: ${successCount}\nGagal: ${failCount}`);
    } catch (error) {
      log('Error broadcasting: ' + error.message);
      await ctx.reply('❌ Gagal melakukan broadcast');
    }
  });
}

// Command untuk membeli script
function setupBuyScCommand(bot) {
  bot.command('buysc', privateChatOnly, async (ctx) => {
    const user = ctx.userData;
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('💰 Bayar dengan QRIS', 'pay_qris')],
      [Markup.button.callback('🔙 Kembali', 'main_menu')]
    ]);
    
    await ctx.replyWithMarkdown(
      `🛒 *Beli Script Premium*\n\n` +
      `Pilih metode pembayaran di bawah ini:`,
      keyboard
    );
  });
}

// Command untuk membeli premium
function setupBuyPremCommand(bot) {
  bot.command('buyprem', privateChatOnly, async (ctx) => {
    const user = ctx.userData;
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback('💰 Bayar dengan QRIS', 'pay_premium_qris')],
      [Markup.button.callback('🔙 Kembali', 'main_menu')]
    ]);
    
    await ctx.replyWithMarkdown(
      `🎖️ *Beli Premium*\n\n` +
      `Dengan premium, Anda dapat:\n` +
      `• Menggunakan semua fitur obfuscation\n` +
      `• Share tanpa batas\n` +
      `• Prioritas support\n\n` +
      `Harga: Rp 50.000 / bulan\n\n` +
      `Pilih metode pembayaran di bawah ini:`,
      keyboard
    );
  });
}

// Command untuk status
function setupStatusCommand(bot) {
  bot.command('status', async (ctx) => {
    const user = ctx.userData;
    const isCreator = ctx.from.id.toString() === global.OWNER_ID;
    
    let statusMessage = `📊 *Status Akun*\n\n`;
    statusMessage += `👤 Nama: ${user.firstName}${user.lastName ? ' ' + user.lastName : ''}\n`;
    statusMessage += `🆔 ID: ${user.userId}\n`;
    statusMessage += `📅 Terdaftar: ${moment(user.createdAt).format('DD/MM/YYYY HH:mm')}\n\n`;
    
    if (user.isPremium && user.premiumUntil > new Date()) {
      const remaining = Math.ceil((user.premiumUntil - new Date()) / (1000 * 60 * 60 * 24));
      statusMessage += `🎖️ Status: *Premium*\n`;
      statusMessage += `⏰ Sisa waktu: ${remaining} hari\n`;
      statusMessage += `📅 Hingga: ${moment(user.premiumUntil).format('DD/MM/YYYY HH:mm')}\n`;
    } else {
      statusMessage += `🎖️ Status: *Regular*\n`;
      statusMessage += `💡 Tambahkan bot ke 3 grup untuk mendapatkan premium 3 hari gratis!\n`;
    }
    
    statusMessage += `\n📤 Total share: ${user.shareCount}`;
    
    await ctx.replyWithMarkdown(statusMessage);
  });
}

// Command untuk tourl (upload file ke uguu.se)
function setupToUrlCommand(bot) {
  bot.command('tourl', async (ctx) => {
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.reply('❌ Balas pesan yang berisi file dengan command ini');
    }
    
    const file = ctx.message.reply_to_message.document;
    const fileId = file.file_id;
    
    try {
      const progressMsg = await ctx.reply('📤 Mengupload file...');
      
      // Download file
      const fileLink = await ctx.telegram.getFileLink(fileId);
      const response = await fetch(fileLink);
      const buffer = await response.buffer();
      
      // Simpan file sementara
      const tempPath = path.join(__dirname, '..', 'temp', file.file_name);
      await fs.ensureDir(path.dirname(tempPath));
      await fs.writeFile(tempPath, buffer);
      
      // Upload ke uguu.se
      await ctx.telegram.editMessageText(
        progressMsg.chat.id,
        progressMsg.message_id,
        null,
        '📤 Mengupload file ke uguu.se...'
      );
      
      const fileUrl = await uploadToUguu(tempPath);
      
      // Hapus file sementara
      await fs.unlink(tempPath);
      
      if (fileUrl) {
        await ctx.telegram.editMessageText(
          progressMsg.chat.id,
          progressMsg.message_id,
          null,
          `✅ File berhasil diupload!\n\n🔗 URL: ${fileUrl}`
        );
      } else {
        await ctx.telegram.editMessageText(
          progressMsg.chat.id,
          progressMsg.message_id,
          null,
          '❌ Gagal mengupload file'
        );
      }
    } catch (error) {
      log('Error uploading file: ' + error.message);
      await ctx.reply('❌ Gagal mengupload file');
    }
  });
}

// Command untuk sharefree
function setupShareFreeCommand(bot) {
  bot.command('sharefree', groupNotBlacklisted, async (ctx) => {
    if (ctx.chat.type === 'private') {
      return ctx.reply('❌ Command ini hanya bisa digunakan di grup!');
    }
    
    const user = ctx.userData;
    
    // Cek apakah user sudah menambahkan bot ke 3 grup
    if (user.joinedGroups.length < 3 && !user.isPremium) {
      return ctx.reply(
        '⛔ Untuk menggunakan fitur share, Anda harus menambahkan bot ke 3 grup terlebih dahulu!\n' +
        'Gunakan /buyprem untuk membeli premium jika ingin menggunakan fitur share tanpa syarat.'
      );
    }
    
    if (!ctx.message.reply_to_message) {
      return ctx.reply('❌ Balas pesan yang ingin di-share dengan command ini');
    }
    
    try {
      // Simpan jumlah share
      user.shareCount += 1;
      await user.save();
      
      // Forward pesan ke grup
      await ctx.telegram.forwardMessage(
        ctx.chat.id,
        ctx.chat.id,
        ctx.message.reply_to_message.message_id
      );
      
      await ctx.reply('✅ Pesan berhasil di-share (Free)');
    } catch (error) {
      log('Error sharing message: ' + error.message);
      await ctx.reply('❌ Gagal share pesan');
    }
  });
}

// Command untuk sharevip
function setupShareVipCommand(bot) {
  bot.command('sharevip', groupNotBlacklisted, async (ctx) => {
    if (ctx.chat.type === 'private') {
      return ctx.reply('❌ Command ini hanya bisa digunakan di grup!');
    }
    
    const user = ctx.userData;
    
    // Hanya user premium yang bisa menggunakan sharevip
    if (!user.isPremium || (user.premiumUntil && user.premiumUntil < new Date())) {
      return ctx.reply('⛔ Fitur ini hanya untuk user premium!');
    }
    
    if (!ctx.message.reply_to_message) {
      return ctx.reply('❌ Balas pesan yang ingin di-share dengan command ini');
    }
    
    try {
      // Simpan jumlah share
      user.shareCount += 1;
      await user.save();
      
      // Copy pesan (bukan forward) untuk prioritas lebih tinggi
      const repliedMessage = ctx.message.reply_to_message;
      
      if (repliedMessage.text) {
        await ctx.telegram.sendMessage(ctx.chat.id, `📢 VIP Share:\n\n${repliedMessage.text}`, {
          reply_to_message_id: ctx.message.message_id
        });
      } else if (repliedMessage.photo) {
        await ctx.telegram.sendPhoto(ctx.chat.id, repliedMessage.photo[repliedMessage.photo.length - 1].file_id, {
          caption: repliedMessage.caption ? `📢 VIP Share:\n\n${repliedMessage.caption}` : '📢 VIP Share',
          reply_to_message_id: ctx.message.message_id
        });
      } else if (repliedMessage.document) {
        await ctx.telegram.sendDocument(ctx.chat.id, repliedMessage.document.file_id, {
          caption: repliedMessage.caption ? `📢 VIP Share:\n\n${repliedMessage.caption}` : '📢 VIP Share',
          reply_to_message_id: ctx.message.message_id
        });
      } else {
        await ctx.reply('❌ Jenis pesan tidak didukung untuk share VIP');
      }
      
      await ctx.reply('✅ Pesan berhasil di-share (VIP)');
    } catch (error) {
      log('Error sharing VIP message: ' + error.message);
      await ctx.reply('❌ Gagal share pesan VIP');
    }
  });
}

// Command untuk pengaturan grup (hanya admin)
function setupGroupSettingsCommands(bot) {
  // Antispam
  bot.command('antispam', async (ctx) => {
    if (ctx.chat.type === 'private') {
      return ctx.reply('❌ Command ini hanya bisa digunakan di grup!');
    }
    
    // Cek apakah pengguna adalah admin
    try {
      const member = await ctx.getChatMember(ctx.from.id);
      if (!['administrator', 'creator'].includes(member.status)) {
        return ctx.reply('⛔ Hanya admin yang bisa menggunakan command ini!');
      }
    } catch (error) {
      return ctx.reply('❌ Gagal memverifikasi status admin');
    }
    
    try {
      let group = await Group.findOne({ groupId: ctx.chat.id });
      if (!group) {
        group = new Group({
          groupId: ctx.chat.id,
          title: ctx.chat.title,
          username: ctx.chat.username
        });
      }
      
      group.settings.antispam = !group.settings.antispam;
      await group.save();
      
      await ctx.reply(`✅ Pengaturan antispam ${group.settings.antispam ? 'diaktifkan' : 'dinonaktifkan'}`);
    } catch (error) {
      log('Error toggling antispam: ' + error.message);
      await ctx.reply('❌ Gagal mengubah pengaturan antispam');
    }
  });
  
  // Noevent
  bot.command('noevent', async (ctx) => {
    if (ctx.chat.type === 'private') {
      return ctx.reply('❌ Command ini hanya bisa digunakan di grup!');
    }
    
    // Cek apakah pengguna adalah admin
    try {
      const member = await ctx.getChatMember(ctx.from.id);
      if (!['administrator', 'creator'].includes(member.status)) {
        return ctx.reply('⛔ Hanya admin yang bisa menggunakan command ini!');
      }
    } catch (error) {
      return ctx.reply('❌ Gagal memverifikasi status admin');
    }
    
    try {
      let group = await Group.findOne({ groupId: ctx.chat.id });
      if (!group) {
        group = new Group({
          groupId: ctx.chat.id,
          title: ctx.chat.title,
          username: ctx.chat.username
        });
      }
      
      group.settings.noevent = !group.settings.noevent;
      await group.save();
      
      await ctx.reply(`✅ Pengaturan noevent ${group.settings.noevent ? 'diaktifkan' : 'dinonaktifkan'}`);
    } catch (error) {
      log('Error toggling noevent: ' + error.message);
      await ctx.reply('❌ Gagal mengubah pengaturan noevent');
    }
  });
  
  // Nolinks
  bot.command('nolinks', async (ctx) => {
    if (ctx.chat.type === 'private') {
      return ctx.reply('❌ Command ini hanya bisa digunakan di grup!');
    }
    
    // Cek apakah pengguna adalah admin
    try {
      const member = await ctx.getChatMember(ctx.from.id);
      if (!['administrator', 'creator'].includes(member.status)) {
        return ctx.reply('⛔ Hanya admin yang bisa menggunakan command ini!');
      }
    } catch (error) {
      return ctx.reply('❌ Gagal memverifikasi status admin');
    }
    
    try {
      let group = await Group.findOne({ groupId: ctx.chat.id });
      if (!group) {
        group = new Group({
          groupId: ctx.chat.id,
          title: ctx.chat.title,
          username: ctx.chat.username
        });
      }
      
      group.settings.nolinks = !group.settings.nolinks;
      await group.save();
      
      await ctx.reply(`✅ Pengaturan nolinks ${group.settings.nolinks ? 'diaktifkan' : 'dinonaktifkan'}`);
    } catch (error) {
      log('Error toggling nolinks: ' + error.message);
      await ctx.reply('❌ Gagal mengubah pengaturan nolinks');
    }
  });
  
  // Noforwards
  bot.command('noforwards', async (ctx) => {
    if (ctx.chat.type === 'private') {
      return ctx.reply('❌ Command ini hanya bisa digunakan di grup!');
    }
    
    // Cek apakah pengguna adalah admin
    try {
      const member = await ctx.getChatMember(ctx.from.id);
      if (!['administrator', 'creator'].includes(member.status)) {
        return ctx.reply('⛔ Hanya admin yang bisa menggunakan command ini!');
      }
    } catch (error) {
      return ctx.reply('❌ Gagal memverifikasi status admin');
    }
    
    try {
      let group = await Group.findOne({ groupId: ctx.chat.id });
      if (!group) {
        group = new Group({
          groupId: ctx.chat.id,
          title: ctx.chat.title,
          username: ctx.chat.username
        });
      }
      
      group.settings.noforwards = !group.settings.noforwards;
      await group.save();
      
      await ctx.reply(`✅ Pengaturan noforwards ${group.settings.noforwards ? 'diaktifkan' : 'dinonaktifkan'}`);
    } catch (error) {
      log('Error toggling noforwards: ' + error.message);
      await ctx.reply('❌ Gagal mengubah pengaturan noforwards');
    }
  });
  
  // Nocontacts
  bot.command('nocontacts', async (ctx) => {
    if (ctx.chat.type === 'private') {
      return ctx.reply('❌ Command ini hanya bisa digunakan di grup!');
    }
    
    // Cek apakah pengguna adalah admin
    try {
      const member = await ctx.getChatMember(ctx.from.id);
      if (!['administrator', 'creator'].includes(member.status)) {
        return ctx.reply('⛔ Hanya admin yang bisa menggunakan command ini!');
      }
    } catch (error) {
      return ctx.reply('❌ Gagal memverifikasi status admin');
    }
    
    try {
      let group = await Group.findOne({ groupId: ctx.chat.id });
      if (!group) {
        group = new Group({
          groupId: ctx.chat.id,
          title: ctx.chat.title,
          username: ctx.chat.username
        });
      }
      
      group.settings.nocontacts = !group.settings.nocontacts;
      await group.save();
      
      await ctx.reply(`✅ Pengaturan nocontacts ${group.settings.nocontacts ? 'diaktifkan' : 'dinonaktifkan'}`);
    } catch (error) {
      log('Error toggling nocontacts: ' + error.message);
      await ctx.reply('❌ Gagal mengubah pengaturan nocontacts');
    }
  });
  
  // Nohashtags
  bot.command('nohashtags', async (ctx) => {
    if (ctx.chat.type === 'private') {
      return ctx.reply('❌ Command ini hanya bisa digunakan di grup!');
    }
    
    // Cek apakah pengguna adalah admin
    try {
      const member = await ctx.getChatMember(ctx.from.id);
      if (!['administrator', 'creator'].includes(member.status)) {
        return ctx.reply('⛔ Hanya admin yang bisa menggunakan command ini!');
      }
    } catch (error) {
      return ctx.reply('❌ Gagal memverifikasi status admin');
    }
    
    try {
      let group = await Group.findOne({ groupId: ctx.chat.id });
      if (!group) {
        group = new Group({
          groupId: ctx.chat.id,
          title: ctx.chat.title,
          username: ctx.chat.username
        });
      }
      
      group.settings.nohashtags = !group.settings.nohashtags;
      await group.save();
      
      await ctx.reply(`✅ Pengaturan nohashtags ${group.settings.nohashtags ? 'diaktifkan' : 'dinonaktifkan'}`);
    } catch (error) {
      log('Error toggling nohashtags: ' + error.message);
      await ctx.reply('❌ Gagal mengubah pengaturan nohashtags');
    }
  });
  
  // Nocommands
  bot.command('nocommands', async (ctx) => {
    if (ctx.chat.type === 'private') {
      return ctx.reply('❌ Command ini hanya bisa digunakan di grup!');
    }
    
    // Cek apakah pengguna adalah admin
    try {
      const member = await ctx.getChatMember(ctx.from.id);
      if (!['administrator', 'creator'].includes(member.status)) {
        return ctx.reply('⛔ Hanya admin yang bisa menggunakan command ini!');
      }
    } catch (error) {
      return ctx.reply('❌ Gagal memverifikasi status admin');
    }
    
    try {
      let group = await Group.findOne({ groupId: ctx.chat.id });
      if (!group) {
        group = new Group({
          groupId: ctx.chat.id,
          title: ctx.chat.title,
          username: ctx.chat.username
        });
      }
      
      group.settings.nocommands = !group.settings.nocommands;
      await group.save();
      
      await ctx.reply(`✅ Pengaturan nocommands ${group.settings.nocommands ? 'diaktifkan' : 'dinonaktifkan'}`);
    } catch (error) {
      log('Error toggling nocommands: ' + error.message);
      await ctx.reply('❌ Gagal mengubah pengaturan nocommands');
    }
  });
}

// Command untuk menghapus grup yang tidak aktif
function setupCleanGroupsCommand(bot) {
  bot.command('cleangroups', ownerOnly, async (ctx) => {
    try {
      const groups = await Group.find({ isActive: true });
      let removedCount = 0;
      
      await ctx.reply(`🔍 Memeriksa ${groups.length} grup...`);
      
      for (const group of groups) {
        try {
          // Cek apakah bot masih ada di grup
          await ctx.telegram.getChatAdministrators(group.groupId);
        } catch (error) {
          // Jika error, artinya bot sudah tidak ada di grup
          group.isActive = false;
          await group.save();
          removedCount++;
        }
        
        // Delay untuk menghindari limit
        await new Promise(resolve => setTimeout(resolve, 100));
      }
      
      await ctx.reply(`✅ Pembersihan selesai!\nDihapus: ${removedCount} grup tidak aktif`);
    } catch (error) {
      log('Error cleaning groups: ' + error.message);
      await ctx.reply('❌ Gagal membersihkan grup');
    }
  });
}

// Setup semua command
function setupAllCommands(bot) {
  setupStartCommand(bot);
  setupMenuCommand(bot);
  setupAddPremCommand(bot);
  setupDelPremCommand(bot);
  setupListPremCommand(bot);
  setupAddBlCommand(bot);
  setupDelBlCommand(bot);
  setupListBlCommand(bot);
  setupListGroupsCommand(bot);
  setupBcCommand(bot);
  setupBuyScCommand(bot);
  setupBuyPremCommand(bot);
  setupStatusCommand(bot);
  setupToUrlCommand(bot);
  setupShareFreeCommand(bot);
  setupShareVipCommand(bot);
  setupGroupSettingsCommands(bot);
  setupCleanGroupsCommand(bot);
}

module.exports = {
  setupAllCommands
};