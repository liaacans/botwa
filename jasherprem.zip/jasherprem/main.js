const { Telegraf, Markup } = require('telegraf');
const { connectDB } = require('./lib/database');
const { setupAllCommands } = require('./src/commands');
const { setupObfuscationCommands } = require('./src/obfuscation');
const { handleNewChatMembers, handleLeftChatMember, handleGroupMessage } = require('./src/groupManagement');
const { userMiddleware, premiumMiddleware } = require('./lib/middleware');
const { log, moment } = require('./lib/utils');
const { setBotInstance } = require('./src/paymentHandler');


// Load config
require('./config');

// Inisialisasi bot
const bot = new Telegraf(global.BOT_TOKEN);

// Koneksi database
connectDB();

// Middleware
bot.use(userMiddleware);
bot.use(handleGroupMessage);

// Setel instance bot di payment handler
setBotInstance(bot);

// Event handlers
bot.on('new_chat_members', handleNewChatMembers);
bot.on('left_chat_member', handleLeftChatMember);

// Setup commands
setupAllCommands(bot);
setupObfuscationCommands(bot);

// Handler error
bot.catch((err, ctx) => {
  log(`Error for ${ctx.updateType}: ${err.message}`);
  console.error(err);
});

// Start bot
bot.launch().then(() => {
  log('Bot started successfully');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));