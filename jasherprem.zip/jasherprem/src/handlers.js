const { Markup } = require('telegraf');
const { User, Group } = require('../lib/database');
const { ADMIN_ID } = require('../config');

async function handleCallbackQuery(ctx) {
    const data = ctx.callbackQuery.data;
    const userId = ctx.from.id;
    
    try {
        switch (data) {
            case 'jasher_menu':
                await ctx.editMessageText(
                    '🤖 <b>Jasher Menu</b>\n\n' +
                    '🔹 /credit - Cek kredit Anda\n' +
                    '🔹 /share - Share pesan (2 kredit)\n' +
                    '🔹 /sharevip - Share pesan premium (hanya premium)\n\n' +
                    'Untuk menambah kredit, tambahkan bot ke 3 group terlebih dahulu.',
                    { 
                        parse_mode: 'HTML',
                        ...Markup.inlineKeyboard([
                            [Markup.button.callback('Kembali', 'main_menu')]
                        ])
                    }
                );
                break;
                
            case 'owner_menu':
                if (userId.toString() !== ADMIN_ID) {
                    await ctx.answerCbQuery('Anda bukan owner!');
                    return;
                }
                
                await ctx.editMessageText(
                    '👑 <b>Owner Menu</b>\n\n' +
                    '🔹 /addprem [user_id] - Tambah user premium\n' +
                    '🔹 /delprem [user_id] - Hapus user premium\n' +
                    '🔹 /listprem - List user premium\n' +
                    '🔹 /broadcast - Broadcast ke semua user',
                    { 
                        parse_mode: 'HTML',
                        ...Markup.inlineKeyboard([
                            [Markup.button.callback('Kembali', 'main_menu')]
                        ])
                    }
                );
                break;
                
            case 'owner_info':
                await ctx.answerCbQuery(`Owner bot: @${ADMIN_ID}`);
                break;
                
            case 'main_menu':
                const user = await User.findOne({ userId });
                const isCreator = userId.toString() === ADMIN_ID;
                const { formatUserInfo } = require('./utils');
                
                const message = formatUserInfo(ctx, user, isCreator);
                
                await ctx.editMessageText(message, {
                    parse_mode: 'HTML',
                    ...Markup.inlineKeyboard([
                        [Markup.button.callback('Jasher Menu', 'jasher_menu')],
                        [Markup.button.callback('Owner Menu', 'owner_menu')],
                        [Markup.button.url('Add Group', 'https://t.me/your_bot_username?startgroup=true')],
                        [Markup.button.callback('Owner', 'owner_info')]
                    ])
                });
                break;
                
            default:
                await ctx.answerCbQuery('Menu tidak dikenali');
        }
    } catch (error) {
        console.error('Error handling callback query:', error);
        await ctx.answerCbQuery('Terjadi kesalahan');
    }
}

async function handleNewChatMembers(ctx) {
    try {
        // Jika bot yang ditambahkan ke group
        if (ctx.message.new_chat_members.some(member => member.is_bot && member.id === ctx.botInfo.id)) {
            const groupId = ctx.chat.id;
            const groupName = ctx.chat.title;
            const groupUsername = ctx.chat.username || '';
            
            // Simpan info group
            await Group.findOneAndUpdate(
                { groupId },
                { 
                    groupId,
                    groupName,
                    groupUsername,
                    memberCount: await ctx.getChatMembersCount(),
                    addedBy: ctx.from.id
                },
                { upsert: true }
            );
            
            // Tambahkan kredit untuk user yang menambahkan bot
            const addedByUser = await User.findOne({ userId: ctx.from.id });
            if (addedByUser) {
                // Cek apakah user sudah menambahkan group ini sebelumnya
                if (!addedByUser.joinedGroups.includes(groupId.toString())) {
                    addedByUser.joinedGroups.push(groupId.toString());
                    
                    // Beri 10 kredit jika sudah menambahkan 3 group
                    if (addedByUser.joinedGroups.length >= 3) {
                        addedByUser.credit += 10;
                        await addedByUser.save();
                        
                        // Kirim notifikasi ke user
                        await ctx.telegram.sendMessage(
                            ctx.from.id, 
                            `Terima kasih! Anda telah menambahkan bot ke 3 group. Anda mendapatkan 10 kredit. Total kredit: ${addedByUser.credit}`
                        );
                    } else {
                        await addedByUser.save();
                    }
                }
            }
            
            await ctx.reply('Terima kasih telah menambahkan saya ke group ini!');
        }
    } catch (error) {
        console.error('Error handling new chat members:', error);
    }
}

module.exports = {
    handleCallbackQuery,
    handleNewChatMembers
};