const { Markup } = require('telegraf');
const { User, Group } = require('../lib/database');
const { runtime, moment, isValidUrl } = require('./utils');

// Menu utama
async function mainMenu(ctx, userData) {
    const sender = ctx.from.first_name;
    const userTelelu = ctx.from.username ? `@${ctx.from.username}` : 'Tidak ada';
    const isCreator = ctx.from.id.toString() === process.env.OWNER_ID;
    
    const caption = `Hi kak @${sender}
╭─❒ 「 User Info 」 
├ Creator : @${userTelelu}
├ Name : ${ctx.from.first_name}${ctx.from.last_name ? ` ${ctx.from.last_name}` : ''}
├ Profile : @${ctx.from.username || 'Tidak ada'}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : VPS
├ Platform : Bot Telegram
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
├ Kredit : ${userData.credit}
├ Status : ${userData.isPremium ? 'Premium' : 'Regular'}
╰❒ Owner : ${isCreator ? 'True' : 'False'}

Silahkan pilih button dibawah ini!`;

    const buttons = Markup.inlineKeyboard([
        [Markup.button.callback('🎯 Jasher Menu', 'jasher_menu')],
        [Markup.button.callback('👤 Owner Menu', 'owner_menu'), Markup.button.callback('🔙 Kembali', 'main_menu')],
        [Markup.button.url('➕ Add Group', 'https://t.me/your_bot_username?startgroup=true')],
        [Markup.button.callback('👨‍💻 Owner', 'owner_info')]
    ]);

    if (ctx.message && ctx.message.text === '/start') {
        await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
            caption: caption,
            parse_mode: 'HTML',
            ...buttons
        });
    } else {
        await ctx.editMessageCaption(caption, {
            parse_mode: 'HTML',
            ...buttons
        });
    }
}

// Handle command start
async function handleStart(ctx) {
    try {
        // Cek atau buat user di database
        let user = await User.findOne({ userId: ctx.from.id });
        if (!user) {
            user = new User({
                userId: ctx.from.id,
                username: ctx.from.username,
                firstName: ctx.from.first_name,
                lastName: ctx.from.last_name
            });
            await user.save();
        }
        
        await mainMenu(ctx, user);
    } catch (error) {
        console.error('Error in handleStart:', error);
        ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

// Handle command help
async function handleHelp(ctx) {
    const helpText = `🤖 <b>Jasher Bot Help</b>

<b>Perintah yang tersedia:</b>
/start - Memulai bot
/help - Menampilkan bantuan
/credit - Mengecek kredit Anda
/share - Membagikan pesan (hanya di private chat)

<b>Cara mendapatkan kredit:</b>
1. Tambahkan bot ke 3 grup untuk mendapatkan 10 kredit
2. Setiap berbagi pesan mengurangi 2 kredit

<b>Fitur Premium:</b>
- ShareVIP untuk broadcast lebih cepat
- Prioritas pengiriman pesan

Hubungi owner untuk informasi premium.`;
    
    await ctx.reply(helpText, { parse_mode: 'HTML' });
}

// Handle command credit
async function handleCredit(ctx) {
    try {
        const user = await User.findOne({ userId: ctx.from.id });
        if (!user) {
            return ctx.reply('Anda belum terdaftar. Ketik /start untuk memulai.');
        }
        
        await ctx.reply(`💰 <b>Info Kredit</b>\n\nKredit Anda: ${user.credit}\nStatus: ${user.isPremium ? 'Premium' : 'Regular'}`, 
            { parse_mode: 'HTML' });
    } catch (error) {
        console.error('Error in handleCredit:', error);
        ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

// Handle command share
async function handleShare(ctx) {
    try {
        // Cek jika di group
        if (ctx.chat.type !== 'private') {
            return ctx.reply('❌ Perintah /share hanya dapat digunakan di private chat.');
        }
        
        const user = await User.findOne({ userId: ctx.from.id });
        if (!user) {
            return ctx.reply('Anda belum terdaftar. Ketik /start untuk memulai.');
        }
        
        // Cek kredit
        if (user.credit < 2 && !user.isPremium) {
            return ctx.reply(`❌ Kredit tidak cukup. Anda membutuhkan 2 kredit untuk berbagi pesan.\nKredit Anda: ${user.credit}`);
        }
        
        // Cek apakah ada pesan yang di-reply
        if (!ctx.message.reply_to_message) {
            return ctx.reply('❌ Balas pesan yang ingin Anda bagikan dengan perintah /share');
        }
        
        // Kurangi kredit untuk user regular
        if (!user.isPremium) {
            user.credit -= 2;
            await user.save();
        }
        
        // Broadcast pesan ke semua group
        const groups = await Group.find();
        let successCount = 0;
        
        for (const group of groups) {
            try {
                await ctx.telegram.copyMessage(group.groupId, ctx.chat.id, ctx.message.reply_to_message.message_id);
                successCount++;
            } catch (error) {
                console.error(`Error sending to group ${group.groupId}:`, error);
            }
        }
        
        await ctx.reply(`✅ Pesan berhasil dibagikan ke ${successCount} grup\n${!user.isPremium ? `Kredit berkurang 2, sisa: ${user.credit}` : 'Menggunakan fitur Premium (tanpa potongan kredit)'}`);
    } catch (error) {
        console.error('Error in handleShare:', error);
        ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

// Handle command sharevip (hanya untuk premium)
async function handleShareVip(ctx) {
    try {
        // Cek jika di group
        if (ctx.chat.type !== 'private') {
            return ctx.reply('❌ Perintah /sharevip hanya dapat digunakan di private chat.');
        }
        
        const user = await User.findOne({ userId: ctx.from.id });
        if (!user) {
            return ctx.reply('Anda belum terdaftar. Ketik /start untuk memulai.');
        }
        
        // Cek status premium
        if (!user.isPremium) {
            return ctx.reply('❌ Fitur ini hanya untuk user premium. Hubungi owner untuk upgrade.');
        }
        
        // Cek apakah ada pesan yang di-reply
        if (!ctx.message.reply_to_message) {
            return ctx.reply('❌ Balas pesan yang ingin Anda bagikan dengan perintah /sharevip');
        }
        
        // Broadcast pesan ke semua group (lebih cepat)
        const groups = await Group.find();
        let successCount = 0;
        
        // Menggunakan Promise.all untuk mempercepat pengiriman
        const sendPromises = groups.map(async (group) => {
            try {
                await ctx.telegram.copyMessage(group.groupId, ctx.chat.id, ctx.message.reply_to_message.message_id);
                successCount++;
                return true;
            } catch (error) {
                console.error(`Error sending to group ${group.groupId}:`, error);
                return false;
            }
        });
        
        await Promise.all(sendPromises);
        
        await ctx.reply(`✅ Pesan VIP berhasil dibagikan ke ${successCount} grup\nMenggunakan fitur Premium (tanpa potongan kredit)`);
    } catch (error) {
        console.error('Error in handleShareVip:', error);
        ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

// Handle command addprem (hanya owner)
async function handleAddPrem(ctx) {
    try {
        // Cek apakah owner
        if (ctx.from.id.toString() !== process.env.OWNER_ID) {
            return ctx.reply('❌ Perintah ini hanya untuk owner.');
        }
        
        // Cek apakah ada reply atau mention
        let targetUserId;
        if (ctx.message.reply_to_message) {
            targetUserId = ctx.message.reply_to_message.from.id;
        } else if (ctx.message.text.split(' ').length > 1) {
            targetUserId = parseInt(ctx.message.text.split(' ')[1]);
        }
        
        if (!targetUserId) {
            return ctx.reply('❌ Balas pesan user atau ketik /addprem <user_id>');
        }
        
        const user = await User.findOne({ userId: targetUserId });
        if (!user) {
            return ctx.reply('❌ User tidak ditemukan.');
        }
        
        user.isPremium = true;
        await user.save();
        
        await ctx.reply(`✅ User ${user.firstName} (${user.userId}) berhasil dijadikan premium.`);
        
        // Beri tahu user
        try {
            await ctx.telegram.sendMessage(targetUserId, '🎉 Selamat! Anda sekarang adalah user premium Jasher Bot.');
        } catch (error) {
            console.error('Cannot notify user:', error);
        }
    } catch (error) {
        console.error('Error in handleAddPrem:', error);
        ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

// Handle command delprem (hanya owner)
async function handleDelPrem(ctx) {
    try {
        // Cek apakah owner
        if (ctx.from.id.toString() !== process.env.OWNER_ID) {
            return ctx.reply('❌ Perintah ini hanya untuk owner.');
        }
        
        // Cek apakah ada reply atau mention
        let targetUserId;
        if (ctx.message.reply_to_message) {
            targetUserId = ctx.message.reply_to_message.from.id;
        } else if (ctx.message.text.split(' ').length > 1) {
            targetUserId = parseInt(ctx.message.text.split(' ')[1]);
        }
        
        if (!targetUserId) {
            return ctx.reply('❌ Balas pesan user atau ketik /delprem <user_id>');
        }
        
        const user = await User.findOne({ userId: targetUserId });
        if (!user) {
            return ctx.reply('❌ User tidak ditemukan.');
        }
        
        user.isPremium = false;
        await user.save();
        
        await ctx.reply(`✅ User ${user.firstName} (${user.userId}) berhasil dihapus dari premium.`);
        
        // Beri tahu user
        try {
            await ctx.telegram.sendMessage(targetUserId, 'ℹ️ Status premium Anda telah dihapus.');
        } catch (error) {
            console.error('Cannot notify user:', error);
        }
    } catch (error) {
        console.error('Error in handleDelPrem:', error);
        ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

// Handle command listprem (hanya owner)
async function handleListPrem(ctx) {
    try {
        // Cek apakah owner
        if (ctx.from.id.toString() !== process.env.OWNER_ID) {
            return ctx.reply('❌ Perintah ini hanya untuk owner.');
        }
        
        const premiumUsers = await User.find({ isPremium: true });
        
        if (premiumUsers.length === 0) {
            return ctx.reply('❌ Tidak ada user premium.');
        }
        
        let listText = '📋 <b>Daftar User Premium</b>\n\n';
        premiumUsers.forEach((user, index) => {
            listText += `${index + 1}. ${user.firstName}${user.lastName ? ` ${user.lastName}` : ''} (@${user.username || 'no_username'}) - ID: ${user.userId}\n`;
        });
        
        await ctx.reply(listText, { parse_mode: 'HTML' });
    } catch (error) {
        console.error('Error in handleListPrem:', error);
        ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

// Handle command broadcast (hanya owner)
async function handleBroadcast(ctx) {
    try {
        // Cek apakah owner
        if (ctx.from.id.toString() !== process.env.OWNER_ID) {
            return ctx.reply('❌ Perintah ini hanya untuk owner.');
        }
        
        // Cek apakah ada pesan yang di-reply
        if (!ctx.message.reply_to_message) {
            return ctx.reply('❌ Balas pesan yang ingin di-broadcast dengan perintah /broadcast');
        }
        
        const users = await User.find();
        let successCount = 0;
        
        for (const user of users) {
            try {
                await ctx.telegram.copyMessage(user.userId, ctx.chat.id, ctx.message.reply_to_message.message_id);
                successCount++;
            } catch (error) {
                console.error(`Error sending to user ${user.userId}:`, error);
            }
        }
        
        await ctx.reply(`✅ Broadcast berhasil dikirim ke ${successCount} user`);
    } catch (error) {
        console.error('Error in handleBroadcast:', error);
        ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

module.exports = {
    handleStart,
    handleHelp,
    handleCredit,
    handleShare,
    handleShareVip,
    handleAddPrem,
    handleDelPrem,
    handleListPrem,
    handleBroadcast,
    mainMenu
};