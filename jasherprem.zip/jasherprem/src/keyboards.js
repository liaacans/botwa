const { Markup } = require('telegraf');

function mainMenuKeyboard(isCreator = false) {
  const buttons = [
    [Markup.button.callback('🎯 Jasher Menu', 'jasher_menu')],
    [Markup.button.callback('👤 Owner Menu', 'owner_menu')],
    [Markup.button.url('➕ Add Group', 'https://t.me/your_bot_username?startgroup=true')],
    [Markup.button.callback('👨‍💻 Owner', 'owner_info')]
  ];
  
  if (isCreator) {
    buttons.splice(2, 0, [Markup.button.callback('⚙️ Admin Menu', 'admin_menu')]);
  }
  
  return Markup.inlineKeyboard(buttons);
}

function jasherMenuKeyboard() {
  return Markup.inlineKeyboard([
    [Markup.button.callback('📤 Share', 'share_menu')],
    [Markup.button.callback('💎 Credit', 'credit_info')],
    [Markup.button.callback('🔙 Kembali', 'main_menu')]
  ]);
}

function shareMenuKeyboard() {
  return Markup.inlineKeyboard([
    [Markup.button.callback('📤 Share Free', 'share_free')],
    [Markup.button.callback('🚀 Share VIP', 'share_vip')],
    [Markup.button.callback('🔙 Kembali', 'jasher_menu')]
  ]);
}

function adminMenuKeyboard() {
  return Markup.inlineKeyboard([
    [Markup.button.callback('📢 Broadcast', 'broadcast_menu')],
    [Markup.button.callback('⭐ Add Premium', 'add_premium')],
    [Markup.button.callback('🗑️ Remove Premium', 'remove_premium')],
    [Markup.button.callback('📋 List Premium', 'list_premium')],
    [Markup.button.callback('🔙 Kembali', 'main_menu')]
  ]);
}

function broadcastMenuKeyboard() {
  return Markup.inlineKeyboard([
    [Markup.button.callback('📢 Broadcast All', 'broadcast_all')],
    [Markup.button.callback('⭐ Broadcast Premium', 'broadcast_premium')],
    [Markup.button.callback('🔙 Kembali', 'admin_menu')]
  ]);
}

function backButton(target) {
  return Markup.inlineKeyboard([
    [Markup.button.callback('🔙 Kembali', target)]
  ]);
}

module.exports = {
  mainMenuKeyboard,
  jasherMenuKeyboard,
  shareMenuKeyboard,
  adminMenuKeyboard,
  broadcastMenuKeyboard,
  backButton
};