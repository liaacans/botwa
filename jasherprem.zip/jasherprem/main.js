require('./config');
const { Telegraf, session } = require('telegraf');
const { mongoose } = require('./lib/database');
const {
  handleStart,
  handleHelp,
  handleCredit,
  handleShare,
  handleShareVip,
  handleAddPrem,
  handleDelPrem,
  handleListPrem,
  handleBroadcast
} = require('./src/commands');
const {
  handleCallbackQuery,
  handleNewChatMembers
} = require('./src/handlers');

const bot = new Telegraf(global.BOT_TOKEN);

// Middleware
bot.use(session());

// Connect to MongoDB
mongoose.connect(global.MONGO_URL)
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('MongoDB connection error:', err));

// Command handlers
bot.command('start', handleStart);
bot.command('help', handleHelp);
bot.command('credit', handleCredit);
bot.command('share', handleShare);
bot.command('sharevip', handleShareVip);
bot.command('addprem', handleAddPrem);
bot.command('delprem', handleDelPrem);
bot.command('listprem', handleListPrem);
bot.command('broadcast', handleBroadcast);

// Event handlers
bot.on('callback_query', handleCallbackQuery);
bot.on('new_chat_members', handleNewChatMembers);

// Error handling
bot.catch((err, ctx) => {
  console.error(`Error for ${ctx.updateType}:`, err);
  ctx.reply('Terjadi kesalahan, silakan coba lagi.');
});

// Start bot
bot.launch().then(() => {
  console.log('Bot started successfully');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));