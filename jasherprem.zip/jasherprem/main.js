const { Telegraf, session } = require('telegraf');
require('./config');
const { loadPremiumUsers } = require('./lib/utils');
const { loadUserGroups, loadBlacklistedGroups } = require('./lib/database');
const handlers = require('./src/handlers');

// Load data
loadPremiumUsers();
loadUserGroups();
loadBlacklistedGroups();

// Inisialisasi bot
const bot = new Telegraf(BOT_TOKEN);

// Middleware session
bot.use(session());

// Command handlers
bot.start((ctx) => handlers.handleStart(ctx));
bot.command('tourl', (ctx) => {
    // Pastikan handler untuk tourl ada di handlers
    if (handlers.handleToUrl) {
        handlers.handleToUrl(ctx);
    } else {
        ctx.reply('Fitur tourl belum tersedia');
    }
});

// Event handlers
bot.on('new_chat_members', (ctx) => handlers.handleNewChatMembers(ctx));
bot.on('left_chat_member', (ctx) => handlers.handleLeftChatMember(ctx));
bot.on('callback_query', (ctx) => handlers.handleCallbackQuery(ctx));
bot.on('message', (ctx, next) => {
    if (ctx.message.reply_to_message) {
        handlers.handleReply(ctx);
    }
    next();
});

// Error handling
bot.catch((err, ctx) => {
    console.error(`Error for ${ctx.updateType}:`, err);
    ctx.reply('Terjadi error! Silahkan coba lagi.');
});

// Jalankan bot
bot.launch().then(() => {
    console.log('Bot Jasher Premium berhasil dijalankan!');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));