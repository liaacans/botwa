const { Markup } = require('telegraf');

const mainKeyboard = Markup.inlineKeyboard([
    [Markup.button.callback('➕ Join Grup', 'join_group')],
    [Markup.button.callback('📢 Share Pesan', 'share_message')],
    [Markup.button.callback('📊 Lihat Stats', 'stats')]
]);

const shareOptionsKeyboard = Markup.inlineKeyboard([
    [Markup.button.callback('❌ Batalkan', 'cancel_share')]
]);

module.exports = {
    mainKeyboard,
    shareOptionsKeyboard
};