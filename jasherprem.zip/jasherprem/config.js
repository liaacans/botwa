global.BOT_TOKEN = "8198305874:AAGhlBEYItkhH2mxD265kLIMXVEcWMiwkMM";
global.developer = "ginaabaikhati";
global.moment = require('moment-timezone');
global.JsConfuser = require('js-confuser');
global.fs = require('fs');
global.path = require('path');

// Database setup
global.db = require('./lib/database');

module.exports = {
    BOT_TOKEN: global.BOT_TOKEN,
    developer: global.developer
};