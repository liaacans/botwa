const { Markup } = require('telegraf');
const moment = require('moment-timezone');
const fs = require('fs-extra');
const path = require('path');
const fetch = require('node-fetch');
const { JsConfuser } = require('js-confuser');
const webcrack = require('webcrack');

const { User, Group, Blacklist, Payment } = require('../lib/database');
const { updateProgress, log, createProgressBar } = require('../lib/utils');
const { 
  obfuscateTimeLocked,
  obfuscateQuantum,
  getSiuCalcrickObfuscationConfig,
  getCustomObfuscationConfig,
  getNebulaObfuscationConfig,
  getNovaObfuscationConfig,
  getStrongObfuscationConfig,
  getArabObfuscationConfig,
  getJapanxArabObfuscationConfig,
  getJapanObfuscationConfig
} = require('../lib/obfuscators');

// Command untuk menampilkan help
async function helpCommand(ctx) {
  try {
    const helpText = `
╭─❒ 「 Bantuan 」 
├ /start - Memulai bot
├ /help - Menampilkan bantuan
├ /profile - Profile user
├ /buyprem - Beli premium
├ /mysc - Lihat script saya
├ /sharefree - Share free (harus tambah bot ke 3 grup)
├ /sharevip - Share VIP (hanya premium)
├ /tourl - Upload file ke URL
├ /status - Status bot
╰❒

╭─❒ 「 Obfuscation Commands 」 
├ /enc [hari] - Time-Locked Encryption
├ /enc2 [nama] - Custom Encryption
├ /enc3 - Mandarin Encryption
├ /enc4 - Arab Encryption
├ /enc5 - Siu+Calcrick Encryption
├ /japan - Japan Encryption
├ /nebula - Nebula Encryption
├ /quantum - Quantum Encryption
├ /var - Var Encryption
├ /zenc - Invisible Encryption
├ /deobfuscate - Deobfuscate
╰❒

╭─❒ 「 Owner Commands 」 
├ /addbl [user_id] - Tambahkan blacklist
├ /delbl [user_id] - Hapus blacklist
├ /listbl - List blacklist
├ /addprem [user_id] [hari] - Tambahkan premium
├ /delprem [user_id] - Hapus premium
├ /listprem - List premium
├ /bc [pesan] - Broadcast ke semua user
├ /stats - Statistik bot
├ /listgroup - List grup
├ /gb - Hapus grup tidak aktif
╰❒

╭─❒ 「 Group Admin Commands 」 
├ /antispam [on/off] - Aktifkan/nonaktifkan antispam
├ /noevent [on/off] - Aktifkan/nonaktifkan no event
├ /nolinks [on/off] - Aktifkan/nonaktifkan no links
├ /noforwards [on/off] - Aktifkan/nonaktifkan no forwards
├ /nocontacts [on/off] - Aktifkan/nonaktifkan no contacts
├ /nohastags [on/off] - Aktifkan/nonaktifkan no hashtags
├ /nocommands [on/off] - Aktifkan/nonaktifkan no commands
╰❒
    `;
    
    await ctx.reply(helpText);
  } catch (error) {
    console.error('Help command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk menampilkan status bot
async function statusCommand(ctx) {
  try {
    const usersCount = await User.countDocuments();
    const groupsCount = await Group.countDocuments({ isActive: true });
    const premiumUsersCount = await User.countDocuments({ 
      isPremium: true, 
      premiumUntil: { $gt: new Date() } 
    });
    
    const statusText = `
╭─❒ 「 Bot Status 」 
├ Pengguna: ${usersCount}
├ Grup aktif: ${groupsCount}
├ Premium: ${premiumUsersCount}
├ Runtime: ${require('../lib/utils').runtime(process.uptime())}
├ Tanggal: ${moment().tz('Asia/Jakarta').format('DD/MM/YYYY')}
├ Waktu: ${moment().tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒
    `;
    
    await ctx.reply(statusText);
  } catch (error) {
    console.error('Status command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk menampilkan script user
async function myscCommand(ctx) {
  try {
    const user = ctx.user;
    // Implementasi untuk menampilkan script user
    await ctx.reply('📜 Fitur ini dalam pengembangan');
  } catch (error) {
    console.error('Mysc command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk owner: menambahkan blacklist
async function addblCommand(ctx) {
  try {
    const args = ctx.message.text.split(' ').slice(1);
    if (args.length < 1) {
      return ctx.reply('❌ Gunakan: /addbl [user_id] [alasan]');
    }
    
    const userId = parseInt(args[0]);
    const reason = args.slice(1).join(' ') || 'Tidak ada alasan';
    
    if (isNaN(userId)) {
      return ctx.reply('❌ User ID harus angka');
    }
    
    // Cek apakah user sudah di blacklist
    const existing = await Blacklist.findOne({ userId });
    if (existing) {
      return ctx.reply('❌ User sudah ada di blacklist');
    }
    
    // Dapatkan info user
    let userInfo;
    try {
      userInfo = await ctx.telegram.getChat(userId);
    } catch (error) {
      userInfo = { username: 'Tidak diketahui', first_name: 'Tidak diketahui' };
    }
    
    // Tambahkan ke blacklist
    const blacklist = new Blacklist({
      userId,
      username: userInfo.username || 'Tidak diketahui',
      reason,
      bannedBy: ctx.from.id
    });
    await blacklist.save();
    
    await ctx.reply(`✅ User @${userInfo.username || userId} telah ditambahkan ke blacklist\nAlasan: ${reason}`);
  } catch (error) {
    console.error('Addbl command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk owner: menghapus blacklist
async function delblCommand(ctx) {
  try {
    const args = ctx.message.text.split(' ').slice(1);
    if (args.length < 1) {
      return ctx.reply('❌ Gunakan: /delbl [user_id]');
    }
    
    const userId = parseInt(args[0]);
    if (isNaN(userId)) {
      return ctx.reply('❌ User ID harus angka');
    }
    
    // Hapus dari blacklist
    const result = await Blacklist.findOneAndDelete({ userId });
    
    if (result) {
      await ctx.reply(`✅ User ${userId} telah dihapus dari blacklist`);
    } else {
      await ctx.reply('❌ User tidak ditemukan di blacklist');
    }
  } catch (error) {
    console.error('Delbl command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk owner: menampilkan list blacklist
async function listblCommand(ctx) {
  try {
    const blacklists = await Blacklist.find().sort({ bannedAt: -1 }).limit(50);
    
    if (blacklists.length === 0) {
      return ctx.reply('✅ Tidak ada user yang di-blacklist');
    }
    
    let listText = '╭─❒ 「 Blacklist Users 」 \n';
    for (const bl of blacklists) {
      listText += `├ ${bl.userId} - @${bl.username} - ${bl.reason}\n`;
    }
    listText += '╰❒';
    
    // Jika teks terlalu panjang, bagi menjadi beberapa pesan
    if (listText.length > 4096) {
      const parts = [];
      while (listText.length > 0) {
        parts.push(listText.substring(0, 4096));
        listText = listText.substring(4096);
      }
      
      for (const part of parts) {
        await ctx.reply(part);
      }
    } else {
      await ctx.reply(listText);
    }
  } catch (error) {
    console.error('Listbl command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk owner: menambahkan premium
async function addpremCommand(ctx) {
  try {
    const args = ctx.message.text.split(' ').slice(1);
    if (args.length < 2) {
      return ctx.reply('❌ Gunakan: /addprem [user_id] [hari]');
    }
    
    const userId = parseInt(args[0]);
    const days = parseInt(args[1]);
    
    if (isNaN(userId) || isNaN(days)) {
      return ctx.reply('❌ User ID dan hari harus angka');
    }
    
    if (days < 1 || days > 365) {
      return ctx.reply('❌ Hari harus antara 1-365');
    }
    
    // Cari user
    const user = await User.findOne({ userId });
    if (!user) {
      return ctx.reply('❌ User tidak ditemukan');
    }
    
    // Update premium
    user.isPremium = true;
    user.premiumUntil = new Date(Date.now() + days * 24 * 60 * 60 * 1000);
    await user.save();
    
    // Coba kirim notifikasi ke user
    try {
      await ctx.telegram.sendMessage(userId, `🎉 Selamat! Anda mendapatkan premium selama ${days} hari dari owner.`);
    } catch (error) {
      console.error('Gagal mengirim notifikasi ke user:', error);
    }
    
    await ctx.reply(`✅ User ${userId} mendapatkan premium selama ${days} hari`);
  } catch (error) {
    console.error('Addprem command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk owner: menghapus premium
async function delpremCommand(ctx) {
  try {
    const args = ctx.message.text.split(' ').slice(1);
    if (args.length < 1) {
      return ctx.reply('❌ Gunakan: /delprem [user_id]');
    }
    
    const userId = parseInt(args[0]);
    if (isNaN(userId)) {
      return ctx.reply('❌ User ID harus angka');
    }
    
    // Cari user
    const user = await User.findOne({ userId });
    if (!user) {
      return ctx.reply('❌ User tidak ditemukan');
    }
    
    // Hapus premium
    user.isPremium = false;
    user.premiumUntil = null;
    await user.save();
    
    await ctx.reply(`✅ Premium user ${userId} telah dihapus`);
  } catch (error) {
    console.error('Delprem command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk owner: menampilkan list premium
async function listpremCommand(ctx) {
  try {
    const premiumUsers = await User.find({ 
      isPremium: true, 
      premiumUntil: { $gt: new Date() } 
    }).sort({ premiumUntil: -1 });
    
    if (premiumUsers.length === 0) {
      return ctx.reply('✅ Tidak ada user premium');
    }
    
    let listText = '╭─❒ 「 Premium Users 」 \n';
    for (const user of premiumUsers) {
      const remaining = Math.ceil((user.premiumUntil - new Date()) / (1000 * 60 * 60 * 24));
      listText += `├ ${user.userId} - @${user.username || 'Tidak ada'} - ${remaining} hari lagi\n`;
    }
    listText += '╰❒';
    
    // Jika teks terlalu panjang, bagi menjadi beberapa pesan
    if (listText.length > 4096) {
      const parts = [];
      while (listText.length > 0) {
        parts.push(listText.substring(0, 4096));
        listText = listText.substring(4096);
      }
      
      for (const part of parts) {
        await ctx.reply(part);
      }
    } else {
      await ctx.reply(listText);
    }
  } catch (error) {
    console.error('Listprem command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk owner: broadcast ke semua user
async function bcCommand(ctx) {
  try {
    const message = ctx.message.text.split(' ').slice(1).join(' ');
    if (!message) {
      return ctx.reply('❌ Gunakan: /bc [pesan]');
    }
    
    const users = await User.find();
    let successCount = 0;
    let failCount = 0;
    
    await ctx.reply(`📢 Mengirim broadcast ke ${users.length} user...`);
    
    for (const user of users) {
      try {
        await ctx.telegram.sendMessage(user.userId, `📢 *Broadcast dari Owner*\n\n${message}`, {
          parse_mode: 'Markdown'
        });
        successCount++;
        
        // Tunggu sebentar agar tidak spam
        await new Promise(resolve => setTimeout(resolve, 100));
      } catch (error) {
        failCount++;
        console.error(`Gagal mengirim ke user ${user.userId}:`, error.message);
      }
    }
    
    await ctx.reply(`✅ Broadcast selesai!\nBerhasil: ${successCount}\nGagal: ${failCount}`);
  } catch (error) {
    console.error('Bc command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk owner: statistik bot
async function statsCommand(ctx) {
  try {
    const usersCount = await User.countDocuments();
    const groupsCount = await Group.countDocuments({ isActive: true });
    const premiumUsersCount = await User.countDocuments({ 
      isPremium: true, 
      premiumUntil: { $gt: new Date() } 
    });
    const blacklistCount = await Blacklist.countDocuments();
    const paymentsCount = await Payment.countDocuments();
    const successPayments = await Payment.countDocuments({ status: 'success' });
    
    const statsText = `
╭─❒ 「 Bot Statistics 」 
├ Total Users: ${usersCount}
├ Active Groups: ${groupsCount}
├ Premium Users: ${premiumUsersCount}
├ Blacklisted Users: ${blacklistCount}
├ Total Payments: ${paymentsCount}
├ Success Payments: ${successPayments}
├ Revenue: Rp ${(successPayments * 50000).toLocaleString('id-ID')}
╰❒
    `;
    
    await ctx.reply(statsText);
  } catch (error) {
    console.error('Stats command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk owner: list grup
async function listgroupCommand(ctx) {
  try {
    const groups = await Group.find({ isActive: true }).sort({ addedAt: -1 });
    
    if (groups.length === 0) {
      return ctx.reply('✅ Tidak ada grup aktif');
    }
    
    let listText = '╭─❒ 「 Active Groups 」 \n';
    for (const group of groups) {
      listText += `├ ${group.groupId} - ${group.title} - @${group.username || 'Tidak ada'}\n`;
    }
    listText += '╰❒';
    
    // Jika teks terlalu panjang, bagi menjadi beberapa pesan
    if (listText.length > 4096) {
      const parts = [];
      while (listText.length > 0) {
        parts.push(listText.substring(0, 4096));
        listText = listText.substring(4096);
      }
      
      for (const part of parts) {
        await ctx.reply(part);
      }
    } else {
      await ctx.reply(listText);
    }
  } catch (error) {
    console.error('Listgroup command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk owner: hapus grup tidak aktif
async function gbCommand(ctx) {
  try {
    // Hapus grup yang tidak aktif (isActive: false)
    const result = await Group.deleteMany({ isActive: false });
    
    await ctx.reply(`✅ ${result.deletedCount} grup tidak aktif telah dihapus`);
  } catch (error) {
    console.error('Gb command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk admin grup: antispam
async function antispamCommand(ctx) {
  try {
    const args = ctx.message.text.split(' ').slice(1);
    if (args.length < 1) {
      return ctx.reply('❌ Gunakan: /antispam [on/off]');
    }
    
    const action = args[0].toLowerCase();
    if (action !== 'on' && action !== 'off') {
      return ctx.reply('❌ Gunakan: /antispam [on/off]');
    }
    
    const groupId = ctx.chat.id;
    const group = await Group.findOne({ groupId });
    
    if (!group) {
      return ctx.reply('❌ Grup tidak terdaftar');
    }
    
    group.settings.antispam = action === 'on';
    await group.save();
    
    await ctx.reply(`✅ Anti-spam ${action === 'on' ? 'diaktifkan' : 'dinonaktifkan'}`);
  } catch (error) {
    console.error('Antispam command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk admin grup: noevent
async function noeventCommand(ctx) {
  try {
    const args = ctx.message.text.split(' ').slice(1);
    if (args.length < 1) {
      return ctx.reply('❌ Gunakan: /noevent [on/off]');
    }
    
    const action = args[0].toLowerCase();
    if (action !== 'on' && action !== 'off') {
      return ctx.reply('❌ Gunakan: /noevent [on/off]');
    }
    
    const groupId = ctx.chat.id;
    const group = await Group.findOne({ groupId });
    
    if (!group) {
      return ctx.reply('❌ Grup tidak terdaftar');
    }
    
    group.settings.noevent = action === 'on';
    await group.save();
    
    await ctx.reply(`✅ No event ${action === 'on' ? 'diaktifkan' : 'dinonaktifkan'}`);
  } catch (error) {
    console.error('Noevent command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk admin grup: nolinks
async function nolinksCommand(ctx) {
  try {
    const args = ctx.message.text.split(' ').slice(1);
    if (args.length < 1) {
      return ctx.reply('❌ Gunakan: /nolinks [on/off]');
    }
    
    const action = args[0].toLowerCase();
    if (action !== 'on' && action !== 'off') {
      return ctx.reply('❌ Gunakan: /nolinks [on/off]');
    }
    
    const groupId = ctx.chat.id;
    const group = await Group.findOne({ groupId });
    
    if (!group) {
      return ctx.reply('❌ Grup tidak terdaftar');
    }
    
    group.settings.nolinks = action === 'on';
    await group.save();
    
    await ctx.reply(`✅ No links ${action === 'on' ? 'diaktifkan' : 'dinonaktifkan'}`);
  } catch (error) {
    console.error('Nolinks command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk admin grup: noforwards
async function noforwardsCommand(ctx) {
  try {
    const args = ctx.message.text.split(' ').slice(1);
    if (args.length < 1) {
      return ctx.reply('❌ Gunakan: /noforwards [on/off]');
    }
    
    const action = args[0].toLowerCase();
    if (action !== 'on' && action !== 'off') {
      return ctx.reply('❌ Gunakan: /noforwards [on/off]');
    }
    
    const groupId = ctx.chat.id;
    const group = await Group.findOne({ groupId });
    
    if (!group) {
      return ctx.reply('❌ Grup tidak terdaftar');
    }
    
    group.settings.noforwards = action === 'on';
    await group.save();
    
    await ctx.reply(`✅ No forwards ${action === 'on' ? 'diaktifkan' : 'dinonaktifkan'}`);
  } catch (error) {
    console.error('Noforwards command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk admin grup: nocontacts
async function nocontactsCommand(ctx) {
  try {
    const args = ctx.message.text.split(' ').slice(1);
    if (args.length < 1) {
      return ctx.reply('❌ Gunakan: /nocontacts [on/off]');
    }
    
    const action = args[0].toLowerCase();
    if (action !== 'on' && action !== 'off') {
      return ctx.reply('❌ Gunakan: /nocontacts [on/off]');
    }
    
    const groupId = ctx.chat.id;
    const group = await Group.findOne({ groupId });
    
    if (!group) {
      return ctx.reply('❌ Grup tidak terdaftar');
    }
    
    group.settings.nocontacts = action === 'on';
    await group.save();
    
    await ctx.reply(`✅ No contacts ${action === 'on' ? 'diaktifkan' : 'dinonaktifkan'}`);
  } catch (error) {
    console.error('Nocontacts command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk admin grup: nohastags
async function nohastagsCommand(ctx) {
  try {
    const args = ctx.message.text.split(' ').slice(1);
    if (args.length < 1) {
      return ctx.reply('❌ Gunakan: /nohastags [on/off]');
    }
    
    const action = args[0].toLowerCase();
    if (action !== 'on' && action !== 'off') {
      return ctx.reply('❌ Gunakan: /nohastags [on/off]');
    }
    
    const groupId = ctx.chat.id;
    const group = await Group.findOne({ groupId });
    
    if (!group) {
      return ctx.reply('❌ Grup tidak terdaftar');
    }
    
    group.settings.nohastags = action === 'on';
    await group.save();
    
    await ctx.reply(`✅ No hashtags ${action === 'on' ? 'diaktifkan' : 'dinonaktifkan'}`);
  } catch (error) {
    console.error('Nohastags command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk admin grup: nocommands
async function nocommandsCommand(ctx) {
  try {
    const args = ctx.message.text.split(' ').slice(1);
    if (args.length < 1) {
      return ctx.reply('❌ Gunakan: /nocommands [on/off]');
    }
    
    const action = args[0].toLowerCase();
    if (action !== 'on' && action !== 'off') {
      return ctx.reply('❌ Gunakan: /nocommands [on/off]');
    }
    
    const groupId = ctx.chat.id;
    const group = await Group.findOne({ groupId });
    
    if (!group) {
      return ctx.reply('❌ Grup tidak terdaftar');
    }
    
    group.settings.nocommands = action === 'on';
    await group.save();
    
    await ctx.reply(`✅ No commands ${action === 'on' ? 'diaktifkan' : 'dinonaktifkan'}`);
  } catch (error) {
    console.error('Nocommands command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk obfuscation: enc (Time-Locked Encryption)
async function encCommand(ctx) {
  try {
    const args = ctx.message.text.split(' ').slice(1);
    if (args.length !== 1 || !/^\d+$/.test(args[0]) || parseInt(args[0]) < 1 || parseInt(args[0]) > 365) {
      return ctx.replyWithMarkdown("❌ *Error:* Gunakan format `/enc [1-365]` untuk jumlah hari (misal: `/enc 7`)!");
    }

    const days = args[0];
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + parseInt(days));
    const expiryFormatted = expiryDate.toLocaleDateString();

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc [1-365]`!");
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, '../temp', `locked-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
        "🔒 EncryptBot\n" +
        " ⚙️ Memulai (Time-Locked Encryption) (1%)\n" +
        " " + createProgressBar(1) + "\n" +
        "```\n" +
        "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Time-Locked Encryption: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan Time-Locked Encryption`);
      await updateProgress(ctx, progressMessage, 40, "Inisialisasi Time-Locked Encryption");
      const obfuscatedCode = await obfuscateTimeLocked(fileContent, days);
      log(`Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(0, 50)}...`);
      log(`Ukuran file setelah obfuscation: ${Buffer.byteLength(obfuscatedCode, "utf-8")} bytes`);

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscatedCode);
      } catch (postObfuscationError) {
        log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
        throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
      }

      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscatedCode);

      log(`Mengirim file terenkripsi time-locked: ${file.file_name}`);
      await ctx.replyWithMarkdown(
        `✅ *File terenkripsi (Time-Locked Encryption) siap!*\n` +
        `⏰ Masa aktif: ${days} hari (Kedaluwarsa: ${expiryFormatted})\n` +
        `_Powered by Ginaa_`,
        { parse_mode: "Markdown" }
      );
      await ctx.replyWithDocument({
        source: encryptedPath,
        filename: `locked-encrypted-${file.file_name}`,
      });
      await updateProgress(ctx, progressMessage, 100, "Time-Locked Encryption Selesai");

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Time-Locked obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  } catch (error) {
    console.error('Enc command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk obfuscation: enc2 (Custom Encryption)
async function enc2Command(ctx) {
  try {
    const customString = ctx.message.text.split(' ')[1];

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc2 <text>`!");
    }

    if (!customString) {
      return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc2 <text>`!");
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, '../temp', `custom-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
        "🔒 EncryptBot\n" +
        " ⚙️ Memulai (custom enc) (1%)\n" +
        " " + createProgressBar(1) + "\n" +
        "```\n" +
        "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk custom obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya custom (${customString})`);
      await updateProgress(ctx, progressMessage, 40, `Inisialisasi custom (${customString})`);

      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getCustomObfuscationConfig(customString)
      );

      let obfuscatedCode = obfuscated.code || obfuscated;
      if (typeof obfuscatedCode !== "string") {
        throw new Error("Hasil obfuscation bukan string");
      }
      log(`Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(0, 50)}...`);
      log(`Ukuran file setelah obfuscation: ${Buffer.byteLength(obfuscatedCode, "utf-8")} bytes`);

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscatedCode);
      } catch (postObfuscationError) {
        log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
        throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
      }

      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscatedCode);

      log(`Mengirim file terenkripsi gaya custom (${customString}): ${file.file_name}`);
      await ctx.replyWithDocument(
        {
          source: encryptedPath,
          filename: `custom-encrypted-${file.file_name}`,
        },
        {
          caption: `✅ *File terenkripsi custom (${customString}) siap!*\nSUKSES ENCRYPT 🕊`,
          parse_mode: "Markdown",
        }
      );
      await updateProgress(ctx, progressMessage, 100, `custom (${customString}) Selesai`);

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat custom enc obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  } catch (error) {
    console.error('Enc2 command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk obfuscation: enc3 (Mandarin Encryption)
async function enc3Command(ctx) {
  try {
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown(`
╭━━━「 ❌ ERROR 」━━━⬣
│ Terjadi kesalahan saat
│ memproses file!
╰━━━━━━━━━━━━━━━━⬣`);
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown(`
╭━━━「 ❌ ERROR 」━━━⬣
│ File harus berekstensi .js!
╰━━━━━━━━━━━━━━━━⬣`);
    }

    const encryptedPath = path.join(__dirname, '../temp', `china-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
        "🔒 EncryptBot\n" +
        ` ⚙️ Memulai (Hardened Mandarin) (1%)\n` +
        ` ${createProgressBar(1)}\n` +
        "```\n" +
        "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Mandarin obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Mandarin yang diperkuat`);
      await updateProgress(ctx, progressMessage, 40, "Inisialisasi Hardened Mandarin Obfuscation");
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getMandarinObfuscationConfig()
      );
      await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
      await fs.writeFile(encryptedPath, obfuscated.code);
      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscated.code);
      } catch (postObfuscationError) {
        throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
      }

      log(`Mengirim file terenkripsi gaya Mandarin: ${file.file_name}`);
      await ctx.replyWithDocument(
        { source: encryptedPath, filename: `china-encrypted-${file.file_name}` },
        {
          caption: "✅ *File terenkripsi (Hardened Mandarin) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(ctx, progressMessage, 100, "Hardened Mandarin Obfuscation Selesai");

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Mandarin obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  } catch (error) {
    console.error('Enc3 command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk obfuscation: enc4 (Arab Encryption)
async function enc4Command(ctx) {
  try {
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc4`!");
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, '../temp', `arab-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
        "🔒 EncryptBot\n" +
        ` ⚙️ Memulai (Hardened Arab) (1%)\n` +
        ` ${createProgressBar(1)}\n` +
        "```\n" +
        "PROSES ENCRYPT"
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Arab obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Arab yang diperkuat`);
      await updateProgress(ctx, progressMessage, 40, "Inisialisasi Hardened Arab Obfuscation");
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getArabObfuscationConfig()
      );
      await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
      await fs.writeFile(encryptedPath, obfuscated.code);
      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscated.code);
      } catch (postObfuscationError) {
        throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
      }

      log(`Mengirim file terenkripsi gaya Arab: ${file.file_name}`);
      await ctx.replyWithDocument(
        { source: encryptedPath, filename: `arab-encrypted-${file.file_name}` },
        {
          caption: "✅ *File terenkripsi (Hardened Arab) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(ctx, progressMessage, 100, "Hardened Arab Obfuscation Selesai");

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Arab obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  } catch (error) {
    console.error('Enc4 command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk obfuscation: enc5 (Siu+Calcrick Encryption)
async function enc5Command(ctx) {
  try {
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc5`!");
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, '../temp', `siucalcrick-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
        "🔒 EncryptBot\n" +
        " ⚙️ Memulai (Calcrick Chaos Core) (1%)\n" +
        " " + createProgressBar(1) + "\n" +
        "```\n" +
        "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Siu+Calcrick obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Siu+Calcrick`);
      await updateProgress(ctx, progressMessage, 40, "Inisialisasi Calcrick Chaos Core");
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getSiuCalcrickObfuscationConfig()
      );
      let obfuscatedCode = obfuscated.code || obfuscated;
      if (typeof obfuscatedCode !== "string") {
        throw new Error("Hasil obfuscation bukan string");
      }
      log(`Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(0, 50)}...`);
      log(`Ukuran file setelah obfuscation: ${Buffer.byteLength(obfuscatedCode, "utf-8")} bytes`);

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscatedCode);
      } catch (postObfuscationError) {
        log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
        throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
      }

      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscatedCode);

      log(`Mengirim file terenkripsi gaya Siu+Calcrick: ${file.file_name}`);
      await ctx.replyWithDocument(
        {
          source: encryptedPath,
          filename: `siucalcrick-encrypted-${file.file_name}`,
        },
        {
          caption: "✅ *File terenkripsi (Calcrick Chaos Core) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(ctx, progressMessage, 100, "Calcrick Chaos Core Selesai");

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Siu+Calcrick obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  } catch (error) {
    console.error('Enc5 command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk obfuscation: japan (Japan Encryption)
async function japanCommand(ctx) {
  try {
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/japan`!");
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, '../temp', `japan-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
        "🔒 EncryptBot\n" +
        ` ⚙️ Memulai (Hardened Japan) (1%)\n` +
        ` ${createProgressBar(1)}\n` +
        "```\n" +
        "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Japan obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Japan yang diperkuat`);
      await updateProgress(ctx, progressMessage, 40, "Inisialisasi Hardened Japan Obfuscation");
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getJapanObfuscationConfig()
      );
      await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");
      await fs.writeFile(encryptedPath, obfuscated.code);
      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscated.code);
      } catch (postObfuscationError) {
        throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
      }

      log(`Mengirim file terenkripsi gaya Japan: ${file.file_name}`);
      await ctx.replyWithDocument(
        { source: encryptedPath, filename: `japan-encrypted-${file.file_name}` },
        {
          caption: "✅ *File terenkripsi (Hardened Japan) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(ctx, progressMessage, 100, "Hardened Japan Obfuscation Selesai");

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Japan obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  } catch (error) {
    console.error('Japan command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk obfuscation: nebula (Nebula Encryption)
async function nebulaCommand(ctx) {
  try {
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/nebula`!");
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, '../temp', `nebula-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
        "🔒 EncryptBot\n" +
        " ⚙️ Memulai (Nebula Polymorphic Storm) (1%)\n" +
        " " + createProgressBar(1) + "\n" +
        "```\n" +
        "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Nebula obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Nebula`);
      await updateProgress(ctx, progressMessage, 40, "Inisialisasi Nebula Polymorphic Storm");
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getNebulaObfuscationConfig()
      );
      let obfuscatedCode = obfuscated.code || obfuscated;
      if (typeof obfuscatedCode !== "string") {
        throw new Error("Hasil obfuscation bukan string");
      }
      log(`Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(0, 50)}...`);
      log(`Ukuran file setelah obfuscation: ${Buffer.byteLength(obfuscatedCode, "utf-8")} bytes`);

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscatedCode);
      } catch (postObfuscationError) {
        log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
        throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
      }

      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscatedCode);

      log(`Mengirim file terenkripsi gaya Nebula: ${file.file_name}`);
      await ctx.replyWithDocument(
        { source: encryptedPath, filename: `nebula-encrypted-${file.file_name}` },
        {
          caption: "✅ *File terenkripsi (Nebula Polymorphic Storm) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(ctx, progressMessage, 100, "Nebula Polymorphic Storm Selesai");

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Nebula obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  } catch (error) {
    console.error('Nebula command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk obfuscation: quantum (Quantum Encryption)
async function quantumCommand(ctx) {
  try {
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/quantum`!");
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, '../temp', `quantum-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
        "🔒 EncryptBot\n" +
        " ⚙️ Memulai (Quantum Vortex Encryption) (1%)\n" +
        " " + createProgressBar(1) + "\n" +
        "```\n" +
        "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Quantum Vortex Encryption: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan Quantum Vortex Encryption`);
      await updateProgress(ctx, progressMessage, 40, "Inisialisasi Quantum Vortex Encryption");
      const obfuscatedCode = await obfuscateQuantum(fileContent);
      log(`Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(0, 50)}...`);
      log(`Ukuran file setelah obfuscation: ${Buffer.byteLength(obfuscatedCode, "utf-8")} bytes`);

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscatedCode);
      } catch (postObfuscationError) {
        log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
        throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
      }

      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscatedCode);

      log(`Mengirim file terenkripsi quantum: ${file.file_name}`);
      await ctx.replyWithDocument(
        {
          source: encryptedPath,
          filename: `quantum-encrypted-${file.file_name}`,
        },
        {
          caption: "✅ *File terenkripsi (Quantum Vortex Encryption) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(ctx, progressMessage, 100, "Quantum Vortex Encryption Selesai");

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Quantum obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  } catch (error) {
    console.error('Quantum command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk obfuscation: var (Var Encryption)
async function varCommand(ctx) {
  try {
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/var`!");
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, '../temp', `var-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
        "🔒 EncryptBot\n" +
        " ⚙️ Memulai (Var) (1%)\n" +
        " " + createProgressBar(1) + "\n" +
        "```\n" +
        "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Var obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Var`);
      await updateProgress(ctx, progressMessage, 40, "Inisialisasi Var Dynamic Obfuscation");
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getNovaObfuscationConfig()
      );
      let obfuscatedCode = obfuscated.code || obfuscated;
      if (typeof obfuscatedCode !== "string") {
        throw new Error("Hasil obfuscation bukan string");
      }
      log(`Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(0, 50)}...`);

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscatedCode);
      } catch (postObfuscationError) {
        log(`Detail kode bermasalah: ${obfuscatedCode.substring(0, 100)}...`);
        throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
      }

      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscatedCode);

      log(`Mengirim file terenkripsi gaya Var: ${file.file_name}`);
      await ctx.replyWithDocument(
        { source: encryptedPath, filename: `Var-encrypted-${file.file_name}` },
        {
          caption: "✅ *File terenkripsi (Var) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(ctx, progressMessage, 100, "Var Obfuscation Selesai");

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Nova obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  } catch (error) {
    console.error('Var command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk obfuscation: zenc (Invisible Encryption)
async function zencCommand(ctx) {
  try {
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/zenc`!");
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, '../temp', `invisible-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
        "🔒 EncryptBot\n" +
        ` ⚙️ Memulai (InvisiBle) (1%)\n` +
        ` ${createProgressBar(1)}\n` +
        "```\n" +
        "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Strong obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Strong`);
      await updateProgress(ctx, progressMessage, 40, "Inisialisasi Hardened Invisible Obfuscation");
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getStrongObfuscationConfig()
      );
      let obfuscatedCode = obfuscated.code || obfuscated;
      if (typeof obfuscatedCode !== "string") {
        throw new Error("Hasil obfuscation bukan string");
      }
      log(`Hasil obfuscation (50 char pertama): ${obfuscatedCode.substring(0, 50)}...`);
      await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");

      log(`Memvalidasi hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscatedCode);
      } catch (postObfuscationError) {
        throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
      }

      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");
      await fs.writeFile(encryptedPath, obfuscatedCode);

      log(`Mengirim file terenkripsi gaya Invisible: ${file.file_name}`);
      await ctx.replyWithDocument(
        {
          source: encryptedPath,
          filename: `Invisible-encrypted-${file.file_name}`,
        },
        {
          caption: "✅ *File terenkripsi (Invisible) siap!*\nSUKSES ENCRYPT 🕊",
          parse_mode: "Markdown",
        }
      );
      await updateProgress(ctx, progressMessage, 100, "Hardened Invisible Obfuscation Selesai");

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Invisible obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  } catch (error) {
    console.error('Zenc command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk obfuscation: deobfuscate
async function deobfuscateCommand(ctx) {
  try {
    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown("❌ *Error:* Balas file .js yang diobfuscate dengan `/deobfuscate`!");
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const deobfuscatedPath = path.join(__dirname, '../temp', `deobfuscated-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
        "🔒 EncryptBot\n" +
        ` ⚙️ Memulai Deobfuscation (1%)\n` +
        ` ${createProgressBar(1)}\n` +
        "```\n" +
        "PROSES ENCRYPT "
      );

      // Mengunduh file
      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk deobfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      // Validasi kode awal
      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode Awal");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      // Proses deobfuscation dengan webcrack
      log(`Memulai deobfuscation dengan webcrack: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 40, "Memulai Deobfuscation");
      const result = await webcrack(fileContent);
      let deobfuscatedCode = result.code;

      // Penanganan jika kode dibundel
      let bundleInfo = "";
      if (result.bundle) {
        bundleInfo = "// Detected as bundled code (e.g., Webpack/Browserify)\n";
        log(`Kode terdeteksi sebagai bundel: ${file.file_name}`);
      }

      // Jika tidak ada perubahan signifikan atau hasil bukan string
      if (!deobfuscatedCode || typeof deobfuscatedCode !== "string" || deobfuscatedCode.trim() === fileContent.trim()) {
        log(`Webcrack tidak dapat mendekode lebih lanjut atau hasil bukan string: ${file.file_name}`);
        deobfuscatedCode = `${bundleInfo}// Webcrack tidak dapat mendekode sepenuhnya atau hasil invalid\n${fileContent}`;
      }

      // Validasi kode hasil
      log(`Memvalidasi kode hasil deobfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 60, "Memvalidasi Kode Hasil");
      let isValid = true;
      try {
        new Function(deobfuscatedCode);
        log(`Kode hasil valid: ${deobfuscatedCode.substring(0, 50)}...`);
      } catch (syntaxError) {
        log(`Kode hasil tidak valid: ${syntaxError.message}`);
        deobfuscatedCode = `${bundleInfo}// Kesalahan validasi: ${syntaxError.message}\n${deobfuscatedCode}`;
        isValid = false;
      }

      // Simpan hasil
      await updateProgress(ctx, progressMessage, 80, "Menyimpan Hasil");
      await fs.writeFile(deobfuscatedPath, deobfuscatedCode);

      // Kirim hasil
      log(`Mengirim file hasil deobfuscation: ${file.file_name}`);
      await ctx.replyWithDocument(
        { source: deobfuscatedPath, filename: `deobfuscated-${file.file_name}` },
        {
          caption: `✅ *File berhasil dideobfuscate!${isValid ? "" : " (Perhatikan pesan error dalam file)"}*\nSUKSES ENCRYPT 🕊`,
          parse_mode: "Markdown",
        }
      );
      await updateProgress(ctx, progressMessage, 100, "Deobfuscation Selesai");

      // Hapus file sementara
      if (await fs.pathExists(deobfuscatedPath)) {
        await fs.unlink(deobfuscatedPath);
        log(`File sementara dihapus: ${deobfuscatedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat deobfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan file Javascript yang valid!_`
      );
      if (await fs.pathExists(deobfuscatedPath)) {
        await fs.unlink(deobfuscatedPath);
        log(`File sementara dihapus setelah error: ${deobfuscatedPath}`);
      }
    }
  } catch (error) {
    console.error('Deobfuscate command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

// Command untuk xx (Custom Encryption dengan nama)
async function xxCommand(ctx) {
  try {
    // Ambil nama kustom dari perintah
    const args = ctx.message.text.split(" ");
    if (args.length < 2 || !args[1]) {
      return ctx.replyWithMarkdown("❌ *Error:* Gunakan format `/enc <nama>` dengan nama kustom!");
    }
    const customName = args[1].replace(/[^a-zA-Z0-9_]/g, "");
    if (!customName) {
      return ctx.replyWithMarkdown("❌ *Error:* Nama kustom harus berisi huruf, angka, atau underscore!");
    }

    if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
      return ctx.replyWithMarkdown("❌ *Error:* Balas file .js dengan `/enc <nama>`!");
    }

    const file = ctx.message.reply_to_message.document;
    if (!file.file_name.endsWith(".js")) {
      return ctx.replyWithMarkdown("❌ *Error:* Hanya file .js yang didukung!");
    }

    const encryptedPath = path.join(__dirname, '../temp', `custom-${customName}-encrypted-${file.file_name}`);

    try {
      const progressMessage = await ctx.replyWithMarkdown(
        "```css\n" +
        "🔒 EncryptBot\n" +
        ` ⚙️ Memulai (Hardened Custom: ${customName}) (1%)\n` +
        ` ${createProgressBar(1)}\n` +
        "```\n" +
        "PROSES ENCRYPT "
      );

      const fileLink = await ctx.telegram.getFileLink(file.file_id);
      log(`Mengunduh file untuk Custom obfuscation: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 10, "Mengunduh");
      const response = await fetch(fileLink);
      let fileContent = await response.text();
      await updateProgress(ctx, progressMessage, 20, "Mengunduh Selesai");

      log(`Memvalidasi kode awal: ${file.file_name}`);
      await updateProgress(ctx, progressMessage, 30, "Memvalidasi Kode");
      try {
        new Function(fileContent);
      } catch (syntaxError) {
        throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
      }

      log(`Mengenkripsi file dengan gaya Custom (${customName}) yang diperkuat`);
      await updateProgress(ctx, progressMessage, 40, "Inisialisasi Hardened Custom Obfuscation");
      const obfuscated = await JsConfuser.obfuscate(
        fileContent,
        getCustomObfuscationConfig(customName)
      );
      log(`Hasil obfuscation (50 char pertama): ${obfuscated.code.substring(0, 50)}...`);
      await updateProgress(ctx, progressMessage, 60, "Transformasi Kode");

      log(`Memvalidasi kode hasil obfuscation: ${file.file_name}`);
      try {
        new Function(obfuscated.code);
      } catch (postObfuscationError) {
        log(`Kode hasil obfuscation tidak valid: ${postObfuscationError.message}`);
        throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
      }

      await fs.writeFile(encryptedPath, obfuscated.code);
      await updateProgress(ctx, progressMessage, 80, "Finalisasi Enkripsi");

      log(`Mengirim file terenkripsi gaya Custom: ${file.file_name}`);
      await ctx.replyWithDocument(
        {
          source: encryptedPath,
          filename: `custom-${customName}-encrypted-${file.file_name}`,
        },
        {
          caption: `✅ *File terenkripsi (Hardened Custom: ${customName}) siap!*\nSUKSES ENCRYPT 🕊`,
          parse_mode: "Markdown",
        }
      );
      await updateProgress(ctx, progressMessage, 100, `Hardened Custom (${customName}) Obfuscation Selesai`);

      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus: ${encryptedPath}`);
      }
    } catch (error) {
      log("Kesalahan saat Custom obfuscation", error);
      await ctx.replyWithMarkdown(
        `❌ *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`
      );
      if (await fs.pathExists(encryptedPath)) {
        await fs.unlink(encryptedPath);
        log(`File sementara dihapus setelah error: ${encryptedPath}`);
      }
    }
  } catch (error) {
    console.error('Xx command error:', error);
    await ctx.reply('❌ Terjadi kesalahan');
  }
}

module.exports = {
  helpCommand,
  statusCommand,
  myscCommand,
  addblCommand,
  delblCommand,
  listblCommand,
  addpremCommand,
  delpremCommand,
  listpremCommand,
  bcCommand,
  statsCommand,
  listgroupCommand,
  gbCommand,
  antispamCommand,
  noeventCommand,
  nolinksCommand,
  noforwardsCommand,
  nocontactsCommand,
  nohastagsCommand,
  nocommandsCommand,
  encCommand,
  enc2Command,
  enc3Command,
  enc4Command,
  enc5Command,
  japanCommand,
  nebulaCommand,
  quantumCommand,
  varCommand,
  zencCommand,
  deobfuscateCommand,
  xxCommand
};