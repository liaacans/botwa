const { Telegraf } = require('telegraf');
const imap = require('imap-simple');
const simpleParser = require('mailparser').simpleParser;
const nodemailer = require('nodemailer');
const fs = require('fs');
const path = require('path');

// Konfigurasi
const BOT_TOKEN = '7569137877:AAHnvva5p9SFclkDpDio8QcJsSfbzlrK6IY';
const IMAP_CONFIG = {
  imap: {
    user: 'nokosmerah@buatkamu.web.id',
    password: 'Grki6Vv1gdlA',
    host: 'newpinwheel.indowebsite.net',
    port: 993,
    tls: true,
    tlsOptions: { rejectUnauthorized: false },
    authTimeout: 10000
  }
};

// Beberapa opsi konfigurasi SMTP untuk dicoba
const SMTP_CONFIGS = [
  // Opsi 1: Standard dengan port 587
  {
    host: 'newpinwheel.indowebsite.net',
    port: 587,
    secure: false,
    auth: {
      user: 'nokosmerah@buatkamu.web.id',
      pass: 'Grki6Vv1gdlA'
    },
    tls: { rejectUnauthorized: false }
  },
  // Opsi 2: Standard dengan port 465
  {
    host: 'newpinwheel.indowebsite.net',
    port: 465,
    secure: true,
    auth: {
      user: 'nokosmerah@buatkamu.web.id',
      pass: 'Grki6Vv1gdlA'
    },
    tls: { rejectUnauthorized: false }
  },
  // Opsi 3: Port 26 (alternatif umum)
  {
    host: 'newpinwheel.indowebsite.net',
    port: 26,
    secure: false,
    auth: {
      user: 'nokosmerah@buatkamu.web.id',
      pass: 'Grki6Vv1gdlA'
    },
    tls: { rejectUnauthorized: false }
  },
  // Opsi 4: Dengan hostname yang berbeda (mungkin mail.domain)
  {
    host: 'mail.buatkamu.web.id',
    port: 587,
    secure: false,
    auth: {
      user: 'nokosmerah@buatkamu.web.id',
      pass: 'Grki6Vv1gdlA'
    },
    tls: { rejectUnauthorized: false }
  },
  // Opsi 5: Dengan hostname lengkap
  {
    host: 'mail.newpinwheel.indowebsite.net',
    port: 587,
    secure: false,
    auth: {
      user: 'nokosmerah@buatkamu.web.id',
      pass: 'Grki6Vv1gdlA'
    },
    tls: { rejectUnauthorized: false }
  }
];

// Inisialisasi bot
const bot = new Telegraf(BOT_TOKEN);

// Variabel untuk melacak email yang sudah diproses
let processedEmails = new Set();

// File untuk menyimpan data notifikasi
const DATA_FILE = 'bot_data.json';

// Load data dari file
let botData = {
  notificationUsers: new Set(),
  allowedGroups: new Set()
};

function loadData() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const data = fs.readFileSync(DATA_FILE, 'utf8');
      const parsed = JSON.parse(data);
      botData.notificationUsers = new Set(parsed.notificationUsers || []);
      botData.allowedGroups = new Set(parsed.allowedGroups || []);
    }
  } catch (error) {
    console.error('Error loading data:', error);
  }
}

function saveData() {
  try {
    const data = {
      notificationUsers: Array.from(botData.notificationUsers),
      allowedGroups: Array.from(botData.allowedGroups)
    };
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
  } catch (error) {
    console.error('Error saving data:', error);
  }
}

// Load data saat start
loadData();

// Fungsi untuk mendapatkan transporter SMTP yang bekerja
async function getWorkingTransporter() {
  for (let i = 0; i < SMTP_CONFIGS.length; i++) {
    const config = SMTP_CONFIGS[i];
    const transporter = nodemailer.createTransport(config);
    
    try {
      console.log(`🔄 Mencoba koneksi SMTP dengan config ${i + 1} (port ${config.port})...`);
      await transporter.verify();
      console.log(`✅ Koneksi SMTP berhasil dengan config ${i + 1} (port ${config.port})`);
      return transporter;
    } catch (error) {
      console.log(`❌ Config ${i + 1} gagal: ${error.code}`);
      continue;
    }
  }
  
  throw new Error('Tidak ada konfigurasi SMTP yang berhasil');
}

// Inisialisasi transporter
let transporter = null;

// Fungsi untuk memeriksa dan memproses email baru
async function checkNewEmails() {
  console.log('Memeriksa email baru...');
  
  try {
    const connection = await imap.connect(IMAP_CONFIG);
    console.log('Terhubung ke server IMAP');

    await connection.openBox('INBOX');
    console.log('Kotak masuk terbuka');

    const searchCriteria = ['UNSEEN'];
    const fetchOptions = {
      bodies: [''],
      markSeen: true,
      struct: true
    };

    const messages = await connection.search(searchCriteria, fetchOptions);
    console.log(`Ditemukan ${messages.length} email baru`);

    for (const message of messages) {
      const all = message.parts.find(part => part.which === '');
      const id = message.attributes.uid;
      const idHeader = "Message-ID: " + (message.attributes['x-gm-msgid'] || id);

      if (processedEmails.has(idHeader)) {
        console.log(`Email ${idHeader} sudah diproses, dilewati`);
        continue;
      }

      const parsedEmail = await simpleParser(all.body);
      console.log('Memproses email dari:', parsedEmail.from.text);

      const emailText = `📧 EMAIL BARU\n\nDari: ${parsedEmail.from.text}\nKepada: ${parsedEmail.to.text}\nSubjek: ${parsedEmail.subject}\n\n${parsedEmail.text ? parsedEmail.text.substring(0, 1000) + (parsedEmail.text.length > 1000 ? '...' : '') : 'Tidak ada konten teks'}`;

      for (const userId of botData.notificationUsers) {
        try {
          await bot.telegram.sendMessage(userId, emailText);
          console.log(`Notifikasi terkirim ke user: ${userId}`);
        } catch (error) {
          console.error(`Gagal mengirim ke user ${userId}:`, error);
        }
      }

      processedEmails.add(idHeader);
      console.log(`Email ${idHeader} diproses`);
    }

    connection.end();
  } catch (error) {
    console.error('Error memeriksa email:', error);
  }
}

// Command /sendmail untuk mengirim email
bot.command('sendmail', async (ctx) => {
  if (ctx.chat.type === 'channel') {
    return ctx.reply('❌ Perintah ini tidak dapat digunakan di channel.');
  }

  try {
    const args = ctx.message.text.split('|').slice(1);
    if (args.length < 3) {
      return ctx.reply('📝 Format: /sendmail |<email_tujuan>|<subjek>|<pesan>\n\nContoh: /sendmail |contoh@email.com|"Test Subject"|"Pesan tes"');
    }

    const toEmail = args[0];
    const subject = args.slice(1, -1).join('|');
    const message = args[args.length - 1];

    const mailOptions = {
      from: 'nokosmerah@buatkamu.web.id',
      to: toEmail,
      subject: subject,
      text: message,
      html: `<p>${message.replace(/\n/g, '<br>')}</p>`
    };

    // Jika transporter belum ada atau error, coba buat baru
    if (!transporter) {
      transporter = await getWorkingTransporter();
    }

    try {
      await transporter.verify();
    } catch (error) {
      console.log('Koneksi SMTP terputus, mencoba reconnect...');
      transporter = await getWorkingTransporter();
    }

    await transporter.sendMail(mailOptions);
    console.log(`Email terkirim ke: ${toEmail}, subjek: ${subject}`);
    ctx.reply(`✅ Email berhasil dikirim ke ${toEmail}`);
  } catch (error) {
    console.error('Error mengirim email:', error);
    
    if (error.code === 'ESOCKET' || error.code === 'ECONNREFUSED') {
      ctx.reply('❌ Server email tidak dapat diakses. Silakan hubungi administrator.');
    } else {
      ctx.reply('❌ Gagal mengirim email. Silakan coba lagi nanti.');
    }
  }
});

// Command untuk berlangganan notifikasi email
bot.command('subemail', async (ctx) => {
  if (ctx.chat.type !== 'private') {
    return ctx.reply('❌ Berlangganan notifikasi hanya bisa di chat pribadi.');
  }

  botData.notificationUsers.add(ctx.from.id.toString());
  saveData();
  ctx.reply('✅ Anda berhasil berlangganan notifikasi email baru!');
});

// Command untuk berhenti langganan notifikasi
bot.command('unsubemail', async (ctx) => {
  if (ctx.chat.type !== 'private') {
    return ctx.reply('❌ Berhenti langganan hanya bisa di chat pribadi.');
  }

  botData.notificationUsers.delete(ctx.from.id.toString());
  saveData();
  ctx.reply('✅ Anda berhenti berlangganan notifikasi email.');
});

// Command untuk info status
bot.command('status', async (ctx) => {
  const isSubscribed = botData.notificationUsers.has(ctx.from.id.toString());
  const isGroupAllowed = botData.allowedGroups.has(ctx.chat.id.toString());

  let statusMessage = `🤖 Status Bot Email\n\n`;
  statusMessage += `👤 User ID: ${ctx.from.id}\n`;
  statusMessage += `💬 Chat Type: ${ctx.chat.type}\n`;
  statusMessage += `🔔 Notifikasi: ${isSubscribed ? '✅' : '❌'}\n`;
  
  if (ctx.chat.type !== 'private') {
    statusMessage += `👥 Grup Diizinkan: ${isGroupAllowed ? '✅' : '❌'}\n`;
  }

  statusMessage += `\n📊 Statistik:\n`;
  statusMessage += `• Notifikasi: ${botData.notificationUsers.size} user\n`;
  statusMessage += `• Grup Diizinkan: ${botData.allowedGroups.size} grup\n`;
  statusMessage += `• Email Diproses: ${processedEmails.size} email`;

  // Test koneksi SMTP
  try {
    if (!transporter) {
      transporter = await getWorkingTransporter();
    }
    await transporter.verify();
    statusMessage += `\n📧 Status SMTP: ✅ Terhubung`;
  } catch (error) {
    statusMessage += `\n📧 Status SMTP: ❌ Terputus`;
  }

  ctx.reply(statusMessage);
});

// Command untuk bantuan
bot.command('help', (ctx) => {
  const helpText = `🤖 Bot Email Help\n
/status - Status bot
/sendmail - Kirim email
/subemail - Langganan notifikasi email (hanya private)
/unsubemail - Berhenti langganan notifikasi (hanya private)

Format /sendmail:
/sendmail |email@tujuan.com|"Subjek email"|"Pesan email"

Contoh:
/sendmail |contoh@gmail.com|"Test Subject"|"Ini adalah pesan test"`;

  ctx.reply(helpText);
});

// Start command
bot.command('start', (ctx) => {
  console.log(`Bot dimulai oleh: ${ctx.from.id} di ${ctx.chat.type}`);
  
  if (ctx.chat.type === 'group' || ctx.chat.type === 'supergroup') {
    if (!botData.allowedGroups.has(ctx.chat.id.toString())) {
      botData.allowedGroups.add(ctx.chat.id.toString());
      saveData();
      console.log(`Grup ${ctx.chat.id} ditambahkan ke daftar yang diizinkan`);
    }
  }

  const welcomeText = `🤖 Selamat datang di Bot Email!\n
Saya membantu mengelola email Anda. Fitur yang tersedia:
• Menerima notifikasi email baru
• Mengirim email melalui Telegram
• Manajemen multi-user

Gunakan /help untuk melihat semua perintah yang tersedia.`;

  ctx.reply(welcomeText);
});

// Middleware untuk otomatis menyimpan data grup
bot.use((ctx, next) => {
  if (ctx.chat && (ctx.chat.type === 'group' || ctx.chat.type === 'supergroup')) {
    if (!botData.allowedGroups.has(ctx.chat.id.toString())) {
      botData.allowedGroups.add(ctx.chat.id.toString());
      saveData();
      console.log(`Grup ${ctx.chat.id} otomatis ditambahkan ke daftar yang diizinkan`);
    }
  }
  
  return next();
});

// Event ketika bot ditambahkan ke grup
bot.on('new_chat_members', (ctx) => {
  if (ctx.message.new_chat_member.id === ctx.botInfo.id) {
    if (!botData.allowedGroups.has(ctx.chat.id.toString())) {
      botData.allowedGroups.add(ctx.chat.id.toString());
      saveData();
      console.log(`Grup ${ctx.chat.id} ditambahkan ke daftar yang diizinkan`);
    }
    ctx.reply('🤖 Terima kasih telah menambahkan saya! Bot sekarang dapat digunakan di grup ini.');
  }
});

// Handle error
bot.catch((err, ctx) => {
  console.error(`Error untuk update ${ctx.updateType}:`, err);
});

// Jalankan bot
async function startBot() {
  try {
    console.log('🔄 Mencari konfigurasi SMTP yang bekerja...');
    transporter = await getWorkingTransporter();
    
    await bot.launch();
    console.log('✅ Bot Telegram berjalan');
    console.log('🤖 Bot info:', bot.botInfo);

    setInterval(checkNewEmails, 60000);
    setTimeout(checkNewEmails, 3000);

  } catch (error) {
    console.error('❌ Gagal memulai bot:', error.message);
    console.log('📧 Fitur pengiriman email tidak akan bekerja, tetapi fitur notifikasi masih aktif');
    
    // Jalankan bot tanpa SMTP
    bot.launch().then(() => {
      console.log('✅ Bot Telegram berjalan (tanpa SMTP)');
    });
  }
}

startBot();

// Enable graceful stop
process.once('SIGINT', () => {
  console.log('🛑 Menghentikan bot...');
  bot.stop('SIGINT');
  saveData();
  process.exit(0);
});

process.once('SIGTERM', () => {
  console.log('🛑 Menghentikan bot...');
  bot.stop('SIGTERM');
  saveData();
  process.exit(0);
});

setInterval(saveData, 60000);