const { Markup } = require('telegraf');
const { updateProgress, isCreator, runtime } = require('../lib/utils');
const db = require('../lib/database');
const obf = require('./obf');
const moment = require('moment-timezone');

class CommandHandler {
    async handleStart(ctx) {
        const userId = ctx.from.id;
        const username = ctx.from.username || 'No Username';
        const firstName = ctx.from.first_name || 'User';
        
        // Add user to database if not exists
        let user = db.getUser(userId);
        if (!user) {
            user = db.addUser(userId, {
                username,
                firstName,
                groups: [],
                shares: 0,
                lastShare: null
            });
        }
        
        const isCreatorUser = isCreator(userId);
        
        const menuText = `╭─❒ 「 User Info 」 
├ Creator : @${global.developer}
├ Name : @${username}
├ Profile : @${ctx.from.username || 'No Username'}
├ ID Telegram Anda: ${userId}
├ Hostname : VPS 6GB
├ Platform : Bot Jasher
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreatorUser ? 'True' : 'False'}

Silahkan pilih button dibawah ini!`;
        
        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('Jasher Menu', 'jasher_menu')],
            [Markup.button.callback('Owner Menu', 'owner_menu')],
            [Markup.button.callback('Obf Menu', 'obf_menu')]
        ]);
        
        try {
            await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
                caption: menuText,
                parse_mode: 'HTML',
                ...keyboard
            });
        } catch (error) {
            await ctx.reply(menuText, {
                parse_mode: 'HTML',
                ...keyboard
            });
        }
        
        updateProgress(userId, 'start');
    }
    
    async handleMenu(ctx) {
        const userId = ctx.from.id;
        const isCreatorUser = isCreator(userId);
        
        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('Jasher Menu', 'jasher_menu')],
            [Markup.button.callback('Owner Menu', 'owner_menu')],
            [Markup.button.callback('Obf Menu', 'obf_menu')],
            [Markup.button.callback('Kembali', 'main_menu')]
        ]);
        
        await ctx.reply('Pilih menu yang tersedia:', keyboard);
        updateProgress(userId, 'menu');
    }
    
    async handleObf(ctx) {
        const userId = ctx.from.id;
        const premiumUser = db.getPremiumUser(userId);
        const isPremium = premiumUser && premiumUser.expiry > Date.now();
        
        if (!isPremium) {
            await ctx.reply('Anda harus premium untuk menggunakan fitur Obfuscation. Silahkan share bot ke 3 group terlebih dahulu.');
            return;
        }
        
        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('Time-Locked Encryption', 'obf_timelocked')],
            [Markup.button.callback('Quantum Vortex Encryption', 'obf_quantum')],
            [Markup.button.callback('Siu Calcrick Obfuscation', 'obf_siu')],
            [Markup.button.callback('Custom Obfuscation', 'obf_custom')],
            [Markup.button.callback('Nebula Obfuscation', 'obf_nebula')],
            [Markup.button.callback('Nova Obfuscation', 'obf_nova')],
            [Markup.button.callback('Strong Obfuscation', 'obf_strong')],
            [Markup.button.callback('Arab Obfuscation', 'obf_arab')],
            [Markup.button.callback('Japan Obfuscation', 'obf_japan')],
            [Markup.button.callback('Japan x Arab Obfuscation', 'obf_japan_arab')],
            [Markup.button.callback('Kembali', 'main_menu')]
        ]);
        
        await ctx.reply('Pilih jenis obfuscation:', keyboard);
        updateProgress(userId, 'obf');
    }
    
    async handleOwner(ctx) {
        const userId = ctx.from.id;
        const isCreatorUser = isCreator(userId);
        
        if (!isCreatorUser) {
            await ctx.reply('Hanya owner yang dapat mengakses menu ini.');
            return;
        }
        
        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('Add Premium', 'owner_addprem')],
            [Markup.button.callback('Delete Premium', 'owner_delprem')],
            [Markup.button.callback('List Premium', 'owner_listprem')],
            [Markup.button.callback('Add Blacklist', 'owner_addbl')],
            [Markup.button.callback('Delete Blacklist', 'owner_delbl')],
            [Markup.button.callback('List Blacklist', 'owner_listbl')],
            [Markup.button.callback('Auto Jasher', 'owner_autojasher')],
            [Markup.button.callback('Stop Auto Jasher', 'owner_stopautojasher')],
            [Markup.button.callback('List Grup', 'owner_listgrup')],
            [Markup.button.callback('Broadcast', 'owner_broadcast')],
            [Markup.button.callback('Kembali', 'main_menu')]
        ]);
        
        await ctx.reply('Menu Owner:', keyboard);
        updateProgress(userId, 'owner');
    }
    
    async handleShareVip(ctx) {
        const userId = ctx.from.id;
        
        if (ctx.chat.type !== 'private') {
            await ctx.reply('Perintah ini hanya bisa digunakan di private chat.');
            return;
        }
        
        const shareText = `🎉 *Jasher Premium Bot* 🎉

Nikmati fitur obfuscation canggih dengan berbagai metode enkripsi:

• Time-Locked Encryption
• Quantum Vortex Encryption
• Siu Calcrick Obfuscation
• Dan masih banyak lagi!

Tambahkan bot ke grup Anda dan dapatkan akses premium dengan membagikan ke 3 grup!

@${ctx.botInfo.username}`;
        
        const keyboard = Markup.inlineKeyboard([
            [Markup.button.url('Tambahkan ke Grup', `https://t.me/${ctx.botInfo.username}?startgroup=true`)],
            [Markup.button.callback('Kembali', 'main_menu')]
        ]);
        
        await ctx.reply(shareText, {
            parse_mode: 'Markdown',
            ...keyboard
        });
        
        updateProgress(userId, 'sharevip');
    }
    
    async handleAddPrem(ctx) {
        const userId = ctx.from.id;
        const isCreatorUser = isCreator(userId);
        
        if (!isCreatorUser) {
            await ctx.reply('Hanya owner yang dapat menambahkan premium.');
            return;
        }
        
        const args = ctx.message.text.split(' ');
        if (args.length < 3) {
            await ctx.reply('Format: /addprem [user_id] [days]');
            return;
        }
        
        const targetUserId = parseInt(args[1]);
        const days = parseInt(args[2]);
        
        if (isNaN(targetUserId) || isNaN(days)) {
            await ctx.reply('User ID dan days harus angka.');
            return;
        }
        
        const result = db.addPremiumUser(targetUserId, days);
        if (result) {
            await ctx.reply(`Berhasil menambahkan premium untuk user ${targetUserId} selama ${days} hari.`);
            
            // Notify the user
            try {
                await ctx.telegram.sendMessage(targetUserId, `Selamat! Anda telah mendapatkan akses premium selama ${days} hari.`);
            } catch (error) {
                console.error('Cannot send message to user:', error);
            }
        } else {
            await ctx.reply('Gagal menambahkan premium.');
        }
        
        updateProgress(userId, 'addprem');
    }
    
    async handleDelPrem(ctx) {
        const userId = ctx.from.id;
        const isCreatorUser = isCreator(userId);
        
        if (!isCreatorUser) {
            await ctx.reply('Hanya owner yang dapat menghapus premium.');
            return;
        }
        
        const args = ctx.message.text.split(' ');
        if (args.length < 2) {
            await ctx.reply('Format: /delprem [user_id]');
            return;
        }
        
        const targetUserId = parseInt(args[1]);
        
        if (isNaN(targetUserId)) {
            await ctx.reply('User ID harus angka.');
            return;
        }
        
        const result = db.removePremiumUser(targetUserId);
        if (result) {
            await ctx.reply(`Berhasil menghapus premium untuk user ${targetUserId}.`);
            
            // Notify the user
            try {
                await ctx.telegram.sendMessage(targetUserId, 'Akses premium Anda telah dihapus.');
            } catch (error) {
                console.error('Cannot send message to user:', error);
            }
        } else {
            await ctx.reply('Gagal menghapus premium atau user tidak ditemukan.');
        }
        
        updateProgress(userId, 'delprem');
    }
    
    async handleListPrem(ctx) {
        const userId = ctx.from.id;
        const isCreatorUser = isCreator(userId);
        
        if (!isCreatorUser) {
            await ctx.reply('Hanya owner yang dapat melihat list premium.');
            return;
        }
        
        const premiumUsers = db.getAllPremiumUsers();
        let message = 'Daftar User Premium:\n\n';
        
        for (const [userId, data] of Object.entries(premiumUsers)) {
            const user = db.getUser(parseInt(userId));
            const username = user ? `@${user.username}` : 'Unknown';
            const expiry = moment(data.expiry).format('DD/MM/YYYY HH:mm:ss');
            message += `• ${username} (${userId}) - Expiry: ${expiry}\n`;
        }
        
        if (Object.keys(premiumUsers).length === 0) {
            message = 'Tidak ada user premium.';
        }
        
        await ctx.reply(message);
        updateProgress(userId, 'listprem');
    }
    
    async handleAddBl(ctx) {
        const userId = ctx.from.id;
        const isCreatorUser = isCreator(userId);
        
        if (!isCreatorUser) {
            await ctx.reply('Hanya owner yang dapat menambahkan blacklist.');
            return;
        }
        
        const args = ctx.message.text.split(' ');
        if (args.length < 2) {
            await ctx.reply('Format: /addbl [group_id]');
            return;
        }
        
        const groupId = args[1];
        const result = db.addToBlacklist(groupId);
        
        if (result) {
            await ctx.reply(`Berhasil menambahkan group ${groupId} ke blacklist.`);
        } else {
            await ctx.reply('Group sudah ada di blacklist.');
        }
        
        updateProgress(userId, 'addbl');
    }
    
    async handleDelBl(ctx) {
        const userId = ctx.from.id;
        const isCreatorUser = isCreator(userId);
        
        if (!isCreatorUser) {
            await ctx.reply('Hanya owner yang dapat menghapus blacklist.');
            return;
        }
        
        const args = ctx.message.text.split(' ');
        if (args.length < 2) {
            await ctx.reply('Format: /delbl [group_id]');
            return;
        }
        
        const groupId = args[1];
        const result = db.removeFromBlacklist(groupId);
        
        if (result) {
            await ctx.reply(`Berhasil menghapus group ${groupId} dari blacklist.`);
        } else {
            await ctx.reply('Group tidak ditemukan di blacklist.');
        }
        
        updateProgress(userId, 'delbl');
    }
    
    async handleListBl(ctx) {
        const userId = ctx.from.id;
        const isCreatorUser = isCreator(userId);
        
        if (!isCreatorUser) {
            await ctx.reply('Hanya owner yang dapat melihat blacklist.');
            return;
        }
        
        const blacklist = db.getBlacklist();
        let message = 'Daftar Blacklist Group:\n\n';
        
        if (blacklist.length === 0) {
            message = 'Tidak ada group di blacklist.';
        } else {
            blacklist.forEach((groupId, index) => {
                message += `${index + 1}. ${groupId}\n`;
            });
        }
        
        await ctx.reply(message);
        updateProgress(userId, 'listbl');
    }
    
    async handleAutoJasher(ctx) {
        const userId = ctx.from.id;
        const isCreatorUser = isCreator(userId);
        
        if (!isCreatorUser) {
            await ctx.reply('Hanya owner yang dapat mengaktifkan auto jasher.');
            return;
        }
        
        // Implement auto jasher logic here
        // This would typically set up a timer to automatically share to groups
        
        await ctx.reply('Auto Jasher diaktifkan. Bot akan otomatis share ke grup setiap 10 menit.');
        updateProgress(userId, 'autojasher');
    }
    
    async handleStopAutoJasher(ctx) {
        const userId = ctx.from.id;
        const isCreatorUser = isCreator(userId);
        
        if (!isCreatorUser) {
            await ctx.reply('Hanya owner yang dapat menghentikan auto jasher.');
            return;
        }
        
        // Implement stop auto jasher logic here
        
        await ctx.reply('Auto Jasher dihentikan.');
        updateProgress(userId, 'stopautojasher');
    }
    
    async handleListGrup(ctx) {
        const userId = ctx.from.id;
        const isCreatorUser = isCreator(userId);
        
        if (!isCreatorUser) {
            await ctx.reply('Hanya owner yang dapat melihat list grup.');
            return;
        }
        
        const groups = db.getAllGroups();
        let message = 'Daftar Grup Aktif:\n\n';
        
        if (Object.keys(groups).length === 0) {
            message = 'Tidak ada grup aktif.';
        } else {
            for (const [groupId, groupData] of Object.entries(groups)) {
                message += `• ${groupData.title || 'Unknown'} (${groupId})\n`;
            }
        }
        
        await ctx.reply(message);
        updateProgress(userId, 'listgrup');
    }
    
    async handleToUrl(ctx) {
        const userId = ctx.from.id;
        
        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.photo) {
            await ctx.reply('Balas pesan foto dengan perintah /tourl');
            return;
        }
        
        const photo = ctx.message.reply_to_message.photo;
        const largestPhoto = photo[photo.length - 1];
        const fileId = largestPhoto.file_id;
        const fileUrl = await ctx.telegram.getFileLink(fileId);
        
        await ctx.reply(`URL Foto: ${fileUrl}`);
        updateProgress(userId, 'tourl');
    }
    
    async handleCallbackQuery(ctx) {
        const data = ctx.callbackQuery.data;
        const userId = ctx.from.id;
        
        switch (data) {
            case 'main_menu':
                await this.handleStart(ctx);
                break;
                
            case 'jasher_menu':
                await this.handleJasherMenu(ctx);
                break;
                
            case 'owner_menu':
                await this.handleOwner(ctx);
                break;
                
            case 'obf_menu':
                await this.handleObf(ctx);
                break;
                
            case 'obf_timelocked':
                await this.handleObfTimelocked(ctx);
                break;
                
            case 'obf_quantum':
                await this.handleObfQuantum(ctx);
                break;
                
            // Add more cases for other obfuscation types
                
            case 'owner_addprem':
                await ctx.reply('Gunakan perintah /addprem [user_id] [days]');
                break;
                
            case 'owner_delprem':
                await ctx.reply('Gunakan perintah /delprem [user_id]');
                break;
                
            case 'owner_listprem':
                await this.handleListPrem(ctx);
                break;
                
            case 'owner_addbl':
                await ctx.reply('Gunakan perintah /addbl [group_id]');
                break;
                
            case 'owner_delbl':
                await ctx.reply('Gunakan perintah /delbl [group_id]');
                break;
                
            case 'owner_listbl':
                await this.handleListBl(ctx);
                break;
                
            case 'owner_autojasher':
                await this.handleAutoJasher(ctx);
                break;
                
            case 'owner_stopautojasher':
                await this.handleStopAutoJasher(ctx);
                break;
                
            case 'owner_listgrup':
                await this.handleListGrup(ctx);
                break;
                
            case 'owner_broadcast':
                await ctx.reply('Balas pesan dengan /broadcast [pesan] untuk mengirim broadcast');
                break;
                
            default:
                await ctx.answerCbQuery('Perintah tidak dikenali');
                break;
        }
        
        await ctx.answerCbQuery();
    }
    
    async handleChatMember(ctx) {
        // Handle bot being added to a group
        if (ctx.chatMember.new_chat_member.status === 'member' && 
            ctx.chatMember.new_chat_member.user.id === ctx.botInfo.id) {
            
            const groupId = ctx.chat.id;
            const groupTitle = ctx.chat.title;
            
            // Check if group is blacklisted
            const blacklist = db.getBlacklist();
            if (blacklist.includes(groupId.toString())) {
                await ctx.telegram.leaveChat(groupId);
                return;
            }
            
            // Add group to database
            db.addGroup(groupId, {
                title: groupTitle,
                added: Date.now()
            });
            
            await ctx.reply(`Terima kasih telah menambahkan saya ke grup ${groupTitle}!`);
        }
    }
    
    async handleMessage(ctx) {
        // Handle text messages for broadcast
        if (ctx.message.text && ctx.message.text.startsWith('/broadcast ')) {
            const userId = ctx.from.id;
            const isCreatorUser = isCreator(userId);
            
            if (!isCreatorUser) {
                await ctx.reply('Hanya owner yang dapat melakukan broadcast.');
                return;
            }
            
            const message = ctx.message.text.substring('/broadcast '.length);
            const users = db.readData(db.usersPath);
            
            let successCount = 0;
            let failCount = 0;
            
            for (const userId of Object.keys(users)) {
                try {
                    await ctx.telegram.sendMessage(userId, `📢 Broadcast:\n\n${message}`);
                    successCount++;
                } catch (error) {
                    console.error(`Failed to send broadcast to ${userId}:`, error);
                    failCount++;
                }
            }
            
            await ctx.reply(`Broadcast selesai. Berhasil: ${successCount}, Gagal: ${failCount}`);
        }
    }
    
    async handleJasherMenu(ctx) {
        const userId = ctx.from.id;
        const user = db.getUser(userId);
        const premiumUser = db.getPremiumUser(userId);
        const isPremium = premiumUser && premiumUser.expiry > Date.now();
        
        const expiryDate = isPremium ? moment(premiumUser.expiry).format('DD/MM/YYYY HH:mm:ss') : 'Tidak aktif';
        const groupsCount = user ? user.groups.length : 0;
        
        const menuText = `╭─❒ 「 Jasher Menu 」 
├ Status : ${isPremium ? 'Premium' : 'Free'}
├ Expiry : ${expiryDate}
├ Groups : ${groupsCount}/3
├ Shares : ${user ? user.shares : 0}
╰❒ Upgrade : Share ke 3 grup untuk premium`;

        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('Share VIP', 'share_vip')],
            [Markup.button.callback('Cek Status', 'check_status')],
            [Markup.button.callback('Kembali', 'main_menu')]
        ]);
        
        await ctx.reply(menuText, keyboard);
        updateProgress(userId, 'jasher_menu');
    }
    
    async handleObfTimelocked(ctx) {
        const userId = ctx.from.id;
        
        await ctx.reply('Balas pesan dengan file JavaScript yang ingin diobfuscate dengan perintah /enclocked [days]');
        updateProgress(userId, 'obf_timelocked');
    }
}

module.exports = new CommandHandler();