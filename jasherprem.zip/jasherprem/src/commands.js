const { Markup } = require('telegraf');
const { User, Group, Broadcast } = require('../lib/database');
const { formatUserInfo } = require('./utils');

async function handleStart(ctx) {
    try {
        const userId = ctx.from.id;
        const username = ctx.from.username;
        const firstName = ctx.from.first_name;
        const lastName = ctx.from.last_name || '';
        
        let user = await User.findOne({ userId });
        
        if (!user) {
            user = new User({
                userId,
                username,
                firstName,
                lastName,
                credit: 0
            });
            await user.save();
        }
        
        const menuText = formatUserInfo(ctx, user);
        const menuButtons = Markup.inlineKeyboard([
            [Markup.button.callback('Jasher Menu', 'jasher_menu')],
            [Markup.button.callback('Owner Menu', 'owner_menu')],
            [Markup.button.url('Add Group', 'https://t.me/jasherpremtia_Bot?startgroup=true')],
            [Markup.button.callback('Owner', 'owner_info')]
        ]);
        
        await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
            caption: menuText,
            parse_mode: 'HTML',
            ...menuButtons
        });
    } catch (error) {
        console.error('Error in start command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleHelp(ctx) {
    const helpText = `
🤖 <b>Jasher Bot Commands</b>

🔄 <b>Credit System:</b>
- Tambah 10 credit dengan mengundang bot ke 3 grup
- Share broadcast di grup mengurangi 2 credit
- ShareVIP mengurangi 1 credit tetapi lebih cepat

📤 <b>Broadcast:</b>
- Hanya bisa di private chat
- Bisa share teks atau reply pesan

👑 <b>Premium Features:</b>
- /addprem - Tambah user premium (Owner only)
- /delprem - Hapus user premium (Owner only)
- /listprem - List user premium

Gunakan button di bawah untuk navigasi mudah!
    `;
    
    const menuButtons = Markup.inlineKeyboard([
        [Markup.button.callback('Jasher Menu', 'jasher_menu')],
        [Markup.button.callback('Kembali', 'main_menu')]
    ]);
    
    await ctx.reply(helpText, {
        parse_mode: 'HTML',
        ...menuButtons
    });
}

async function handleCredit(ctx) {
    try {
        const userId = ctx.from.id;
        const user = await User.findOne({ userId });
        
        if (!user) {
            return await ctx.reply('Anda belum terdaftar. Ketik /start untuk memulai.');
        }
        
        const creditText = `
💳 <b>Credit Information</b>

Credit Anda: <b>${user.credit}</b>

Cara mendapatkan credit:
1. Undang bot ke 3 grup → +10 credit
2. Setiap hari → +1 credit

Cara menggunakan credit:
1. Share broadcast → -2 credit
2. ShareVIP broadcast → -1 credit
        `;
        
        await ctx.reply(creditText, { parse_mode: 'HTML' });
    } catch (error) {
        console.error('Error in credit command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleShare(ctx) {
    try {
        if (ctx.chat.type !== 'private') {
            return await ctx.reply('Command ini hanya bisa digunakan di private chat!');
        }
        
        const userId = ctx.from.id;
        const user = await User.findOne({ userId });
        
        if (!user) {
            return await ctx.reply('Anda belum terdaftar. Ketik /start untuk memulai.');
        }
        
        if (user.credit < 2) {
            return await ctx.reply('Credit Anda tidak cukup. Minimal 2 credit untuk share broadcast.');
        }
        
        let messageText = '';
        if (ctx.message.reply_to_message) {
            messageText = ctx.message.reply_to_message.text || ctx.message.reply_to_message.caption;
        } else {
            const args = ctx.message.text.split(' ').slice(1);
            messageText = args.join(' ');
        }
        
        if (!messageText || messageText.trim() === '') {
            return await ctx.reply('Silakan reply pesan yang ingin di-share atau ketik pesan setelah command /share');
        }
        
        // Kurangi credit
        user.credit -= 2;
        await user.save();
        
        // Simpan broadcast info
        const broadcast = new Broadcast({
            messageId: ctx.message.message_id.toString(),
            senderId: userId,
            text: messageText,
            recipientCount: 0 // Akan diupdate nanti
        });
        await broadcast.save();
        
        // Kirim ke semua user (dalam implementasi nyata, ini akan dijalankan secara async)
        await ctx.reply(`Broadcast sedang diproses. Credit berkurang 2. Sisa credit: ${user.credit}`);
        
        // Di sini akan ada logika untuk mengirim ke semua user
        // Untuk implementasi nyata, ini mungkin perlu background job
        
    } catch (error) {
        console.error('Error in share command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleShareVip(ctx) {
    try {
        if (ctx.chat.type !== 'private') {
            return await ctx.reply('Command ini hanya bisa digunakan di private chat!');
        }
        
        const userId = ctx.from.id;
        const user = await User.findOne({ userId });
        
        if (!user) {
            return await ctx.reply('Anda belum terdaftar. Ketik /start untuk memulai.');
        }
        
        if (!user.isPremium) {
            return await ctx.reply('Fitur ini hanya untuk user premium!');
        }
        
        if (user.credit < 1) {
            return await ctx.reply('Credit Anda tidak cukup. Minimal 1 credit untuk shareVIP broadcast.');
        }
        
        let messageText = '';
        if (ctx.message.reply_to_message) {
            messageText = ctx.message.reply_to_message.text || ctx.message.reply_to_message.caption;
        } else {
            const args = ctx.message.text.split(' ').slice(1);
            messageText = args.join(' ');
        }
        
        if (!messageText || messageText.trim() === '') {
            return await ctx.reply('Silakan reply pesan yang ingin di-share atau ketik pesan setelah command /sharevip');
        }
        
        // Kurangi credit
        user.credit -= 1;
        await user.save();
        
        // Simpan broadcast info
        const broadcast = new Broadcast({
            messageId: ctx.message.message_id.toString(),
            senderId: userId,
            text: messageText,
            recipientCount: 0 // Akan diupdate nanti
        });
        await broadcast.save();
        
        await ctx.reply(`BroadcastVIP sedang diproses. Credit berkurang 1. Sisa credit: ${user.credit}`);
        
    } catch (error) {
        console.error('Error in sharevip command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleAddPrem(ctx) {
    try {
        // Cek jika pengguna adalah admin
        if (ctx.from.id.toString() !== process.env.ADMIN_ID) {
            return await ctx.reply('Anda tidak memiliki izin untuk menggunakan command ini!');
        }
        
        const args = ctx.message.text.split(' ').slice(1);
        if (args.length === 0) {
            return await ctx.reply('Usage: /addprem <user_id>');
        }
        
        const targetUserId = parseInt(args[0]);
        if (isNaN(targetUserId)) {
            return await ctx.reply('User ID harus angka!');
        }
        
        const user = await User.findOne({ userId: targetUserId });
        if (!user) {
            return await ctx.reply('User tidak ditemukan!');
        }
        
        user.isPremium = true;
        await user.save();
        
        await ctx.reply(`User ${targetUserId} sekarang premium!`);
        
    } catch (error) {
        console.error('Error in addprem command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleDelPrem(ctx) {
    try {
        // Cek jika pengguna adalah admin
        if (ctx.from.id.toString() !== process.env.ADMIN_ID) {
            return await ctx.reply('Anda tidak memiliki izin untuk menggunakan command ini!');
        }
        
        const args = ctx.message.text.split(' ').slice(1);
        if (args.length === 0) {
            return await ctx.reply('Usage: /delprem <user_id>');
        }
        
        const targetUserId = parseInt(args[0]);
        if (isNaN(targetUserId)) {
            return await ctx.reply('User ID harus angka!');
        }
        
        const user = await User.findOne({ userId: targetUserId });
        if (!user) {
            return await ctx.reply('User tidak ditemukan!');
        }
        
        user.isPremium = false;
        await user.save();
        
        await ctx.reply(`User ${targetUserId} dihapus dari premium!`);
        
    } catch (error) {
        console.error('Error in delprem command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

async function handleListPrem(ctx) {
    try {
        // Cek jika pengguna adalah admin
        if (ctx.from.id.toString() !== process.env.ADMIN_ID) {
            return await ctx.reply('Anda tidak memiliki izin untuk menggunakan command ini!');
        }
        
        const premiumUsers = await User.find({ isPremium: true });
        
        if (premiumUsers.length === 0) {
            return await ctx.reply('Tidak ada user premium!');
        }
        
        let listText = '👑 <b>Daftar User Premium</b>\n\n';
        premiumUsers.forEach((user, index) => {
            listText += `${index + 1}. ID: ${user.userId} | Name: ${user.firstName} ${user.lastName || ''} | Username: @${user.username || 'N/A'}\n`;
        });
        
        await ctx.reply(listText, { parse_mode: 'HTML' });
        
    } catch (error) {
        console.error('Error in listprem command:', error);
        await ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

module.exports = {
    handleStart,
    handleHelp,
    handleCredit,
    handleShare,
    handleShareVip,
    handleAddPrem,
    handleDelPrem,
    handleListPrem
};