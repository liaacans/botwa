const { Telegraf } = require('telegraf');
const nodemailer = require('nodemailer');
const Imap = require('imap');
const { simpleParser } = require('simple-parser');
const { inspect } = require('util');

// Konfigurasi
const BOT_TOKEN = '7569137877:AAHnvva5p9SFclkDpDio8QcJsSfbzlrK6IY'; // Ganti dengan token bot Anda
const ALLOWED_GROUP_ID = '-1002793801544'; // ID grup yang diizinkan
const EMAIL_CONFIG = {
    host: 'newpinwheel.indowebsite.net',
    port: 993, // IMAP port
    tls: true,
    user: 'nokosmerah@buatkamu.web.id',
    password: 'Grki6Vv1gdlA'
};

// SMTP Configuration untuk mengirim email
const SMTP_CONFIG = {
    host: 'newpinwheel.indowebsite.net', // Ganti dengan SMTP host jika berbeda
    port: 587, // SMTP port
    secure: false,
    auth: {
        user: 'nokosmerah@buatkamu.web.id',
        pass: 'Grki6Vv1gdlA'
    }
};

const bot = new Telegraf(BOT_TOKEN);
let imapConnection = null;
let processedEmails = new Set(); // Untuk melacak email yang sudah diproses

// Inisialisasi IMAP connection
function initIMAP() {
    imapConnection = new Imap({
        user: EMAIL_CONFIG.user,
        password: EMAIL_CONFIG.password,
        host: EMAIL_CONFIG.host,
        port: EMAIL_CONFIG.port,
        tls: EMAIL_CONFIG.tls,
        tlsOptions: { rejectUnauthorized: false }
    });

    imapConnection.once('ready', () => {
        console.log('IMAP Connected successfully');
        checkNewEmails();
    });

    imapConnection.once('error', (err) => {
        console.error('IMAP Connection error:', err);
    });

    imapConnection.once('end', () => {
        console.log('IMAP Connection ended');
    });

    imapConnection.connect();
}

// Fungsi untuk memeriksa email baru
function checkNewEmails() {
    imapConnection.openBox('INBOX', false, (err, box) => {
        if (err) {
            console.error('Error opening inbox:', err);
            return;
        }

        // Cari email yang belum dibaca
        imapConnection.search(['UNSEEN'], (err, results) => {
            if (err) {
                console.error('Search error:', err);
                return;
            }

            if (results.length === 0) {
                console.log('No new emails');
                return;
            }

            const fetch = imapConnection.fetch(results, {
                bodies: '',
                markSeen: true // Tandai sebagai dibaca
            });

            fetch.on('message', (msg) => {
                msg.on('body', async (stream) => {
                    try {
                        const parsed = await simpleParser(stream);
                        
                        // Cek jika email sudah diproses
                        const emailId = parsed.messageId || parsed.date + parsed.from;
                        if (processedEmails.has(emailId)) {
                            return;
                        }

                        processedEmails.add(emailId);

                        // Format pesan untuk dikirim ke Telegram
                        const emailMessage = `
📧 *Email Baru*

*Dari:* ${parsed.from?.text || 'Unknown'}
*Kepada:* ${parsed.to?.text || 'Unknown'}
*Subjek:* ${parsed.subject || 'No Subject'}

*Isi:*
${parsed.text ? parsed.text.substring(0, 1000) + (parsed.text.length > 1000 ? '...' : '') : 'No content'}

${parsed.html ? '\n_Email mengandung konten HTML_' : ''}
                        `.trim();

                        // Kirim ke grup yang diizinkan
                        try {
                            await bot.telegram.sendMessage(ALLOWED_GROUP_ID, emailMessage, {
                                parse_mode: 'Markdown'
                            });
                            console.log('New email notification sent to Telegram');
                        } catch (tgError) {
                            console.error('Error sending to Telegram:', tgError);
                        }

                    } catch (parseError) {
                        console.error('Error parsing email:', parseError);
                    }
                });
            });

            fetch.once('error', (err) => {
                console.error('Fetch error:', err);
            });

            fetch.once('end', () => {
                console.log('Finished fetching emails');
            });
        });
    });
}

// Command: /sendmail
bot.command('sendmail', async (ctx) => {
    // Cek jika di grup yang diizinkan
    if (ctx.chat.id.toString() !== ALLOWED_GROUP_ID) {
        await ctx.reply('❌ Bot hanya dapat digunakan di grup tertentu.');
        return;
    }

    const args = ctx.message.text.split(' ').slice(1);
    if (args.length < 2) {
        await ctx.reply('Format: /sendmail <email_tujuan> <subjek> <isi_pesan>\nContoh: /sendmail example@email.com "Test Subject" "Isi pesan"');
        return;
    }

    const toEmail = args[0];
    const subject = args[1];
    const message = args.slice(2).join(' ') || 'No message content';

    try {
        // Buat transporter SMTP
        const transporter = nodemailer.createTransporter(SMTP_CONFIG);

        // Kirim email
        await transporter.sendMail({
            from: EMAIL_CONFIG.user,
            to: toEmail,
            subject: subject,
            text: message,
            html: `<p>${message.replace(/\n/g, '<br>')}</p>`
        });

        await ctx.reply(`✅ Email berhasil dikirim ke ${toEmail}`);
        
    } catch (error) {
        console.error('Error sending email:', error);
        await ctx.reply('❌ Gagal mengirim email: ' + error.message);
    }
});

// Handler untuk ketika bot ditambahkan ke grup
bot.on('chat_member', async (ctx) => {
    const chatMember = ctx.chatMember;
    const chatId = ctx.chat.id.toString();
    
    // Jika bot ditambahkan ke grup
    if (chatMember.new_chat_member.status === 'member' && 
        chatMember.new_chat_member.user.id === ctx.botInfo.id) {
        
        // Jika bukan grup yang diizinkan, keluar
        if (chatId !== ALLOWED_GROUP_ID) {
            try {
                await ctx.telegram.sendMessage(chatId, 
                    '❌ Bot ini hanya dapat digunakan di grup tertentu. Bot akan meninggalkan grup ini.'
                );
                await ctx.telegram.leaveChat(chatId);
            } catch (error) {
                console.error('Error leaving chat:', error);
            }
        }
    }
});

// Middleware untuk memblokir grup lain
bot.use(async (ctx, next) => {
    if (ctx.chat && ctx.chat.type !== 'private') {
        if (ctx.chat.id.toString() !== ALLOWED_GROUP_ID) {
            console.log(`Blocked access from group: ${ctx.chat.id}`);
            return; // Jangan proses pesan dari grup lain
        }
    }
    await next();
});

// Command start
bot.start((ctx) => {
    if (ctx.chat.type === 'private') {
        ctx.reply('🤖 Bot Email Notification\n\nBot ini hanya bekerja di grup tertentu untuk menerima dan mengirim notifikasi email.');
    }
});

// Command help
bot.help((ctx) => {
    ctx.reply(`
📧 *Bot Email Commands:*

/sendmail <email> <subjek> <pesan> - Kirim email
/status - Status koneksi email

Bot akan otomatis meneruskan email baru ke grup.
    `.trim());
});

// Command status
bot.command('status', async (ctx) => {
    if (ctx.chat.id.toString() !== ALLOWED_GROUP_ID) return;
    
    const status = imapConnection && imapConnection.state === 'authenticated' ? 
        '✅ Terhubung ke email' : '❌ Tidak terhubung ke email';
    
    ctx.reply(`📊 Status Bot:\n${status}\nEmail: ${EMAIL_CONFIG.user}`);
});

// Handle errors
bot.catch((err, ctx) => {
    console.error(`Error for ${ctx.updateType}:`, err);
});

// Fungsi untuk memeriksa email secara berkala
function startEmailChecker() {
    // Periksa email setiap 1 menit
    setInterval(() => {
        if (imapConnection && imapConnection.state === 'authenticated') {
            checkNewEmails();
        } else {
            console.log('IMAP not connected, reinitializing...');
            initIMAP();
        }
    }, 60000); // 60 detik
}

// Inisialisasi bot
async function startBot() {
    try {
        console.log('Starting Telegram Bot...');
        await bot.launch();
        console.log('Bot started successfully');
        
        console.log('Initializing IMAP connection...');
        initIMAP();
        
        console.log('Starting email checker...');
        startEmailChecker();
        
    } catch (error) {
        console.error('Failed to start bot:', error);
        process.exit(1);
    }
}

// Handle graceful shutdown
process.once('SIGINT', () => {
    console.log('Shutting down...');
    bot.stop();
    if (imapConnection) {
        imapConnection.end();
    }
    process.exit(0);
});

process.once('SIGTERM', () => {
    console.log('Shutting down...');
    bot.stop();
    if (imapConnection) {
        imapConnection.end();
    }
    process.exit(0);
});

// Start the bot
startBot();