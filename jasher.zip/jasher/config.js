global.BOT_TOKEN = 'YOUR_BOT_TOKEN_HERE'; // Ganti dengan token bot Anda
global.ADMIN_ID = 'YOUR_ADMIN_ID'; // Ganti dengan ID admin Anda (opsional)