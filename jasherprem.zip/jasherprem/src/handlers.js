const { User } = require('../lib/database');
const { mainMenuKeyboard, jasherMenuKeyboard, ownerMenuKeyboard } = require('./keyboards');
const {
    handleStart,
    handleHelp,
    handleCredit,
    handleAddGroup,
    handleShare,
    handleShareVIP,
    handleBroadcast,
    handleAddPrem,
    handleDelPrem,
    handleListPrem
} = require('./commands');

async function handleTextMessage(ctx) {
    try {
        const text = ctx.message.text;
        const user = await User.findOne({ userId: ctx.from.id });
        if (!user) return handleStart(ctx);
        
        switch (text) {
            case 'Jasher Menu':
                await ctx.reply('Menu Jasher:', jasherMenuKeyboard());
                break;
                
            case 'Owner Menu':
                if (user.isCreator) {
                    await ctx.reply('Menu Owner:', ownerMenuKeyboard(true));
                } else {
                    await ctx.reply('Anda bukan owner!', mainMenuKeyboard());
                }
                break;
                
            case 'Kembali':
                await ctx.reply('Kembali ke menu utama:', mainMenuKeyboard());
                break;
                
            case 'AddGroup':
                await ctx.reply('Tambahkan bot ke grup Anda dan kirim perintah /addgroup di grup tersebut untuk mendapatkan kredit!', mainMenuKeyboard());
                break;
                
            case 'Owner':
                await ctx.reply('Pemilik bot: @username_owner', mainMenuKeyboard());
                break;
                
            case 'Credit':
                await handleCredit(ctx);
                break;
                
            case 'Share':
                await handleShare(ctx);
                break;
                
            case 'ShareVIP':
                await handleShareVIP(ctx);
                break;
                
            case 'Broadcast':
                await handleBroadcast(ctx);
                break;
                
            case 'AddPrem':
                await handleAddPrem(ctx);
                break;
                
            case 'DelPrem':
                await handleDelPrem(ctx);
                break;
                
            case 'ListPrem':
                await handleListPrem(ctx);
                break;
                
            default:
                await ctx.reply('Perintah tidak dikenali. Silakan pilih menu yang tersedia.', mainMenuKeyboard());
                break;
        }
    } catch (error) {
        console.error('Error handling text message:', error);
        ctx.reply('Terjadi kesalahan, silakan coba lagi.');
    }
}

module.exports = { handleTextMessage };