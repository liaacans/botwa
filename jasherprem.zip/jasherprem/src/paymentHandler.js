const { Payment, User } = require('../lib/database');
const { log } = require('../lib/utils');
const fetch = require('node-fetch');
const crypto = require('crypto');

// Fungsi untuk validasi nomor telepon
function validatePhone(phone) {
  // Hapus semua karakter non-digit
  phone = phone.replace(/[^0-9]/g, '');
  
  // Cek panjang nomor (min 10 digit, max 15 digit)
  if (phone.length < 10 || phone.length > 15) {
    return false;
  }
  
  return phone;
}

// Fungsi untuk menghitung fee pembayaran
async function calculateFee(paymentMethod, amount) {
  try {
    const url = "https://yab-group.com/api/live/fee-calculator";
    const apikey = global.PAYMENT_API_KEY;
    const secret_key = global.PAYMENT_SECRET_KEY;
    
    const postdata = {
      api_key: apikey,
      secret_key: secret_key,
      code: paymentMethod.toUpperCase(),
      amount: amount
    };
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(postdata)
    });
    
    const data = await response.json();
    
    if (data.status === "success") {
      return {
        success: true,
        fee: data.data.fee,
        total: data.data.total,
        admin: data.data.admin
      };
    } else {
      throw new Error(data.message || 'Gagal menghitung fee');
    }
  } catch (error) {
    log('Error calculating fee: ' + error.message);
    throw error;
  }
}

// Fungsi untuk membuat pembayaran
async function createPayment(userData, amount, product, paymentMethod, phone, email) {
  try {
    const url = global.PAYMENT_URL;
    const apikey = global.PAYMENT_API_KEY;
    const secret_key = global.PAYMENT_SECRET_KEY;
    const method = paymentMethod.toUpperCase();
    const ref_kode = "JasherBot_" + Date.now() + "_" + Math.random().toString(36).substr(2, 5);
    
    // Validasi nomor telepon
    const validatedPhone = validatePhone(phone);
    if (!validatedPhone) {
      throw new Error('Nomor telepon tidak valid (min 10 digit)');
    }
    
    // Validasi email
    if (email && !/\S+@\S+\.\S+/.test(email)) {
      throw new Error('Format email tidak valid');
    }
    
    // Hitung fee
    const feeInfo = await calculateFee(paymentMethod, amount);
    
    // Siapkan data untuk API
    const postdata = {
      'api_key': apikey,
      'secret_key': secret_key,
      'channel_payment': method,
      'ref_kode': ref_kode,
      'nominal': amount,
      'cus_nama': userData.firstName + (userData.lastName ? ' ' + userData.lastName : ''),
      'cus_email': email || 'user@example.com',
      'cus_phone': validatedPhone,
      'produk': product,
      'url_redirect': "https://t.me/" + (userData.username || 'jasherbot'),
      'url_callback': "https://localhost:8080/callback", // Ganti dengan domain Anda
      'expired_time': Math.floor(Date.now() / 1000) + (24 * 60 * 60),
      'signature': crypto.createHmac('sha256', secret_key).update(ref_kode + apikey + amount).digest('hex')
    };
    
    // Panggil API YAB-Group
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: new URLSearchParams(postdata).toString()
    });
    
    const responseData = await response.json();
    
    if (responseData.data && responseData.data.status === "success") {
      // Simpan data pembayaran
      const payment = new Payment({
        userId: userData.userId,
        amount: amount,
        product: product,
        paymentMethod: paymentMethod,
        status: 'pending',
        referenceId: responseData.data.id_reference,
        checkoutUrl: responseData.data.checkout_url,
        fee: feeInfo.fee,
        totalAmount: feeInfo.total,
        adminFee: feeInfo.admin
      });
      
      await payment.save();
      
      return {
        success: true,
        checkoutUrl: responseData.data.checkout_url,
        referenceId: responseData.data.id_reference,
        feeInfo: feeInfo
      };
    } else {
      const errorMsg = responseData.message || responseData.data?.message || 'Gagal memproses pembayaran';
      throw new Error(errorMsg);
    }
  } catch (error) {
    log('Error creating payment: ' + error.message);
    throw error;
  }
}

// Fungsi untuk memeriksa status pembayaran
async function checkPaymentStatus(referenceId) {
  try {
    const url = "https://yab-group.com/api/live/transactions";
    const apikey = global.PAYMENT_API_KEY;
    const secret_key = global.PAYMENT_SECRET_KEY;
    
    const postdata = {
      api_key: apikey,
      secret_key: secret_key,
      id_reference: referenceId
    };
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: new URLSearchParams(postdata).toString()
    });
    
    const responseData = await response.json();
    
    if (responseData.data) {
      return {
        success: true,
        status: responseData.data.status,
        data: responseData.data
      };
    } else {
      throw new Error(responseData.message || 'Gagal memeriksa status pembayaran');
    }
  } catch (error) {
    log('Error checking payment status: ' + error.message);
    throw error;
  }
}

// Handler untuk callback pembayaran
async function handlePaymentCallback(data) {
  try {
    // Verifikasi signature
    const signature = crypto
      .createHmac('sha256', global.PAYMENT_SECRET_KEY)
      .update(data.reference_id + global.PAYMENT_API_KEY + data.amount)
      .digest('hex');
    
    if (signature !== data.signature) {
      log('Invalid payment callback signature');
      return { success: false, message: 'Invalid signature' };
    }
    
    // Cari data pembayaran
    const payment = await Payment.findOne({ referenceId: data.reference_id });
    if (!payment) {
      log('Payment not found: ' + data.reference_id);
      return { success: false, message: 'Payment not found' };
    }
    
    // Update status pembayaran
    payment.status = data.status === 'success' ? 'success' : 'failed';
    payment.updatedAt = new Date();
    await payment.save();
    
    if (data.status === 'success') {
      // Berikan akses premium atau kirim script
      const user = await User.findOne({ userId: payment.userId });
      
      if (!user) {
        log('User not found for payment: ' + payment.userId);
        return { success: false, message: 'User not found' };
      }
      
      if (payment.product.includes('premium')) {
        // Tambahkan premium
        let premiumDays = 30; // Default 30 hari untuk 50k
        
        if (payment.amount === 25000) {
          premiumDays = 15;
        } else if (payment.amount === 10000) {
          premiumDays = 7;
        }
        
        const premiumUntil = new Date();
        premiumUntil.setDate(premiumUntil.getDate() + premiumDays);
        
        user.isPremium = true;
        user.premiumUntil = premiumUntil;
        await user.save();
        
        log(`Premium activated for user ${user.userId} for ${premiumDays} days`);
        
        // Kirim notifikasi ke user
        try {
          await bot.telegram.sendMessage(
            user.userId,
            `🎉 *Pembayaran Premium Berhasil!*\n\n` +
            `Anda sekarang memiliki akses premium selama *${premiumDays} hari*.\n` +
            `Akses premium Anda berlaku hingga: ${premiumUntil.toLocaleDateString('id-ID')}\n\n` +
            `Terima kasih telah berlangganan Jasher Premium!`,
            { parse_mode: 'Markdown' }
          );
        } catch (error) {
          log('Error sending premium notification: ' + error.message);
        }
      } else if (payment.product.includes('script')) {
        // Kirim script berdasarkan produk yang dibeli
        let scriptMessage = '';
        let scriptFile = null;
        
        switch (payment.product) {
          case 'script_basic':
            scriptMessage = '📦 *Script Basic telah dikirim!*\n\nBerikut adalah script yang Anda beli:';
            scriptFile = './scriptnya/basic_script.js';
            break;
          case 'script_pro':
            scriptMessage = '📦 *Script Pro telah dikirim!*\n\nBerikut adalah script yang Anda beli:';
            scriptFile = './scriptnya/pro_script.js';
            break;
          case 'script_enterprise':
            scriptMessage = '📦 *Script Enterprise telah dikirim!*\n\nBerikut adalah script yang Anda beli:';
            scriptFile = './scriptnya/enterprise_script.js';
            break;
          default:
            scriptMessage = '📦 *Script telah dikirim!*\n\nBerikut adalah script yang Anda beli:';
            scriptFile = './scriptnya/default_script.js';
        }
        
        // Kirim script ke user
        try {
          await bot.telegram.sendDocument(
            user.userId,
            { source: scriptFile },
            {
              caption: scriptMessage,
              parse_mode: 'Markdown'
            }
          );
        } catch (error) {
          log('Error sending script: ' + error.message);
          await bot.telegram.sendMessage(
            user.userId,
            `❌ *Gagal mengirim script*\n\n` +
            `Silakan hubungi admin untuk mendapatkan script yang Anda beli.`,
            { parse_mode: 'Markdown' }
          );
        }
      }
      
      // Kirim notifikasi ke admin
      try {
        await bot.telegram.sendMessage(
          global.OWNER_ID,
          `💰 *Pembayaran Berhasil*\n\n` +
          `User: ${user.firstName}${user.lastName ? ' ' + user.lastName : ''} (@${user.username || 'N/A'})\n` +
          `Produk: ${payment.product}\n` +
          `Amount: Rp ${payment.amount.toLocaleString('id-ID')}\n` +
          `Reference: ${payment.referenceId}`,
          { parse_mode: 'Markdown' }
        );
      } catch (error) {
        log('Error sending admin notification: ' + error.message);
      }
    }
    
    return { success: true };
  } catch (error) {
    log('Error handling payment callback: ' + error.message);
    return { success: false, message: error.message };
  }
}

// Fungsi untuk mendapatkan riwayat pembayaran user
async function getPaymentHistory(userId, limit = 10) {
  try {
    const payments = await Payment.find({ userId })
      .sort({ createdAt: -1 })
      .limit(limit);
    
    return {
      success: true,
      payments: payments
    };
  } catch (error) {
    log('Error getting payment history: ' + error.message);
    throw error;
  }
}

// Fungsi untuk membatalkan pembayaran
async function cancelPayment(referenceId) {
  try {
    const payment = await Payment.findOne({ referenceId });
    
    if (!payment) {
      throw new Error('Pembayaran tidak ditemukan');
    }
    
    if (payment.status !== 'pending') {
      throw new Error('Hanya pembayaran pending yang dapat dibatalkan');
    }
    
    payment.status = 'cancelled';
    payment.updatedAt = new Date();
    await payment.save();
    
    return {
      success: true,
      message: 'Pembayaran berhasil dibatalkan'
    };
  } catch (error) {
    log('Error cancelling payment: ' + error.message);
    throw error;
  }
}

// Fungsi untuk mendapatkan daftar metode pembayaran
async function getPaymentMethods() {
  try {
    const url = "https://yab-group.com/api/sanbox/fee-calculator";
    const apikey = global.PAYMENT_API_KEY;
    const secret_key = global.PAYMENT_SECRET_KEY;
    
    const postdata = {
      api_key: apikey,
      secret_key: secret_key
    };
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: new URLSearchParams(postdata).toString()
    });
    
    const responseData = await response.json();
    
    if (responseData.data) {
      return {
        success: true,
        methods: responseData.data
      };
    } else {
      throw new Error(responseData.message || 'Gagal mendapatkan metode pembayaran');
    }
  } catch (error) {
    log('Error getting payment methods: ' + error.message);
    throw error;
  }
}

// Inisialisasi bot instance (akan di-set dari main.js)
let bot = null;

function setBotInstance(botInstance) {
  bot = botInstance;
}

module.exports = {
  validatePhone,
  calculateFee,
  createPayment,
  checkPaymentStatus,
  handlePaymentCallback,
  getPaymentHistory,
  cancelPayment,
  getPaymentMethods,
  setBotInstance
};