const { isPremium, isOwner, log } = require('../../lib/functions');
const db = require('../../lib/database');

module.exports = (bot, users, groups, premium, blacklist) => {
    
    // Middleware untuk menangani blacklist
    bot.use(async (ctx, next) => {
        const userId = ctx.from?.id?.toString();
        const chatId = ctx.chat?.id?.toString();
        
        // Cek blacklist user
        if (userId && blacklist.has(userId)) {
            log(`Blocked blacklisted user: ${userId}`);
            return;
        }
        
        // Cek blacklist group
        if (chatId && blacklist.has(chatId)) {
            log(`Blocked blacklisted chat: ${chatId}`);
            return;
        }
        
        await next();
    });

    // Middleware untuk menangani spam
    bot.use(async (ctx, next) => {
        if (ctx.chat?.type === 'private') {
            const userId = ctx.from.id.toString();
            
            // Simpan timestamp terakhir user
            if (!global.userCooldown) global.userCooldown = new Map();
            
            const now = Date.now();
            const lastMessage = global.userCooldown.get(userId) || 0;
            const cooldown = 1000; // 1 second cooldown
            
            if (now - lastMessage < cooldown) {
                log(`Blocked spam from user: ${userId}`);
                return;
            }
            
            global.userCooldown.set(userId, now);
        }
        
        await next();
    });

    // Handler untuk pesan baru di private chat
    bot.on('message', async (ctx) => {
        if (ctx.chat.type !== 'private') return;
        
        const userId = ctx.from.id;
        
        // Add user to database jika belum ada
        if (!users.has(userId)) {
            users.add(userId);
            await db.saveUsers(users);
            log(`New user registered: ${ctx.from.first_name} (${userId})`);
        }

        // Handle text messages yang bukan command
        if (ctx.message.text && !ctx.message.text.startsWith('/')) {
            // Jika user premium, berikan respons khusus
            if (isPremium(userId, premium)) {
                await ctx.replyWithMarkdown(`
👋 *Halo Premium User!*
Gunakan menu di bawah atau ketik /menu untuk melihat fitur yang tersedia.`);
            } else {
                await ctx.replyWithMarkdown(`
👋 *Halo! Selamat datang di Jasher Bot!*
            
Saya adalah bot obfuscation dan sharing yang powerful. Berikut fitur yang tersedia:

🔒 *Obfuscation Features:*
- enc3, enc4, japan, zenc, var, nebula, enc5, quantum
- Time-locked encryption dengan /enc [hari]
- Custom encryption dengan /enc2 [nama]

📤 *Sharing Features:*
- Share Free (perlu tambah 3 group)
- Share VIP (hanya premium)

💳 *Premium:*
- Upgrade dengan /buypremium
- Cek status dengan /premium

Ketik /menu untuk melihat menu lengkap!`);
            }
        }
    });

    // Handler untuk callback queries (button clicks)
    bot.on('callback_query', async (ctx) => {
        await ctx.answerCbQuery(); // Jawab callback query
        
        const userId = ctx.from.id;
        const data = ctx.callbackQuery.data;
        
        log(`Callback query from ${userId}: ${data}`);
        
        // Handle berbagai callback data
        switch (data) {
            case 'main_menu':
            case 'jasher_menu':
            case 'owner_menu':
            case 'obf_menu':
            case 'share_free':
            case 'share_vip':
            case 'buy_premium':
            case 'list_premium':
            case 'owner_broadcast':
            case 'add_premium':
            case 'del_premium':
            case 'add_blacklist':
            case 'del_blacklist':
            case 'owner_list_premium':
            case 'list_blacklist':
            case 'list_groups':
            case 'pay_now':
                // Handler sudah ada di file commands masing-masing
                break;
                
            default:
                log(`Unknown callback data: ${data}`);
                await ctx.replyWithMarkdown('❌ *Error:* Tombol tidak dikenali!');
        }
    });

    // Handler untuk error
    bot.catch((error, ctx) => {
        log('Error occurred:', error);
        
        try {
            ctx.replyWithMarkdown(`
╭━━━「 ❌ ERROR 」━━━⬣
│ Terjadi kesalahan sistem!
│ 
│ Silahkan coba lagi nanti.
╰━━━━━━━━━━━━━━━━⬣`);
        } catch (e) {
            log('Error sending error message:', e);
        }
    });

    // Handler untuk foto (bukti pembayaran)
    bot.on('photo', async (ctx) => {
        if (ctx.chat.type !== 'private') return;
        
        // Jika ada caption dengan command bukti
        if (ctx.message.caption && ctx.message.caption.startsWith('/bukti')) {
            // Handler sudah ada di commands/user.js
            return;
        }
        
        // Jika user mengirim foto tanpa context
        await ctx.replyWithMarkdown(`
📷 *Foto diterima!*
    
Jika ini adalah bukti pembayaran premium, silahkan reply foto ini dengan command:
/bukti [jumlah_hari] [nama_bank]
    
Contoh: /bukti 30 BCA`);
    });

    // Handler untuk document (file obfuscation)
    bot.on('document', async (ctx) => {
        if (ctx.chat.type !== 'private') return;
        
        const file = ctx.message.document;
        
        if (file.file_name.endsWith('.js')) {
            await ctx.replyWithMarkdown(`
📄 *File JavaScript diterima!*
    
Anda bisa mengobfuscate file ini dengan command:
- /enc3 - Mandarin Encryption
- /enc4 - Arab Encryption
- /japan - Japan Encryption
- /zenc - Invisible Encryption
- /var - Var Encryption
- /nebula - Nebula Encryption
- /enc5 - Calcrick Encryption
- /quantum - Quantum Encryption
- /enc [hari] - Time-Locked Encryption
- /enc2 [nama] - Custom Encryption
- /deobfuscate - Deobfuscate
    
Contoh: Reply file ini dengan /enc3`);
        } else {
            await ctx.replyWithMarkdown('❌ *Error:* Hanya file .js yang didukung untuk obfuscation!');
        }
    });
};