const { Telegraf } = require('telegraf');
const { connectDB } = require('./lib/database');
const { BOT_TOKEN } = require('./config');
const {
    startCommand,
    helpCommand,
    creditCommand,
    addPremCommand,
    delPremCommand,
    listPremCommand
} = require('./src/commands');
const {
    handleCallbackQuery,
    handleShare,
    handleShareVip,
    handleNewChatMembers
} = require('./src/handlers');

// Inisialisasi bot
const bot = new Telegraf(BOT_TOKEN);

// Koneksi database
connectDB();

// Middleware untuk menyimpan data user
bot.use(async (ctx, next) => {
    if (ctx.from) {
        const User = require('./lib/database').User;
        let user = await User.findOne({ userId: ctx.from.id });
        
        if (!user) {
            user = new User({
                userId: ctx.from.id,
                username: ctx.from.username,
                firstName: ctx.from.first_name,
                lastName: ctx.from.last_name || ''
            });
            await user.save();
        }
        
        ctx.userData = user;
    }
    
    await next();
});

// Command handlers
bot.command('start', startCommand);
bot.command('help', helpCommand);
bot.command('credit', creditCommand);
bot.command('addprem', addPremCommand);
bot.command('delprem', delPremCommand);
bot.command('listprem', listPremCommand);

// Text handlers
bot.hears('share', handleShare);
bot.hears('sharevip', handleShareVip);

// Event handlers
bot.on('callback_query', handleCallbackQuery);
bot.on('message', handleNewChatMembers);

// Error handling
bot.catch((err, ctx) => {
    console.error(`Error for ${ctx.updateType}:`, err);
    ctx.reply('Terjadi kesalahan, silakan coba lagi.');
});

// Start bot
bot.launch().then(() => {
    console.log('Bot Jasher started successfully');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));