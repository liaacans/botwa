/*
Base Ori Rahman x Ginaa imupp

Sosmed media :
Ig : private
Tele : @tiaaxl
Wa : Privet
Yt : A. Aulia Rahman Official (@auliarhmanproduction)


Thanks too::
Allah swt
Nabi Muhammad
Aulia Rahman
Ginaa Imupp

Create Bot Tokennya Di
@BotFather
Cek id tele nya Di
@CekID_tele_bot

Note : don't remove copyright of this script!
*/

function setupHandlers(bot) {
    // Handle new chat members (when bot is added to a group)
    bot.on('new_chat_members', (ctx) => {
        const newMembers = ctx.message.new_chat_members;
        
        // Check if bot was added to the group
        const botAdded = newMembers.some(member => member.is_bot && member.id === ctx.botInfo.id);
        
        if (botAdded) {
            const group = {
                id: ctx.chat.id,
                title: ctx.chat.title
            };
            
            // Add group to database
            const db = require('../lib/database');
            db.addGroup(group, ctx.from.id, function(err) {
                if (err) {
                    console.error('Error adding group:', err);
                    return;
                }
                
                // Give credit to user who added the bot
                db.updateUserCredit(ctx.from.id, 10, (err) => {
                    if (err) {
                        console.error('Error updating credit:', err);
                    } else {
                        ctx.deleteMessage();
                        ctx.reply(`✅ Thanks for adding me to this group! @${ctx.from.username || ctx.from.first_name} received 10 credits.`);
                    }
                });
            });
        }
    });

    // Error handling
    bot.catch((err, ctx) => {
        console.error(`Error for ${ctx.updateType}:`, err);
        ctx.reply('❌ An error occurred. Please try again.');
    });
}

module.exports = { setupHandlers };