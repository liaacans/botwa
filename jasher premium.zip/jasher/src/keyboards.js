const { Markup } = require('telegraf');

const mainKeyboard = Markup.keyboard([
    ['💳 Credit', '📤 Share'],
    ['⭐ ShareVIP', '📝 AddGroup'],
    ['👤 Owner', '🔧 Owner Menu']
]).resize();

const ownerKeyboard = Markup.keyboard([
    ['📢 Broadcast', '⭐ Add Premium'],
    ['🗑️ Remove Premium', '📋 List Premium'],
    ['🏠 Kembali']
]).resize();

const backKeyboard = Markup.keyboard([
    ['🏠 Kembali']
]).resize();

module.exports = {
    mainKeyboard,
    ownerKeyboard,
    backKeyboard
};