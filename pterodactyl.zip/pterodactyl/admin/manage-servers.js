<?php
include '../includes/config.php';
include '../includes/database.php';
include '../includes/functions.php';

if (!isLoggedIn() || !isAdmin()) {
    redirect('../index.php');
}

$db = new Database();
$connection = $db->getConnection();

// Handle delete server
if (isset($_GET['delete'])) {
    $serverId = (int)$_GET['delete'];
    
    // Dapatkan data server
    $server = getServerById($connection, $serverId);
    
    if ($server) {
        // Hapus server dari Pterodactyl
        if (!empty($server['pterodactyl_server_id'])) {
            pterodactylAPI('servers/' . $server['pterodactyl_server_id'], 'DELETE');
        }
        
        // Hapus server dari database
        $query = "DELETE FROM servers WHERE id = :server_id";
        $stmt = $connection->prepare($query);
        $stmt->bindParam(':server_id', $serverId);
        
        if ($stmt->execute()) {
            $_SESSION['success'] = 'Server berhasil dihapus';
        } else {
            $_SESSION['error'] = 'Gagal menghapus server';
        }
    } else {
        $_SESSION['error'] = 'Server tidak ditemukan';
    }
    
    redirect('manage-servers.php');
}

// Dapatkan semua servers
$servers = getServers($connection);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Servers - Panel Pterodactyl</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Panel Pterodactyl - Admin</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage-users.php">Manage Users</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="manage-servers.php">Manage Servers</a>
                    </li>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <?php echo htmlspecialchars($_SESSION['user_name']); ?> (Admin)
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="../panel.php">User Panel</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../auth/logout.php">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Manage Servers</h2>
        </div>
        
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Identifier</th>
                        <th>User</th>
                        <th>RAM</th>
                        <th>Disk</th>
                        <th>CPU</th>
                        <th>Status</th>
                        <th>Tanggal Dibuat</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($servers as $server): ?>
                        <tr>
                            <td><?php echo $server['id']; ?></td>
                            <td><?php echo htmlspecialchars($server['identifier']); ?></td>
                            <td>
                                <?php echo htmlspecialchars($server['user_name']); ?>
                                <br><small><?php echo htmlspecialchars($server['user_email']); ?></small>
                            </td>
                            <td><?php echo number_format($server['memory'] / 1024, 1); ?> GB</td>
                            <td><?php echo number_format($server['disk'] / 1024, 1); ?> GB</td>
                            <td><?php echo $server['cpu'] / 100; ?> Core</td>
                            <td>
                                <span class="badge bg-<?php echo $server['status'] === 'active' ? 'success' : 'warning'; ?>">
                                    <?php echo ucfirst($server['status']); ?>
                                </span>
                            </td>
                            <td><?php echo date('d M Y H:i', strtotime($server['created_at'])); ?></td>
                            <td>
                                <a href="<?php echo PTERODACTYL_DOMAIN; ?>/server/<?php echo $server['identifier']; ?>" 
                                   target="_blank" class="btn btn-sm btn-primary mb-1">Kelola</a>
                                <a href="manage-servers.php?delete=<?php echo $server['id']; ?>" 
                                   class="btn btn-sm btn-danger" 
                                   onclick="return confirm('Apakah Anda yakin ingin menghapus server ini?')">Hapus</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container text-center">
            <p>&copy; 2023 Panel Pterodactyl. All rights reserved.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>