global.BOT_TOKEN = "8198305874:AAGhlBEYItkhH2mxD265kLIMXVEcWMiwkMM";
global.developer = "ginaabaikhati";
global.ownerId = [8135269613]; // Ganti dengan ID Telegram Anda

// Konfigurasi database
global.db = require('./lib/database');