global.BOT_TOKEN = process.env.BOT_TOKEN || '8404410811:AAEZIftEDvh7qfQ-zRxfCLbLuwMK3d9Vzc0';
global.PREMIUM_USERS = new Set();
global.USER_CREDITS = new Map();
global.GROUP_REQUIREMENT = 3;
global.SHARE_COST = 2;