const { Telegraf } = require('telegraf');
const db = require('../lib/database');
const utils = require('../lib/utils');
const keyboards = require('./keyboards');

function setupCommands(bot) {
  // Start command
  bot.command('start', async (ctx) => {
    const userId = ctx.from.id;
    let user = await db.getUser(userId);
    
    if (!user) {
      await db.createUser(ctx.from);
      user = await db.getUser(userId);
    }
    
    const isCreator = String(userId) === process.env.OWNER_ID;
    const sender = ctx.from.username || ctx.from.first_name;
    const userTelelu = ctx.from.username || 'No username';
    
    const message = `
Hi kak <b>@${sender}</b>
╭─❒ 「 User Info 」 
├ Creator : <b>@${userTelelu}</b>
├ Name : <b>@${sender}</b>
├ Profile : <b>@${sender}</b>
├ ID Telegram Anda: <b>${ctx.from.id}</b>
├ Hostname : <b>Linux</b>
├ Platform : <b>Bot Telegram</b>
├ Runtime : <b>${utils.runtime(process.uptime())}</b>
├ Tanggal Server : <b>${utils.moment.tz('Asia/Jakarta').format('DD/MM/YY')}</b>
├ Waktu Server : <b>${utils.moment.tz('Asia/Jakarta').format('HH:mm:ss')}</b>
╰❒ Owner : <b>${isCreator ? 'True' : 'False'}</b>

Silahkan pilih button dibawah ini!
    `.trim();
    
    await ctx.replyWithHTML(message, keyboards.mainMenu(ctx, user));
  });
  
  // Help command
  bot.command('help', async (ctx) => {
    const helpMessage = `
<b>🤖 Jasher Bot Commands</b>

<b>📋 Main Commands:</b>
/start - Memulai bot
/help - Menampilkan bantuan
/credit - Menampilkan credit Anda

<b>🎯 Jasher Features:</b>
- Share Free: Broadcast ke group dengan biaya 2 credit
- Share VIP: Broadcast premium yang lebih cepat
- Credit Info: Lihat informasi credit Anda

<b>👑 Owner Commands (Hanya Owner):</b>
- Broadcast ke semua user
- Kelola user premium
    `.trim();
    
    await ctx.replyWithHTML(helpMessage);
  });
  
  // Credit command
  bot.command('credit', async (ctx) => {
    const userId = ctx.from.id;
    const user = await db.getUser(userId);
    
    if (!user) {
      return ctx.reply('Anda belum terdaftar. Ketik /start untuk mendaftar.');
    }
    
    const message = `
<b>💳 Credit Information</b>

👤 <b>User:</b> @${ctx.from.username || ctx.from.first_name}
💰 <b>Credit:</b> ${utils.formatCredit(user.credit)}
🏢 <b>Groups Joined:</b> ${user.joined_groups}

💡 <b>Info:</b> Tambah 3 group untuk mendapatkan 10 credit gratis!
    `.trim();
    
    await ctx.replyWithHTML(message);
  });
  
  // Handle callback queries
  bot.action('main_menu', async (ctx) => {
    await ctx.deleteMessage();
    await ctx.replyWithHTML('Menu utama:', keyboards.mainMenu(ctx));
  });
  
  bot.action('jasher_menu', async (ctx) => {
    await ctx.editMessageText('🎯 <b>Jasher Menu</b>', {
      parse_mode: 'HTML',
      ...keyboards.jasherMenu(ctx)
    });
  });
  
  bot.action('owner_menu', async (ctx) => {
    if (String(ctx.from.id) !== process.env.OWNER_ID) {
      return ctx.answerCbQuery('❌ Hanya owner yang bisa mengakses menu ini!');
    }
    
    await ctx.editMessageText('👑 <b>Owner Menu</b>', {
      parse_mode: 'HTML',
      ...keyboards.ownerMenu(ctx)
    });
  });
  
  bot.action('credit_info', async (ctx) => {
    const userId = ctx.from.id;
    const user = await db.getUser(userId);
    
    const message = `
<b>💳 Credit Information</b>

👤 <b>User:</b> @${ctx.from.username || ctx.from.first_name}
💰 <b>Credit:</b> ${utils.formatCredit(user.credit)}
🏢 <b>Groups Joined:</b> ${user.joined_groups}

💡 <b>Info:</b> Tambah 3 group untuk mendapatkan 10 credit gratis!
    `.trim();
    
    await ctx.editMessageText(message, {
      parse_mode: 'HTML',
      ...keyboards.backButton('jasher_menu')
    });
  });
  
  bot.action('share_free', async (ctx) => {
    if (ctx.chat.type !== 'private') {
      return ctx.answerCbQuery('❌ Command ini hanya bisa digunakan di private chat!');
    }
    
    const userId = ctx.from.id;
    const user = await db.getUser(userId);
    
    if (user.credit < 2) {
      return ctx.answerCbQuery('❌ Credit Anda tidak cukup! Minimal 2 credit untuk share free.');
    }
    
    await ctx.editMessageText('📤 <b>Share Free</b>\n\nSilakan kirim pesan yang ingin di-share:', {
      parse_mode: 'HTML',
      ...keyboards.backButton('jasher_menu')
    });
    
    // Set state untuk menunggu pesan broadcast
    ctx.session.waitingForBroadcast = true;
    ctx.session.broadcastType = 'free';
  });
  
  bot.action('share_vip', async (ctx) => {
    if (ctx.chat.type !== 'private') {
      return ctx.answerCbQuery('❌ Command ini hanya bisa digunakan di private chat!');
    }
    
    if (!user.is_premium) {
      return ctx.answerCbQuery('❌ Hanya user premium yang bisa menggunakan fitur ini!');
    }
    
    const userId = ctx.from.id;
    const user = await db.getUser(userId);
    
    if (user.credit < 5) {
      return ctx.answerCbQuery('❌ Credit Anda tidak cukup! Minimal 5 credit untuk share VIP.');
    }
    
    await ctx.editMessageText('💎 <b>Share VIP</b>\n\nSilakan kirim pesan yang ingin di-share:', {
      parse_mode: 'HTML',
      ...keyboards.backButton('jasher_menu')
    });
    
    // Set state untuk menunggu pesan broadcast
    ctx.session.waitingForBroadcast = true;
    ctx.session.broadcastType = 'vip';
  });
  
  // Owner actions
  bot.action('add_premium', async (ctx) => {
    if (String(ctx.from.id) !== process.env.OWNER_ID) {
      return ctx.answerCbQuery('❌ Hanya owner yang bisa mengakses menu ini!');
    }
    
    await ctx.editMessageText('👑 <b>Add Premium User</b>\n\nSilakan kirim user ID yang ingin ditambahkan sebagai premium:', {
      parse_mode: 'HTML',
      ...keyboards.backButton('owner_menu')
    });
    
    ctx.session.waitingForPremiumAdd = true;
  });
  
  bot.action('remove_premium', async (ctx) => {
    if (String(ctx.from.id) !== process.env.OWNER_ID) {
      return ctx.answerCbQuery('❌ Hanya owner yang bisa mengakses menu ini!');
    }
    
    await ctx.editMessageText('🚫 <b>Remove Premium User</b>\n\nSilakan kirim user ID yang ingin dihapus dari premium:', {
      parse_mode: 'HTML',
      ...keyboards.backButton('owner_menu')
    });
    
    ctx.session.waitingForPremiumRemove = true;
  });
  
  bot.action('list_premium', async (ctx) => {
    if (String(ctx.from.id) !== process.env.OWNER_ID) {
      return ctx.answerCbQuery('❌ Hanya owner yang bisa mengakses menu ini!');
    }
    
    const premiumUsers = await db.getPremiumUsers();
    
    if (premiumUsers.length === 0) {
      return ctx.editMessageText('📋 <b>Premium Users List</b>\n\nTidak ada user premium.', {
        parse_mode: 'HTML',
        ...keyboards.backButton('owner_menu')
      });
    }
    
    let message = '📋 <b>Premium Users List</b>\n\n';
    premiumUsers.forEach((user, index) => {
      message += `${index + 1}. @${user.username || 'No username'} (ID: ${user.user_id})\n`;
    });
    
    await ctx.editMessageText(message, {
      parse_mode: 'HTML',
      ...keyboards.backButton('owner_menu')
    });
  });
  
  bot.action('owner_broadcast', async (ctx) => {
    if (String(ctx.from.id) !== process.env.OWNER_ID) {
      return ctx.answerCbQuery('❌ Hanya owner yang bisa mengakses menu ini!');
    }
    
    await ctx.editMessageText('📢 <b>Owner Broadcast</b>\n\nSilakan kirim pesan yang ingin di-broadcast ke semua user:', {
      parse_mode: 'HTML',
      ...keyboards.backButton('owner_menu')
    });
    
    ctx.session.waitingForOwnerBroadcast = true;
  });
  
  // Handle text messages for various states
  bot.on('text', async (ctx) => {
    if (ctx.session.waitingForBroadcast) {
      const userId = ctx.from.id;
      const user = await db.getUser(userId);
      const message = ctx.message.text;
      const broadcastType = ctx.session.broadcastType;
      const creditCost = broadcastType === 'free' ? 2 : 5;
      
      // Kurangi credit user
      const success = await db.updateUserCredit(userId, -creditCost);
      
      if (!success) {
        return ctx.reply('❌ Gagal memotong credit. Silakan coba lagi.');
      }
      
      // Simpan broadcast ke database
      const broadcastId = await db.addBroadcast(userId, message, creditCost);
      
      // Kirim konfirmasi
      await ctx.replyWithHTML(`✅ <b>Pesan berhasil dikirim untuk di-broadcast!</b>\n\nCredit berkurang: ${creditCost}\nSisa credit: ${user.credit - creditCost}`);
      
      // Reset state
      ctx.session.waitingForBroadcast = false;
      ctx.session.broadcastType = null;
      
      // Proses broadcast (dalam implementasi nyata, ini akan dijalankan oleh worker)
      // processBroadcast(broadcastId, broadcastType);
      
    } else if (ctx.session.waitingForPremiumAdd) {
      if (String(ctx.from.id) !== process.env.OWNER_ID) {
        ctx.session.waitingForPremiumAdd = false;
        return;
      }
      
      const userId = parseInt(ctx.message.text);
      if (isNaN(userId)) {
        return ctx.reply('❌ Format user ID tidak valid. Harus angka.');
      }
      
      const success = await db.setPremium(userId, true);
      
      if (success) {
        await ctx.reply(`✅ User dengan ID ${userId} berhasil ditambahkan sebagai premium.`);
      } else {
        await ctx.reply(`❌ Gagal menambahkan user sebagai premium. Pastikan user ID valid.`);
      }
      
      ctx.session.waitingForPremiumAdd = false;
      
    } else if (ctx.session.waitingForPremiumRemove) {
      if (String(ctx.from.id) !== process.env.OWNER_ID) {
        ctx.session.waitingForPremiumRemove = false;
        return;
      }
      
      const userId = parseInt(ctx.message.text);
      if (isNaN(userId)) {
        return ctx.reply('❌ Format user ID tidak valid. Harus angka.');
      }
      
      const success = await db.setPremium(userId, false);
      
      if (success) {
        await ctx.reply(`✅ User dengan ID ${userId} berhasil dihapus dari premium.`);
      } else {
        await ctx.reply(`❌ Gagal menghapus user dari premium. Pastikan user ID valid.`);
      }
      
      ctx.session.waitingForPremiumRemove = false;
      
    } else if (ctx.session.waitingForOwnerBroadcast) {
      if (String(ctx.from.id) !== process.env.OWNER_ID) {
        ctx.session.waitingForOwnerBroadcast = false;
        return;
      }
      
      const message = ctx.message.text;
      const users = await db.getAllUsers();
      
      await ctx.reply(`📢 Memulai broadcast ke ${users.length} user...`);
      
      // Broadcast ke semua user (dalam implementasi nyata, ini akan dijalankan secara async)
      let successCount = 0;
      let failCount = 0;
      
      for (const user of users) {
        try {
          await ctx.telegram.sendMessage(user.user_id, `📢 <b>Broadcast dari Owner:</b>\n\n${message}`, {
            parse_mode: 'HTML'
          });
          successCount++;
        } catch (error) {
          console.error(`Gagal mengirim broadcast ke user ${user.user_id}:`, error);
          failCount++;
        }
        
        // Delay untuk menghindari rate limit
        await new Promise(resolve => setTimeout(resolve, 100));
      }
      
      await ctx.reply(`✅ Broadcast selesai!\nBerhasil: ${successCount}\nGagal: ${failCount}`);
      
      ctx.session.waitingForOwnerBroadcast = false;
    }
  });
  
  // Handle when bot is added to a group
  bot.on('chat_join_request', async (ctx) => {
    try {
      const chat = ctx.update.chat_join_request.chat;
      const user = ctx.update.chat_join_request.from;
      
      // Tambahkan group ke database
      await db.addGroup({
        id: chat.id,
        title: chat.title,
        username: chat.username,
        member_count: 0 // Tidak bisa mendapatkan member count dari join request
      });
      
      // Update user's joined groups count
      await db.updateUserGroups(user.id, 1);
      
      const userData = await db.getUser(user.id);
      
      // Berikan bonus credit jika sudah menambahkan 3 group
      if (userData.joined_groups % 3 === 0) {
        await db.updateUserCredit(user.id, 10);
        await ctx.telegram.sendMessage(
          user.id, 
          `🎉 Terima kasih telah menambahkan bot ke group ke-${userData.joined_groups}! Anda mendapatkan bonus 10 credit.`
        );
      }
      
      console.log(`Bot ditambahkan ke group: ${chat.title} (${chat.id}) oleh user: ${user.id}`);
    } catch (error) {
      console.error('Error handling chat join request:', error);
    }
  });
}

module.exports = { setupCommands };