const { Markup } = require('telegraf');
const { User, Group, Broadcast } = require('../lib/database');
const { formatUserInfo } = require('./utils');

async function handleStart(ctx) {
  try {
    let user = await User.findOne({ userId: ctx.from.id });
    
    if (!user) {
      user = new User({
        userId: ctx.from.id,
        username: ctx.from.username,
        firstName: ctx.from.first_name,
        lastName: ctx.from.last_name,
        credit: 0
      });
      await user.save();
    }
    
    const menuText = formatUserInfo(ctx, user);
    const menuButtons = Markup.inlineKeyboard([
      [Markup.button.callback('🎯 Jasher Menu', 'jasher_menu')],
      [Markup.button.callback('👤 Owner Menu', 'owner_menu')],
      [Markup.button.url('➕ Add Group', 'https://t.me/jasherpremtia_Bot?startgroup=true')]
    ]);
    
    await ctx.replyWithPhoto('https://f.top4top.io/p_3530xky9e4.jpg', {
      caption: menuText,
      parse_mode: 'HTML',
      ...menuButtons
    });
  } catch (error) {
    console.error('Error in start command:', error);
    ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleHelp(ctx) {
  const helpText = `🤖 *Jasher Bot Help*

🔹 *Credit System*
- Dapatkan 10 kredit dengan menambahkan bot ke 3 grup
- Share broadcast: -2 kredit
- Share VIP: -5 kredit (lebih cepat)

🔹 *Perintah*
/start - Memulai bot
/help - Bantuan
/credit - Cek kredit
/share - Share pesan (hanya di private chat)
/sharevip - Share VIP (hanya di private chat)

🔹 *Owner Only*
/addprem - Tambah user premium
/delprem - Hapus user premium
/listprem - List user premium
/broadcast - Broadcast ke semua user`;
  
  await ctx.reply(helpText, { parse_mode: 'Markdown' });
}

async function handleCredit(ctx) {
  try {
    const user = await User.findOne({ userId: ctx.from.id });
    if (!user) return ctx.reply('Anda belum terdaftar. Ketik /start untuk mendaftar.');
    
    await ctx.reply(`💳 Kredit Anda: ${user.credit}`);
  } catch (error) {
    console.error('Error in credit command:', error);
    ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleShare(ctx) {
  try {
    if (ctx.chat.type !== 'private') {
      return ctx.reply('Perintah ini hanya bisa digunakan di private chat.');
    }
    
    const user = await User.findOne({ userId: ctx.from.id });
    if (!user) return ctx.reply('Anda belum terdaftar. Ketik /start untuk mendaftar.');
    
    if (user.credit < 2) {
      return ctx.reply('Kredit tidak cukup. Minimal 2 kredit untuk share. Tambah bot ke 3 grup untuk mendapatkan kredit.');
    }
    
    const messageToShare = ctx.message.reply_to_message || ctx.message;
    if (!messageToShare.text && !messageToShare.caption) {
      return ctx.reply('Balas pesan yang ingin di-share atau ketik pesan setelah perintah /share.');
    }
    
    const shareText = messageToShare.text || messageToShare.caption;
    
    // Simpan broadcast
    const broadcast = new Broadcast({
      messageId: messageToShare.message_id,
      senderId: ctx.from.id,
      text: shareText
    });
    await broadcast.save();
    
    // Kurangi kredit
    user.credit -= 2;
    await user.save();
    
    // Kirim ke semua grup
    const groups = await Group.find({});
    let successCount = 0;
    
    for (const group of groups) {
      try {
        await ctx.telegram.sendMessage(group.groupId, `📢 *Broadcast:*\n\n${shareText}`, {
          parse_mode: 'Markdown'
        });
        successCount++;
      } catch (error) {
        console.error(`Gagal mengirim ke grup ${group.groupId}:`, error);
      }
    }
    
    await ctx.reply(`✅ Broadcast berhasil dikirim ke ${successCount} grup. Kredit berkurang 2. Sisa kredit: ${user.credit}`);
  } catch (error) {
    console.error('Error in share command:', error);
    ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleShareVip(ctx) {
  try {
    if (ctx.chat.type !== 'private') {
      return ctx.reply('Perintah ini hanya bisa digunakan di private chat.');
    }
    
    const user = await User.findOne({ userId: ctx.from.id });
    if (!user) return ctx.reply('Anda belum terdaftar. Ketik /start untuk mendaftar.');
    
    if (!user.isPremium) {
      return ctx.reply('Fitur ini hanya untuk user premium. Hubungi owner untuk menjadi premium.');
    }
    
    if (user.credit < 5) {
      return ctx.reply('Kredit tidak cukup. Minimal 5 kredit untuk share VIP.');
    }
    
    const messageToShare = ctx.message.reply_to_message || ctx.message;
    if (!messageToShare.text && !messageToShare.caption) {
      return ctx.reply('Balas pesan yang ingin di-share atau ketik pesan setelah perintah /sharevip.');
    }
    
    const shareText = messageToShare.text || messageToShare.caption;
    
    // Simpan broadcast
    const broadcast = new Broadcast({
      messageId: messageToShare.message_id,
      senderId: ctx.from.id,
      text: shareText
    });
    await broadcast.save();
    
    // Kurangi kredit
    user.credit -= 5;
    await user.save();
    
    // Kirim ke semua grup (lebih cepat dengan paralel)
    const groups = await Group.find({});
    let successCount = 0;
    const promises = [];
    
    for (const group of groups) {
      promises.push(
        ctx.telegram.sendMessage(group.groupId, `🚀 *Broadcast VIP:*\n\n${shareText}`, {
          parse_mode: 'Markdown'
        }).then(() => {
          successCount++;
        }).catch(error => {
          console.error(`Gagal mengirim ke grup ${group.groupId}:`, error);
        })
      );
    }
    
    await Promise.all(promises);
    
    await ctx.reply(`✅ Broadcast VIP berhasil dikirim ke ${successCount} grup. Kredit berkurang 5. Sisa kredit: ${user.credit}`);
  } catch (error) {
    console.error('Error in sharevip command:', error);
    ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

// Owner commands
async function handleAddPrem(ctx) {
  try {
    if (ctx.from.id.toString() !== global.OWNER_ID) {
      return ctx.reply('Perintah ini hanya untuk owner.');
    }
    
    const targetUserId = ctx.message.text.split(' ')[1];
    if (!targetUserId) return ctx.reply('Gunakan: /addprem <user_id>');
    
    const user = await User.findOneAndUpdate(
      { userId: targetUserId },
      { isPremium: true },
      { new: true, upsert: true }
    );
    
    await ctx.reply(`✅ User ${targetUserId} sekarang premium.`);
  } catch (error) {
    console.error('Error in addprem command:', error);
    ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleDelPrem(ctx) {
  try {
    if (ctx.from.id.toString() !== global.OWNER_ID) {
      return ctx.reply('Perintah ini hanya untuk owner.');
    }
    
    const targetUserId = ctx.message.text.split(' ')[1];
    if (!targetUserId) return ctx.reply('Gunakan: /delprem <user_id>');
    
    const user = await User.findOneAndUpdate(
      { userId: targetUserId },
      { isPremium: false },
      { new: true }
    );
    
    if (!user) return ctx.reply('User tidak ditemukan.');
    
    await ctx.reply(`✅ User ${targetUserId} dihapus dari premium.`);
  } catch (error) {
    console.error('Error in delprem command:', error);
    ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleListPrem(ctx) {
  try {
    if (ctx.from.id.toString() !== global.OWNER_ID) {
      return ctx.reply('Perintah ini hanya untuk owner.');
    }
    
    const premiumUsers = await User.find({ isPremium: true });
    if (premiumUsers.length === 0) return ctx.reply('Tidak ada user premium.');
    
    let listText = '👑 *Daftar User Premium:*\n\n';
    premiumUsers.forEach((user, index) => {
      listText += `${index + 1}. ID: ${user.userId} | Username: @${user.username || 'N/A'} | Kredit: ${user.credit}\n`;
    });
    
    await ctx.reply(listText, { parse_mode: 'Markdown' });
  } catch (error) {
    console.error('Error in listprem command:', error);
    ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

async function handleBroadcast(ctx) {
  try {
    if (ctx.from.id.toString() !== global.OWNER_ID) {
      return ctx.reply('Perintah ini hanya untuk owner.');
    }
    
    const broadcastMessage = ctx.message.reply_to_message || ctx.message;
    if (!broadcastMessage.text && !broadcastMessage.caption) {
      return ctx.reply('Balas pesan yang ingin di-broadcast atau ketik pesan setelah perintah /broadcast.');
    }
    
    const broadcastText = broadcastMessage.text || broadcastMessage.caption;
    const users = await User.find({});
    
    let successCount = 0;
    const promises = [];
    
    for (const user of users) {
      promises.push(
        ctx.telegram.sendMessage(user.userId, `📢 *Broadcast dari Owner:*\n\n${broadcastText}`, {
          parse_mode: 'Markdown'
        }).then(() => {
          successCount++;
        }).catch(error => {
          console.error(`Gagal mengirim ke user ${user.userId}:`, error);
        })
      );
    }
    
    await Promise.all(promises);
    
    await ctx.reply(`✅ Broadcast berhasil dikirim ke ${successCount} user.`);
  } catch (error) {
    console.error('Error in broadcast command:', error);
    ctx.reply('Terjadi kesalahan, silakan coba lagi.');
  }
}

module.exports = {
  handleStart,
  handleHelp,
  handleCredit,
  handleShare,
  handleShareVip,
  handleAddPrem,
  handleDelPrem,
  handleListPrem,
  handleBroadcast
};