const { Telegraf } = require('telegraf');
const { isPremium, isOwner, log } = require('../../lib/functions');

module.exports = (bot, users, groups, premium, blacklist) => {
    
    // Global error handler untuk callback queries
    bot.on('callback_query', async (ctx) => {
        try {
            await ctx.answerCbQuery(); // Selalu jawab callback query
            
            const action = ctx.callbackQuery.data;
            const userId = ctx.from.id;
            
            log(`Callback action: ${action} from user ${userId}`);
            
            // Handle actions berdasarkan prefix
            if (action.startsWith('premium_')) {
                await handlePremiumActions(ctx, action);
            } else if (action.startsWith('obf_')) {
                await handleObfuscationActions(ctx, action);
            } else if (action.startsWith('admin_')) {
                await handleAdminActions(ctx, action);
            }
            
        } catch (error) {
            log('Error in callback handler:', error);
            try {
                await ctx.answerCbQuery('❌ Terjadi error!', true);
                await ctx.replyWithMarkdown('❌ *Error:* Terjadi kesalahan sistem!');
            } catch (e) {
                log('Error sending error message:', e);
            }
        }
    });

    // Handler untuk aksi premium
    async function handlePremiumActions(ctx, action) {
        const userId = ctx.from.id.toString();
        
        switch (action) {
            case 'premium_buy_1':
                await handlePremiumPurchase(ctx, 1, 5000);
                break;
            case 'premium_buy_7':
                await handlePremiumPurchase(ctx, 7, 25000);
                break;
            case 'premium_buy_30':
                await handlePremiumPurchase(ctx, 30, 80000);
                break;
            case 'premium_buy_permanent':
                await handlePremiumPurchase(ctx, 3650, 300000); // 10 tahun
                break;
            default:
                await ctx.replyWithMarkdown('❌ *Error:* Aksi premium tidak dikenali!');
        }
    }

    async function handlePremiumPurchase(ctx, days, price) {
        const userId = ctx.from.id;
        
        await ctx.replyWithMarkdown(`
╭─❒ 「 💳 PEMBELIAN PREMIUM 」 
├ Paket : ${days} Hari
├ Harga : Rp ${price.toLocaleString()}
├ Metode : Transfer Bank
╰❒
📋 *Instruksi Pembayaran:*

1. Transfer ke rekening:
   🏦 BCA: 1234567890
   👤 A/N: JASHER PREMIUM

2. Setelah transfer, kirim bukti dengan:
   /bukti ${days} BCA

3. Premium akan diaktifkan dalam 1x24 jam
   setelah konfirmasi pembayaran.

⚠️ *Pastikan mengirim bukti transfer yang jelas!*`);
    }

    // Handler untuk aksi obfuscation
    async function handleObfuscationActions(ctx, action) {
        switch (action) {
            case 'obf_help':
                await ctx.replyWithMarkdown(`
🔧 *Panduan Obfuscation:*

1. *Persiapan File:*
   - File harus berekstensi .js
   - Pastikan kode JavaScript valid
   - Maksimal ukuran file: 20MB

2. *Cara Menggunakan:*
   - Kirim file .js ke bot
   - Reply file dengan command obfuscation
   - Tunggu proses selesai

3. *Jenis Obfuscation:*
   - *enc3*: Mandarin Encryption (Tinggi)
   - *enc4*: Arab Encryption (Tinggi) 
   - *japan*: Japan Encryption (Tinggi)
   - *zenc*: Invisible Encryption (Sangat Tinggi)
   - *var*: Var Encryption (Medium)
   - *nebula*: Nebula Encryption (Sangat Tinggi)
   - *enc5*: Calcrick Encryption (Extreme)
   - *quantum*: Quantum Encryption (Experimental)
   - *enc*: Time-Locked (Dengan expiry)
   - *enc2*: Custom Encryption

💡 *Tips:* Gunakan quantum/nebula untuk keamanan maksimal!`);
                break;
                
            case 'obf_examples':
                await ctx.replyWithMarkdown(`
📝 *Contoh Penggunaan:*

1. *Basic Obfuscation:*
   \`\`\`
   Kirim file example.js
   Reply dengan: /enc3
   \`\`\`

2. *Time-Locked Encryption:*
   \`\`\`
   Kirim file script.js
   Reply dengan: /enc 30
   (Aktif 30 hari saja)
   \`\`\`

3. *Custom Encryption:*
   \`\`\`
   Kirim file bot.js
   Reply dengan: /enc2 mybot
   \`\`\`

4. *Deobfuscate:*
   \`\`\`
   Kirim file encrypted.js
   Reply dengan: /deobfuscate
   \`\`\`

⚠️ *Note:* Hasil obfuscation mungkin meningkatkan ukuran file.`);
                break;
                
            default:
                await ctx.replyWithMarkdown('❌ *Error:* Aksi obfuscation tidak dikenali!');
        }
    }

    // Handler untuk aksi admin
    async function handleAdminActions(ctx, action) {
        if (!isOwner(ctx.from.id)) {
            await ctx.replyWithMarkdown('❌ *Error:* Hanya owner yang bisa mengakses fitur ini!');
            return;
        }

        switch (action) {
            case 'admin_stats_detail':
                await showDetailedStats(ctx);
                break;
            case 'admin_backup':
                await backupData(ctx);
                break;
            case 'admin_restart':
                await restartBot(ctx);
                break;
            default:
                await ctx.replyWithMarkdown('❌ *Error:* Aksi admin tidak dikenali!');
        }
    }

    async function showDetailedStats(ctx) {
        const activeUsers = Array.from(users).length;
        const activeGroups = Array.from(groups.values()).filter(g => g.active).length;
        const activePremium = Array.from(premium.values()).filter(p => p.expiry > Date.now()).length;
        
        let premiumStats = '';
        let count = 0;
        
        for (const [userId, data] of premium) {
            if (count >= 10) break;
            const expiry = new Date(data.expiry).toLocaleDateString();
            premiumStats += `├ ${userId} - ${data.days}hr - ${expiry}\n`;
            count++;
        }

        await ctx.replyWithMarkdown(`
╭─❒ 「 📊 DETAILED STATS 」 
├ Users: ${activeUsers}
├ Groups: ${activeGroups} (${groups.size} total)
├ Premium: ${activePremium}
├ Blacklist: ${blacklist.size}
╰❒
📈 *Top 10 Premium Users:*
${premiumStats || '├ Tidak ada data'}
╰❒`);
    }

    async function backupData(ctx) {
        await ctx.replyWithMarkdown('🔄 *Memulai backup data...*');
        
        try {
            const db = require('../../lib/database');
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            
            // Simpan semua data
            await db.saveUsers(users);
            await db.saveGroups(groups);
            await db.savePremium(premium);
            await db.saveBlacklist(blacklist);
            
            await ctx.replyWithMarkdown(`
✅ *Backup Berhasil!*
    
Data telah disimpan dengan aman.
Timestamp: ${timestamp}
    
Total data:
- Users: ${users.size}
- Groups: ${groups.size} 
- Premium: ${premium.size}
- Blacklist: ${blacklist.size}`);
                
        } catch (error) {
            log('Backup error:', error);
            await ctx.replyWithMarkdown('❌ *Error:* Gagal melakukan backup!');
        }
    }

    async function restartBot(ctx) {
        await ctx.replyWithMarkdown('🔄 *Restarting bot...*');
        
        // Simpan data sebelum restart
        const db = require('../../lib/database');
        await db.saveUsers(users);
        await db.saveGroups(groups);
        await db.savePremium(premium);
        await db.saveBlacklist(blacklist);
        
        setTimeout(() => {
            process.exit(0);
        }, 2000);
    }

    // Handler untuk tombol kembali yang umum
    bot.action(/back_/, async (ctx) => {
        const [, menu] = ctx.callbackQuery.data.split('_');
        
        switch (menu) {
            case 'main':
                // Kembali ke menu utama
                const mainMenu = require('../commands/user');
                // Panggil fungsi menu utama
                break;
            case 'premium':
                // Kembali ke menu premium
                break;
            case 'obf':
                // Kembali ke menu obfuscation
                break;
            default:
                await ctx.replyWithMarkdown('🔙 *Kembali ke menu utama...*');
        }
        
        await ctx.answerCbQuery();
    });
};