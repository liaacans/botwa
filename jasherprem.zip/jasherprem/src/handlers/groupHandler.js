const { Markup } = require('telegraf');
const { log } = require('../../lib/utils');
const { addGroup, getGroup, removeGroup, getUser, updateUserGroups } = require('../../lib/database');

module.exports = (bot) => {
    // Handle group events dan management

    // Auto-detect ketika bot ditambahkan ke group
    bot.on('new_chat_members', async (ctx) => {
        const newMembers = ctx.message.new_chat_members;
        
        // Cek jika bot yang ditambahkan
        if (newMembers.some(member => member.id === ctx.botInfo.id)) {
            const groupId = ctx.chat.id;
            const groupName = ctx.chat.title;
            const addedBy = ctx.from.id;

            // Tambah group ke database
            addGroup(groupId, {
                title: groupName,
                username: ctx.chat.username,
                added_by: addedBy,
                added_date: new Date().toISOString()
            });

            // Welcome message
            await ctx.reply(
                `🤖 *Terima kasih telah menambahkan ${ctx.botInfo.first_name}!*\n\n` +
                `✨ *Fitur yang tersedia:*\n` +
                `• Obfuscation JavaScript\n` +
                `• Group protection\n` +
                `• Share system\n` +
                `• Premium features\n\n` +
                `📋 *Cara menggunakan:*\n` +
                `1. Gunakan /addgroup untuk mendaftarkan group\n` +
                `2. Gunakan /menu untuk melihat fitur\n` +
                `3. Untuk obfuscation, gunakan di private chat\n\n` +
                `👨‍💻 *Support:* @${ctx.botInfo.username}`,
                { 
                    parse_mode: 'Markdown',
                    ...Markup.inlineKeyboard([
                        [Markup.button.url('📱 Private Chat', `https://t.me/${ctx.botInfo.username}?start=group_${groupId}`)]
                    ])
                }
            );

            log(`Bot ditambahkan ke group: ${groupName} (${groupId}) oleh ${ctx.from.first_name} (${addedBy})`);
        }

        // Welcome new members (kecuali bot)
        const humanMembers = newMembers.filter(member => !member.is_bot);
        if (humanMembers.length > 0) {
            for (const member of humanMembers) {
                await ctx.reply(
                    `👋 Selamat datang *${member.first_name}* di ${ctx.chat.title}!\n\n` +
                    `Jangan lupa baca rules group dan enjoy! 🎉`,
                    { parse_mode: 'Markdown' }
                );
            }
        }
    });

    // Handle ketika bot dikeluarkan dari group
    bot.on('left_chat_member', async (ctx) => {
        if (ctx.message.left_chat_member.id === ctx.botInfo.id) {
            const groupId = ctx.chat.id;
            const groupName = ctx.chat.title;

            // Hapus group dari database
            removeGroup(groupId);

            log(`Bot dikeluarkan dari group: ${groupName} (${groupId})`);
        }
    });

    // Handle group migration (supergroup upgrade)
    bot.on('migrate_to_chat_id', async (ctx) => {
        const oldGroupId = ctx.chat.id;
        const newGroupId = ctx.message.migrate_to_chat_id;

        const group = getGroup(oldGroupId);
        if (group) {
            // Update group ID di database
            removeGroup(oldGroupId);
            addGroup(newGroupId, {
                ...group,
                migrated_from: oldGroupId,
                migrated_at: new Date().toISOString()
            });

            await ctx.reply(
                `🔄 *Group telah di-upgrade ke supergroup!*\n\n` +
                `Semua settings dan data telah ditransfer.`,
                { parse_mode: 'Markdown' }
            );

            log(`Group migrated: ${oldGroupId} -> ${newGroupId}`);
        }
    });

    // Handle group title changes
    bot.on('new_chat_title', async (ctx) => {
        const groupId = ctx.chat.id;
        const newTitle = ctx.message.new_chat_title;
        const group = getGroup(groupId);

        if (group) {
            // Update group title di database
            group.title = newTitle;
            group.updated_at = new Date().toISOString();

            log(`Group title changed: ${group.title} -> ${newTitle} (${groupId})`);
        }
    });

    // Handle group photo changes
    bot.on('new_chat_photo', async (ctx) => {
        const groupId = ctx.chat.id;
        const group = getGroup(groupId);

        if (group) {
            group.photo_updated = new Date().toISOString();
            log(`Group photo updated: ${group.title} (${groupId})`);
        }
    });

    // Advanced group protection system
    bot.on('message', async (ctx) => {
        if (ctx.chat.type === 'private') return;

        await handleGroupProtection(ctx);
    });

    // Group protection handler
    async function handleGroupProtection(ctx) {
        const message = ctx.message;
        const groupId = ctx.chat.id;
        const group = getGroup(groupId);

        // Skip jika group tidak terdaftar atau message dari admin
        if (!group) return;

        try {
            const member = await ctx.getChatMember(ctx.from.id);
            const isAdmin = ['administrator', 'creator'].includes(member.status);
            
            if (isAdmin) return; // Skip protection untuk admin

            // Anti-Spam Protection
            await handleAntiSpam(ctx, group);

            // Anti-Link Protection
            await handleAntiLink(ctx, group);

            // Anti-Forward Protection
            await handleAntiForward(ctx, group);

            // Anti-Contact Protection
            await handleAntiContact(ctx, group);

            // Anti-Hashtag Protection
            await handleAntiHashtag(ctx, group);

            // Anti-Command Protection
            await handleAntiCommand(ctx, group);

        } catch (error) {
            log(`Error in group protection: ${error.message}`);
        }
    }

    async function handleAntiSpam(ctx, group) {
        // Implementasi dasar anti-spam
        const userId = ctx.from.id;
        const now = Date.now();
        const spamWindow = 10000; // 10 seconds
        const maxMessages = 5; // Max 5 messages in 10 seconds

        if (!group.spamTracker) {
            group.spamTracker = new Map();
        }

        if (!group.spamTracker.has(userId)) {
            group.spamTracker.set(userId, {
                messages: 1,
                firstMessage: now,
                lastMessage: now
            });
        } else {
            const userTracker = group.spamTracker.get(userId);
            
            // Reset jika window sudah lewat
            if (now - userTracker.firstMessage > spamWindow) {
                userTracker.messages = 1;
                userTracker.firstMessage = now;
            } else {
                userTracker.messages++;
                userTracker.lastMessage = now;

                // Jika melebihi batas
                if (userTracker.messages > maxMessages) {
                    await ctx.deleteMessage();
                    await ctx.reply(
                        `🚫 *Anti-Spam Protection*\n\n` +
                        `@${ctx.from.username || ctx.from.first_name} mengirim terlalu banyak pesan!\n` +
                        `Silakan tunggu beberapa saat.`,
                        { parse_mode: 'Markdown' }
                    );
                    
                    log(`Spam detected from ${ctx.from.first_name} in ${group.title}`);
                }
            }
        }
    }

    async function handleAntiLink(ctx, group) {
        const messageText = ctx.message.text || ctx.message.caption || '';
        const links = messageText.match(/(https?:\/\/[^\s]+)/g);

        if (links && links.length > 0) {
            await ctx.deleteMessage();
            await ctx.reply(
                `🔗 *Anti-Link Protection*\n\n` +
                `@${ctx.from.username || ctx.from.first_name} link tidak diizinkan di group ini!`,
                { parse_mode: 'Markdown' }
            );
            
            log(`Link removed from ${ctx.from.first_name} in ${group.title}: ${links[0]}`);
        }
    }

    async function handleAntiForward(ctx, group) {
        if (ctx.message.forward_from || ctx.message.forward_from_chat) {
            await ctx.deleteMessage();
            await ctx.reply(
                `↩️ *Anti-Forward Protection*\n\n` +
                `@${ctx.from.username || ctx.from.first_name} forwarded messages tidak diizinkan!`,
                { parse_mode: 'Markdown' }
            );
        }
    }

    async function handleAntiContact(ctx, group) {
        if (ctx.message.contact) {
            await ctx.deleteMessage();
            await ctx.reply(
                `📞 *Anti-Contact Protection*\n\n` +
                `@${ctx.from.username || ctx.from.first_name} sharing kontak tidak diizinkan!`,
                { parse_mode: 'Markdown' }
            );
        }
    }

    async function handleAntiHashtag(ctx, group) {
        const messageText = ctx.message.text || ctx.message.caption || '';
        const hashtags = messageText.match(/#\w+/g);

        if (hashtags && hashtags.length > 3) { // Max 3 hashtags
            await ctx.deleteMessage();
            await ctx.reply(
                `#️⃣ *Anti-Hashtag Protection*\n\n` +
                `@${ctx.from.username || ctx.from.first_name} terlalu banyak hashtag! (Max: 3)`,
                { parse_mode: 'Markdown' }
            );
        }
    }

    async function handleAntiCommand(ctx, group) {
        const messageText = ctx.message.text || '';
        
        if (messageText.startsWith('/') && !messageText.startsWith('/addgroup')) {
            // Cek jika command dari non-admin
            try {
                const member = await ctx.getChatMember(ctx.from.id);
                if (!['administrator', 'creator'].includes(member.status)) {
                    await ctx.deleteMessage();
                    await ctx.reply(
                        `⚡ *Anti-Command Protection*\n\n` +
                        `@${ctx.from.username || ctx.from.first_name} commands hanya untuk admin!`,
                        { parse_mode: 'Markdown' }
                    );
                }
            } catch (error) {
                // Ignore error
            }
        }
    }

    // Group statistics command
    bot.command('groupstats', async (ctx) => {
        if (ctx.chat.type === 'private') {
            return ctx.reply('❌ Command ini hanya untuk group!');
        }

        const group = getGroup(ctx.chat.id);
        if (!group) {
            return ctx.reply('❌ Group belum terdaftar. Gunakan /addgroup terlebih dahulu.');
        }

        try {
            const chat = await ctx.getChat();
            const membersCount = await ctx.telegram.getChatMembersCount(ctx.chat.id);
            const admins = await ctx.getChatAdministrators();
            const botAdmin = admins.find(admin => admin.user.id === ctx.botInfo.id);

            let statsMessage = `📊 *Group Statistics*\n\n`;
            statsMessage += `🏷️ *Nama:* ${chat.title}\n`;
            statsMessage += `🆔 *ID:* ${ctx.chat.id}\n`;
            statsMessage += `👥 *Members:* ${membersCount}\n`;
            statsMessage += `👑 *Admins:* ${admins.length}\n`;
            statsMessage += `🤖 *Bot Status:* ${botAdmin ? 'Admin' : 'Member'}\n`;
            statsMessage += `📅 *Ditambahkan:* ${new Date(group.added).toLocaleDateString('id-ID')}\n`;
            statsMessage += `👤 *Oleh:* ${group.added_by}\n\n`;

            statsMessage += `🛡️ *Protection Status:*\n`;
            statsMessage += `• Anti-Spam: ✅ Aktif\n`;
            statsMessage += `• Anti-Link: ✅ Aktif\n`;
            statsMessage += `• Anti-Forward: ✅ Aktif\n`;
            statsMessage += `• Anti-Contact: ✅ Aktif\n`;

            await ctx.reply(statsMessage, { parse_mode: 'Markdown' });

        } catch (error) {
            await ctx.reply('❌ Gagal mendapatkan statistik group.');
        }
    });

    // System untuk auto-clean inactive groups
    setInterval(async () => {
        await cleanInactiveGroups(bot);
    }, 24 * 60 * 60 * 1000); // Setiap 24 jam
}

// Function untuk membersihkan group yang tidak aktif
async function cleanInactiveGroups(bot) {
    const { getAllGroups, removeGroup } = require('../../lib/database');
    const groups = getAllGroups();
    const now = Date.now();
    const thirtyDays = 30 * 24 * 60 * 60 * 1000;

    let cleanedCount = 0;

    for (const [groupId, groupData] of Object.entries(groups)) {
        try {
            // Cek jika bot masih di group
            await bot.telegram.getChatMember(groupId, bot.botInfo.id);
            
            // Update last active time
            groupData.last_active = now;
            
        } catch (error) {
            // Jika error, artinya bot tidak ada di group lagi
            if (error.description === 'Bad Request: chat not found' || 
                error.description === 'Forbidden: bot was kicked from the group chat') {
                
                removeGroup(groupId);
                cleanedCount++;
                
                console.log(`Cleaned inactive group: ${groupData.title} (${groupId})`);
            }
        }
    }

    if (cleanedCount > 0) {
        console.log(`Group cleanup completed: ${cleanedCount} groups removed`);
    }
}

module.exports.cleanInactiveGroups = cleanInactiveGroups;