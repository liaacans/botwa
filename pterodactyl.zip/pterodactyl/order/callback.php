<?php
include '../includes/config.php';
include '../includes/functions.php';

// Terima data callback dari YAB-Group
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if ($data && isset($data['ref_kode']) && isset($data['status'])) {
    $refCode = $data['ref_kode'];
    $status = $data['status'];
    
    $database = new Database();
    $db = $database->getConnection();
    
    // Update status transaksi
    $query = "UPDATE transactions SET status = :status WHERE ref_code = :ref_code";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':status', $status);
    $stmt->bindParam(':ref_code', $refCode);
    $stmt->execute();
    
    // Jika pembayaran sukses, buat server
    if ($status == 'success') {
        // Dapatkan data transaksi
        $query = "SELECT * FROM transactions WHERE ref_code = :ref_code";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':ref_code', $refCode);
        $stmt->execute();
        $transaction = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($transaction) {
            // Dapatkan data user
            $query = "SELECT * FROM users WHERE id = :user_id";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':user_id', $transaction['user_id']);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user) {
                // Tentukan spesifikasi berdasarkan paket
                $packages = [
                    '2gb' => ['ram' => 2048, 'disk' => 20480, 'cpu' => 100],
                    '3gb' => ['ram' => 3072, 'disk' => 30720, 'cpu' => 150],
                    '4gb' => ['ram' => 4096, 'disk' => 40960, 'cpu' => 200],
                    '5gb' => ['ram' => 5120, 'disk' => 51200, 'cpu' => 250],
                    '6gb' => ['ram' => 6144, 'disk' => 61440, 'cpu' => 300],
                    '7gb' => ['ram' => 7168, 'disk' => 71680, 'cpu' => 350],
                    '8gb' => ['ram' => 8192, 'disk' => 81920, 'cpu' => 400],
                    '9gb' => ['ram' => 9216, 'disk' => 92160, 'cpu' => 450],
                    '10gb' => ['ram' => 10240, 'disk' => 102400, 'cpu' => 500]
                ];
                
                if (array_key_exists($transaction['package'], $packages)) {
                    $specs = $packages[$transaction['package']];
                    
                    // Buat server
                    $server = createPterodactylServer($user['ptero_user_id'], $user['username'], $specs['ram'], $specs['disk'], $specs['cpu']);
                    
                    if ($server) {
                        $serverId = $server['attributes']['id'];
                        
                        // Update user dengan server ID dan package
                        $query = "UPDATE users SET ptero_server_id = :server_id, package = :package WHERE id = :user_id";
                        $stmt = $db->prepare($query);
                        $stmt->bindParam(':server_id', $serverId);
                        $stmt->bindParam(':package', $transaction['package']);
                        $stmt->bindParam(':user_id', $user['id']);
                        $stmt->execute();
                        
                        // Kirim email notifikasi
                        $subject = "Server Panel Pterodactyl Anda Telah Aktif";
                        $message = "
                        <h2>Selamat! Server Anda telah aktif.</h2>
                        <p>Detail server Anda:</p>
                        <ul>
                            <li><strong>Paket:</strong> " . $transaction['package'] . "</li>
                            <li><strong>RAM:</strong> " . number_format($specs['ram'] / 1024, 1) . " GB</li>
                            <li><strong>Disk:</strong> " . number_format($specs['disk'] / 1024, 1) . " GB</li>
                            <li><strong>CPU:</strong> " . $specs['cpu'] . "%</li>
                            <li><strong>URL Panel:</strong> " . DOMAIN . "/server/" . $serverId . "</li>
                        </ul>
                        <p>Silakan login untuk mengelola server Anda.</p>
                        ";
                        
                        sendEmail($user['email'], $subject, $message);
                    }
                }
            }
        }
    }
    
    // Beri respon ke YAB-Group
    http_response_code(200);
    echo json_encode(['status' => 'success']);
} else {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid callback data']);
}
?>