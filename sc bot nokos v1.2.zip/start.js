// createBackupOnEvent aktifkan jika mau backup data nya🗿

const TelegramBot = require('node-telegram-bot-api');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const fsAsync = require('fs').promises;
const archiver = require('archiver');
const QRCode = require('qrcode');
const config = require('./config');
const api = require('./x-apikey');
const CashifyService = require('./x-apikeyv2'); 
const cashifyService = new CashifyService(); 

const bot = new TelegramBot(config.bot_token, {
  polling: { 
    interval: 50,
    params: { 
      timeout: 10,
      allowed_updates: ['message', 'callback_query']
    }
  }
});

const x_apikey = config.apikey;
const x_domain = config.domain;
const owner_ids = config.owner_ids;
const channel = config.channel;

const userSessions = new Map();
const userLastMessage = new Map();
const userFirstTimeNotifications = new Set();
const userSelections = new Map();
const userDepositMessages = new Map();
const userPendingCommands = new Map();
const balanceCache = new Map();
const transactionCache = new Map();
const priceCache = new Map();
const priceHistory = new Map();
const lastNotificationTime = new Map();
const sentNotifications = new Map();
const orderProcessing = new Map();
const depositProcessing = new Map();
let isCheckingPrices = false;

const dataDir = path.join(__dirname, 'database');
const datafile = path.join(dataDir, 'users.json');
const transactionsFile = path.join(dataDir, 'transactions.json');
const balanceFile = path.join(dataDir, 'balances.json');
const settingsFile = path.join(dataDir, 'settings.json');

if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

function loadSettings() {
  try {
    if (!fs.existsSync(settingsFile)) {
      const defaultSettings = {
        maintenance: false,
        maintenance_reason: '',
        maintenance_time: '',
        payment_method: 'rumahotp'
      };
      saveSettings(defaultSettings);
      return defaultSettings;
    }
    return JSON.parse(fs.readFileSync(settingsFile, 'utf8'));
  } catch (e) {
    return {
      maintenance: false,
      maintenance_reason: '',
      maintenance_time: '',
      payment_method: 'cashify'
    };
  }
}

function saveSettings(settings) {
  try {
    fs.writeFileSync(settingsFile, JSON.stringify(settings, null, 2));
    return true;
  } catch (error) {
    return false;
  }
}

function loadBalances() {
  try {
    if (!fs.existsSync(balanceFile)) {
      return {};
    }
    const data = fs.readFileSync(balanceFile, 'utf8');
    const parsed = JSON.parse(data);
    return parsed;
  } catch (e) {
    console.error('Error loading balances:', e);
    return {};
  }
}

function saveBalances(balances) {
  try {
    fs.writeFileSync(balanceFile, JSON.stringify(balances, null, 2));
    return true;
  } catch (error) {
    console.error('Error saving balances:', error);
    return false;
  }
}

function getUserBalance(userId) {
    const userIdStr = String(userId);
    
    if (depositProcessing.has(`${userId}_deposit`)) {
        balanceCache.delete(userIdStr);
    }
    
    if (balanceCache.has(userIdStr)) {
        const cached = balanceCache.get(userIdStr);
        return isNaN(cached) ? 0 : Number(cached);
    }
    
    const balances = loadBalances();
    const balance = parseInt(balances[userIdStr]) || 0;
    const numBalance = isNaN(balance) ? 0 : Number(balance);
    balanceCache.set(userIdStr, numBalance);
    return numBalance;
}

function validateAmount(amount) {
    const numAmount = Number(amount);
    if (isNaN(numAmount) || !isFinite(numAmount)) {
        return { valid: false, error: 'Jumlah tidak valid' };
    }
    if (numAmount <= 0) {
        return { valid: false, error: 'Jumlah harus lebih dari 0' };
    }
    return { valid: true, amount: numAmount };
}

function validateUserId(userId) {
    const userIdStr = String(userId);
    if (!userIdStr || userIdStr.length < 5) {
        return { valid: false, error: 'User ID tidak valid' };
    }
    if (!/^\d+$/.test(userIdStr)) {
        return { valid: false, error: 'User ID harus angka' };
    }
    return { valid: true, userId: userIdStr };
}

function setUserBalance(userId, amount) {
    const userIdStr = String(userId);
    const numAmount = Number(amount);
    if (isNaN(numAmount)) return false;
    
    const balances = loadBalances();
    balances[userIdStr] = numAmount;
    
    balanceCache.set(userIdStr, numAmount);
    
    return saveBalances(balances);
}

function addUserBalance(userId, amount) {
    try {
        const validation = validateAmount(amount);
        if (!validation.valid) return false;
        
        const numAmount = validation.amount;
        const userIdStr = String(userId);
        
        const balances = loadBalances();
        const currentBalance = parseInt(balances[userIdStr]) || 0;
        const numCurrent = isNaN(currentBalance) ? 0 : Number(currentBalance);
        
        const newBalance = numCurrent + numAmount;
        
        balances[userIdStr] = newBalance;
        
        balanceCache.set(userIdStr, newBalance);
        
        return saveBalances(balances);
    } catch (error) {
        return false;
    }
}

function deductUserBalance(userId, amount) {
    try {
        const validation = validateAmount(amount);
        if (!validation.valid) return false;
        
        const numAmount = validation.amount;
        const userIdStr = String(userId);
        
        const balances = loadBalances();
        const currentBalance = parseInt(balances[userIdStr]) || 0;
        const numCurrent = isNaN(currentBalance) ? 0 : Number(currentBalance);
        
        if (numCurrent < numAmount) {
            return false;
        }

        const newBalance = numCurrent - numAmount;
        
        balances[userIdStr] = newBalance;

        balanceCache.set(userIdStr, newBalance);
        
        return saveBalances(balances);
    } catch (error) {
        return false;
    }
}

setInterval(() => {
    const now = Date.now();
    for (const [key, timestamp] of depositProcessing.entries()) {
        if (now - timestamp > 5 * 60 * 1000) {
            depositProcessing.delete(key);
        }
    }
}, 60 * 1000);

function saveJSON(file, data) {
  try {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    return false;
  }
}

function isOrderProcessing(orderId) {
  return orderProcessing.has(orderId);
}

function setOrderProcessing(orderId, processing = true) {
  if (processing) {
    orderProcessing.set(orderId, Date.now());
  } else {
    orderProcessing.delete(orderId);
  }
}

function loadJSON(file) {
  try {
    if (!fs.existsSync(file)) {
      if (file === datafile) return { users: [], settings: { maintenance: false } };
      return {};
    }
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (e) {
    return file === datafile ? { users: [], settings: { maintenance: false } } : {};
  }
}

function loadData() {
  return loadJSON(datafile);
}

function saveData(data) {
  return saveJSON(datafile, data);
}

function saveUser(userId) {
  const data = loadData();
  const userIdStr = String(userId);
  
  if (!data.users) data.users = [];
  
  const userExists = data.users.some(id => id === userIdStr);
  
  if (!userExists) {
    data.users.push(userIdStr);
    saveData(data);
    
    // User baru ditambahkan, fungsi notifyNewUser akan dipanggil
    // dari handler /start untuk memberikan notifikasi
    return {
      success: true,
      isNewUser: true
    };
  }
  
  return {
    success: true,
    isNewUser: false
  };
}

function loadTransactions() {
  const data = loadJSON(transactionsFile);
  return {
    nokos_orders: data.nokos_orders || [],
    rumahotp_deposits: data.rumahotp_deposits || [],
    cashify_deposits: data.cashify_deposits || []
  };
}

function addTransaction(type, data) {
  const transactions = loadTransactions();
  transactions[type] = transactions[type] || [];
 
  if (type === 'nokos_orders') {
    const now = Date.now();
    const fifteenMinutes = 15 * 60 * 1000;
    
    transactions[type] = transactions[type].filter(order => {
      const orderTime = new Date(order.timestamp).getTime();
      
      if ((order.status === 'pending' || order.status === 'active') && 
          (now - orderTime > fifteenMinutes)) {
        return false;
      }
      return true;
    });
  }
  
  const transaction = {
    id: data.id || Math.random().toString(36).substr(2, 9),
    userId: data.userId,
    data: data,
    timestamp: new Date().toISOString(),
    status: data.status || 'pending'
  };
  
  if (type === 'nokos_orders') {
    transaction.data.originalBalance = getUserBalance(data.userId) + (data.price || 0);
  }
  
  transactions[type].push(transaction);
  saveTransactions(transactions);
  return transaction.id;
}

function saveTransactions(transactions) {
  return saveJSON(transactionsFile, transactions);
}

function updateTransactionStatus(type, transactionId, status) {
  const transactions = loadTransactions();
  if (transactions[type]) {
    const transaction = transactions[type].find(t => t.id === transactionId);
    if (transaction) {
      transaction.status = status;
      transaction.data.status = status;
      saveTransactions(transactions);
      return true;
    }
  }
  return false;
}

function cleanExpiredDeposits() {
    try {
        const transactions = loadTransactions();
        const now = Date.now();
        const twentyMinutes = 20 * 60 * 1000;
        
       ['cashify_deposits', 'rumahotp_deposits'].forEach(type => {
    if (transactions[type]) {
        transactions[type] = transactions[type].filter(deposit => {
            const depositTime = new Date(deposit.timestamp).getTime();
            
            return (deposit.status === 'success' || deposit.status === 'paid') || 
                   (now - depositTime < twentyMinutes && (deposit.status === 'pending' || deposit.status === 'waiting'));
        });
    }
});
        
        saveTransactions(transactions);
    } catch (error) {
        console.error('Error cleaning deposits:', error);
    }
}

setInterval(cleanExpiredDeposits, 5 * 60 * 1000);

setInterval(() => {
  balanceCache.clear();
  transactionCache.clear();
}, 10 * 60 * 1000);

function formatCurrency(amount) {
  const numAmount = Number(amount);
  if (isNaN(numAmount) || !isFinite(numAmount)) {
    return 'Rp0';
  }
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0
  }).format(numAmount);
}

function getPaymentMethod() {
  const settings = loadSettings();
  return settings.payment_method || 'rumahotp';
}

function setPaymentMethod(method) {
  const settings = loadSettings();
  settings.payment_method = method;
  saveSettings(settings);
  return method;
}

async function sendNewMessage(chatId, message, options = {}) {
  try {
    const lastMsgId = userLastMessage.get(chatId);
    if (lastMsgId) {
      try {
        bot.deleteMessage(chatId, lastMsgId).catch(() => {});
      } catch (e) {
      }
    }
    
    const newMessage = await bot.sendMessage(chatId, message, {
      parse_mode: 'HTML',
      disable_web_page_preview: true,
      disable_notification: true,
      ...options
    });
    
    userLastMessage.set(chatId, newMessage.message_id);
    return newMessage;
  } catch (error) {
    const newMessage = await bot.sendMessage(chatId, message, {
      parse_mode: 'HTML',
      disable_web_page_preview: true,
      disable_notification: true,
      ...options
    });
    userLastMessage.set(chatId, newMessage.message_id);
    return newMessage;
  }
}

async function editMessage(chatId, messageId, callbackQueryId, message, options = {}) {
  try {
    if (callbackQueryId) {
      bot.answerCallbackQuery(callbackQueryId).catch(() => {});
    }
    
    await bot.editMessageText(message, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML',
      disable_web_page_preview: true,
      ...options
    });
    return true;
  } catch (error) {
    try {
      await sendNewMessage(chatId, message, options);
      return false;
    } catch (e) {
      return false;
    }
  }
}

function isMaintenance() {
  const settings = loadSettings();
  return settings.maintenance === true;
}

function getMaintenanceInfo() {
  const settings = loadSettings();
  if (!settings.maintenance) {
    return { active: false, reason: '' };
  }
  return {
    active: true,
    reason: settings.maintenance_reason || 'Bot sedang dalam perbaikan',
    time: settings.maintenance_time || ''
  };
}

function setMaintenance(active, reason = '') {
  const settings = loadSettings();
  
  settings.maintenance = active;
  if (active) {
    settings.maintenance_reason = reason;
    settings.maintenance_time = new Date().toLocaleString('id-ID');
  } else {
    settings.maintenance_reason = '';
    settings.maintenance_time = '';
  }
  
  saveSettings(settings);
  return active;
}

async function checkMaintenance(msg) {
  const userId = msg.from.id.toString();
  const chatId = msg.chat.id;
  
  const maintenance = getMaintenanceInfo();
  
  if (maintenance.active && !owner_ids.includes(userId)) {
    await bot.sendMessage(chatId,
      `<b>⚠️ Bot Sedang Maintenance</b>

<b>Status:</b> ⛔ Bot tidak bisa digunakan
<b>Alasan:</b> ${maintenance.reason}

<b>Mohon tunggu sampai maintenance selesai.</b>
<b>Owner:</b> @andinsukaapink`,
      { 
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔄 Coba Lagi', callback_data: 'refresh_maintenance' }]
          ]
        }
      }
    );
    return false;
  }
  return true;
}

async function checkChannelMembership(userId) {
  try {
    const chatMember = await bot.getChatMember(channel, userId);
    return ["member", "administrator", "creator"].includes(chatMember.status);
  } catch {
    return false;
  }
}

async function requireJoin(msg) {
  const userId = msg.from.id;
  const isMember = await checkChannelMembership(userId);

  if (!isMember) {
    const originalCommand = msg.text || "/start";
    userPendingCommands.set(userId, originalCommand);

    await sendNewMessage(msg.chat.id, 
`<b>⚠️ Join Channel Terlebih Dahulu</b>

<i>Informasi User</i>
├ Username : <code>${msg.from.first_name}</code>
├ Status   : <code>Tidak termasuk member</code>
└ Akses    : <code>⛔ Terblokir</code>

🔒 <b>Perlu pengecekan akses</b>
└─ Member terlebih dahulu untuk mengakses fitur bot

🔰 <i>Tunggu terlebih dahulu sampai terverifikasi</i>`,

    {
      reply_markup: {
        inline_keyboard: [
          [{ 
            text: "➕ Join Channel", 
            url: `https://t.me/${channel.replace('@','')}` 
          }],
          [{ 
            text: "🔄 Verifikasi Ulang", 
            callback_data: "check_join_again" 
          }]
        ]
      },
      parse_mode: 'HTML'
    });
    return false;
  }
  
  if (userPendingCommands.has(userId)) {
    userPendingCommands.delete(userId);
  }
  
  return true;
}

function withRequireJoin(handler) {
  return async (msg, match) => {
    const ok = await requireJoin(msg);
    if (!ok) return;
    return handler(msg, match);
  };
}

bot.on("callback_query", async (query) => {
  const userId = query.from.id.toString();
  const chatId = query.message.chat.id;

  if (query.data === "check_join_again") {
    await bot.answerCallbackQuery(query.id, {
      text: "Memeriksa kembali...",
      show_alert: false
    });

    const isMember = await checkChannelMembership(userId);

    if (isMember) {
      await bot.deleteMessage(chatId, query.message.message_id).catch(() => {});
      
      await sendNewMessage(chatId, 
`<b>✅ Akses Terverifikasi</b>

<i>Informasi Verifikasi</i>
├ Status : ✅ Terverifikasi
└ Akses  : 🎊 Teridentifikasi

🔓 <b>Selamat menggunakan bot sekarang Anda sudah bisa</b>`,
        { parse_mode: 'HTML' }
      );

      const pendingCommand = userPendingCommands.get(userId);
      if (pendingCommand) {
        const simulatedMsg = {
          ...query.message,
          text: pendingCommand,
          from: query.from,
          chat: { id: chatId }
        };

        if (pendingCommand === "/start") {
          await bot.emit("text", simulatedMsg);
        } else {
          setTimeout(() => {
            bot.emit("text", simulatedMsg);
          }, 500);
        }

        userPendingCommands.delete(userId);
      } else {
        setTimeout(() => {
          bot.emit("text", {
            ...query.message,
            text: "/start",
            from: query.from,
            chat: { id: chatId }
          });
        }, 500);
      }

    } else {
      await editMessage(chatId, query.message.message_id, query.id,
`<b>❌ Tidak Termasuk Member</b>

<i>Informasi Verifikasi</i>
├ Status : ⛔ Tidak termasuk member
└ Akses  : ⛔ Terblokir

🔒 <b>Perlu Pengecekan</b>
└─ Silahkan join channel untuk mengakses fitur bot

🔰 <i>Tunggu terlebih dahulu sampai terverifikasi</i>`,
        {
          reply_markup: {
            inline_keyboard: [
              [{ 
                text: "➕ Join Channel", 
                url: `https://t.me/${channel.replace('@','')}` 
              }],
              [{ 
                text: "🔄 Verifikasi Ulang", 
                callback_data: "check_join_again" 
              }]
            ]
          },
          parse_mode: 'HTML'
        }
      );
    }
  }
});

async function showMainMenu(chatId, userId, user, messageId = null, callbackQueryId = null) {
  try {
    userSelections.delete(userId);
    
    balanceCache.delete(userId.toString());
    
    const userBalance = getUserBalance(userId);
    const data = loadData();
    const transactions = loadTransactions();
    const totalUsers = data.users?.length || 0;
    const successfulOrders = transactions.nokos_orders?.filter(order => {
        if (order.status === 'completed' || order.data?.status === 'completed') {
            return true;
        }
        if (order.data?.otp_code && 
            order.data.otp_code !== '-' && 
            order.data.otp_code !== '' &&
            order.data.otp_code !== null) {
            return true;
        }
        if (order.data?.otp_received === true) {
            return true;
        }
        return false;
    }) || [];
    
    const successfulCashifyDeposits = transactions.cashify_deposits?.filter(deposit => 
        deposit.status === 'success' || deposit.status === 'paid'
    ) || [];
    
    const successfulRumahotpDeposits = transactions.rumahotp_deposits?.filter(deposit => 
        deposit.status === 'success' || deposit.status === 'paid'
    ) || [];
    
    const totalOrders = successfulOrders.length;
    const cashifyDeposits = successfulCashifyDeposits.length; 
    const rumahotpDeposits = successfulRumahotpDeposits.length;
    const totalDeposits = cashifyDeposits + rumahotpDeposits;
    const username = user.username ? `@${user.username}` : 'tidak ada';
    const firstName = user.first_name || 'User';
    const message = `
<b>🛍️ ANDIN STORE</b>

<b>Selamat Datang ${firstName}!</b>
<i>Tempat terbaik untuk layanan OTP</i>

<b>Profil Anda</b>
┌ ID: <code>${userId}</code>
├ Username: ${username}
├ Status: Aktif
└ Saldo: <b>${formatCurrency(userBalance)}</b>

<b>Statistik Bot</b>
┌ Total User: ${totalUsers}
├ Order Sukses: ${totalOrders} 
└ Deposit Sukses: ${totalDeposits}

<b>Pilih menu dibawah:</b>`;

    const keyboard = [
      [
        { text: 'Beli Nokos', callback_data: 'nokos_menu' },
        { text: 'Topup Saldo', callback_data: 'deposit_main' }
      ],
      [
        { text: 'Riwayat Order', callback_data: 'order_history' },
        { text: 'Riwayat Deposit', callback_data: 'deposit_history' }
      ],
      [
        { text: 'CS', url: 'https://t.me/andinsukaapink' },
        { text: 'Channel', url: `https://t.me/${channel.replace('@', '')}` }
      ]
    ];

    if (owner_ids.includes(userId.toString())) {
      keyboard.push([
        { text: 'Owner Menu', callback_data: 'owner_menu' }
      ]);
    }

    const options = {
      reply_markup: { inline_keyboard: keyboard },
      parse_mode: 'HTML',
      disable_web_page_preview: true
    };

    if (messageId && callbackQueryId) {
      await editMessage(chatId, messageId, callbackQueryId, message, options);
    } else if (messageId) {
      await editMessage(chatId, messageId, null, message, options);
    } else {
      await sendNewMessage(chatId, message, options);
    }
  } catch (error) {
    console.error('Error showMainMenu:', error);
  }
}

async function showOwnerMenu(chatId, userId, messageId, callbackQueryId) {
  try {
    if (!owner_ids.includes(userId.toString())) {
      await bot.answerCallbackQuery(callbackQueryId, {
        text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
        show_alert: true
      });
      return;
    }

    const message = `<b>OWNER MENU</b>

<b>Commands yang tersedia:</b>
/broadcast - Kirim pesan ke semua user
/stats - Lihat statistik bot
/setpay - Atur metode pembayaran
/maintenance - Mode maintenance
/addsaldo - Tambah saldo user

<i>Ketik command di chat</i>`;

    const keyboard = [
      [
        { text: 'Kembali', callback_data: 'main_menu' }
      ]
    ];

    await editMessage(chatId, messageId, callbackQueryId, message, {
      reply_markup: { inline_keyboard: keyboard },
      parse_mode: 'HTML'
    });

  } catch (error) {}
}

async function showServerList(chatId, userId, numberId, countryName, messageId, callbackQueryId) {
    try {
        let userSelection = userSelections.get(userId);
        
        if (!userSelection || !userSelection.serviceId) {
            await editMessage(chatId, messageId, callbackQueryId,
                'Sesi Tidak Lengkap\n\nSilakan pilih layanan dari awal.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Mulai Dari Awal', callback_data: 'nokos_menu' }]
                        ]
                    }
                }
            );
            return;
        }
        
        await editMessage(chatId, messageId, callbackQueryId,
            'Memuat server...',
            { parse_mode: 'HTML' }
        );
        
        const countriesData = await api.getCountries(userSelection.serviceId);
        if (!countriesData || !countriesData.success) {
            await editMessage(chatId, messageId, callbackQueryId,
                'Gagal memuat data.\n\nSilakan coba lagi.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Coba Lagi', callback_data: `nokos_service_${userSelection.serviceId}` }]
                        ]
                    }
                }
            );
            return;
        }
        
        const countries = countriesData.data || [];
        const selectedCountry = countries.find(c => c.number_id == numberId);
        
        if (!selectedCountry || !selectedCountry.pricelist || selectedCountry.pricelist.length === 0) {
            await editMessage(chatId, messageId, callbackQueryId,
                `Tidak ada server tersedia untuk ${countryName}.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Pilih Negara Lain', callback_data: `nokos_service_${userSelection.serviceId}` }]
                        ]
                    }
                }
            );
            return;
        }
        
        let servers = selectedCountry.pricelist;
        servers.sort((a, b) => a.price - b.price);

        userSelection.step = 'nokos_server';
        userSelection.numberId = numberId;
        userSelection.countryName = countryName;
        userSelection.countryData = selectedCountry;
        userSelections.set(userId, userSelection);
        
        const countryCode = getCountryCode(selectedCountry.iso_code);
        
        let message = `<b>${countryName}</b>\n`;
        message += `Layanan: ${userSelection.serviceName}\n`;
        message += `Stok: ${selectedCountry.stock_total} nomor\n`;
        message += `Server: ${servers.length} tersedia\n\n`;
        
        const keyboard = [];
        const buttonsPerRow = 3;
        const maxButtons = 15;
        const serversToShow = servers.slice(0, maxButtons);
        
        for (let i = 0; i < serversToShow.length; i += buttonsPerRow) {
            const row = [];
            for (let j = 0; j < buttonsPerRow; j++) {
                if (serversToShow[i + j]) {
                    const server = serversToShow[i + j];
                    const serverNumber = i + j + 1;
                    const buttonText = `S${serverNumber}`;
                    const callbackData = `nokos_server_${server.provider_id}_${server.price}_${server.rate}_${server.stock}`;
                    
                    row.push({ 
                        text: buttonText, 
                        callback_data: callbackData
                    });
                }
            }
            if (row.length > 0) {
                keyboard.push(row);
            }
        }
        
        keyboard.push([
            { text: 'Kembali', callback_data: `nokos_service_${userSelection.serviceId}` },
            { text: 'Menu Utama', callback_data: 'main_menu' }
        ]);
        
        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML'
        });
        
    } catch (error) {
        await editMessage(chatId, messageId, callbackQueryId,
            'Terjadi kesalahan.\n\nSilakan coba lagi.',
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: 'Coba Lagi', callback_data: `nokos_service_${userSelections.get(userId)?.serviceId || 'nokos_menu'}` }]
                    ]
                }
            }
        );
    }
}

async function showServerListEnhanced(chatId, userId, numberId, countryName, messageId, callbackQueryId, startIndex = 0) {
    try {
        let userSelection = userSelections.get(userId);
        
        if (!userSelection || !userSelection.serviceId) {
            await editMessage(chatId, messageId, callbackQueryId,
                'Sesi tidak lengkap.\n\nSilakan pilih layanan dari awal.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Mulai Dari Awal', callback_data: 'nokos_menu' }]
                        ]
                    }
                }
            );
            return;
        }
        
        await editMessage(chatId, messageId, callbackQueryId,
            'Memuat server...',
            { parse_mode: 'HTML' }
        );
        
        const countriesData = await api.getCountries(userSelection.serviceId);
        if (!countriesData || !countriesData.success) {
            await editMessage(chatId, messageId, callbackQueryId,
                'Gagal memuat data.\n\nSilakan coba lagi.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Coba Lagi', callback_data: `nokos_service_${userSelection.serviceId}` }]
                        ]
                    }
                }
            );
            return;
        }
        
        const countries = countriesData.data || [];
        const selectedCountry = countries.find(c => c.number_id == numberId);
        
        if (!selectedCountry || !selectedCountry.pricelist || selectedCountry.pricelist.length === 0) {
            await editMessage(chatId, messageId, callbackQueryId,
                `Tidak ada server tersedia untuk ${countryName}.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Pilih Negara Lain', callback_data: `nokos_service_${userSelection.serviceId}` }]
                        ]
                    }
                }
            );
            return;
        }
        
        let servers = selectedCountry.pricelist;
        servers.sort((a, b) => a.price - b.price);

        userSelection.step = 'nokos_server';
        userSelection.numberId = numberId;
        userSelection.countryName = countryName;
        userSelection.countryData = selectedCountry;
        userSelections.set(userId, userSelection);
        
        const flagEmoji = getFlagEmoji(selectedCountry.iso_code);
        const countryCode = getCountryCode(selectedCountry.iso_code); 
        const serversPerPage = 9;
        const currentPage = Math.floor(startIndex / serversPerPage) + 1;
        const totalPages = Math.ceil(servers.length / serversPerPage);
        const displayStart = (currentPage - 1) * serversPerPage;
        const displayEnd = displayStart + serversPerPage;
        const displayServers = servers.slice(displayStart, displayEnd);
        
        let message = `<b>${flagEmoji} ${countryName}</b>\n`;
        message += `<i>Layanan:</i> ${userSelection.serviceName}\n`;
        message += `<i>Stok Total:</i> ${selectedCountry.stock_total} nomor\n`;
        message += `<i>Server Tersedia:</i> ${servers.length}\n`;
        message += `\n<b>Pilih Server:</b> Halaman ${currentPage}/${totalPages}\n\n`;

        const rowsPerGrid = 3;
        for (let row = 0; row < rowsPerGrid; row++) {
            const rowStart = row * rowsPerGrid;
            const rowServers = displayServers.slice(rowStart, rowStart + rowsPerGrid);
            
            if (rowServers.length === 0) break;
            
            message += `<b>`;
            rowServers.forEach((server, colIndex) => {
                const serverNumber = displayStart + rowStart + colIndex + 1;
                message += `S${serverNumber} `;
            });
            message += `</b>\n`;
            
            rowServers.forEach((server, colIndex) => {
                const serverNumber = displayStart + rowStart + colIndex + 1;
                message += `Rp${server.price.toLocaleString('id-ID')} `;
            });
            message += `\n`;
            
            rowServers.forEach((server, colIndex) => {
                message += `(${server.rate}%) `;
            });
            message += `\n`;
            
            message += `\n`;
        }
        
        const keyboard = [];
        
        for (let row = 0; row < rowsPerGrid; row++) {
            const rowStart = row * rowsPerGrid;
            const rowServers = displayServers.slice(rowStart, rowStart + rowsPerGrid);
            
            if (rowServers.length === 0) break;
            
            const buttonRow = [];
            rowServers.forEach((server, colIndex) => {
                const serverNumber = displayStart + rowStart + colIndex + 1;
                const buttonText = `S${serverNumber}`; 
                const callbackData = `nokos_server_${server.provider_id}_${server.price}_${server.rate}_${server.stock}`;
                
                buttonRow.push({ 
                    text: buttonText, 
                    callback_data: callbackData 
                });
            });
            
            if (buttonRow.length > 0) {
                keyboard.push(buttonRow);
            }
        }
        
        const navButtons = [];
        
        if (currentPage > 1) {
            navButtons.push({ 
                text: '◀️', 
                callback_data: `server_prev_${numberId}_${encodeURIComponent(countryName)}_${displayStart - serversPerPage}` 
            });
        } else {
            navButtons.push({ 
                text: '◀️', 
                callback_data: 'no_action' 
            });
        }
        
        navButtons.push({ 
            text: `Page ${currentPage}/${totalPages}`, 
            callback_data: 'no_action' 
        });
        
        if (currentPage < totalPages) {
            navButtons.push({ 
                text: '▶️', 
                callback_data: `server_next_${numberId}_${encodeURIComponent(countryName)}_${displayStart + serversPerPage}` 
            });
        } else {
            navButtons.push({ 
                text: '▶️', 
                callback_data: 'no_action' 
            });
        }
        
        keyboard.push(navButtons);
        
        keyboard.push([
            { text: 'Kembali', callback_data: `nokos_service_${userSelection.serviceId}` },
            { text: 'Menu Utama', callback_data: 'main_menu' }
        ]);
        
        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML'
        });
        
    } catch (error) {
        await editMessage(chatId, messageId, callbackQueryId,
            'Terjadi kesalahan.\n\nSilakan coba lagi.',
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: 'Coba Lagi', callback_data: `nokos_service_${userSelections.get(userId)?.serviceId || 'nokos_menu'}` }]
                    ]
                }
            }
        );
    }
}

function getCountryCode(isoCode) {
    const countryCodes = {
        'id': '+62',
        'ph': '+63',
        'us': '+1',
        'gb': '+44',
        'sg': '+65',
        'my': '+60',
        'th': '+66',
        'vn': '+84'
    };
    
    return countryCodes[isoCode?.toLowerCase()] || `+${isoCode?.toUpperCase() || '62'}`;
}

function getFlagEmoji(countryCode) {
    if (!countryCode || typeof countryCode !== 'string') return '🌐';
    const codePoints = countryCode
        .toUpperCase()
        .split('')
        .map(char => 127397 + char.charCodeAt());
    return String.fromCodePoint(...codePoints);
}

async function showOperatorMenu(chatId, userId, numberId, price, countryName, messageId, callbackQueryId) {
    try {
        const userSelection = userSelections.get(userId);
        if (!userSelection) {
            await editMessage(chatId, messageId, callbackQueryId,
                'Sesi tidak ditemukan.\n\nSilakan mulai kembali dari menu utama.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Menu Utama', callback_data: 'main_menu' }]
                        ]
                    }
                }
            );
            return;
        }
        
        userSelection.step = 'nokos_operator';
        userSelection.numberId = numberId;
        userSelection.price = price;
        userSelection.countryName = countryName;
        userSelections.set(userId, userSelection);

        await editMessage(chatId, messageId, callbackQueryId,
            'Mencari operator...',
            { parse_mode: 'HTML' }
        );

        const countriesData = await api.getCountries(userSelection.serviceId);
        
        if (!countriesData || !countriesData.success) {
            await editMessage(chatId, messageId, callbackQueryId,
                'Gagal mendapatkan data.\n\nSilakan coba lagi.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Coba Lagi', callback_data: `nokos_server_list_${numberId}_${encodeURIComponent(countryName)}` }]
                        ]
                    }
                }
            );
            return;
        }

        const countries = countriesData.data || [];
        const selectedCountry = countries.find(c => c.number_id == numberId);
        
        if (!selectedCountry) {
            await editMessage(chatId, messageId, callbackQueryId,
                `Data negara "${countryName}" tidak ditemukan.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Kembali', callback_data: `nokos_service_${userSelection.serviceId}` }]
                        ]
                    }
                }
            );
            return;
        }

        if (!selectedCountry.pricelist || selectedCountry.pricelist.length === 0) {
            await editMessage(chatId, messageId, callbackQueryId,
                `Tidak ada operator tersedia untuk ${countryName}.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Pilih Negara Lain', callback_data: `nokos_service_${userSelection.serviceId}` }]
                        ]
                    }
                }
            );
            return;
        }

        const providerId = userSelection.providerId || selectedCountry.pricelist[0].provider_id;
        userSelection.providerId = providerId;
        userSelections.set(userId, userSelection);

        const operatorsData = await api.getOperators(selectedCountry.name, providerId);
        
        if (!operatorsData || !operatorsData.success) {
            const errorMsg = operatorsData?.message || 'Gagal terhubung ke server operator';
            await editMessage(chatId, messageId, callbackQueryId,
                errorMsg,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Kembali', callback_data: `nokos_server_list_${numberId}_${encodeURIComponent(countryName)}` }]
                        ]
                    }
                }
            );
            return;
        }

        const operators = operatorsData.data || [];
        
        if (operators.length === 0) {
            await editMessage(chatId, messageId, callbackQueryId,
                `Belum ada operator yang tersedia untuk ${countryName}.\n\nSilakan pilih negara lain.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Pilih Negara Lain', callback_data: `nokos_service_${userSelection.serviceId}` }]
                        ]
                    }
                }
            );
            return;
        }

        let message = `<b>Pilih Operator</b>\n`;
        message += `Layanan: ${userSelection.serviceName}\n`;
        message += `Negara: ${countryName}\n`;
        message += `Harga: Rp${Number(price).toLocaleString('id-ID')}\n`;
        if (userSelection.rate) {
            message += `Rate: ${userSelection.rate}%\n`;
        }
        message += `\n${operators.length} operator tersedia:`;

        const keyboard = [];

        for (let i = 0; i < operators.length; i += 2) {
            const row = [];
            
            if (operators[i]) {
                const op = operators[i];
                const buttonText = op.name ? `${op.name.substring(0, 12)}` : `Operator ${i+1}`;
                row.push({ 
                    text: buttonText, 
                    callback_data: `nokos_operator_${op.id}_${providerId}_${price}` 
                });
            }
            
            if (operators[i + 1]) {
                const op = operators[i + 1];
                const buttonText = op.name ? `${op.name.substring(0, 12)}` : `Operator ${i+2}`;
                row.push({ 
                    text: buttonText, 
                    callback_data: `nokos_operator_${op.id}_${providerId}_${price}` 
                });
            }
            
            if (row.length > 0) {
                keyboard.push(row);
            }
        }

        keyboard.push([
            { 
                text: 'Kembali', 
                callback_data: `nokos_server_list_${numberId}_${encodeURIComponent(countryName)}` 
            },
            { 
                text: 'Menu Utama', 
                callback_data: 'main_menu' 
            }
        ]);

        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML'
        });

    } catch (error) {
        await editMessage(chatId, messageId, callbackQueryId,
            'Terjadi kesalahan.\n\nSilakan coba lagi.',
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: 'Coba Lagi', callback_data: `nokos_server_list_${numberId}_${encodeURIComponent(countryName)}` }]
                    ]
                }
            }
        );
    }
}

async function showNokosMenu(chatId, userId, messageId, callbackQueryId) {
  try {
    const servicesData = await getServicesCached();
    
    if (!servicesData || !servicesData.success) {
      await editMessage(chatId, messageId, callbackQueryId, 
        '<b>❌ Gagal mendapatkan layanan</b>\n\nSilakan coba lagi nanti.',
        { parse_mode: 'HTML' }
      );
      return;
    }

    const services = servicesData.data;
    const popularServiceNames = new Set(['whatsapp', 'telegram', 'instagram', 'facebook', 'gojek', 'ovo', 'dana']);
    const popularServices = [];
    const otherServices = [];
    
    for (const service of services) {
      if (popularServiceNames.has(service.service_name.toLowerCase())) {
        popularServices.push(service);
      } else {
        otherServices.push(service);
      }
    }

    const message = `
<b>📱 Layanan Nokos</b>

<i>Pilih layanan untuk order nomor OTP</i>

<b>Layanan Populer:</b>`;

    const keyboard = [];
    
    for (let i = 0; i < Math.min(popularServices.length, 6); i += 2) {
      const row = [];
      
      if (popularServices[i]) {
        const serviceName = popularServices[i].service_name;
        row.push({ 
          text: serviceName.substring(0, 12), 
          callback_data: `nokos_service_${popularServices[i].service_code}` 
        });
      }
      
      if (popularServices[i + 1]) {
        const serviceName = popularServices[i + 1].service_name;
        row.push({ 
          text: serviceName.substring(0, 12), 
          callback_data: `nokos_service_${popularServices[i + 1].service_code}` 
        });
      }
      
      if (row.length > 0) {
        keyboard.push(row);
      }
    }

    if (otherServices.length > 0) {
      keyboard.push([
        { text: 'Layanan Lainnya', callback_data: 'nokos_other_services' }
      ]);
    }

    keyboard.push([
      { text: 'Menu Utama', callback_data: 'main_menu' },
      { text: 'Refresh', callback_data: 'nokos_menu' }
    ]);

    await editMessage(chatId, messageId, callbackQueryId, message, {
      reply_markup: { inline_keyboard: keyboard },
      parse_mode: 'HTML'
    });

  } catch (error) {
    await editMessage(chatId, messageId, callbackQueryId,
      'Gagal memuat menu layanan.\n\nSilakan coba lagi.',
      { 
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: 'Coba Lagi', callback_data: 'nokos_menu' }]
          ]
        }
      }
    );
  }
}

async function showDepositMenu(chatId, userId, messageId, callbackQueryId) {
  const userBalance = getUserBalance(userId);
  
  const message = `
<b>💰 Topup Saldo</b>

<i>Saldo saat ini:</i> <b>${formatCurrency(userBalance)}</b>

<b>Informasi:</b>
Minimal: Rp 2,000
Maksimal: Rp 5,000,000
Metode: QRIS

<b>Pilih nominal:</b>`;

  userSelections.set(userId, { step: 'rumahotp_deposit_amount' });
  
  await editMessage(chatId, messageId, callbackQueryId, message, {
    reply_markup: { 
      inline_keyboard: [
        [
          { text: '2K', callback_data: 'deposit_amount_2000' },
          { text: '5K', callback_data: 'deposit_amount_5000' },
          { text: '10K', callback_data: 'deposit_amount_10000' }
        ],
        [
          { text: '20K', callback_data: 'deposit_amount_20000' },
          { text: '50K', callback_data: 'deposit_amount_50000' },
          { text: '100K', callback_data: 'deposit_amount_100000' }
        ],
        [
          { text: '200K', callback_data: 'deposit_amount_200000' },
          { text: '500K', callback_data: 'deposit_amount_500000' },
          { text: '1 JT', callback_data: 'deposit_amount_1000000' }
        ],
        [
          { text: 'Custom', callback_data: 'deposit_custom' },
          { text: 'Kembali', callback_data: 'main_menu' }
        ]
      ] 
    },
    parse_mode: 'HTML'
  });
}

async function showOtherServices(chatId, userId, messageId, callbackQueryId) {
  try {
    const servicesData = await getServicesCached();
    
    if (!servicesData || !servicesData.success) {
      await editMessage(chatId, messageId, callbackQueryId, 
        '<b>❌ Gagal mendapatkan layanan</b>\n\nSilakan coba lagi nanti.',
        { parse_mode: 'HTML' }
      );
      return;
    }

    const services = servicesData.data;

    const popularServiceNames = [
      'whatsapp', 'telegram', 'instagram', 'facebook', 
      'gojek', 'gopay', 'ovo', 'dana', 'tiktok', 'twitter'
    ];
    
    const otherServices = [];
    for (const service of services) {
      const serviceNameLower = service.service_name.toLowerCase();
      let isPopular = false;
      
      for (const popularName of popularServiceNames) {
        if (serviceNameLower.includes(popularName)) {
          isPopular = true;
          break;
        }
      }
      
      if (!isPopular) {
        otherServices.push(service);
      }
    }
    
    const displayServices = otherServices.slice(0, 20);

    if (displayServices.length === 0) {
      await editMessage(chatId, messageId, callbackQueryId, 
        '<b>Layanan Lainnya</b>\n\nTidak ada layanan lainnya.',
        { 
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [{ text: 'Kembali', callback_data: 'nokos_menu' }]
            ]
          }
        }
      );
      return;
    }

    let message = '<b>Layanan Lainnya</b>\n\n';
    message += `<i>Total: ${displayServices.length} layanan</i>\n\n`;
    
    const keyboard = [];
    
    for (let i = 0; i < displayServices.length; i += 2) {
      const row = [];
      
      if (displayServices[i]) {
        const serviceName = displayServices[i].service_name;
        row.push({ 
          text: serviceName.substring(0, 12), 
          callback_data: `nokos_service_${displayServices[i].service_code}` 
        });
      }
      
      if (displayServices[i + 1]) {
        const serviceName = displayServices[i + 1].service_name;
        row.push({ 
          text: serviceName.substring(0, 12), 
          callback_data: `nokos_service_${displayServices[i + 1].service_code}` 
        });
      }
      
      if (row.length > 0) {
        keyboard.push(row);
      }
    }

    keyboard.push([
      { text: 'Kembali', callback_data: 'nokos_menu' },
      { text: 'Menu Utama', callback_data: 'main_menu' }
    ]);

    await editMessage(chatId, messageId, callbackQueryId, message, {
      reply_markup: { inline_keyboard: keyboard },
      parse_mode: 'HTML'
    });

  } catch (error) {
    await editMessage(chatId, messageId, callbackQueryId, 
      'Gagal memuat layanan.\n\nSilakan coba lagi.',
      { 
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: 'Coba Lagi', callback_data: 'nokos_menu' }]
          ]
        }
      }
    );
  }
}

async function showCountryMenu(chatId, userId, serviceId, serviceName, messageId, callbackQueryId, page = 0) {
    try {
        const itemsPerPage = 6; 
        userSelections.set(userId, {
            step: 'nokos_country',
            serviceId: serviceId,
            serviceName: serviceName
        });

        await editMessage(chatId, messageId, callbackQueryId,
            'Memuat daftar negara...',
            { parse_mode: 'HTML' }
        );

        const countriesData = await api.getCountries(serviceId);
        
        if (!countriesData || !countriesData.success) {
            await editMessage(chatId, messageId, callbackQueryId, 
                'Gagal mendapatkan daftar negara.\n\nSilakan coba lagi.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Kembali', callback_data: `nokos_service_${serviceId}` }]
                        ]
                    }
                }
            );
            return;
        }

        const allCountries = countriesData.data || [];
        
        if (allCountries.length === 0) {
            await editMessage(chatId, messageId, callbackQueryId, 
                `Tidak ada negara tersedia untuk ${serviceName}.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Pilih Lainnya', callback_data: 'nokos_menu' }]
                        ]
                    }
                }
            );
            return;
        }
 
        const indonesiaCountries = [];
        const otherCountries = [];
        
        for (const country of allCountries) {
            const countryNameLower = country.name.toLowerCase();
            if (countryNameLower.includes('indonesia') || countryNameLower.includes('indo')) {
                indonesiaCountries.push(country);
            } else {
                otherCountries.push(country);
            }
        }
        
        otherCountries.sort((a, b) => {
            return a.name.localeCompare(b.name);
        });
        
        const sortedCountries = [...indonesiaCountries, ...otherCountries];

        const totalPages = Math.ceil(sortedCountries.length / itemsPerPage);
        if (page < 0) page = 0;
        if (page >= totalPages) page = totalPages - 1;

        const startIndex = page * itemsPerPage;
        const endIndex = startIndex + itemsPerPage;
        const currentCountries = sortedCountries.slice(startIndex, endIndex);

        let message = `<b>Pilih Negara</b>\n`;
        message += `Layanan: ${serviceName}\n`;
        message += `Halaman: ${page + 1}/${totalPages}\n`;
        message += `Total: ${sortedCountries.length} negara\n\n`;
        
        const keyboard = [];
       
        for (let i = 0; i < currentCountries.length; i += 2) {
            const row = [];
            
            if (currentCountries[i]) {
                const country = currentCountries[i];
                
                let countryText = country.name;
                if (countryText.length > 10) {
                    countryText = countryText.substring(0, 10);
                }
                
                row.push({ 
                    text: countryText, 
                    callback_data: `nokos_server_list_${country.number_id}_${encodeURIComponent(country.name)}` 
                });
            }
            
            if (currentCountries[i + 1]) {
                const country = currentCountries[i + 1];

                let countryText = country.name;
                if (countryText.length > 10) {
                    countryText = countryText.substring(0, 10);
                }
                
                row.push({ 
                    text: countryText, 
                    callback_data: `nokos_server_list_${country.number_id}_${encodeURIComponent(country.name)}` 
                });
            }
            
            if (row.length > 0) {
                keyboard.push(row);
            }
        }

        const navButtons = [];
        
        if (totalPages > 1) {
            if (page > 0) {
                navButtons.push({ 
                    text: '<', 
                    callback_data: `nokos_country_page_${serviceId}_${page - 1}` 
                });
            }

            if (page < totalPages - 1) {
                navButtons.push({ 
                    text: '>', 
                    callback_data: `nokos_country_page_${serviceId}_${page + 1}` 
                });
            }
            
            if (navButtons.length > 0) {
                keyboard.push(navButtons);
            }
        }

        keyboard.push([
            { text: 'Kembali', callback_data: `nokos_service_${serviceId}` },
            { text: 'Menu Utama', callback_data: 'main_menu' }
        ]);

        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML'
        });

    } catch (error) {
        await editMessage(chatId, messageId, callbackQueryId,
            'Terjadi kesalahan.\n\nSilakan coba lagi.',
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: 'Coba Lagi', callback_data: `nokos_service_${serviceId}` }],
                        [{ text: 'Menu Utama', callback_data: 'main_menu' }]
                    ]
                }
            }
        );
    }
}

async function showOrderConfirmation(chatId, userId, operatorId, providerId, price, messageId, callbackQueryId) {
    try {
        const userSelection = userSelections.get(userId);
        if (!userSelection) {
            return;
        }

        const userBalance = getUserBalance(userId);
        const canOrder = userBalance >= price;      
        const message = `
<b>Konfirmasi Order</b>

Detail Order:
Layanan: ${userSelection.serviceName}
Negara: ${userSelection.countryName}
Harga: Rp${Number(price).toLocaleString('id-ID')}
Saldo Anda: Rp${userBalance.toLocaleString('id-ID')}

Status: ${canOrder ? 'Saldo Cukup' : 'Saldo Tidak Cukup'}

${canOrder ? 
    'Klik Beli Sekarang untuk melanjutkan pembelian.' : 
    'Saldo Anda tidak cukup. Silakan deposit terlebih dahulu.'}
        `.trim();

        userSelection.operatorId = operatorId;
        userSelection.providerId = providerId;
        userSelection.price = price;
        userSelections.set(userId, userSelection);

        const keyboard = [
            [
                { 
                    text: canOrder ? 'Beli Sekarang' : 'Deposit', 
                    callback_data: canOrder ? 
                        `nokos_confirm_${userSelection.numberId}_${providerId}_${operatorId}_${price}` : 
                        'deposit_main' 
                }
            ],
            [
                { 
                    text: 'Kembali', 
                    callback_data: `nokos_server_list_${userSelection.numberId}_${encodeURIComponent(userSelection.countryName)}` 
                },
                { 
                    text: 'Menu Utama', 
                    callback_data: 'main_menu' 
                }
            ]
        ];

        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML'
        });
    } catch (error) {
        await editMessage(chatId, messageId, callbackQueryId,
            'Gagal menampilkan konfirmasi order.',
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: 'Kembali', callback_data: 'nokos_menu' }]
                    ]
                }
            }
        );
    }
}
        
async function processNokosOrder(chatId, userId, numberId, providerId, operatorId, price, messageId, callbackQueryId) {
    try {
        const orderKey = `${userId}_${Date.now()}`;

        if (isOrderProcessing(orderKey)) {
            await editMessage(chatId, messageId, callbackQueryId,
                'Order sedang diproses, mohon tunggu...',
                { parse_mode: 'HTML' }
            );
            return;
        }
        
        setOrderProcessing(orderKey, true);
        
        const userBalance = getUserBalance(userId);
        const numPrice = Number(price);
        
        if (userBalance < numPrice || isNaN(numPrice)) {
            await editMessage(chatId, messageId, callbackQueryId,
                'Saldo tidak cukup untuk melakukan order ini.',
                { parse_mode: 'HTML' }
            );
            setOrderProcessing(orderKey, false);
            return;
        }

        const deductionSuccess = deductUserBalance(userId, numPrice);
        
        if (!deductionSuccess) {
            await editMessage(chatId, messageId, callbackQueryId,
                'Gagal memotong saldo. Silakan hubungi admin.',
                { parse_mode: 'HTML' }
            );
            setOrderProcessing(orderKey, false);
            return;
        }
        
        const orderResult = await api.createOrder(numberId, providerId, operatorId);
        
        if (!orderResult || !orderResult.success) {
            const errorMsg = orderResult?.error?.message || 
                           orderResult?.message || 
                           orderResult?.data?.message ||
                           'Error dari API';
            
            addUserBalance(userId, numPrice);
            
            await editMessage(chatId, messageId, callbackQueryId,
                `Gagal membuat order.\n\n${errorMsg}\n\nSaldo telah dikembalikan.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ 
                                text: 'Coba Lagi', 
                                callback_data: `nokos_confirm_${numberId}_${providerId}_${operatorId}_${price}` 
                            }],
                            [{ 
                                text: 'Menu Utama', 
                                callback_data: 'main_menu' 
                            }]
                        ]
                    }
                }
            );
            setOrderProcessing(orderKey, false);
            return;
        }

        const orderData = orderResult.data;
        const expiresInMinutes = orderData.expires_in_minute || 15;
        const expiresAt = Date.now() + (expiresInMinutes * 60 * 1000);
        const orderPrice = orderData.price ? Number(orderData.price) : numPrice;
        
        addTransaction('nokos_orders', {
             userId: userId,
             orderId: orderData.order_id,
             phoneNumber: orderData.phone_number,
             service: orderData.service,
             country: orderData.country,
             operator: orderData.operator,
             price: orderPrice,
             status: 'active',
             expiresAt: expiresAt,
             expiresInMinutes: expiresInMinutes,
             canCancelAt: Date.now() + (2 * 60 * 1000),
             deductedAmount: orderPrice,
             refunded: false 
        });

        try {
            const user = await bot.getChat(userId).catch(() => ({ 
                id: userId, 
                first_name: 'User' 
            }));
            
            await notifyOrderSuccess(user, orderData, orderPrice, false);
        } catch (error) {}

        const message = `
Order Berhasil

Detail Order:
ID Order: ${orderData.order_id}
Nomor: ${orderData.phone_number}
Layanan: ${orderData.service}
Negara: ${orderData.country}
Operator: ${orderData.operator}
Harga: ${formatCurrency(orderPrice)} 
Expired: ${expiresInMinutes} menit

Instruksi:
1. Gunakan nomor untuk registrasi
2. Tunggu SMS OTP masuk
3. Klik tombol Cek OTP untuk melihat kode

Catatan:
- Order otomatis expired dalam ${expiresInMinutes} menit
- Saldo terpotong: ${formatCurrency(orderPrice)}
- Saldo sekarang: ${formatCurrency(getUserBalance(userId))}`;

const keyboard = [
    [
        { 
            text: 'Cek OTP', 
            callback_data: `nokos_check_${orderData.order_id}` 
        },
        { 
            text: 'Tunggu 3m', 
            callback_data: `wait_cancel_${orderData.order_id}` 
        }
    ],
    [
        { 
            text: 'Order Baru', 
            callback_data: 'nokos_menu' 
        },
        { 
            text: 'Menu Utama', 
            callback_data: 'main_menu' 
        }
    ]
];

        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML'
        });

        setTimeout(() => {
            monitorOTP(chatId, userId, orderData.order_id, orderPrice, expiresInMinutes);
        }, 5000);

        /*await createBackupOnEvent('order_success', {
            orderId: orderData.order_id,
            userId: userId,
            amount: orderPrice
        });*/

        setOrderProcessing(orderKey, false);

    } catch (error) {
        try {
            const refundAmount = Number(price) || 0;
            if (refundAmount > 0) {
                addUserBalance(userId, refundAmount);
            }
        } catch (refundError) {}
        
        await editMessage(chatId, messageId, callbackQueryId,
            `Terjadi kesalahan sistem.\n\n${error.message || 'Silakan coba lagi'}`,
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ 
                            text: 'Coba Lagi', 
                            callback_data: `nokos_confirm_${numberId}_${providerId}_${operatorId}_${price}` 
                        }],
                        [{ 
                            text: 'Menu Utama', 
                            callback_data: 'main_menu' 
                        }]
                    ]
                }
            }
        );
        
        if (orderKey) setOrderProcessing(orderKey, false);
    }
}

async function monitorOTP(chatId, userId, orderId, price, expiresInMinutes = 15) {
    const maxRetries = Math.floor(expiresInMinutes * 6);
    let retryCount = 0;
    let errorCount = 0;
    const maxErrors = 3;
    let hasSentExpiredMessage = false;
    
    const monitorInterval = setInterval(async () => {
        retryCount++;
        
        if (retryCount >= maxRetries) {
            clearInterval(monitorInterval);
            
            const transactions = loadTransactions();
            const order = transactions.nokos_orders?.find(o => 
                o.id === orderId || o.data?.orderId === orderId
            );
            
            const manuallyCancelled = order?.data?.manually_cancelled === true;
            
            if (!manuallyCancelled && !hasSentExpiredMessage) {
                await autoCancelOrder(chatId, userId, orderId, price);
                hasSentExpiredMessage = true;
            }
            return;
        }

        try {
            const statusResult = await api.getOrderStatus(orderId);
            
            if (!statusResult || !statusResult.success) {
                errorCount++;
                if (errorCount >= maxErrors) {
                    clearInterval(monitorInterval);
                }
                return;
            }

            const orderData = statusResult.data;
            
            if (!orderData) {
                return;
            }
            
            const transactions = loadTransactions();
            const order = transactions.nokos_orders?.find(o => 
                o.id === orderId || o.data?.orderId === orderId
            );
            
            const manuallyCancelled = order?.data?.manually_cancelled === true;
            
            if (manuallyCancelled) {
                clearInterval(monitorInterval);
                return;
            }
            
            if (orderData.otp_code && orderData.otp_code !== '-') {
                clearInterval(monitorInterval);
                
                updateTransactionStatus('nokos_orders', orderId, 'completed');
                
                const transactions = loadTransactions();
                const orderIndex = transactions.nokos_orders?.findIndex(o => 
                    o.id === orderId || o.data?.orderId === orderId
                );
                if (orderIndex !== -1) {
                    transactions.nokos_orders[orderIndex].data.otp_received = true;
                    transactions.nokos_orders[orderIndex].data.otp_code = orderData.otp_code;
                    saveTransactions(transactions);
                }
                
                await sendNewMessage(chatId,
                    `OTP Diterima!\n\nOrder ID: #${orderId}\nNomor: ${orderData.phone_number}\nKode OTP: ${orderData.otp_code}\n\nSimpan kode dengan aman!`,
                    { parse_mode: 'HTML' }
                );
                
                try {
                    const user = await bot.getChat(userId).catch(() => ({ 
                        id: userId, 
                        first_name: 'User' 
                    }));
                    await notifyOrderSuccess(user, orderData, price, true);
                } catch {}
                
            } else if (orderData.status === 'completed' || orderData.status === 'canceled' || orderData.status === 'expired') {
                clearInterval(monitorInterval);
                
                if (manuallyCancelled) {
                    return;
                }
                
                updateTransactionStatus('nokos_orders', orderId, orderData.status);
                
                const transactions = loadTransactions();
                const order = transactions.nokos_orders?.find(o => 
                    o.id === orderId || o.data?.orderId === orderId
                );
                
                const otpReceived = order?.data?.otp_received === true;
                
                if ((orderData.status === 'canceled' || orderData.status === 'expired') && !otpReceived) {
                    addUserBalance(userId, price);
                    await sendNewMessage(chatId,
                        `Order ${orderData.status === 'canceled' ? 'Dibatalkan' : 'Expired'}\n\nOrder ID: #${orderId}\n\nSaldo sebesar ${formatCurrency(price)} telah dikembalikan.`,
                        { parse_mode: 'HTML' }
                    );
                } else if (orderData.status === 'completed') {
                    
                    if (transactions.nokos_orders) {
                        const orderIndex = transactions.nokos_orders.findIndex(o => 
                            o.id === orderId || o.data?.orderId === orderId
                        );
                        if (orderIndex !== -1) {
                            transactions.nokos_orders[orderIndex].data.otp_received = true;
                            saveTransactions(transactions);
                        }
                    }
                }
            }
            
            errorCount = 0;
            
        } catch {
            errorCount++;
            if (errorCount >= maxErrors) {
                clearInterval(monitorInterval);
            }
        }
    }, 10000);
}

async function checkOTP(chatId, orderId, messageId, callbackQueryId) {
    try {
        await editMessage(chatId, messageId, callbackQueryId,
            'Mengecek OTP...',
            { parse_mode: 'HTML' }
        );

        const statusResult = await api.getOrderStatus(orderId);
        
        if (!statusResult || !statusResult.success) {
            await editMessage(chatId, messageId, callbackQueryId,
                'Gagal mengecek OTP.\n\nSilakan coba lagi nanti.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Coba Lagi', callback_data: `nokos_check_${orderId}` }],
                            [{ text: 'Menu Utama', callback_data: 'main_menu' }]
                        ]
                    }
                }
            );
            return;
        }

        const orderData = statusResult.data;
        
        if (orderData.otp_code && orderData.otp_code !== '-') {
            const transactions = loadTransactions();
            const orderIndex = transactions.nokos_orders?.findIndex(o => 
                o.id === orderId || o.data?.orderId === orderId
            );
            
            if (orderIndex !== -1) {
                transactions.nokos_orders[orderIndex].data.otp_received = true;
                transactions.nokos_orders[orderIndex].data.otp_code = orderData.otp_code;
                transactions.nokos_orders[orderIndex].data.status = 'completed';
                transactions.nokos_orders[orderIndex].data.can_refund = false; 
                const orderPrice = transactions.nokos_orders[orderIndex].data.price || 0;
                saveTransactions(transactions);
                
                try {
                    const user = await bot.getChat(chatId).catch(() => ({ 
                        id: chatId, 
                        first_name: 'User' 
                    }));
                    await notifyOrderSuccess(user, orderData, orderPrice, true);
                } catch (error) {}
            }
            
            await editMessage(chatId, messageId, callbackQueryId,
                `<b>✅ OTP Ditemukan!</b>\n\n` +
                `Order ID: <code>#${orderId}</code>\n` +
                `Nomor: ${orderData.phone_number}\n` +
                `Kode OTP: <code>${orderData.otp_code}</code>\n\n` +
                `<b>Status:</b> Order selesai\n` +
                `<b>Saldo sudah terpakai.</b>\n\n` +
                `<i>Order sudah selesai dan tidak dapat dibatalkan.</i>`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { text: 'Order Baru', callback_data: 'nokos_menu' },
                                { text: 'Menu Utama', callback_data: 'main_menu' }
                            ]
                        ]
                    }
                }
            );
            
            updateTransactionStatus('nokos_orders', orderId, 'completed');
            
        } else {
            await editMessage(chatId, messageId, callbackQueryId,
                `<b>Menunggu OTP</b>\n\nOrder ID: <code>#${orderId}</code>\nNomor: ${orderData.phone_number}\nStatus: ${orderData.status}\n\nOTP belum diterima. Silakan coba lagi nanti.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { text: 'Cek Lagi', callback_data: `nokos_check_${orderId}` },
                                { text: 'Batal', callback_data: `nokos_cancel_${orderId}` }
                            ],
                            [
                                { text: 'Menu Utama', callback_data: 'main_menu' }
                            ]
                        ]
                    }
                }
            );
        }
    } catch (error) {
        await editMessage(chatId, messageId, callbackQueryId,
            'Gagal mengecek OTP.',
            { parse_mode: 'HTML' }
        );
    }
}

function formatTimeRemaining(minutes) {
    if (minutes >= 60) {
        const hours = Math.floor(minutes / 60);
        const mins = minutes % 60;
        return `${hours} jam ${mins} menit`;
    }
    return `${minutes} menit`;
}

function hasOTPBeenReceived(orderId) {
    try {
        const transactions = loadTransactions();
        const order = transactions.nokos_orders?.find(o => 
            o.id === orderId || o.data?.orderId === orderId
        );
        
        const dbCheck = order?.data?.otp_received === true;
        const otpCheck = order?.data?.otp_code && 
                       order.data.otp_code !== '-' && 
                       order.data.otp_code !== '';
        
        return dbCheck || otpCheck;
    } catch (error) {
        return false;
    }
}

async function cancelOrder(chatId, userId, orderId, messageId, callbackQueryId) {
  try {
    const transactions = loadTransactions();
    const order = transactions.nokos_orders?.find(o => o.id === orderId || o.data?.orderId === orderId);
    
    if (!order) {
      if (callbackQueryId) {
        await bot.answerCallbackQuery(callbackQueryId, {
          text: 'Order tidak ditemukan',
          show_alert: true
        });
      }
      return;
    }

    let orderTime;
    try {
        if (order.timestamp instanceof Date) {
            orderTime = order.timestamp.getTime();
        } else if (typeof order.timestamp === 'string') {
            orderTime = new Date(order.timestamp).getTime();
        } else if (order.timestamp && typeof order.timestamp === 'number') {
            orderTime = order.timestamp;
        } else {
            orderTime = Date.now();
        }
        
        if (isNaN(orderTime)) {
            orderTime = Date.now();
        }
    } catch (error) {
        orderTime = Date.now();
    }

    const now = Date.now();
    const threeMinutes = 3 * 60 * 1000;
    
    if (now - orderTime < threeMinutes) {
      const timeLeft = Math.ceil((threeMinutes - (now - orderTime)) / 1000);
      const minutesLeft = Math.floor(timeLeft / 60);
      const secondsLeft = timeLeft % 60;
      
      if (callbackQueryId) {
        await bot.answerCallbackQuery(callbackQueryId, {
          text: `Tunggu ${minutesLeft}m ${secondsLeft}s sebelum membatalkan`,
          show_alert: true
        });
      }
      return;
    }

    await editMessage(chatId, messageId, callbackQueryId,
      'Membatalkan order...',
      { parse_mode: 'HTML' }
    );

    const statusResult = await api.getOrderStatus(orderId);
    
    let otpReceived = false;
    if (statusResult && statusResult.success && statusResult.data) {
      const orderData = statusResult.data;
      otpReceived = orderData.otp_code && orderData.otp_code !== '-' && orderData.otp_code !== '';
    }

    const dbOtpReceived = order?.data?.otp_received === true;
    
    if (otpReceived || dbOtpReceived) {
        await editMessage(chatId, messageId, callbackQueryId,
            `Order tidak dapat dibatalkan!\n\nOrder ID: #${orderId}\n\nAlasan: OTP sudah diterima.\nStatus: Order selesai\nSaldo tidak dapat dikembalikan.`,
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: 'Order Baru', callback_data: 'nokos_menu' },
                            { text: 'Menu Utama', callback_data: 'main_menu' }
                        ]
                    ]
                }
            }
        );
        return;
    }
    
    if (order?.status === 'cancelled' || order?.status === 'expired' || order?.status === 'completed') {
      await editMessage(chatId, messageId, callbackQueryId,
        `Order sudah dalam status: ${order.status}\n\nOrder ID: #${orderId}\n\nTidak bisa dibatalkan lagi.`,
        { 
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [
                { text: 'Order Baru', callback_data: 'nokos_menu' },
                { text: 'Menu Utama', callback_data: 'main_menu' }
              ]
            ]
          }
        }
      );
      return;
    }

    const alreadyRefunded = order?.data?.refunded === true;
    
    if (alreadyRefunded) {
      await editMessage(chatId, messageId, callbackQueryId,
        `Refund sudah diberikan.\n\nSaldo untuk order ini sudah dikembalikan sebelumnya.`,
        { parse_mode: 'HTML' }
      );
      return;
    }

    const cancelResult = await api.setOrderStatus(orderId, 'cancel');
    
    if (!cancelResult || !cancelResult.success) {
      const errorMsg = cancelResult?.message || 'Provider menolak pembatalan';
      
      if (errorMsg.includes('wait') || errorMsg.includes('tunggu') || errorMsg.includes('minute')) {
        await editMessage(chatId, messageId, callbackQueryId,
          `Provider sedang memproses order.\n\nSilakan tunggu beberapa saat lagi sebelum membatalkan.`,
          { 
            parse_mode: 'HTML',
            reply_markup: {
              inline_keyboard: [
                [
                  { text: 'Coba Lagi', callback_data: `nokos_cancel_${orderId}` },
                  { text: 'Menu Utama', callback_data: 'main_menu' }
                ]
              ]
            }
          }
        );
      } else {
        await editMessage(chatId, messageId, callbackQueryId,
          `Gagal membatalkan order.\n\n${errorMsg}`,
          { 
            parse_mode: 'HTML',
            reply_markup: {
              inline_keyboard: [
                [
                  { text: 'Coba Lagi', callback_data: `nokos_cancel_${orderId}` },
                  { text: 'Menu Utama', callback_data: 'main_menu' }
                ]
              ]
            }
          }
        );
      }
      return;
    }

    updateTransactionStatus('nokos_orders', orderId, 'cancelled');

    if (transactions.nokos_orders) {
      const orderIndex = transactions.nokos_orders.findIndex(o => o.id === orderId || o.data?.orderId === orderId);
      if (orderIndex !== -1) {
        transactions.nokos_orders[orderIndex].data.refunded = true;
        transactions.nokos_orders[orderIndex].data.manually_cancelled = true;
        saveTransactions(transactions);
      }
    }
    
    let refundMessage = '';
    const orderPrice = order.data?.price || 0;
    const refundAmount = Number(orderPrice);
    
    if (!isNaN(refundAmount) && refundAmount > 0) {
      const success = addUserBalance(userId, refundAmount);
      
      if (success) {
        balanceCache.delete(userId.toString());
        
        const currentBalance = getUserBalance(userId);
        refundMessage = `\n\nRefund: ${formatCurrency(refundAmount)}\nSaldo sekarang: ${formatCurrency(currentBalance)}`;
      }
    }

    await editMessage(chatId, messageId, callbackQueryId,
      `Order Dibatalkan\n\nOrder ID: #${orderId}${refundMessage}`,
      { 
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: 'Order Baru', callback_data: 'nokos_menu' },
              { text: 'Menu Utama', callback_data: 'main_menu' }
            ]
          ]
        }
      }
    );
  } catch (error) {
    await editMessage(chatId, messageId, callbackQueryId,
      `Gagal membatalkan order.\n\n${error.message || 'Error sistem'}`,
      { 
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: 'Coba Lagi', callback_data: `nokos_cancel_${orderId}` },
              { text: 'Menu Utama', callback_data: 'main_menu' }
            ]
          ]
        }
      }
    );
  }
}

async function autoCancelOrder(chatId, userId, orderId, price) {
  try {
    const transactions = loadTransactions();
    const order = transactions.nokos_orders?.find(o => 
        o.id === orderId || o.data?.orderId === orderId
    );
    
    if (!order) return;

    const manuallyCancelled = order?.data?.manually_cancelled === true;
    const alreadyRefunded = order?.data?.refunded === true;
    
    if (manuallyCancelled || alreadyRefunded) {
      return;
    }

    const cancelResult = await api.setOrderStatus(orderId, 'cancel');
    
    if (cancelResult && cancelResult.success) {
      updateTransactionStatus('nokos_orders', orderId, 'expired');
      
      if (transactions.nokos_orders) {
        const orderIndex = transactions.nokos_orders.findIndex(o => 
            o.id === orderId || o.data?.orderId === orderId
        );
        if (orderIndex !== -1) {
          transactions.nokos_orders[orderIndex].data.refunded = true;
          saveTransactions(transactions);
        }
      }
      
      const refundAmount = Number(price);
      
      if (!isNaN(refundAmount) && refundAmount > 0) {
        addUserBalance(userId, refundAmount);
        balanceCache.delete(userId.toString());
      }
      
      await sendNewMessage(chatId,
        `Order Expired\n\nOrder ID: #${orderId}\n\nOTP tidak diterima dalam waktu yang ditentukan.\nSaldo sebesar ${formatCurrency(price)} telah dikembalikan.`,
        { parse_mode: 'HTML' }
      );
    }
  } catch (error) {}
}

async function handleRumahOTPDeposit(chatId, userId, amount) {
    try {
        const depositKey = `${userId}_deposit`;

        if (depositProcessing.has(depositKey)) {
            await sendNewMessage(chatId,
                'Deposit sedang diproses, mohon tunggu...',
                { parse_mode: 'HTML' }
            );
            return;
        }
        
        depositProcessing.set(depositKey, Date.now());
        
        const amountValidation = validateAmount(amount);
        if (!amountValidation.valid) {
            await sendNewMessage(chatId,
                `Jumlah tidak valid: ${amountValidation.error}`,
                { parse_mode: 'HTML' }
            );
            depositProcessing.delete(depositKey);
            return;
        }
        
        const depositAmount = amountValidation.amount;
        
        if (depositAmount < 2000) {
            await sendNewMessage(chatId,
                'Minimal deposit adalah Rp 2,000',
                { parse_mode: 'HTML' }
            );
            depositProcessing.delete(depositKey);
            return;
        }
        
        if (depositAmount > 5000000) {
            await sendNewMessage(chatId,
                'Maksimal deposit adalah Rp 5,000,000',
                { parse_mode: 'HTML' }
            );
            depositProcessing.delete(depositKey);
            return;
        }

        const loadingMessage = await sendNewMessage(chatId, 'Memproses deposit...', { parse_mode: 'HTML' });

        const paymentMethod = getPaymentMethod();
        let depositResult;
        
        try {
            if (paymentMethod === 'cashify') {
                
                depositResult = await cashifyService.createDeposit(userId.toString(), depositAmount);
            } else {
                depositResult = await api.createRumahOTPDeposit(depositAmount);
            }
        } catch (apiError) {
            depositProcessing.delete(depositKey);
            await editMessage(chatId, loadingMessage.message_id, null,
                `Gagal membuat deposit: ${apiError.message || 'Koneksi error'}`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: { 
                        inline_keyboard: [
                            [{ text: 'Coba Lagi', callback_data: 'deposit_main' }],
                            [{ text: 'Menu Utama', callback_data: 'main_menu' }]
                        ] 
                    } 
                }
            );
            return;
        }
        
        const isCashify = paymentMethod === 'cashify';
        const successCheck = isCashify ? 
            depositResult?.success : 
            depositResult?.success;
        
        if (!successCheck) {
            const errorMsg = depositResult?.message || 
                           depositResult?.error?.message || 
                           depositResult?.error || 
                           'Terjadi kesalahan sistem';
            
            await editMessage(chatId, loadingMessage.message_id, null,
                `Gagal membuat deposit.\n\n${errorMsg}`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: { 
                        inline_keyboard: [
                            [{ text: 'Coba Lagi', callback_data: 'deposit_main' }],
                            [{ text: 'Menu Utama', callback_data: 'main_menu' }]
                        ] 
                    } 
                }
            );
            depositProcessing.delete(depositKey);
            return;
        }

        let depositData;
        let depositId;
        const transactionType = isCashify ? 'cashify_deposits' : 'rumahotp_deposits';
        
        if (isCashify) {
            depositData = depositResult.data;
            depositId = depositData.id;
            
            depositData = {
                id: depositId,
                method: 'QRIS',
                qr_string: depositData.qr_string || depositData.qr_code || '',
                total: depositAmount,
                diterima: depositData.diterima || depositAmount,
                fee: depositData.fee || 0,
                status: 'pending'
            };
        } else {
            depositData = depositResult.data;
            depositId = depositData.id || depositData.no_inv;
        }

        if (!depositId) {
            await editMessage(chatId, loadingMessage.message_id, null,
                'Gagal mendapatkan ID deposit dari provider',
                { 
                    parse_mode: 'HTML',
                    reply_markup: { 
                        inline_keyboard: [
                            [{ text: 'Coba Lagi', callback_data: 'deposit_main' }],
                            [{ text: 'Menu Utama', callback_data: 'main_menu' }]
                        ] 
                    } 
                }
            );
            depositProcessing.delete(depositKey);
            return;
        }
        
        addTransaction(transactionType, {
            userId: userId,
            id: depositId,
            amount: depositAmount,
            total: depositData.total || depositAmount,
            fee: depositData.fee || 0,
            diterima: depositData.diterima || depositAmount,
            method: 'QRIS', 
            status: 'pending',
            raw_data: depositResult
        });

        try {
            await notifyOwnerDepositCreated(depositData, userId, depositAmount, paymentMethod);
        } catch (error) {}

        const message = `
Deposit Diproses

Informasi Deposit:
ID: #${depositId}
Jumlah: ${formatCurrency(depositAmount)}
Metode: QRIS
Fee: ${formatCurrency(depositData.fee || 0)}
Diterima: ${formatCurrency(depositData.diterima || depositAmount)}
Status: Menunggu Pembayaran

Silakan scan QR untuk pembayaran
Batas waktu: 20 menit`;

        const keyboard = {
            inline_keyboard: [
                [
                    { text: 'Periksa Status', callback_data: `deposit_status_${depositId}` },
                    { text: 'Batalkan', callback_data: `deposit_cancel_${depositId}` }
                ],
                [
                    { text: 'Deposit Lagi', callback_data: 'deposit_main' },
                    { text: 'Menu Utama', callback_data: 'main_menu' }
                ]
            ]
        };

        await bot.deleteMessage(chatId, loadingMessage.message_id).catch(() => {});
        
        if (isCashify && depositData.qr_string && depositData.qr_string.trim() !== '') {
            try {
                const qrBuffer = await QRCode.toBuffer(depositData.qr_string, {
                    errorCorrectionLevel: 'H',
                    margin: 1,
                    width: 300
                });
                
                const qrMessage = await bot.sendPhoto(chatId, qrBuffer, {
                    caption: message,
                    parse_mode: 'HTML',
                    reply_markup: keyboard
                });
                userDepositMessages.set(`${userId}_${depositId}`, qrMessage.message_id);
            } catch (qrError) {
                const textMessage = await sendNewMessage(chatId, 
                    `${message}\n\nQR Text:\n<code>${depositData.qr_string.substring(0, 100)}...</code>`,
                    { 
                        parse_mode: 'HTML',
                        reply_markup: keyboard 
                    }
                );
                userDepositMessages.set(`${userId}_${depositId}`, textMessage.message_id);
            }
        } else if (depositData.qr_string && depositData.qr_string.trim() !== '') {
            try {
                const qrBuffer = await QRCode.toBuffer(depositData.qr_string, {
                    errorCorrectionLevel: 'H',
                    margin: 1,
                    width: 300
                });
                
                const qrMessage = await bot.sendPhoto(chatId, qrBuffer, {
                    caption: message,
                    parse_mode: 'HTML',
                    reply_markup: keyboard
                });
                userDepositMessages.set(`${userId}_${depositId}`, qrMessage.message_id);
            } catch (qrError) {
                const textMessage = await sendNewMessage(chatId, 
                    `${message}\n\nQR Text:\n<code>${depositData.qr_string.substring(0, 100)}...</code>`,
                    { 
                        parse_mode: 'HTML',
                        reply_markup: keyboard 
                    }
                );
                userDepositMessages.set(`${userId}_${depositId}`, textMessage.message_id);
            }
        } else {
            const textMessage = await sendNewMessage(chatId, message, { 
                parse_mode: 'HTML',
                reply_markup: keyboard 
            });
            userDepositMessages.set(`${userId}_${depositId}`, textMessage.message_id);
        }

        /*await createBackupOnEvent('deposit_pending', {
            depositId: depositId,
            userId: userId,
            amount: depositAmount,
            method: paymentMethod
        });*/

        depositProcessing.delete(depositKey);
        
        setTimeout(() => checkDepositStatus(chatId, depositId, userId), 10000);
    } catch (error) {
        depositProcessing.delete(`${userId}_deposit`);
        
        await sendNewMessage(chatId,
            `Gagal memproses deposit.\n\n${error.message || 'Terjadi kesalahan sistem.'}`,
            { parse_mode: 'HTML' }
        );
    }
}

async function checkDepositStatus(chatId, depositId, userId, messageId = null, retryCount = 0) {
    const maxRetries = 120;
    
    if (retryCount >= maxRetries) {
        if (messageId) {
            await editMessage(chatId, messageId, null, 
                'Pemeriksaan status deposit dibatalkan.\n\nWaktu pemeriksaan status deposit telah habis.\nSilakan ulangi transaksi lagi.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: { 
                        inline_keyboard: [
                            [{ text: 'Menu Utama', callback_data: 'main_menu' }]
                        ] 
                    } 
                }
            );
        }
        return;
    }

    const paymentMethod = getPaymentMethod();
    let statusResult;
    
    if (paymentMethod === 'cashify') {
        statusResult = await cashifyService.checkDepositStatus(depositId);
    } else {
        statusResult = await api.checkRumahOTPDepositStatus(depositId);
    }
    
    const isCashify = paymentMethod === 'cashify';
    const successCheck = isCashify ? 
        statusResult?.success : 
        statusResult?.success;
    
    if (!successCheck) {
        setTimeout(() => {
            checkDepositStatus(chatId, depositId, userId, messageId, retryCount + 1);
        }, 10000);
        return;
    }

    let deposit;
    if (isCashify) {
        deposit = statusResult.data;

        if (deposit.status === 'paid') {
            deposit.status = 'success';
            
            const transactions = loadTransactions();
            const transactionType = 'cashify_deposits';
            const existingDeposit = transactions[transactionType]?.find(d => d.data.id === depositId);
            
            if (!existingDeposit || existingDeposit.status !== 'success') {
                const amountToAdd = deposit.diterima || deposit.total || 0;
                
                if (amountToAdd > 0) {
                    addUserBalance(userId, amountToAdd);
                    updateTransactionStatus(transactionType, depositId, 'success');

                    try {
                        const user = await bot.getChat(userId).catch(() => ({ 
                            id: userId, 
                            first_name: 'User' 
                        }));
                        await notifyDepositSuccess(user, amountToAdd, depositId, getUserBalance(userId));
                    } catch (error) {}

                    const depositKey = `${userId}_${depositId}`;
                    const qrMessageId = userDepositMessages.get(depositKey);
                    if (qrMessageId) {
                        try {
                            await bot.deleteMessage(chatId, qrMessageId);
                        } catch (deleteError) {}
                        userDepositMessages.delete(depositKey);
                    }
                    
                    const successMessage = `
Deposit Berhasil

${formatCurrency(amountToAdd)} telah ditambahkan ke saldo Anda
Saldo sekarang: ${formatCurrency(getUserBalance(userId))}

Terima kasih telah melakukan deposit`;
                    
                    const keyboard = {
                        inline_keyboard: [
                            [
                                { text: 'Deposit Lagi', callback_data: 'deposit_main' },
                                { text: 'Menu Utama', callback_data: 'main_menu' }
                            ]
                        ]
                    };
                    
                    if (messageId) {
                        await editMessage(chatId, messageId, null, successMessage, {
                            parse_mode: 'HTML',
                            reply_markup: keyboard
                        });
                    } else {
                        await sendNewMessage(chatId, successMessage, {
                            parse_mode: 'HTML',
                            reply_markup: keyboard
                        });
                    }
                    
                   /* await createBackupOnEvent('deposit_success', {
                        depositId: depositId,
                        userId: userId,
                        amount: amountToAdd,
                        method: paymentMethod
                    });*/
                }
            }
            return; 
        }
    } else {
        deposit = statusResult.data;
    }
    
    if (deposit.status === 'success' || deposit.status === 'paid') {
        const amountToAdd = deposit.diterima || deposit.total || depositAmount;
        
        const transactions = loadTransactions();
        const transactionType = isCashify ? 'cashify_deposits' : 'rumahotp_deposits';
        const existingDeposit = transactions[transactionType]?.find(d => d.data.id === depositId);
        
        if (!existingDeposit || existingDeposit.status !== 'success') {
            addUserBalance(userId, amountToAdd);
            updateTransactionStatus(transactionType, depositId, 'success');

            try {
                const user = await bot.getChat(userId).catch(() => ({ 
                    id: userId, 
                    first_name: 'User' 
                }));
                await notifyDepositSuccess(user, amountToAdd, depositId, getUserBalance(userId));
            } catch (error) {}
        }

        const depositKey = `${userId}_${depositId}`;
        const qrMessageId = userDepositMessages.get(depositKey);
        if (qrMessageId) {
            try {
                await bot.deleteMessage(chatId, qrMessageId);
            } catch (deleteError) {}
            userDepositMessages.delete(depositKey);
        }
        
        const successMessage = `
Deposit Berhasil

${formatCurrency(amountToAdd)} telah ditambahkan ke saldo Anda
Saldo sekarang: ${formatCurrency(getUserBalance(userId))}

Terima kasih telah melakukan deposit`;
        
        const keyboard = {
            inline_keyboard: [
                [
                    { text: 'Deposit Lagi', callback_data: 'deposit_main' },
                    { text: 'Menu Utama', callback_data: 'main_menu' }
                ]
            ]
        };
        
        if (messageId) {
            await editMessage(chatId, messageId, null, successMessage, {
                parse_mode: 'HTML',
                reply_markup: keyboard
            });
        } else {
            await sendNewMessage(chatId, successMessage, {
                parse_mode: 'HTML',
                reply_markup: keyboard
            });
        }
        
        /*await createBackupOnEvent('deposit_success', {
            depositId: depositId,
            userId: userId,
            amount: amountToAdd,
            method: paymentMethod
        });*/
        
    } else if ((deposit.status === 'pending' || deposit.status === 'waiting') && messageId) {
        const updateMessage = `
Status Deposit

ID: #${depositId}
Jumlah: ${formatCurrency(deposit.total || depositAmount || 0)}
Status: Menunggu pembayaran`;
        
        await editMessage(chatId, messageId, null, updateMessage, {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'Periksa Status', callback_data: `deposit_status_${depositId}` },
                        { text: 'Batalkan', callback_data: `deposit_cancel_${depositId}` }
                    ],
                    [
                        { text: 'Menu Utama', callback_data: 'main_menu' }
                    ]
                ]
            }
        });
        
        setTimeout(() => {
            checkDepositStatus(chatId, depositId, userId, messageId, retryCount + 1);
        }, 10000);
        
    } else if (deposit.status === 'cancel' || deposit.status === 'cancelled' || deposit.status === 'expired' || deposit.status === 'failed') {
        const transactionType = isCashify ? 'cashify_deposits' : 'rumahotp_deposits';
        updateTransactionStatus(transactionType, depositId, deposit.status);

        const failedMessage = `
Deposit ${deposit.status.toUpperCase()}

ID: #${depositId}
Jumlah: ${formatCurrency(deposit.total || depositAmount || 0)}
Status: ${deposit.status}

Silakan ulangi deposit lagi.`;
    
        if (messageId) {
            await editMessage(chatId, messageId, null, failedMessage, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: 'Ulangi Deposit', callback_data: 'deposit_main' },
                            { text: 'Menu Utama', callback_data: 'main_menu' }
                        ]
                    ]
                }
            });
        }
    } else {
        setTimeout(() => {
            checkDepositStatus(chatId, depositId, userId, messageId, retryCount + 1);
        }, 10000);
    }
}

bot.on('message', async (msg) => {
  if (msg.text && msg.text.startsWith('/')) return;
  
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const text = msg.text;
  
  const selection = userSelections.get(userId);
  
  if (selection && selection.step === 'rumahotp_deposit_amount') {
    const amount = parseInt(text.replace(/[^\d]/g, ''));
    
    if (isNaN(amount) || amount < 2000 || amount > 5000000) {
        await sendNewMessage(chatId,
            `Nilai tidak valid.\n\nMinimal: Rp 2,000\nMaksimal: Rp 5,000,000`,
            { 
              parse_mode: 'HTML',
              reply_markup: { 
                inline_keyboard: [
                  [{ text: 'Coba Lagi', callback_data: 'deposit_main' }]
                ] 
              } 
            }
        );
        userSelections.delete(userId);
        return;
    }

    userSelections.delete(userId);
    
    await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
    
    await handleRumahOTPDeposit(chatId, userId, amount);
  }
});

async function showOrderHistory(chatId, userId, messageId, callbackQueryId) {
    try {
        const transactions = loadTransactions();
        const allOrders = transactions.nokos_orders || [];
        const userOrders = allOrders.filter(order => 
            String(order.userId) === String(userId)
        );
        
        const completedOrders = userOrders.filter(order => 
            order.status === 'completed' || 
            order.status === 'cancelled' || 
            order.status === 'expired'
        );
        
        if (completedOrders.length === 0) {
            await editMessage(chatId, messageId, callbackQueryId,
                'Riwayat Order\n\nBelum ada riwayat order yang selesai.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Buat Order', callback_data: 'nokos_menu' }],
                            [{ text: 'Menu Utama', callback_data: 'main_menu' }]
                        ]
                    }
                }
            );
            return;
        }

        const recentOrders = completedOrders.slice(-15).reverse();
        
        let message = '<b>📋 Riwayat Order Anda</b>\n';
        message += `Total Order Anda: ${completedOrders.length}\n\n`;
        
        recentOrders.forEach((order, index) => {
            const orderData = order.data;
            const date = new Date(order.timestamp).toLocaleString('id-ID');
            const maskedPhone = maskPhoneNumber(orderData.phoneNumber);
            
            let statusText = '';
            if (order.status === 'completed') {
                statusText = '✅ Sukses';
            } else if (order.status === 'cancelled') {
                statusText = '❌ Dibatalkan';
            } else if (order.status === 'expired') {
                statusText = '⏱️ Expired';
            } else {
                statusText = order.status || 'unknown';
            }
            
            message += `<b>${index + 1}. ${orderData.service || 'Nokos'}</b>\n`;
            message += `ID: <code>#${orderData.orderId}</code>\n`;
            message += `Nomor: ${maskedPhone}\n`;
            message += `Harga: ${formatCurrency(orderData.price || 0)}\n`;
            message += `Status: ${statusText}\n`;
 
            if (orderData.otp_code && orderData.otp_code !== '-' && orderData.otp_code !== '') {
                message += `OTP: <code>${orderData.otp_code}</code>\n`;
            }
            
            message += `Tanggal: ${date}\n\n`;
        });

        await editMessage(chatId, messageId, callbackQueryId, message, {
            parse_mode: 'HTML',
            disable_web_page_preview: true,
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'Order Baru', callback_data: 'nokos_menu' },
                        { text: 'Refresh', callback_data: 'order_history' }
                    ],
                    [
                        { text: 'Menu Utama', callback_data: 'main_menu' }
                    ]
                ]
            }
        });

    } catch (error) {
        await editMessage(chatId, messageId, callbackQueryId,
            '❌ Error\n\nGagal memuat riwayat order.',
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: 'Coba Lagi', callback_data: 'order_history' }]
                    ]
                }
            }
        );
    }
}

async function showDepositHistory(chatId, userId, messageId, callbackQueryId) {
    try {
        const transactions = loadTransactions();
        const allDeposits = [];
        
        if (transactions.rumahotp_deposits) {
            const userRumahOTP = transactions.rumahotp_deposits.filter(deposit => 
                String(deposit.userId) === String(userId)
            );
            allDeposits.push(...userRumahOTP);
        }
        
        if (transactions.cashify_deposits) { 
            const userCashify = transactions.cashify_deposits.filter(deposit => 
                String(deposit.userId) === String(userId)
            );
            allDeposits.push(...userCashify);
        }
        
        const successfulDeposits = allDeposits.filter(deposit => 
            deposit.status === 'success' || deposit.status === 'paid'
        );
        
        successfulDeposits.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
        
        if (successfulDeposits.length === 0) {
            await editMessage(chatId, messageId, callbackQueryId,
                '💰 Riwayat Deposit\n\nBelum ada riwayat deposit yang sukses.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Deposit', callback_data: 'deposit_main' }],
                            [{ text: 'Menu Utama', callback_data: 'main_menu' }]
                        ]
                    }
                }
            );
            return;
        }

        const recentDeposits = successfulDeposits.slice(0, 15);
        
        let message = '<b>💰 Riwayat Deposit Anda</b>\n';
        message += `Total Deposit Anda: ${successfulDeposits.length}\n\n`;
        
        recentDeposits.forEach((deposit, index) => {
            const depositData = deposit.data;
            const date = new Date(deposit.timestamp).toLocaleString('id-ID');
            
            let method = 'QRIS';
            if (depositData.method) {
                method = depositData.method;
            } else if (depositData.qr_string) {
                method = 'QRIS';
            }
            
            message += `<b>${index + 1}. Deposit ${formatCurrency(depositData.amount || depositData.total || 0)}</b>\n`;
            message += `ID: <code>#${depositData.id}</code>\n`;
            message += `Jumlah: ${formatCurrency(depositData.amount || depositData.total || 0)}\n`;
            message += `Diterima: ${formatCurrency(depositData.diterima || depositData.amount || 0)}\n`;
            message += `Biaya: ${formatCurrency(depositData.fee || 0)}\n`;
            message += `Metode: ${method}\n`;
            message += `Tanggal: ${date}\n\n`;
        });

        await editMessage(chatId, messageId, callbackQueryId, message, {
            parse_mode: 'HTML',
            disable_web_page_preview: true,
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'Deposit Lagi', callback_data: 'deposit_main' },
                        { text: 'Refresh', callback_data: 'deposit_history' }
                    ],
                    [
                        { text: 'Menu Utama', callback_data: 'main_menu' }
                    ]
                ]
            }
        });

    } catch (error) {
        await editMessage(chatId, messageId, callbackQueryId,
            '❌ Error\n\nGagal memuat riwayat deposit.',
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: 'Coba Lagi', callback_data: 'deposit_history' }]
                    ]
                }
            }
        );
    }
}

bot.on('callback_query', async (callbackQuery) => {
  const msg = callbackQuery.message;
  const user = callbackQuery.from;
  const data = callbackQuery.data;
  const chatId = msg.chat.id;
  const messageId = msg.message_id;
  const callbackQueryId = callbackQuery.id;
  
  try {
    bot.answerCallbackQuery(callbackQueryId, { 
      text: '',
      show_alert: false 
    }).catch(() => {});
    
    if (data === 'main_menu') {
      await showMainMenu(chatId, user.id, user, messageId, callbackQueryId);
      return;
    }
    
    if (data === 'nokos_menu') {
      await showNokosMenu(chatId, user.id, messageId, callbackQueryId);
      return;
    }
    
    if (data === 'nokos_other_services') {
      await showOtherServices(chatId, user.id, messageId, callbackQueryId);
      return;
    }
    
    if (data.startsWith('nokos_service_')) {
      const serviceId = data.replace('nokos_service_', '');
      const servicesData = await getServicesCached(); 
      if (servicesData && servicesData.success) {
        const service = servicesData.data.find(s => s.service_code == serviceId);
        if (service) {
          await showCountryMenu(chatId, user.id, serviceId, service.service_name, messageId, callbackQueryId);
        }
      }
      return;
    }

    if (data === 'setpay_rumahotp') {
      if (!owner_ids.includes(user.id.toString())) {
        return bot.answerCallbackQuery(callbackQueryId, {
          text: 'Hanya owner yang bisa setting',
          show_alert: true
        });
      }
      setPaymentMethod('rumahotp');
      await editMessage(chatId, messageId, callbackQueryId,
        `Metode pembayaran berhasil diubah.

Status saat ini:
Rumah OTP: Aktif
Cashify: Nonaktif

Detail sistem:
Provider: Rumah OTP
Tipe: QRIS
Auto Confirm: Ya
Biaya: Gratis

Pengubah: ${user.first_name}
Waktu: ${new Date().toLocaleTimeString('id-ID')}`,
        { 
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [
                { text: 'RUMAH OTP', callback_data: 'setpay_rumahotp' },
                { text: 'CASHIFY', callback_data: 'setpay_cashify' }
              ],
              [
                { text: 'Refresh Status', callback_data: 'setpay_refresh' }
              ]
            ]
          }
        }
      );
      return;
    }

    if (data === 'setpay_cashify') {
      if (!owner_ids.includes(user.id.toString())) {
        return bot.answerCallbackQuery(callbackQueryId, {
          text: 'Hanya owner yang bisa setting',
          show_alert: true
        });
      }
      setPaymentMethod('cashify');
      await editMessage(chatId, messageId, callbackQueryId,
        `Metode pembayaran berhasil diubah.

Status saat ini:
Rumah OTP: Nonaktif
Cashify: Aktif

Detail sistem:
Provider: Cashify.my.id
Tipe: QRIS Dynamic
E-Wallet: DANA
Auto Confirm: Ya
Biaya: Sesuai unique code

Pengubah: ${user.first_name}
Waktu: ${new Date().toLocaleTimeString('id-ID')}`,
        { 
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [
                { text: 'RUMAH OTP', callback_data: 'setpay_rumahotp' },
                { text: 'CASHIFY', callback_data: 'setpay_cashify' }
              ],
              [
                { text: 'Refresh Status', callback_data: 'setpay_refresh' }
              ]
            ]
          }
        }
      );
      return;
    }

    if (data === 'setpay_refresh') {
      if (!owner_ids.includes(user.id.toString())) {
        return bot.answerCallbackQuery(callbackQueryId, {
          text: 'Hanya owner yang bisa setting',
          show_alert: true
        });
      }
      const currentMethod = getPaymentMethod();
      const isRumahOTP = currentMethod === 'rumahotp';
      const isCashify = currentMethod === 'cashify';
      
      await editMessage(chatId, messageId, callbackQueryId,
        `Setting metode pembayaran.

Status system:
Rumah OTP: ${isRumahOTP ? 'Aktif' : 'Nonaktif'}
Cashify: ${isCashify ? 'Aktif' : 'Nonaktif'}

Informasi:
Semua deposit menggunakan metode ini
QRIS otomatis menyesuaikan
User tidak perlu pilih manual

Pilih metode yang ingin digunakan:`,
        { 
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [
                { 
                  text: isRumahOTP ? 'RUMAH OTP' : 'RUMAH OTP', 
                  callback_data: 'setpay_rumahotp' 
                },
                { 
                  text: isCashify ? 'CASHIFY' : 'CASHIFY', 
                  callback_data: 'setpay_cashify' 
                }
              ]
            ]
          }
        }
      );
      return;
    }

    if (data.startsWith('nokos_country_page_')) {
      const parts = data.replace('nokos_country_page_', '').split('_');
      const serviceId = parts[0];
      const page = parseInt(parts[1]);
      const servicesData = await getServicesCached();
      if (servicesData && servicesData.success) {
        const service = servicesData.data.find(s => s.service_code == serviceId);
        if (service) {
          await showCountryMenu(chatId, user.id, serviceId, service.service_name, messageId, callbackQueryId, page);
        }
      }
      return;
    }
    
    if (data.startsWith('nokos_server_list_')) {
      try {
        const parts = data.replace('nokos_server_list_', '').split('_');
        if (parts.length < 2) {
            throw new Error('Format data server tidak valid');
        }
        const numberId = parts[0];
        const countryName = decodeURIComponent(parts.slice(1).join('_'));
        await showServerList(chatId, user.id, numberId, countryName, messageId, callbackQueryId);
        return;
      } catch (error) {
        bot.answerCallbackQuery(callbackQueryId, {
            text: 'Error memproses pilihan server',
            show_alert: true
        }).catch(() => {});
        return;
      }
    }
    
    if (data.startsWith('nokos_server_')) {
      try {
        const parts = data.replace('nokos_server_', '').split('_');
        if (parts.length < 3) {
            throw new Error('Format data server tidak valid');
        }
        const providerId = parts[0];
        const price = parts[1];
        const rate = parts[2];
        const userSelection = userSelections.get(user.id) || {};
        userSelection.providerId = providerId;
        userSelection.price = price;
        userSelection.rate = rate;
        userSelections.set(user.id, userSelection);
        await showOperatorMenu(chatId, user.id, userSelection.numberId, price, userSelection.countryName, messageId, callbackQueryId);
        return;
      } catch (error) {
        bot.answerCallbackQuery(callbackQueryId, {
            text: 'Error memilih server',
            show_alert: true
        }).catch(() => {});
        return;
      }
    }
    
    if (data.startsWith('nokos_operator_')) {
      const parts = data.replace('nokos_operator_', '').split('_');
      const operatorId = parts[0];
      const providerId = parts[1];
      const price = parts[2];
      await showOrderConfirmation(chatId, user.id, operatorId, providerId, price, messageId, callbackQueryId);
      return;
    }
    
    if (data === 'owner_menu') {
    await showOwnerMenu(chatId, user.id, messageId, callbackQueryId);
      return;
    }
    
    if (data.startsWith('nokos_confirm_')) {
      const parts = data.replace('nokos_confirm_', '').split('_');
      const numberId = parts[0];
      const providerId = parts[1];
      const operatorId = parts[2];
      const price = parts[3];
      await processNokosOrder(chatId, user.id, numberId, providerId, operatorId, price, messageId, callbackQueryId);
      return;
    }
    
    if (data.startsWith('server_prev_')) {
      const parts = data.replace('server_prev_', '').split('_');
      const numberId = parts[0];
      const countryName = decodeURIComponent(parts.slice(1, parts.length - 1).join('_'));
      const startIndex = parseInt(parts[parts.length - 1]);
      await showServerListEnhanced(chatId, user.id, numberId, countryName, messageId, callbackQueryId, startIndex);
      return;
    }
    
    if (data.startsWith('server_next_')) {
      const parts = data.replace('server_next_', '').split('_');
      const numberId = parts[0];
      const countryName = decodeURIComponent(parts.slice(1, parts.length - 1).join('_'));
      const startIndex = parseInt(parts[parts.length - 1]);
      await showServerListEnhanced(chatId, user.id, numberId, countryName, messageId, callbackQueryId, startIndex);
      return;
    }
    
    if (data.startsWith('nokos_check_')) {
      const orderId = data.replace('nokos_check_', '');
      await checkOTP(chatId, orderId, messageId, callbackQueryId);
      return;
    }
    
    if (data.startsWith('nokos_cancel_')) {
      const orderId = data.replace('nokos_cancel_', '');
      await cancelOrder(chatId, user.id, orderId, messageId, callbackQueryId);
      return;
    }
    
    if (data === 'deposit_main') {
      await showDepositMenu(chatId, user.id, messageId, callbackQueryId);
      return;
    }
    
    if (data === 'order_history') {
      await showOrderHistory(chatId, user.id, messageId, callbackQueryId);
      return;
    }
    
    if (data === 'deposit_history') {
      await showDepositHistory(chatId, user.id, messageId, callbackQueryId);
      return;
    }
    
    if (data.startsWith('deposit_status_')) {
      const depositId = data.replace('deposit_status_', '');
      await editMessage(chatId, messageId, callbackQueryId,
        'Memeriksa status deposit...',
        { parse_mode: 'HTML' }
      );
      checkDepositStatus(chatId, depositId, user.id, messageId);
      return;
    }
    
    if (data.startsWith('wait_cancel_')) {
    const orderId = data.replace('wait_cancel_', '');
    const transactions = loadTransactions();
    const order = transactions.nokos_orders?.find(o => 
        o.id === orderId || o.data?.orderId === orderId
    );
    
    if (!order) {
        await bot.answerCallbackQuery(callbackQueryId, {
            text: 'Order tidak ditemukan',
            show_alert: true
        });
        return;
    }
    
    const orderTime = new Date(order.timestamp).getTime();
    const now = Date.now();
    const threeMinutes = 3 * 60 * 1000;
    const timeLeft = threeMinutes - (now - orderTime);
    
    if (timeLeft <= 0) {
        await bot.answerCallbackQuery(callbackQueryId, {
            text: '✅ Sekarang bisa membatalkan order',
            show_alert: true
        });

        await editMessage(chatId, messageId, callbackQueryId,
            `Order ID: <code>#${orderId}</code>\n\n✅ Order sudah bisa dibatalkan.\nKlik tombol "Batal Order" untuk membatalkan.`,
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { 
                                text: 'Cek OTP', 
                                callback_data: `nokos_check_${orderId}` 
                            },
                            { 
                                text: 'Batal Order', 
                                callback_data: `nokos_cancel_${orderId}` 
                            }
                        ],
                        [
                            { 
                                text: 'Order Baru', 
                                callback_data: 'nokos_menu' 
                            },
                            { 
                                text: 'Menu Utama', 
                                callback_data: 'main_menu' 
                            }
                        ]
                    ]
                }
            }
        );
    } else {
        const minutesLeft = Math.floor(timeLeft / 60000);
        const secondsLeft = Math.floor((timeLeft % 60000) / 1000);
        
        let timeText = '';
        if (minutesLeft > 0) {
            timeText = `${minutesLeft}m ${secondsLeft}s`;
        } else {
            timeText = `${secondsLeft}s`;
        }
        
        let buttonText = '';
        if (minutesLeft > 0) {
            buttonText = `${minutesLeft}m`;
        } else if (secondsLeft > 0) {
            buttonText = `${secondsLeft}s`;
        } else {
            buttonText = '0s';
        }
        
        await bot.answerCallbackQuery(callbackQueryId, {
            text: `⏳ Tunggu ${timeText} sebelum bisa membatalkan`,
            show_alert: true
        });
        
        await editMessage(chatId, messageId, callbackQueryId,
            `Order ID: <code>#${orderId}</code>\n\n⏳ Tunggu ${timeText} sebelum bisa membatalkan order.\n\nOrder masih dalam proses aktivasi nomor.`,
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { 
                                text: 'Cek OTP', 
                                callback_data: `nokos_check_${orderId}` 
                            },
                            { 
                                text: buttonText, 
                                callback_data: `wait_cancel_${orderId}` 
                            }
                        ],
                        [
                            { 
                                text: 'Order Baru', 
                                callback_data: 'nokos_menu' 
                            },
                            { 
                                text: 'Menu Utama', 
                                callback_data: 'main_menu' 
                            }
                        ]
                    ]
                }
            }
        );
    }
    return;
    }

    if (data.startsWith('deposit_cancel_')) {
  const depositId = data.replace('deposit_cancel_', '');
  bot.deleteMessage(chatId, messageId).catch(() => {});
  const loadingMsg = await sendNewMessage(chatId,
    'Membatalkan deposit...',
    { parse_mode: 'HTML' }
  );
  
  const paymentMethod = getPaymentMethod();
  let cancelResult;
  
  if (paymentMethod === 'cashify') {
    cancelResult = await cashifyService.cancelDeposit(depositId);
  } else {
    cancelResult = await api.cancelRumahOTPDeposit(depositId);
  }
  
  const isCashify = paymentMethod === 'cashify';
  const successCheck = isCashify ? 
    cancelResult?.success : 
    cancelResult?.success;
  
  if (successCheck) {
    const transactionType = isCashify ? 'cashify_deposits' : 'rumahotp_deposits';
    updateTransactionStatus(transactionType, depositId, 'cancelled');
    
    await editMessage(chatId, loadingMsg.message_id, null,
      `Deposit berhasil dibatalkan
      
ID Deposit: <code>${depositId}</code>
Status: Dibatalkan
Waktu: ${new Date().toLocaleTimeString('id-ID')}`,
      { 
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: 'Deposit Lagi', callback_data: 'deposit_main' }],
            [{ text: 'Menu Utama', callback_data: 'main_menu' }]
          ]
        }
      }
    );
  } else {
    const errorMsg = cancelResult?.message || 
                    cancelResult?.error?.message || 
                    cancelResult?.error || 
                    'Gagal membatalkan deposit';
    
    await editMessage(chatId, loadingMsg.message_id, null,
      `Gagal membatalkan deposit
      
Pesan Error: ${errorMsg}
ID Deposit: <code>${depositId}</code>`,
      { 
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: 'Coba Lagi', callback_data: 'deposit_main' }],
            [{ text: 'Menu Utama', callback_data: 'main_menu' }]
          ]
        }
      }
    );
  }
  return;
}
    
    if (data === 'refresh_maintenance') {
      const userId = user.id.toString();
      const maintenance = getMaintenanceInfo();
      if (maintenance.active && !owner_ids.includes(userId)) {
        await bot.answerCallbackQuery(callbackQueryId, {
          text: 'Bot masih dalam maintenance',
          show_alert: true
        });
        return;
      }
      
      balanceCache.delete(userId);
      
      await bot.deleteMessage(chatId, messageId).catch(() => {});
      saveUser(userId);
      await showMainMenu(chatId, userId, user, null, callbackQueryId);
      return;
    }
    
    if (data.startsWith('deposit_amount_')) {
      const amount = data.replace('deposit_amount_', '');
      userSelections.delete(user.id);
      bot.deleteMessage(chatId, messageId).catch(() => {});
      await handleRumahOTPDeposit(chatId, user.id, parseInt(amount));
      return;
    }
    
    if (data === 'deposit_custom') {
      await editMessage(chatId, messageId, callbackQueryId,
        `Deposit Custom

Kirim jumlah deposit dalam angka:
Minimal: Rp2.000
Maksimal: Rp5.000.000

Contoh: <code>25000</code>
Format: Angka saja (tanpa titik/koma)`,
        { 
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [{ text: 'Kembali', callback_data: 'deposit_main' }]
            ]
          }
        }
      );
      userSelections.set(user.id, { step: 'rumahotp_deposit_amount' });
      return;
    }
    
    bot.answerCallbackQuery(callbackQueryId, { 
      text: 'Tombol tidak dikenali', 
      show_alert: false 
    }).catch(() => {});
    
  } catch (error) {
    try {
      await sendNewMessage(chatId,
        `Terjadi kesalahan sistem.

Pesan Error: ${error.message || 'Unknown error'}
Waktu: ${new Date().toLocaleTimeString('id-ID')}

Silakan coba lagi atau hubungi admin`,
        { 
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [{ text: 'Coba Lagi', callback_data: 'main_menu' }]
            ]
          }
        }
      );
    } catch (e) {}
  }
});

const servicesCache = {
  data: null,
  timestamp: 0,
  ttl: 2 * 60 * 1000,
  loading: false
};

async function getServicesCached() {
  const now = Date.now();
  
  if (servicesCache.data && (now - servicesCache.timestamp < servicesCache.ttl)) {
    return servicesCache.data;
  }
  
  if (servicesCache.loading) {
    return servicesCache.data || { success: false, data: [] };
  }
  
  servicesCache.loading = true;
  
  try {
    const servicesData = await api.getServices();
    if (servicesData && servicesData.success) {
      servicesCache.data = servicesData;
      servicesCache.timestamp = now;
    }
    return servicesData;
  } catch (error) {
    return servicesCache.data || { success: false, data: [] };
  } finally {
    servicesCache.loading = false;
  }
}

async function preloadAllData() {
  try {
    await getServicesCached();
    
    const balances = loadBalances();
    Object.entries(balances).forEach(([userId, balance]) => {
      balanceCache.set(userId, parseInt(balance) || 0);
    });
    
    loadTransactions();
  } catch (error) {}
}

preloadAllData();

async function notifyOrderSuccess(user, orderData, price, hasOTP = false) {
    try {
        const orderId = orderData.order_id;
        const notificationKey = `order_${orderId}_${hasOTP ? 'otp' : 'pending'}`;
        
        if (sentNotifications.has(notificationKey)) {
            return;
        }
        
        const userId = user.id;
        const firstName = user.first_name || 'User';
        const username = user.username ? `@${user.username}` : 'Tidak ada username';
        const maskedPhone = maskPhoneNumber(orderData.phone_number);     
        const formattedPrice = formatCurrency(price);

        if (!hasOTP || !orderData.otp_code || orderData.otp_code === '-') {
            const ownerMessage = `Order baru - Menunggu OTP

User:
Nama: ${firstName}
Username: ${username}
ID: ${userId}

Order:
ID: #${orderData.order_id}
Nomor: ${maskedPhone}
Layanan: ${orderData.service}
Negara: ${orderData.country}
Operator: ${orderData.operator || '-'}
Harga: ${formattedPrice}
Status: Menunggu OTP

Waktu: ${new Date().toLocaleString('id-ID')}`;

           await bot.sendMessage(channel, ownerMessage, {
                parse_mode: 'HTML',
                disable_web_page_preview: true,
            });
            
            sentNotifications.set(notificationKey, Date.now());
            return;
        } else {
            const otpCode = orderData.otp_code;
            const formattedOTP = otpCode.length === 6 ? `${otpCode.substring(0, 3)}-${otpCode.substring(3)}` : otpCode;
            const dateStr = new Date().toLocaleString('id-ID', { 
                day: 'numeric', 
                month: 'short', 
                year: 'numeric', 
                hour: '2-digit', 
                minute: '2-digit' 
            });
            
            const channelMessage = `OTP RECEIVED

<b>ID:</b> ${orderData.order_id}
<b>Users:</b> ${firstName}
<b>Number:</b> ${maskedPhone}
<b>SMS code:</b> ${formattedOTP}
<b>Harga:</b> ${formattedPrice}
<b>Tanggal:</b> ${dateStr}

${orderData.service || 'Layanan'}: kode verifikasi anda ${formattedOTP}, Jangan diberikan pada siapapun`;
            
            const keyboard = {
                inline_keyboard: [
                    [
                        { 
                            text: '🛒 Orders', 
                            url: 'https://t.me/andinnstorebot'
                        },
                        { 
                            text: '💬 Support', 
                            text: 'Channel', url: `https://t.me/${channel.replace('@', '')}`
                        }
                    ]
                ]
            };
            
            await bot.sendMessage(channel, channelMessage, {
                parse_mode: 'HTML',
                disable_web_page_preview: true,
                reply_markup: keyboard
            });
            
            sentNotifications.set(notificationKey, Date.now());
        }
    } catch (error) {
        console.error('Notify Order Error:', error);
    }
}

async function notifyDepositSuccess(user, amount, depositId, newBalance) {
    try {
        const notificationKey = `deposit_${depositId}`;
        
        if (sentNotifications.has(notificationKey)) {
            return;
        }
        
        const userId = user.id;
        const firstName = user.first_name || 'User';
        const username = user.username ? `@${user.username}` : 'Tidak ada username';
        const dateStr = new Date().toLocaleString('id-ID', { 
            day: 'numeric', 
            month: 'short', 
            year: 'numeric', 
            hour: '2-digit', 
            minute: '2-digit' 
        });
        
        const channelMessage = `DEPOSIT SUCCESS!!

<b>ID:</b> ${depositId}
<b>Users:</b> ${firstName}
<b>Nominal:</b> ${formatCurrency(amount)}
<b>Method:</b> QRIS 
<b>Tanggal:</b> ${dateStr}`;
        
        const keyboard = {
            inline_keyboard: [
                [
                    { 
                        text: '🛒 Orders', 
                        url: 'https://t.me/andinnstorebot'
                    },
                    { 
                        text: '💬 Support', 
                        url: `https://t.me/${channel.replace('@','')}`
                    }
                ]
            ]
        };
        
        await bot.sendMessage(channel, channelMessage, {
            parse_mode: 'HTML',
            disable_web_page_preview: true,
            reply_markup: keyboard
        });
        
        sentNotifications.set(notificationKey, Date.now());
        
    } catch (error) {}
}

setInterval(() => {
    const now = Date.now();
    const oneHour = 60 * 60 * 1000;
    
    for (const [key, timestamp] of sentNotifications.entries()) {
        if (now - timestamp > oneHour) {
            sentNotifications.delete(key);
        }
    }

    for (const [key, timestamp] of orderProcessing.entries()) {
        if (now - timestamp > 5 * 60 * 1000) { 
            orderProcessing.delete(key);
        }
    }
}, 60 * 60 * 1000);

async function notifyOwnerDepositCreated(depositData, userId, amount, paymentMethod) {
    try {
        const user = await bot.getChat(userId);
        const dateStr = new Date().toLocaleString('id-ID', { 
            day: 'numeric', 
            month: 'short', 
            year: 'numeric', 
            hour: '2-digit', 
            minute: '2-digit' 
        });
        
        const message = `DEPOSIT PENDING

<b>Users:</b> ${user.first_name}
<b>Username:</b> ${user.username ? '@' + user.username : 'Tidak ada'}
<b>ID:</b> ${user.id}

<b>Deposit:</b>
ID: #${depositData.id || depositData.no_inv}
Jumlah: ${formatCurrency(amount)}
Metode: QRIS
Fee: ${formatCurrency(depositData.fee || 0)}
Diterima: ${formatCurrency(depositData.diterima || amount)}

<b>Status:</b> Menunggu pembayaran
<b>Batas waktu:</b> 20 menit
<b>Tanggal:</b> ${dateStr}`;

        for (const ownerId of owner_ids) {
            try {
                await bot.sendMessage(ownerId, message, { 
                    parse_mode: 'HTML',
                    disable_web_page_preview: true 
                });
            } catch (error) {}
        }
    } catch (error) {}
}

function maskPhoneNumber(phoneNumber) {
    if (!phoneNumber) return '-';
    const cleanNumber = phoneNumber.replace(/\D/g, '');
    if (cleanNumber.length <= 4) return cleanNumber;
    const visibleDigits = Math.min(4, Math.floor(cleanNumber.length / 2));
    const firstPart = cleanNumber.substring(0, visibleDigits);
    const lastPart = cleanNumber.substring(cleanNumber.length - visibleDigits);
    return `${firstPart}****${lastPart}`;
}

function loadUserNotifications() {
    try {
        const notificationsFile = path.join(dataDir, 'notified_users.json');
        if (!fs.existsSync(notificationsFile)) {
            return;
        }
        
        const data = JSON.parse(fs.readFileSync(notificationsFile, 'utf8'));
        data.users.forEach(userId => {
            userFirstTimeNotifications.add(userId);
        });
        console.log(`Loaded ${data.users.length} notified users from file`);
    } catch (error) {
        console.error('Error loading user notifications:', error);
    }
}

function saveUserNotifications() {
    try {
        const notificationsFile = path.join(dataDir, 'notified_users.json');
        const data = {
            users: Array.from(userFirstTimeNotifications),
            lastUpdated: new Date().toISOString()
        };
        fs.writeFileSync(notificationsFile, JSON.stringify(data, null, 2));
    } catch (error) {
        console.error('Error saving user notifications:', error);
    }
}

async function notifyNewUser(user, userBalance = 0) {
    try {
        const userId = user.id.toString();
        
        // Cek apakah user sudah pernah dikirim notifikasi
        if (userFirstTimeNotifications.has(userId)) {
            return; // User sudah pernah dikirim notifikasi
        }
        
        // Tandai bahwa user sudah dikirim notifikasi
        userFirstTimeNotifications.add(userId);
        
        const firstName = user.first_name || 'Tidak ada';
        const username = user.username ? `@${user.username}` : 'Tidak ada username';
        
        const message = `<b>📋 USER BARU MEMULAI BOT</b>

<b>Informasi User:</b>
├ User ID: <code>${userId}</code>
├ Username: ${username}
├ Nama: ${firstName}
└ Saldo Awal: ${formatCurrency(userBalance)}

<b>Waktu:</b> ${new Date().toLocaleString('id-ID')}

<i>Status: ✅ User baru terdaftar</i>`;
        
        for (const adminId of owner_ids) {
            try {
                await bot.sendMessage(adminId, message, {
                    parse_mode: 'HTML',
                    disable_web_page_preview: true
                });
            } catch (error) {}
        }
        
    } catch (error) {
        console.error('Error in notifyNewUser:', error);
    }
}

bot.onText(/\/start/, withRequireJoin(async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const user = msg.from;
  
  if (!(await checkMaintenance(msg))) {
    return;
  }
  
  const data = loadData();
  const userIdStr = String(userId);
  
  const saveResult = saveUser(userId);
  
  const userBalance = getUserBalance(userId);
  
  // Hanya notify jika user baru
  if (saveResult.isNewUser) {
    await notifyNewUser(user, userBalance);
  }
  
  balanceCache.delete(userIdStr);
  
  await showMainMenu(chatId, userId, user);
}));

bot.onText(/^\/broadcast$/, async (msg) => {
  try {
    const chatId = msg.chat.id;
    const senderId = msg.from.id.toString();
    const mainOwnerId = owner_ids[0];
    
    if (senderId !== mainOwnerId) {
      return await bot.sendMessage(chatId, 
        "Akses ditolak.\n\nHanya owner utama yang dapat menggunakan command ini.",
        { parse_mode: "HTML" }
      ).catch(() => {});
    }

    if (!msg.reply_to_message) {
      return await bot.sendMessage(chatId, 
        `Broadcast message.

Cara penggunaan:
1. Reply pesan yang ingin di broadcast
2. Ketik command /broadcast

Supported message:
Text, Photo, Document, Video

Pastikan pesan sudah benar sebelum dikirim`,
        { parse_mode: "HTML" }
      ).catch(() => {});
    }

    const data = loadData();
    const uniqueUsers = [...new Set(data.users || [])];
    const total = uniqueUsers.length;

    if (total === 0) {
      return await bot.sendMessage(chatId, "Tidak ada user yang terdaftar.", { parse_mode: "HTML" }).catch(() => {});
    }

    const processingMsg = await bot.sendMessage(chatId, 
      `Memulai broadcast.

Statistik:
Total user: ${total}
Status: Mengirim...
Progress: 0%

Mohon tunggu proses broadcast...`, 
      { parse_mode: "HTML" }
    );

    const reply = msg.reply_to_message;
    let sukses = 0, gagal = 0;
    const broadcastHeader = `📢 BROADCAST DARI ADMIN\n`;

    for (let i = 0; i < uniqueUsers.length; i++) {
      const userId = uniqueUsers[i];
      try {
        if (reply.text) {
          const messageWithHeader = `${broadcastHeader}${reply.text}`;
          await bot.sendMessage(userId, messageWithHeader, { 
            parse_mode: 'HTML',
            disable_web_page_preview: true
          }).catch(() => {
            bot.sendMessage(userId, `${broadcastHeader}${reply.text}`).catch(() => {});
          });
        } else if (reply.photo) {
          const fileId = reply.photo[reply.photo.length - 1].file_id;
          const captionWithHeader = reply.caption ? `${broadcastHeader}${reply.caption}` : broadcastHeader;
          await bot.sendPhoto(userId, fileId, { 
            caption: captionWithHeader,
            parse_mode: 'HTML'
          }).catch(() => {});
        } else if (reply.document) {
          const captionWithHeader = reply.caption ? `${broadcastHeader}${reply.caption}` : broadcastHeader;
          await bot.sendDocument(userId, reply.document.file_id, { 
            caption: captionWithHeader,
            parse_mode: 'HTML'
          }).catch(() => {});
        } else if (reply.video) {
          const captionWithHeader = reply.caption ? `${broadcastHeader}${reply.caption}` : broadcastHeader;
          await bot.sendVideo(userId, reply.video.file_id, { 
            caption: captionWithHeader,
            parse_mode: 'HTML'
          }).catch(() => {});
        } else {
          await bot.sendMessage(userId, `${broadcastHeader}Jenis pesan ini belum bisa di broadcast.`, {
            parse_mode: 'HTML'
          }).catch(() => {});
        }
        sukses++;
      } catch (err) {
        gagal++;
      }

      if (i % 10 === 0 || i === uniqueUsers.length - 1) {
        const progress = Math.round(((i + 1) / uniqueUsers.length) * 100);
        try {
          await bot.editMessageText(
            `Memulai broadcast.

Statistik:
Total user: ${total}
Status: Mengirim...
Progress: ${progress}%

Mohon tunggu proses broadcast...`,
            {
              chat_id: chatId,
              message_id: processingMsg.message_id,
              parse_mode: "HTML"
            }
          );
        } catch (editError) {}
      }

      await new Promise(r => setTimeout(r, 200));
    }

    try {
      await bot.editMessageText(
        `Broadcast selesai.

Hasil broadcast:
Total user: ${total}
Sukses: ${sukses}
Gagal: ${gagal}

Statistik:
Success rate: ${Math.round((sukses / total) * 100)}%`,
        {
          chat_id: chatId,
          message_id: processingMsg.message_id,
          parse_mode: "HTML"
        }
      );
    } catch (editError) {
      await bot.sendMessage(chatId,
        `Broadcast selesai.

Hasil broadcast:
Total user: ${total}
Sukses: ${sukses}
Gagal: ${gagal}

Statistik:
Success rate: ${Math.round((sukses / total) * 100)}%`,
        { parse_mode: "HTML" }
      ).catch(() => {});
    }
  } catch (err) {
    await bot.sendMessage(msg.chat.id, "Terjadi error saat memproses broadcast.", { parse_mode: "HTML" }).catch(() => {});
  }
});

bot.onText(/^\/setpay$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  
  if (!owner_ids.includes(userId)) {
    return bot.sendMessage(chatId, 
      "Hanya owner yang bisa mengganti metode pembayaran",
      { parse_mode: 'HTML' }
    );
  }
  
  const currentMethod = getPaymentMethod();
  const isRumahOTP = currentMethod === 'rumahotp';
  const isCashify = currentMethod === 'cashify';   
  const message = `Setting metode pembayaran.

Status saat ini:
Rumah OTP: ${isRumahOTP ? 'Aktif' : 'Nonaktif'}
Cashify: ${isCashify ? 'Aktif' : 'Nonaktif'}

Informasi:
QRIS akan menyesuaikan metode
User tidak akan melihat perbedaan
Sistem otomatis

Klik tombol untuk mengganti:`;
  
  await bot.sendMessage(chatId, message, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { 
            text: isRumahOTP ? 'RUMAH OTP' : 'RUMAH OTP', 
            callback_data: 'setpay_rumahotp' 
          },
          { 
            text: isCashify ? 'CASHIFY' : 'CASHIFY', 
            callback_data: 'setpay_cashify' 
          }
        ]
      ]
    }
  });
});

bot.onText(/^\/maintenance/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  
  if (!owner_ids.includes(userId)) {
    return bot.sendMessage(chatId, 
      "Hanya owner yang bisa menggunakan command ini",
      { parse_mode: 'HTML' }
    );
  }
  
  const text = msg.text || '';
  const args = text.trim().split(/\s+/);
  
  if (args.length === 1) {
    const maintenance = getMaintenanceInfo();
    const status = maintenance.active ? 'ON' : 'OFF';
    const reason = maintenance.reason ? `\n\nAlasan: ${maintenance.reason}` : '';
    
    return bot.sendMessage(chatId,
      `Status maintenance.

Status: ${status}${reason}

Format:
/maintenance on (reply pesan untuk alasan)
/maintenance off`,
      { parse_mode: 'HTML' }
    );
  }
  
  const command = args[1].toLowerCase();
  
  if (command === 'off') {
    setMaintenance(false);
    return bot.sendMessage(chatId,
      `Maintenance mode dimatikan.

Bot sekarang bisa digunakan oleh semua user.`,
      { parse_mode: 'HTML' }
    );
  }
  
  if (command === 'on') {
    if (!msg.reply_to_message) {
      return bot.sendMessage(chatId,
        `Reply pesan untuk alasan maintenance.

Contoh:
1. Ketik alasan maintenance (contoh: "Perbaikan server")
2. Reply pesan tersebut
3. Kirim /maintenance on`,
        { parse_mode: 'HTML' }
      );
    }
    
    const reason = msg.reply_to_message.text || 'Bot sedang dalam perbaikan';
    setMaintenance(true, reason);
    
    return bot.sendMessage(chatId,
      `Maintenance mode diaktifkan.

Alasan: ${reason}

Efek:
User biasa tidak bisa menggunakan bot
Owner masih bisa mengakses
User akan lihat pesan maintenance`,
      { parse_mode: 'HTML' }
    );
  }
  
  bot.sendMessage(chatId,
    "Format salah.\n\nGunakan: /maintenance on atau /maintenance off",
    { parse_mode: 'HTML' }
  );
});

bot.onText(/\/stats/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (!owner_ids.includes(userId.toString())) {
        await bot.sendMessage(chatId, 
            "Command ini hanya untuk owner!",
            { parse_mode: 'HTML' }
        );
        return;
    }
    
    const data = loadData();
    const balances = loadBalances();
    const transactions = loadTransactions();
    
    const totalUsers = data.users?.length || 0;
    const totalOrders = transactions.nokos_orders?.length || 0;
    const cashifyDeposits = transactions.cashify_deposits?.length || 0; 
    const rumahotpDeposits = transactions.rumahotp_deposits?.length || 0;
    const totalDeposits = cashifyDeposits + rumahotpDeposits; 

    let totalBalance = 0;
    let usersWithBalance = 0;
    Object.values(balances).forEach(balance => {
        const amount = parseInt(balance) || 0;
        totalBalance += amount;
        if (amount > 0) usersWithBalance++;
    });
    
    let apiBalanceResult = '';
    try {
        const balanceResult = await api.getUserBalanceAPI();
        if (balanceResult && balanceResult.success) {
            const apiBalance = balanceResult.data?.balance || balanceResult.data?.saldo || 0;
            const apiCurrency = balanceResult.data?.currency || 'IDR';
            apiBalanceResult = `${formatCurrency(apiBalance)} (${apiCurrency})`;
        } else {
            apiBalanceResult = 'Gagal mengambil';
        }
    } catch (error) {
        apiBalanceResult = 'Gagal mengambil';
    }
    
    const message = `📊 <b>STATISTIK BOT</b>

<b>📱 User Statistics:</b>
├ Total users: ${totalUsers}
├ User dengan saldo: ${usersWithBalance}
└ User tanpa saldo: ${totalUsers - usersWithBalance}

<b>💰 Financial Statistics:</b>
├ Total saldo bot: ${formatCurrency(totalBalance)}
├ Saldo API: ${apiBalanceResult}
├ Rata-rata saldo/user: ${formatCurrency(totalUsers > 0 ? Math.round(totalBalance / totalUsers) : 0)}
└ User terbanyak saldo: ${getTopUserBalance(balances)}

<b>🔄 Transaction Statistics:</b>
├ Total order: ${totalOrders}
├ Total deposit: ${totalDeposits}
├ └ Cashify: ${cashifyDeposits} 
├ └ Rumah OTP: ${rumahotpDeposits}
└ Success rate: ${totalOrders > 0 ? Math.round((totalOrders / (totalOrders + totalDeposits)) * 100) : 0}%

<b>📈 Today's Activity:</b>
${getTodayStats(transactions)}

<b>⏰ System:</b>
└ Update terakhir: ${new Date().toLocaleString('id-ID')}`;
    
    await bot.sendMessage(chatId, message, {
        parse_mode: 'HTML',
        disable_web_page_preview: true
    });
});

function getTopUserBalance(balances) {
    let topUserId = null;
    let topBalance = 0;
    
    Object.entries(balances).forEach(([userId, balance]) => {
        const amount = parseInt(balance) || 0;
        if (amount > topBalance) {
            topBalance = amount;
            topUserId = userId;
        }
    });
    
    return topUserId ? `${topUserId} (${formatCurrency(topBalance)})` : 'Tidak ada';
}

function getTodayStats(transactions) {
    const today = new Date().toISOString().split('T')[0];
    let todayOrders = 0;
    let todayDeposits = 0;
    let todayDepositAmount = 0;
    
    if (transactions.nokos_orders) {
        todayOrders = transactions.nokos_orders.filter(order => {
            const orderDate = new Date(order.timestamp).toISOString().split('T')[0];
            return orderDate === today;
        }).length;
    }
    
    ['cashify_deposits', 'rumahotp_deposits'].forEach(type => { 
        if (transactions[type]) {
            const todayDepositsData = transactions[type].filter(deposit => {
                const depositDate = new Date(deposit.timestamp).toISOString().split('T')[0];
                return depositDate === today;
            });
            
            todayDeposits += todayDepositsData.length;
            todayDepositsData.forEach(deposit => {
                todayDepositAmount += parseInt(deposit.data?.amount || deposit.data?.total || 0);
            });
        }
    });
    
    return `├ Order hari ini: ${todayOrders}\n├ Deposit hari ini: ${todayDeposits}\n└ Total deposit hari ini: ${formatCurrency(todayDepositAmount)}`;
}

async function addBalanceAdmin(chatId, adminId, commandText) {
    try {
        const parts = commandText.split(' ');
        if (parts.length < 3) {
            await bot.sendMessage(chatId,
                `Format salah.

Format: /addsaldo [user_id] [jumlah]
Contoh: /addsaldo 123456789 20000

Catatan:
User ID harus berupa angka
Jumlah minimal Rp 1.000`,
                { parse_mode: 'HTML' }
            );
            return;
        }

        const targetUserId = parts[1];
        const amount = parseInt(parts[2]);
        const userIdValidation = validateUserId(targetUserId);
        if (!userIdValidation.valid) {
            await bot.sendMessage(chatId,
                `User ID tidak valid: ${userIdValidation.error}

User ID yang dimasukkan: ${targetUserId}`,
                { parse_mode: 'HTML' }
            );
            return;
        }

        const amountValidation = validateAmount(amount);
        if (!amountValidation.valid || amountValidation.amount < 1000) {
            await bot.sendMessage(chatId,
                `Jumlah tidak valid: ${amountValidation.error || 'Minimal Rp 1.000'}

Jumlah yang dimasukkan: ${formatCurrency(amount)}`,
                { parse_mode: 'HTML' }
            );
            return;
        }

        const numAmount = amountValidation.amount;

        if (numAmount > 5000000) {
            await bot.sendMessage(chatId,
                `Jumlah terlalu besar.

Maksimal penambahan saldo: Rp 5,000,000
Jumlah yang dimasukkan: ${formatCurrency(numAmount)}`,
                { parse_mode: 'HTML' }
            );
            return;
        }

        const data = loadData();
        if (!data.users) data.users = [];
        
        const userExists = data.users.some(id => id === targetUserId);
        if (!userExists) {
            data.users.push(targetUserId);
            saveData(data);
        }
        
        balanceCache.delete(targetUserId);
        
        const oldBalance = getUserBalance(targetUserId);
        const success = addUserBalance(targetUserId, numAmount);
        const newBalance = getUserBalance(targetUserId);

        if (!success) {
            await bot.sendMessage(chatId,
                `Gagal menambah saldo.

Terjadi kesalahan sistem saat menambah saldo
User ID: ${targetUserId}
Jumlah: ${formatCurrency(numAmount)}`,
                { parse_mode: 'HTML' }
            );
            return;
        }

        await bot.sendMessage(chatId,
            `Saldo berhasil ditambahkan.

Detail transaksi:
User ID: ${targetUserId}
Jumlah: ${formatCurrency(numAmount)}
Saldo lama: ${formatCurrency(oldBalance)}
Saldo baru: ${formatCurrency(newBalance)}
Admin: ${adminId}

Notifikasi telah dikirim ke user`,
            { parse_mode: 'HTML' }
        );

        try {
            const user = await bot.getChat(targetUserId);
            await bot.sendMessage(targetUserId,
                `Saldo Anda telah ditambahkan.

Detail penambahan:
Jumlah: ${formatCurrency(numAmount)}
Saldo lama: ${formatCurrency(oldBalance)}
Saldo baru: ${formatCurrency(newBalance)}

Saldo telah berhasil ditambahkan oleh Admin
Terima kasih telah menggunakan layanan kami!`,
                { parse_mode: 'HTML' }
            );
        } catch {
            await bot.sendMessage(chatId,
                `Peringatan.

Saldo berhasil ditambahkan ke user ID: ${targetUserId}
Namun tidak dapat mengirim notifikasi ke user (mungkin belum pernah start bot)`,
                { parse_mode: 'HTML' }
            );
        }

        /*await createBackupOnEvent('balance_added', {
            targetUserId: targetUserId,
            amount: numAmount,
            adminId: adminId
        });*/

    } catch (error) {
        await bot.sendMessage(chatId,
            `Terjadi kesalahan.

Gagal memproses perintah /addsaldo
Silakan coba lagi atau hubungi developer`,
            { parse_mode: 'HTML' }
        );
    }
}

setInterval(() => {
    autoBackupTransactions('auto_backup', {});
}, 7200000);

bot.onText(/^\/addsaldo(\s|$)/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    if (!owner_ids.includes(userId)) {
        await bot.sendMessage(chatId,
            `Akses ditolak.

Command ini hanya untuk Admin
Silakan hubungi Admin untuk bantuan`,
            { parse_mode: 'HTML' }
        );
        return;
    }
    
    await addBalanceAdmin(chatId, userId, msg.text);
});

setInterval(monitorSpecificPrices, 15 * 60 * 1000); 
setInterval(monitorStockLevels, 30 * 60 * 1000);
scheduleDailySummary();

async function monitorSpecificPrices() {
  try {
    if (isCheckingPrices) return;
    isCheckingPrices = true;
    
    const servicesData = await getServicesCached();
    
    if (!servicesData || !servicesData.success) {
      isCheckingPrices = false;
      return;
    }

    const services = servicesData.data;
    const targetServices = [];
    
    for (const service of services) {
      const serviceName = service.service_name.toLowerCase();
      
      if (serviceName.includes('whatsapp') || serviceName.includes('telegram')) {
        targetServices.push(service);
      }
      
      if (targetServices.length >= 2) break;
    }
    
    for (const service of targetServices) {
      await checkServiceIndonesia(service);
      await new Promise(resolve => setTimeout(resolve, 5000));
    }
    
    isCheckingPrices = false;
  } catch (error) {
    isCheckingPrices = false;
  }
}

async function checkServiceIndonesia(service) {
  try {
    const countriesData = await api.getCountries(service.service_code);
    
    if (!countriesData || !countriesData.success) {
      return;
    }

    const countries = countriesData.data || [];
    
    for (const country of countries) {
      const countryName = country.name.toLowerCase();
      
      if (!countryName.includes('indonesia') && !countryName.includes('indo')) {
        continue;
      }
      
      if (!country.pricelist || country.pricelist.length === 0) {
        continue;
      }

      const cacheKey = `${service.service_code}_${country.number_id}`;
      const currentPrices = country.pricelist.map(server => ({
        provider_id: server.provider_id,
        price: server.price,
        rate: server.rate,
        stock: server.stock
      }));

      const previousPrices = priceCache.get(cacheKey);
      
      priceCache.set(cacheKey, currentPrices);
      
      if (previousPrices) {
        const changes = detectPriceChanges(previousPrices, currentPrices, service, country);
        if (changes.length > 0) {
          await notifyPriceChanges(changes, service, country);
        }
      } else {
        priceCache.set(cacheKey, currentPrices);
      }
    }
    
  } catch (error) {}
}

function detectPriceChanges(oldPrices, newPrices, service, country) {
  const changes = [];
  const notificationKey = `${service.service_code}_${country.number_id}`;
  const lastNotified = lastNotificationTime.get(notificationKey) || 0;
  const now = Date.now();
  
  if (now - lastNotified < 60 * 60 * 1000) {
    return changes;
  }

  for (let i = 0; i < Math.min(oldPrices.length, newPrices.length); i++) {
    const oldPrice = oldPrices[i];
    const newPrice = newPrices[i];
    
    if (oldPrice && newPrice && oldPrice.price !== newPrice.price) {
      const changeAmount = Math.abs(newPrice.price - oldPrice.price);
      const minChange = 500;
      
      if (changeAmount >= minChange) {
        const changePercent = ((newPrice.price - oldPrice.price) / oldPrice.price * 100).toFixed(1);
        
        changes.push({
          service: service.service_name,
          country: country.name,
          server: i + 1,
          oldPrice: oldPrice.price,
          newPrice: newPrice.price,
          change: parseInt(newPrice.price) - parseInt(oldPrice.price),
          changePercent: changePercent,
          rate: newPrice.rate,
          stock: newPrice.stock
        });
      }
    }
  }
  
  if (changes.length > 0) {
    lastNotificationTime.set(notificationKey, now);
  }
  
  return changes;
}

async function notifyPriceChanges(changes, service, country) {
  try {
    if (changes.length === 0) return;
    
    const priceDownChanges = changes.filter(c => c.change < 0);
    const priceUpChanges = changes.filter(c => c.change > 0);
    
    if (priceDownChanges.length === 0 && priceUpChanges.length === 0) return;
    
    let message = ``;
    
    if (priceDownChanges.length > 0) {
      message += `🟢 <b>HARGA TURUN!</b>\n\n`;
    } else if (priceUpChanges.length > 0) {
      message += `🔴 <b>HARGA NAIK!</b>\n\n`;
    }
    
    message += `<b>${service.service_name} - ${country.name}</b>\n\n`;
    
    if (priceDownChanges.length > 0) {
      message += `<b>💰 HARGA TURUN:</b>\n`;
      priceDownChanges.forEach(change => {
        const discount = Math.abs(change.change);
        message += `• Server ${change.server}: Rp${change.oldPrice.toLocaleString('id-ID')} → <b>Rp${change.newPrice.toLocaleString('id-ID')}</b>\n`;
        message += `  🔻 Turun Rp${discount.toLocaleString('id-ID')} (${Math.abs(change.changePercent)}%)\n`;
        message += `  📊 Rate: ${change.rate}% | 📦 Stok: ${change.stock}\n\n`;
      });
    }
    
    if (priceUpChanges.length > 0) {
      message += `<b>📈 HARGA NAIK:</b>\n`;
      priceUpChanges.forEach(change => {
        const increase = Math.abs(change.change);
        message += `• Server ${change.server}: Rp${change.oldPrice.toLocaleString('id-ID')} → <b>Rp${change.newPrice.toLocaleString('id-ID')}</b>\n`;
        message += `  🔺 Naik Rp${increase.toLocaleString('id-ID')} (${Math.abs(change.changePercent)}%)\n`;
        message += `  📊 Rate: ${change.rate}% | 📦 Stok: ${change.stock}\n\n`;
      });
    }
    
    message += `<i>Update: ${new Date().toLocaleString('id-ID')}</i>`;
    
    await bot.sendMessage(channel, message, {
      parse_mode: 'HTML',
      disable_web_page_preview: true
    });
    
    savePriceChangeHistory({
      service: service.service_name,
      country: country.name,
      changes: changes,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {}
}

function savePriceChangeHistory(data) {
  try {
    const historyFile = path.join(dataDir, 'price_history.json');
    let history = [];
    
    if (fs.existsSync(historyFile)) {
      history = JSON.parse(fs.readFileSync(historyFile, 'utf8'));
    }
    
    history.unshift(data);
    
    if (history.length > 50) {
      history = history.slice(0, 50);
    }
    
    fs.writeFileSync(historyFile, JSON.stringify(history, null, 2));
  } catch (error) {}
}

async function monitorStockLevels() {
  try {
    const servicesData = await getServicesCached();
    
    if (!servicesData || !servicesData.success) {
      return;
    }

    const services = servicesData.data;
    
    for (const service of services) {
      const serviceName = service.service_name.toLowerCase();
      
      if (!serviceName.includes('whatsapp') && !serviceName.includes('telegram')) {
        continue;
      }
      
      const countriesData = await api.getCountries(service.service_code);
      
      if (!countriesData || !countriesData.success) {
        continue;
      }

      const countries = countriesData.data || [];
      
      for (const country of countries) {
        const countryName = country.name.toLowerCase();
        
        if (!countryName.includes('indonesia') && !countryName.includes('indo')) {
          continue;
        }
        
        if (!country.pricelist) continue;
        
        if (country.stock_total < 5) {
          await notifyLowStock(service, country);
        }
      }
    }
    
  } catch (error) {}
}

async function notifyLowStock(service, country) {
  try {
    const cacheKey = `lowstock_${service.service_code}_${country.number_id}`;
    const lastNotified = lastNotificationTime.get(cacheKey) || 0;
    const now = Date.now();
    
    if (now - lastNotified < 4 * 60 * 60 * 1000) {
      return;
    }
    
    const message = `⚠️ <b>STOK MENIPIS!</b>\n\n` +
                   `<b>Layanan:</b> ${service.service_name}\n` +
                   `<b>Negara:</b> ${country.name}\n` +
                   `<b>Stok Tersisa:</b> ${country.stock_total}\n\n` +
                   `<i>Segera tambah stok!</i>`;
    
    await bot.sendMessage(channel, message, {
      parse_mode: 'HTML',
      disable_web_page_preview: true
    });
    
    lastNotificationTime.set(cacheKey, now);
    
  } catch (error) {}
}

async function sendDailyPriceSummary() {
  try {
    const servicesData = await getServicesCached();
    
    if (!servicesData || !servicesData.success) {
      return;
    }

    const services = servicesData.data;
    const targetServices = [];
    
    for (const service of services) {
      const serviceName = service.service_name.toLowerCase();
      
      if (serviceName.includes('whatsapp') || serviceName.includes('telegram')) {
        targetServices.push(service);
      }
      
      if (targetServices.length >= 2) break;
    }
    
    if (targetServices.length === 0) return;
    
    let message = `📊 <b>REKAP HARGA HARIAN</b>\n\n`;
    message += `<i>${new Date().toLocaleDateString('id-ID', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    })}</i>\n\n`;
    
    for (const service of targetServices) {
      const countriesData = await api.getCountries(service.service_code);
      
      if (!countriesData || !countriesData.success || !countriesData.data.length) {
        continue;
      }
      
      const indonesiaCountry = countriesData.data.find(c => 
        c.name.toLowerCase().includes('indonesia') || c.name.toLowerCase().includes('indo')
      );
      
      if (!indonesiaCountry || !indonesiaCountry.pricelist || !indonesiaCountry.pricelist.length) continue;
      
      const server = indonesiaCountry.pricelist[0];
      
      message += `<b>${service.service_name} - Indonesia</b>\n`;
      message += `💰 Rp${server.price.toLocaleString('id-ID')}\n`;
      message += `📊 Rate: ${server.rate}%\n`;
      message += `📦 Stok: ${indonesiaCountry.stock_total}\n`;
      message += `📡 Server: ${indonesiaCountry.pricelist.length}\n\n`;
    }
    
    message += `<i>Pantau terus @${channel.replace('@', '')} untuk update harga!</i>`;
    
    await bot.sendMessage(channel, message, {
      parse_mode: 'HTML',
      disable_web_page_preview: true
    });
    
  } catch (error) {}
}

function scheduleDailySummary() {
  const now = new Date();
  const target = new Date();
  target.setHours(9, 0, 0, 0);
  
  if (now > target) {
    target.setDate(target.getDate() + 1);
  }
  
  const timeUntilTarget = target.getTime() - now.getTime();
  
  setTimeout(() => {
    sendDailyPriceSummary();
    setInterval(sendDailyPriceSummary, 24 * 60 * 60 * 1000);
  }, timeUntilTarget);
}

async function autoBackupTransactions(eventType, data = {}) {
    try {
        const now = new Date();
        const dateStr = now.toISOString().split('T')[0];
        const timeStr = now.getHours().toString().padStart(2, '0') + '-' + 
                       now.getMinutes().toString().padStart(2, '0') + '-' +
                       now.getSeconds().toString().padStart(2, '0');
        
        const backupDir = path.join(__dirname, 'backup');
        if (!fs.existsSync(backupDir)) {
            fs.mkdirSync(backupDir, { recursive: true });
        }
        
        const backupFiles = [
            { name: 'balances.json', file: balanceFile },
            { name: 'users.json', file: datafile },
            { name: 'transactions.json', file: transactionsFile },
            { name: 'settings.json', file: settingsFile }
        ];
        
        const backupFileName = `backup_${dateStr}_${timeStr}.zip`;
        const backupPath = path.join(backupDir, backupFileName);
        
        const output = fs.createWriteStream(backupPath);
        const archive = archiver('zip', {
            zlib: { level: 9 }
        });
        
        output.on('close', async () => {
            const eventMessages = {
                'deposit_success': 'Deposit sukses',
                'deposit_pending': 'Deposit pending',
                'order_success': 'Order sukses',
                'order_cancelled': 'Order dibatalkan',
                'order_expired': 'Order expired',
                'balance_added': 'Saldo ditambahkan',
                'balance_deducted': 'Saldo dikurangi'
            };
            
            const eventMessage = eventMessages[eventType] || 'Event sistem';
            const fileSize = (archive.pointer() / 1024).toFixed(2);
            
            for (const ownerId of owner_ids) {
                try {
                    await bot.sendDocument(ownerId, backupPath, {
                        caption: `📁 Backup Database\n\nEvent: ${eventMessage}\nFile: ${backupFileName}\nSize: ${fileSize} KB\nWaktu: ${now.toLocaleString('id-ID')}`,
                        parse_mode: 'HTML'
                    });
                } catch (error) {}
            }
            
            const maxBackups = 10;
            const files = fs.readdirSync(backupDir)
                .filter(f => f.startsWith('backup_') && f.endsWith('.zip'))
                .sort((a, b) => {
                    const aPath = path.join(backupDir, a);
                    const bPath = path.join(backupDir, b);
                    return fs.statSync(bPath).mtime.getTime() - fs.statSync(aPath).mtime.getTime();
                });
            
            if (files.length > maxBackups) {
                for (let i = maxBackups; i < files.length; i++) {
                    fs.unlinkSync(path.join(backupDir, files[i]));
                }
            }
        });
        
        archive.on('error', (err) => {
        });
        
        archive.pipe(output);
        
        for (const file of backupFiles) {
            if (fs.existsSync(file.file)) {
                archive.file(file.file, { name: file.name });
            }
        }
        
        await archive.finalize();
        
    } catch (error) {}
}

/*async function createBackupOnEvent(eventType, data = {}) {
    try {
        await autoBackupTransactions(eventType, data);
    } catch (error) {}
}*/

// Load user notifications saat bot start
loadUserNotifications();

// Save user notifications secara berkala
setInterval(saveUserNotifications, 30 * 60 * 1000); // Setiap 30 menit

// Save user notifications saat bot dimatikan
process.on('SIGINT', () => {
    saveUserNotifications();
    process.exit(0);
});

process.on('SIGTERM', () => {
    saveUserNotifications();
    process.exit(0);
});

console.log('Bot telah dimulai!');