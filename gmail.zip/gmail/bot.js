const { Telegraf, Markup } = require('telegraf');
const Imap = require('imap');
const { simpleParser } = require('mailparser');
const nodemailer = require('nodemailer');
const { inspect } = require('util');

// Konfigurasi
const BOT_TOKEN = '7569137877:AAHnvva5p9SFclkDpDio8QcJsSfbzlrK6IY';
const ALLOWED_GROUP_ID = '-1002793801544';
const IMAP_CONFIG = {
  user: 'nokosmerah@buatkamu.web.id',
  password: 'Grki6Vv1gdlA',
  host: 'newpinwheel.indowebsite.net',
  port: 993,
  tls: true,
  tlsOptions: { rejectUnauthorized: false }
};

const SMTP_CONFIG = {
  host: 'newpinwheel.indowebsite.net',
  port: 587,
  secure: false,
  auth: {
    user: 'nokosmerah@buatkamu.web.id',
    pass: 'Grki6Vv1gdlA'
  }
};

const bot = new Telegraf(BOT_TOKEN);
const emailTransporter = nodemailer.createTransport(SMTP_CONFIG);
let imapConnection = null;

// Fungsi untuk koneksi IMAP
function connectIMAP() {
  imapConnection = new Imap(IMAP_CONFIG);
  
  imapConnection.once('ready', () => {
    console.log('IMAP Connected');
    checkNewEmails();
  });

  imapConnection.once('error', (err) => {
    console.error('IMAP Error:', err);
  });

  imapConnection.once('end', () => {
    console.log('IMAP Connection ended');
    setTimeout(connectIMAP, 10000); // Reconnect after 10 seconds
  });

  imapConnection.connect();
}

// Fungsi untuk memeriksa email baru
function checkNewEmails() {
  imapConnection.openBox('INBOX', true, (err, box) => {
    if (err) throw err;

    imapConnection.search(['UNSEEN'], (err, results) => {
      if (err) throw err;
      
      if (results.length === 0) return;

      const fetch = imapConnection.fetch(results, { 
        bodies: '',
        markSeen: true 
      });

      fetch.on('message', (msg) => {
        msg.on('body', async (stream) => {
          try {
            const parsed = await simpleParser(stream);
            const emailContent = formatEmail(parsed);
            
            // Kirim ke grup yang diizinkan
            await bot.telegram.sendMessage(
              ALLOWED_GROUP_ID, 
              emailContent,
              { parse_mode: 'HTML' }
            );
          } catch (error) {
            console.error('Error parsing email:', error);
          }
        });
      });

      fetch.once('error', (err) => {
        console.error('Fetch error:', err);
      });
    });
  });
}

// Format email untuk dikirim ke Telegram
function formatEmail(email) {
  return `
📧 <b>Email Baru</b>
────────────────
<b>From:</b> ${email.from?.text || 'Unknown'}
<b>To:</b> ${email.to?.text || 'Unknown'}
<b>Subject:</b> ${email.subject || 'No Subject'}
<b>Date:</b> ${email.date || 'Unknown'}
────────────────
${email.text ? email.text.slice(0, 1000) + (email.text.length > 1000 ? '...' : '') : 'No content'}
  `.trim();
}

// Command handler
bot.command('start', (ctx) => {
  if (ctx.chat.type !== 'private') return;
  
  ctx.reply(`
🤖 <b>Email Bot</b>

Command yang tersedia:
/sendmail - Kirim email baru
/help - Tampilkan bantuan

Bot ini hanya bekerja di grup yang diizinkan.
  `.trim(), { parse_mode: 'HTML' });
});

bot.command('sendmail', async (ctx) => {
  if (ctx.chat.type !== 'private') {
    return ctx.reply('Command ini hanya bisa digunakan di private chat!');
  }

  ctx.reply('Silakan balas pesan ini dengan format:\n\nTo: email@tujuan.com\nSubject: Judul Email\n\nIsi pesan email');
  ctx.session = { waitingForEmail: true };
});

// Handle balasan untuk mengirim email
bot.on('text', async (ctx) => {
  if (ctx.chat.type !== 'private' || !ctx.session?.waitingForEmail) return;

  try {
    const message = ctx.message.text;
    const lines = message.split('\n');
    
    let to = '';
    let subject = '';
    let body = '';

    for (const line of lines) {
      if (line.toLowerCase().startsWith('to:')) {
        to = line.substring(3).trim();
      } else if (line.toLowerCase().startsWith('subject:')) {
        subject = line.substring(8).trim();
      } else {
        body += line + '\n';
      }
    }

    if (!to || !subject || !body) {
      return ctx.reply('Format tidak valid! Pastikan termasuk To:, Subject: dan isi pesan');
    }

    // Kirim email
    await emailTransporter.sendMail({
      from: IMAP_CONFIG.user,
      to,
      subject,
      text: body
    });

    ctx.reply('✅ Email berhasil dikirim!');
    ctx.session.waitingForEmail = false;

  } catch (error) {
    console.error('Error sending email:', error);
    ctx.reply('❌ Gagal mengirim email: ' + error.message);
  }
});

// Handler untuk grup yang tidak diizinkan
bot.on('message', (ctx) => {
  if (ctx.chat.type === 'group' || ctx.chat.type === 'supergroup') {
    if (ctx.chat.id.toString() !== ALLOWED_GROUP_ID.replace('-100', '')) {
      ctx.leaveChat();
    }
  }
});

// Handler ketika bot ditambahkan ke grup
bot.on('chat_member', (ctx) => {
  const chatId = ctx.chat.id.toString();
  const allowedId = ALLOWED_GROUP_ID.replace('-100', '');
  
  if (chatId !== allowedId && ctx.chatMember.new_chat_member.status === 'member') {
    ctx.leaveChat();
  }
});

// Error handling
bot.catch((err, ctx) => {
  console.error(`Error for ${ctx.updateType}:`, err);
});

// Jalankan bot
async function startBot() {
  console.log('Starting Email Bot...');
  
  // Start IMAP connection
  connectIMAP();
  
  // Periodic email check every 1 minute
  setInterval(checkNewEmails, 60000);
  
  // Launch bot
  await bot.launch();
  console.log('Bot started successfully');
}

// Graceful shutdown
process.once('SIGINT', () => {
  bot.stop('SIGINT');
  if (imapConnection) imapConnection.end();
});

process.once('SIGTERM', () => {
  bot.stop('SIGTERM');
  if (imapConnection) imapConnection.end();
});

// Start the bot
startBot().catch(console.error);