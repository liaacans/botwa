const { Telegraf } = require('telegraf');
const { initializeData, startAutoSave } = require('./lib/database');
const { setupCommands } = require('./src/commands');
const { 
    handleNewChatMembers, 
    handleLeftChatMember, 
    handleGroupMessages, 
    handleSharingCommands,
    handleTourlCommand
} = require('./src/handlers');
const { BOT_TOKEN } = require('./config');
const { saveUsers, savePremiumUsers, saveGroups, saveBlacklistGroups, saveGroupSettings } = require('./lib/utils');
const { users, premiumUsers, groups, blacklistGroups, groupSettings } = require('./lib/database');

// Initialize bot
const bot = new Telegraf(BOT_TOKEN);

// Initialize data
initializeData();

// Start auto-save
startAutoSave();

// Setup commands
setupCommands(bot);

// Setup handlers
handleNewChatMembers(bot);
handleLeftChatMember(bot);
handleGroupMessages(bot);
handleSharingCommands(bot);
handleTourlCommand(bot);

// Error handling
bot.catch((err, ctx) => {
    console.error(`Error for ${ctx.updateType}:`, err);
    ctx.reply('❌ Terjadi kesalahan. Silakan coba lagi.');
});

// Start bot
bot.launch().then(() => {
    console.log('🤖 Bot Jasher started successfully!');
});

// Enable graceful stop
process.once('SIGINT', () => {
    bot.stop('SIGINT');
    // Save data before exit
    saveUsers(users);
    savePremiumUsers(premiumUsers);
    saveGroups(groups);
    saveBlacklistGroups(blacklistGroups);
    saveGroupSettings(groupSettings);
    console.log('Data saved before exit');
});

process.once('SIGTERM', () => {
    bot.stop('SIGTERM');
    // Save data before exit
    saveUsers(users);
    savePremiumUsers(premiumUsers);
    saveGroups(groups);
    saveBlacklistGroups(blacklistGroups);
    saveGroupSettings(groupSettings);
    console.log('Data saved before exit');
});