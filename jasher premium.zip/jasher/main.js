const { Telegraf, Markup } = require('telegraf');
const config = require('./config');
const { handleStart, handleHelp, handleCredit, handleShare, handleShareVip, handleBroadcast, handleAddPrem, handleDelPrem, handleListPrem } = require('./src/commands');
const { isPrivateChat, isCreator, runtime, getUserCredits, deductCredits, addCredits } = require('./src/utils');
const moment = require('moment-timezone');

const bot = new Telegraf(config.BOT_TOKEN);

// Middleware untuk menyimpan data pengguna
bot.use(async (ctx, next) => {
  ctx.userData = {
    id: ctx.from.id,
    username: ctx.from.username || `user_${ctx.from.id}`,
    isCreator: isCreator(ctx.from.id)
  };
  await next();
});

// Command handlers
bot.command('start', handleStart);
bot.command('help', handleHelp);
bot.command('credit', handleCredit);
bot.command('share', handleShare);
bot.command('sharevip', handleShareVip);
bot.command('broadcast', handleBroadcast);
bot.command('addprem', handleAddPrem);
bot.command('delprem', handleDelPrem);
bot.command('listprem', handleListPrem);

// Action handlers
bot.action('main_menu', async (ctx) => {
  const sender = ctx.from.username || `user_${ctx.from.id}`;
  const userTelelu = ctx.from.username || `user_${ctx.from.id}`;
  const isCreatorUser = isCreator(ctx.from.id);
  
  await ctx.editMessageText(
    `Hi kak @${sender}
╭─❒ 「 User Info 」 
├ Creator : @${userTelelu}
├ Name : @${sender}
├ Profile : @${sender}
├ ID Telegram Anda: ${ctx.from.id}
├ Hostname : Linux
├ Platform : Bot Telegram
├ Runtime : ${runtime(process.uptime())}
├ Tanggal Server : ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
├ Waktu Server : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')}
╰❒ Owner : ${isCreatorUser ? 'True' : 'False'}
Silahkan pilih button dibawah ini!`,
    {
      reply_markup: {
        inline_keyboard: [
          [
            Markup.button.callback('Jasher Menu', 'jasher_menu'),
            Markup.button.callback('Owner Menu', 'owner_menu')
          ],
          [
            Markup.button.callback('Kembali', 'main_menu'),
            Markup.button.callback('AddGroup', 'add_group')
          ],
          [
            Markup.button.callback('Owner', 'owner_info')
          ]
        ]
      }
    }
  );
});

bot.action('jasher_menu', async (ctx) => {
  await ctx.editMessageText(
    'Jasher Menu:\n- /credit: Cek kredit Anda\n- /share: Share pesan (2 kredit)\n- /sharevip: Share VIP (lebih cepat)',
    {
      reply_markup: {
        inline_keyboard: [
          [Markup.button.callback('Kembali', 'main_menu')]
        ]
      }
    }
  );
});

bot.action('owner_menu', async (ctx) => {
  if (!isCreator(ctx.from.id)) {
    await ctx.answerCbQuery('Hanya owner yang bisa mengakses menu ini!');
    return;
  }
  
  await ctx.editMessageText(
    'Owner Menu:\n- /addprem: Tambah user premium\n- /delprem: Hapus user premium\n- /listprem: List user premium\n- /broadcast: Broadcast ke semua user',
    {
      reply_markup: {
        inline_keyboard: [
          [Markup.button.callback('Kembali', 'main_menu')]
        ]
      }
    }
  );
});

bot.action('add_group', async (ctx) => {
  await ctx.editMessageText(
    'Untuk menambah group, silahkan add bot ke group Anda dan kemudian hubungi owner.',
    {
      reply_markup: {
        inline_keyboard: [
          [Markup.button.callback('Kembali', 'main_menu')]
        ]
      }
    }
  );
});

bot.action('owner_info', async (ctx) => {
  await ctx.editMessageText(
    'Hubungi owner untuk informasi lebih lanjut: @tiaaxl',
    {
      reply_markup: {
        inline_keyboard: [
          [Markup.button.callback('Kembali', 'main_menu')]
        ]
      }
    }
  );
});

// Error handling
bot.catch((err, ctx) => {
  console.error(`Error for ${ctx.updateType}:`, err);
});

// Start bot
bot.launch().then(() => {
  console.log('Bot Jasher started successfully');
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));