const { Markup } = require('telegraf');
const db = require('../lib/database');
const { formatUserInfo } = require('../lib/utils');

async function handleCallbackQuery(ctx) {
  const data = ctx.callbackQuery.data;
  const userId = ctx.from.id;
  const user = await db.getUser(userId);
  
  switch (data) {
    case 'jasher_menu':
      await showJasherMenu(ctx, user);
      break;
      
    case 'owner_menu':
      await showOwnerMenu(ctx, user);
      break;
      
    case 'vip_share':
      await ctx.reply('Balas pesan dengan /sharevip untuk menggunakan fitur VIP Share');
      break;
      
    case 'confirm_share':
      await processShare(ctx, 'regular');
      break;
      
    case 'confirm_vip_share':
      await processShare(ctx, 'vip');
      break;
      
    case 'cancel_share':
      await ctx.editMessageText('❌ Share dibatalkan.');
      break;
      
    case 'owner_broadcast':
      await ctx.reply('Balas pesan dengan /broadcast untuk mengirim pesan ke semua user');
      break;
      
    case 'confirm_broadcast':
      await processBroadcast(ctx);
      break;
      
    case 'cancel_broadcast':
      await ctx.editMessageText('❌ Broadcast dibatalkan.');
      break;
      
    default:
      await ctx.answerCbQuery('❌ Perintah tidak dikenali');
  }
  
  await ctx.answerCbQuery();
}

async function showJasherMenu(ctx, user) {
  const menuText = `🎯 <b>Jasher Menu</b>

<b>Fitur yang tersedia:</b>
• Share pesan ke grup (2 kredit)
• Share VIP (hanya premium)
• Cek kredit

<b>Status:</b>
• Kredit: ${user.credit}
• Grup ditambahkan: ${user.groups.length}/3`;

  await ctx.editMessageCaption(menuText, {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('🔙 Kembali', 'back_to_main')],
      [Markup.button.url('➕ Add Group', 'https://t.me/your_bot_username?startgroup=true')]
    ])
  });
}

async function showOwnerMenu(ctx, user) {
  if (ctx.from.id.toString() !== global.OWNER_ID) {
    return ctx.answerCbQuery('❌ Hanya owner yang dapat mengakses menu ini!');
  }
  
  const premiumCount = (await db.getPremiumUsers()).length;
  const menuText = `👤 <b>Owner Menu</b>

<b>Fitur Owner:</b>
• Tambah/hapus user premium
• Broadcast ke semua user
• Lihat statistik bot

<b>Statistik:</b>
• User premium: ${premiumCount}`;

  await ctx.editMessageCaption(menuText, {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('🔙 Kembali', 'back_to_main')],
      [Markup.button.callback('📋 List Premium', 'list_premium')]
    ])
  });
}

async function processShare(ctx, type) {
  const userId = ctx.from.id;
  const user = await db.getUser(userId);
  const shareMessage = ctx.session.shareMessage;
  
  if (!shareMessage) {
    return ctx.editMessageText('❌ Tidak ada pesan untuk di-share.');
  }
  
  // Simulasi pengiriman ke grup (dalam implementasi nyata, 
  // Anda akan mengirim ke grup yang sudah ditambahkan)
  try {
    // Kurangi kredit
    if (type === 'regular') {
      await db.updateUser(userId, { $inc: { credit: -2 } });
    }
    
    // Edit pesan konfirmasi
    await ctx.editMessageText(
      type === 'vip' 
        ? '✅ Pesan VIP berhasil dikirim ke semua grup!'
        : '✅ Pesan berhasil dikirim ke semua grup! (2 kredit telah dikurangi)'
    );
    
    // Di sini Anda akan mengirim pesan ke grup-grup yang sudah ditambahkan
    // Contoh: 
    // for (const group of user.groups) {
    //   await ctx.telegram.copyMessage(group.id, ctx.chat.id, shareMessage.message_id);
    // }
    
  } catch (error) {
    console.error('Error sharing message:', error);
    await ctx.editMessageText('❌ Gagal mengirim pesan. Silakan coba lagi.');
  }
  
  // Hapus session
  delete ctx.session.shareMessage;
  delete ctx.session.shareType;
}

async function processBroadcast(ctx) {
  const broadcastMessage = ctx.session.broadcastMessage;
  
  if (!broadcastMessage) {
    return ctx.editMessageText('❌ Tidak ada pesan untuk di-broadcast.');
  }
  
  try {
    // Edit pesan konfirmasi
    await ctx.editMessageText('📤 Mengirim broadcast ke semua user...');
    
    // Di sini Anda akan mengirim pesan ke semua user yang terdaftar
    // Contoh:
    // const allUsers = await db.getAllUsers();
    // for (const user of allUsers) {
    //   try {
    //     await ctx.telegram.copyMessage(user.id, ctx.chat.id, broadcastMessage.message_id);
    //   } catch (error) {
    //     console.error(`Gagal mengirim ke user ${user.id}:`, error);
    //   }
    // }
    
    await ctx.editMessageText('✅ Broadcast berhasil dikirim ke semua user!');
    
  } catch (error) {
    console.error('Error broadcasting message:', error);
    await ctx.editMessageText('❌ Gagal mengirim broadcast. Silakan coba lagi.');
  }
  
  // Hapus session
  delete ctx.session.broadcastMessage;
}

module.exports = {
  handleCallbackQuery
};