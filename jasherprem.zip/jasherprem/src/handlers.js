const { Markup } = require('telegraf');
const { User, Group } = require('../lib/database');
const { formatUserInfo } = require('./utils');

async function handleCallbackQuery(ctx) {
  const data = ctx.callbackQuery.data;
  
  try {
    switch (data) {
      case 'jasher_menu':
        await showJasherMenu(ctx);
        break;
      case 'owner_menu':
        await showOwnerMenu(ctx);
        break;
      case 'contact_owner':
        await ctx.answerCbQuery('Hubungi owner di @username_owner');
        break;
      case 'back_to_main':
        await showMainMenu(ctx);
        break;
      default:
        await ctx.answerCbQuery('Menu tidak dikenali');
    }
  } catch (error) {
    console.error('Error handling callback query:', error);
    await ctx.answerCbQuery('Terjadi kesalahan');
  }
}

async function showMainMenu(ctx) {
  const user = await User.findOne({ userId: ctx.from.id });
  const menuText = formatUserInfo(ctx, user);
  
  const menuButtons = Markup.inlineKeyboard([
    [Markup.button.callback('🎯 Jasher Menu', 'jasher_menu')],
    [Markup.button.callback('👤 Owner Menu', 'owner_menu')],
    [Markup.button.url('➕ Add Group', 'https://t.me/your_bot_username?startgroup=true')],
    [Markup.button.callback('👨‍💻 Owner', 'contact_owner')]
  ]);
  
  await ctx.editMessageCaption(menuText, {
    parse_mode: 'HTML',
    ...menuButtons
  });
}

async function showJasherMenu(ctx) {
  const user = await User.findOne({ userId: ctx.from.id });
  const menuText = `🎯 *Jasher Menu*

💰 Kredit: ${user.credit}
⭐ Status: ${user.isPremium ? 'Premium' : 'Regular'}

Fitur yang tersedia:
- /share - Berbagi pesan (2 kredit)
- /sharevip - Berbagi pesan premium (hanya premium)
- /credit - Cek kredit

Tambahkan bot ke 3 grup untuk mendapatkan 10 kredit!`;
  
  const menuButtons = Markup.inlineKeyboard([
    [Markup.button.callback('🔙 Kembali', 'back_to_main')]
  ]);
  
  await ctx.editMessageCaption(menuText, {
    parse_mode: 'Markdown',
    ...menuButtons
  });
}

async function showOwnerMenu(ctx) {
  if (ctx.from.id.toString() !== process.env.OWNER_ID) {
    await ctx.answerCbQuery('Akses ditolak! Hanya owner yang bisa mengakses menu ini.');
    return;
  }
  
  const menuText = `👤 *Owner Menu*

Perintah yang tersedia:
- /addprem @username - Tambah user premium
- /delprem @username - Hapus user premium
- /listprem - Lihat daftar premium
- /broadcast - Broadcast ke semua user

Balas pesan dengan perintah /broadcast untuk mengirim ke semua user.`;
  
  const menuButtons = Markup.inlineKeyboard([
    [Markup.button.callback('🔙 Kembali', 'back_to_main')]
  ]);
  
  await ctx.editMessageCaption(menuText, {
    parse_mode: 'Markdown',
    ...menuButtons
  });
}

async function handleNewChatMembers(ctx) {
  try {
    // Cek jika bot yang ditambahkan ke grup
    if (ctx.message.new_chat_members.some(member => member.is_bot && member.id === ctx.botInfo.id)) {
      const groupId = ctx.chat.id;
      const groupTitle = ctx.chat.title;
      const groupUsername = ctx.chat.username;
      const addedBy = ctx.from.id;
      
      // Simpan info grup ke database
      let group = await Group.findOne({ groupId });
      
      if (!group) {
        group = new Group({
          groupId,
          title: groupTitle,
          username: groupUsername,
          addedBy
        });
        await group.save();
        
        // Beri kredit kepada user yang menambahkan bot
        const user = await User.findOne({ userId: addedBy });
        if (user) {
          // Hitung berapa banyak grup yang telah ditambahkan user
          const userGroups = await Group.find({ addedBy: addedBy });
          
          if (userGroups.length % 3 === 0) {
            // Setiap 3 grup, beri 10 kredit
            user.credit += 10;
            await user.save();
            
            // Kirim pesan ke user
            await ctx.telegram.sendMessage(addedBy, 
              `Terima kasih telah menambahkan bot ke grup ke-${userGroups.length}. Anda mendapatkan 10 kredit! Total kredit: ${user.credit}`
            );
          }
        }
      }
    }
  } catch (error) {
    console.error('Error handling new chat members:', error);
  }
}

module.exports = {
  handleCallbackQuery,
  handleNewChatMembers
};